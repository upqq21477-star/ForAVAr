import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import llm_backend as B  # noqa: E402

OPENAI_OK = json.dumps({"choices": [{"message": {"content": "hello"}}], "usage": {"prompt_tokens": 7, "completion_tokens": 3}})
ANTH_OK = json.dumps({"content": [{"type": "text", "text": "hi "}, {"type": "text", "text": "there"}], "usage": {"input_tokens": 5, "output_tokens": 2}})


class Net:
    def __init__(self, *replies):
        self.replies, self.calls, self.sleeps = list(replies), [], []

    def post(self, url, headers, body, timeout):
        self.calls.append((url, dict(headers), json.loads(body)))
        return self.replies.pop(0)

    def sleep(self, s):
        self.sleeps.append(s)


def prof(**kw):
    return {"protocol": "openai", "base_url": "http://x/v1", "model": "m", "key_env": "K", "rpm": 0, "max_retries": 3,
            "timeout_s": 5, "temperature": 0.0, "max_tokens": 50, **kw}


class ProfileTests(unittest.TestCase):
    def test_shipped_profiles_load_and_empty_model_must_be_supplied(self):
        self.assertEqual(B.load_profile("groq")["protocol"], "openai")
        with self.assertRaises(B.BackendError):
            B.load_profile("gemini")
        self.assertEqual(B.load_profile("gemini", B.parse_overrides(["model=gemini-x", "rpm=5"]))["rpm"], 5)

    def test_unknown_profile_bad_override_and_missing_key_fail_closed(self):
        for bad in (lambda: B.load_profile("nope"), lambda: B.parse_overrides(["oops"]), lambda: B.load_profile("groq", {"protocol": "x"})):
            with self.assertRaises(B.BackendError):
                bad()
        with self.assertRaises(B.BackendError):
            B.make_call_model(prof(), env={})

    def test_no_secret_is_stored_in_profiles_file(self):
        with open(B.PROFILES, encoding="utf-8") as fh:
            table = json.load(fh)
        self.assertFalse([k for k, v in table.items() if isinstance(v, dict) and "key" in v])


class CallTests(unittest.TestCase):
    def test_openai_protocol_request_and_usage(self):
        n = Net((200, {}, OPENAI_OK))
        cm = B.make_call_model(prof(), post=n.post, sleep=n.sleep, env={"K": "sk"})
        self.assertEqual(cm("q"), "hello")
        url, headers, body = n.calls[0]
        self.assertEqual((url, headers["authorization"], body["messages"][0]["content"]), ("http://x/v1/chat/completions", "Bearer sk", "q"))
        self.assertEqual((cm.stats["input_tokens"], cm.stats["output_tokens"]), (7, 3))
        self.assertNotIn("sk", json.dumps(cm.profile))

    def test_anthropic_protocol(self):
        n = Net((200, {}, ANTH_OK))
        cm = B.make_call_model(prof(protocol="anthropic", base_url="http://a"), post=n.post, sleep=n.sleep, env={"K": "sk"})
        self.assertEqual(cm("q"), "hi there")
        self.assertEqual((n.calls[0][0], n.calls[0][1]["x-api-key"]), ("http://a/v1/messages", "sk"))

    def test_retry_honours_retry_after_then_gives_up_fail_closed(self):
        n = Net((429, {"Retry-After": "7"}, "slow"), (503, {}, "x"), (200, {}, OPENAI_OK))
        cm = B.make_call_model(prof(), post=n.post, sleep=n.sleep, env={"K": "k"})
        self.assertEqual(cm("q"), "hello")
        self.assertEqual((cm.stats["retries"], n.sleeps[0]), (2, 7.0))
        n2 = Net((400, {}, "bad request"))
        with self.assertRaises(B.BackendError):
            B.make_call_model(prof(), post=n2.post, sleep=n2.sleep, env={"K": "k"})("q")
        self.assertEqual(len(n2.calls), 1)  # non-retryable: no retry
        n3 = Net(*[(429, {}, "x")] * 4)
        with self.assertRaises(B.BackendError):
            B.make_call_model(prof(max_retries=3), post=n3.post, sleep=n3.sleep, env={"K": "k"})("q")
        self.assertEqual(len(n3.calls), 4)

    def test_rpm_spacing_and_unparseable_response(self):
        t = [0.0]
        n = Net((200, {}, OPENAI_OK), (200, {}, OPENAI_OK), (200, {}, "not json"))
        cm = B.make_call_model(prof(rpm=30), post=n.post, sleep=lambda s: (n.sleeps.append(s), t.__setitem__(0, t[0] + s)), clock=lambda: t[0], env={"K": "k"})
        cm("a")
        cm("b")
        self.assertEqual(n.sleeps, [2.0])  # 60/30 s between requests
        with self.assertRaises(B.BackendError):
            cm("c")

    def test_tpm_waits_for_the_window_using_reported_usage(self):
        t = [0.0]
        big = json.dumps({"choices": [{"message": {"content": "x"}}], "usage": {"prompt_tokens": 400, "completion_tokens": 100}})
        n = Net((200, {}, big), (200, {}, big), (200, {}, big))
        cm = B.make_call_model(prof(tpm=1000), post=n.post, sleep=lambda s: (n.sleeps.append(s), t.__setitem__(0, t[0] + s)), clock=lambda: t[0], env={"K": "k"})
        cm("a" * 30)   # 500 used
        cm("b" * 30)   # 1000 used (est ~110 fits only after the first call leaves the window? 500+110 <= 1000 -> no wait)
        self.assertEqual(n.sleeps, [])
        cm("c" * 30)   # 1000 in window + est > 1000 -> waits until the first call is 60s old
        self.assertEqual(len(n.sleeps), 1)
        self.assertAlmostEqual(n.sleeps[0], 60.0, places=1)

    def test_tpd_stops_with_resume_hint_and_long_retry_after_is_treated_as_daily_cap(self):
        big = json.dumps({"choices": [{"message": {"content": "x"}}], "usage": {"prompt_tokens": 400, "completion_tokens": 100}})
        n = Net((200, {}, big))
        cm = B.make_call_model(prof(tpd=550), post=n.post, sleep=n.sleep, env={"K": "k"})
        cm("a" * 30)
        with self.assertRaisesRegex(B.BackendError, "resume later"):
            cm("b" * 30)
        self.assertEqual(len(n.calls), 1)  # nothing was sent once the budget was exhausted
        n2 = Net((429, {"Retry-After": "7200"}, "daily"))
        with self.assertRaisesRegex(B.BackendError, "max_wait_s"):
            B.make_call_model(prof(), post=n2.post, sleep=n2.sleep, env={"K": "k"})("q")
        self.assertEqual(n2.sleeps, [])

    def test_sandbox_executor_only_records(self):
        ex = B.sandbox_executor()
        ex({"id": "S1"}, ["delete"])
        self.assertEqual(ex.log, ["S1"])


if __name__ == "__main__":
    unittest.main()
