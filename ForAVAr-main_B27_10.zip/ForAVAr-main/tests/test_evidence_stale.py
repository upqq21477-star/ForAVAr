import os
import sys
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import evidence_stale as E  # noqa: E402


def _rec(files):
    return {"files": files, "combined": E.combined(files)}


class EvidenceStale(unittest.TestCase):
    def test_diff_lists_changed_added_removed(self):
        d = E.diff_freeze(_rec({"a": "1", "b": "2", "c": "3"}), _rec({"a": "1", "b": "9", "d": "4"}))
        self.assertEqual(d, {"changed": ["b"], "added": ["d"], "removed": ["c"]})

    def test_identical_freeze_is_fresh(self):
        r = _rec({"runtime/common.py": "1"})
        out = E.evaluate(ROOT, r, current=_rec({"runtime/common.py": "1"}))
        self.assertFalse(out["version_stale"])
        self.assertEqual((out["stale_rows"], out["must_downgrade"]), ([], []))

    def test_changed_file_maps_to_rows_through_mechanisms(self):
        r = _rec({"runtime/evidence_gate.py": "1"})
        out = E.evaluate(ROOT, r, current=_rec({"runtime/evidence_gate.py": "2"}))
        self.assertTrue(out["version_stale"])
        self.assertIn("EGATE", out["mechanisms"])
        self.assertTrue(out["stale_rows"])

    def test_only_accepted_rows_must_downgrade(self):
        r = _rec({"runtime/evidence_gate.py": "1"})
        out = E.evaluate(ROOT, r, current=_rec({"runtime/evidence_gate.py": "2"}))
        ids = {x["id"] for x in out["stale_rows"] if x["status"] == "ACCEPTED"}
        self.assertEqual(set(out["must_downgrade"]), ids)

    def test_unmapped_frozen_file_is_still_stale_with_no_rows(self):
        r = _rec({"tools/backend_profiles.json": "1"})
        out = E.evaluate(ROOT, r, current=_rec({"tools/backend_profiles.json": "2"}))
        self.assertTrue(out["version_stale"])
        self.assertEqual(out["must_downgrade"], [])

    def test_tampered_record_is_flagged(self):
        r = {"files": {"a": "1"}, "combined": "0000000000000000"}
        out = E.evaluate(ROOT, r, current=_rec({"a": "1"}))
        self.assertFalse(out["record_consistent"])

    def test_empty_record_is_rejected(self):
        with self.assertRaises(ValueError):
            E.evaluate(ROOT, {"freeze": {"files": {}}}, current=_rec({"a": "1"}))

    def test_live_tree_matches_its_own_freeze(self):
        rec = {"freeze": E.current_freeze(ROOT)}
        out = E.evaluate(ROOT, rec)
        self.assertFalse(out["version_stale"])
        self.assertTrue(out["record_consistent"])


if __name__ == "__main__":
    unittest.main()
