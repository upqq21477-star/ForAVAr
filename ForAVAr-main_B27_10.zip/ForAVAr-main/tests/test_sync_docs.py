import json
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import jsonio  # noqa: E402
import sync_docs  # noqa: E402

COPY = ("docs", "runtime", "adapters", "tools", "tests")


def _copy(d: str) -> None:
    for rel in COPY:
        shutil.copytree(os.path.join(ROOT, rel), os.path.join(d, rel), ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copy(os.path.join(ROOT, "README.md"), os.path.join(d, "README.md"))


class JsonIo(unittest.TestCase):
    def test_all_docs_roundtrip_exactly(self):
        with tempfile.TemporaryDirectory() as d:
            for n in sorted(os.listdir(os.path.join(ROOT, "docs"))):
                if n.endswith(".json"):
                    src = os.path.join(ROOT, "docs", n)
                    data, fmt = jsonio.load(src)
                    out = os.path.join(d, n)
                    jsonio.save(out, data, fmt)
                    self.assertEqual(open(src, "rb").read(), open(out, "rb").read(), n)

    def test_refuses_layout_it_cannot_reproduce(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.json")
            open(p, "w").write('{"a":   1,\n "b": [1,2]}')
            with self.assertRaises(ValueError):
                jsonio.load(p)

    def test_set_and_append_touch_only_the_target(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.json")
            jsonio.save(p, {"a": {"b/c": 1}, "l": [1]}, {"indent": 1, "nl": True})
            jsonio.set_value(p, "/a/b~1c", 2)
            jsonio.append(p, "/l", 3)
            self.assertEqual(jsonio.load(p)[0], {"a": {"b/c": 2}, "l": [1, 3]})
            with self.assertRaises(ValueError):
                jsonio.append(p, "/a", 1)


class SyncDocs(unittest.TestCase):
    def test_repo_is_in_sync(self):
        self.assertEqual(sync_docs.drift(ROOT), [], "run: python tools/sync_docs.py --write")

    def test_blast_within_ceiling(self):
        self.assertEqual(sync_docs.blast_over(ROOT), [])

    def test_new_feature_needs_no_hand_bookkeeping(self):
        with tempfile.TemporaryDirectory() as d:
            _copy(d)
            open(os.path.join(d, "runtime", "zz_new.py"), "w").write('"""x"""\nfrom common import fail\n')
            open(os.path.join(d, "tests", "test_zz_new.py"), "w").write(
                "import unittest\n\n\nclass T(unittest.TestCase):\n    def test_a(self):\n        pass\n\n    def test_b(self):\n        pass\n")
            found = sync_docs.drift(d)
            self.assertTrue(any("README" in f for f in found) and any("ledger counts" in f for f in found), found)
            self.assertTrue(any("zz_new.py" in f for f in found), found)
            changed = sync_docs.write(d)
            self.assertIn("README.md", changed)
            self.assertEqual(sync_docs.drift(d), [])
            self.assertEqual(sync_docs.write(d), [], "second write must be a no-op")
            self.assertIn("runtime/zz_new.py", json.load(open(os.path.join(d, "README.md".replace("README.md", "docs/features.json"))))["blast_ceiling"])

    def test_ledger_counts_are_recomputed(self):
        with tempfile.TemporaryDirectory() as d:
            _copy(d)
            p = os.path.join(d, "docs", "progress_ledger.json")
            led, fmt = jsonio.load(p)
            led["counts"]["functions"] = 1
            jsonio.save(p, led, fmt)
            self.assertTrue(any("ledger counts" in f for f in sync_docs.drift(d)))
            sync_docs.write(d)
            self.assertEqual(jsonio.load(p)[0]["counts"]["functions"], len(led["functions"]))

    def test_blast_over_reports_a_widened_hub_and_write_never_raises_it(self):
        with tempfile.TemporaryDirectory() as d:
            _copy(d)
            p = os.path.join(d, "docs", "features.json")
            jsonio.set_value(p, "/blast_ceiling/runtime~1common.py", {"modules": 1, "tests": 1})
            over = sync_docs.blast_over(d)
            self.assertTrue(any(o.startswith("runtime/common.py") for o in over), over)
            sync_docs.write(d)
            self.assertEqual(jsonio.get(p, "/blast_ceiling/runtime~1common.py"), {"modules": 1, "tests": 1})


if __name__ == "__main__":
    unittest.main()
