"""Layered brief: L0 is small, L1 prices a route, L2 resolves ids anywhere, handles go stale when the file changes."""
import contextlib
import io
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

import brief as B  # noqa: E402

REPO = os.path.join(HERE, "..")


def text(rel):
    with open(os.path.join(REPO, rel), encoding="utf-8") as fh:
        return fh.read()


def run(*argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = B.main(list(argv))
    return rc, buf.getvalue()


class RealRepo(unittest.TestCase):
    def test_l0_is_a_small_fraction_of_the_docs(self):
        rc, out = run("--root", REPO)
        whole = sum(B.est(text(r)) for r in B._docs(REPO))
        self.assertEqual(rc, 0)
        self.assertIn("purpose:", out)
        self.assertLess(B.est(out), whole * 0.05)

    def test_ids_resolve_across_documents(self):
        rc, out = run("--root", REPO, "CL-027", "IMPORTGRAPH")
        self.assertEqual(rc, 0)
        self.assertIn("docs/change_log.json#/entries/", out)
        self.assertIn("docs/features.json#/mech/IMPORTGRAPH", out)
        rc, out = run("--root", REPO, "PR-001")
        self.assertGreaterEqual(len(out.strip().splitlines()), 2)  # same id lives in problem register, registry and ledger

    def test_unknown_id_is_reported_and_fails(self):
        rc, out = run("--root", REPO, "NO-SUCH-1")
        self.assertEqual(rc, 1)
        self.assertIn("not found: NO-SUCH-1", out)

    def test_route_is_priced_below_its_whole_file(self):
        rc, out = run("--root", REPO, "--route", "Core")
        tok = int(out.split("~")[1].split(" ")[0])
        self.assertEqual(rc, 0)
        self.assertLess(tok, B.est(text("docs/blueprint.json")) * 0.1)


class Synthetic(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.d, "docs"))
        self.put("a.json", {"anything": {"renamed": [{"id": "Z-1", "name": "first"}, {"id": "Z-2", "name": "second"}]},
                            "archive": {"x": {"id": "Z-1", "name": "noise"}}})

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def put(self, name, data):
        with open(os.path.join(self.d, "docs", name), "w", encoding="utf-8") as fh:
            json.dump(data, fh)

    def test_structure_agnostic_and_skips_lookup_tables(self):
        hits = B.resolve(self.d, "Z-1")
        self.assertEqual(len(hits), 1)
        self.assertIn("docs/a.json#/anything/renamed/0", hits[0])

    def test_handle_goes_stale_when_file_changes(self):
        before = B.resolve(self.d, "Z-2")[0].split("@")[1].split("\t")[0]
        self.put("a.json", {"anything": {"renamed": [{"id": "Z-2", "name": "changed"}]}})
        after = B.resolve(self.d, "Z-2")[0].split("@")[1].split("\t")[0]
        self.assertNotEqual(before, after)

    def test_match_cap_and_budget_cut(self):
        self.put("b.json", {"rows": [{"id": "DUP"} for _ in range(9)]})
        hits = B.resolve(self.d, "DUP")
        self.assertEqual(len(hits), B.MAXHIT + 1)
        self.assertIn("more matches", hits[-1])
        rc, out = run("--root", self.d, "--budget", "40", "DUP")
        self.assertTrue(out.strip().endswith("…[cut]"))

    def test_route_cost_matches_estimate_of_pointed_node(self):
        self.put("index.json", {"quick_routes": [{"query": "find first", "file": "docs/a.json", "pointer": "/anything/renamed/0"}]})
        line = B.routes(self.d, ["first"])[0]
        want = B.est(json.dumps({"id": "Z-1", "name": "first"}, ensure_ascii=False))
        self.assertTrue(line.endswith(f"~{want} tok"), line)

    def test_route_ranks_by_words_matched_and_any_word_counts(self):
        self.put("index.json", {"quick_routes": [
            {"query": "alpha only", "file": "docs/a.json", "pointer": "/anything"},
            {"query": "alpha beta both", "file": "docs/a.json", "pointer": "/anything"},
            {"query": "unrelated", "file": "docs/a.json", "pointer": "/anything"}]})
        lines = B.routes(self.d, ["alpha", "beta"])
        self.assertEqual([x.split("\t")[0] for x in lines], ["alpha beta both", "alpha only"])
        self.assertEqual(B.routes(self.d, ["alpha", "beta"], top=1)[0].split("\t")[0], "alpha beta both")
        self.assertEqual(B.routes(self.d, ["nothing-matches"]), [])

    def test_real_repo_finds_the_candidate_flow_route(self):
        rc, out = run("--root", REPO, "--route", "candidate", "gate")
        self.assertEqual(rc, 0)
        self.assertIn("/change_isolation/candidate_flow", out)

    def test_unreadable_docs_do_not_crash(self):
        with open(os.path.join(self.d, "docs", "bad.json"), "w", encoding="utf-8") as fh:
            fh.write("{not json")
        self.assertEqual(len(B.resolve(self.d, "Z-2")), 1)
        self.assertEqual(run("--root", self.d)[0], 0)


if __name__ == "__main__":
    unittest.main()
