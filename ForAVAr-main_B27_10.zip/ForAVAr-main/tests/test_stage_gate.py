"""R1 contract tests: stage-gate recorder (four rejection paths + success + rollback)."""
from __future__ import annotations

import copy
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "tools"))
sys.path.insert(0, os.path.join(HERE, "..", "runtime"))
import stage_gate as G  # noqa: E402

REAL = os.path.join(HERE, "..")
EV = "unit tests ran and passed; evidence recorded in the handoff"
OK = lambda root: []  # noqa: E731


class StageGateTests(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.d, "docs"))
        shutil.copy(os.path.join(REAL, "docs", "progress_ledger.json"), os.path.join(self.d, "docs"))
        path = os.path.join(self.d, G.LEDGER_REL)  # fixed starting point: PLANNING passed, the rest not started
        with open(path, encoding="utf-8") as fh:
            led = json.load(fh)
        led["stage_gates"] = [led["stage_gates"][0]] + [{"stage": s, "status": "NOT_STARTED"} for s in G.STAGES[1:]]
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(led, fh, ensure_ascii=False)
        self.addCleanup(shutil.rmtree, self.d, True)

    def gates(self):
        with open(os.path.join(self.d, G.LEDGER_REL), encoding="utf-8") as fh:
            return json.load(fh)["stage_gates"]

    def rec(self, stage, status="PASSED", **kw):
        kw.setdefault("batch", "B23")
        kw.setdefault("reviewer", "SELF")
        kw.setdefault("evidence", EV)
        kw.setdefault("ledger_check", OK)
        return G.record_gate(self.d, stage, status, **kw)

    def test_rejects_skipping_a_stage(self):
        before = self.gates()
        with self.assertRaisesRegex(G.GateRejected, "not PASSED"):
            self.rec("CLOSURE")
        self.assertEqual(self.gates(), before)

    def test_rejects_passed_without_evidence_or_reviewer(self):
        for kw in ({"evidence": ""}, {"evidence": "short"}, {"reviewer": ""}):
            with self.assertRaises(G.GateRejected):
                self.rec("REALIZATION", **kw)
        self.assertEqual(self.gates()[1]["status"], "NOT_STARTED")

    def test_rejects_when_ledger_integrity_fails(self):
        with self.assertRaisesRegex(G.GateRejected, "integrity"):
            self.rec("REALIZATION", ledger_check=lambda r: ["ledger_ids: broken"])
        self.assertEqual(self.gates()[1]["status"], "NOT_STARTED")

    def test_rejects_when_write_is_rolled_back(self):
        with open(os.path.join(self.d, G.LEDGER_REL), encoding="utf-8") as fh:
            before = fh.read()
        with self.assertRaisesRegex(G.GateRejected, "rolled back"):
            self.rec("REALIZATION", verify=lambda r: ["incompatible"])
        with open(os.path.join(self.d, G.LEDGER_REL), encoding="utf-8") as fh:
            self.assertEqual(fh.read(), before)

    def test_passed_is_immutable_and_unknown_inputs_rejected(self):
        with self.assertRaisesRegex(G.GateRejected, "immutable"):
            self.rec("PLANNING")
        with self.assertRaises(G.GateRejected):
            self.rec("NOPE")
        with self.assertRaises(G.GateRejected):
            self.rec("REALIZATION", status="NOT_STARTED")

    def test_success_records_and_chain_advances(self):
        out = self.rec("REALIZATION")
        self.assertEqual(out["txn"], "COMMITTED")
        g = self.gates()
        self.assertEqual((g[1]["status"], g[1]["reviewer"]), ("PASSED", "SELF"))
        self.assertEqual(g[2]["status"], "NOT_STARTED")
        self.rec("CLOSURE")  # now allowed

    def test_failed_records_reason_and_blocks_next(self):
        self.rec("REALIZATION", status="FAILED", evidence="tests red in R7")
        self.assertEqual(self.gates()[1]["status"], "FAILED")
        with self.assertRaises(G.GateRejected):
            self.rec("CLOSURE")
        self.rec("REALIZATION", batch="B24", retry_of="B23")
        self.assertEqual(self.gates()[1]["retry_of"], "B23")

    def test_final_test_needs_independent_reviewer(self):
        for s in ("REALIZATION", "CLOSURE"):
            self.rec(s)
        with self.assertRaisesRegex(G.GateRejected, "independent"):
            self.rec("FINAL_TEST")
        self.rec("FINAL_TEST", independent=True)

    def test_real_ledger_passes_default_integrity_check(self):
        self.assertEqual(G._ledger_errors(REAL), [])


if __name__ == "__main__":
    unittest.main()
