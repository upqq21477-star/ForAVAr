"""B24 C2: closure regression. The 24 scenarios resolved in B22/B23 (formerly foravab data/closure_resolved.json),
each run through the live slice / controller. Rows 00-23 keep their original order. The three optional stages
(frame gate / model / synthesis) are checked for "added, not regressed" at the end."""
import os
import sys
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "runtime"))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

from foravar_vertical_slice import FAILURE_BRANCHES, FAILURE_CLASSES, run_vertical_slice  # noqa: E402
from loop_controller import REENTRY, run_closed_loop  # noqa: E402
from loop_fixtures import HIGH, LOW, OBS, TID, Fake, failing, good_exec, passing, task, unknown  # noqa: E402

GRANT = lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A", "authorized_scope": ["w"]}  # noqa: E731
EV0 = {"task_id": TID, "status": "READY", "records": [OBS], "critical_unknowns": []}
HI_OK = {"route": {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m", "m2"], "selected_method": "m", "reason": "r",
                   "stop_rule": "s", "requires_authorization": True, "required_scope": ["w"]}}


def boom(*a):
    raise RuntimeError("boom")


def run(profile=None, fake=None, **ad):
    fake = fake or Fake()
    return run_vertical_slice(task(profile), fake.adapters(**ad)), fake


def frame(status="READY", **kw):
    return {"task_id": TID, "status": status, "frame_id": "F", "problem_statement": "p", "in_scope": [], "out_of_scope": [],
            "unknowns": [], **kw}


class ScenarioCatalogue(unittest.TestCase):
    def test_00_frame_blocked_or_not_proven(self):
        for st in ("BLOCKED", "NOT_PROVEN"):
            r, f = run(frame=lambda t, st=st: frame(st, reason="x"))
            self.assertEqual(r["status"], st)
            self.assertEqual(f.calls["execute"], 0)

    def test_01_evidence_blocked(self):
        r, f = run(evidence=lambda t, fr: {"task_id": TID, "status": "BLOCKED", "records": [], "critical_unknowns": [], "reason": "x"})
        self.assertEqual((r["status"], f.calls["execute"]), ("BLOCKED", 0))

    def test_02_high_risk_with_critical_unknown(self):
        ev = {"task_id": TID, "status": "PARTIAL", "records": [OBS], "critical_unknowns": ["u"]}
        r, f = run(HIGH, evidence=lambda t, fr: ev, **HI_OK, authorize=GRANT)
        self.assertEqual((r["status"], f.calls["execute"]), ("BLOCKED", 0))

    def test_03_route_rejected_or_not_proven(self):
        for st in ("REJECTED", "NOT_PROVEN"):
            r, f = run(route=lambda t, fr, e, st=st: {"task_id": TID, "status": st, "reason": "x"})
            self.assertEqual(r["status"], st)
            self.assertEqual(f.calls["execute"], 0)

    def test_04_authorization_denied_or_backend_fault_fails_closed(self):
        route = lambda t, fr, e: HI_OK["route"]  # noqa: E731
        for auth in (boom, lambda t, r: "yes", lambda t, r: {"task_id": TID, "status": "DENIED", "reason": "no"}):
            r, f = run(HIGH, evidence=lambda t, fr: EV0, authorize=auth, route=route)
            self.assertEqual(r["status"], "BLOCKED")
            self.assertEqual(f.calls["execute"], 0)

    def test_05_execute_non_success_states(self):
        want = {"FAILED": "FAILED", "BLOCKED": "BLOCKED", "NOT_RUN": "NOT_EXECUTED"}
        for st, out in want.items():
            r, _ = run(execute=lambda t, f, e, rt, st=st: {**good_exec(), "status": st, "reason": "x"})
            self.assertEqual(r["status"], out)
            if st == "FAILED":
                self.assertIn("run_record", r)
        r, _ = run(execute=lambda t, f, e, rt: {**good_exec(), "status": "PARTIAL"})
        self.assertEqual(r["status"], "PARTIAL")

    def test_06_execute_timeout(self):
        r, _ = run(HIGH, evidence=lambda t, fr: EV0, authorize=GRANT, route=lambda t, fr, e: HI_OK["route"],
                   execute=lambda *a: (_ for _ in ()).throw(TimeoutError("t")))
        self.assertEqual(r["status"], "INCONCLUSIVE")
        self.assertTrue(r["unknown_side_effect"])
        r2, _ = run(execute=lambda *a: {**good_exec(), "status": "TIMEOUT_UNKNOWN_SIDE_EFFECT"})
        self.assertEqual(r2["status"], "INCONCLUSIVE")

    def test_07_evaluation_unknown_or_unevidenced_is_not_proven(self):
        for ev in (unknown(), passing(ids=()), {"task_id": TID, "criteria_results": []}):
            r, _ = run(evaluate=lambda t, x, e, ev=ev: ev)
            self.assertEqual(r["status"], "NOT_PROVEN")

    def test_08_evaluation_fail_per_failure_branch(self):
        seen = {}
        for b in sorted(FAILURE_BRANCHES - {"NONE"}):
            r, _ = run(evaluate=lambda t, x, e, b=b: failing(b))
            self.assertEqual(r["status"], "FAILED", b)
            seen[b] = r["feedback"]["action"]
            self.assertIn(seen[b], REENTRY, b)
        self.assertEqual(len(set(seen.values())), len(seen))  # every branch has its own return action

    def test_09_pre_execute_adapter_exception_is_named(self):
        for stage in ("frame", "evidence", "route"):
            r, f = run(**{stage: boom})
            self.assertIn("feedback", r, stage)
            self.assertNotEqual(r["status"], "PASS", stage)
            self.assertEqual(f.calls["execute"], 0, stage)

    def test_10_execute_exception_with_unknown_effect_is_inconclusive(self):
        r, _ = run(HIGH, evidence=lambda t, fr: EV0, authorize=GRANT, route=lambda t, fr, e: HI_OK["route"],
                   execute=lambda *a: (_ for _ in ()).throw(ConnectionError("dropped")))
        self.assertEqual(r["status"], "INCONCLUSIVE")

    def test_11_evaluate_exception_is_not_proven_and_never_reexecutes(self):
        r, f = run(evaluate=boom)
        self.assertEqual(r["status"], "NOT_PROVEN")
        self.assertEqual(f.calls["execute"], 1)

    def test_12_contract_violations_are_named_exits(self):
        r, _ = run(execute=lambda *a: {**good_exec(), "task_id": "OTHER"})  # task_id mismatch
        self.assertNotEqual(r["status"], "PASS")
        self.assertIn("feedback", r)
        ad = Fake().adapters()
        del ad["evaluate"]  # missing adapter
        r = run_vertical_slice(task(), ad)
        self.assertNotEqual(r["status"], "PASS")
        self.assertIn("feedback", r)
        r = run_vertical_slice({"task_id": ""}, Fake().adapters())  # invalid task
        self.assertNotEqual(r["status"], "PASS")
        self.assertIn("feedback", r)

    def test_13_persistence_failure_rolls_back_with_class(self):
        import tempfile
        with tempfile.TemporaryDirectory() as d:
            root, snap = os.path.join(d, "r"), os.path.join(d, "s")
            os.makedirs(root)
            fk = Fake(evaluate_script=[failing("LOCAL_FAILURE")] * 3)
            out = run_closed_loop(task(), fk.adapters(), budget={"max_attempts": 2},
                                  persist={"root": os.path.join(d, "missing", "x" * 5000), "snap_dir": snap})
            self.assertEqual(out["stop"]["condition"], "PERSISTENCE_FAULT")
            self.assertEqual(out["stop"]["failure_class"], "PERSISTENCE_OR_STATE_ERROR")

    def test_14_change_set_mismatch_names_class(self):
        from error_exits import change_set_guard
        out = change_set_guard(TID, {"allowed_to_change": ["a.py", "b.py"]}, ["a.py", "c.py"])
        self.assertEqual(out["failure_class"], "INTEGRATION_OR_DEPENDENCY_UPDATE_ERROR")

    def test_15_stage_skipping_is_refused(self):
        import json
        import shutil
        import tempfile
        import stage_gate as G
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "docs"))
            shutil.copy(os.path.join(HERE, "..", G.LEDGER_REL), os.path.join(d, "docs"))
            path = os.path.join(d, G.LEDGER_REL)
            with open(path, encoding="utf-8") as fh:
                led = json.load(fh)
            led["stage_gates"] = [{"stage": s, "status": "NOT_STARTED"} for s in G.STAGES]
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(led, fh, ensure_ascii=False)
            with self.assertRaises(G.GateRejected):
                G.record_gate(d, "CLOSURE", "PASSED", batch="B99", reviewer="t", evidence="x" * 80, ledger_check=lambda r: [])

    def test_16_blueprint_nodes_and_branches_have_owner(self):
        import json
        with open(os.path.join(HERE, "..", "docs", "blueprint.json"), encoding="utf-8") as fh:
            bp = json.load(fh)
        nodes = {n["id"] for n in bp["architecture"]["skeleton_nodes"]}
        self.assertEqual(len(nodes), 18)
        owned = json.dumps(bp["architecture"]["conditional_framework"], ensure_ascii=False)
        for n in ("N16", "N17"):
            self.assertIn(n, owned)

    def test_17_unresolved_conflict_low_risk_cannot_pass(self):
        ev = {"task_id": TID, "status": "CONFLICT", "records": [OBS, {**OBS, "evidence_id": "E2"}],
              "conflicts": [{"conflict_id": "K1", "evidence_ids": ["E1", "E2"]}], "critical_unknowns": []}
        r, _ = run(evidence=lambda t, fr: ev)
        self.assertEqual(r["status"], "PARTIAL")
        self.assertEqual(r["feedback"]["action"], "RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE")

    def test_18_unresolved_conflict_high_risk_blocks_before_execute(self):
        ev = {"task_id": TID, "status": "CONFLICT", "records": [OBS, {**OBS, "evidence_id": "E2"}],
              "conflicts": [{"conflict_id": "K1", "evidence_ids": ["E1", "E2"]}], "critical_unknowns": []}
        r, f = run(HIGH, evidence=lambda t, fr: ev, authorize=GRANT, route=lambda t, fr, e: HI_OK["route"])
        self.assertEqual((r["status"], f.calls["execute"]), ("BLOCKED", 0))

    def test_19_stale_evidence_blocks_pass_even_when_uncited(self):  # known trade-off 1: gate reads ALL OBSERVED records
        old = {**OBS, "evidence_id": "E9", "valid_until": "2000-01-01T00:00:00Z"}
        ev = {"task_id": TID, "status": "READY", "records": [OBS, old], "critical_unknowns": []}
        r, _ = run(evidence=lambda t, fr: ev)  # passing() cites only E1
        self.assertEqual(r["status"], "PARTIAL")
        self.assertIn("E9", r["feedback"]["reason"])
        stale_rev = {**OBS, "target_revision": "r0"}  # pinned target_revision differs
        ad = Fake().adapters(evidence=lambda t, fr: {**EV0, "records": [stale_rev]})
        self.assertEqual(run_vertical_slice({**task(), "target_revision": "r1"}, ad)["status"], "PARTIAL")

    def test_20_feedback_action_is_consumed_by_controller(self):
        fk = Fake(evaluate_script=[failing("METHOD_FAILURE"), passing()])
        h = {"REROUTE_METHOD": lambda ctx: {"method": "m2", "discriminating_change": True}}
        out = run_closed_loop(task(), fk.adapters(), budget={"max_attempts": 3}, handlers=h)
        self.assertEqual(out["final_status"], "PASS")
        self.assertEqual(out["attempts"], 2)

    def test_21_failed_without_attribution_is_classified_first(self):
        fk = Fake(evaluate_script=[{"task_id": TID, "criteria_results": [{"criterion_id": "C1", "status": "FAIL", "evidence_ids": ["E1"]}]}])
        out = run_closed_loop(task(), fk.adapters(), budget={"max_attempts": 2}, handlers={})
        self.assertNotEqual(out["final_status"], "PASS")
        self.assertIn("failure_class", out["stop"])

    def test_22_all_failure_classes_exist(self):
        self.assertEqual(len(FAILURE_CLASSES), 10)

    def test_23_budget_exhausted_stops_with_state(self):
        fk = Fake(evaluate_script=[RuntimeError("boom")])  # permanently broken evaluator: bounded, never PASS
        out = run_closed_loop(task(), fk.adapters(), budget={"max_attempts": 3}, handlers={})
        self.assertEqual((out["final_status"], out["stop"]["condition"], out["stop"]["failure_class"]),
                         ("PARTIAL", "BUDGET_EXHAUSTED", "COST_OR_STOP_ERROR"))
        self.assertEqual(fk.calls["execute"], 1)


class OptionalStagesNotRegressed(unittest.TestCase):
    """frame gate (profile opt-in), model adapter, synthesis adapter: absent = unchanged, present+valid = PASS, present+bad = stopped."""
    FRAME = {"task_id": TID, "status": "READY", "frame_id": "F", "problem_statement": "p", "in_scope": ["a"],
             "out_of_scope": [{"item": "b", "reason": "not requested"}], "unknowns": [],
             "dependencies": [{"id": "D1", "direction": "UPSTREAM", "status": "KNOWN", "impact": "LOW"}]}
    MODEL = {"task_id": TID, "status": "READY", "model_id": "M1", "elements": [{"id": "a", "label": "A"}, {"id": "b", "label": "B"}],
             "relations": [{"id": "r1", "source": "a", "target": "b", "basis": "EVIDENCED", "evidence_ids": ["E1"]}],
             "conditions": [{"id": "c1", "statement": "x", "applies_to": ["r1"]}],
             "unknowns": [{"id": "u1", "statement": "s", "affects": ["b"]}],
             "hypotheses": [{"id": "H1", "statement": "s1", "discriminating_test": "t1"}, {"id": "H2", "statement": "s2", "discriminating_test": "t2"}]}
    SYNTH = {"task_id": TID, "status": "READY", "synthesis_id": "S1", "unresolved": [{"id": "u1", "statement": "b stability still unknown"}],
             "conclusions": [{"id": "k1", "statement": "a holds", "basis": "EVIDENCED", "confidence": "HIGH", "evidence_ids": ["E1"]}]}

    def test_baseline_unchanged_without_optional_stages(self):
        r, _ = run()
        self.assertEqual(r["status"], "PASS")
        self.assertIsNone(r.get("model"))
        self.assertIsNone(r.get("synthesis"))

    def test_all_three_stages_added_and_valid_still_pass(self):
        r, _ = run({**LOW, "frame_gate": True}, frame=lambda t: self.FRAME, model=lambda t, f, e: self.MODEL,
                   synthesis=lambda t, e, ev: self.SYNTH)
        self.assertEqual(r["status"], "PASS")
        for k in ("frame_gate", "model_gate", "synthesis_gate"):
            self.assertTrue(r[k]["ok"], k)

    def test_each_bad_stage_stops_the_run(self):
        bad_frame = {**self.FRAME, "in_scope": []}
        r, f = run({**LOW, "frame_gate": True}, frame=lambda t: bad_frame)
        self.assertNotEqual(r["status"], "PASS")
        self.assertEqual(f.calls["execute"], 0)
        r, f = run(model=lambda t, fr, e: {**self.MODEL, "elements": []})
        self.assertNotEqual(r["status"], "PASS")
        self.assertEqual(f.calls["execute"], 0)
        r, _ = run(synthesis=lambda t, e, ev: {**self.SYNTH, "conclusions": [{**self.SYNTH["conclusions"][0], "evidence_ids": ["NOPE"]}]})
        self.assertNotEqual(r["status"], "PASS")

    def test_gates_are_opt_in_by_design(self):  # C2 decision: no default-on; frame gate needs profile.frame_gate, others need the adapter
        bad_frame = {**self.FRAME, "in_scope": []}
        r, _ = run(LOW, frame=lambda t: bad_frame)
        self.assertEqual(r["status"], "PASS")
        self.assertIsNone(r.get("frame_gate"))


if __name__ == "__main__":
    unittest.main()
