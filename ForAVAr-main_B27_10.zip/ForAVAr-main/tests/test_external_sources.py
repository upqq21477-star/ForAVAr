"""External source registry: schema, adoption rules, vendored-hash drift, due list (offline)."""
import copy
import datetime
import hashlib
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

import external_sources as XS  # noqa: E402

REPO = os.path.join(HERE, "..")


def row(**kw):
    r = {"id": "XS-T", "name": "t", "kind": "tool", "url": "https://example.org/t", "license": "MIT", "seen_on": "2026-10-26",
         "pinned": "v1.0", "status": "PINNED", "adopted": False, "integration": "none", "absorbed_into": [],
         "check_every_days": 30, "last_checked": "2026-10-26", "cooldown_days": 14, "on_update": "candidate_gate"}
    r.update(kw)
    return r


class Case(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        os.makedirs(os.path.join(self.d, "docs"))
        with open(os.path.join(self.d, "vend.py"), "w", encoding="utf-8") as fh:
            fh.write("x = 1\n")

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def put(self, *rows):
        with open(os.path.join(self.d, XS.REGISTRY), "w", encoding="utf-8") as fh:
            json.dump({"schema": "x", "sources": list(rows)}, fh)

    def test_real_registry_is_valid(self):
        self.assertEqual(XS.check(REPO), [])

    def test_valid_rows_pass(self):
        self.put(row(), row(id="XS-A", adopted=True, integration="idea_only", absorbed_into=["vend.py"]))
        self.assertEqual(XS.check(self.d), [])

    def test_bad_fields_reported(self):
        for bad in (row(kind="x"), row(status="x"), row(url="http://x"), row(last_checked="soon"), row(cooldown_days=-1),
                    row(on_update="merge"), row(id="t")):
            self.put(bad)
            self.assertTrue(XS.check(self.d), bad)

    def test_missing_field_and_duplicate(self):
        r = row()
        del r["license"]
        self.put(r)
        self.assertIn("XS-T: missing license", XS.check(self.d))
        self.put(row(), row())
        self.assertIn("XS-T: duplicate id", XS.check(self.d))

    def test_adoption_rules(self):
        for bad in (row(adopted=True, integration="idea_only"),                                    # nothing absorbed
                    row(adopted=True, integration="idea_only", absorbed_into=["vend.py"], pinned="UNPINNED"),
                    row(adopted=True, integration="none", absorbed_into=["vend.py"]),
                    row(adopted=False, integration="vendored"),
                    row(adopted=True, integration="idea_only", absorbed_into=["gone.py"])):          # target missing
            self.put(bad)
            self.assertTrue(XS.check(self.d), bad)

    def test_vendored_hash_drift_detected(self):
        good = hashlib.sha256(b"x = 1\n").hexdigest()
        v = row(adopted=True, integration="vendored", absorbed_into=["vend.py"], sha256={"vend.py": good})
        self.put(v)
        self.assertEqual(XS.check(self.d), [])
        with open(os.path.join(self.d, "vend.py"), "w", encoding="utf-8") as fh:
            fh.write("x = 2\n")
        self.assertTrue(any("hash differs" in p for p in XS.check(self.d)))
        self.put(copy.deepcopy(dict(v, sha256={})))
        self.assertTrue(any("needs sha256" in p for p in XS.check(self.d)))

    def test_due_is_informational_and_dated(self):
        self.put(row(last_checked="2026-10-01"), row(id="XS-B", last_checked="2026-10-20"), row(id="XS-C", status="DROPPED", last_checked="2020-01-01"))
        self.assertEqual([x.split("\t")[0] for x in XS.due(self.d, datetime.date(2026, 11, 5))], ["XS-T"])
        self.assertEqual(XS.check(self.d), [])  # overdue never fails the check

    def test_unreadable_registry_reports(self):
        self.assertTrue(XS.check(self.d)[0].startswith(XS.REGISTRY))


if __name__ == "__main__":
    unittest.main()
