"""R6 contract tests: blueprint closed_loop.error_exits (nine events), no exception escapes the slice."""
from __future__ import annotations

import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "runtime"))
sys.path.insert(0, HERE)

import error_exits as X  # noqa: E402
import state_bundle as SB  # noqa: E402
from test_runtime_contract import HIGH, LOW, TID, run, task  # noqa: E402

ROUTE_W = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                           "selected_method": "m", "reason": "r", "stop_rule": "s",
                           "requires_authorization": True, "required_scope": ["write"]}
GRANT = lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A1",  # noqa: E731
                      "authorized_scope": ["write"]}
EV0 = lambda t, f: {"task_id": TID, "status": "READY", "records": [], "critical_unknowns": []}  # noqa: E731


def boom(*a):
    raise RuntimeError("adapter exploded")


class ErrorExitTests(unittest.TestCase):
    def check(self, out, event):
        status, action, cls = X.ERROR_EXITS[event]
        self.assertEqual((out["status"], out["event"], out["failure_class"]), (status, event, cls))
        self.assertEqual(out["feedback"]["action"], action)
        self.assertTrue(out["error"]["stage"] or out["error"]["message"])

    def test_1_task_invalid(self):
        out, _ = run({**task(), "goal": ""})
        self.check(out, "TASK_INVALID")
        from foravar_vertical_slice import run_vertical_slice
        for bad in ("not-a-mapping", None):
            out = run_vertical_slice(bad, {})
            self.check(out, "TASK_INVALID")
            self.assertEqual(out["task_id"], "UNKNOWN")

    def test_2_adapter_fault_each_pre_execute_stage(self):
        t = task({**LOW, "requires_external_evidence": True})
        for name in ("frame", "evidence", "route"):
            out, _ = run(t, **{name: boom})
            self.check(out, "ADAPTER_FAULT")
            self.assertEqual(out["error"]["stage"], name)
            self.assertEqual(out["error"]["type"], "RuntimeError")
            self.assertNotIn("EXECUTION", out["trace"])

    def test_2b_missing_adapter_is_a_named_exit(self):
        out, _ = run(task({**LOW, "requires_external_evidence": True}), route=None)
        self.check(out, "ADAPTER_FAULT")

    def test_3_execute_exception_with_possible_side_effect_is_inconclusive(self):
        n = []
        def ex(t, f, e, r):
            n.append(1)
            raise ConnectionError("dropped")
        out, calls = run(task({**HIGH}), route=ROUTE_W, authorize=GRANT, evidence=EV0, execute=ex)
        self.check(out, "EXECUTE_FAULT_UNKNOWN_EFFECT")
        self.assertTrue(out["unknown_side_effect"])
        self.assertEqual(out["run_record"]["result_status"], "TIMEOUT_UNKNOWN_SIDE_EFFECT")
        self.assertEqual(len(n), 1)  # never retried here
        self.assertNotIn("evaluate", calls)

    def test_3b_execute_output_violating_contract_counts_as_execute_fault(self):
        bad = lambda t, f, e, r: {"task_id": TID, "status": "EXECUTED"}  # noqa: E731 (no execution_id)
        out, _ = run(task({**HIGH}), route=ROUTE_W, authorize=GRANT, evidence=EV0, execute=bad)
        self.check(out, "EXECUTE_FAULT_UNKNOWN_EFFECT")

    def test_4_execute_exception_declared_no_effect_is_failed(self):
        out, _ = run(execute=boom)
        self.check(out, "EXECUTE_FAULT_NO_EFFECT")
        self.assertNotIn("unknown_side_effect", out)
        self.assertEqual(out["run_record"]["result_status"], "FAILED")

    def test_5_evaluate_fault_keeps_execution_and_never_reexecutes(self):
        out, calls = run(evaluate=boom)
        self.check(out, "EVALUATE_FAULT")
        self.assertEqual(calls.count("execute"), 1)
        self.assertIn("execution", out)
        self.assertIn("run_record", out)
        bad = lambda t, x, e: {"task_id": TID, "criteria_results": "nope"}  # noqa: E731
        self.check(run(evaluate=bad)[0], "EVALUATE_FAULT")

    def test_6_authorization_backend_fault_blocks(self):
        out, calls = run(task({**HIGH}), route=ROUTE_W, authorize=boom, evidence=EV0)
        self.assertEqual(out["status"], "BLOCKED")
        self.assertEqual(out["failure_class"], "AUTHORIZATION_OR_POLICY_BLOCK")
        self.assertNotIn("execute", calls)
        status, action, cls = X.ERROR_EXITS["AUTHORIZATION_FAULT"]
        self.assertEqual((status, cls), ("BLOCKED", "AUTHORIZATION_OR_POLICY_BLOCK"))

    def test_7_persistence_fault_reports_rollback(self):
        out = X.persistence_guard(TID, boom)
        self.check(out, "PERSISTENCE_FAULT")
        self.assertTrue(out["rolled_back"])
        with tempfile.TemporaryDirectory() as d:  # real path: authority files are refused, nothing written
            bundle = SB.build_bundle(TID, "P1")
            out = X.persistence_guard(TID, SB.persist_checkpoint, d, os.path.join(d, "snap"), bundle,
                                      extra_files={"docs/blueprint.json": "{}"})
            self.check(out, "PERSISTENCE_FAULT")
            self.assertFalse(os.path.exists(os.path.join(d, "docs", "blueprint.json")))
            ok = X.persistence_guard(TID, SB.persist_checkpoint, d, os.path.join(d, "snap2"), bundle)
            self.assertEqual(ok["status"], "PERSISTED")

    def test_8_change_set_mismatch(self):
        plan = {"allowed_to_change": ["A", "B"]}
        self.assertEqual(X.change_set_guard(TID, plan, ["A"])["status"], "WITHIN_PLAN")
        out = X.change_set_guard(TID, plan, ["A", "Z"])
        self.check(out, "CHANGE_SET_MISMATCH")
        self.assertEqual(out["unexpected"], ["Z"])
        self.check(X.change_set_guard(TID, {}, ["A"]), "CHANGE_SET_MISMATCH")

    def test_9_conflict_or_stale_row_exists_and_is_partial(self):
        self.assertEqual(X.exit_for("EVIDENCE_CONFLICT_OR_STALE")[0], "PARTIAL")  # runtime gate lands with R8

    def test_no_exception_escapes_any_stage(self):
        t = task({**LOW, "requires_external_evidence": True})
        for exc in (RuntimeError, KeyError, ValueError, TypeError, ZeroDivisionError, OSError):
            def f(*a, exc=exc):
                raise exc("x")
            for name in ("frame", "evidence", "route", "execute", "evaluate"):
                out, _ = run(t, **{name: f})
                self.assertIn(out["status"], {"FAILED", "INCONCLUSIVE", "NOT_PROVEN", "BLOCKED"}, (exc, name))
                self.assertTrue(out["feedback"]["action"])

    def test_table_matches_blueprint(self):
        with open(os.path.join(HERE, "..", "docs", "blueprint.json"), encoding="utf-8") as fh:
            rows = json.load(fh)["architecture"]["closed_loop"]["error_exits"]["map"]
        norm = lambda s: s.split("（")[0].replace("／", "_OR_")  # noqa: E731
        bp = {(norm(r["status"]), norm(r["action"]), r["class"]) for r in rows}
        mine = {(s, a, c) for s, a, c in X.ERROR_EXITS.values()}
        self.assertEqual(bp - mine, set(), "blueprint rows missing in error_exits")
        self.assertEqual(len(rows), 9)
        self.assertEqual(len(X.ERROR_EXITS), 9)


if __name__ == "__main__":
    unittest.main()
