"""Shared fakes for R7/R8 tests (not a test module). In-memory adapters; contract-level evidence only."""
TID = "LC-1"
OBS = {"evidence_id": "E1", "kind": "SOURCE_OBSERVATION", "status": "OBSERVED", "target_revision": "r1",
       "observed_at": "2026-10-24", "summary": "s"}
OBS2 = {**OBS, "evidence_id": "E2"}
OBS3 = {**OBS, "evidence_id": "E3"}
LOW = {"risk_level": "LOW", "requires_external_evidence": True, "requires_diagnostic": False,
       "has_source_conflict": False, "has_critical_unknowns": False, "side_effects": False}
HIGH = {**LOW, "risk_level": "HIGH", "side_effects": True}


def task(profile=None, **kw):
    return {"task_id": TID, "goal": "g", "profile": dict(profile or LOW),
            "acceptance_criteria": [{"id": "C1", "description": "d", "required_evidence_kinds": ["SOURCE_OBSERVATION"]}], **kw}


class Fake:
    """Scripted adapters with call counters. evaluate_script: list of dicts/exceptions consumed per call (last repeats)."""

    def __init__(self, evaluate_script=None, execute_script=None, evidence=None, route=None, profile=None):
        self.calls = {"frame": 0, "evidence": 0, "route": 0, "execute": 0, "evaluate": 0}
        self.eval_script = list(evaluate_script or [passing()])
        self.exec_script = list(execute_script or [good_exec()])
        self.evidence_value = evidence
        self.route_value = route

    def _next(self, script, key):
        i = min(self.calls[key] - 1, len(script) - 1)
        item = script[i]
        if isinstance(item, BaseException):
            raise item
        return item

    def adapters(self, **override):
        def frame(t):
            self.calls["frame"] += 1
            return {"task_id": TID, "status": "READY", "frame_id": "F", "problem_statement": "p", "in_scope": [], "out_of_scope": [], "unknowns": []}

        def evidence(t, f):
            self.calls["evidence"] += 1
            return self.evidence_value() if callable(self.evidence_value) else (self.evidence_value or
                                                                              {"task_id": TID, "status": "READY", "records": [OBS], "critical_unknowns": []})

        def route(t, f, e):
            self.calls["route"] += 1
            return self.route_value or {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m", "m2"], "selected_method": "m",
                                        "reason": "r", "stop_rule": "s", "requires_authorization": False, "required_scope": ["w"]}

        def execute(t, f, e, r):
            self.calls["execute"] += 1
            return self._next(self.exec_script, "execute")

        def evaluate(t, x, e):
            self.calls["evaluate"] += 1
            return self._next(self.eval_script, "evaluate")

        ad = {"frame": frame, "evidence": evidence, "route": route, "execute": execute, "evaluate": evaluate,
              "authorize": lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A", "authorized_scope": list(r.get("required_scope", []))}}
        ad.update(override)
        return ad


def good_exec(target="r1"):
    return {"task_id": TID, "status": "EXECUTED", "execution_id": "X", "result_summary": "ok", "target_version": target,
            "tool_or_command": "cmd", "exit_status": 0, "environment": "env"}


def passing(ids=("E1",), **extra):
    return {"task_id": TID, "criteria_results": [{"criterion_id": "C1", "status": "PASS", "evidence_ids": list(ids)}], **extra}


def failing(branch, **extra):
    return {"task_id": TID, "criteria_results": [{"criterion_id": "C1", "status": "FAIL", "evidence_ids": ["E1"]}],
            "failure_branch": branch, "reason": f"scripted {branch}", **extra}


def unknown():
    return {"task_id": TID, "criteria_results": [{"criterion_id": "C1", "status": "UNKNOWN", "evidence_ids": []}]}
