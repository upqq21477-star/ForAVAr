import hashlib
import json
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
sys.path.insert(0, os.path.join(ROOT, "tools", "probes"))
import candidate_gate  # noqa: E402
import update_cost  # noqa: E402
import verify_cost  # noqa: E402
import replay_cost  # noqa: E402
import read_cost  # noqa: E402

PROBE = ('import json,os,sys\nr=sys.argv[1]\nd=sum(os.path.getsize(os.path.join(a,f)) for a,_,fs in os.walk(os.path.join(r,"docs")) for f in fs)\n'
         't=sum(open(os.path.join(r,"tests",f)).read().count("def test_") for f in os.listdir(os.path.join(r,"tests")) if f.endswith(".py"))\n'
         'print(json.dumps({"docs_bytes":d,"tests_count":t}))\n')
FREEZE = ('import hashlib,json,os,sys\nh=hashlib.sha256()\nfor f in sorted(os.listdir("frozen")):h.update(open(os.path.join("frozen",f),"rb").read())\n'
          'json.dump({"freeze":{"combined":h.hexdigest()[:16]}},open(sys.argv[1],"w"))\n')
OKTEST = "import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\n"
POLICY = {"timeout_s": 60, "safety": [["{py}", "-m", "unittest", "discover", "-s", "tests"]],
          "freeze_cmd": ["{py}", "freeze.py", "{out}"], "probes": [{"id": "t", "cmd": ["{py}", "probe.py", "{root}"]}],
          "guards": [{"metric": "t.tests_count", "worse_if": "decrease", "hard": True},
                     {"metric": "t.docs_bytes", "worse_if": "increase", "tol_rel": 0.03}],
          "judge_paths": ["probe.py", "judge/"], "authority_docs": ["index.json"]}


def _w(root, rel, text):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8") as fh:
        fh.write(text)


def _tree(root):
    h = hashlib.sha256()
    for d, _, fs in sorted(os.walk(root)):
        for f in sorted(fs):
            if "__pycache__" not in d:
                with open(os.path.join(d, f), "rb") as fh:
                    h.update((os.path.join(d, f) + fh.read().hex()).encode())
    return h.hexdigest()


class Gate(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.root = os.path.join(self.tmp, "repo")
        _w(self.root, "tests/test_ok.py", OKTEST)
        _w(self.root, "docs/notes.md", "x" * 1000)
        _w(self.root, "docs/index.json", "{}")
        _w(self.root, "frozen/core.txt", "core")
        _w(self.root, "judge/j.py", "ok")
        _w(self.root, "probe.py", PROBE)
        _w(self.root, "freeze.py", FREEZE)
        self.before = _tree(self.root)
        self.n = 0

    def tearDown(self):
        self.assertEqual(_tree(self.root), self.before, "the real root must never change")
        shutil.rmtree(self.tmp, ignore_errors=True)

    def cand(self, files=None, delete=(), expect=(), waive=()):
        self.n += 1
        d = os.path.join(self.tmp, f"c{self.n}")
        for rel, text in (files or {}).items():
            _w(d, "files/" + rel, text)
        _w(d, "candidate.json", json.dumps({"id": f"c{self.n}", "need": "t", "expect": list(expect), "delete": list(delete),
                                             "accept_regress": list(waive)}))
        return d

    def judge(self, d, policy=None):
        return candidate_gate.judge(self.root, d, policy or POLICY)

    SHRINK = [{"metric": "t.docs_bytes", "better": "decrease", "min_rel": 0.1}]

    def test_ready_when_safe_and_effect_shown(self):
        v = self.judge(self.cand({"docs/notes.md": "x" * 500}, expect=self.SHRINK))
        self.assertEqual((v["status"], v["reasons"]), ("READY", []))
        self.assertEqual(v["effect"]["shown"], ["t.docs_bytes"])
        self.assertEqual(v["touched"]["modified"], ["docs/notes.md"])

    def test_failing_test_is_rejected(self):
        bad = "import unittest\nclass B(unittest.TestCase):\n    def test_b(self):\n        self.assertTrue(False)\n"
        v = self.judge(self.cand({"tests/test_bad.py": bad}, expect=self.SHRINK))
        self.assertEqual(v["status"], "REJECT")
        self.assertTrue(any(r.startswith("safety_failed") for r in v["reasons"]))

    def test_no_effect_or_no_declared_effect_is_held(self):
        v = self.judge(self.cand({"docs/notes.md": "x" * 1001}, expect=self.SHRINK))
        self.assertEqual(v["status"], "HOLD")
        self.assertTrue(any(r.startswith("effect_not_shown") for r in v["reasons"]))
        v = self.judge(self.cand({"docs/notes.md": "x" * 900}))
        self.assertEqual((v["status"], v["reasons"]), ("HOLD", ["no_declared_effect"]))

    def test_frozen_change_is_held_even_when_effect_shown(self):
        v = self.judge(self.cand({"frozen/core.txt": "changed", "docs/notes.md": "x" * 500}, expect=self.SHRINK))
        self.assertEqual(v["status"], "HOLD")
        self.assertTrue(any(r.startswith("frozen_set_changed") for r in v["reasons"]))
        self.assertNotEqual(v["freeze"]["before"], v["freeze"]["after"])

    def test_candidate_cannot_approve_itself_by_editing_the_judge(self):
        v = self.judge(self.cand({"judge/j.py": "always READY", "docs/notes.md": "x" * 500}, expect=self.SHRINK))
        self.assertEqual(v["status"], "HOLD")
        self.assertTrue(any(r.startswith("judge_touched") for r in v["reasons"]))

    def test_path_escape_is_rejected_before_anything_runs(self):
        d = self.cand(delete=["../outside.txt"], expect=self.SHRINK)
        self.assertEqual(self.judge(d)["status"], "REJECT")

    def test_a_candidate_built_on_an_older_root_is_rejected_not_silently_overwriting(self):
        sha = hashlib.sha256(b"x" * 1000).hexdigest()
        d = self.cand({"docs/notes.md": "x" * 500}, expect=self.SHRINK)
        with open(os.path.join(d, "candidate.json"), encoding="utf-8") as fh:
            c = json.load(fh)
        c["base"] = {"docs/notes.md": sha, "docs/new.md": None}
        with open(os.path.join(d, "candidate.json"), "w", encoding="utf-8") as fh:
            json.dump(c, fh)
        self.assertEqual(self.judge(d)["status"], "READY")
        c["base"]["docs/notes.md"] = hashlib.sha256(b"older").hexdigest()
        with open(os.path.join(d, "candidate.json"), "w", encoding="utf-8") as fh:
            json.dump(c, fh)
        v = self.judge(d)
        self.assertEqual(v["status"], "REJECT")
        self.assertTrue(v["reasons"][0].startswith("stale_base"))

    def test_guard_regression_rejects_unless_soft_and_waived_with_reason(self):
        grow = {"docs/notes.md": "x" * 1600, "tests/test_more.py": OKTEST.replace("test_a", "test_c")}
        more = [{"metric": "t.tests_count", "better": "increase", "min_abs": 1}]
        self.assertEqual(self.judge(self.cand(grow, expect=more))["status"], "REJECT")
        v = self.judge(self.cand(grow, expect=more, waive=[{"metric": "t.docs_bytes", "reason": "new feature docs"}]))
        self.assertEqual(v["status"], "READY")
        self.assertEqual([g["waived"] for g in v["guards"] if g["metric"] == "t.docs_bytes"], ["new feature docs"])

    def test_hard_guard_cannot_be_waived(self):
        v = self.judge(self.cand(delete=["tests/test_ok.py"], expect=self.SHRINK,
                                 waive=[{"metric": "t.tests_count", "reason": "trust me"}]))
        self.assertEqual(v["status"], "REJECT")
        self.assertTrue(any("guard_worse: t.tests_count" in r for r in v["reasons"]))

    def test_authority_doc_is_ready_but_needs_owner_authorization(self):
        v = self.judge(self.cand({"docs/index.json": '{"a":1}', "docs/notes.md": "x" * 500}, expect=self.SHRINK))
        self.assertEqual(v["status"], "READY")
        self.assertTrue(v["needs_owner_authorization"])

    def test_every_swappable_part_is_data_swap_probe_and_guards(self):
        alt = json.loads(json.dumps(POLICY))
        alt["probes"] = [{"id": "u", "cmd": ["{py}", "probe.py", "{root}"]}]
        alt["guards"] = [{"metric": "u.tests_count", "worse_if": "decrease", "hard": True}]
        exp = [{"metric": "u.docs_bytes", "better": "decrease", "min_rel": 0.1}]
        v = self.judge(self.cand({"docs/notes.md": "x" * 500}, expect=exp), alt)
        self.assertEqual(v["status"], "READY")

    def test_a_probe_the_candidate_adds_gets_a_baseline_number_but_still_needs_the_owner_key(self):
        pol = dict(POLICY, policy_file="gate_policy.json", judge_paths=POLICY["judge_paths"] + ["gate_policy.json", "probe2.py"])
        _w(self.root, "gate_policy.json", json.dumps(pol))
        self.before = _tree(self.root)
        newpol = dict(pol, probes=pol["probes"] + [{"id": "r", "cmd": ["{py}", "probe2.py", "{root}"]}])
        probe2 = 'import json,os,sys\nprint(json.dumps({"notes_bytes": os.path.getsize(os.path.join(sys.argv[1], "docs", "notes.md"))}))\n'
        exp = [{"metric": "r.notes_bytes", "better": "decrease", "min_rel": 0.1}]
        v = self.judge(self.cand({"gate_policy.json": json.dumps(newpol), "probe2.py": probe2, "docs/notes.md": "x" * 500}, expect=exp), pol)
        self.assertEqual(v["effect"]["shown"], ["r.notes_bytes"])
        self.assertEqual(v["metrics"]["r.notes_bytes"], {"before": 1000.0, "after": 500.0})
        self.assertEqual((v["status"], len(v["reasons"])), ("HOLD", 1))
        self.assertTrue(v["reasons"][0].startswith("judge_touched"))

    def test_changes_have_the_shape_release_txn_takes(self):
        d = self.cand({"docs/notes.md": "new"}, delete=["frozen/core.txt"])
        with open(os.path.join(d, "candidate.json"), encoding="utf-8") as fh:
            self.assertEqual(candidate_gate.changes_of(d, json.load(fh)), {"docs/notes.md": "new", "frozen/core.txt": None})


    # --- LT-31: a change needs a NEW change_log entry that lists every changed file; authority hint on HOLD ---
    SCOPED = dict(POLICY, change_scope={"log": "docs/change_log.json"})
    LOG = "docs/change_log.json"

    @staticmethod
    def _log(new_scope=None, prior=("docs/index.json",)):
        ents = [{"id": "CL-0", "replan": {"scope": list(prior)}}]
        if new_scope is not None:
            ents.append({"id": "CL-1", "replan": {"scope": list(new_scope)}})
        return json.dumps({"entries": ents})

    def _root_log(self, prior=("docs/index.json",)):
        _w(self.root, self.LOG, self._log(prior=prior))
        self.before = _tree(self.root)

    def test_changed_file_missing_from_the_new_entry_scope_is_rejected_and_named(self):
        self._root_log()
        v = self.judge(self.cand({"docs/notes.md": "x" * 500, self.LOG: self._log([self.LOG])}, expect=self.SHRINK), self.SCOPED)
        self.assertEqual((v["status"], v["scope_gaps"]), ("REJECT", ["docs/notes.md"]))
        self.assertTrue(any(r.startswith("scope_gap") and "docs/notes.md" in r for r in v["reasons"]))

    def test_new_entry_listing_every_changed_file_passes_and_extra_scope_is_fine(self):
        self._root_log()
        v = self.judge(self.cand({"docs/notes.md": "x" * 500, self.LOG: self._log([self.LOG, "docs/notes.md", "runtime/unrelated.py"])}, expect=self.SHRINK), self.SCOPED)
        self.assertEqual((v["status"], v["scope_gaps"]), ("READY", []))

    def test_change_without_a_new_entry_is_rejected_even_if_the_previous_entry_lists_the_file(self):
        self._root_log(prior=("docs/notes.md", self.LOG))  # the last entry already covers notes.md: it must not vouch for this change
        v = self.judge(self.cand({"docs/notes.md": "x" * 500}, expect=self.SHRINK), self.SCOPED)
        self.assertEqual((v["status"], v["scope_gaps"]), ("REJECT", ["docs/notes.md"]))
        self.assertTrue(any("no_new_entry" in r for r in v["reasons"]))

    def test_rewriting_an_old_entry_is_not_a_new_entry_but_editing_the_log_alone_is_exempt(self):
        self._root_log()
        rewrite = json.dumps({"entries": [{"id": "CL-0", "replan": {"scope": ["docs/index.json", "x"]}}]})
        v = self.judge(self.cand({self.LOG: rewrite}), self.SCOPED)
        self.assertEqual(v["scope_gaps"], [])
        v = self.judge(self.cand({self.LOG: rewrite, "docs/notes.md": "y"}), self.SCOPED)
        self.assertEqual(v["scope_gaps"], [self.LOG, "docs/notes.md"])

    def test_deleted_files_must_be_in_the_new_entry_scope_too(self):
        self._root_log()
        v = self.judge(self.cand({self.LOG: self._log([self.LOG])}, delete=["docs/notes.md"], expect=self.SHRINK), self.SCOPED)
        self.assertEqual(v["scope_gaps"], ["docs/notes.md"])

    def test_scope_check_is_data_driven_off_without_policy_key_and_hold_when_log_unreadable(self):
        v = self.judge(self.cand({"docs/notes.md": "x" * 500}, expect=self.SHRINK))
        self.assertEqual((v["status"], v["scope_gaps"]), ("READY", []))
        v = self.judge(self.cand({"docs/notes.md": "x" * 500}, expect=self.SHRINK), self.SCOPED)
        self.assertEqual(v["status"], "HOLD")
        self.assertIn("change_scope_unreadable", v["reasons"])

    def test_authority_hint_is_given_on_hold_too_but_not_on_reject(self):
        v = self.judge(self.cand({"docs/index.json": '{"a":1}'}))
        self.assertEqual((v["status"], v["authority_touched"], v["needs_owner_authorization"]), ("HOLD", ["docs/index.json"], True))
        bad = "import unittest\nclass B(unittest.TestCase):\n    def test_b(self):\n        self.assertTrue(False)\n"
        v = self.judge(self.cand({"docs/index.json": '{"a":1}', "tests/test_bad.py": bad}, expect=self.SHRINK))
        self.assertEqual((v["status"], v["needs_owner_authorization"]), ("REJECT", False))


class VerifyCostProbe(unittest.TestCase):
    def test_reports_seconds_and_returns_nothing_without_the_checker(self):
        self.assertGreater(verify_cost.measure(ROOT, runs=1)["check_seconds"], 0)
        tmp = tempfile.mkdtemp()
        try:
            self.assertEqual(verify_cost.measure(tmp), {})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class UpdateCostProbe(unittest.TestCase):
    def test_measures_tree_and_flags_fingerprint_drift(self):
        tmp = tempfile.mkdtemp()
        try:
            _w(tmp, "tests/test_a.py", OKTEST)
            _w(tmp, "docs/change_log.json", json.dumps({"entries": [{"id": "CL-001", "change": "combined＝aaaaaaaaaaaaaaaa", "replan": {"scope": ["docs/x.md", "tools/y.py"]}}]}))
            _w(tmp, "README.md", "combined aaaaaaaaaaaaaaaa")
            m = update_cost.measure(tmp)
            self.assertEqual((m["tests_count"], m["fingerprint_drift"], m["mean_files_per_update"], m["doc_file_share"]), (1, 0, 2.0, 0.5))
            _w(tmp, "README.md", "combined aaaaaaaaaaaaaaab")
            self.assertEqual(update_cost.measure(tmp)["fingerprint_drift"], 1)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_newer_entry_without_a_fingerprint_does_not_blind_the_drift_check(self):
        tmp = tempfile.mkdtemp()
        try:
            _w(tmp, "docs/change_log.json", json.dumps({"entries": [{"id": "CL-1", "change": "combined＝aaaaaaaaaaaaaaaa"}, {"id": "CL-2", "change": "no fingerprint here"}]}))
            _w(tmp, "README.md", "combined aaaaaaaaaaaaaaab")
            m = update_cost.measure(tmp)
            self.assertEqual((m["fingerprint_truth_found"], m["fingerprint_drift"]), (1, 1))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_missing_pieces_do_not_raise(self):
        tmp = tempfile.mkdtemp()
        try:
            self.assertEqual(update_cost.measure(tmp)["fingerprint_drift"], 0)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class ReplayCostProbe(unittest.TestCase):
    def test_adding_a_test_touches_no_authority_doc_and_the_probe_never_writes_the_root(self):
        before = _tree(ROOT)
        m = replay_cost.measure(ROOT)
        self.assertEqual(m["authority_files_changed_on_add_test"], 0, m)
        self.assertGreaterEqual(m["files_changed_on_add_test"], 1)
        self.assertEqual(_tree(ROOT), before)

    def test_no_sync_docs_means_no_numbers_not_an_error(self):
        tmp = tempfile.mkdtemp()
        try:
            self.assertEqual(replay_cost.measure(tmp), {})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class UpdateCostProbe(unittest.TestCase):
    def test_measures_tree_and_flags_fingerprint_drift(self):
        tmp = tempfile.mkdtemp()
        try:
            _w(tmp, "tests/test_a.py", OKTEST)
            _w(tmp, "docs/change_log.json", json.dumps({"entries": [{"id": "CL-001", "change": "combined＝aaaaaaaaaaaaaaaa", "replan": {"scope": ["docs/x.md", "tools/y.py"]}}]}))
            _w(tmp, "README.md", "combined aaaaaaaaaaaaaaaa")
            m = update_cost.measure(tmp)
            self.assertEqual((m["tests_count"], m["fingerprint_drift"], m["mean_files_per_update"], m["doc_file_share"]), (1, 0, 2.0, 0.5))
            _w(tmp, "README.md", "combined aaaaaaaaaaaaaaab")
            self.assertEqual(update_cost.measure(tmp)["fingerprint_drift"], 1)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_newer_entry_without_a_fingerprint_does_not_blind_the_drift_check(self):
        tmp = tempfile.mkdtemp()
        try:
            _w(tmp, "docs/change_log.json", json.dumps({"entries": [{"id": "CL-1", "change": "combined＝aaaaaaaaaaaaaaaa"}, {"id": "CL-2", "change": "no fingerprint here"}]}))
            _w(tmp, "README.md", "combined aaaaaaaaaaaaaaab")
            m = update_cost.measure(tmp)
            self.assertEqual((m["fingerprint_truth_found"], m["fingerprint_drift"]), (1, 1))
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_missing_pieces_do_not_raise(self):
        tmp = tempfile.mkdtemp()
        try:
            self.assertEqual(update_cost.measure(tmp)["fingerprint_drift"], 0)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


class ReadCostProbe(unittest.TestCase):
    def test_real_repo_gives_every_metric_and_never_writes_the_root(self):
        before = _tree(ROOT)
        m = read_cost.measure(ROOT)
        self.assertEqual(sorted(m), ["docs_tokens", "l0_tokens", "scope_tokens_recent_mean", "start_here_tokens"])
        self.assertTrue(all(v > 0 for v in m.values()), m)
        self.assertLess(m["l0_tokens"], m["start_here_tokens"] * 0.05)  # the layered entry must stay far below the whole-file entry
        self.assertEqual(_tree(ROOT), before)

    def test_scope_mean_uses_only_the_last_five_scoped_entries(self):
        tmp = tempfile.mkdtemp()
        try:
            os.makedirs(os.path.join(tmp, "docs"))
            with open(os.path.join(tmp, "a.txt"), "w", encoding="utf-8") as fh:
                fh.write("x" * 360)  # 100 estimated tokens
            entries = [{"id": f"CL-{i}", "replan": {"scope": ["a.txt"] * (i + 1)}} for i in range(7)] + [{"id": "CL-no-scope"}]
            with open(os.path.join(tmp, "docs", "change_log.json"), "w", encoding="utf-8") as fh:
                json.dump({"entries": entries}, fh)
            self.assertEqual(read_cost.measure(tmp)["scope_tokens_recent_mean"], 500.0)  # entries 2..6 -> (3+4+5+6+7)/5 files * 100
            self.assertEqual(read_cost.est("x" * 360), 100)
            self.assertEqual(read_cost.est("字" * 10), 10)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_missing_inputs_give_fewer_keys_not_an_error(self):
        tmp = tempfile.mkdtemp()
        try:
            self.assertEqual(read_cost.measure(tmp), {})
            os.makedirs(os.path.join(tmp, "docs"))
            with open(os.path.join(tmp, "docs", "change_log.json"), "w", encoding="utf-8") as fh:
                fh.write("{broken")
            self.assertEqual(read_cost.measure(tmp), {"docs_tokens": float(read_cost.est("{broken"))})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    unittest.main()


if __name__ == "__main__":
    unittest.main()
