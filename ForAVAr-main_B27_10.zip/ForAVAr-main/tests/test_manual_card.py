import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
import dialogue_axis as D  # noqa: E402
import manual_card as M  # noqa: E402


class ManualCardTests(unittest.TestCase):
    def test_repo_readme_card_is_current_and_refs_resolve(self):
        self.assertEqual(M.problems(), [])

    def test_card_is_small_enough_for_a_front_page_and_names_the_limits(self):
        text = M.block()
        self.assertLess(len(text.encode("utf-8")), 6000)
        for needle in ("PROTOCOL_FOLLOWING", "BLOCKED", "NOT_PROVEN", "INCONCLUSIVE", "L3"):
            self.assertIn(needle, text)

    def test_card_axis_section_names_every_axis_node_and_the_switch(self):
        text = M.block()
        for nid in D.IDS:
            self.assertIn(D.LABEL[nid].split("（")[0], text)  # card wording must follow the module's node table
        self.assertIn("對話主軸 開", text)
        self.assertIn(f"最多問 {D.MAX_QUESTIONS} 個問題", text)

    def test_drift_and_dangling_ref_are_detected(self):
        d = tempfile.mkdtemp()
        os.makedirs(os.path.join(d, "docs"))
        for rel in ("docs/manual_card.json", "docs/operating_contract.json", "README.md"):
            shutil.copy(os.path.join(M.ROOT, rel), os.path.join(d, rel))
        self.assertEqual(M.problems(d), [])
        with open(os.path.join(d, "README.md"), "a", encoding="utf-8") as fh:
            fh.write("")
        text = open(os.path.join(d, "README.md"), encoding="utf-8").read().replace("L0 一次性回答", "L0 被手改")
        with open(os.path.join(d, "README.md"), "w", encoding="utf-8") as fh:
            fh.write(text)
        self.assertTrue(any("out of date" in e for e in M.problems(d)))
        M.write(d)
        self.assertEqual(M.problems(d), [])
        import json
        c = json.load(open(os.path.join(d, "docs/manual_card.json"), encoding="utf-8"))
        c["sections"][0]["refs"].append("no_such_key/x")
        json.dump(c, open(os.path.join(d, "docs/manual_card.json"), "w", encoding="utf-8"), ensure_ascii=False)
        self.assertTrue(any("unresolved ref" in e for e in M.problems(d)))


if __name__ == "__main__":
    unittest.main()
