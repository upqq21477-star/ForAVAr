"""R3-synthesis: synthesis gate (N14-N15), standalone and through the optional slice stage."""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "adapters"))

from foravar_vertical_slice import run_vertical_slice  # noqa: E402
from synthesis_gate import assess_synthesis, collect_open_items  # noqa: E402
import model_adapter  # noqa: E402
from loop_fixtures import HIGH, LOW, TID, Fake, task  # noqa: E402

OBSERVED = {"E1"}


def synth(**kw):
    s = {"task_id": TID, "status": "READY", "synthesis_id": "S1",
         "conclusions": [{"id": "k1", "statement": "a holds", "basis": "EVIDENCED", "confidence": "HIGH", "evidence_ids": ["E1"]}],
         "unresolved": []}
    s.update(kw)
    return s


def rules(s, profile=LOW, observed=OBSERVED, open_ids=(), prior=()):
    return {v["rule"] for v in assess_synthesis(profile, s, observed, open_ids, prior)["violations"]}


def run(s, profile=LOW, **adapters):
    fake = Fake()
    return run_vertical_slice(task(profile), fake.adapters(synthesis=lambda t, e, ev: s, **adapters)), fake


class ShapeTests(unittest.TestCase):
    def test_complete_synthesis_is_ok(self):
        out = assess_synthesis(LOW, synth(), OBSERVED)
        self.assertEqual((out["ok"], out["status"], out["conclusions_counted"]), (True, "OK", 1))

    def test_conclusions_required_unless_basis_given(self):
        self.assertIn("CONCLUSIONS_MISSING", rules(synth(conclusions=[])))
        self.assertNotIn("CONCLUSIONS_MISSING", rules(synth(conclusions=[], omitted_basis={"conclusions": "nothing established"})))
        self.assertIn("CONCLUSIONS_MISSING", rules(synth(conclusions="x")))

    def test_conclusion_fields_and_unique_ids(self):
        c = synth()["conclusions"][0]
        self.assertIn("CONCLUSION_MALFORMED", rules(synth(conclusions=[c, dict(c)])))
        self.assertIn("CONCLUSION_MALFORMED", rules(synth(conclusions=[{**c, "confidence": "CERTAIN"}])))
        self.assertIn("CONCLUSION_MALFORMED", rules(synth(conclusions=[{**c, "basis": "FACT"}])))
        self.assertIn("CONCLUSION_MALFORMED", rules(synth(conclusions=[{**c, "statement": " "}])))

    def test_unresolved_must_be_a_list_of_items(self):
        s = synth()
        del s["unresolved"]
        self.assertIn("UNRESOLVED_MISSING", rules(s))
        self.assertIn("UNRESOLVED_MALFORMED", rules(synth(unresolved=[{"id": "u1"}])))


class EvidenceTests(unittest.TestCase):
    def concl(self, **kw):
        c = {"id": "k1", "statement": "s", "basis": "EVIDENCED", "confidence": "HIGH", "evidence_ids": ["E1"]}
        c.update(kw)
        return synth(conclusions=[c])

    def test_evidenced_needs_observed_evidence(self):
        self.assertIn("CONCLUSION_UNSUPPORTED", rules(self.concl(evidence_ids=[])))
        self.assertIn("CONCLUSION_UNSUPPORTED", rules(self.concl(evidence_ids=["E9"])))
        self.assertIn("CONCLUSION_UNSUPPORTED", rules(self.concl(evidence_ids=["E1", "E9"])))
        self.assertIn("CONCLUSION_UNSUPPORTED", rules(self.concl(), observed=set()))

    def test_confidence_must_match_evidence(self):
        self.assertIn("CONFIDENCE_EXCEEDS_EVIDENCE", rules(self.concl(basis="HYPOTHESIS", evidence_ids=["E1"])))
        self.assertIn("CONFIDENCE_EXCEEDS_EVIDENCE", rules(self.concl(basis="HYPOTHESIS", evidence_ids=[], confidence="MEDIUM")))
        self.assertEqual(rules(self.concl(basis="HYPOTHESIS", evidence_ids=[], confidence="LOW")), set())
        self.assertIn("CONFIDENCE_EXCEEDS_EVIDENCE", rules(self.concl(evidence_ids=["E1"]), observed=set()))

    def test_model_cannot_claim_observed(self):
        s = self.concl(status="OBSERVED")
        self.assertIn("SYNTHESIS_CLAIMS_OBSERVED", rules(s))
        s = synth(unresolved=[{"id": "u", "statement": "s", "observed_at": "2026-10-24"}])
        self.assertIn("SYNTHESIS_CLAIMS_OBSERVED", rules(s))


class CarryAndMergeTests(unittest.TestCase):
    def test_open_items_must_all_be_carried(self):
        self.assertIn("UNRESOLVED_DROPPED", rules(synth(), open_ids=["u1"]))
        ok = synth(unresolved=[{"id": "u1", "statement": "still unknown"}])
        self.assertEqual(rules(ok, open_ids=["u1"]), set())
        self.assertIn("UNRESOLVED_DROPPED", rules(ok, open_ids=["u1", "u2"]))

    def test_merged_from_must_name_known_prior_conclusions(self):
        c = {**synth()["conclusions"][0], "merged_from": ["p1"]}
        self.assertIn("MERGE_SOURCE_UNKNOWN", rules(synth(conclusions=[c])))
        self.assertEqual(rules(synth(conclusions=[c]), prior=["p1"]), set())
        self.assertIn("MERGE_SOURCE_UNKNOWN", rules(synth(conclusions=[{**c, "merged_from": []}]), prior=["p1"]))

    def test_collect_open_items(self):
        ids = collect_open_items({"unknowns": ["fu", {"id": "fu2"}]}, {"unknowns": [{"id": "mu"}]},
                                 [{"criterion_id": "C1", "status": "UNKNOWN"}, {"criterion_id": "C2", "status": "PASS"}],
                                 {"conflicts": [{"conflict_id": "X1"}], "stale": [{"evidence_id": "E5"}]})
        self.assertEqual(ids, ["fu", "fu2", "mu", "C1", "X1", "E5"])
        self.assertEqual(collect_open_items(None, None, None, None), [])

    def test_status_depends_on_stakes(self):
        bad = synth(conclusions=[])
        self.assertEqual(assess_synthesis(LOW, bad, OBSERVED)["status"], "NOT_PROVEN")
        self.assertEqual(assess_synthesis({**LOW, "side_effects": True}, bad, OBSERVED)["status"], "BLOCKED")
        self.assertEqual(assess_synthesis({**LOW, "governance": "G2"}, bad, OBSERVED)["status"], "BLOCKED")
        self.assertEqual(assess_synthesis({**LOW, "governance": "G1"}, bad, OBSERVED)["status"], "NOT_PROVEN")

    def test_malformed_input_never_raises(self):
        for s in ({}, {"conclusions": [1, None], "unresolved": [5]}, {"conclusions": 5, "unresolved": "x", "omitted_basis": 3}):
            assess_synthesis({**LOW, "governance": "bad"}, s, OBSERVED, ["x"], ["y"])


class SliceIntegrationTests(unittest.TestCase):
    def test_no_synthesis_adapter_means_unchanged_behaviour(self):
        r = run_vertical_slice(task(LOW), Fake().adapters())
        self.assertEqual((r["status"], r["synthesis"], r["synthesis_gate"]), ("PASS", None, None))
        self.assertNotIn("SYNTHESIS", r["trace"])

    def test_valid_synthesis_keeps_pass_and_is_reported(self):
        r, _ = run(synth())
        self.assertEqual((r["status"], r["synthesis_gate"]["ok"]), ("PASS", True))
        self.assertLess(r["trace"].index("EVALUATION"), r["trace"].index("SYNTHESIS_GATE"))
        self.assertLess(r["trace"].index("SYNTHESIS_GATE"), r["trace"].index("FEEDBACK"))

    def test_invalid_synthesis_downgrades_pass_to_partial(self):
        r, _ = run(synth(conclusions=[]))
        self.assertEqual((r["status"], r["acceptance"]["failure_class"]), ("PARTIAL", "INFERENCE_OR_MODEL_ERROR"))
        self.assertIn("CONCLUSIONS_MISSING", r["feedback"]["reason"])

    def test_invalid_synthesis_blocks_high_risk(self):
        r, _ = run(synth(conclusions=[]), HIGH)
        self.assertEqual((r["status"], r["feedback"]["action"]), ("BLOCKED", "STOP_BLOCKED"))

    def test_open_items_from_slice_must_be_carried(self):
        fake = Fake()
        frame = lambda t: {"task_id": TID, "status": "READY", "frame_id": "F", "problem_statement": "p", "in_scope": [],  # noqa: E731
                           "out_of_scope": [], "unknowns": [{"id": "fu1", "statement": "x"}]}
        r = run_vertical_slice(task(LOW), fake.adapters(frame=frame, synthesis=lambda t, e, ev: synth()))
        self.assertEqual(r["status"], "PARTIAL")
        self.assertIn("UNRESOLVED_DROPPED", r["feedback"]["reason"])
        carried = synth(unresolved=[{"id": "fu1", "statement": "still unknown"}])
        r = run_vertical_slice(task(LOW), Fake().adapters(frame=frame, synthesis=lambda t, e, ev: carried))
        self.assertEqual(r["status"], "PASS")

    def test_not_ready_synthesis_is_a_violation(self):
        r, _ = run({"task_id": TID, "status": "NOT_PROVEN", "reason": "too little data", "conclusions": [], "unresolved": []})
        self.assertEqual(r["status"], "PARTIAL")
        self.assertIn("SYNTHESIS_NOT_READY", r["feedback"]["reason"])
        r, _ = run({"task_id": TID, "status": "BLOCKED", "reason": "x", "conclusions": [], "unresolved": []})
        self.assertEqual(r["status"], "BLOCKED")

    def test_failed_evaluation_skips_synthesis(self):
        failing = {"task_id": TID, "criteria_results": [{"criterion_id": "C1", "status": "FAIL", "evidence_ids": ["E1"]}]}
        fake = Fake(evaluate_script=[failing])
        r = run_vertical_slice(task(LOW), fake.adapters(synthesis=lambda t, e, ev: synth()))
        self.assertEqual((r["status"], r["synthesis"]), ("FAILED", None))

    def test_adapter_fault_and_wrong_task_are_named(self):
        def boom(t, e, ev):
            raise RuntimeError("x")
        r = run_vertical_slice(task(LOW), Fake().adapters(synthesis=boom))
        self.assertEqual((r["status"], r["event"]), ("FAILED", "ADAPTER_FAULT"))
        r, _ = run({**synth(), "task_id": "OTHER"})
        self.assertEqual(r["event"], "ADAPTER_FAULT")


class AdapterStageTests(unittest.TestCase):
    def test_template_and_contract_exist(self):
        for table in (model_adapter.TEMPLATES, model_adapter.REQUIRED, model_adapter.ARGS, model_adapter.DECLARATIONS):
            self.assertIn("synthesis", table)
        ad = model_adapter.make_adapter("synthesis", lambda prompt: json.dumps(synth()))
        out = ad(task(LOW), {"criteria_results": []}, {"records": []})
        self.assertEqual(out["synthesis_id"], "S1")

    def test_missing_fields_rejected(self):
        bad = synth()
        del bad["unresolved"]
        ad = model_adapter.make_adapter("synthesis", lambda prompt: json.dumps(bad))
        with self.assertRaises(model_adapter.AdapterOutputError):
            ad(task(LOW), {}, {"records": []})



# ---- B27.8 mutation-audit edge cases ----
from synthesis_gate import collect_open_items  # noqa: E402


class SynthesisEdges(unittest.TestCase):
    def test_open_items_deduped_and_string_only(self):
        got = collect_open_items({"unknowns": ["U1", "U1", {"id": "U2"}, 5, "", "  "]}, {"unknowns": [{"id": "U2"}, {"id": "U3"}, {"id": 9}]},
                                 [{"criterion_id": "C1", "status": "UNKNOWN"}, {"criterion_id": "C1", "status": "NOT_RUN"}, {"criterion_id": "C2", "status": "PASS"}],
                                 {"conflicts": [{"conflict_id": "K1"}], "stale": [{"evidence_id": "E1"}, "x"]})
        self.assertEqual(got, ["U1", "U2", "U3", "C1", "K1", "E1"])


if __name__ == "__main__":
    unittest.main()
