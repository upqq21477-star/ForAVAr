"""B24 CLOSURE checks: import graph/layering/cycles, ledger counts, drift, adapter_stage, stray artifacts, difference inventory."""
import json
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
from check_consistency import check, import_graph  # noqa: E402
from closure_report import diff_repos, impact  # noqa: E402


class ClosureCheckTests(unittest.TestCase):
    def copy_repo(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for sub in ("docs", "runtime", "tests", "adapters", "tools"):
            shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copy(os.path.join(ROOT, "README.md"), d)
        return d

    def errors(self, d):
        return {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}

    def edit_json(self, d, name, fn):
        p = os.path.join(d, "docs", name)
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        fn(data)
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)

    def append(self, d, rel, text):
        with open(os.path.join(d, rel), "a", encoding="utf-8") as fh:
            fh.write(text)

    def test_real_repo_graph_is_layered_and_acyclic(self):
        g = import_graph(ROOT)
        self.assertIn("runtime/stage_model.py", g["runtime/foravar_vertical_slice.py"])  # LT-20: gates are wired by stage modules
        self.assertIn("runtime/model_gate.py", g["runtime/stage_model.py"])
        self.assertEqual(g["runtime/synthesis_gate.py"], {"runtime/common.py"})  # gates share only common.py
        self.assertEqual(g["runtime/correction_propagation.py"], {"runtime/common.py"})  # not coupled to the slice
        self.assertEqual(g["adapters/model_adapter.py"], {"runtime/foravar_vertical_slice.py", "runtime/content_guard.py"})  # CL-037: raw-source scan reuses the content_guard rules
        self.assertFalse({"layering", "import_cycle"} & self.errors(ROOT))

    def test_runtime_importing_tools_or_adapters_is_a_layering_error(self):
        d = self.copy_repo()
        self.append(d, "runtime/policy_gate.py", "\nimport check_consistency\n")
        self.assertIn("layering", self.errors(d))
        d = self.copy_repo()
        self.append(d, "runtime/run_record.py", "\nimport model_adapter\n")
        self.assertIn("layering", self.errors(d))

    def test_runtime_import_cycle_detected(self):
        d = self.copy_repo()
        self.append(d, "runtime/policy_gate.py", "\nimport run_record\n")
        self.append(d, "runtime/run_record.py", "\nimport policy_gate\n")
        self.assertIn("import_cycle", self.errors(d))

    def test_gate_importing_another_gate_is_a_coupling_error(self):
        d = self.copy_repo()
        self.append(d, "runtime/frame_gate.py", "\nimport model_gate\n")
        self.assertIn("runtime_coupling", self.errors(d))
        self.assertNotIn("runtime_coupling", self.errors(self.copy_repo()))

    def test_ledger_counts_must_match_rows(self):
        d = self.copy_repo()
        self.edit_json(d, "progress_ledger.json", lambda L: L["counts"]["function_status"].update({"CONTRACT_TESTED": 1}))
        self.assertIn("ledger_counts", self.errors(d))

    def test_maturity_drift_detected(self):
        d = self.copy_repo()
        self.edit_json(d, "progress_ledger.json", lambda L: L["counts"].update(tests_total=1))
        self.assertIn("sync_drift", self.errors(d))  # test counts are derived (tools/sync_docs.py); since CL-026 they live in ledger.counts
        d = self.copy_repo()

        def ver(B):
            k = "runtime/foravar_vertical_slice.py"
            B["maturity"][k] = B["maturity"][k].replace("(0.", "(9.", 1)
        self.edit_json(d, "blueprint.json", ver)
        self.assertIn("maturity_drift", self.errors(d))

    def test_adapter_stage_must_have_a_template(self):
        d = self.copy_repo()

        def mut(L):
            L["functions"][0]["adapter_stage"] = "nonexistent_stage"
        self.edit_json(d, "progress_ledger.json", mut)
        self.assertIn("adapter_stage", self.errors(d))

    def test_stray_artifacts_and_modes(self):
        d = self.copy_repo()
        os.makedirs(os.path.join(d, ".foravar_snap", "x"))
        open(os.path.join(d, "HANDOFF_B1.md"), "w").close()
        open(os.path.join(d, "old.zip"), "w").close()
        os.chmod(os.path.join(d, "README.md"), 0o666)
        self.assertTrue({"stray_artifact", "file_mode"} <= self.errors(d))

    def test_pycache_is_only_info(self):
        d = self.copy_repo()
        os.makedirs(os.path.join(d, "runtime", "__pycache__"))
        open(os.path.join(d, "runtime", "__pycache__", "a.pyc"), "w").close()
        self.assertEqual(self.errors(d), set())
        self.assertTrue(any(x["check"] == "stray_artifact" and x["level"] == "INFO" for x in check(d)["findings"]))

    def test_tools_must_be_listed_in_readme(self):
        d = self.copy_repo()
        open(os.path.join(d, "tools", "extra_tool.py"), "w").close()
        self.assertIn("readme_listing", self.errors(d))


class DiffInventoryTests(unittest.TestCase):
    def test_identical_roots_have_no_differences(self):
        r = diff_repos(ROOT, ROOT)
        self.assertEqual((r["files_added"], r["files_removed"], r["files_changed"], r["status_transitions"]), ([], [], [], {}))

    def test_reports_file_and_ledger_changes(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for sub in ("docs", "runtime"):
            shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns("__pycache__"))
        os.remove(os.path.join(d, "runtime", "run_record.py"))
        with open(os.path.join(d, "runtime", "new_mod.py"), "w") as fh:
            fh.write("x = 1\n")
        with open(os.path.join(d, "runtime", "model_gate.py"), "a") as fh:
            fh.write("\n# edit\n")
        p = os.path.join(d, "docs", "progress_ledger.json")
        with open(p, encoding="utf-8") as fh:
            led = json.load(fh)
        fid = led["functions"][0]["id"]
        old_status = led["functions"][0]["status"]
        led["functions"][0]["status"] = "ACCEPTED"
        next(g for g in led["stage_gates"] if g["stage"] == "CLOSURE")["status"] = "OLD_STATUS"  # independent of the real gate state
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(led, fh, ensure_ascii=False)
        r = diff_repos(d, ROOT)  # old = mutated copy, new = real repo
        self.assertIn("runtime/run_record.py", r["files_added"])
        self.assertIn("runtime/new_mod.py", r["files_removed"])
        self.assertIn("runtime/model_gate.py", r["files_changed"])
        self.assertIn(fid, r["status_transitions"][f"ACCEPTED -> {old_status}"])
        self.assertEqual(r["gates_changed"]["CLOSURE"][0], "OLD_STATUS")


class ImpactTests(unittest.TestCase):
    def test_leaf_runtime_module_reaches_importers_tests_and_ledger(self):
        r = impact(ROOT, ["runtime/release_txn.py"])
        self.assertIn("runtime/loop_controller.py", r["affected_by_layer"]["runtime"])
        self.assertIn("tools/stage_gate.py", r["affected_by_layer"]["tools"])
        self.assertIn("tests/test_release_txn.py", r["tests_direct"])
        self.assertLessEqual(set(r["tests_direct"]), set(r["tests_to_run"]))
        self.assertIn("TXN", r["mechanisms_direct"])
        self.assertEqual(r["blast"]["modules"], sum(len(v) for v in r["affected_by_layer"].values()))

    def test_tests_and_unknown_paths(self):
        r = impact(ROOT, ["tests/test_frame_gate.py", "runtime/nope.py"])
        self.assertEqual(r["unknown_paths"], ["runtime/nope.py"])
        self.assertIn("tests/test_frame_gate.py", r["tests_direct"])
        self.assertEqual(r["affected_by_layer"], {})  # nothing imports a test module

    def test_adapters_layer_is_downstream_only(self):
        r = impact(ROOT, ["adapters/model_adapter.py"])
        self.assertEqual(set(r["affected_by_layer"]) - {"tests", "tools"}, set())
        self.assertEqual(r["affected_by_layer"].get("tools", []), ["tools/final_test_run.py"])  # the one recorded LAYER_EDGES entry


if __name__ == "__main__":
    unittest.main()


class ImportGraphEquivalence(unittest.TestCase):
    """The pruned, memoised graph must equal the plain ast.walk definition (the spec) on the real repo and on awkward syntax."""

    @staticmethod
    def reference(root):
        import ast
        folders = ("runtime", "adapters", "tools", "tests")
        mods = {}
        for folder in folders:
            d = os.path.join(root, folder)
            for n in sorted(os.listdir(d)) if os.path.isdir(d) else []:
                if n.endswith(".py"):
                    mods.setdefault(n[:-3], []).append(f"{folder}/{n}")
        graph = {}
        for folder in folders:
            d = os.path.join(root, folder)
            for n in sorted(os.listdir(d)) if os.path.isdir(d) else []:
                if not n.endswith(".py"):
                    continue
                try:
                    with open(os.path.join(d, n), encoding="utf-8") as fh:
                        tree = ast.parse(fh.read())
                except (OSError, SyntaxError):
                    continue
                deps = set()
                for node in ast.walk(tree):
                    names = [a.name for a in node.names] if isinstance(node, ast.Import) else \
                        ([node.module or ""] + ([a.name for a in node.names] if node.level or not node.module else [])) if isinstance(node, ast.ImportFrom) else []
                    for name in names:
                        parts = name.split(".")
                        stem = parts[1] if parts[0] in folders and len(parts) > 1 else parts[0]
                        deps.update(m for m in mods.get(stem, []) if m != f"{folder}/{n}")
                graph[f"{folder}/{n}"] = deps
        return graph

    def test_real_repo(self):
        self.assertEqual(import_graph(ROOT), self.reference(ROOT))

    def test_imports_in_every_statement_position_and_broken_files(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for f in ("runtime", "tools", "tests", "adapters"):
            os.makedirs(os.path.join(d, f))
        for rel, text in {"runtime/common.py": "x = 1\n", "runtime/b.py": "", "runtime/bad.py": "def (:\n",
                          "runtime/a.py": "import common\nclass C:\n    from runtime import b\n    def f(self):\n        try:\n            import runtime.common as c\n"
                                          "        except ImportError:\n            from . import b\n        finally:\n            if True:\n                for i in range(1):\n"
                                          "                    with open('x') as h:\n                        from common import x\n"
                                          "        match 1:\n            case 1:\n                import b\n        return lambda: [__import__('common')]\n"}.items():
            with open(os.path.join(d, rel), "w", encoding="utf-8") as fh:
                fh.write(text)
        got = import_graph(d)
        self.assertEqual(got, self.reference(d))
        self.assertIn("runtime/b.py", got)
        self.assertNotIn("runtime/bad.py", got)

    def test_cache_is_keyed_by_content_so_an_edit_is_seen(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for f in ("runtime", "tools", "tests", "adapters"):
            os.makedirs(os.path.join(d, f))
        for rel, text in {"runtime/common.py": "x = 1\n", "runtime/a.py": "x = 1\n"}.items():
            with open(os.path.join(d, rel), "w", encoding="utf-8") as fh:
                fh.write(text)
        self.assertEqual(import_graph(d)["runtime/a.py"], set())
        with open(os.path.join(d, "runtime/a.py"), "w", encoding="utf-8") as fh:
            fh.write("import common\n")
        self.assertEqual(import_graph(d)["runtime/a.py"], {"runtime/common.py"})
