"""B24 C2: restore drill over snap_dir / ckpt-NNNN chains; loop.json size cap (known trade-offs 2 and 3)."""
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "runtime"))
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

import loop_controller as LC  # noqa: E402
import release_txn  # noqa: E402
import restore_drill as RD  # noqa: E402
from loop_fixtures import Fake, failing, good_exec, passing, task  # noqa: E402


class DrillCase(unittest.TestCase):
    def setUp(self):
        self.d = tempfile.mkdtemp()
        self.root, self.snap = os.path.join(self.d, "root"), os.path.join(self.d, "snap")
        os.makedirs(self.root)
        with open(os.path.join(self.root, "a.txt"), "w", encoding="utf-8") as fh:
            fh.write("v0")

    def tearDown(self):
        shutil.rmtree(self.d, ignore_errors=True)

    def commit(self, n, text, extra=None):
        ch = {"a.txt": text, **(extra or {})}
        out = release_txn.apply_transaction(self.root, ch, os.path.join(self.snap, f"ckpt-{n:04d}"))
        self.assertEqual(out["status"], "COMMITTED")


class ChainTests(DrillCase):
    def test_healthy_chain_passes_with_and_without_root(self):
        for i, t in enumerate(("v1", "v2", "v3"), 1):
            self.commit(i, t, {"new.txt": t} if i == 2 else None)
        rep = RD.drill(self.snap)
        self.assertTrue(rep["ok"], rep)
        self.assertEqual([s["dir"] for s in rep["snapshots"]], ["ckpt-0001", "ckpt-0002", "ckpt-0003"])
        rep = RD.drill(self.snap, self.root)
        self.assertTrue(rep["ok"], rep)
        self.assertEqual(rep["snapshots"][-1]["live"], "AFTER")
        with open(os.path.join(self.root, "a.txt"), encoding="utf-8") as fh:  # drill never touches live state
            self.assertEqual(fh.read(), "v3")

    def test_numeric_order_beyond_9999_and_single_dir(self):
        self.commit(1, "v1")
        self.assertEqual(RD.discover(os.path.join(self.snap, "ckpt-0001")), [os.path.join(self.snap, "ckpt-0001")])
        os.makedirs(os.path.join(self.snap, "ckpt-10000"))
        with open(os.path.join(self.snap, "ckpt-10000", "manifest.json"), "w", encoding="utf-8") as fh:
            fh.write("{}")
        self.assertEqual([os.path.basename(x) for x in RD.discover(self.snap)], ["ckpt-0001", "ckpt-10000"])

    def test_corrupted_snapshot_file_is_reported(self):
        self.commit(1, "v1")
        self.commit(2, "v2")
        with open(os.path.join(self.snap, "ckpt-0002", "files", "a.txt"), "w", encoding="utf-8") as fh:
            fh.write("tampered")
        rep = RD.drill(self.snap)
        self.assertFalse(rep["ok"])
        self.assertTrue(any("hash mismatch" in p for p in rep["snapshots"][1]["problems"]))

    def test_unreadable_manifest_is_reported_not_raised(self):
        self.commit(1, "v1")
        with open(os.path.join(self.snap, "ckpt-0001", "manifest.json"), "w", encoding="utf-8") as fh:
            fh.write("not json")
        rep = RD.drill(self.snap)
        self.assertFalse(rep["ok"])

    def test_external_change_between_checkpoints_breaks_chain(self):
        self.commit(1, "v1")
        with open(os.path.join(self.root, "a.txt"), "w", encoding="utf-8") as fh:
            fh.write("edited outside")
        self.commit(2, "v2")
        rep = RD.drill(self.snap)
        self.assertFalse(rep["ok"])
        self.assertTrue(any("chain break" in p for p in rep["chain_problems"]), rep)

    def test_partial_live_state_is_a_problem(self):
        self.commit(1, "v1", {"b.txt": "b1"})
        with open(os.path.join(self.root, "b.txt"), "w", encoding="utf-8") as fh:
            fh.write("drifted")
        rep = RD.drill(self.snap, self.root)
        self.assertFalse(rep["ok"])
        self.assertEqual(rep["snapshots"][-1]["live"], "PARTIAL")

    def test_empty_or_missing_snap_dir(self):
        self.assertFalse(RD.drill(os.path.join(self.d, "nothing"))["ok"])
        os.makedirs(os.path.join(self.d, "empty"))
        self.assertFalse(RD.drill(os.path.join(self.d, "empty"))["ok"])


class LoopCheckpointTests(DrillCase):
    def run_loop(self, fake, **kw):
        persist = {"root": self.root, "snap_dir": self.snap}
        return LC.run_closed_loop(task(), fake.adapters(), budget={"max_attempts": 3}, persist=persist, **kw)

    def test_real_loop_checkpoints_pass_the_drill(self):
        fk = Fake(evaluate_script=[failing("LOCAL_FAILURE"), passing()])
        out = self.run_loop(fk, handlers={"REPAIR_LOCAL_NODE_AND_REGRESS": lambda ctx: {"discriminating_change": True}})
        self.assertIn(out["final_status"], {"PASS", "PARTIAL"})
        rep = RD.drill(self.snap, self.root)
        self.assertTrue(rep["ok"], rep)
        self.assertGreaterEqual(len(rep["snapshots"]), 2)

    def test_oversized_text_is_cut_visibly_and_resume_still_loads(self):
        big = "x" * 50000
        fk = Fake(execute_script=[{**good_exec(), "result_summary": big}], evaluate_script=[failing("LOCAL_FAILURE")])
        self.run_loop(fk, handlers={})
        path = os.path.join(self.root, "state", "LC-1.loop.json")
        self.assertLess(os.path.getsize(path), 30000)
        state = LC.load_loop_state(self.root, "LC-1")
        self.assertGreaterEqual(state["truncated_strings"], 1)
        self.assertIn("[TRUNCATED", json.dumps(state))
        self.assertEqual(state["task"]["task_id"], "LC-1")  # task itself is never cut

    def test_capped_leaves_short_values_alone(self):
        n = [0]
        v = {"a": ["short", 1, None, {"b": "ok"}]}
        self.assertEqual(LC._capped(v, n), v)
        self.assertEqual(n[0], 0)


if __name__ == "__main__":
    unittest.main()
