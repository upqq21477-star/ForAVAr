"""LT-21: LOOP_GUARD is unreachable under the real decide_retry (exhaustive over max_attempts x every re-entry action).

Argument: each continuing RUN adds one history entry before it can run again, so RUN <= max_attempts + 1 and DISPATCH <= max_attempts,
i.e. iterations <= 2*max_attempts + 1 < the guard 3*max_attempts + 6. This test checks it by running the real controller (no patched policy).
"""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
sys.path.insert(0, os.path.dirname(__file__))

import loop_controller as lc  # noqa: E402
from loop_controller import REENTRY, run_closed_loop  # noqa: E402
from loop_fixtures import LOW, TID, Fake, task  # noqa: E402

LOOPING = sorted(a for a, row in REENTRY.items() if row[0] not in ("CLOSE", "STOP"))


def _runner(action):
    return lambda t, a: {"task_id": TID, "status": "FAILED", "feedback": {"action": action, "reason": "stub"}, "run_record": None}


def _handlers():
    n = [0]

    def fresh(ctx):  # always supplies new, discriminating information so the policy cannot stop for 'no change'
        n[0] += 1
        return {"method": f"m{n[0]}", "discriminating_change": True, "actual_state_read": True, "cost": 0}

    return {a: fresh for a in LOOPING}


class LoopGuardReachability(unittest.TestCase):
    def test_guard_formula_is_above_the_bound(self):
        for a in range(1, 40):
            self.assertLess(2 * a + 1, a * 3 + 6)

    def test_never_loop_guard_with_real_policy(self):
        self.assertTrue(LOOPING)
        for action in LOOPING:
            for attempts in range(1, 9):
                r = run_closed_loop(task(LOW), Fake().adapters(), budget={"max_attempts": attempts}, handlers=_handlers(), runner=_runner(action))
                cond = r["stop"]["condition"]
                self.assertNotEqual(cond, "LOOP_GUARD", (action, attempts))
                self.assertLessEqual(r["attempts"], attempts, (action, attempts, cond))

    def test_cost_budget_also_stops_by_name(self):
        for attempts in (1, 3, 6):
            r = run_closed_loop(task(LOW), Fake().adapters(), budget={"max_attempts": attempts, "max_cost": 2}, runner=_runner("REROUTE_METHOD"),
                                handlers={"REROUTE_METHOD": lambda ctx: {"method": "mx", "discriminating_change": True, "cost": 1}})
            self.assertNotEqual(r["stop"]["condition"], "LOOP_GUARD")


if __name__ == "__main__":
    unittest.main()
