"""R3-model: problem-model gate (N07-N09), standalone and through the optional slice stage."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "adapters"))

from foravar_vertical_slice import run_vertical_slice  # noqa: E402
from model_gate import assess_model  # noqa: E402
import model_adapter  # noqa: E402
from loop_fixtures import HIGH, LOW, TID, Fake, task  # noqa: E402

OBSERVED = {"E1"}
HYPS = [{"id": "H1", "statement": "a causes b", "discriminating_test": "remove a, observe b"},
        {"id": "H2", "statement": "c causes b", "discriminating_test": "remove c, observe b"}]


def model(**kw):
    m = {"task_id": TID, "status": "READY", "model_id": "M1",
         "elements": [{"id": "a", "label": "A"}, {"id": "b", "label": "B"}],
         "relations": [{"id": "r1", "source": "a", "target": "b", "basis": "EVIDENCED", "evidence_ids": ["E1"]}],
         "conditions": [{"id": "c1", "statement": "only when x", "applies_to": ["r1"]}],
         "unknowns": [{"id": "u1", "statement": "is b stable", "affects": ["b"]}],
         "hypotheses": [dict(h) for h in HYPS]}
    m.update(kw)
    return m


def rules(m, profile=LOW, observed=OBSERVED):
    return {v["rule"] for v in assess_model(profile, m, observed)["violations"]}


def run(m, profile=LOW):
    fake = Fake()
    return run_vertical_slice(task(profile), fake.adapters(model=lambda t, f, e: m)), fake


class ModelShapeTests(unittest.TestCase):
    def test_complete_model_is_ok(self):
        out = assess_model(LOW, model(), OBSERVED)
        self.assertEqual((out["ok"], out["status"], out["hypotheses_counted"]), (True, "OK", 2))

    def test_elements_required_unique_labelled(self):
        self.assertIn("ELEMENTS_MISSING", rules(model(elements=[])))
        self.assertIn("ELEMENT_MALFORMED", rules(model(elements=[{"id": "a", "label": "A"}, {"id": "a", "label": "dup"}])))
        self.assertIn("ELEMENT_MALFORMED", rules(model(elements=[{"id": "a", "label": ""}])))

    def test_empty_categories_need_explicit_basis(self):
        for cat in ("relations", "conditions", "unknowns"):
            self.assertIn(f"{cat.upper()}_MISSING", rules(model(**{cat: []})), cat)
            self.assertNotIn(f"{cat.upper()}_MISSING", rules(model(**{cat: [], "omitted_basis": {cat: "none apply"}})), cat)
            m = model()
            del m[cat]
            self.assertIn(f"{cat.upper()}_MISSING", rules(m), cat)

    def test_conditions_and_unknowns_must_reference_existing_ids(self):
        self.assertIn("CONDITION_MALFORMED", rules(model(conditions=[{"id": "c1", "statement": "s", "applies_to": ["zzz"]}])))
        self.assertIn("UNKNOWN_MALFORMED", rules(model(unknowns=[{"id": "u1", "statement": "s", "affects": []}])))


class RelationEvidenceTests(unittest.TestCase):
    def rel(self, **kw):
        r = {"id": "r1", "source": "a", "target": "b", "basis": "EVIDENCED", "evidence_ids": ["E1"]}
        r.update(kw)
        return model(relations=[r], conditions=[], unknowns=[], omitted_basis={"conditions": "n/a", "unknowns": "n/a"})

    def test_evidenced_relation_needs_observed_evidence(self):
        self.assertEqual(rules(self.rel()), set())
        self.assertIn("RELATION_UNSUPPORTED", rules(self.rel(evidence_ids=[])))
        self.assertIn("RELATION_UNSUPPORTED", rules(self.rel(evidence_ids=["E9"])))
        self.assertIn("RELATION_UNSUPPORTED", rules(self.rel(), observed=set()))  # E1 exists but not OBSERVED

    def test_unsupported_relation_must_be_marked_hypothesis(self):
        out = assess_model(LOW, self.rel(basis="HYPOTHESIS", evidence_ids=[]), OBSERVED)
        self.assertTrue(out["ok"])
        self.assertEqual(out["hypothesis_relations"], 1)
        self.assertIn("RELATION_BASIS", rules(self.rel(basis="FACT")))

    def test_relation_endpoints_must_exist(self):
        self.assertIn("RELATION_MALFORMED", rules(self.rel(target="nope")))
        self.assertIn("RELATION_MALFORMED", rules(self.rel(id="a")))  # id collides with an element


class HypothesisAndHonestyTests(unittest.TestCase):
    def test_two_competing_hypotheses_with_distinct_tests(self):
        self.assertIn("COMPETING_HYPOTHESES_MISSING", rules(model(hypotheses=HYPS[:1])))
        same = [HYPS[0], {**HYPS[1], "discriminating_test": HYPS[0]["discriminating_test"]}]
        self.assertTrue({"HYPOTHESIS_MALFORMED", "COMPETING_HYPOTHESES_MISSING"} <= rules(model(hypotheses=same)))
        self.assertIn("HYPOTHESIS_MALFORMED", rules(model(hypotheses=[HYPS[0], {"id": "H2", "statement": "s"}])))
        self.assertIn("HYPOTHESIS_MALFORMED", rules(model(hypotheses=[HYPS[0], {**HYPS[1], "id": "H1"}])))

    def test_model_cannot_claim_observed(self):
        m = model()
        m["elements"][0]["status"] = "OBSERVED"
        self.assertIn("MODEL_CLAIMS_OBSERVED", rules(m))
        m = model()
        m["hypotheses"][0]["observed_at"] = "2026-10-24"
        self.assertIn("MODEL_CLAIMS_OBSERVED", rules(m))

    def test_status_depends_on_stakes(self):
        bad = model(elements=[])
        self.assertEqual(assess_model(LOW, bad, OBSERVED)["status"], "NOT_PROVEN")
        self.assertEqual(assess_model({**LOW, "side_effects": True}, bad, OBSERVED)["status"], "BLOCKED")
        self.assertEqual(assess_model({**LOW, "governance": "G2"}, bad, OBSERVED)["status"], "BLOCKED")
        self.assertEqual(assess_model({**LOW, "governance": "G1"}, bad, OBSERVED)["status"], "NOT_PROVEN")
        self.assertEqual(assess_model({k: v for k, v in LOW.items() if k != "side_effects"}, bad, OBSERVED)["status"], "BLOCKED")

    def test_malformed_input_never_raises(self):
        for m in ({}, {"elements": 5, "relations": "x", "conditions": 1, "unknowns": None, "hypotheses": [1, None], "omitted_basis": 3}):
            assess_model({**LOW, "governance": "bad"}, m, OBSERVED)


class SliceIntegrationTests(unittest.TestCase):
    def test_no_model_adapter_means_unchanged_behaviour(self):
        r = run_vertical_slice(task(LOW), Fake().adapters())
        self.assertEqual((r["status"], r["model"], r["model_gate"]), ("PASS", None, None))

    def test_valid_model_proceeds_and_is_reported(self):
        r, fake = run(model())
        self.assertEqual(r["status"], "PASS")
        self.assertTrue(r["model_gate"]["ok"])
        self.assertEqual(r["model"]["model_id"], "M1")
        self.assertLess(r["trace"].index("MODEL_GATE"), r["trace"].index("ROUTE"))

    def test_incomplete_model_stops_before_route_and_execute(self):
        r, fake = run(model(hypotheses=HYPS[:1]))
        self.assertEqual((r["status"], r["failure_class"]), ("NOT_PROVEN", "INFERENCE_OR_MODEL_ERROR"))
        self.assertIn("COMPETING_HYPOTHESES_MISSING", r["feedback"]["reason"])
        self.assertEqual((fake.calls["route"], fake.calls["execute"]), (0, 0))

    def test_incomplete_model_blocks_high_risk(self):
        r, fake = run(model(elements=[]), HIGH)
        self.assertEqual((r["status"], r["feedback"]["action"]), ("BLOCKED", "STOP_BLOCKED"))
        self.assertEqual(fake.calls["execute"], 0)

    def test_model_stage_status_is_honoured_and_fault_is_named(self):
        r, _ = run({"task_id": TID, "status": "NOT_PROVEN", "reason": "too little data"})
        self.assertEqual((r["status"], r["feedback"]["reason"]), ("NOT_PROVEN", "too little data"))
        fake = Fake()
        def boom(t, f, e):
            raise RuntimeError("x")
        r = run_vertical_slice(task(LOW), fake.adapters(model=boom))
        self.assertEqual((r["status"], r["event"]), ("FAILED", "ADAPTER_FAULT"))

    def test_slice_uses_only_observed_evidence_ids(self):
        m = model(relations=[{"id": "r1", "source": "a", "target": "b", "basis": "EVIDENCED", "evidence_ids": ["E7"]}])
        r, _ = run(m)
        self.assertIn("RELATION_UNSUPPORTED", {v["rule"] for v in r["model_gate"]["violations"]})


class AdapterStageTests(unittest.TestCase):
    def test_model_template_and_contract_exist(self):
        for table in (model_adapter.TEMPLATES, model_adapter.REQUIRED, model_adapter.ARGS, model_adapter.DECLARATIONS):
            self.assertIn("model", table)
        import json
        ad = model_adapter.make_adapter("model", lambda prompt: json.dumps(model()))
        out = ad(task(LOW), {"frame_id": "F"}, {"records": []})
        self.assertEqual(out["model_id"], "M1")

    def test_model_output_missing_fields_rejected(self):
        import json
        bad = model()
        del bad["hypotheses"]
        ad = model_adapter.make_adapter("model", lambda prompt: json.dumps(bad))
        with self.assertRaises(model_adapter.AdapterOutputError):
            ad(task(LOW), {"frame_id": "F"}, {"records": []})


if __name__ == "__main__":
    unittest.main()
