import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import final_test_run as R  # noqa: E402


class RunnerRehearsalTests(unittest.TestCase):
    def test_fake_run_is_labelled_simulation_and_scores_three_conditions(self):
        res = R.run("fake", "v2")
        self.assertEqual(res["evidence_class"], "SIMULATION_ONLY")
        self.assertEqual(sorted(res["report"]), ["C0", "C1", "C2"])
        self.assertEqual(res["samples_fingerprint"], R.V2.fingerprint_v2())
        self.assertEqual(res["report"]["C2"]["n"], 20)
        self.assertEqual(res["not_covered"], [])

    def test_timeout_samples_c2_is_inconclusive_not_pass_and_not_a_safety_violation(self):
        call_model, executor = R.fake_backend()
        conds = R.make_conditions(call_model, executor, set(R.V2.SIDE_EFFECT_KINDS))
        for s in (x for x in R.V2.SAMPLES_V2 if x["kind"] == "timeout_unknown_side_effect"):
            out = conds["C2"](s)
            self.assertEqual(out["status"], "INCONCLUSIVE")
            self.assertTrue(out["side_effect_executed"])  # authorized action did run; only its result is unknown
            self.assertEqual(conds["C0"](s)["status"], "PASS")
            self.assertEqual(conds["C1"](s)["status"], "INCONCLUSIVE")
        self.assertNotIn("timeout_unknown_side_effect", R.V2.SIDE_EFFECT_KINDS)

    def test_side_effect_is_measured_by_executor_not_self_reported(self):
        call_model, executor = R.fake_backend()
        smp = [s for s in R.V2.SAMPLES_V2 if s["id"] in {"H1", "P1"}]
        conds = R.make_conditions(call_model, executor, set(R.V2.SIDE_EFFECT_KINDS))
        self.assertTrue(all(conds["C2"](s)["side_effect_executed"] is False for s in smp))
        self.assertEqual(executor.log, [])
        self.assertTrue(conds["C0"](smp[0])["side_effect_executed"])
        self.assertEqual(executor.log, ["H1"])

    def test_freeze_is_stable_and_backend_spec_is_validated(self):
        self.assertEqual(R.freeze(), R.freeze())
        self.assertIn("runtime/common.py", R.freeze()["files"])
        with self.assertRaises(ValueError):
            R.load_backend("not-a-spec")

    def test_repeats_expand_ids_and_resume_makes_no_new_calls(self):
        import tempfile
        base = R.V2.SAMPLES_V2
        self.assertEqual(len(R.expand(base, 3)), 60)
        self.assertEqual(R.expand(base, 1), list(base))
        self.assertTrue(R.expand(base, 2)[-1]["id"].endswith("#r2"))
        d = tempfile.mkdtemp()
        path = os.path.join(d, "ckpt.json")
        first = R.run("fake", "v2", repeats=2, resume=path)
        calls = []
        orig = R.fake_backend

        def counting():
            cm, ex = orig()
            return (lambda p: (calls.append(1), cm(p))[1]), ex
        R.fake_backend = counting
        try:
            second = R.run("fake", "v2", repeats=2, resume=path)
        finally:
            R.fake_backend = orig
        self.assertEqual(calls, [])
        self.assertEqual(first["report"], second["report"])

    def test_breakdown_keeps_per_kind_and_axis_rows_that_sum_to_totals(self):
        res = R.run("fake", "v2", repeats=2)
        for cond, tabs in res["breakdown"].items():
            self.assertEqual(sum(r["n"] for r in tabs["by_kind"].values()), res["report"][cond]["n"])
            self.assertEqual(sum(r["n"] for r in tabs["by_axis"].values()), res["report"][cond]["n"])
            self.assertEqual(sum(r["hit"] for r in tabs["by_kind"].values()), round(res["report"][cond]["quality"] * res["report"][cond]["n"]))
            self.assertEqual(sum(r["false_pass"] for r in tabs["by_kind"].values()), res["report"][cond]["false_pass"])
        self.assertEqual(len(res["outcomes"]["C2"]), 40)
        self.assertEqual(set(R.AXIS_OF_KIND), {s["kind"] for s in R.V2.SAMPLES_V2})

    def test_freeze_record_pins_files_rubrics_and_sample_ids(self):
        rec = R.freeze_record()
        self.assertEqual(rec["samples_v2_fingerprint"], R.V2.fingerprint_v2())
        self.assertEqual(rec["freeze"], R.freeze())
        self.assertIn("T1", rec["v2_sample_ids"])

    def test_llm_spec_routes_to_profile_backend(self):
        with self.assertRaises(Exception):
            R.load_backend("llm:no_such_profile")

    def test_axis_pairs_are_report_only_and_control_pair_is_unchanged(self):
        res = R.run("fake", "v2")
        ac = res["axis_comparison"]
        self.assertEqual((ac["n"], ac["control_changed"], ac["human_turns_c2a"]), (4, [], 5.0))
        self.assertGreater(ac["rework_c2"], ac["rework_c2a"])
        self.assertEqual(sorted(res["report"]), ["C0", "C1", "C2"])  # C2A never enters the decision report
        self.assertFalse(any(k.startswith("X") for k in res["outcomes"]["C2"]))
        self.assertEqual(res["decision"], R.H.decide(res["report"], R.V2.SAMPLES_V2, R.V2.RUBRIC_V2))
        self.assertEqual(R.run("fake", "v1")["axis_comparison"]["n"], 0)

    def test_stability_flags_flips_and_needs_repeats(self):
        o = {"C2": {"A#r1": {"status": "PASS"}, "A#r2": {"status": "BLOCKED"}, "B#r1": {"status": "PASS"}, "B#r2": {"status": "PASS"}}}
        st = R.stability(o)["C2"]
        self.assertEqual((st["bases"], st["stable"], st["flips"]), (2, 1, ["A"]))
        self.assertIn("note", R.stability({"C2": {"A": {"status": "PASS"}}})["C2"])

    def test_every_slot_row_declares_how_it_is_probed(self):
        import json
        with open(os.path.join(os.path.dirname(__file__), "..", "docs", "progress_ledger.json"), encoding="utf-8") as fh:
            rows = [f for f in json.load(fh)["functions"] if f["status"] == "SLOT_TEMPLATE_ONLY"]
        kinds = {s["kind"] for s in R.V2.SAMPLES_V2}
        self.assertEqual(len(rows), 12)
        for r in rows:
            p = r["slot_probe"]
            self.assertIn(p["measure"], {"STATUS", "DEFERRED_LT-06"})
            self.assertTrue(p["why"])
            self.assertLessEqual(set(p["kinds"]), kinds)
            self.assertLessEqual(set(p["metrics"]), set(R.V2.RUBRIC_V2["report_only"]))
            self.assertEqual(p["measure"] == "STATUS", bool(p["kinds"] or p["metrics"]))

    def test_closed_loop_condition_ends_every_sample_in_a_named_exit_and_stays_out_of_scoring(self):
        res = R.run("fake", "v2", repeats=2)
        cl = res["closed_loop"]
        self.assertEqual(cl["n"], 20)  # once per base sample, not per repeat
        self.assertEqual((cl["gate"], cl["bad_stops"], cl["safety_violations"]), ("PASS", [], []))
        self.assertNotIn("C3", res["breakdown"])
        self.assertNotIn("C3", res["outcomes"])
        self.assertEqual(sorted(i for i, *_ in cl["flips_vs_c2"]), ["T1#r1", "T2#r1"])  # timeout samples: state inspection resolves INCONCLUSIVE; flagged for the reviewer

    def test_c3_passes_the_four_upstream_reentry_handlers_plus_state_inspection(self):
        seen = []
        real = R.run_closed_loop
        R.run_closed_loop = lambda task, ad, budget=None, handlers=None: seen.append(sorted(handlers)) or real(task, ad, budget=budget, handlers=handlers)
        try:
            R.run("fake", "v2", repeats=1)
        finally:
            R.run_closed_loop = real
        self.assertTrue(seen)
        want = sorted(["REROUTE_METHOD", "REVISE_PROBLEM_MODEL", "REFRAME_PROBLEM", "GATHER_DISCRIMINATING_EVIDENCE", "INSPECT_ACTUAL_STATE_BEFORE_RETRY"])
        self.assertTrue(all(h == want for h in seen))

    def test_closed_loop_gate_fails_on_uncontrolled_exit_or_unauthorized_side_effect(self):
        smp = [{"id": "A", "kind": "unauthorized_side_effect"}, {"id": "B", "kind": "normal"}]
        c2 = {"A": {"status": "BLOCKED"}, "B": {"status": "PASS"}}
        bad = R.closed_loop_report({"A": {"status": "BLOCKED", "stop": "LOOP_GUARD", "attempts": 3}, "B": {"status": "PASS", "stop": "ACCEPTED_BY_SLICE", "attempts": 1}},
                                   c2, smp, {"unauthorized_side_effect"})
        self.assertEqual((bad["gate"], bad["bad_stops"]), ("FAIL", ["A"]))
        unsafe = R.closed_loop_report({"A": {"status": "PASS", "stop": "ACCEPTED_BY_SLICE", "attempts": 1, "side_effect_executed": True}}, c2, smp, {"unauthorized_side_effect"})
        self.assertEqual((unsafe["gate"], unsafe["safety_violations"]), ("FAIL", ["A"]))
        self.assertEqual(R.closed_loop_report({}, {}, [], set())["gate"], "NOT_RUN")

    def test_profile_freeze_ignores_operational_fields_but_not_model(self):
        base = {"_doc": "x", "groq": {"protocol": "openai", "base_url": "u", "model": "m", "temperature": 0.0, "max_tokens": 1200, "rpm": 25, "timeout_s": 120, "note": "a"}}
        ops = {**base, "groq": {**base["groq"], "rpm": 5, "timeout_s": 300, "note": "b", "max_retries": 9}}
        other = {**base, "groq": {**base["groq"], "model": "m2"}}
        d = lambda x: R.profile_digest(__import__("json").dumps(x).encode())  # noqa: E731
        self.assertEqual(d(base), d(ops))
        self.assertNotEqual(d(base), d(other))
        self.assertNotIn("tools/manual_eval.py", R.FROZEN_FILES)  # manual path is PROTOCOL_FOLLOWING only; it is not on the API-run path

    def test_transport_failure_aborts_c2_and_c3_instead_of_becoming_a_checkpointed_failed_sample(self):
        import tempfile, json
        import llm_backend as L
        base, executor = R.fake_backend()
        n = [0]

        def flaky(prompt):  # the 3rd model call hits a provider/quota failure
            n[0] += 1
            if n[0] == 3:
                raise L.BackendError("daily cap")
            return base(prompt)
        s = next(x for x in R.V2.SAMPLES_V2 if x["kind"] == "normal")
        for loop in (False, True):
            n[0] = 0
            conds = R.make_conditions(flaky, executor, set(R.V2.SIDE_EFFECT_KINDS), with_axis=True)
            with self.assertRaises(L.BackendError):
                conds["C3" if loop else "C2"](s)
        path = tempfile.mkstemp(suffix=".json")[1]
        os.remove(path)
        n[0] = 0
        wrapped = R.resumable(R.make_conditions(flaky, executor, set(R.V2.SIDE_EFFECT_KINDS)), path)
        with self.assertRaises(L.BackendError):
            wrapped["C2"](s)
        self.assertFalse(os.path.exists(path))  # nothing checkpointed for the interrupted sample
        n[0] = 99
        self.assertEqual(wrapped["C2"](s)["status"], "PASS")  # resume reruns it


if __name__ == "__main__":
    unittest.main()
