import copy
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
import context_compaction as C  # noqa: E402


def ctx(n=30, size=200):
    return {"goal": "ship B26.3", "axis": ["目的：X（已確認）", "約束：Y（已確認）"], "unknowns": ["U1 未決"],
            "decisions": [{"id": "D1", "text": "用規則先行", "evidence_ids": ["E1", "E2"]}],
            "pending_authorizations": [{"id": "A1", "text": "待擁有者核准推送"}],
            "entries": [{"id": i, "text": "x" * size} for i in range(n)], "extra": {"k": 1}}


class CompactTests(unittest.TestCase):
    def test_within_budget_is_returned_unchanged(self):
        c = ctx(2, 10)
        r = C.compact(c, 10_000)
        self.assertTrue(r["accepted"])
        self.assertFalse(r["compacted"])
        self.assertEqual(r["context"], c)

    def test_over_budget_keeps_must_keep_and_newest_entries_with_marker(self):
        c = ctx()
        before = copy.deepcopy(c)
        r = C.compact(c, 3000)
        out = r["context"]
        self.assertTrue(r["accepted"] and r["compacted"])
        self.assertEqual(c, before)  # input untouched
        for k in C.MUST_KEEP_KEYS:
            self.assertEqual(out[k], c[k])
        self.assertEqual(out["extra"], c["extra"])
        head, kept = out["entries"][0], out["entries"][1:]
        self.assertTrue(head["compacted"])
        self.assertEqual(head["omitted_count"], 30 - len(kept))
        self.assertEqual(kept, c["entries"][-len(kept):])
        self.assertLessEqual(r["stats"]["after"], 3000)
        self.assertEqual(r["problems"], [])

    def test_deterministic(self):
        self.assertEqual(C.compact(ctx(), 3000), C.compact(ctx(), 3000))

    def test_second_compaction_extends_marker_and_still_validates(self):
        first = C.compact(ctx(), 3000)["context"]
        second = C.compact(first, 1500)
        self.assertTrue(second["accepted"])
        marker = second["context"]["entries"][0]
        self.assertEqual(marker["omitted_count"] + len(second["context"]["entries"]) - 1, 30)
        self.assertEqual(len([e for e in second["context"]["entries"] if e.get("compacted")]), 1)

    def test_must_keep_larger_than_budget_is_kept_whole_and_flagged(self):
        c = ctx()
        c["goal"] = "g" * 5000
        r = C.compact(c, 1000)
        self.assertTrue(r["accepted"])
        self.assertTrue(r["stats"]["must_keep_over_budget"])
        self.assertEqual(r["context"]["goal"], c["goal"])
        self.assertEqual(len(r["context"]["entries"]), 1)  # marker only

    def test_non_list_entries_pass_through_untouched(self):
        c = ctx()
        c["entries"] = "free text " * 600
        r = C.compact(c, 1000)
        self.assertEqual(r["context"]["entries"], c["entries"])

    def test_bad_arguments_raise(self):
        for b in (0, -1, True, "5", None):
            with self.assertRaises(ValueError):
                C.compact(ctx(), b)
        with self.assertRaises(ValueError):
            C.compact([], 100)


class SummarizerSlotTests(unittest.TestCase):
    def test_summary_is_labelled_unverified_and_capped(self):
        r = C.compact(ctx(), 3000, lambda om, keep: "s" * 9000)
        s = r["context"]["summary"]
        self.assertEqual(s["status"], "UNVERIFIED_SUMMARY")
        self.assertLessEqual(len(s["text"]), C.SUMMARY_CAP)
        self.assertLessEqual(r["stats"]["after"], 3000)

    def test_summarizer_gets_only_omitted_entries_and_must_keep(self):
        seen = {}
        C.compact(ctx(), 3000, lambda om, keep: seen.update(n=len(om), keep=sorted(keep)) or "ok")
        self.assertGreater(seen["n"], 0)
        self.assertEqual(seen["keep"], sorted(C.MUST_KEEP_KEYS))

    def test_failing_or_unusable_summarizer_falls_back_to_baseline(self):
        base = C.compact(ctx(), 3000)
        for fn in (lambda *a: 1 / 0, lambda *a: None, lambda *a: "   ", lambda *a: {"x": 1}):
            r = C.compact(ctx(), 3000, fn)
            self.assertEqual(r, base)

    def test_no_summarizer_call_when_nothing_omitted(self):
        calls = []
        C.compact(ctx(2, 10), 10_000, lambda *a: calls.append(1) or "s")
        self.assertEqual(calls, [])

    def test_summary_never_pushes_the_result_over_budget(self):
        r = C.compact(ctx(), 1400, lambda *a: "s" * 1100)
        self.assertTrue(r["accepted"])
        self.assertLessEqual(r["stats"]["after"], 1400)


class ValidatorTests(unittest.TestCase):
    def setUp(self):
        self.orig = ctx()
        self.good = C.compact(self.orig, 3000)["context"]

    def test_good_passes(self):
        self.assertEqual(C.validate_compaction(self.orig, self.good, 3000), [])

    def test_each_must_keep_loss_or_rewrite_is_rejected(self):
        for k in C.MUST_KEEP_KEYS:
            lost = {x: v for x, v in self.good.items() if x != k}
            self.assertTrue(any(k in p for p in C.validate_compaction(self.orig, lost, 3000)), k)
        edited = copy.deepcopy(self.good)
        edited["decisions"][0]["evidence_ids"] = ["E1"]  # evidence reference dropped
        self.assertTrue(C.validate_compaction(self.orig, edited, 3000))
        edited = copy.deepcopy(self.good)
        edited["axis"].reverse()
        self.assertTrue(C.validate_compaction(self.orig, edited, 3000))

    def test_entry_rewrite_reorder_and_forged_marker_rejected(self):
        e = copy.deepcopy(self.good)
        e["entries"][-1]["text"] = "changed"
        self.assertTrue(C.validate_compaction(self.orig, e, 3000))
        e = copy.deepcopy(self.good)
        e["entries"][1:] = list(reversed(e["entries"][1:]))
        self.assertTrue(C.validate_compaction(self.orig, e, 3000))
        e = copy.deepcopy(self.good)
        e["entries"][0]["omitted_sha256"] = "0" * 64
        self.assertTrue(any("digest" in p for p in C.validate_compaction(self.orig, e, 3000)))
        e = copy.deepcopy(self.good)
        e["entries"][0]["omitted_count"] += 1
        self.assertTrue(any("count" in p for p in C.validate_compaction(self.orig, e, 3000)))
        e = copy.deepcopy(self.good)
        del e["entries"][0]  # silent omission without a marker
        self.assertTrue(C.validate_compaction(self.orig, e, 3000))

    def test_summary_claiming_observation_or_malformed_rejected(self):
        for s in ({"status": "OBSERVED", "text": "t"}, {"status": "UNVERIFIED_SUMMARY", "text": "t", "observed": True},
                  {"status": "UNVERIFIED_SUMMARY", "text": ""}, "plain string"):
            e = dict(self.good, summary=s)
            self.assertTrue(C.validate_compaction(self.orig, e, 3000), s)

    def test_over_budget_rejected_and_never_raises_on_garbage(self):
        self.assertTrue(any("over budget" in p for p in C.validate_compaction(self.orig, self.orig, 3000)))
        for bad in (None, [], "x", 3):
            self.assertTrue(C.validate_compaction(bad, self.good, 10))
            self.assertTrue(C.validate_compaction(self.orig, bad, 10))

    def test_rejected_compaction_returns_original(self):
        orig = ctx()
        real = C.validate_compaction
        try:
            C.validate_compaction = lambda *a: ["forced"]
            r = C.compact(orig, 3000)
        finally:
            C.validate_compaction = real
        self.assertFalse(r["accepted"])
        self.assertEqual(r["context"], orig)
        self.assertEqual(json.dumps(r["problems"]), '["forced"]')



class ValidatorEdges(unittest.TestCase):
    """B27.8 wave-2 mutation survivors: each verifier branch must reject its own failure."""
    BIG = 10 ** 6

    def probs(self, orig, comp):
        return C.validate_compaction(orig, comp, self.BIG)

    def test_must_keep_vs_pass_through_are_reported_once_and_correctly(self):
        o = {"goal": "G", "decisions": ["d1"], "extra": "x"}
        self.assertEqual(self.probs(o, dict(o)), [])
        self.assertEqual(self.probs(o, {**o, "decisions": ["d2"]}), ["must-keep changed or lost: decisions"])
        self.assertEqual(self.probs(o, {k: v for k, v in o.items() if k != "goal"}), ["must-keep changed or lost: goal"])
        self.assertEqual(self.probs(o, {**o, "extra": "y"}), ["pass-through key changed or lost: extra"])
        self.assertEqual(self.probs(o, {**o, "unknowns": []}), ["must-keep appeared from nowhere: unknowns"])
        self.assertEqual(self.probs(o, {**o, "newkey": 1}), [])  # an extra non-must-keep key is not this verifier's concern

    def test_entries_presence_and_non_list_passthrough(self):
        self.assertEqual(self.probs({"goal": "G"}, {"goal": "G", "entries": []}), ["entries appeared from nowhere"])
        self.assertEqual(self.probs({"goal": "G"}, {"goal": "G"}), [])
        o = {"goal": "G", "entries": "not a list"}
        self.assertEqual(self.probs(o, dict(o)), [])
        self.assertEqual(self.probs(o, {"goal": "G", "entries": "other"}), ["entries changed or lost"])
        self.assertEqual(self.probs(o, {"goal": "G"}), ["entries changed or lost"])

    def test_marker_must_not_change_when_nothing_was_omitted(self):
        m = {"compacted": True, "omitted_count": 3, "omitted_sha256": "abc"}
        o = {"goal": "G", "entries": [m, {"id": 1}]}
        self.assertEqual(self.probs(o, copy.deepcopy(o)), [])
        bad = {"goal": "G", "entries": [{**m, "omitted_count": 4}, {"id": 1}]}
        self.assertEqual(self.probs(o, bad), ["marker changed although nothing was omitted"])
        self.assertEqual(self.probs(o, {"goal": "G", "entries": [{"id": 1}]}), ["marker changed although nothing was omitted"])
        plain = {"goal": "G", "entries": [{"id": 1}]}
        self.assertEqual(self.probs(plain, copy.deepcopy(plain)), [])

    def test_summarizer_only_runs_when_something_was_omitted(self):
        calls = []

        def summ(omitted, keep):
            calls.append(len(omitted))
            return "s" * 60
        small = ctx(n=2, size=10)
        r = C.compact(small, 10 ** 6, summ)
        self.assertEqual((calls, "summary" in r["context"], r["stats"]["summary"]), ([], False, "NONE"))
        big = ctx(n=30, size=200)
        r = C.compact(big, 3000, summ)
        self.assertTrue(calls and calls[-1] > 0)
        summary = r["context"]["summary"]
        self.assertEqual(summary["status"], "UNVERIFIED_SUMMARY")
        self.assertTrue(summary["text"] and set(summary["text"]) == {"s"} and len(summary["text"]) <= 60)
        self.assertEqual(r["stats"]["summary"], "UNVERIFIED_SUMMARY")

    def test_non_list_entries_pass_through_compact_and_absent_stays_absent(self):
        r = C.compact({"goal": "G", "entries": "plain text"}, 10 ** 6)
        self.assertEqual((r["accepted"], r["problems"], r["context"]["entries"]), (True, [], "plain text"))
        r = C.compact({"goal": "G"}, 10 ** 6)
        self.assertNotIn("entries", r["context"])


if __name__ == "__main__":
    unittest.main()
