import copy
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import final_test_samples_v2 as V2  # noqa: E402
import result_digest as D  # noqa: E402

KINDS = ("normal", "critical_unknown_high_risk")


def fixture():
    cond = {"n": 4, "quality": 1.0, "false_pass": 0, "safety_violations": 0, "cost": 3.0, "failures_kept": []}
    row = {"n": 2, "hit": 2, "false_pass": 0, "safety_violations": 0}
    return {"backend": "fake", "samples": "v2", "repeats": 2, "rubric_fingerprint": "r", "evidence_class": "SIMULATION_ONLY",
            "decision": {"decision": "ADOPT"}, "samples_fingerprint": V2.fingerprint_v2(), "freeze": {"combined": "f" * 16},
            "report": {c: dict(cond, failures_kept=[]) for c in ("C0", "C1", "C2")},
            "breakdown": {c: {"by_kind": {k: dict(row) for k in KINDS}, "by_axis": {}} for c in ("C0", "C1", "C2")},
            "axis_comparison": {"n": 4, "rework_c2": 3, "rework_c2a": 0, "outcomes": {"C2": {"X1": ["PASS", 3]}}},
            "stability": {"C2": {"note": "x"}}, "backend_stats": {"calls": 9}, "not_covered": []}


class ResultDigestTests(unittest.TestCase):
    def setUp(self):
        self.res = fixture()

    def test_digest_is_compact_and_flags_simulation(self):
        d = D.digest(self.res)
        self.assertEqual(sorted(d["report"]), ["C0", "C1", "C2"])
        self.assertNotIn("outcomes", d["axis_comparison"])
        self.assertTrue(any("not a real run" in w for w in d["warnings"]))
        self.assertLess(len(D.render(d)), 2000)
        self.assertEqual(d["failed_samples"]["C2"], {})

    def test_failures_group_by_sample_and_weak_kinds_show(self):
        r = copy.deepcopy(self.res)
        r["report"]["C2"]["failures_kept"] = ["H1#r1", "H1#r2", "N1#r1"]
        r["breakdown"]["C2"]["by_kind"]["critical_unknown_high_risk"]["hit"] = 0
        d = D.digest(r)
        self.assertEqual(d["failed_samples"]["C2"], {"H1": 2, "N1": 1})
        self.assertIn("critical_unknown_high_risk", d["weak_kinds"]["C2"])

    def test_stale_fingerprint_and_freeze_mismatch_are_warned(self):
        r = copy.deepcopy(self.res)
        r["samples_fingerprint"] = "0" * 16
        d = D.digest(r, {"freeze": {"combined": "x" * 16}})
        self.assertTrue(any("stale result" in w for w in d["warnings"]))
        self.assertTrue(any("freeze combined" in w for w in d["warnings"]))
        self.assertFalse(any("freeze combined" in w for w in D.digest(self.res, {"freeze": {"combined": "f" * 16}})["warnings"]))

    def test_real_run_label_is_not_warned_as_simulation(self):
        r = copy.deepcopy(self.res)
        r["evidence_class"] = "REAL_RUN_UNREVIEWED"
        self.assertFalse(any("not a real run" in w for w in D.digest(r)["warnings"]))


if __name__ == "__main__":
    unittest.main()
