"""对話主軸: switch, HOLD/ECHO behaviour, dependency-scoped edits, and the opt-in slice entry."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

import dialogue_axis as D  # noqa: E402
from foravar_vertical_slice import run_vertical_slice  # noqa: E402
from loop_fixtures import Fake, task  # noqa: E402

FULL = {"purpose": "讓團隊週報不再手工整理", "object": "一份可重用的週報範本", "start": "現有三份手寫週報",
        "done": "新範本能在 10 分鐘內填完", "constraints": "不更動現有表單系統"}


def filled(**over):
    st = D.new_state()
    for k, v in {**FULL, **over}.items():
        if v is not None:
            st = D.propose(st, k, v)
    return st


class AxisTests(unittest.TestCase):
    def test_default_off_and_malformed_switch_reads_as_off(self):
        self.assertFalse(D.is_enabled({}))
        self.assertFalse(D.is_enabled({"dialogue_axis": {"enabled": "yes"}}))
        self.assertFalse(D.is_enabled("on"))
        self.assertTrue(D.is_enabled({"dialogue_axis": {"enabled": True}}))
        for cfg in (None, "x", {"enabled": False}, {"enabled": 1}, {}):
            g = D.gate(cfg)
            self.assertEqual((g["mode"], g["release"]), ("OFF", True))

    def test_on_with_nothing_confirmed_holds_and_asks_only_the_core_first(self):
        a = D.assess(D.new_state(), True)
        self.assertEqual((a["mode"], a["release"]), ("HOLD", False))
        self.assertEqual([q["node"] for q in a["questions"]], ["purpose"])
        self.assertEqual(a["questions"][0]["kind"], "OPEN")
        self.assertEqual(a["pending"], list(D.REQUIRED))

    def test_questions_follow_dependencies_and_are_capped(self):
        st = D.confirm(D.propose(D.new_state(), "purpose", "p"), "purpose")
        a = D.assess(st, True)
        self.assertEqual([q["node"] for q in a["questions"]], ["object", "done"])  # start waits for object
        self.assertLessEqual(len(a["questions"]), D.MAX_QUESTIONS)

    def test_ambiguous_node_offers_distinct_branches_plus_other_and_choose_confirms(self):
        br = [{"id": "a", "label": "封裝檔案", "meaning": "把檔案打包成壓縮檔"}, {"id": "b", "label": "蒸餾精華", "meaning": "把內容濃縮成重點"}]
        st = D.propose(D.new_state(), "purpose", branches=br)
        q = D.assess(st, True)["questions"][0]
        self.assertEqual((q["kind"], q["options"][-1]["id"]), ("CHOICE", "OTHER"))
        st, info = D.choose(st, "purpose", "b")
        self.assertEqual(D._node(st, "purpose")["status"], "CONFIRMED")
        self.assertFalse(info["core_changed"])
        with self.assertRaises(ValueError):
            D.choose(D.propose(D.new_state(), "purpose", branches=br), "purpose", "zzz")
        for bad in ([br[0]], [br[0], dict(br[0])], br * 3, [{"id": "a", "label": "x", "meaning": ""}, br[1]]):
            with self.assertRaises(ValueError):
                D.propose(D.new_state(), "purpose", branches=bad)

    def test_complete_opening_is_echoed_and_proceeds_without_questions(self):
        st, a = D.open_conversation(filled(), True)
        self.assertEqual((a["mode"], a["release"], a["questions"]), ("ECHO_AND_PROCEED", True, []))
        self.assertIn(FULL["purpose"], a["echo"])
        self.assertEqual(D.assess(st, True)["mode"], "CONFIRMED")

    def test_incomplete_opening_holds_even_if_most_nodes_are_filled(self):
        _, a = D.open_conversation(filled(done=None), True)
        self.assertEqual((a["mode"], a["release"]), ("HOLD", False))
        self.assertIn("done", a["pending"])
        _, off = D.open_conversation(filled(done=None), False)
        self.assertEqual(off["mode"], "OFF")

    def test_confirm_refuses_open_nodes_and_confirm_all_leaves_them_open(self):
        with self.assertRaises(ValueError):
            D.confirm(D.new_state(), "purpose")
        st = D.confirm_all(filled(done=None))
        self.assertEqual(D._node(st, "purpose")["status"], "CONFIRMED")
        self.assertEqual(D._node(st, "done")["status"], "UNKNOWN")

    def test_local_edit_reopens_only_dependents_and_core_edit_reopens_the_chain(self):
        st, _ = D.open_conversation(filled(method="用表單範本"), True)
        st2, info = D.edit(st, "done", "新範本能在 5 分鐘內填完")
        self.assertEqual(info["reopened"], ["method"])
        self.assertEqual({n: D._node(st2, n)["status"] for n in ("purpose", "object", "start", "constraints")}, {n: "CONFIRMED" for n in ("purpose", "object", "start", "constraints")})
        self.assertEqual(D._node(st2, "method")["status"], "STALE")
        st3, info3 = D.edit(st, "purpose", "讓週報自動彙整")
        self.assertTrue(info3["core_changed"])
        self.assertEqual(set(info3["reopened"]), {"object", "start", "done", "constraints", "method"})
        self.assertEqual(D.assess(st3, True)["mode"], "HOLD")
        st4, info4 = D.edit(st, "done", FULL["done"])  # same text: nothing reopens
        self.assertEqual((info4["changed"], info4["reopened"]), (False, []))

    def test_edit_is_pure_and_reopen_marks_the_node_and_its_dependents(self):
        st, _ = D.open_conversation(filled(), True)
        before = repr(st)
        D.edit(st, "purpose", "別的目的")
        self.assertEqual(repr(st), before)
        st2 = D.reopen(st, "object")
        self.assertEqual([n for n in D.IDS if D._node(st2, n)["status"] == "STALE"], ["object", "start"])

    def test_render_is_compact_and_shows_status(self):
        text = D.render(D.confirm_all(filled(done=None)))
        self.assertIn("完成條件：—（未定）", text)
        self.assertNotIn("方法", text)  # optional and unknown: not shown

    def test_node_table_is_consistent(self):
        self.assertEqual(D.dependents("purpose"), ["object", "start", "done", "constraints", "method"])
        self.assertEqual(D.dependents("method"), [])


class EntryTests(unittest.TestCase):
    def run_it(self, cfg, **kw):
        fake = Fake()
        res = D.run_with_axis(task(dialogue_axis=cfg, **kw), fake.adapters(), run_vertical_slice)
        return res, fake

    def test_enabled_unconfirmed_axis_runs_nothing(self):
        res, fake = self.run_it({"enabled": True, "state": D.new_state()})
        self.assertEqual((res["status"], res["feedback"]["action"]), ("NOT_EXECUTED", "ASK_USER_TO_CONFIRM_AXIS"))
        self.assertEqual(sum(fake.calls.values()), 0)
        self.assertEqual(res["dialogue_axis"]["mode"], "HOLD")

    def test_disabled_or_confirmed_axis_lets_the_task_run_and_is_reported(self):
        for cfg in ({"enabled": False, "state": D.new_state()}, {"enabled": True, "state": D.confirm_all(filled())}):
            res, fake = self.run_it(cfg)
            self.assertNotEqual(res["status"], "NOT_EXECUTED", cfg)
            self.assertEqual(fake.calls["frame"], 1)
            self.assertIn(res["dialogue_axis"]["mode"], {"OFF", "CONFIRMED"})

    def test_absent_field_is_unchanged_behaviour(self):
        fake = Fake()
        res = D.run_with_axis(task(), fake.adapters(), run_vertical_slice)
        self.assertEqual(fake.calls["frame"], 1)
        self.assertNotIn("dialogue_axis", res)

    def test_confirmed_axis_seeds_missing_goal_and_acceptance_but_never_overrides(self):
        seen = []
        run = lambda t, a: seen.append(t) or {"status": "PASS"}  # noqa: E731
        cfg = {"enabled": True, "state": D.confirm_all(filled())}
        D.run_with_axis({"task_id": "T", "dialogue_axis": cfg}, {}, run)
        self.assertEqual(seen[0]["goal"], FULL["purpose"])
        self.assertEqual(seen[0]["acceptance_criteria"][0]["description"], FULL["done"])
        self.assertEqual(seen[0]["confirmed_constraints"], [FULL["constraints"]])  # K2: confirmed constraints reach the frame stage via the task
        self.assertNotIn("dialogue_axis", seen[0])
        D.run_with_axis({"task_id": "T", "goal": "explicit", "acceptance_criteria": [{"id": "X"}], "dialogue_axis": cfg}, {}, run)
        self.assertEqual((seen[1]["goal"], seen[1]["acceptance_criteria"]), ("explicit", [{"id": "X"}]))
        self.assertEqual(D.to_task_seed(filled()), {})  # proposals (ASSUMED) seed nothing

    def test_placement_rule_slice_and_axis_do_not_import_each_other(self):
        root = os.path.join(os.path.dirname(__file__), "..", "runtime")
        with open(os.path.join(root, "foravar_vertical_slice.py"), encoding="utf-8") as fh:
            self.assertNotIn("dialogue_axis", fh.read())
        with open(os.path.join(root, "dialogue_axis.py"), encoding="utf-8") as fh:
            src = fh.read()
        self.assertNotIn("import foravar_vertical_slice", src)
        self.assertNotIn("from foravar_vertical_slice", src)



class AxisEdges(unittest.TestCase):
    """B27.8 wave-2 mutation survivors in dialogue_axis."""

    def test_required_nodes(self):
        self.assertEqual({n[0] for n in D.NODES if n[2]}, {"purpose", "object", "start", "done", "constraints"})

    def test_node_reader_never_trusts_malformed_state(self):
        blank = {"status": "UNKNOWN", "value": None}
        for state in ("x", None, 5, {"nodes": []}, {"nodes": "n"}, {"nodes": {"purpose": "x"}},
                      {"nodes": {"purpose": {"status": "ASSUMED", "value": "  "}}},
                      {"nodes": {"purpose": {"status": "ASSUMED", "value": 5}}},
                      {"nodes": {"purpose": {"status": "BOGUS", "value": "v"}}}):
            self.assertEqual(D._node(state, "purpose"), blank, state)
        ok = {"nodes": {"purpose": {"status": "ASSUMED", "value": "v"}, "object": {"status": "UNKNOWN"}}}
        self.assertEqual(D._node(ok, "purpose"), {"status": "ASSUMED", "value": "v"})
        self.assertEqual(D._node(ok, "object"), {"status": "UNKNOWN"})

    def test_propose_blank_value_is_unknown_and_edit_rejects_blank(self):
        st = D.propose(D.new_state(), "purpose", "   ")
        self.assertEqual(st["nodes"]["purpose"], {"status": "UNKNOWN", "value": None})
        st = D.propose(D.new_state(), "purpose", "  做 X  ")
        self.assertEqual(st["nodes"]["purpose"], {"status": "ASSUMED", "value": "做 X"})
        for bad in ("", "  ", 5, None):
            with self.assertRaises(ValueError, msg=repr(bad)):
                D.edit(D.new_state(), "purpose", bad)

    def test_disabled_axis_never_seeds_the_task_even_with_a_confirmed_state(self):
        st = D.confirm(D.propose(D.new_state(), "purpose", "from axis"), "purpose")
        seen = {}

        def run(merged, adapters):
            seen.update(merged)
            return {"status": "X"}
        D.run_with_axis({"task_id": "T", "dialogue_axis": {"enabled": False, "state": st}}, {}, run)
        self.assertEqual(seen, {"task_id": "T"})
        seen.clear()
        D.run_with_axis({"task_id": "T", "dialogue_axis": {"enabled": True, "state": D.new_state()}}, {}, run)
        self.assertEqual(seen, {})  # unconfirmed axis holds: nothing runs


class AxisSource(unittest.TestCase):
    """LT-30: who wrote a node value survives confirm / edit / choose / stale / reopen; nothing else about the axis changes."""

    BR = [{"id": "a", "label": "甲", "meaning": "做甲"}, {"id": "b", "label": "乙", "meaning": "做乙"}]

    def test_confirming_an_ai_proposal_adds_nothing_and_reads_as_ai_proposed_like_legacy_nodes(self):
        st = D.confirm(D.propose(D.new_state(), "purpose", "P"), "purpose")
        self.assertEqual(st["nodes"]["purpose"], {"status": "CONFIRMED", "value": "P"})  # untouched proposal: same bytes as before LT-30
        self.assertEqual(D.source_of(st, "purpose"), "ai_proposed")
        legacy = {"nodes": {"purpose": {"status": "CONFIRMED", "value": "P"}}}
        self.assertEqual(D.source_of(legacy, "purpose"), "ai_proposed")
        self.assertEqual(D.source_of(D.new_state(), "object"), "ai_proposed")

    def test_edit_over_an_assumed_value_records_user_edit_and_optional_quote(self):
        st = D.propose(D.new_state(), "purpose", "AI 猜的")
        st, info = D.edit(st, "purpose", "我自己寫的", quote="  我原本說的那句  ")
        self.assertEqual(st["nodes"]["purpose"], {"status": "CONFIRMED", "value": "我自己寫的", "source": "user_edit", "quote": "我原本說的那句"})
        self.assertEqual(info, {"changed": True, "reopened": [], "core_changed": False})  # return shape unchanged
        st, _ = D.edit(D.propose(D.new_state(), "purpose", "p"), "purpose", "p", quote="   ")
        self.assertNotIn("quote", st["nodes"]["purpose"])  # blank quote is not stored
        self.assertEqual(D.source_of(st, "purpose"), "user_edit")  # typing the same words is still the user's act

    def test_choose_records_user_choice(self):
        st = D.propose(D.new_state(), "object", branches=self.BR)
        st, _ = D.choose(st, "object", "b", quote="我要乙")
        self.assertEqual(st["nodes"]["object"], {"status": "CONFIRMED", "value": "乙：做乙", "source": "user_choice", "quote": "我要乙"})

    def test_source_survives_stale_and_reconfirm_but_a_new_edit_replaces_it(self):
        st = D.confirm_all(filled())
        st, _ = D.edit(st, "object", "使用者寫的產出")
        st, info = D.edit(st, "purpose", "新的目的")  # re-opens dependents
        self.assertIn("object", info["reopened"])
        self.assertEqual(st["nodes"]["object"]["status"], "STALE")
        self.assertEqual(D.source_of(st, "object"), "user_edit")  # kept value keeps its author
        self.assertEqual(D.source_of(D.confirm(st, "object"), "object"), "user_edit")
        st = D.reopen(D.confirm_all(filled()), "done")
        self.assertEqual((st["nodes"]["done"]["status"], D.source_of(st, "done")), ("STALE", "ai_proposed"))
        self.assertEqual(D.source_of(D.edit(st, "done", "改過")[0], "done"), "user_edit")

    def test_source_never_changes_gate_seed_or_render_and_junk_source_is_ignored(self):
        plain = {"nodes": {n: {"status": "CONFIRMED", "value": FULL[n]} for n in FULL}}
        marked = D.confirm_all(filled())
        marked, _ = D.edit(marked, "purpose", FULL["purpose"], quote="q")
        self.assertEqual((D.assess(marked, True), D.to_task_seed(marked), D.render(marked)), (D.assess(plain, True), D.to_task_seed(plain), D.render(plain)))
        for junk in ({"source": 5}, {"source": "root"}, {"source": None}, {"quote": 3}, {"quote": "  "}):
            st = {"nodes": {"purpose": {"status": "CONFIRMED", "value": "P", **junk}}}
            self.assertEqual(D._node(st, "purpose"), {"status": "CONFIRMED", "value": "P"}, junk)
            self.assertEqual(D.source_of(st, "purpose"), "ai_proposed")
        with self.assertRaises(ValueError):
            D.source_of(D.new_state(), "nope")


if __name__ == "__main__":
    unittest.main()
