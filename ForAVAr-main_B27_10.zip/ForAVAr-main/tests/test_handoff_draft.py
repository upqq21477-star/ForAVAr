"""LT-03: fixed sections, no empty section, entry ids traceable, read-only."""
import json
import os
import shutil
import sys
import tempfile
import unittest

HERE = os.path.dirname(__file__)
sys.path.insert(0, os.path.join(HERE, "..", "tools"))

import handoff_draft as HD  # noqa: E402

ROOT = os.path.abspath(os.path.join(HERE, ".."))


def sections(md):
    return {h.strip(): [x for x in body.strip().split("\n") if x.strip()] for h, body in (p.split("\n", 1) for p in md.split("\n## ")[1:])}


class RealRepoTests(unittest.TestCase):
    def test_sections_are_fixed_ordered_and_never_empty(self):
        md = HD.build(ROOT, "BX")
        sec = sections(md)
        self.assertEqual(tuple(sec), HD.SECTIONS)
        self.assertTrue(all(v for v in sec.values()))
        self.assertTrue(md.startswith("# BX forAVAr"))

    def test_entry_ids_are_traceable_to_the_change_log(self):
        with open(os.path.join(ROOT, "docs", "change_log.json"), encoding="utf-8") as fh:
            log = json.load(fh)["entries"]
        ids = {e["id"] for e in log}
        md = HD.build(ROOT, entries=3)
        shown = [x for x in sections(md)["本次更改"] if x.startswith("- CL-")]
        self.assertEqual(len(shown), 3)
        self.assertTrue(all(x[2:8] in ids for x in shown))
        self.assertIn(f"- {log[-1]['id']}", md)

    def test_open_items_come_from_not_this_and_todo_lists_unfinished_work(self):
        sec = sections(HD.build(ROOT))
        self.assertTrue(any(x.startswith("- CL-") for x in sec["需你核對"]))
        self.assertTrue(any("TODO" in x or "OPEN" in x or "BLOCKED" in x for x in sec["待辦"]))

    def test_build_does_not_modify_the_repo(self):
        before = HD.tree_hashes(ROOT)
        HD.build(ROOT, entries=2, prev=ROOT)
        self.assertEqual(before, HD.tree_hashes(ROOT))


class DiffAndFailureTests(unittest.TestCase):
    def test_diff_lists_changed_added_removed(self):
        with tempfile.TemporaryDirectory() as a, tempfile.TemporaryDirectory() as b:
            for d, files in ((a, {"x": "1", "y": "1"}), (b, {"x": "2", "z": "1"})):
                for n, t in files.items():
                    with open(os.path.join(d, n), "w") as fh:
                        fh.write(t)
            self.assertEqual(HD.diff_files(a, b), {"added": ["z"], "removed": ["y"], "changed": ["x"]})

    def test_empty_sources_are_named_not_blank(self):
        with tempfile.TemporaryDirectory() as d:
            os.makedirs(os.path.join(d, "docs"))
            with open(os.path.join(d, "docs", "change_log.json"), "w") as fh:
                json.dump({"entries": []}, fh)
            with open(os.path.join(d, "docs", "progress_ledger.json"), "w") as fh:
                json.dump({"roadmap": {"program": {}}}, fh)
            sec = sections(HD.build(d))
        self.assertTrue(all(v and "來源無資料" in v[0] for v in sec.values()))

    def test_missing_files_return_nonzero_without_traceback(self):
        with tempfile.TemporaryDirectory() as d:
            self.assertEqual(HD.main([d]), 1)


if __name__ == "__main__":
    unittest.main()
