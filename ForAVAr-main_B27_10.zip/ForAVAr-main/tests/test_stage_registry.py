"""LT-20: slice stages are independent modules that talk only through Run (structure + contract level)."""
import ast
import os
import sys
import unittest

RUNTIME = os.path.join(os.path.dirname(__file__), "..", "runtime")
sys.path.insert(0, RUNTIME)
sys.path.insert(0, os.path.dirname(__file__))

import foravar_vertical_slice as slice_mod  # noqa: E402
import stage_common  # noqa: E402
from loop_fixtures import LOW, TID, Fake, task  # noqa: E402

STAGE_FILES = sorted(f[:-3] for f in os.listdir(RUNTIME) if f.startswith("stage_") and f.endswith(".py") and f != "stage_common.py")


def _imports(name):
    tree = ast.parse(open(os.path.join(RUNTIME, name + ".py"), encoding="utf-8").read())
    out = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            out.add(node.module.lstrip("."))
        elif isinstance(node, ast.Import):
            out.update(a.name for a in node.names)
    return out


class StageStructure(unittest.TestCase):
    def test_stages_do_not_import_each_other_or_the_slice(self):
        self.assertTrue(STAGE_FILES)
        for name in STAGE_FILES:
            bad = {m for m in _imports(name) if m.startswith("stage_") and m != "stage_common" or m == "foravar_vertical_slice"}
            self.assertEqual(bad, set(), name)

    def test_common_is_a_leaf(self):
        self.assertEqual({m for m in _imports("stage_common") if m.startswith("stage_") or m.endswith("_gate") or m == "foravar_vertical_slice"}, set())

    def test_registry_lists_every_stage_file_in_trace_order(self):
        expected = ["stage_frame", "stage_evidence", "stage_model", "stage_route", "stage_authorize", "stage_cancel",
                    "stage_execute", "stage_evaluate", "stage_synthesis", "stage_feedback"]
        self.assertEqual([f.__module__ for f in slice_mod.STAGES], expected)
        self.assertEqual(sorted(expected), STAGE_FILES)  # no stage file outside the registry, none missing
        self.assertEqual([f.__module__ for f in slice_mod.PRE_STAGES], expected[:3])
        for f in slice_mod.STAGES:
            self.assertTrue(callable(f))

    def test_slice_holds_order_and_fault_exit_only(self):
        src = open(os.path.join(RUNTIME, "foravar_vertical_slice.py"), encoding="utf-8").read()
        self.assertLess(len(src.splitlines()), 130)
        self.assertEqual({m for m in _imports("foravar_vertical_slice") if m.endswith("_gate")}, set())


class StageContract(unittest.TestCase):
    def test_happy_path_trace_order_is_unchanged(self):
        out = slice_mod.run_vertical_slice(task(LOW), Fake().adapters())
        self.assertEqual(out["trace"][:3], ["FRAME", "EVIDENCE", "EVIDENCE_GATE"])
        self.assertEqual(out["trace"][-1], "FEEDBACK")

    def test_stage_returns_early_result_not_exception(self):
        ad = Fake().adapters(frame=lambda t: {"task_id": TID, "status": "BLOCKED", "reason": "no"})
        out = slice_mod.run_vertical_slice(task(LOW), ad)
        self.assertEqual((out["status"], out["trace"]), ("BLOCKED", ["FRAME"]))

    def test_run_object_carries_state_between_stages(self):
        ctx = {"trace": [], "stage": "task"}
        r = stage_common.Run({"task_id": TID}, TID, dict(LOW), Fake().adapters(), ctx)
        self.assertIsNone(slice_mod.PRE_STAGES[0](r))
        self.assertEqual(r.frame["status"], "READY")
        self.assertEqual(r.trace, ["FRAME"])


if __name__ == "__main__":
    unittest.main()
