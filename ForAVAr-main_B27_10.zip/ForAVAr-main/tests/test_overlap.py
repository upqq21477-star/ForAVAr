import os
import sys
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import overlap  # noqa: E402


class Overlap(unittest.TestCase):
    def test_finds_docs_and_code_for_a_known_feature(self):
        hits = overlap.scan(ROOT, ["dialogue_axis"])
        self.assertIn("docs/features.json", hits)
        self.assertTrue(any(f.startswith("docs/") for f in hits) and "runtime/dialogue_axis.py" in hits or "tests" not in hits)

    def test_any_word_matches_and_case_is_ignored(self):
        self.assertTrue(overlap.scan(ROOT, ["RUN_WITH_AXIS", "nonexistent_zzz"]))

    def test_field_names_in_string_literals_are_found(self):
        hits = overlap.scan(ROOT, ["out_of_scope"])
        self.assertIn("runtime/frame_gate.py", hits)

    def test_no_match_is_empty(self):
        self.assertEqual(overlap.scan(ROOT, ["qqqq_not_a_word_zzz"]), {})

    def test_cap_limits_rows_per_file(self):
        rows = overlap.scan(ROOT, ["a"], cap=3)
        self.assertTrue(all(len(v) <= 4 for v in rows.values()))

    def test_blast_only_for_python_files(self):
        b = overlap.blast(ROOT, ["runtime/dialogue_axis.py", "docs/index.json"])
        self.assertEqual(list(b), ["runtime/dialogue_axis.py"])
        self.assertIn("tests", b["runtime/dialogue_axis.py"])


if __name__ == "__main__":
    unittest.main()
