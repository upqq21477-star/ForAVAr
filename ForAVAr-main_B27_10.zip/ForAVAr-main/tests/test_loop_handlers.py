"""LT-13: re-entry handlers return contract fields only, change adapters/method only, and say nothing when there is nothing new."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

import loop_handlers as H  # noqa: E402

KEYS = {"task", "adapters", "method", "target", "new_evidence_ids", "discriminating_change", "actual_state_read", "cost",
        "execution", "outcome", "correction", "apply", "branch", "state_report", "regression_run"}
ROUTE = {"task_id": "T", "status": "ROUTED", "candidate_methods": ["m1", "m2", "m3"], "selected_method": "m1", "reason": "r",
         "stop_rule": "s", "requires_authorization": False, "required_scope": ["w"]}


def ctx(action, history=("m1",), route=ROUTE, reason="x" * 1000):
    return {"task": {"task_id": "T", "goal": "g"}, "action": action, "attempt": len(history), "failure_class": "METHOD_OR_ROUTING_ERROR",
            "history": [{"method": m} for m in history],
            "last_result": {"route": route, "feedback": {"reason": reason},
                            "acceptance": {"criteria_results": [{"criterion_id": f"C{i}", "status": "FAIL"} for i in range(20)] + [{"criterion_id": "OK", "status": "PASS"}]}}}


class HandlerContractTests(unittest.TestCase):
    def test_every_handler_returns_only_contract_keys_and_no_task_replacement(self):
        seen = []
        base = {s: (lambda t, *a, _s=s: seen.append((_s, t)) or {}) for s in ("frame", "evidence", "model")}
        h = H.make_handlers(base)
        self.assertEqual(set(h), set(H.ACTIONS))
        for action in H.ACTIONS:
            out = h[action](ctx(action))
            self.assertLessEqual(set(out), KEYS, action)
            self.assertNotIn("task", out)

    def test_no_adapter_for_the_stage_means_nothing_new(self):
        h = H.make_handlers({})
        for action in ("REVISE_PROBLEM_MODEL", "REFRAME_PROBLEM", "GATHER_DISCRIMINATING_EVIDENCE"):
            self.assertEqual(h[action](ctx(action)), {})


class RerouteTests(unittest.TestCase):
    def test_picks_the_first_untried_candidate_and_replays_the_route(self):
        out = H.make_handlers({})["REROUTE_METHOD"](ctx("REROUTE_METHOD"))
        self.assertEqual(out["method"], "m2")
        route = out["adapters"]["route"]({}, {}, {})
        self.assertEqual((route["selected_method"], route["candidate_methods"], route["required_scope"]), ("m2", ROUTE["candidate_methods"], ["w"]))
        self.assertEqual(ROUTE["selected_method"], "m1")  # the previous route is not mutated

    def test_skips_every_tried_method_and_stops_when_none_left(self):
        self.assertEqual(H.make_handlers({})["REROUTE_METHOD"](ctx("REROUTE_METHOD", history=("m1", "m2")))["method"], "m3")
        self.assertEqual(H.make_handlers({})["REROUTE_METHOD"](ctx("REROUTE_METHOD", history=("m1", "m2", "m3"))), {})

    def test_missing_or_malformed_route_means_nothing_new(self):
        for bad in (None, {}, {"candidate_methods": "m1"}):
            self.assertEqual(H.make_handlers({})["REROUTE_METHOD"](ctx("REROUTE_METHOD", route=bad)), {})


class WrapTests(unittest.TestCase):
    def test_wrapped_stage_sees_bounded_retry_context_and_original_task_is_untouched(self):
        got = {}
        h = H.make_handlers({"evidence": lambda t, f: got.update(t=t, f=f) or {"ok": 1}})
        out = h["GATHER_DISCRIMINATING_EVIDENCE"](ctx("GATHER_DISCRIMINATING_EVIDENCE"))
        task = {"task_id": "T", "goal": "g"}
        self.assertEqual(out["adapters"]["evidence"](task, {"frame": 1}), {"ok": 1})
        rc = got["t"]["retry_context"]
        self.assertEqual((len(rc["reason"]), len(rc["open_criteria"]), rc["methods_tried"]), (H.REASON_CAP, H.CRITERIA_CAP, ["m1"]))
        self.assertNotIn("PASS", [c["status"] for c in rc["open_criteria"]])
        self.assertNotIn("retry_context", task)
        self.assertEqual(got["f"], {"frame": 1})

    def test_retries_wrap_the_base_adapter_never_an_earlier_wrapper(self):
        depth = []
        h = H.make_handlers({"frame": lambda t: depth.append(t) or {}})
        for _ in range(3):
            h["REFRAME_PROBLEM"](ctx("REFRAME_PROBLEM"))["adapters"]["frame"]({"task_id": "T"})
        self.assertTrue(all(set(t) == {"task_id", "retry_context"} for t in depth))

    def test_context_is_deterministic(self):
        self.assertEqual(H.retry_context(ctx("REROUTE_METHOD")), H.retry_context(ctx("REROUTE_METHOD")))



class HandlerEdges(unittest.TestCase):
    """B27.8 wave-2 survivors in loop_handlers' deterministic helpers."""

    def test_retry_context_lists_only_open_criteria_and_keeps_the_class(self):
        ctx = {"attempt": 2, "action": "A", "failure_class": "SOME_CLASS",
               "last_result": {"acceptance": {"criteria_results": [
                   {"criterion_id": "C1", "status": "PASS"}, {"criterion_id": "C2", "status": "FAIL"}, "junk", None,
                   {"criterion_id": "C3", "status": "UNKNOWN"}]}, "feedback": {"reason": "r" * 5000}}}
        rc = H.retry_context(ctx)
        self.assertEqual(rc["open_criteria"], [{"criterion_id": "C2", "status": "FAIL"}, {"criterion_id": "C3", "status": "UNKNOWN"}])
        self.assertEqual((rc["attempt"], rc["action"], rc["failure_class"]), (2, "A", "SOME_CLASS"))
        self.assertLessEqual(len(rc["reason"]), H.REASON_CAP)
        self.assertEqual(H.retry_context({})["failure_class"], "UNKNOWN")

    def test_tried_methods_are_unique_strings_in_order(self):
        ctx = {"history": [{"method": "a"}, {"method": "b"}, {"method": "a"}, {"method": 5}, "junk", {"x": 1}, None]}
        self.assertEqual(H._tried(ctx), ["a", "b"])
        self.assertEqual(H._tried({}), [])

    def test_reroute_reason_names_the_failure_class(self):
        route = {"candidate_methods": ["m1", "m2"], "selected_method": "m1"}
        got = H._reroute({"last_result": {"route": route}, "failure_class": "SOME_CLASS"})
        self.assertIn("untried candidate after SOME_CLASS on m1", got["adapters"]["route"]()["reason"])
        got = H._reroute({"last_result": {"route": route}})
        self.assertIn("untried candidate after failure on m1", got["adapters"]["route"]()["reason"])
        self.assertEqual(got["method"], "m2")


if __name__ == "__main__":
    unittest.main()
