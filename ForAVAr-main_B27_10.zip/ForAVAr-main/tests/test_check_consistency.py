import json
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
from check_consistency import check  # noqa: E402


class ConsistencyTests(unittest.TestCase):
    def copy_repo(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for sub in ("docs", "runtime", "tests"):
            shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copy(os.path.join(ROOT, "README.md"), d)
        return d

    def test_real_repo_has_no_errors(self):
        r = check(ROOT)
        self.assertEqual(r["errors"], 0, r["findings"])
        self.assertGreater(r["ids_checked"]["capability"], 0)

    def test_detects_duplicate_id_and_count_mismatch(self):
        d = self.copy_repo()
        p = os.path.join(d, "docs", "capability_registry.json")
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        data["items"].append(dict(data["items"][0]))
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        checks = {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}
        self.assertTrue({"id_unique", "index_counts"} <= checks)

    def test_detects_broken_json_missing_file_and_unlisted_module(self):
        d = self.copy_repo()
        with open(os.path.join(d, "docs", "problem_register.json"), "w") as fh:
            fh.write("{bad")
        os.remove(os.path.join(d, "runtime", "run_record.py"))
        with open(os.path.join(d, "runtime", "extra.py"), "w") as fh:
            fh.write("")
        checks = {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}
        self.assertTrue({"json_parse", "local_ref", "readme_listing"} <= checks)

    def _ledger_mutation(self, fn):
        d = self.copy_repo()
        p = os.path.join(d, "docs", "progress_ledger.json")
        with open(p, encoding="utf-8") as fh:
            led = json.load(fh)
        fn(led)
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(led, fh, ensure_ascii=False)
        return {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}

    def test_ledger_detects_missing_acceptance_unknown_status_and_missing_id(self):
        def mut(led):
            led["functions"][0]["acceptance"] = []
            led["functions"][1]["status"] = "BUILD_COMPLETE"
            led["problems"].pop()
        self.assertTrue({"ledger_acceptance", "ledger_status", "ledger_ids"} <= self._ledger_mutation(mut))

    def test_ledger_gate_order_and_evidence_rules(self):
        def mut(led):
            led["stage_gates"][2]["status"] = "PASSED"   # CLOSURE passed while REALIZATION is not
            led["stage_gates"][0]["evidence"] = ""
        self.assertIn("ledger_gates", self._ledger_mutation(mut))

    def test_ledger_accepted_needs_evidence_and_merge_target_must_exist(self):
        def mut(led):
            led["functions"][0]["status"] = "ACCEPTED"
            m = next(f for f in led["functions"] if f["ruling"] == "MERGE_INTO")
            m["merged_into"] = "NOPE-999"
        self.assertTrue({"ledger_evidence", "ledger_merge"} <= self._ledger_mutation(mut))

    def test_ledger_closure_gaps_and_planned_items_need_an_increment(self):
        def mut(led):
            led["closure_matrix"]["rows"].append({"scenario": "synthetic gap", "status": "GAP", "realize": "R99"})
            f = next(f for f in led["functions"] if f["ruling"] == "ADOPT")  # synthetic: ledger may hold no PLANNED item
            f["status"], f["realize"] = "PLANNED", None
        self.assertIn("ledger_closure", self._ledger_mutation(mut))

    def test_registry_items_all_reference_ledger(self):
        d = self.copy_repo()
        p = os.path.join(d, "docs", "capability_registry.json")
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        del data["items"][3]["ledger_ref"]
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        self.assertIn("ledger_ref", {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"})

    def _edit_doc(self, name, fn):
        d = self.copy_repo()
        p = os.path.join(d, "docs", name)
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        fn(data)
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False)
        return {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}

    def test_ledger_ref_must_resolve_to_existing_ledger_id(self):
        def dangling(data):
            data["items"][3]["ledger_ref"] = "docs/progress_ledger.json#/functions/NOPE-999"
        def wrong_id(data):
            data["items"][3]["ledger_ref"] = data["items"][4]["ledger_ref"]
        def malformed(data):
            data["items"][3]["ledger_ref"] = "progress_ledger.json"
        for fn in (dangling, wrong_id, malformed):
            self.assertIn("ledger_ref", self._edit_doc("capability_registry.json", fn), fn.__name__)

    def test_problem_register_items_need_resolvable_ledger_ref(self):
        self.assertIn("ledger_ref", self._edit_doc("problem_register.json", lambda d: d["items"][0].pop("ledger_ref")))
        self.assertIn("ledger_ref", self._edit_doc("problem_register.json",
                      lambda d: d["items"][0].__setitem__("ledger_ref", "docs/progress_ledger.json#/problems/PR-999")))

    def test_vocabulary_is_aligned_no_known_deviation(self):
        r = check(ROOT)
        self.assertEqual([x for x in r["findings"] if x["check"] not in {"stray_artifact", "file_mode"}], [])  # env-only INFOs excluded


if __name__ == "__main__":
    unittest.main()
