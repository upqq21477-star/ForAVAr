import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import guard_rules as G  # noqa: E402


def _tree(files: dict[str, str]) -> tempfile.TemporaryDirectory:
    d = tempfile.TemporaryDirectory()
    for rel, text in files.items():
        p = os.path.join(d.name, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(text)
    return d


class Guards(unittest.TestCase):
    def test_repo_is_clean(self):
        import json
        with open(os.path.join(ROOT, "docs", "progress_ledger.json"), encoding="utf-8") as fh:
            self.assertEqual(G.findings(ROOT, json.load(fh)), [])

    def test_dynamic_import_forms_are_caught_in_runtime_only(self):
        with _tree({"runtime/a.py": "import importlib\n", "runtime/b.py": "x = __import__('os')\n", "runtime/c.py": "eval('1')\n",
                    "runtime/d.py": "from importlib import util\n", "runtime/ok.py": "import json\n", "tools/t.py": "import importlib\n"}) as d:
            hits = sorted(x[1].split(":")[0] for x in G.dynamic_import(d))
        self.assertEqual(hits, ["runtime/a.py", "runtime/b.py", "runtime/c.py", "runtime/d.py"])

    def test_entry_guard_allows_listed_files_and_flags_others(self):
        with _tree({"runtime/foravar_vertical_slice.py": "def run_vertical_slice(): pass\n", "runtime/other.py": "from x import run_vertical_slice\n",
                    "tools/t.py": "import m\nm.run_vertical_slice()\n", "tools/final_test_run.py": "run_vertical_slice()\n",
                    "runtime/doc.py": '"""mentions run_vertical_slice only in text"""\n', "tests/test_x.py": "run_vertical_slice()\n"}) as d:
            hits = sorted(x[1].split(":")[0] for x in G.entry_guard(d))
        self.assertEqual(hits, ["runtime/other.py", "tools/t.py"])

    def test_ledger_ruling_requires_known_value_on_every_function_row(self):
        led = {"functions": [{"id": "A", "ruling": "ADOPT"}, {"id": "B"}, {"id": "C", "ruling": "NEW"}]}
        self.assertEqual([x[1].split(":")[0] for x in G.ledger_ruling(led)], ["B", "C"])
        self.assertEqual(G.ledger_ruling(None), [])

    def _log_tree(self, entry_patch=None, mech=("M1",), drop=()):
        import json
        e = {"id": "CL-001", "date": "2026-10-25", "status": "ACCEPTED", "need": "n", "owner": ["runtime/a.py"], "ruling": "ADOPT", "change": "c",
             "why": "w", "not_this": ["x"], "replan": {"scope": ["runtime/a.py"], "status": "CLOSED"}, "mechanisms": ["M1"]}
        e.update(entry_patch or {})
        for k in drop:
            e.pop(k, None)
        return _tree({"runtime/a.py": "x = 1\n", "docs/features.json": json.dumps({"mech": {m: ["runtime/a.py", "x", "t"] for m in mech}}),
                      "docs/change_log.json": json.dumps({"entries": [e]})})

    def test_change_log_accepts_a_complete_entry(self):
        with self._log_tree() as d:
            self.assertEqual(G.change_log(d), [])

    def test_change_log_flags_each_form_problem(self):
        cases = [({"ruling": "MAYBE"}, "ruling"), ({"status": "SUPERSEDED"}, "superseded_by"), ({"supersedes": ["CL-009"]}, "unknown entry"),
                 ({"owner": ["nope.py"]}, "owner"), ({"replan": {"scope": [], "status": "OPEN"}}, "replan status"),
                 ({"not_this": []}, "not_this"), ({"mechanisms": ["ZZ"]}, "not in docs/features.json"), ({"date": "25/10"}, "date"),
                 ({"id": "X1"}, "id must")]
        for patch, word in cases:
            with self._log_tree(patch) as d:
                self.assertTrue(any(word in x[1] for x in G.change_log(d)), (patch, G.change_log(d)))
        with self._log_tree(drop=("need",)) as d:
            self.assertTrue(any("need" in x[1] for x in G.change_log(d)))

    def test_change_log_requires_every_mechanism_to_be_covered(self):
        with self._log_tree(mech=("M1", "M2")) as d:
            self.assertEqual([x[1].split(" ")[1] for x in G.change_log(d)], ["M2"])

    def test_superseded_entry_may_name_things_retired_since_but_a_live_one_may_not(self):
        import json
        base = {"date": "2026-10-25", "need": "n", "ruling": "ADOPT", "change": "c", "why": "w", "not_this": ["x"],
                "replan": {"scope": ["runtime/a.py"], "status": "CLOSED"}}
        old = dict(base, id="CL-001", status="SUPERSEDED", superseded_by="CL-002", owner=["gone.py"], mechanisms=["GONE"])
        new = dict(base, id="CL-002", status="ACCEPTED", owner=["runtime/a.py"], mechanisms=["M1"], supersedes=["CL-001"])
        files = {"runtime/a.py": "x = 1\n", "docs/features.json": json.dumps({"mech": {"M1": ["runtime/a.py", "x", "t"]}})}
        with _tree(dict(files, **{"docs/change_log.json": json.dumps({"entries": [old, new]})})) as d:
            self.assertEqual(G.change_log(d), [])
        live_old = dict(old, status="ACCEPTED", superseded_by=None)
        with _tree(dict(files, **{"docs/change_log.json": json.dumps({"entries": [live_old, new]})})) as d:
            msgs = " ".join(x[1] for x in G.change_log(d))
            self.assertTrue("'gone.py'" in msgs and "'GONE'" in msgs, msgs)
        no_target = dict(old, superseded_by="CL-009")
        with _tree(dict(files, **{"docs/change_log.json": json.dumps({"entries": [no_target, new]})})) as d:
            self.assertTrue(any("superseded_by" in x[1] for x in G.change_log(d)))

    def test_change_log_missing_file_is_an_error(self):
        with _tree({"runtime/a.py": "x = 1\n"}) as d:
            self.assertEqual(len(G.change_log(d)), 1)

    # --- echelon_check (CL-011 and later; blueprint echelons) ---
    FT = 'FROZEN_DIRS = ("runtime", "adapters")\nFROZEN_FILES = ("tools/final_test_run.py",)\n'

    def _ec_tree(self, ec="default", scope=("docs/x.json",), eid="CL-011", ft=True):
        import json
        good = {"E1": {"result": "PASS", "note": "n"}, "E2": {"result": "PASS", "note": "n"}, "E3": {"result": "NOT_APPLICABLE", "note": "docs only"},
                "E4": {"result": "NOT_TRIGGERED", "note": "no frozen file"}}
        e = {"id": eid, "date": "2026-10-25", "status": "ACCEPTED", "need": "n", "owner": ["runtime/a.py"], "ruling": "ADOPT", "change": "c", "why": "w",
             "not_this": ["x"], "replan": {"scope": list(scope), "status": "CLOSED"}, "mechanisms": []}
        if ec == "default":
            e["echelon_check"] = good
        elif ec is not None:
            e["echelon_check"] = ec(good) if callable(ec) else ec
        files = {"runtime/a.py": "x = 1\n", "docs/features.json": json.dumps({"mech": {}}), "docs/change_log.json": json.dumps({"entries": [e]})}
        if ft:
            files["tools/final_test_run.py"] = self.FT
        return _tree(files)

    def _msgs(self, d):
        return " | ".join(x[1] for x in G.change_log(d))

    def test_echelon_complete_record_passes(self):
        with self._ec_tree() as d:
            self.assertEqual(G.change_log(d), [])

    def test_echelon_entries_before_the_rule_are_exempt(self):
        with self._ec_tree(ec=None, eid="CL-010") as d:
            self.assertEqual(G.change_log(d), [])

    def test_echelon_missing_record_is_flagged_from_cl011(self):
        with self._ec_tree(ec=None) as d:
            self.assertIn("echelon_check missing", self._msgs(d))

    def test_echelon_form_problems_are_flagged(self):
        def patch(k, v):
            def f(g):
                g = {a: dict(b) for a, b in g.items()}
                g[k] = v
                return g
            return f
        cases = [(patch("E1", {"result": "FAIL", "note": "n"}), "E1.result"), (patch("E2", {"result": "PASS", "note": " "}), "E2.note"),
                 (patch("E3", {"result": "NOT_TRIGGERED", "note": "n"}), "E3.result"), (patch("E4", {"result": "PASS", "note": "n"}), "E4.result"),
                 (patch("E4", {"result": "DONE_REAL", "note": "n"}), "needs evidence"), (lambda g: {k: v for k, v in g.items() if k != "E2"}, "keys must be exactly"),
                 (lambda g: {**g, "E5": g["E1"]}, "keys must be exactly"), ("oops", "missing")]
        for ec, word in cases:
            with self._ec_tree(ec=ec) as d:
                self.assertIn(word, self._msgs(d), (word, self._msgs(d)))

    def test_echelon_e4_not_triggered_is_refused_when_scope_touches_frozen_set(self):
        for scope in (["runtime/a.py"], ["tools/final_test_run.py"]):
            with self._ec_tree(scope=scope) as d:
                self.assertIn("touches the frozen set", self._msgs(d))
        with self._ec_tree(scope=["tools/guard_rules.py", "runtime/readme.txt", "docs/x.json"]) as d:
            self.assertEqual(G.change_log(d), [])

    def test_echelon_e4_pending_is_allowed_on_frozen_scope(self):
        ec = lambda g: {**g, "E4": {"result": "PENDING_REAL_RUN", "note": "runtime changed"}}  # noqa: E731
        with self._ec_tree(ec=ec, scope=["runtime/a.py"]) as d:
            self.assertEqual(G.change_log(d), [])

    def test_echelon_unreadable_frozen_set_is_an_error_not_a_pass(self):
        with self._ec_tree(ft=False) as d:
            self.assertIn("cannot derive the frozen set", self._msgs(d))

    def test_echelon_frozen_scope_is_matched_after_path_normalisation(self):
        fz = (("runtime", "adapters"), ("tools/final_test_run.py",))
        hit = ["./runtime/common.py", "runtime/", "runtime", "tools/../runtime/common.py", "/runtime/common.py", "Runtime/common.py",
               "tools/./final_test_run.py", "adapters", "tools", ".", "runtime\\common.py"]
        for p in hit:
            self.assertEqual(G._touches_frozen([p], fz), [p], p)
        for p in ["docs/x.json", "tools/guard_rules.py", "runtime/readme.txt", "runtimes/a.py", "tests/test_x.py", "", 5, None]:
            self.assertEqual(G._touches_frozen([p], fz), [], p)


if __name__ == "__main__":
    unittest.main()
