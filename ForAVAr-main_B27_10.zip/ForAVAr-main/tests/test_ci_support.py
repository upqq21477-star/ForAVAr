"""Contract tests for tools/ci_support.py and static guards on .github/workflows/final_test.yml (no network, no YAML library)."""
from __future__ import annotations

import json
import os
import re
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import ci_support as C  # noqa: E402

PROFILES = {"groq": {"model": "openai/gpt-oss-120b"}, "cerebras": {"model": "gpt-oss-120b"}, "gemini": {"model": ""},
            "openrouter": {"model": ""}}
WORKFLOW = os.path.join(ROOT, ".github", "workflows", "final_test.yml")


def _write(d: str, name: str, obj: object) -> str:
    p = os.path.join(d, name)
    with open(p, "w", encoding="utf-8") as fh:
        json.dump(obj, fh)
    return p


class IndependenceTests(unittest.TestCase):
    def test_same_model_on_two_providers_is_refused(self) -> None:
        ok, msg = C.independence("groq", "", "cerebras", "", PROFILES)
        self.assertFalse(ok)
        self.assertIn("same model", msg)

    def test_same_family_name_is_refused(self) -> None:
        ok, _ = C.independence("groq", "", "openrouter", "openai/gpt-4o-mini", PROFILES)
        self.assertFalse(ok)

    def test_generator_without_model_is_refused(self) -> None:
        ok, msg = C.independence("groq", "", "gemini", "", PROFILES)
        self.assertFalse(ok)
        self.assertIn("gen_model", msg)

    def test_different_family_passes_with_heuristic_caveat(self) -> None:
        ok, msg = C.independence("groq", "", "gemini", "gemini-2.5-flash", PROFILES)
        self.assertTrue(ok)
        self.assertIn("reviewer", msg)

    def test_unknown_backend_raises(self) -> None:
        with self.assertRaises(ValueError):
            C.independence("nope", "", "gemini", "x", PROFILES)

    def test_default_profiles_file_loads(self) -> None:
        self.assertEqual(C.effective_model("groq"), "openai/gpt-oss-120b")

    def test_family_key(self) -> None:
        self.assertEqual(C.family_key("openai/gpt-oss-120b"), "gpt")
        self.assertEqual(C.family_key("gemini-2.5-flash"), "gemini")
        self.assertEqual(C.family_key("123"), "")

    def test_candidate_file_generator_is_checked(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            same = _write(d, "a.json", {"generator": {"model": "gpt-oss-120b"}, "samples": []})
            other = _write(d, "b.json", {"generator": {"model": "gemini-2.5-flash"}, "samples": []})
            none = _write(d, "c.json", {"generator": {}, "samples": []})
            self.assertFalse(C.independence_cand("groq", "", same, PROFILES)[0])
            self.assertTrue(C.independence_cand("groq", "", other, PROFILES)[0])
            self.assertFalse(C.independence_cand("groq", "", none, PROFILES)[0])


class FreezeAndCandTests(unittest.TestCase):
    def test_freeze_check(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            a = _write(d, "a.json", {"freeze": {"combined": "aaaa"}})
            b = _write(d, "b.json", {"freeze": {"combined": "bbbb"}})
            nof = _write(d, "n.json", {"freeze": {}})
            self.assertTrue(C.freeze_check(a)[0])
            self.assertTrue(C.freeze_check(a, expect="aaaa", against=a)[0])
            self.assertFalse(C.freeze_check(a, expect="bbbb")[0])
            self.assertFalse(C.freeze_check(a, against=b)[0])
            self.assertFalse(C.freeze_check(nof)[0])

    def test_cand_markdown_escapes_table_cells(self) -> None:
        md = C.cand_markdown({"generator": {"model": "m"}, "samples": [{"id": "G1", "kind": "normal", "text": "a|b\nc"}]})
        self.assertIn("| G1 | normal | a\\|b c |", md)
        self.assertIn("m", md.splitlines()[0])

    def test_main_exit_codes(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            a = _write(d, "a.json", {"freeze": {"combined": "aaaa"}})
            self.assertEqual(C.main(["freeze-check", a]), 0)
            self.assertEqual(C.main(["freeze-check", a, "--expect", "zzzz"]), 1)


class WorkflowStaticTests(unittest.TestCase):
    def setUp(self) -> None:
        with open(WORKFLOW, encoding="utf-8") as fh:
            self.lines = fh.read().splitlines()

    def test_only_manual_trigger(self) -> None:
        text = "\n".join(self.lines)
        self.assertIn("workflow_dispatch:", text)
        for bad in ("pull_request", "pull_request_target", "push:", "schedule:", "workflow_run"):
            self.assertNotIn(bad, text)

    def test_inputs_never_interpolated_inside_run_blocks(self) -> None:
        in_run, run_indent = False, 0
        for n, line in enumerate(self.lines, 1):
            indent = len(line) - len(line.lstrip())
            if in_run and line.strip() and indent <= run_indent:
                in_run = False
            if re.match(r"\s*(- )?run:\s*\|", line):
                in_run, run_indent = True, indent
                continue
            if in_run:
                self.assertNotIn("${{", line, f"line {n}: expression inside a run block (pass it through env)")

    def test_no_secret_is_echoed_or_committed(self) -> None:
        text = "\n".join(self.lines)
        self.assertNotRegex(text, r"echo[^\n]*\$\{?[A-Z_]*API_KEY")
        self.assertNotIn("git push", text)
        self.assertNotIn("git commit", text)

    def test_key_names_match_backend_profiles(self) -> None:
        with open(os.path.join(ROOT, "tools", "backend_profiles.json"), encoding="utf-8") as fh:
            profs = json.load(fh)
        text = "\n".join(self.lines)
        for name in ("groq", "gemini", "openrouter", "nvidia", "cerebras", "anthropic"):
            self.assertIn(f"{profs[name]['key_env']}: ${{{{ secrets.{profs[name]['key_env']} }}}}", text)

    def test_third_party_actions_are_pinned_to_a_major_version(self) -> None:
        for line in self.lines:
            m = re.match(r"\s*- uses:\s*(\S+)|\s*uses:\s*(\S+)", line)
            if m:
                ref = m.group(1) or m.group(2)
                self.assertRegex(ref, r"@v\d+$", ref)


if __name__ == "__main__":
    unittest.main()
