import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import confirm_set as CS  # noqa: E402
import final_test_run as R  # noqa: E402


def fake_generator(prompt: str) -> str:
    kind = prompt.split('"kind": "')[1].split('"')[0]
    items = [{"id": f"G-{kind[:3]}-{i}", "kind": kind, "text": f"generated {kind} case number {i}", "expected_status": "PASS",
              **({"authorized_scope": ["delete"]} if kind in CS.NEEDS_SCOPE else {})} for i in (1, 2)]
    return "noise " + json.dumps(items)


class ConfirmSetTests(unittest.TestCase):
    def test_generator_cannot_set_truth_or_flags(self):
        smp = CS.generate(fake_generator, 2)
        self.assertEqual(len(smp), 20)
        for s in smp:
            self.assertEqual(s["expected_status"], CS.KIND_TRUTH[s["kind"]])
        self.assertTrue(all(s.get("simulate_timeout") for s in smp if s["kind"] == "timeout_unknown_side_effect"))

    def test_malformed_or_thin_sets_fail_closed(self):
        good = CS.generate(fake_generator, 2)
        with self.assertRaises(ValueError):
            CS.normalize(good[:-1])  # one kind drops below the minimum
        with self.assertRaises(ValueError):
            CS.normalize([{**good[0], "kind": "bogus"}] + good[1:])
        bad = [dict(s) for s in good if s["kind"] != "partial_scope_authorization"] + [{"id": "x1", "kind": "partial_scope_authorization", "text": "no scope given here"}] * 2
        with self.assertRaises(ValueError):
            CS.normalize(bad)

    def test_freeze_detects_edit_and_unfrozen_file(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "c.json")
        CS.freeze_file(CS.generate(fake_generator, 2), {"model": "gen-model"}, p)
        smp, fp, gen = CS.load_frozen(p)
        self.assertEqual((len(smp), gen["model"]), (20, "gen-model"))
        with open(p) as fh:
            rec = json.load(fh)
        rec["samples"][0]["text"] = "edited after the freeze happened"
        with open(p, "w") as fh:
            json.dump(rec, fh)
        with self.assertRaises(ValueError):
            CS.load_frozen(p)
        with open(p, "w") as fh:
            json.dump({**rec, "frozen": False}, fh)
        with self.assertRaises(ValueError):
            CS.load_frozen(p)

    def test_runner_scores_a_frozen_confirmation_set_on_fake_backend(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "c.json")
        CS.freeze_file(CS.generate(fake_generator, 2), {"model": "gen-model"}, p)
        res = R.run("fake", "confirm", confirm_file=p)
        self.assertEqual(res["samples_fingerprint"], CS.load_frozen(p)[1])
        self.assertEqual(res["report"]["C2"]["n"], 20)
        self.assertEqual(res["evidence_class"], "SIMULATION_ONLY")
        self.assertEqual(res["confirm_generator"]["model"], "gen-model")
        with self.assertRaises(Exception):
            R.run("fake", "confirm")  # no file -> refuse


if __name__ == "__main__":
    unittest.main()
