import os
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "runtime"))
import release_txn as T  # noqa: E402


def _w(root, rel, text):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


def _r(root, rel):
    p = os.path.join(root, rel)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8", newline="") as fh:
        return fh.read()


class ReleaseTxnTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.root = os.path.join(self._t.name, "repo")
        self.snap = os.path.join(self._t.name, "snap")
        _w(self.root, "a.txt", "A1")
        _w(self.root, "sub/b.txt", "B1")

    def tearDown(self):
        self._t.cleanup()

    def test_multi_file_commit_applies_all_including_create_and_delete(self):
        rep = T.apply_transaction(self.root, {"a.txt": "A2", "new/c.txt": "C1", "sub/b.txt": None}, self.snap)
        self.assertEqual(rep["status"], "COMMITTED")
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "new/c.txt"), _r(self.root, "sub/b.txt")), ("A2", "C1", None))
        self.assertEqual(T.classify(self.root, self.snap), "AFTER")

    def test_failed_verify_rolls_back_every_file(self):
        rep = T.apply_transaction(self.root, {"a.txt": "A2", "new/c.txt": "C1"}, self.snap,
                                  verify=lambda r: ["incompatible"])
        self.assertEqual(rep["status"], "ROLLED_BACK")
        self.assertTrue(rep["rollback_verified"])
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "new/c.txt")), ("A1", None))
        self.assertEqual(T.classify(self.root, self.snap), "BEFORE")

    def test_exception_midway_rolls_back_no_partial_state(self):
        def boom(_root):
            raise RuntimeError("verify crashed")
        rep = T.apply_transaction(self.root, {"a.txt": "A2", "sub/b.txt": "B2"}, self.snap, verify=boom)
        self.assertEqual(rep["status"], "ROLLED_BACK")
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "sub/b.txt")), ("A1", "B1"))

    def test_recover_rolls_back_crashed_prepared_release(self):
        T.apply_transaction(self.root, {"a.txt": "A2", "sub/b.txt": "B2"}, self.snap)
        m = T._load(self.snap)
        m["state"] = "PREPARED"  # simulate crash before COMMITTED + one file reverted by hand
        T._write_json(os.path.join(self.snap, "manifest.json"), m)
        _w(self.root, "sub/b.txt", "B1")
        self.assertEqual(T.classify(self.root, self.snap), "PARTIAL")
        self.assertEqual(T.recover(self.root, self.snap), "ROLLED_BACK")
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "sub/b.txt")), ("A1", "B1"))

    def test_explicit_rollback_after_commit_restores_previous_version(self):
        T.apply_transaction(self.root, {"a.txt": "A2", "new/c.txt": "C1"}, self.snap)
        rep = T.rollback(self.root, self.snap)
        self.assertTrue(rep["rollback_verified"])
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "new/c.txt")), ("A1", None))

    def test_restore_drill_passes_then_detects_corrupted_snapshot(self):
        T.apply_transaction(self.root, {"a.txt": "A2"}, self.snap)
        self.assertEqual(T.restore_drill(self.snap), [])
        _w(self.snap, "files/a.txt", "tampered")
        self.assertTrue(any("mismatch" in p for p in T.restore_drill(self.snap)))

    def test_path_escape_authority_and_reuse_rejected(self):
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"../x.txt": "x"}, self.snap)
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap)
        rep = T.apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap, authorized=True)
        self.assertEqual(rep["status"], "COMMITTED")
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"a.txt": "A9"}, self.snap)
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {}, os.path.join(self._t.name, "s2"))


class PersistCheckpointTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.root = os.path.join(self._t.name, "repo")
        os.makedirs(self.root)
        self.snap = os.path.join(self._t.name, "snap")
        sys.path.insert(0, os.path.join(ROOT, "tools"))

    def tearDown(self):
        self._t.cleanup()

    def _bundle(self):
        import state_bundle as sb
        b = sb.build_bundle("T/1", "P2", task_state={"status": "DONE", "next_action": "n", "recovery": "r", "run_records": []})
        h = sb.export_handoff({"task_id": "T/1", "goal": "g"})
        return sb, b, h

    def test_persist_writes_bundle_and_handoff_together_and_reads_back(self):
        sb, b, h = self._bundle()
        rep = sb.persist_checkpoint(self.root, self.snap, b, h)
        self.assertEqual(rep["status"], "COMMITTED")
        self.assertEqual(sb.read_bundle(os.path.join(self.root, "state", "T_1.bundle.json"))["task_id"], "T/1")
        self.assertIn("# HANDOFF", _r(self.root, "state/T_1.handoff.md"))

    def test_failed_verify_leaves_no_files_and_p0_writes_nothing(self):
        sb, b, h = self._bundle()
        rep = sb.persist_checkpoint(self.root, self.snap, b, h, verify=lambda r: ["bad"])
        self.assertEqual(rep["status"], "ROLLED_BACK")
        self.assertIsNone(_r(self.root, "state/T_1.bundle.json"))
        self.assertEqual(sb.persist_checkpoint(self.root, os.path.join(self._t.name, "s2"), None)["status"], "SKIPPED_P0")

    def test_authority_path_in_extra_files_refused_before_any_write(self):
        sb, b, h = self._bundle()
        with self.assertRaises(sb.StateBundleError):
            sb.persist_checkpoint(self.root, self.snap, b, h, extra_files={"docs/blueprint.json": "{}"})
        self.assertIsNone(_r(self.root, "state/T_1.bundle.json"))

    def test_standard_verify_reports_failing_command_only(self):
        import standard_verify as sv
        ok = [sys.executable, "-c", "pass"]
        bad = [sys.executable, "-c", "import sys; print('boom'); sys.exit(3)"]
        self.assertEqual(sv.verify(self.root, (ok,)), [])
        out = sv.verify(self.root, (ok, bad))
        self.assertEqual(len(out), 1)
        self.assertIn("boom", out[0])



# ---- B27.8 mutation-audit edge cases ----
import hashlib  # noqa: E402
import json  # noqa: E402
import json as _json  # noqa: E402
import state_bundle as SB  # noqa: E402


class ReleaseTxnEdges(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        self.root = os.path.join(self._td.name, "repo")
        self.snaps = os.path.join(self._td.name, "snaps")
        os.makedirs(self.root)
        self.n = 0

    def snap(self):
        self.n += 1
        return os.path.join(self.snaps, f"s{self.n}")

    def put(self, rel, text):
        p = os.path.join(self.root, rel)
        os.makedirs(os.path.dirname(p), exist_ok=True)
        with open(p, "w", encoding="utf-8") as fh:
            fh.write(text)

    def get(self, rel):
        p = os.path.join(self.root, rel)
        if not os.path.exists(p):
            return None
        with open(p, encoding="utf-8") as fh:
            return fh.read()

    def test_unsafe_paths_refused_and_nothing_written(self):
        for bad in ("/etc/x", "../x", ".", "", "a/../../x", "..\\x"):
            with self.assertRaises(T.TxnError, msg=repr(bad)):
                T.apply_transaction(self.root, {bad: "x"}, self.snap())
        self.assertEqual(os.listdir(self.root), [])
        self.assertEqual(T.apply_transaction(self.root, {"a/b.txt": "ok"}, self.snap())["status"], "COMMITTED")

    def test_authority_files_need_authorization_only_under_docs(self):
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap())
        self.assertIsNone(self.get("docs/blueprint.json"))
        self.assertEqual(T.apply_transaction(self.root, {"blueprint.json": "{}"}, self.snap())["status"], "COMMITTED")
        self.assertEqual(T.apply_transaction(self.root, {"docs/notes.json": "{}"}, self.snap())["status"], "COMMITTED")
        self.assertEqual(T.apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap(), authorized=True)["status"], "COMMITTED")

    def test_inner_apply_defaults_to_unauthorized(self):
        with self.assertRaises(T.TxnError):
            T._apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap())

    def test_invalid_manifest_is_refused(self):
        T.apply_transaction(self.root, {"a.txt": "1"}, s := self.snap())
        mp = os.path.join(s, "manifest.json")
        good = _jl(mp)
        for patch in ({"schema": "other"}, {"state": "BOGUS"}):
            _jd(mp, {**good, **patch})
            with self.assertRaises(T.TxnError, msg=str(patch)):
                T.classify(self.root, s)

    def test_recover_decisions(self):
        # committed and intact: recover must not touch anything
        self.put("a.txt", "old")
        T.apply_transaction(self.root, {"a.txt": "new"}, s1 := self.snap())
        self.assertEqual((T.recover(self.root, s1), self.get("a.txt")), ("COMMITTED", "new"))
        # manifest still PREPARED (crash before the commit mark): rolled back
        self.put("b.txt", "old")
        T.apply_transaction(self.root, {"b.txt": "new"}, s2 := self.snap())
        mp = os.path.join(s2, "manifest.json")
        m = _jl(mp)
        m["state"] = "PREPARED"
        _jd(mp, m)
        self.assertEqual((T.recover(self.root, s2), self.get("b.txt")), ("ROLLED_BACK", "old"))
        self.assertEqual(_jl(mp)["state"], "ROLLED_BACK")
        # half-applied (one file back at its old content): rolled back whole
        self.put("c.txt", "c0")
        self.put("d.txt", "d0")
        T.apply_transaction(self.root, {"c.txt": "c1", "d.txt": "d1"}, s3 := self.snap())
        self.put("d.txt", "d0")
        self.assertEqual(T.classify(self.root, s3), "PARTIAL")
        self.assertEqual(T.recover(self.root, s3), "ROLLED_BACK")
        self.assertEqual((self.get("c.txt"), self.get("d.txt")), ("c0", "d0"))


class StateBundleEdges(unittest.TestCase):
    def test_compaction_digest_is_exact_and_marker_complete(self):
        recs = [{"z": "中文", "a": i} for i in range(7)]
        out = SB.compact_bundle({"TASK_EXECUTION_STATE": {"run_records": recs}}, max_run_records=3)
        old = recs[:4]
        want = hashlib.sha256(_json.dumps(old, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
        marker, kept = out["TASK_EXECUTION_STATE"]["run_records"][0], out["TASK_EXECUTION_STATE"]["run_records"][1:]
        self.assertEqual(marker, {"compacted": True, "omitted_count": 4, "omitted_sha256": want})
        self.assertEqual(kept, recs[4:])
        self.assertEqual(out["compaction"]["run_records_omitted"], 4)
        same = SB.compact_bundle({"TASK_EXECUTION_STATE": {"run_records": recs[:3]}}, max_run_records=3)
        self.assertNotIn("compaction", same)

    def test_handoff_markdown_marks_empty_list_not_provided(self):
        md = SB.handoff_to_markdown({"task_id": "T", "goal": []})
        self.assertIn("## goal\nNOT_PROVIDED", md)
        self.assertIn("## goal\n- a\n- b", SB.handoff_to_markdown({"task_id": "T", "goal": ["a", "b"]}))

    def test_persist_refuses_authority_names_anywhere_and_docs_dirs(self):
        b = SB.build_bundle("T1", "P2", task_state={"status": "DONE", "next_action": "n", "recovery": "r", "run_records": []})
        with tempfile.TemporaryDirectory() as td:
            root = os.path.join(td, "repo")
            os.makedirs(root)
            for i, rel in enumerate(("docs/x.md", "tools/index.json", "problem_register.json", "operating_contract.json",
                                     "capability_registry.json", "a/blueprint.json")):
                with self.assertRaises(SB.StateBundleError, msg=rel):
                    SB.persist_checkpoint(root, os.path.join(td, f"s{i}"), b, None, extra_files={rel: "{}"})
            self.assertEqual(os.listdir(root), [])


def _jl(path):
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def _jd(path, data):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(data, fh)



class CrashHygiene(unittest.TestCase):
    """B27.8 T3 findings: a killed process must not leave a 10-minute lock or staging litter."""

    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        self.root = os.path.join(self._td.name, "repo")
        os.makedirs(self.root)

    def test_lock_of_dead_owner_is_reclaimed_but_live_owner_is_not(self):
        import subprocess
        dead = subprocess.Popen([sys.executable, "-c", "pass"])
        dead.wait()
        lock = os.path.join(self.root, T.LOCK_NAME)
        with open(lock, "w", encoding="ascii") as fh:
            fh.write(str(dead.pid))
        if os.name == "posix":
            self.assertEqual(T.apply_transaction(self.root, {"a.txt": "1"}, os.path.join(self._td.name, "s1"))["status"], "COMMITTED")
        with open(lock, "w", encoding="ascii") as fh:
            fh.write(str(os.getppid()))  # a live process that is not us
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"a.txt": "2"}, os.path.join(self._td.name, "s2"))
        for junk in ("", "abc", "-5"):
            with open(lock, "w", encoding="ascii") as fh:
                fh.write(junk)
            with self.assertRaises(T.TxnError, msg=repr(junk)):
                T.apply_transaction(self.root, {"a.txt": "3"}, os.path.join(self._td.name, "s3"))

    def test_recover_sweeps_stage_leftovers(self):
        T.apply_transaction(self.root, {"d/a.txt": "1"}, snap := os.path.join(self._td.name, "s"))
        left = os.path.join(self.root, "d", "tmpabc123.stage")
        keep = os.path.join(self.root, "d", "notes.stage")
        for p in (left, keep):
            with open(p, "w", encoding="utf-8") as fh:
                fh.write("x")
        T.recover(self.root, snap)
        self.assertFalse(os.path.exists(left))
        self.assertTrue(os.path.exists(keep))


if __name__ == "__main__":
    unittest.main()
