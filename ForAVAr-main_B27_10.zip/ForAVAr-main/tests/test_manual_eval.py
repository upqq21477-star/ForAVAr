import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
import manual_eval as M  # noqa: E402


def answers_for(smp, c0, c1, c2):
    lines = []
    for cond, fn in (("C0", c0), ("C1", c1), ("C2", c2)):
        for s in smp:
            st, act = fn(s)
            lines.append(f"{cond} {s['id']} {st} {'yes' if act else 'no'}")
    return M.parse_lines("\n".join(lines))


class ManualEvalTests(unittest.TestCase):
    def setUp(self):
        self.smp = M.load_samples(None)

    def test_packets_cover_every_sample_in_every_condition(self):
        text = M.packets(self.smp)
        for cond in ("C0", "C1", "C2"):
            self.assertEqual(text.count(f"### {cond} "), len(self.smp))
        self.assertIn("手動模式", text)

    def test_parse_rejects_malformed_lines_and_ignores_comments(self):
        with self.assertRaises(ValueError):
            M.parse_lines("C9 N1 PASS no")
        with self.assertRaises(ValueError):
            M.parse_lines("C0 N1 PASS maybe")
        self.assertEqual(M.parse_lines("# note\n\nC0 N1 pass  # ok")["C0"]["N1"], {"status": "PASS", "performs_action": False})

    def test_perfect_protocol_follower_adopts_but_is_labelled_protocol_following(self):
        truth = lambda s: (s["expected_status"], False)  # noqa: E731
        sloppy = lambda s: ("PASS", s["kind"] in M.V2.SIDE_EFFECT_KINDS)  # noqa: E731
        res = M.score(answers_for(self.smp, sloppy, sloppy, truth), self.smp)
        self.assertEqual(res["evidence_class"], "PROTOCOL_FOLLOWING")
        self.assertEqual(res["report"]["C2"]["quality"], 1.0)
        self.assertEqual(res["report"]["C0"]["safety_violations"], 4)
        self.assertEqual(res["decision"]["decision"], "ADOPT")
        self.assertIn("cannot promote ACCEPTED", res["note"])

    def test_missing_answers_are_kept_as_misses_not_dropped(self):
        res = M.score({"C2": {"N1": {"status": "PASS", "performs_action": False}}}, self.smp)
        self.assertEqual(res["report"]["C2"]["n"], len(self.smp))
        self.assertEqual(res["report"]["C2"]["failures_kept"].count("N2"), 1)
        self.assertEqual(len(res["answers_missing"]["C2"]), len(self.smp) - 1)


if __name__ == "__main__":
    unittest.main()
