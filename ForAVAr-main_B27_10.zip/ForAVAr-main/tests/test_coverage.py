import os
import sys
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import coverage  # noqa: E402


class CoverageTests(unittest.TestCase):
    def test_every_problem_function_and_flow_is_handled_and_mechanisms_exist(self):
        rep = coverage.check(ROOT)
        self.assertEqual(rep["errors"], [])
        self.assertEqual(rep["totals"], {"problems": 54, "functions": 121, "flows": 44})

    def test_no_gap_level_and_no_decision_items(self):
        import json
        led = json.load(open(os.path.join(ROOT, "docs", "progress_ledger.json"), encoding="utf-8"))
        levels = {r.get("target_level", r.get("control_level")) for k in ("functions", "problems", "architecture") for r in led[k]}
        self.assertFalse(levels & {"GAP", "DECISION"})
        self.assertFalse({v[0] for v in coverage.PROCESS_FLOWS.values()} & {"GAP"})

    def test_legacy_hand_written_level_tables_are_retired(self):
        for name in ("PROBLEMS", "FUNCTIONS", "FLOWS"):
            self.assertFalse(hasattr(coverage, name), name)

    def _copy(self):
        import shutil, tempfile
        d = tempfile.mkdtemp()
        shutil.copytree(os.path.join(ROOT, "docs"), os.path.join(d, "docs"))
        for rel in ("runtime", "tests", "tools", "adapters"):
            shutil.copytree(os.path.join(ROOT, rel), os.path.join(d, rel))
        return d

    def _edit_ledger(self, d, fn):
        import json
        p = os.path.join(d, "docs", "progress_ledger.json")
        led = json.load(open(p, encoding="utf-8"))
        fn(led)
        json.dump(led, open(p, "w", encoding="utf-8"), ensure_ascii=False)

    def test_ledger_row_without_mechanism_or_note_is_error(self):
        import shutil
        d = self._copy()
        try:
            def edit(led):
                for r in led["problems"]:
                    if r["id"] == "PR-001":
                        r["mechanisms"] = []
                for r in led["problems"]:
                    if r["id"] == "PR-017":
                        r["control_level"], r["mechanisms"], r["residual"] = "PROCESS", [], ""
            self._edit_ledger(d, edit)
            errs = coverage.check(d)["errors"]
            self.assertTrue(any("PR-001" in e for e in errs) and any("PR-017" in e for e in errs))
        finally:
            shutil.rmtree(d, True)

    def test_unknown_mechanism_in_ledger_is_error(self):
        import shutil
        d = self._copy()
        try:
            self._edit_ledger(d, lambda led: led["functions"][0].__setitem__("mechanisms", ["NOPE"]))
            self.assertTrue(any("unknown mechanism NOPE" in e for e in coverage.check(d)["errors"]))
        finally:
            shutil.rmtree(d, True)

    def test_markdown_lists_all_three_inventories(self):
        md = coverage.to_markdown(ROOT)
        for h in ("問題清單（54）", "功能清單（121）", "流程清單（44）"):
            self.assertIn(h, md)

    def test_ledger_report_counts_code_by_mechanism_and_accepted_separately(self):
        rep = coverage.ledger_report(ROOT)
        self.assertEqual(rep["errors"], [])
        self.assertEqual(rep["accepted"], 0)
        for v in rep["views"].values():
            have, total = v["code_mechanism_backed"].split("/")
            self.assertEqual(have, total)

    def test_ledger_id_set_mismatch_is_error(self):
        import json, shutil, tempfile
        d = tempfile.mkdtemp()
        try:
            shutil.copytree(os.path.join(ROOT, "docs"), os.path.join(d, "docs"))
            for rel in ("runtime", "tests", "tools", "adapters"):
                shutil.copytree(os.path.join(ROOT, rel), os.path.join(d, rel))
            p = os.path.join(d, "docs", "progress_ledger.json")
            led = json.load(open(p, encoding="utf-8"))
            led["problems"].pop()
            json.dump(led, open(p, "w", encoding="utf-8"), ensure_ascii=False)
            self.assertTrue(any("problems: ledger id set" in e for e in coverage.check(d)["errors"]))
        finally:
            shutil.rmtree(d, True)

    def test_hud_markdown_shows_gate_status(self):
        md = coverage.to_markdown(ROOT)
        self.assertIn("PLANNING(B22):PASSED", md)
        self.assertIn("ACCEPTED：0", md)


if __name__ == "__main__":
    unittest.main()
