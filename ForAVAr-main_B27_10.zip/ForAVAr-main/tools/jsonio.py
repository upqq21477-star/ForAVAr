"""Safe edits for docs/*.json (rule: never patch these files with text replacement).

Each docs file keeps its own layout (indent / trailing newline). ``load`` detects it and refuses files that do not round-trip
exactly, so a save never silently reformats a file. Stdlib only; tools layer.

  python tools/jsonio.py get FILE POINTER
  python tools/jsonio.py set FILE POINTER JSON_VALUE      (replace an existing value or add a key)
  python tools/jsonio.py append FILE POINTER JSON_VALUE   (append to an existing list)
POINTER is an RFC 6901 pointer, e.g. /maturity/runtime~1common.py ("" or "/" = whole document).
"""
from __future__ import annotations

import json
import sys
from typing import Any

INDENTS = (None, 0, 1, 2, 4)


def _dump(data: Any, indent: int | None, nl: bool) -> str:
    return json.dumps(data, ensure_ascii=False, indent=indent) + ("\n" if nl else "")


def load(path: str) -> tuple[Any, dict[str, Any]]:
    with open(path, encoding="utf-8") as fh:
        text = fh.read()
    data = json.loads(text)
    for indent in INDENTS:
        for nl in (True, False):
            if _dump(data, indent, nl) == text:
                return data, {"indent": indent, "nl": nl}
    raise ValueError(f"{path}: layout is not reproducible by json.dumps; refusing to edit (would reformat the file)")


def save(path: str, data: Any, fmt: dict[str, Any]) -> None:
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(_dump(data, fmt["indent"], fmt["nl"]))


def _parts(pointer: str) -> list[str]:
    if pointer in ("", "/"):
        return []
    if not pointer.startswith("/"):
        raise ValueError(f"bad pointer {pointer!r}")
    return [p.replace("~1", "/").replace("~0", "~") for p in pointer[1:].split("/")]


def _walk(doc: Any, parts: list[str]) -> Any:
    for p in parts:
        doc = doc[int(p)] if isinstance(doc, list) else doc[p]
    return doc


def get(path: str, pointer: str) -> Any:
    return _walk(load(path)[0], _parts(pointer))


def set_value(path: str, pointer: str, value: Any) -> None:
    data, fmt = load(path)
    parts = _parts(pointer)
    if not parts:
        data = value
    else:
        parent = _walk(data, parts[:-1])
        if isinstance(parent, list):
            parent[int(parts[-1])] = value
        else:
            parent[parts[-1]] = value
    save(path, data, fmt)


def append(path: str, pointer: str, value: Any) -> None:
    data, fmt = load(path)
    target = _walk(data, _parts(pointer))
    if not isinstance(target, list):
        raise ValueError(f"{pointer} is not a list")
    target.append(value)
    save(path, data, fmt)


if __name__ == "__main__":
    a = sys.argv[1:]
    try:
        if len(a) == 3 and a[0] == "get":
            print(json.dumps(get(a[1], a[2]), ensure_ascii=False, indent=2))
        elif len(a) == 4 and a[0] == "set":
            set_value(a[1], a[2], json.loads(a[3]))
        elif len(a) == 4 and a[0] == "append":
            append(a[1], a[2], json.loads(a[3]))
        else:
            sys.exit(__doc__)
    except (OSError, ValueError, KeyError, IndexError) as exc:
        sys.exit(f"jsonio: {exc}")
