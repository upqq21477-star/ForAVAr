"""Derived bookkeeping (LT-10): facts that can be read from files are computed, not hand-maintained.

Derived here:
  README          RUNTIME / ADAPTERS / TESTS / TOOLS lists   <- files on disk (existing order kept, new files appended sorted)
  ledger          counts.tests_total / counts.test_files  <- AST count of unittest methods (not in the authority doc blueprint, CL-026)
  ledger          counts block                                <- ledger rows
  features.json   blast_ceiling rows for files that have none <- closure_report impact (existing ceilings are never raised)
Not derived (judgement stays manual): ledger rows, mechanism rows in docs/features.json, index routes, handoff text.
The test total is counted, not executed: tools/standard_verify.py is what runs the tests.

  python tools/sync_docs.py [ROOT]            check; exit 1 and list drift
  python tools/sync_docs.py [ROOT] --write    apply (JSON via tools/jsonio.py, README block rewritten in place)
"""
from __future__ import annotations

import ast
import collections
import json
import os
import re
import sys
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import jsonio  # noqa: E402

README_KEYS = (("RUNTIME", "runtime", (".py",)), ("ADAPTERS", "adapters", (".py",)), ("TESTS", "tests", (".py",)),
               ("TOOLS", "tools", (".py", ".json")))
BLOCK = re.compile(r"```json\n(\{.*?\n\})\n```", re.S)
FEATURES = "docs/features.json"


def _files(root: str, folder: str, exts: tuple[str, ...]) -> list[str]:
    d = os.path.join(root, folder)
    names = sorted(n for n in os.listdir(d) if n.endswith(exts) and not n.startswith("__")) if os.path.isdir(d) else []
    return [f"{folder}/{n}" for n in names]


def count_tests(root: str) -> tuple[int, int]:
    """(test files, test methods) — unittest methods named test_* inside classes, by AST."""
    td = os.path.join(root, "tests")
    files = [n for n in sorted(os.listdir(td)) if re.fullmatch(r"test_\w+\.py", n)] if os.path.isdir(td) else []
    total = 0
    for n in files:
        with open(os.path.join(td, n), encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        total += sum(1 for c in ast.walk(tree) if isinstance(c, ast.ClassDef)
                     for f in c.body if isinstance(f, ast.FunctionDef) and f.name.startswith("test_"))
    return len(files), total


def ledger_counts(led: dict[str, Any]) -> dict[str, Any]:
    rows = lambda k: led.get(k, [])  # noqa: E731
    cnt = lambda k, f: dict(collections.Counter(x.get(f) for x in rows(k)))  # noqa: E731
    return {"functions": len(rows("functions")), "problems": len(rows("problems")), "architecture": len(rows("architecture")),
            "function_ruling": cnt("functions", "ruling"), "function_target_level": cnt("functions", "target_level"),
            "function_status": cnt("functions", "status"), "problem_status": cnt("problems", "status")}


def _merge(old: list[str], disk: list[str]) -> list[str]:
    keep = [x for x in old if x in disk]
    return keep + [x for x in disk if x not in keep]


def _render(block: dict[str, Any]) -> str:
    return "{\n" + ",\n".join(f"  {json.dumps(k)}: {json.dumps(v, ensure_ascii=False)}" for k, v in block.items()) + "\n}"


def _readme(root: str) -> tuple[str, dict[str, Any] | None]:
    with open(os.path.join(root, "README.md"), encoding="utf-8") as fh:
        text = fh.read()
    m = BLOCK.search(text)
    return text, (json.loads(m.group(1)) if m else None)


def derive(root: str) -> dict[str, Any]:
    """Everything derivable, as the value each target should hold."""
    text, block = _readme(root)
    block = dict(block or {})
    for key, folder, exts in README_KEYS:
        block[key] = _merge(list(block.get(key, [])), _files(root, folder, exts))
    n_files, n_tests = count_tests(root)
    led, _ = jsonio.load(os.path.join(root, "docs", "progress_ledger.json"))
    return {"readme": block, "test_files": n_files, "tests_total": n_tests, "ledger_counts": {**ledger_counts(led), "tests_total": n_tests, "test_files": n_files}}


def drift(root: str) -> list[str]:
    d, out = derive(root), []
    text, block = _readme(root)
    if _render(d["readme"]) != _render(block or {}):
        out.append("README file lists differ from disk")
    led, _ = jsonio.load(os.path.join(root, "docs", "progress_ledger.json"))
    if any(led.get("counts", {}).get(k) != v for k, v in d["ledger_counts"].items()):
        out.append("ledger counts differ from rows")
    return out + [f"no blast ceiling for {f}" for f in missing_ceilings(root)]


def _tracked(root: str) -> list[str]:
    return [f for _, folder, _e in README_KEYS[:2] + README_KEYS[3:] for f in _files(root, folder, (".py",))]


def missing_ceilings(root: str) -> list[str]:
    feats, _ = jsonio.load(os.path.join(root, FEATURES))
    return [f for f in _tracked(root) if f not in feats.get("blast_ceiling", {})]


def blast_all(root: str, paths: list[str]) -> dict[str, dict[str, int]]:
    """{path: {modules, tests}} = transitive importers (same definition as closure_report impact), one import-graph pass."""
    from importgraph import import_graph
    rev: dict[str, set[str]] = {}
    for src, deps in import_graph(root).items():
        for dep in deps:
            rev.setdefault(dep, set()).add(src)
    out = {}
    for p in paths:
        seen, todo = set(), [p]
        while todo:
            for up in rev.get(todo.pop(), ()):
                if up not in seen and up != p:
                    seen.add(up)
                    todo.append(up)
        out[p] = {"modules": len(seen), "tests": sum(1 for s in seen if s.startswith("tests/"))}
    return out


def blast_now(root: str, path: str) -> dict[str, int]:
    return blast_all(root, [path])[path]


def blast_over(root: str) -> list[str]:
    """Files whose current blast radius exceeds the recorded ceiling (a decision, never auto-fixed)."""
    feats, _ = jsonio.load(os.path.join(root, FEATURES))
    out = []
    caps = {f: c for f, c in sorted(feats.get("blast_ceiling", {}).items()) if os.path.exists(os.path.join(root, f))}
    nows = blast_all(root, list(caps))
    for f, cap in caps.items():
        now = nows[f]
        if now["modules"] > cap["modules"] or now["tests"] > cap["tests"]:
            out.append(f"{f}: blast {now} exceeds ceiling {cap}")
    return out


def write(root: str) -> list[str]:
    d, changed = derive(root), []
    text, block = _readme(root)
    if _render(d["readme"]) != _render(block or {}):
        new = BLOCK.sub(lambda _m: "```json\n" + _render(d["readme"]) + "\n```", text, count=1)
        with open(os.path.join(root, "README.md"), "w", encoding="utf-8") as fh:
            fh.write(new)
        changed.append("README.md")
    led_path = os.path.join(root, "docs", "progress_ledger.json")
    led, fmt = jsonio.load(led_path)
    if any(led.get("counts", {}).get(k) != v for k, v in d["ledger_counts"].items()):
        led.setdefault("counts", {}).update(d["ledger_counts"])
        jsonio.save(led_path, led, fmt)
        changed.append("docs/progress_ledger.json")
    miss = missing_ceilings(root)
    if miss:
        f_path = os.path.join(root, FEATURES)
        feats, fmt = jsonio.load(f_path)
        for f, v in blast_all(root, miss).items():
            feats.setdefault("blast_ceiling", {})[f] = v
        jsonio.save(f_path, feats, fmt)
        changed.append(FEATURES)
    return changed


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    repo = args[0] if args else os.path.join(HERE, "..")
    if "--write" in sys.argv:
        print("\n".join(write(repo)) or "nothing to change")
    else:
        found = drift(repo)
        print("\n".join(found) or "OK")
        sys.exit(1 if found else 0)
