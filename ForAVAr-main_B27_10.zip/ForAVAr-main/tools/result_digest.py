"""Compact digest of final_test_run result files (F2c/F3 reader). Reads only; never scores, decides or promotes anything.

Why: a result file carries every per-sample outcome and can be large; the reviewer needs the decision, the failures, the per-kind/axis
rows, the report-only metrics and a list of reasons NOT to trust the file (simulation, stale fingerprint, freeze mismatch).
Usage: python tools/result_digest.py RESULT.json [RESULT.json ...] [--freeze-file data/freeze_B26.json] [--json]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import Counter
from collections.abc import Mapping
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import final_test_samples_v2 as V2  # noqa: E402


def _base(sid: str) -> str:
    return sid.split("#r")[0]


def digest(res: Mapping[str, Any], freeze_rec: Mapping[str, Any] | None = None) -> dict[str, Any]:
    warn: list[str] = []
    if res.get("evidence_class") != "REAL_RUN_UNREVIEWED":
        warn.append(f"evidence_class={res.get('evidence_class')}: not a real run, evidence for nothing")
    if res.get("samples") == "v2" and res.get("samples_fingerprint") != V2.fingerprint_v2():
        warn.append(f"samples_fingerprint {res.get('samples_fingerprint')} != current v2 {V2.fingerprint_v2()}: stale result")
    cur = (res.get("freeze") or {}).get("combined")
    if freeze_rec is not None and cur != (freeze_rec.get("freeze") or {}).get("combined"):
        warn.append(f"freeze combined {cur} != freeze record {(freeze_rec.get('freeze') or {}).get('combined')}: code changed after freeze")
    if not res.get("backend_stats"):
        warn.append("no backend_stats (cannot check call counts)")
    if res.get("not_covered"):
        warn.append(f"not_covered: {res['not_covered']}")
    if int(res.get("repeats") or 1) < 2:
        warn.append("repeats<2: stability not measured")
    if (res.get("independence_check") or "").startswith("SAME_MODEL"):
        warn.append("confirmation generator is the same model as the one under test")
    rep = res.get("report", {})
    fails: dict[str, dict[str, int]] = {}
    for c, r in rep.items():
        cnt = Counter(_base(i) for i in r.get("failures_kept", []))
        fails[c] = dict(sorted(cnt.items()))
    weak: dict[str, dict[str, str]] = {}
    for c, b in (res.get("breakdown") or {}).items():
        rows = {k: f"{v['hit']}/{v['n']}" + (f" fp{v['false_pass']}" if v["false_pass"] else "") + (f" sv{v['safety_violations']}" if v["safety_violations"] else "")
                for k, v in b.get("by_kind", {}).items() if v["hit"] < v["n"] or v["false_pass"] or v["safety_violations"]}
        if rows:
            weak[c] = rows
    ax = {k: v for k, v in (res.get("axis_comparison") or {}).items() if k != "outcomes"}
    return {"backend": res.get("backend"), "samples": res.get("samples"), "repeats": res.get("repeats"), "rubric_fingerprint": res.get("rubric_fingerprint"),
            "evidence_class": res.get("evidence_class"), "decision": res.get("decision"),
            "report": {c: {k: r.get(k) for k in ("n", "quality", "false_pass", "safety_violations", "cost")} for c, r in rep.items()},
            "failed_samples": fails, "weak_kinds": weak, "axis_comparison": ax, "closed_loop": res.get("closed_loop"), "stability": res.get("stability"),
            "backend_stats": res.get("backend_stats"), "warnings": warn}


def render(d: Mapping[str, Any]) -> str:
    out = [f"== {d['backend']} samples={d['samples']} x{d['repeats']} class={d['evidence_class']}", f"decision: {json.dumps(d['decision'], ensure_ascii=False)}"]
    for c, r in d["report"].items():
        out.append(f"{c}: n={r['n']} quality={r['quality']:.3f} false_pass={r['false_pass']} safety={r['safety_violations']} cost={r['cost']:.2f}")
    for title, key in (("failed (id: runs)", "failed_samples"), ("weak kinds (hit/n)", "weak_kinds")):
        for c, v in d[key].items():
            if v:
                out.append(f"{title} {c}: {json.dumps(v, ensure_ascii=False)}")
    out.append(f"axis_comparison: {json.dumps(d['axis_comparison'], ensure_ascii=False)}")
    out.append(f"closed_loop: {json.dumps(d['closed_loop'], ensure_ascii=False)}")
    out.append(f"stability: {json.dumps(d['stability'], ensure_ascii=False)}")
    out.append(f"backend_stats: {json.dumps(d['backend_stats'], ensure_ascii=False)}")
    out += [f"WARNING: {w}" for w in d["warnings"]] or ["warnings: none"]
    return "\n".join(out)


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("files", nargs="+")
    ap.add_argument("--freeze-file")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    fr = None
    if a.freeze_file:
        with open(a.freeze_file, encoding="utf-8") as fh:
            fr = json.load(fh)
    for p in a.files:
        with open(p, encoding="utf-8") as fh:
            d = digest(json.load(fh), fr)
        print(json.dumps(d, ensure_ascii=False, indent=1) if a.json else render(d))
