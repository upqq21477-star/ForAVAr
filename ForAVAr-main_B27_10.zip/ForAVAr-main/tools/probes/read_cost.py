"""Probe: how much a reader must read. Estimated tokens (CJK character = 1, other text = 1 per 3.6 characters; not a tokenizer).

Contract: ``python tools/probes/read_cost.py ROOT`` prints one JSON object {metric: number}; ROOT is never written.
  scope_tokens_recent_mean  mean, over the last 5 change_log entries that have replan.scope, of the whole-file read cost of that scope
                            (the naive upper bound of one update; actual reads are lower when tools/brief.py is used)
  start_here_tokens         whole-file read cost of the files index.json start_here lists
  l0_tokens                 size of the tools/brief.py L0 output (absent when the root has no brief.py)
  docs_tokens               all docs/*.json together
Missing or unreadable inputs give fewer keys, never an error: a candidate that removes an input is judged on what remains.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys

CJK = re.compile(r"[\u3000-\u9fff\uff00-\uffef]")
RECENT = 5


def est(text: str) -> int:
    n = len(CJK.findall(text))
    return n + int((len(text) - n) / 3.6)


def _tokens(root: str, rel: str) -> int | None:
    try:
        with open(os.path.join(root, rel), encoding="utf-8", errors="replace") as fh:
            return est(fh.read())
    except OSError:
        return None


def _json(root: str, rel: str):
    try:
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def measure(root: str) -> dict[str, float]:
    out: dict[str, float] = {}
    cl = _json(root, "docs/change_log.json")
    if isinstance(cl, dict):
        rows = []
        for e in cl.get("entries", []):
            scope = (e.get("replan") or {}).get("scope") if isinstance(e, dict) else None
            if isinstance(scope, list) and scope:
                rows.append(sum(_tokens(root, p) or 0 for p in scope if isinstance(p, str)))
        if rows:
            out["scope_tokens_recent_mean"] = round(sum(rows[-RECENT:]) / len(rows[-RECENT:]), 1)
    ix = _json(root, "docs/index.json")
    if isinstance(ix, dict) and isinstance(ix.get("start_here"), list):
        out["start_here_tokens"] = float(sum(_tokens(root, p) or 0 for p in ix["start_here"] if isinstance(p, str)))
    d = os.path.join(root, "docs")
    if os.path.isdir(d):
        out["docs_tokens"] = float(sum(_tokens(root, f"docs/{n}") or 0 for n in sorted(os.listdir(d)) if n.endswith(".json")))
    brief = os.path.join(root, "tools", "brief.py")
    if os.path.isfile(brief):
        r = subprocess.run([sys.executable, brief, "--root", root, "--budget", "100000"], capture_output=True, text=True, encoding="utf-8")
        if r.returncode == 0:
            out["l0_tokens"] = float(est(r.stdout))
    return out


if __name__ == "__main__":
    print(json.dumps(measure(sys.argv[1] if len(sys.argv) > 1 else "."), sort_keys=True))
