"""Probe: how long the structural checker takes (a proxy for the per-update verification cost).

Contract: ``python tools/probes/verify_cost.py ROOT`` prints one JSON object {metric: number}; ROOT is never written.
check_seconds = best of 3 fresh-process runs of tools/check_consistency.py (fresh process = cold caches); lower is better.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time


def measure(root: str, runs: int = 3) -> dict[str, float]:
    script = os.path.join(root, "tools", "check_consistency.py")
    if not os.path.isfile(script):
        return {}
    best = None
    for _ in range(runs):
        t = time.time()
        subprocess.run([sys.executable, script, root], cwd=root, capture_output=True, text=True)
        dt = time.time() - t
        best = dt if best is None else min(best, dt)
    return {"check_seconds": round(best or 0.0, 3)}


if __name__ == "__main__":
    print(json.dumps(measure(sys.argv[1] if len(sys.argv) > 1 else "."), sort_keys=True))
