"""Probe: update-cost metrics (replaceable plug-in for tools/candidate_gate.py).

Contract: ``python tools/probes/update_cost.py ROOT`` prints one JSON object {metric: number}. Read-only; stdlib only.
Metrics are properties of the repo as a file tree plus its own change_log, so a candidate is judged on the tree it would produce.
"""
from __future__ import annotations

import json
import os
import re
import sys
from typing import Any

SKIP = {".git", "__pycache__", "node_modules"}
BIG_DOCS = ("blueprint", "progress_ledger", "capability_registry", "index")
TRIO = {"docs/blueprint.json", "docs/change_log.json", "docs/progress_ledger.json"}
FP = re.compile(r"combined[^0-9a-fA-F\n]{0,8}([0-9a-f]{16})")


def _bytes(root: str, sub: str) -> int:
    total = 0
    for d, dirs, files in os.walk(os.path.join(root, sub)):
        dirs[:] = [x for x in dirs if x not in SKIP]
        total += sum(os.path.getsize(os.path.join(d, f)) for f in files if not f.endswith(".pyc"))
    return total


def _json(root: str, rel: str) -> Any:
    try:
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _tests(root: str) -> int:
    n = 0
    tdir = os.path.join(root, "tests")
    for f in os.listdir(tdir) if os.path.isdir(tdir) else ():
        if f.endswith(".py"):
            with open(os.path.join(tdir, f), encoding="utf-8") as fh:
                n += len(re.findall(r"^\s+def test_", fh.read(), re.M))
    return n


def measure(root: str) -> dict[str, float]:
    m: dict[str, float] = {"docs_bytes": _bytes(root, "docs"), "tools_bytes": _bytes(root, "tools"),
                           "runtime_bytes": _bytes(root, "runtime") + _bytes(root, "adapters"),
                           "tests_bytes": _bytes(root, "tests"), "tests_count": _tests(root)}
    for name in BIG_DOCS:  # where the reading cost sits: bytes per top-level section
        d = _json(root, f"docs/{name}.json")
        if isinstance(d, dict):
            for k, v in d.items():
                size = len(json.dumps(v, ensure_ascii=False).encode("utf-8"))
                if size >= 8000:
                    m[f"{name}.{k}_bytes"] = size
    log = _json(root, "docs/change_log.json")
    ents = log.get("entries", []) if isinstance(log, dict) else []
    scopes = [sorted(set((e.get("replan") or {}).get("scope") or [])) for e in ents]
    scopes = [s for s in scopes if s]
    if ents:
        last = ents[-5:]
        m["changelog_entries"] = len(ents)
        m["changelog_recent_mean_bytes"] = sum(len(json.dumps(e, ensure_ascii=False).encode("utf-8")) for e in last) / len(last)
    if scopes:
        m["mean_files_per_update"] = sum(len(s) for s in scopes) / len(scopes)
        m["trio_ratio"] = sum(1 for s in scopes if TRIO <= set(s)) / len(scopes)
        m["doc_file_share"] = sum(1 for s in scopes for f in s if not f.startswith(("tests/", "runtime/", "adapters/", "tools/"))) / sum(len(s) for s in scopes)
    # drift: a combined fingerprint literal in a current doc that differs from the newest change_log entry's claim
    truth = None
    for e in reversed(ents):  # newest entry that states a combined fingerprint; a newer entry without one must not blind the check
        claims = FP.findall(json.dumps(e, ensure_ascii=False))
        if claims:
            truth = claims[-1]
            break
    m["fingerprint_truth_found"] = 1 if truth else 0
    drift = 0
    if truth:
        for rel in ("docs/progress_ledger.json", "docs/FINAL_TEST_RUNBOOK.md", "README.md", "docs/features.json", "docs/blueprint.json"):
            try:
                with open(os.path.join(root, rel), encoding="utf-8") as fh:
                    drift += sum(1 for x in FP.findall(fh.read()) if x != truth)
            except OSError:
                pass
    m["fingerprint_drift"] = drift
    return m


if __name__ == "__main__":
    print(json.dumps(measure(sys.argv[1] if len(sys.argv) > 1 else "."), sort_keys=True))
