"""Probe: replay a minimal update (add one trivial test file) in a scratch copy and count what the repo forces you to touch.

Contract: ``python tools/probes/replay_cost.py ROOT`` prints one JSON object {metric: number}; ROOT is never written.
authority files changed = docs/<name> listed in tools/gate_policy.json authority_docs (these need owner authorization to apply).
"""
from __future__ import annotations

import filecmp
import json
import os
import shutil
import subprocess
import sys
import tempfile

SKIP = {".git", "__pycache__", "node_modules"}
TEST = "import unittest\n\n\nclass Replay(unittest.TestCase):\n    def test_replay(self):\n        self.assertTrue(True)\n"


def _authority(root: str) -> set[str]:
    try:
        with open(os.path.join(root, "tools", "gate_policy.json"), encoding="utf-8") as fh:
            return set(json.load(fh).get("authority_docs", []))
    except (OSError, ValueError):
        return {"blueprint.json", "operating_contract.json", "capability_registry.json", "problem_register.json", "index.json"}


def measure(root: str) -> dict[str, float]:
    if not os.path.isfile(os.path.join(root, "tools", "sync_docs.py")):
        return {}
    tmp = tempfile.mkdtemp(prefix="replay_")
    try:
        work = os.path.join(tmp, "r")
        shutil.copytree(root, work, ignore=shutil.ignore_patterns(*SKIP, "*.pyc"))
        with open(os.path.join(work, "tests", "test_zz_replay.py"), "w", encoding="utf-8") as fh:
            fh.write(TEST)
        subprocess.run([sys.executable, "tools/sync_docs.py", work, "--write"], cwd=work, capture_output=True, text=True)
        changed = []
        for d, dirs, files in os.walk(work):
            dirs[:] = [x for x in dirs if x not in SKIP]
            for f in files:
                rel = os.path.relpath(os.path.join(d, f), work)
                old = os.path.join(root, rel)
                if os.path.isfile(old) and not filecmp.cmp(old, os.path.join(work, rel), shallow=False):
                    changed.append(rel.replace(os.sep, "/"))
        auth = _authority(root)
        return {"files_changed_on_add_test": len(changed),
                "authority_files_changed_on_add_test": sum(1 for c in changed if c.startswith("docs/") and os.path.basename(c) in auth)}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    print(json.dumps(measure(sys.argv[1] if len(sys.argv) > 1 else "."), sort_keys=True))
