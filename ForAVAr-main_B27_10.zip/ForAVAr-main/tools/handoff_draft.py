"""HANDOFF skeleton (LT-03): derived from the repo, no reasons written, nothing invented.

Sections are fixed: 本次更改／目前進度／後續規劃／待辦／需你核對. Each is filled from a named source; when a source is
empty the section says so with the source pointer (never left blank) so the human can see what to write.
  本次更改   latest change_log entries (``--entries N``, default 1): id, ruling, first sentence of ``change``; plus the file
             diff against ``--prev ROOT`` when given
  目前進度   ledger.roadmap.program.batches (id, status)
  後續規劃   ledger.roadmap.next
  待辦       batches not DONE + open_decisions in OPEN／DEFERRED
  需你核對   ``not_this`` of the entries shown
Prints Markdown; the HANDOFF itself stays outside the repo (a person pastes and completes it).

  python tools/handoff_draft.py [ROOT] [--batch B26.2] [--entries 1] [--prev OLD_ROOT]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from typing import Any

SECTIONS = ("本次更改", "目前進度", "後續規劃", "待辦", "需你核對")
SKIP_DIRS = {".git", "__pycache__", "node_modules"}


def _json(root: str, rel: str) -> Any:
    with open(os.path.join(root, rel), encoding="utf-8") as fh:
        return json.load(fh)


def _first_sentence(text: str, cap: int = 160) -> str:
    cut = min([i for i in (text.find(s) for s in ("。", ". ", "\n")) if i >= 0] or [len(text)])
    return text[:cut + 1].strip()[:cap]


def tree_hashes(root: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
        for f in sorted(files):
            p = os.path.join(d, f)
            with open(p, "rb") as fh:
                out[os.path.relpath(p, root).replace(os.sep, "/")] = hashlib.sha256(fh.read()).hexdigest()[:16]
    return out


def diff_files(old_root: str, new_root: str) -> dict[str, list[str]]:
    a, b = tree_hashes(old_root), tree_hashes(new_root)
    return {"added": sorted(set(b) - set(a)), "removed": sorted(set(a) - set(b)),
            "changed": sorted(k for k in set(a) & set(b) if a[k] != b[k])}


def build(root: str, batch: str = "", entries: int = 1, prev: str | None = None) -> str:
    log = _json(root, "docs/change_log.json")["entries"]
    ledger = _json(root, "docs/progress_ledger.json")
    program = ledger["roadmap"]["program"]
    shown = log[-max(entries, 1):]
    lines = [f"# {batch or 'BATCH'} forAVAr 交接（草稿：由 tools/handoff_draft.py 產生，理由與判斷由人補）", ""]

    lines += ["## 本次更改"]
    for e in shown:
        lines.append(f"- {e['id']}（{e.get('ruling')}／E4={e.get('echelon_check', {}).get('E4', {}).get('result', 'n/a')}）：{_first_sentence(e.get('change', ''))}")
    if prev:
        d = diff_files(prev, root)
        for k, label in (("changed", "改"), ("added", "增"), ("removed", "刪")):
            lines.append(f"- 檔案{label}（{len(d[k])}）：" + (", ".join(d[k]) if d[k] else "無"))
    elif not shown:
        lines.append("- （來源無資料：docs/change_log.json entries）")

    lines += ["", "## 目前進度"]
    batches = program.get("batches", [])
    lines += [f"- {b['id']}：{b.get('status')}" for b in batches] or ["- （來源無資料：ledger.roadmap.program.batches）"]

    lines += ["", "## 後續規劃", f"- {ledger['roadmap'].get('next') or '（來源無資料：ledger.roadmap.next）'}"]

    todo = [f"- {b['id']}：{b.get('status')}" for b in batches if not str(b.get("status", "")).startswith("DONE")]
    todo += [f"- {d['id']}（{d['state']}）：{d['item']}" for d in ledger.get("open_decisions", []) if d.get("state") in {"OPEN", "DEFERRED"}]
    lines += ["", "## 待辦"] + (todo or ["- （來源無資料：無未完成批次與未決項）"])

    check: list[str] = []
    for e in shown:
        check += [f"- {e['id']}：{x}" for x in e.get("not_this", [])]
    lines += ["", "## 需你核對"] + (check or ["- （來源無資料：最新條目的 not_this）"])
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("root", nargs="?", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    ap.add_argument("--batch", default="")
    ap.add_argument("--entries", type=int, default=1)
    ap.add_argument("--prev")
    a = ap.parse_args(argv)
    try:
        sys.stdout.write(build(a.root, a.batch, a.entries, a.prev))
    except (OSError, KeyError, ValueError) as exc:
        sys.stderr.write(f"handoff_draft: cannot build ({type(exc).__name__}: {exc})\n")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
