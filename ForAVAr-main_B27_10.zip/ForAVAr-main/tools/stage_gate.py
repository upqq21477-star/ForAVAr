"""Stage-gate recorder (R1; closes P2-F30, PR-033). The only sanctioned writer of ledger ``stage_gates``.

Rules enforced (each rejection raises GateRejected and writes nothing):
  1. stages go in order PLANNING -> REALIZATION -> CLOSURE -> FINAL_TEST; a stage can only be recorded
     when every earlier stage is PASSED;
  2. PASSED needs a non-empty evidence text and reviewer; FINAL_TEST additionally needs independent=True;
  3. a PASSED stage is immutable (no re-recording);
  4. ledger integrity (check_consistency ``ledger_*`` checks) must be clean before recording;
  5. the write goes through release_txn (snapshot + full rollback on failure).
Usage: python tools/stage_gate.py STAGE STATUS --batch B23 --reviewer R --evidence "..." [--independent] [--retry-of B22]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections.abc import Callable
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "runtime"))
sys.path.insert(0, HERE)

import release_txn  # noqa: E402

STAGES = ("PLANNING", "REALIZATION", "CLOSURE", "FINAL_TEST")
WRITABLE = ("IN_PROGRESS", "PASSED", "FAILED")
LEDGER_REL = "docs/progress_ledger.json"
MIN_EVIDENCE_CHARS = 20


class GateRejected(ValueError):
    """Recording refused; the ledger is untouched."""


def _ledger_errors(root: str) -> list[str]:
    import check_consistency  # local import: keeps module import cheap and testable
    r = check_consistency.check(root)
    return [f"{f['check']}: {f['detail']}" for f in r["findings"] if f["level"] == "ERROR" and f["check"].startswith("ledger")]


def record_gate(root: str, stage: str, status: str, *, batch: str, reviewer: str = "", evidence: str = "",
                independent: bool = False, retry_of: str | None = None, snap_dir: str | None = None,
                ledger_check: Callable[[str], list[str]] | None = None,
                verify: Callable[[str], list[str]] | None = None) -> dict[str, Any]:
    if stage not in STAGES:
        raise GateRejected(f"unknown stage: {stage}")
    if status not in WRITABLE:
        raise GateRejected(f"status must be one of {WRITABLE}")
    if not isinstance(batch, str) or not batch.strip():
        raise GateRejected("batch is required")
    path = os.path.join(root, LEDGER_REL)
    with open(path, encoding="utf-8") as fh:
        ledger = json.load(fh)
    gates = ledger.get("stage_gates")
    if not isinstance(gates, list) or [g.get("stage") for g in gates] != list(STAGES):
        raise GateRejected("ledger stage_gates must list the four stages in order")
    idx = STAGES.index(stage)
    for prev in gates[:idx]:
        if prev.get("status") != "PASSED":
            raise GateRejected(f"{prev['stage']} is not PASSED; cannot record {stage}")
    entry = gates[idx]
    if entry.get("status") == "PASSED":
        raise GateRejected(f"{stage} is already PASSED (immutable)")
    if status == "PASSED":
        if len((evidence or "").strip()) < MIN_EVIDENCE_CHARS:
            raise GateRejected(f"PASSED needs evidence text of at least {MIN_EVIDENCE_CHARS} characters")
        if not (reviewer or "").strip():
            raise GateRejected("PASSED needs a reviewer")
        if stage == "FINAL_TEST" and not independent:
            raise GateRejected("FINAL_TEST PASSED needs an independent reviewer (independent=True)")
    problems = (ledger_check or _ledger_errors)(root)
    if problems:
        raise GateRejected("ledger integrity check failed: " + "; ".join(problems[:3]))
    new = {**entry, "stage": stage, "batch": batch, "status": status}
    if status == "PASSED":
        new.update(reviewer=reviewer.strip(), evidence=evidence.strip(), independent=bool(independent))
    elif status == "FAILED":
        new.update(reason=(evidence or "").strip(), next="redo the same stage in the next batch (retry_of)")
    if retry_of:
        new["retry_of"] = retry_of
    gates = list(gates)
    gates[idx] = new
    ledger["stage_gates"] = gates
    text = json.dumps(ledger, ensure_ascii=False, indent=0) + "\n"
    snap = snap_dir or os.path.join(root, ".foravar_snap", f"gate_{stage}_{batch}")
    report = release_txn.apply_transaction(root, {LEDGER_REL: text}, snap, authorized=True, verify=verify)
    if report["status"] != "COMMITTED":
        raise GateRejected(f"write rolled back: {report['problems']}")
    return {"stage": stage, "status": status, "batch": batch, "txn": report["status"]}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("stage")
    ap.add_argument("status")
    ap.add_argument("--batch", required=True)
    ap.add_argument("--reviewer", default="")
    ap.add_argument("--evidence", default="")
    ap.add_argument("--independent", action="store_true")
    ap.add_argument("--retry-of")
    ap.add_argument("--root", default=os.path.join(HERE, ".."))
    a = ap.parse_args(argv)
    try:
        print(json.dumps(record_gate(a.root, a.stage, a.status, batch=a.batch, reviewer=a.reviewer, evidence=a.evidence,
                                     independent=a.independent, retry_of=a.retry_of), ensure_ascii=False))
    except GateRejected as exc:
        print(f"REJECTED: {exc}")
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
