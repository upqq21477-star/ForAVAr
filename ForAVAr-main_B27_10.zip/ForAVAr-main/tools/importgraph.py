"""Static import graph of the repo (runtime/adapters/tools/tests), via ast. Shared primitive: check_consistency, closure_report and
sync_docs all read it from here, so none of them has to import another just to get the graph. Stdlib only; tools layer."""
from __future__ import annotations

import ast
import hashlib
import os

FOLDERS = ("runtime", "adapters", "tools", "tests")


_NAMES: dict[bytes, tuple[str, ...] | None] = {}  # sha of source -> imported names (pure function of the text, so a hit is always exact)


def _imported_names(src: str) -> tuple[str, ...] | None:
    """Names in every Import/ImportFrom of ``src`` (None = syntax error). Import is a statement, so only statements, handlers and
    match cases are visited: expression subtrees (most of the nodes) are never entered. Result is memoised by content hash."""
    key = hashlib.blake2b(src.encode("utf-8"), digest_size=16).digest()
    if key in _NAMES:
        return _NAMES[key]
    try:
        tree = ast.parse(src)
    except SyntaxError:
        _NAMES[key] = None
        return None
    names: list[str] = []
    stack: list[ast.AST] = [tree]
    while stack:
        node = stack.pop()
        if isinstance(node, ast.Import):
            names += [a.name for a in node.names]
        elif isinstance(node, ast.ImportFrom):
            names += [node.module or ""] + ([a.name for a in node.names] if node.level or not node.module else [])
        else:
            stack += [c for c in ast.iter_child_nodes(node) if isinstance(c, (ast.stmt, ast.ExceptHandler, ast.match_case))]
    _NAMES[key] = tuple(names)
    return _NAMES[key]


def import_graph(root: str) -> dict[str, set[str]]:
    """{'runtime/x.py': {'runtime/y.py', ...}} for local imports (relative, bare module, or runtime.X), via ast."""
    mods = {}
    for folder in FOLDERS:
        d = os.path.join(root, folder)
        for n in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if n.endswith(".py"):
                mods.setdefault(n[:-3], []).append(f"{folder}/{n}")
    graph: dict[str, set[str]] = {}
    for folder in FOLDERS:
        d = os.path.join(root, folder)
        for n in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if not n.endswith(".py"):
                continue
            try:
                with open(os.path.join(d, n), encoding="utf-8") as fh:
                    names = _imported_names(fh.read())
            except OSError:
                continue
            if names is None:
                continue
            deps: set[str] = set()
            for name in names:
                parts = name.split(".")
                stem = parts[1] if parts[0] in FOLDERS and len(parts) > 1 else parts[0]
                deps.update(m for m in mods.get(stem, []) if m != f"{folder}/{n}")
            graph[f"{folder}/{n}"] = deps
    return graph
