"""Overlap scan (LT-12): "does the system already have this?" as one fixed step before adding or changing a feature.

Searches every authority document (registry, problems, ledger rows, contract, blueprint, features table, index) by JSON pointer,
plus code identifiers (def/class/CONSTANT lines) and string-literal field names in runtime/adapters/tools, case-insensitive, any of the given words.
For each code file hit it also prints the blast radius (closure_report impact), so "reuse or extend" can be judged by cost.

  python tools/overlap.py WORD [WORD...] [--root ROOT] [--max N]
"""
from __future__ import annotations

import json
import os
import re
import sys
from typing import Any, Iterator

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DOCS = ("capability_registry.json", "problem_register.json", "progress_ledger.json", "operating_contract.json",
        "blueprint.json", "features.json", "index.json", "manual_card.json")
CODE_LINE = re.compile(r"^\s*(def |class |[A-Z][A-Z0-9_]+\s*[:=])")
QUOTED = re.compile(r"""(["'])[^"'\n]*\1""")  # string literals: field names such as "out_of_scope" are where real overlap hides
SKIP_KEYS = {"integrity_snapshot"}


def _leaves(node: Any, ptr: str = "") -> Iterator[tuple[str, str]]:
    if isinstance(node, dict):
        for k, v in node.items():
            if k not in SKIP_KEYS:
                yield from _leaves(v, f"{ptr}/{str(k).replace('~', '~0').replace('/', '~1')}")
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from _leaves(v, f"{ptr}/{i}")
    elif isinstance(node, str):
        yield ptr, node


def _snip(text: str, at: int) -> str:
    s = text[max(0, at - 40): at + 70].replace("\n", " ")
    return s


def scan(root: str, words: list[str], cap: int = 6) -> dict[str, list[str]]:
    """file -> hit lines ("<pointer or line no>: snippet"), at most ``cap`` per file (+ a '... N more' marker)."""
    ws = [w.lower() for w in words if w]
    hits: dict[str, list[str]] = {}

    def add(f: str, line: str) -> None:
        hits.setdefault(f, []).append(line)

    for name in DOCS:
        path = os.path.join(root, "docs", name)
        if not os.path.exists(path):
            continue
        with open(path, encoding="utf-8") as fh:
            doc = json.load(fh)
        for ptr, text in _leaves(doc):
            low = f"{ptr} {text}".lower()
            if any(w in low for w in ws):
                at = min((text.lower().find(w) for w in ws if w in text.lower()), default=0)
                add(f"docs/{name}", f"{ptr}: {_snip(text, max(at, 0))}")
    for folder in ("runtime", "adapters", "tools"):
        d = os.path.join(root, folder)
        for n in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if not n.endswith(".py"):
                continue
            with open(os.path.join(d, n), encoding="utf-8") as fh:
                for i, line in enumerate(fh, 1):
                    low = line.lower()
                    if not any(w in low for w in ws):
                        continue
                    if CODE_LINE.match(line) or any(w in q.group(0).lower() for q in QUOTED.finditer(line) for w in ws):
                        add(f"{folder}/{n}", f"L{i}: {line.strip()[:110]}")
    for f, rows in hits.items():
        if len(rows) > cap:
            hits[f] = rows[:cap] + [f"... {len(rows) - cap} more"]
    return hits


def blast(root: str, files: list[str]) -> dict[str, dict[str, int]]:
    from closure_report import impact
    return {f: impact(root, [f])["blast"] for f in files if f.endswith(".py")}


def main(argv: list[str]) -> int:
    root, cap, words, i = os.path.join(HERE, ".."), 6, [], 0
    while i < len(argv):
        if argv[i] == "--root":
            root, i = argv[i + 1], i + 2
        elif argv[i] == "--max":
            cap, i = int(argv[i + 1]), i + 2
        else:
            words.append(argv[i])
            i += 1
    if not words:
        sys.exit(__doc__)
    hits = scan(root, words, cap)
    for f in sorted(hits, key=lambda x: (not x.startswith("docs/"), x)):
        print(f"== {f}")
        print("\n".join(f"  {r}" for r in hits[f]))
    b = blast(root, [f for f in hits if not f.startswith("docs/")])
    if b:
        print("== blast (modules/tests/ledger_rows if you change the file)")
        for f, v in b.items():
            print(f"  {f}: {v['modules']}/{v['tests']}/{v['ledger_rows']}")
    if not hits:
        print("no overlap found")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
