"""Coverage view (R2/R5): problems, functions and flows -> how the system handles each.

Single source of level and status = docs/progress_ledger.json (PR-034). This file keeps only the MECH reader (table = docs/features.json)
(mechanism name -> source symbol + test file) and PROCESS_FLOWS (task-flow / build-stage rows that have no
ledger entry). Levels: CODE enforced by runtime code AND a named test; SLOT stage/adapter contract exists, effect
NOT_VERIFIED until FINAL_TEST; PROCESS handled by an operating procedure; DECISION owner item. GAP never allowed.
check() proves a mechanism exists and is tested, not that it is sufficient.
Usage: python tools/coverage.py [repo_root] [--md out.md]
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter
from typing import Any

FEATURES = "docs/features.json"  # mechanism table lives in data (B25.1f): add a feature = one JSON row, no code edit here


def mech_table(root: str) -> dict[str, tuple[str, str, str]]:
    """name -> (source file, symbol, test file), read from ``root``/docs/features.json."""
    try:
        with open(os.path.join(root, FEATURES), encoding="utf-8") as fh:
            rows = json.load(fh).get("mech", {})
    except (OSError, ValueError):
        return {}
    return {k: (v[0], v[1], v[2]) for k, v in rows.items() if isinstance(v, list) and len(v) == 3}


LEVELS = ("CODE", "SLOT", "PROCESS", "DECISION", "GAP")
NO_MECH_STATUS = ("MERGED", "DEFERRED")  # not realised here; no mechanism required
NOT_COUNTED = ("MERGED", "DEFERRED", "PLANNED")  # excluded from the CODE mechanism-backed count

PROCESS_FLOWS: dict[str, tuple[str, list[str], str]] = {
    'TASKFLOW:INTAKE': ('CODE', ['TASK'], ''),
    'TASKFLOW:AUTHORIZE': ('CODE', ['POL'], ''),
    'TASKFLOW:SELECT_SOP': ('SLOT', ['ROUTE', 'ADAPT'], ''),
    'TASKFLOW:PLAN': ('SLOT', ['ROUTE', 'ADAPT'], ''),
    'TASKFLOW:EXECUTE': ('CODE', ['EXEC', 'RUNREC'], ''),
    'TASKFLOW:VERIFY': ('CODE', ['UNK', 'EVID'], ''),
    'TASKFLOW:PERSIST': ('CODE', ['BUNDLE', 'TXN'], 'persist_checkpoint: bundle+handoff written as one transaction'),
    'TASKFLOW:REVIEW': ('PROCESS', ['BASE'], 'independent review is manual'),
    'STAGE:PLANNING': ('PROCESS', ['CORR'], 'impact planning automated; plan authoring manual'),
    'STAGE:REALIZATION': ('CODE', ['CONSIST'], ''),
    'STAGE:CLOSURE': ('CODE', ['CONSIST'], ''),
    'STAGE:FINAL_TEST': ('CODE', ['BASE', 'FTRUN', 'LLMB', 'CONFSET', 'MANCARD', 'MANEVAL'], 'harness＋runner rehearsed with fake backend (SIMULATION_ONLY); real run is batch 4 (FINAL_TEST), NOT_EXECUTED'),
}
KINDS = ("problems", "functions", "architecture")


def _read(root: str, rel: str) -> str:
    try:
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def _json(root: str, rel: str) -> dict[str, Any]:
    try:
        return json.loads(_read(root, rel) or "{}")
    except ValueError:
        return {}


def expected_ids(root: str) -> dict[str, set[str]]:
    reg, prob = _json(root, "docs/capability_registry.json"), _json(root, "docs/problem_register.json")
    arch = _json(root, "docs/blueprint.json").get("architecture", {})
    oc = _json(root, "docs/operating_contract.json")
    arch_ids = {x["id"] for k in ("axes", "skeleton_nodes", "conditional_framework") for x in arch.get(k, [])}
    flows = set(arch_ids) | {f"TASKFLOW:{s}" for s in oc.get("task_flow", [])}
    flows |= {f"STAGE:{s['stage']}" for s in oc.get("build_stage_flow", [])}
    prob_ids = {i["id"] for i in prob.get("items", [])}
    cap = {i["id"] for i in reg.get("items", [])}
    return {"problems": prob_ids, "functions": cap - prob_ids, "architecture": arch_ids, "flows": flows}


def _row(kind: str, r: dict[str, Any]) -> tuple[str, list[str], str, str]:
    """(level, mechanisms, note, status) of a ledger row."""
    lvl = r.get("control_level" if kind == "problems" else "target_level", "")
    note = r.get("residual" if kind == "problems" else "note", "")
    return lvl, list(r.get("mechanisms") or []), note, r.get("status", "")


def _mech_ok(root: str, mechs: list[str]) -> bool:
    MECH = mech_table(root)
    for m in mechs:
        if m not in MECH:
            return False
        src, sym, test = MECH[m]
        if sym.removeprefix("def ") not in _read(root, src) or not _read(root, test):
            return False
    return True


def _scan(root: str, errors: list[str]) -> tuple[dict[str, Counter], dict[str, Any]]:
    MECH = mech_table(root)
    led = _json(root, "docs/progress_ledger.json")
    if not led:
        errors.append("progress_ledger.json missing or unreadable")
        return {}, {}
    exp = expected_ids(root)
    levels: dict[str, Counter] = {}
    views: dict[str, Any] = {}
    for kind in KINDS:
        rows = led.get(kind, [])
        have = [r.get("id") for r in rows]
        if set(have) != exp[kind] or len(have) != len(set(have)):
            errors.append(f"{kind}: ledger id set differs from authority (missing={sorted(exp[kind] - set(have))[:5]} "
                          f"extra={sorted(set(have) - exp[kind])[:5]})")
        by_level: Counter = Counter()
        by_status: Counter = Counter()
        backed = total = 0
        for r in rows:
            lvl, mechs, note, status = _row(kind, r)
            by_level[lvl] += 1
            by_status[status] += 1
            if lvl not in LEVELS or lvl == "GAP":
                errors.append(f"{r.get('id')}: level {lvl}")
            for m in mechs:
                if m not in MECH:
                    errors.append(f"{r.get('id')}: unknown mechanism {m}")
            if status in NO_MECH_STATUS:
                continue
            if lvl in ("CODE", "SLOT") and not mechs:
                errors.append(f"{r.get('id')}: {lvl} needs a mechanism")
            if lvl == "PROCESS" and not note:
                errors.append(f"{r.get('id')}: PROCESS needs a note on the procedure")
            if lvl == "CODE" and status not in NOT_COUNTED:
                total += 1
                if mechs and _mech_ok(root, mechs):
                    backed += 1
                else:
                    errors.append(f"{r.get('id')}: CODE item without existing mechanism symbol/test")
            if status == "ACCEPTED" and not r.get("evidence"):
                errors.append(f"{r.get('id')}: ACCEPTED without evidence")
        levels[kind] = by_level
        views[kind] = {"total": len(rows), "level": dict(by_level), "status": dict(by_status),
                       "code_mechanism_backed": f"{backed}/{total}"}
    pf_have = set(PROCESS_FLOWS)
    pf_want = exp["flows"] - exp["architecture"]
    if pf_have != pf_want:
        errors.append(f"flows: process-flow table differs from operating_contract (missing={sorted(pf_want - pf_have)} extra={sorted(pf_have - pf_want)})")
    for id_, (lvl, mechs, note) in PROCESS_FLOWS.items():
        if lvl not in LEVELS or lvl == "GAP":
            errors.append(f"{id_}: level {lvl}")
        if lvl in ("CODE", "SLOT") and not mechs:
            errors.append(f"{id_}: {lvl} needs a mechanism")
        if lvl == "PROCESS" and not note:
            errors.append(f"{id_}: PROCESS needs a note on the procedure")
        if mechs and not _mech_ok(root, mechs):
            errors.append(f"{id_}: mechanism missing symbol/test")
    views["_led"] = led
    return levels, views


def ledger_report(root: str) -> dict[str, Any]:
    """Progress view from the ledger. ACCEPTED is listed separately and never inferred from tests."""
    errors: list[str] = []
    _, views = _scan(root, errors)
    led = views.pop("_led", {})
    gates = [(g.get("stage"), g.get("batch"), g.get("status")) for g in led.get("stage_gates", [])]
    accepted = sum(1 for k in KINDS for r in led.get(k, []) if r.get("status") == "ACCEPTED")
    return {"errors": errors, "views": views, "gates": gates, "accepted": accepted}


def check(root: str) -> dict[str, Any]:
    errors: list[str] = []
    MECH = mech_table(root)
    for name, (src, sym, test) in MECH.items():
        if sym.removeprefix("def ") not in _read(root, src):
            errors.append(f"mechanism {name}: symbol '{sym}' not found in {src}")
        if not _read(root, test):
            errors.append(f"mechanism {name}: test file {test} missing")
    levels, views = _scan(root, errors)
    led = views.pop("_led", {})
    exp = expected_ids(root)
    fl = Counter(PROCESS_FLOWS[k][0] for k in PROCESS_FLOWS) + levels.get("architecture", Counter())
    out_levels = {"problems": dict(levels.get("problems", {})), "functions": dict(levels.get("functions", {})), "flows": dict(fl)}
    totals = {"problems": len(exp["problems"]), "functions": len(exp["functions"]), "flows": len(exp["flows"])}
    accepted = sum(1 for k in KINDS for r in led.get(k, []) if r.get("status") == "ACCEPTED")
    gates = [(g.get("stage"), g.get("batch"), g.get("status")) for g in led.get("stage_gates", [])]
    return {"errors": errors, "levels": out_levels, "totals": totals,
            "ledger": {"views": views, "gates": gates, "accepted": accepted}}


def hud_markdown(root: str) -> str:
    rep = ledger_report(root)
    out = ["# forAVAr HUD（ledger 驅動）", ""]
    out.append("放行：" + " → ".join(f"{s}({b}):{st}" for s, b, st in rep["gates"]))
    out.append(f"ACCEPTED：{rep['accepted']}（未達 SYSTEM_DONE 不得宣稱完成）")
    out += ["", "| 類別 | 總數 | 層級 | 狀態 | CODE 機制備齊 |", "|---|---|---|---|---|"]
    for kind, v in rep["views"].items():
        out.append(f"| {kind} | {v['total']} | {v['level']} | {v['status']} | {v['code_mechanism_backed']} |")
    out.append("")
    out += [f"ERROR: {e}" for e in rep["errors"]] or ["ledger 與權威 ID 集合一致"]
    return "\n".join(out) + "\n\n"


def to_markdown(root: str) -> str:
    out = [hud_markdown(root) + "# forAVAr 覆蓋清冊（問題／功能／流程）", "",
           "CODE＝程式強制且有測試；SLOT＝契約入口、內容由 adapter 提供（未驗證）；PROCESS＝靠流程手動處理。層級與狀態來源＝ledger。", ""]
    titles: dict[str, str] = {}
    for i in _json(root, "docs/problem_register.json").get("items", []):
        titles[i["id"]] = i.get("title", "")
    for i in _json(root, "docs/capability_registry.json").get("items", []):
        titles.setdefault(i["id"], i.get("name", ""))
    led = _json(root, "docs/progress_ledger.json")
    for a in led.get("architecture", []):
        titles.setdefault(a["id"], a.get("name", ""))
    tables = {"問題清單": [(r["id"],) + _row("problems", r)[:3] for r in led.get("problems", [])],
              "功能清單": [(r["id"],) + _row("functions", r)[:3] for r in led.get("functions", [])],
              "流程清單": [(r["id"],) + _row("architecture", r)[:3] for r in led.get("architecture", [])]
              + [(k, *v) for k, v in PROCESS_FLOWS.items()]}
    for kind, rows in tables.items():
        out += [f"## {kind}（{len(rows)}）", "", "| ID | 名稱 | 層級 | 處理機制 | 限制／說明 |", "|---|---|---|---|---|"]
        for id_, lvl, mechs, note in rows:
            out.append(f"| {id_} | {titles.get(id_, '')[:28]} | {lvl} | {' '.join(mechs)} | {note} |")
        out.append("")
    return "\n".join(out)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    repo = args[0] if args and not args[0].endswith(".md") else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    if "--md" in sys.argv:
        dest = sys.argv[sys.argv.index("--md") + 1]
        with open(dest, "w", encoding="utf-8") as fh:
            fh.write(to_markdown(repo))
    rep = check(repo)
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    sys.exit(1 if rep["errors"] else 0)
