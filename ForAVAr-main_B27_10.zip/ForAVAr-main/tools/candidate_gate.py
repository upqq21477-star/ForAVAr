"""Candidate gate: isolate -> verify safety -> measure effect -> verdict. Decides nothing about *what* to change.

A candidate is a directory: ``candidate.json`` (id, need, expect[], accept_regress[], delete[], optional base{path: sha256}) plus ``files/`` (repo-relative
paths holding the new content). The gate never touches the real root: it copies the root twice (baseline / candidate scratch),
applies the candidate to the scratch copy only, and proves afterwards that the real root is byte-identical.

  READY   safe, every declared effect shown, no guard worse, nothing needing a second key
  HOLD    safe but not activatable yet: no effect shown / no effect declared / frozen set changed / judge touched
  REJECT  a safety command failed, a guard got worse (unwaived), the path escapes the root, the base moved (stale_base), or the real root changed

Everything that can be swapped lives in data: ``tools/gate_policy.json`` (safety commands, probes, guards, judge paths).
The judge always runs from the *baseline* root, so a candidate that edits the judge cannot approve itself (judge_touched
is always HOLD for the owner). Activation is not done here: apply the READY change set through runtime/release_txn
(``apply_transaction`` with ``standard_verify.verify``), which already snapshots and rolls back.

  python tools/candidate_gate.py CANDIDATE_DIR [--root REPO] [--policy FILE] [--out verdict.json] [--emit-changes FILE]
Exit code: 0 READY, 10 HOLD, 20 REJECT, 2 usage/policy error.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Any

SCHEMA = "foravar.candidate_gate/1"
SKIP = {".git", "__pycache__", "node_modules"}
EXIT = {"READY": 0, "HOLD": 10, "REJECT": 20}


def _tree_hash(root: str) -> str:
    h = hashlib.sha256()
    for d, dirs, files in os.walk(root):
        dirs[:] = sorted(x for x in dirs if x not in SKIP)
        for f in sorted(files):
            if f.endswith(".pyc"):
                continue
            p = os.path.join(d, f)
            h.update(os.path.relpath(p, root).encode() + b"\0")
            with open(p, "rb") as fh:
                h.update(hashlib.sha256(fh.read()).digest())
    return h.hexdigest()[:16]


def _file_sha(path: str) -> str | None:
    if not os.path.isfile(path):
        return None
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def _copy(src: str, dst: str) -> None:
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns(*SKIP, "*.pyc"))


def _safe(rel: str) -> bool:
    n = os.path.normpath(rel)
    return bool(rel) and not os.path.isabs(rel) and not n.startswith("..") and n != "."


def _run(cmd: list[str], cwd: str, timeout: int, out: str = "") -> dict[str, Any]:
    argv = [sys.executable if a == "{py}" else a.replace("{root}", cwd).replace("{out}", out) for a in cmd]
    t0 = time.time()
    try:
        r = subprocess.run(argv, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        rc, so, se = r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        rc, so, se = 124, "", "timeout"
    return {"cmd": " ".join(cmd[1:] if cmd and cmd[0] == "{py}" else cmd), "rc": rc, "sec": round(time.time() - t0, 1),
            "stdout": so, "tail": (so + se)[-400:] if rc else ""}


def _probes(policy: dict[str, Any], root: str) -> tuple[dict[str, float], list[str]]:
    metrics: dict[str, float] = {}
    errs: list[str] = []
    for p in policy.get("probes", []):
        r = _run(p["cmd"], root, policy.get("timeout_s", 300))
        try:
            data = json.loads(r["stdout"].strip().splitlines()[-1])
            metrics.update({f"{p['id']}.{k}": float(v) for k, v in data.items()})
        except (ValueError, IndexError, TypeError):
            errs.append(f"probe {p['id']} unreadable (rc={r['rc']})")
    return metrics, errs


def _freeze(policy: dict[str, Any], root: str) -> str | None:
    cmd = policy.get("freeze_cmd")
    if not cmd:
        return None
    out = os.path.join(tempfile.mkdtemp(prefix="gate_fz_"), "freeze.json")
    _run(cmd, root, policy.get("timeout_s", 300), out)
    try:
        with open(out, encoding="utf-8") as fh:
            return str(json.load(fh)["freeze"]["combined"])
    except (OSError, ValueError, KeyError):
        return None


def _added_probes(policy: dict[str, Any], base: str, scratch: str) -> list[dict[str, Any]]:
    """Probes the candidate adds (new ids in its own policy file) have no baseline number: run them on the baseline copy too,
    from the candidate's script. They are measurement only; touching policy/probes is judge_touched, so the owner reviews them."""
    try:
        with open(os.path.join(scratch, policy.get("policy_file", "tools/gate_policy.json")), encoding="utf-8") as fh:
            new = json.load(fh)
    except (OSError, ValueError):
        return []
    have = {p["id"] for p in policy.get("probes", [])}
    add = [p for p in new.get("probes", []) if p["id"] not in have]
    for p in add:
        for a in p["cmd"]:
            src, dst = os.path.join(scratch, a), os.path.join(base, a)
            if a.endswith(".py") and _safe(a) and os.path.isfile(src) and not os.path.exists(dst):
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copyfile(src, dst)
    return add


def _worse(guard: dict[str, Any], b: float, c: float) -> bool:
    tol = max(abs(b) * guard.get("tol_rel", 0.0), guard.get("tol_abs", 0.0))
    return c > b + tol if guard.get("worse_if", "increase") == "increase" else c < b - tol


def _better(exp: dict[str, Any], b: float, c: float) -> bool:
    gain = (b - c) if exp.get("better", "decrease") == "decrease" else (c - b)
    return gain > 0 and gain >= abs(b) * exp.get("min_rel", 0.0) and gain >= exp.get("min_abs", 0.0)


def _scope_gaps(base: str, scratch: str, touched: list[str], policy: dict[str, Any]) -> tuple[list[str], str | None]:
    """Changed files the candidate's NEW change_log entry does not list in replan.scope (write-before-change, S5). A change needs an entry
    it adds itself: the previous entry may list the same files and must not vouch for this change. Only editing the log alone is exempt.
    Off unless gate_policy has ``change_scope``. Returns (gaps, note); note is "no_new_entry" or "change_scope_unreadable" or None."""
    cfg = policy.get("change_scope")
    if not isinstance(cfg, dict):
        return [], None
    rel = cfg.get("log", "docs/change_log.json")
    try:
        ents = []
        for root in (base, scratch):
            with open(os.path.join(root, rel), encoding="utf-8") as fh:
                ents.append(json.load(fh)["entries"])
        seen = {e["id"] for e in ents[0]}
        new = [e for e in ents[1] if e["id"] not in seen]
        if not new:
            return ([] if touched in ([], [rel]) else list(touched)), "no_new_entry"
        return [p for p in touched if p not in new[-1]["replan"]["scope"]], None
    except (OSError, ValueError, KeyError, IndexError, TypeError):
        return [], "change_scope_unreadable"


def judge(root: str, cand_dir: str, policy: dict[str, Any]) -> dict[str, Any]:
    t0 = time.time()
    with open(os.path.join(cand_dir, "candidate.json"), encoding="utf-8") as fh:
        cand = json.load(fh)
    root_before = _tree_hash(root)
    reject: list[str] = []
    hold: list[str] = []
    files_dir = os.path.join(cand_dir, "files")
    adds: dict[str, str] = {}
    for d, _, fs in os.walk(files_dir) if os.path.isdir(files_dir) else ():
        for f in fs:
            adds[os.path.relpath(os.path.join(d, f), files_dir).replace(os.sep, "/")] = os.path.join(d, f)
    deletes = list(cand.get("delete", []))
    bad = [p for p in list(adds) + deletes if not _safe(p)]
    v: dict[str, Any] = {"schema": SCHEMA, "candidate": cand.get("id"), "need": cand.get("need"), "root_hash": root_before}
    # optional cand["base"]: {path: sha256 of the file the candidate was built on, null = must not exist}; a moved root is stale
    stale = [p for p, h in (cand.get("base") or {}).items() if _file_sha(os.path.join(root, p)) != h]
    if bad or stale:
        v.update(status="REJECT", reasons=([f"path_escape: {bad}"] if bad else []) + ([f"stale_base: {stale}"] if stale else []),
                 elapsed_s=round(time.time() - t0, 1))
        return v
    work = tempfile.mkdtemp(prefix="gate_")
    base, scratch = os.path.join(work, "base"), os.path.join(work, "cand")
    _copy(root, base)
    _copy(root, scratch)
    existing = {p for p in adds if os.path.exists(os.path.join(scratch, p))}
    for rel, src in adds.items():
        dst = os.path.join(scratch, rel)
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copyfile(src, dst)
    for rel in deletes:
        if os.path.isfile(os.path.join(scratch, rel)):
            os.remove(os.path.join(scratch, rel))
    touched = sorted(set(adds) | set(deletes))
    v["touched"] = {"new": sorted(set(adds) - existing), "modified": sorted(existing), "deleted": sorted(deletes)}
    v["candidate_hash"] = _tree_hash(files_dir) if os.path.isdir(files_dir) else "none"
    # safety: all commands must pass on the scratch copy
    safety = [_run(c, scratch, policy.get("timeout_s", 300)) for c in policy.get("safety", [])]
    v["safety"] = [{k: s[k] for k in ("cmd", "rc", "sec", "tail")} for s in safety]
    reject += [f"safety_failed: {s['cmd']}" for s in safety if s["rc"]]
    # frozen set / judge / authority classification
    fb, fc = _freeze(policy, base), _freeze(policy, scratch)
    v["freeze"] = {"before": fb, "after": fc}
    if fb is None or fc is None:
        hold.append("freeze_unknown")
    elif fb != fc:
        hold.append("frozen_set_changed: weekly batch, previous real results void (E4 PENDING_REAL_RUN)")
    jt = [p for p in touched if any(p == j or (j.endswith("/") and p.startswith(j)) for j in policy.get("judge_paths", []))]
    if jt:
        hold.append(f"judge_touched: the judge cannot approve itself, owner key needed {jt}")
    gaps, note = _scope_gaps(base, scratch, touched, policy)
    v["scope_gaps"] = gaps
    if gaps:
        reject.append(f"scope_gap: changed but not covered by a change_log entry this candidate adds ({note or 'not in its replan.scope'}) {gaps}")
    if note == "change_scope_unreadable":
        hold.append(note)
    auth = [p for p in touched if p.startswith("docs/") and os.path.basename(p) in policy.get("authority_docs", [])]
    # effect + guards
    add = _added_probes(policy, base, scratch)
    mb, eb = _probes(dict(policy, probes=policy.get("probes", []) + add), base)
    mc, ec = _probes(dict(policy, probes=policy.get("probes", []) + add), scratch)
    if eb:
        v["policy_error"] = eb
    reject += [f"{e} on candidate" for e in ec]
    v["metrics"] = {k: {"before": mb.get(k), "after": mc.get(k)} for k in sorted(set(mb) | set(mc)) if mb.get(k) != mc.get(k)}
    waived = {w["metric"]: w.get("reason", "") for w in cand.get("accept_regress", []) if w.get("reason")}
    v["guards"] = []
    for g in policy.get("guards", []):
        m = g["metric"]
        if m not in mb:
            continue
        b, c = mb[m], mc.get(m)
        broke = c is None or _worse(g, b, c)
        waived_ok = broke and m in waived and not g.get("hard")
        v["guards"].append({"metric": m, "before": b, "after": c, "worse": broke, "waived": waived.get(m) if waived_ok else None})
        if broke and not waived_ok:
            reject.append(f"guard_worse: {m} {b} -> {c}")
    exp = cand.get("expect", [])
    if not exp:
        hold.append("no_declared_effect")
    shown, missed = [], []
    for e in exp:
        b, c = mb.get(e["metric"]), mc.get(e["metric"])
        (shown if b is not None and c is not None and _better(e, b, c) else missed).append(e["metric"])
    v["effect"] = {"shown": shown, "not_shown": missed}
    if missed:
        hold.append(f"effect_not_shown: {missed}")
    if _tree_hash(root) != root_before:
        reject.append("root_modified")
    status = "REJECT" if reject else "HOLD" if hold else "READY"
    v.update(status=status, reasons=reject + hold, needs_owner_authorization=bool(auth) and status != "REJECT", authority_touched=auth)
    v["elapsed_s"] = round(time.time() - t0, 1)
    shutil.rmtree(work, ignore_errors=True)
    return v


def changes_of(cand_dir: str, cand: dict[str, Any]) -> dict[str, str | None]:
    """Change set in the shape runtime/release_txn.apply_transaction takes: path -> new text (None = delete)."""
    out: dict[str, str | None] = {}
    fd = os.path.join(cand_dir, "files")
    for d, _, fs in os.walk(fd) if os.path.isdir(fd) else ():
        for f in fs:
            with open(os.path.join(d, f), encoding="utf-8") as fh:
                out[os.path.relpath(os.path.join(d, f), fd).replace(os.sep, "/")] = fh.read()
    out.update({p: None for p in cand.get("delete", [])})
    return out


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate")
    ap.add_argument("--root", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
    ap.add_argument("--policy")
    ap.add_argument("--out")
    ap.add_argument("--emit-changes")
    a = ap.parse_args()
    root = os.path.abspath(a.root)
    try:
        with open(a.policy or os.path.join(root, "tools", "gate_policy.json"), encoding="utf-8") as fh:
            policy = json.load(fh)
        v = judge(root, a.candidate, policy)
    except (OSError, ValueError, KeyError) as exc:
        print(f"gate error: {exc}", file=sys.stderr)
        return 2
    if a.out:
        with open(a.out, "w", encoding="utf-8") as fh:
            json.dump(v, fh, ensure_ascii=False, indent=1)
    if a.emit_changes and v["status"] == "READY":
        with open(os.path.join(a.candidate, "candidate.json"), encoding="utf-8") as fh:
            ch = changes_of(a.candidate, json.load(fh))
        with open(a.emit_changes, "w", encoding="utf-8") as fh:
            json.dump(ch, fh, ensure_ascii=False)
    print(json.dumps({k: v[k] for k in ("candidate", "status", "reasons", "effect", "elapsed_s") + (("authority_touched",) if v.get("authority_touched") else ()) if k in v}, ensure_ascii=False))
    return EXIT[v["status"]]


if __name__ == "__main__":
    sys.exit(main())
