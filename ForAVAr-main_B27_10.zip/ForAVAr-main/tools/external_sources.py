"""External source registry (provenance): every outside tool / paper / practice the system absorbs is one row in docs/external_sources.json.

Why: an absorbed idea or copied file loses its origin; later nobody can say where it came from, which version was read, or when to look again.
Rule: an upstream change is never merged. It becomes a candidate and goes through tools/candidate_gate.py like any other change
(``on_update`` can only be ``candidate_gate``). ``cooldown_days`` = do not adopt an upstream version younger than that (supply-chain delay).
Offline and stdlib only: it reads the registry and the repo, it never fetches. Looking upstream is a chat-level search whose result
becomes a candidate. ``--due`` is informational and never a check failure (no time bomb inside standard_verify).

  python tools/external_sources.py [ROOT] --check            exit 1 and list problems
  python tools/external_sources.py [ROOT] --due [--today D]  rows whose last_checked is older than check_every_days
  python tools/external_sources.py [ROOT] --show ID          one row, compact JSON
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
import re
import sys
from typing import Any

REGISTRY = "docs/external_sources.json"
KINDS = {"idea", "tool", "paper", "product", "practice", "dataset"}
STATUS = {"WATCH", "PINNED", "DROPPED"}
INTEGRATION = {"none", "idea_only", "vendored", "dependency"}
REQUIRED = ("id", "name", "kind", "url", "license", "seen_on", "pinned", "status", "adopted", "integration", "absorbed_into",
            "check_every_days", "last_checked", "cooldown_days", "on_update")
ID = re.compile(r"^XS-[A-Z0-9]+(-[A-Z0-9]+)*$")


def _date(s: Any) -> datetime.date | None:
    try:
        return datetime.date.fromisoformat(s)
    except (TypeError, ValueError):
        return None


def _sha(path: str) -> str | None:
    if not os.path.isfile(path):
        return None
    with open(path, "rb") as fh:
        return hashlib.sha256(fh.read()).hexdigest()


def load(root: str) -> dict[str, Any]:
    with open(os.path.join(root, REGISTRY), encoding="utf-8") as fh:
        return json.load(fh)


def row_problems(root: str, r: dict[str, Any]) -> list[str]:
    rid = r.get("id", "?")
    out = [f"{rid}: missing {k}" for k in REQUIRED if k not in r]
    if out:
        return out
    if not ID.match(str(rid)):
        out.append(f"{rid}: id must look like XS-NAME")
    if r["kind"] not in KINDS:
        out.append(f"{rid}: kind {r['kind']!r} not in {sorted(KINDS)}")
    if r["status"] not in STATUS:
        out.append(f"{rid}: status {r['status']!r} not in {sorted(STATUS)}")
    if r["integration"] not in INTEGRATION:
        out.append(f"{rid}: integration {r['integration']!r} not in {sorted(INTEGRATION)}")
    if not str(r["url"]).startswith("https://"):
        out.append(f"{rid}: url must be https")
    for k in ("seen_on", "last_checked"):
        if _date(r[k]) is None:
            out.append(f"{rid}: {k} must be an ISO date")
    for k in ("check_every_days", "cooldown_days"):
        if not isinstance(r[k], int) or isinstance(r[k], bool) or r[k] < 0:
            out.append(f"{rid}: {k} must be a non-negative integer")
    if r["on_update"] != "candidate_gate":
        out.append(f"{rid}: on_update must be candidate_gate (upstream is never merged directly)")
    if not isinstance(r["absorbed_into"], list):
        out.append(f"{rid}: absorbed_into must be a list")
        return out
    if r["adopted"]:
        if not r["absorbed_into"]:
            out.append(f"{rid}: adopted but absorbed_into is empty")
        if str(r["pinned"]).upper().startswith("UNPINNED"):
            out.append(f"{rid}: adopted but not pinned (record version, commit or date read)")
        if r["integration"] == "none":
            out.append(f"{rid}: adopted but integration is none")
    elif r["integration"] in ("vendored", "dependency"):
        out.append(f"{rid}: integration {r['integration']} requires adopted=true")
    for p in r["absorbed_into"]:
        if not os.path.exists(os.path.join(root, p)):
            out.append(f"{rid}: absorbed_into {p} does not exist")
    if r["integration"] == "vendored":
        sha = r.get("sha256")
        if not isinstance(sha, dict) or not sha:
            out.append(f"{rid}: vendored needs sha256 {{path: hash}}")
        else:
            out += [f"{rid}: vendored file {p} changed or missing (hash differs): upstream drift or local edit" for p, h in sha.items()
                    if _sha(os.path.join(root, p)) != h]
    return out


def check(root: str) -> list[str]:
    try:
        reg = load(root)
    except (OSError, ValueError) as e:
        return [f"{REGISTRY}: cannot read ({e})"]
    rows = reg.get("sources")
    if not isinstance(rows, list):
        return [f"{REGISTRY}: sources must be a list"]
    problems: list[str] = []
    seen: set[str] = set()
    for r in rows:
        if not isinstance(r, dict):
            problems.append("source row is not an object")
            continue
        if r.get("id") in seen:
            problems.append(f"{r.get('id')}: duplicate id")
        seen.add(r.get("id"))
        problems += row_problems(root, r)
    return problems


def due(root: str, today: datetime.date) -> list[str]:
    out = []
    for r in load(root).get("sources", []):
        last = _date(r.get("last_checked"))
        if r.get("status") != "DROPPED" and (last is None or (today - last).days >= int(r.get("check_every_days", 0))):
            out.append(f"{r['id']}\t{r.get('last_checked')}\t{r['url']}")
    return out


def main(argv: list[str]) -> int:
    args = [a for a in argv if not a.startswith("--")]
    root = args[0] if args and os.path.isdir(args[0]) else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    if "--due" in argv:
        i = argv.index("--today") + 1 if "--today" in argv else 0
        today = _date(argv[i]) if i else datetime.date.today()
        if today is None:
            print("--today needs YYYY-MM-DD")
            return 2
        print("\n".join(due(root, today)) or "none due")
        return 0
    if "--show" in argv:
        want = argv[argv.index("--show") + 1]
        hit = [r for r in load(root)["sources"] if r.get("id") == want]
        print(json.dumps(hit[0], ensure_ascii=False) if hit else f"no such id {want}")
        return 0 if hit else 1
    problems = check(root)
    print("\n".join(problems) or "OK")
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
