"""Config-driven LLM backend for tools/final_test_run.py. stdlib only; no network call is made at import time.

One code path per *protocol* ("openai" chat-completions format: Groq, OpenRouter, NVIDIA NIM, Ollama, vLLM, Gemini's
compatible endpoint; "anthropic" messages format). Everything provider-specific lives in tools/backend_profiles.json and
can be overridden per run (``--set model=...``), so changing provider/model/environment never edits code. The same command
works in any environment that has Python + network + the key in an environment variable (PC, Colab, GitHub Actions).
``make_call_model`` throttles to ``rpm`` and (optional, 0=off) ``tpm`` tokens/minute using the provider's reported usage, stops with a
resume hint when ``tpd`` (tokens/day, counted per process) is reached or a Retry-After exceeds ``max_wait_s`` (default 900s, i.e. a daily cap),
retries 429/5xx/timeouts with backoff (honours Retry-After) and counts usage. Free tiers are often limited by tokens, not requests.
The sandbox executor only records calls; it performs no real action.
"""
from __future__ import annotations

import json
import os
import time
import urllib.error
import urllib.request
from collections.abc import Callable, Mapping
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
PROFILES = os.path.join(HERE, "backend_profiles.json")
INT_KEYS = {"rpm", "max_retries", "timeout_s", "max_tokens", "tpm", "tpd", "max_wait_s"}
FLOAT_KEYS = {"temperature"}
RETRY_STATUS = {408, 409, 425, 429, 500, 502, 503, 504}


class BackendError(RuntimeError):
    """Configuration or transport failure (callers treat it like any adapter fault: fail closed, keep the sample)."""


def parse_overrides(pairs: list[str] | None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for p in pairs or []:
        k, sep, v = p.partition("=")
        if not sep or not k.strip():
            raise BackendError(f"--set expects key=value, got {p!r}")
        k = k.strip()
        out[k] = int(v) if k in INT_KEYS else float(v) if k in FLOAT_KEYS else v
    return out


def load_profile(name: str, overrides: Mapping[str, Any] | None = None, path: str = PROFILES) -> dict[str, Any]:
    with open(path, encoding="utf-8") as fh:
        table = json.load(fh)
    if name not in table or name.startswith("_"):
        raise BackendError(f"unknown profile {name!r}; known: {sorted(k for k in table if not k.startswith('_'))}")
    prof = {**table[name], **(overrides or {})}
    if prof.get("protocol") not in {"openai", "anthropic"}:
        raise BackendError("profile.protocol must be 'openai' or 'anthropic'")
    for k in ("base_url", "model"):
        if not str(prof.get(k, "")).strip():
            raise BackendError(f"profile {name!r} needs {k} (use --set {k}=...)")
    return prof


def _post(url: str, headers: Mapping[str, str], body: bytes, timeout: float) -> tuple[int, Mapping[str, str], str]:
    req = urllib.request.Request(url, data=body, headers=dict(headers), method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:  # noqa: S310 - URL comes from the owner's profile
            return r.status, dict(r.headers), r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, dict(e.headers or {}), e.read().decode("utf-8", "replace")


def _request(prof: Mapping[str, Any], prompt: str, key: str) -> tuple[str, dict[str, str], bytes]:
    base = str(prof["base_url"]).rstrip("/")
    if prof["protocol"] == "anthropic":
        body = {"model": prof["model"], "max_tokens": prof["max_tokens"], "temperature": prof["temperature"],
                "messages": [{"role": "user", "content": prompt}]}
        headers = {"content-type": "application/json", "anthropic-version": "2023-06-01", "x-api-key": key}
        return f"{base}/v1/messages", headers, json.dumps(body).encode()
    body = {"model": prof["model"], "max_tokens": prof["max_tokens"], "temperature": prof["temperature"],
            "messages": [{"role": "user", "content": prompt}]}
    headers = {"content-type": "application/json"}
    if key:
        headers["authorization"] = f"Bearer {key}"
    return f"{base}/chat/completions", headers, json.dumps(body).encode()


def _parse(prof: Mapping[str, Any], text: str) -> tuple[str, int, int]:
    try:
        obj = json.loads(text)
        if prof["protocol"] == "anthropic":
            out = "".join(b.get("text", "") for b in obj["content"] if b.get("type") == "text")
            u = obj.get("usage", {})
            return out, int(u.get("input_tokens", 0)), int(u.get("output_tokens", 0))
        out = obj["choices"][0]["message"]["content"] or ""
        u = obj.get("usage", {})
        return out, int(u.get("prompt_tokens", 0)), int(u.get("completion_tokens", 0))
    except (ValueError, KeyError, IndexError, TypeError, AttributeError) as exc:
        raise BackendError(f"unparseable provider response ({type(exc).__name__}): {text[:200]!r}") from exc


def make_call_model(prof: Mapping[str, Any], post: Callable[..., Any] = _post, sleep: Callable[[float], None] = time.sleep,
                    clock: Callable[[], float] = time.monotonic, env: Mapping[str, str] | None = None) -> Callable[[str], str]:
    env = os.environ if env is None else env
    key = env.get(prof.get("key_env", ""), "") if prof.get("key_env") else ""
    if prof.get("key_env") and not key:
        raise BackendError(f"environment variable {prof['key_env']} is empty (set the API key there; never in files)")
    stats = {"calls": 0, "retries": 0, "input_tokens": 0, "output_tokens": 0}
    last = [None]  # time of the previous request, for rpm spacing
    gap = 60.0 / prof["rpm"] if prof.get("rpm") else 0.0
    tpm, tpd, max_wait = int(prof.get("tpm") or 0), int(prof.get("tpd") or 0), float(prof.get("max_wait_s") or 900)
    window: list[tuple[float, int]] = []  # (finish time, tokens) of recent successes, for tpm
    day = [0]  # tokens used by this process, for tpd

    def avg_out() -> int:
        return min(int(prof["max_tokens"]), stats["output_tokens"] // stats["calls"] if stats["calls"] else 400)

    def budget(prompt: str) -> None:
        est = len(prompt) // 3 + avg_out()
        if tpd and day[0] + est > tpd:
            raise BackendError(f"daily token budget tpd={tpd} reached ({day[0]} used); resume later with --resume")
        while tpm:
            now = clock()
            window[:] = [(t, n) for t, n in window if now - t < 60.0]
            if not window or sum(n for _, n in window) + est <= tpm:
                return
            sleep(max(window[0][0] + 60.0 - now, 0.1))

    def call_model(prompt: str) -> str:
        url, headers, body = _request(prof, prompt, key)
        budget(prompt)
        for attempt in range(int(prof["max_retries"]) + 1):
            if gap and last[0] is not None and clock() - last[0] < gap:
                sleep(gap - (clock() - last[0]))
            last[0] = clock()
            try:
                status, hdrs, text = post(url, headers, body, float(prof["timeout_s"]))
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                status, hdrs, text = 599, {}, str(exc)
            if status == 200:
                out, tin, tout = _parse(prof, text)
                stats["calls"] += 1
                stats["input_tokens"] += tin
                stats["output_tokens"] += tout
                window.append((clock(), tin + tout))
                day[0] += tin + tout
                return out
            if status not in RETRY_STATUS and status != 599 or attempt == int(prof["max_retries"]):
                raise BackendError(f"provider returned {status} after {attempt + 1} attempt(s): {text[:200]!r}")
            stats["retries"] += 1
            try:
                wait = float({k.lower(): v for k, v in hdrs.items()}.get("retry-after", ""))
            except ValueError:
                wait = min(2.0 ** attempt * 2, 60.0)
            if wait > max_wait:
                raise BackendError(f"provider asks to wait {wait:.0f}s (> max_wait_s={max_wait:.0f}), likely a daily cap; resume later with --resume")
            sleep(max(wait, gap))

    call_model.stats = stats  # type: ignore[attr-defined]
    call_model.profile = {k: v for k, v in prof.items() if k != "note"}  # type: ignore[attr-defined]
    return call_model


def sandbox_executor() -> Callable[..., Any]:
    """Records every call; performs no real action. ``executor.log`` is the measured side-effect record."""
    log: list[str] = []

    def executor(sample: Mapping[str, Any], scope: list[str]) -> dict[str, Any]:
        log.append(str(sample["id"]))
        return {"executed": True, "scope": list(scope)}

    executor.log = log  # type: ignore[attr-defined]
    return executor


def factory(name: str, overrides: Mapping[str, Any] | None = None, **kw: Any) -> tuple[Callable[[str], str], Callable[..., Any]]:
    return make_call_model(load_profile(name, overrides), **kw), sandbox_executor()
