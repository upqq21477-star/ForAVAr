"""Cheap ledger lookup so agents never read docs/progress_ledger.json whole (~100KB).

  python tools/ledger_query.py ID [ID...]          show those items (compact JSON)
  python tools/ledger_query.py --status PLANNED    ids + names by status
  python tools/ledger_query.py --realize R7        items assigned to an increment
  python tools/ledger_query.py --todo              increments with progress, gates, open decisions
"""
from __future__ import annotations

import json
import os
import sys

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
KINDS = ("functions", "problems", "architecture", "invariants")


def load(root: str = ROOT) -> dict:
    with open(os.path.join(root, "docs", "progress_ledger.json"), encoding="utf-8") as fh:
        return json.load(fh)


def items(led: dict):
    for k in KINDS:
        for r in led.get(k, []):
            yield k, r


def brief(r: dict) -> str:
    return f"{r['id']}\t{r.get('status', '')}\t{r.get('name') or r.get('title') or ''}"


def query(led: dict, args: list[str]) -> list[str]:
    if args[:1] == ["--status"]:
        return [brief(r) for _, r in items(led) if r.get("status") == args[1]]
    if args[:1] == ["--realize"]:
        return [brief(r) for _, r in items(led) if r.get("realize") == args[1]]
    if args[:1] == ["--todo"]:
        plan = led["realization_plan"]
        out = [f"{i['id']}\t{i.get('progress', 'TODO')}\t{i['name']}" for i in plan["increments"]]
        out += [f"GATE {g['stage']}\t{g['status']}\t{g.get('batch', '')}" for g in led["stage_gates"]]
        out += [f"{d['id']}\t{d['state']}\t{d['item']}" for d in led["open_decisions"]]
        return out
    want = set(args)
    return [json.dumps(r, ensure_ascii=False) for _, r in items(led) if r["id"] in want]


if __name__ == "__main__":
    for line in query(load(), sys.argv[1:] or ["--todo"]):
        print(line)
