"""Layered brief: read by query, not by file. Derived on demand from the authority docs, so nothing is stored twice and nothing can drift.

  L0  python tools/brief.py                    purpose, status, counts, last changes, size of each doc in est. tokens (~1k tokens)
  L1  python tools/brief.py --route WORD...    top 5 index quick_routes by number of words matched, each with the est. token cost of the target
  L2  python tools/brief.py ID [ID...]         every node whose "id" equals ID (or mechanism name), in any authority doc: compact fields,
                                               JSON pointer and a 8-hex file hash (changes when the file changes = the handle went stale)
  --budget N   cap output at N characters (default 3500; cut marked with '…[cut]'). --root ROOT.

Structure-agnostic on purpose: L2 walks every JSON node that has an "id", so a renamed array or a new document kind needs no change here.
Token counts are an estimate (CJK characters count 1, other text 1 per 3.6 characters), not a tokenizer.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sys
from typing import Any, Iterator

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
CJK = re.compile(r"[\u3000-\u9fff\uff00-\uffef]")
SKIP = {"integrity_snapshot", "id_lookup", "archive"}  # lookup tables / snapshots: handles live elsewhere, matching them is noise
MAXHIT = 5


def est(text: str) -> int:
    n = len(CJK.findall(text))
    return n + int((len(text) - n) / 3.6)


def _docs(root: str) -> list[str]:
    d = os.path.join(root, "docs")
    return sorted(f"docs/{n}" for n in os.listdir(d) if n.endswith(".json")) if os.path.isdir(d) else []


def _load(root: str, rel: str) -> tuple[Any, str] | None:
    try:
        with open(os.path.join(root, rel), "rb") as fh:
            raw = fh.read()
        return json.loads(raw.decode("utf-8")), hashlib.sha256(raw).hexdigest()[:8]
    except (OSError, ValueError):
        return None


def _short(v: Any, n: int = 160) -> str:
    s = v if isinstance(v, str) else json.dumps(v, ensure_ascii=False)
    return s if len(s) <= n else s[: n - 1] + "…"


def _ptr(parts: list[str]) -> str:
    return "/" + "/".join(p.replace("~", "~0").replace("/", "~1") for p in parts)


def _walk(node: Any, parts: list[str]) -> Iterator[tuple[list[str], Any]]:
    if isinstance(node, dict):
        yield parts, node
        for k, v in node.items():
            if k not in SKIP:
                yield from _walk(v, parts + [str(k)])
    elif isinstance(node, list):
        for i, v in enumerate(node):
            yield from _walk(v, parts + [str(i)])


def resolve(root: str, key: str) -> list[str]:
    hits: list[str] = []
    total = 0
    for rel in _docs(root):
        got = _load(root, rel)
        if got is None:
            continue
        doc, h = got
        for parts, node in _walk(doc, []):
            named = node.get("id") == key
            mech = bool(parts) and parts[-1] == "mech" and key in node  # mechanism rows are keyed by name, not by "id"
            if not (named or mech):
                continue
            total += 1
            if len(hits) < MAXHIT:
                if mech:
                    where, body = parts + [key], _short(node[key], 200)
                else:
                    where, body = parts, "; ".join(f"{k}={_short(v)}" for k, v in list(node.items())[:6] if k != "id")
                hits.append(f"{key}\t{rel}#{_ptr(where)} @{h}\t{body}")
    if total > MAXHIT:
        hits.append(f"…{total - MAXHIT} more matches for {key}: narrow by file")
    return hits


def _cost(root: str, f: str, ptr: Any) -> str:
    """Est. tokens of what a route points at: JSON pointer(s) inside a JSON file, file path(s), or the whole file."""
    total, known = 0, False
    for p in (ptr if isinstance(ptr, list) else [ptr]):
        if isinstance(p, str) and p.startswith("/") and f.endswith(".json"):
            tgt = _load(root, f)
            node: Any = tgt[0] if tgt else None
            try:
                for part in [x for x in p.split("/") if x]:
                    node = node[int(part)] if isinstance(node, list) else node[part]
                total, known = total + est(json.dumps(node, ensure_ascii=False)), True
            except (KeyError, IndexError, ValueError, TypeError):
                pass
        elif isinstance(p, str) and os.path.isfile(os.path.join(root, p)):
            with open(os.path.join(root, p), encoding="utf-8", errors="replace") as fh:
                total, known = total + est(fh.read()), True
    if not known and f and os.path.isfile(os.path.join(root, f)):
        with open(os.path.join(root, f), encoding="utf-8", errors="replace") as fh:
            return str(est(fh.read()))
    return str(total) if known else "?"


def routes(root: str, words: list[str], top: int = 5) -> list[str]:
    """Rank quick_routes by how many of the words they contain (any word counts; all words ranks first)."""
    got = _load(root, "docs/index.json")
    scored: list[tuple[int, int, str]] = []
    for n, r in enumerate(got[0].get("quick_routes", []) if got else []):
        if not isinstance(r, dict):
            continue
        blob = json.dumps(r, ensure_ascii=False).lower()
        hit = sum(1 for w in words if w.lower() in blob)
        if hit:
            f, ptr = r.get("file", ""), r.get("pointer")
            scored.append((-hit, n, f"{r.get('query')}\t{f}\t{_short(ptr, 90)}\t~{_cost(root, f, ptr)} tok"))
    return [line for _, _, line in sorted(scored)[:top]]


def level0(root: str) -> list[str]:
    out = ["# L0 brief (derived; read deeper with --route WORD or an ID)"]
    bp = _load(root, "docs/blueprint.json")
    if bp:
        out.append(f"purpose: {_short(bp[0].get('purpose'), 200)} | {_short(bp[0].get('purpose_definition'), 240)}")
    ix = _load(root, "docs/index.json")
    if ix:
        out.append(f"index status: {_short(ix[0].get('status'), 80)} updated {ix[0].get('updated_at')}; routes: {len(ix[0].get('quick_routes', []))}")
    cl = _load(root, "docs/change_log.json")
    if cl:
        ent = cl[0].get("entries", [])
        out.append(f"change_log: {len(ent)} entries; last:")
        out += [f"  {e.get('id')} {e.get('status')} {_short(e.get('need'), 70)}" for e in ent[-3:]]
    pr = _load(root, "docs/problem_register.json")
    cr = _load(root, "docs/capability_registry.json")
    out.append(f"problems: {len(pr[0].get('items', [])) if pr else '?'}; capabilities: {len(cr[0].get('items', [])) if cr else '?'}")
    xs = _load(root, "docs/external_sources.json")
    if xs:
        out.append(f"external sources: {len(xs[0].get('sources', []))} (python tools/external_sources.py --due)")
    out.append("doc size, est. tokens (whole-file read cost — avoid; use L1/L2):")
    sizes = []
    for rel in _docs(root) + ["README.md"]:
        try:
            with open(os.path.join(root, rel), encoding="utf-8", errors="replace") as fh:
                sizes.append((est(fh.read()), rel))
        except OSError:
            pass
    out.append("  " + "  ".join(f"{rel.split('/')[-1]}={t}" for t, rel in sorted(sizes, reverse=True)))
    out.append("change a thing: copy repo -> edit copy -> candidate_from_copy -> python tools/candidate_gate.py DIR -> release_txn")
    return out


def render(lines: list[str], budget: int) -> str:
    text = "\n".join(lines)
    return text if len(text) <= budget else text[: max(0, budget - 8)] + "…[cut]"


def main(argv: list[str]) -> int:
    budget, root, rest = 3500, ROOT, []
    i = 0
    while i < len(argv):
        if argv[i] == "--budget" and i + 1 < len(argv):
            budget, i = int(argv[i + 1]), i + 2
        elif argv[i] == "--root" and i + 1 < len(argv):
            root, i = argv[i + 1], i + 2
        else:
            rest.append(argv[i])
            i += 1
    if not rest:
        print(render(level0(root), budget))
        return 0
    if rest[0] == "--route":
        lines = routes(root, rest[1:])
        print(render(lines or ["no route matches; try fewer words"], budget))
        return 0 if lines else 1
    lines, missing = [], []
    for key in rest:
        got = resolve(root, key)
        (lines.extend if got else missing.append)(got or key)
    if missing:
        lines.append("not found: " + " ".join(missing))
    print(render(lines, budget))
    return 1 if missing else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
