"""Difference inventory (差異清冊) between two repo roots. Read-only; stdlib only; not part of Runtime.

Reports file adds/removals/changes (sha256 prefix), ledger row status transitions per id, counts deltas, stage-gate and
open-decision changes. Usage: python tools/closure_report.py OLD_ROOT [NEW_ROOT]   (NEW_ROOT defaults to this repo).
Typical use at B24: unpack the previous batch's zip, diff against the working tree, paste the summary into the handoff.

Impact graph (B24 C2): ``python tools/closure_report.py impact FILE [FILE...]`` answers "if I change this file, what is
touched": transitive importers (by layer), the test files among them, coverage mechanisms whose source/test is the file,
and the ledger rows that cite those mechanisms. Static import statements only (dynamic loading is not seen).
"""
from __future__ import annotations

import hashlib
import json
import os
import sys
from typing import Any

SKIP = {"__pycache__", ".foravar_snap", ".git"}
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)


def _files(root: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for base, dirs, names in os.walk(root):
        dirs[:] = sorted(d for d in dirs if d not in SKIP)
        for n in sorted(names):
            p = os.path.join(base, n)
            with open(p, "rb") as fh:
                out[os.path.relpath(p, root).replace(os.sep, "/")] = hashlib.sha256(fh.read()).hexdigest()[:16]
    return out


def _ledger(root: str) -> dict[str, Any]:
    try:
        with open(os.path.join(root, "docs", "progress_ledger.json"), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return {}


def diff_repos(old: str, new: str) -> dict[str, Any]:
    fo, fn = _files(old), _files(new)
    lo, ln = _ledger(old), _ledger(new)
    rows = lambda led, k: {e.get("id"): e for e in led.get(k, [])}  # noqa: E731
    transitions: dict[str, list[str]] = {}
    for key in ("functions", "problems", "architecture"):
        a, b = rows(lo, key), rows(ln, key)
        for i in sorted(set(a) | set(b)):
            sa, sb = (a.get(i) or {}).get("status", "ABSENT"), (b.get(i) or {}).get("status", "ABSENT")
            if sa != sb:
                transitions.setdefault(f"{sa} -> {sb}", []).append(i)
    gate = lambda led: {g.get("stage"): g.get("status") for g in led.get("stage_gates", [])}  # noqa: E731
    go, gn = gate(lo), gate(ln)
    dec = lambda led: {d.get("id"): d.get("status") for d in led.get("open_decisions", []) if isinstance(d, dict)}  # noqa: E731
    do, dn = dec(lo), dec(ln)
    return {
        "files_added": sorted(set(fn) - set(fo)),
        "files_removed": sorted(set(fo) - set(fn)),
        "files_changed": sorted(p for p in set(fo) & set(fn) if fo[p] != fn[p]),
        "files_unchanged": len(set(fo) & set(fn)) - len([p for p in set(fo) & set(fn) if fo[p] != fn[p]]),
        "status_transitions": transitions,
        "counts_changed": {k: [lo.get("counts", {}).get(k), v] for k, v in ln.get("counts", {}).items() if lo.get("counts", {}).get(k) != v},
        "gates_changed": {k: [go.get(k), v] for k, v in gn.items() if go.get(k) != v},
        "decisions_changed": {k: [do.get(k), v] for k, v in dn.items() if do.get(k) != v},
    }


def impact(root: str, targets: list[str]) -> dict[str, Any]:
    """Blast radius of changing ``targets`` (repo-relative paths). Read-only."""
    from importgraph import import_graph
    from coverage import mech_table
    MECH = mech_table(root)
    graph = import_graph(root)
    rev: dict[str, set[str]] = {}
    for src, deps in graph.items():
        for d in deps:
            rev.setdefault(d, set()).add(src)
    unknown = [t for t in targets if t not in graph and not os.path.exists(os.path.join(root, t))]
    seen: set[str] = set()
    todo = [t for t in targets if t in graph]
    while todo:
        n = todo.pop()
        for up in rev.get(n, ()):
            if up not in seen and up not in targets:
                seen.add(up)
                todo.append(up)
    affected = sorted(seen)
    mechs = sorted(m for m, (src, _sym, test) in MECH.items() if src in targets or test in targets
                   or src in seen or test in seen)
    direct = sorted(m for m, (src, _sym, test) in MECH.items() if src in targets or test in targets)
    led = _ledger(root)
    rows = sorted({r["id"] for k in ("architecture", "functions", "problems", "invariants") for r in led.get(k, [])
                   if set(r.get("mechanisms") or []) & set(direct)})
    by_layer: dict[str, list[str]] = {}
    for a_ in affected:
        by_layer.setdefault(a_.split("/")[0], []).append(a_)
    own_tests = sorted(t for t in targets if t.startswith("tests/"))
    direct_tests = sorted({u for t in targets for u in rev.get(t, ()) if u.startswith("tests/")} | set(own_tests))
    return {"targets": targets, "unknown_paths": unknown, "affected_by_layer": by_layer,
            "tests_direct": direct_tests,  # quick set: tests that import a target directly (or are the target)
            "tests_to_run": sorted(set(by_layer.get("tests", [])) | set(own_tests)),  # full set: transitive
            "mechanisms_direct": direct, "mechanisms_indirect": sorted(set(mechs) - set(direct)),
            "ledger_rows_direct": rows,
            "blast": {"modules": len(affected), "tests": len(by_layer.get("tests", [])), "ledger_rows": len(rows)}}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: closure_report.py OLD_ROOT [NEW_ROOT] | impact FILE [FILE...]")
    if sys.argv[1] == "impact":
        print(json.dumps(impact(os.path.join(HERE, ".."), sys.argv[2:]), ensure_ascii=False, indent=2))
        sys.exit(0)
    new_root = sys.argv[2] if len(sys.argv) > 2 else os.path.join(HERE, "..")
    print(json.dumps(diff_repos(sys.argv[1], new_root), ensure_ascii=False, indent=2))
