"""Static consistency check (SOP-CAND-008). Read-only; stdlib only; not part of Runtime.

Placement note: this is a repo-maintenance tool, not Runtime/source. It is kept under
tools/ (not runtime/) so the runtime boundary stays clean; move to forAVArb if the owner
prefers. Checks: JSON parses; capability/problem IDs unique and match index counts; local
path references exist; runtime/tests files are listed in README; code status literals vs
blueprint runtime_contract.statuses. Also (B24): import graph/layering/cycles, ledger counts vs rows, maturity drift, adapter_stage vs templates,
stray artifacts, file modes. Findings: ERROR (breaks consistency) or INFO (known,
documented deviation). Usage: python tools/check_consistency.py [repo_root]
"""
from __future__ import annotations

import ast
import collections
import json
import os
import re
import sys
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from importgraph import import_graph  # noqa: E402,F401  (re-exported; defined in tools/importgraph.py)
import guard_rules  # noqa: E402  (K2: dynamic_import / entry_guard / ledger_ruling)

DOCS = ("blueprint.json", "operating_contract.json", "capability_registry.json", "problem_register.json", "index.json", "progress_ledger.json")
LEVELS = {"CODE", "SLOT", "PROCESS"}
STATUSES = {"PLANNED", "SLOT_TEMPLATE_ONLY", "CONTRACT_TESTED", "MANUAL_BY_RULING", "MERGED", "DEFERRED", "ACCEPTED", "RETIRED"}
STAGES = ("PLANNING", "REALIZATION", "CLOSURE", "FINAL_TEST")
KNOWN_EXTRA_STATUSES: set[str] = set()  # blueprint statuses now include REJECTED/CANCELLED
PATH_RE = re.compile(r"(?:runtime|tests|tools|docs)/[\w./-]+\.(?:py|json|md)")


def _load(root: str, name: str, findings: list[dict[str, str]]) -> Any:
    try:
        with open(os.path.join(root, "docs", name), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError) as exc:
        findings.append({"level": "ERROR", "check": "json_parse", "detail": f"docs/{name}: {exc}"})
        return None


def _dups(ids: list[str]) -> list[str]:
    seen: set[str] = set()
    return sorted({i for i in ids if i in seen or seen.add(i)})  # type: ignore[func-returns-value]


REF_RE = re.compile(r"^docs/progress_ledger\.json#/(functions|problems|architecture)/([^/]+)$")


def _bad_ledger_ref(item: dict[str, Any], led: Any) -> str:
    """'' if item.ledger_ref points at an existing ledger row with the same id, else the reason."""
    ref = item.get("ledger_ref")
    if not ref:
        return "missing ledger_ref"
    m = REF_RE.match(ref)
    if not m:
        return f"malformed ledger_ref {ref}"
    if m.group(2) != item.get("id"):
        return f"ledger_ref targets {m.group(2)}"
    if not any(r.get("id") == m.group(2) for r in led.get(m.group(1), [])):
        return f"no ledger row {m.group(1)}/{m.group(2)}"
    return ""


def check_ledger(led: Any, cap: Any, prob: Any, bp: Any, err: Any) -> None:
    """Progress ledger completeness: ids match authorities; every item has level, status, acceptance; gates ordered."""
    if not led:
        return
    prob_ids = {i.get("id") for i in (prob or {}).get("items", [])}
    fn_ids = {i.get("id") for i in (cap or {}).get("items", [])} - prob_ids
    arch = (bp or {}).get("architecture", {})
    arch_ids = {x["id"] for k in ("axes", "skeleton_nodes", "conditional_framework") for x in arch.get(k, [])}
    for key, want in (("functions", fn_ids), ("problems", prob_ids), ("architecture", arch_ids)):
        have = [e.get("id") for e in led.get(key, [])]
        if _dups(have) or set(have) != want:
            err("ledger_ids", f"{key}: missing={sorted(want - set(have))[:5]} extra={sorted(set(have) - want)[:5]} dup={_dups(have)}")
    for key in ("functions", "problems", "architecture"):
        for e in led.get(key, []):
            lvl = e.get("target_level", e.get("control_level"))
            if lvl not in LEVELS:
                err("ledger_level", f"{e.get('id')}: level {lvl}")
            if e.get("status") not in STATUSES:
                err("ledger_status", f"{e.get('id')}: status {e.get('status')}")
            if not e.get("acceptance"):
                err("ledger_acceptance", f"{e.get('id')}: no acceptance")
            if e.get("status") == "ACCEPTED" and not e.get("evidence"):
                err("ledger_evidence", f"{e.get('id')}: ACCEPTED without evidence")
    ids = {e.get("id") for k in ("functions", "architecture") for e in led.get(k, [])}
    for e in led.get("functions", []):
        if e.get("ruling") == "MERGE_INTO" and e.get("merged_into") not in ids:
            err("ledger_merge", f"{e.get('id')}: merge target {e.get('merged_into')} not found")
    inc_ids = {i.get("id") for i in led.get("realization_plan", {}).get("increments", [])}
    for r in led.get("closure_matrix", {}).get("rows", []):
        if r.get("status") == "GAP" and r.get("realize") not in inc_ids:
            err("ledger_closure", f"GAP row without a planned increment: {r.get('scenario')}")
    for key in ("functions", "problems", "architecture"):
        for e in led.get(key, []):
            if e.get("status") == "PLANNED" and e.get("realize") not in inc_ids and e.get("ruling") != "MERGE_INTO":
                err("ledger_closure", f"{e.get('id')}: PLANNED without a planned increment")
    gates = {g.get("stage"): g for g in led.get("stage_gates", [])}
    if tuple(g.get("stage") for g in led.get("stage_gates", [])) != STAGES:
        err("ledger_gates", "stage_gates must list the four stages in order")
    prev_ok = True
    for st in STAGES:
        g = gates.get(st, {})
        if g.get("status") == "PASSED":
            if not prev_ok:
                err("ledger_gates", f"{st} PASSED while previous stage is not PASSED")
            if not g.get("evidence") or not g.get("reviewer"):
                err("ledger_gates", f"{st} PASSED without evidence/reviewer")
        prev_ok = g.get("status") == "PASSED"


LAYERS = {"runtime": set(), "adapters": {"runtime"}, "tools": {"runtime", "tools"}, "tests": {"runtime", "adapters", "tools", "tests"}}
STRAY = (".foravar_snap",)  # ERROR: release_txn snapshot dir left behind by stage_gate
STRAY_RE = re.compile(r"(^HANDOFF.*\.md$|\.zip$)")
CACHE = ("__pycache__", ".git")  # INFO only: normal in a working tree, delete before packaging


INTEGRATORS = {"runtime/foravar_vertical_slice.py", "runtime/loop_controller.py"}  # the only runtime modules that may wire others
SHARED = "runtime/common.py"
LAYER_EDGES = {"tools/final_test_run.py": {"adapters/model_adapter.py"}}  # FINAL_TEST runner exercises the adapter pack (B24.3); only edge out of the tools layer into adapters
ALLOWED_EDGES = {"runtime/state_bundle.py": {"runtime/release_txn.py"},  # storage composition, deliberate; add here only with a recorded reason
                 # LT-20 (CL-033): slice stage modules. Each may import only its own gate(s) and stage_common; never another stage.
                 "runtime/stage_common.py": {"runtime/content_guard.py"},
                 "runtime/stage_frame.py": {"runtime/frame_gate.py", "runtime/stage_common.py"},
                 "runtime/stage_evidence.py": {"runtime/error_exits.py", "runtime/evidence_gate.py", "runtime/stage_common.py"},
                 "runtime/stage_model.py": {"runtime/model_gate.py", "runtime/stage_common.py"},
                 "runtime/stage_route.py": {"runtime/stage_common.py"},
                 "runtime/stage_authorize.py": {"runtime/policy_gate.py", "runtime/stage_common.py"},
                 "runtime/stage_cancel.py": {"runtime/stage_common.py"},
                 "runtime/stage_execute.py": {"runtime/run_record.py", "runtime/stage_common.py"},
                 "runtime/stage_evaluate.py": {"runtime/evidence_gate.py", "runtime/stage_common.py"},
                 "runtime/stage_synthesis.py": {"runtime/synthesis_gate.py", "runtime/stage_common.py"},
                 "runtime/stage_feedback.py": {"runtime/common.py", "runtime/evidence_gate.py", "runtime/stage_common.py"}}


def check_architecture(root: str, err: Any) -> None:
    graph = import_graph(root)
    for src, deps in graph.items():
        for dep in sorted(deps):
            if dep in LAYER_EDGES.get(src, set()):
                continue
            if dep.split("/")[0] not in LAYERS[src.split("/")[0]] | {src.split("/")[0]}:
                err("layering", f"{src} imports {dep} (layer {src.split('/')[0]} may only use {sorted(LAYERS[src.split('/')[0]])})")
    for src, deps in graph.items():  # runtime_coupling: gates/leaves stay independent; only integrators wire modules together
        if src.startswith("runtime/") and src not in INTEGRATORS:
            extra = sorted(d for d in deps if d.startswith("runtime/") and d != SHARED and d not in ALLOWED_EDGES.get(src, set()))
            if extra:
                err("runtime_coupling", f"{src} imports {extra}; non-integrator runtime modules may import only {SHARED} (or an ALLOWED_EDGES entry)")
    state: dict[str, int] = {}

    def visit(n: str, stack: list[str]) -> None:
        if state.get(n) == 2:
            return
        if state.get(n) == 1:
            err("import_cycle", " -> ".join(stack[stack.index(n):] + [n]))
            return
        state[n] = 1
        for d in sorted(graph.get(n, ())):
            if d.startswith("runtime/"):
                visit(d, stack + [n])
        state[n] = 2
    for n in sorted(graph):
        if n.startswith("runtime/"):
            visit(n, [])


def check_package(root: str, err: Any, info: Any) -> None:
    unreadable: list[str] = []
    caches: set[str] = set()
    for base, dirs, files in os.walk(root):
        for name in list(dirs) + files:
            rel = os.path.relpath(os.path.join(base, name), root)
            if name in STRAY or STRAY_RE.search(name):
                err("stray_artifact", f"{rel} must not ship in the repo package")
            elif name in CACHE or name.endswith(".pyc"):
                if name in CACHE or name.endswith(".pyc"):
                    caches.add(rel.split(os.sep)[0] + "/" + (rel.split(os.sep)[1] if os.sep in rel else ""))
        for name in files:
            path = os.path.join(base, name)
            mode = os.stat(path).st_mode
            rel = os.path.relpath(path, root)
            if mode & 0o002:
                err("file_mode", f"{rel} is world-writable")
            elif not mode & 0o044 == 0o044:
                unreadable.append(rel)
        dirs[:] = [d for d in dirs if d not in STRAY and d not in CACHE]
    if caches:
        info("stray_artifact", f"cache files present in {sorted(caches)[:4]} (delete before packaging)")
    if unreadable:
        info("file_mode", f"{len(unreadable)} files not group/other readable (chmod 644 before packaging): {unreadable[:3]}")


def check_ledger_counts(led: Any, err: Any) -> None:
    """counts block must equal what the rows say (it silently went stale once)."""
    if not led:
        return
    c, rows = led.get("counts", {}), lambda k: led.get(k, [])
    cnt = lambda k, f: dict(collections.Counter(x.get(f) for x in rows(k)))  # noqa: E731
    want = {"functions": len(rows("functions")), "problems": len(rows("problems")), "architecture": len(rows("architecture")),
            "function_ruling": cnt("functions", "ruling"), "function_target_level": cnt("functions", "target_level"),
            "function_status": cnt("functions", "status"), "problem_status": cnt("problems", "status")}
    for k, v in want.items():
        if k in c and c[k] != v:
            err("ledger_counts", f"counts.{k}={c[k]} but rows give {v}")


def check_sync(root: str, err: Any) -> None:
    """Derived bookkeeping (tools/sync_docs.py) and per-file blast ceilings (docs/features.json)."""
    if not os.path.exists(os.path.join(root, "docs", "features.json")):
        err("features", "docs/features.json missing")
        return
    from sync_docs import blast_over, drift
    for line in drift(root):
        err("sync_drift", f"{line} (run: python tools/sync_docs.py --write)")
    for line in blast_over(root):
        err("blast_ceiling", f"{line} (a change widened this file's reach; decouple it or raise the ceiling with a reason in the handoff)")


def check_drift(root: str, bp: Any, led: Any, err: Any) -> None:
    mat = (bp or {}).get("maturity", {})
    slice_path = os.path.join(root, "runtime", "foravar_vertical_slice.py")
    if os.path.exists(slice_path):
        ver = None
        for name in ("foravar_vertical_slice.py", "stage_common.py"):  # LT-20: the constant moved to stage_common; keep the drift guard alive
            with open(os.path.join(root, "runtime", name), encoding="utf-8") as fh:
                ver = ver or re.search(r'IMPLEMENTATION_VERSION = "([\d.]+)"', fh.read()) if os.path.exists(os.path.join(root, "runtime", name)) else ver
        mv = re.search(r"\(([\d.]+):", str(mat.get("runtime/foravar_vertical_slice.py", "")))
        if ver and mv and ver.group(1) != mv.group(1):
            err("maturity_drift", f"slice version {ver.group(1)} but maturity says {mv.group(1)}")
    ad = os.path.join(root, "adapters", "model_adapter.py")
    if led and os.path.exists(ad):
        with open(ad, encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        stages: set[str] = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign) and any(getattr(t, "id", "") == "TEMPLATES" for t in node.targets) and isinstance(node.value, ast.Dict):
                stages = {k.value for k in node.value.keys if isinstance(k, ast.Constant)}
        for key in ("functions", "architecture"):
            for e in led.get(key, []):
                st = e.get("adapter_stage")
                if st and stages and st not in stages:
                    err("adapter_stage", f"{e.get('id')}: adapter_stage '{st}' has no template in adapters/model_adapter.py")


def check(root: str) -> dict[str, Any]:
    f: list[dict[str, str]] = []
    err = lambda c, d: f.append({"level": "ERROR", "check": c, "detail": d})  # noqa: E731
    info = lambda c, d: f.append({"level": "INFO", "check": c, "detail": d})  # noqa: E731
    docs = {n: _load(root, n, f) for n in DOCS}

    cap, prob, idx, bp = (docs[n] for n in ("capability_registry.json", "problem_register.json", "index.json", "blueprint.json"))
    cap_ids = [i.get("id") for i in (cap or {}).get("items", [])]
    prob_ids = [i.get("id") for i in (prob or {}).get("items", [])]
    for label, ids in (("capability", cap_ids), ("problem", prob_ids)):
        if _dups(ids):
            err("id_unique", f"duplicate {label} ids: {_dups(ids)}")
    snap = (idx or {}).get("integrity_snapshot", {})
    for label, ids, key in (("capability", cap_ids, "capability_items"), ("problem", prob_ids, "problem_items")):
        if idx and snap.get(key) != len(ids):
            err("index_counts", f"index {key}={snap.get(key)} but registry has {len(ids)} {label} items")

    check_ledger(docs.get("progress_ledger.json"), cap, prob, bp, err)
    led = docs.get("progress_ledger.json")
    if led:
        bad = [f"{i.get('id')}: {why}" for reg in (cap, prob) for i in (reg or {}).get("items", [])
               if (why := _bad_ledger_ref(i, led))]
        if bad:
            err("ledger_ref", f"{len(bad)} unresolved ledger_ref (registry/problem): {bad[:5]}")

    check_ledger_counts(led, err)
    check_drift(root, bp, led, err)
    check_sync(root, err)
    check_architecture(root, err)
    for c, d in guard_rules.findings(root, led):
        err(c, d)
    check_package(root, err, info)

    readme_path = os.path.join(root, "README.md")
    readme = ""
    if os.path.exists(readme_path):
        with open(readme_path, encoding="utf-8") as fh:
            readme = fh.read()
    if not readme:
        err("readme", "README.md missing or empty")
    refs = set(PATH_RE.findall(readme)) | set(PATH_RE.findall(json.dumps(idx or {}, ensure_ascii=False)))
    for ref in sorted(refs):
        if not os.path.exists(os.path.join(root, ref)):
            err("local_ref", f"referenced path does not exist: {ref}")
    for folder in ("runtime", "tests", "adapters", "tools"):
        d = os.path.join(root, folder)
        for name in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if name.endswith(".py") and not name.startswith("__") and f"{folder}/{name}" not in readme:
                err("readme_listing", f"{folder}/{name} not listed in README")

    statuses = set((bp or {}).get("runtime_contract", {}).get("statuses", []))
    code_path = os.path.join(root, "runtime", "foravar_vertical_slice.py")
    if statuses and os.path.exists(code_path):
        with open(code_path, encoding="utf-8") as fh:
            src = fh.read()
        used = set(re.findall(r'_early\(\s*"([A-Z_]+)"', src)) | set(re.findall(r'status = "([A-Z_]+)"', src))
        used |= {s for s in KNOWN_EXTRA_STATUSES if f'"{s}"' in src}
        for s in sorted(used - statuses):
            (info if s in KNOWN_EXTRA_STATUSES else err)("status_vocab", f"code status '{s}' not in blueprint runtime_contract.statuses" + (" (known F5 deviation)" if s in KNOWN_EXTRA_STATUSES else ""))
    return {"errors": sum(x["level"] == "ERROR" for x in f), "info": sum(x["level"] == "INFO" for x in f),
            "findings": f, "ids_checked": {"capability": len(cap_ids), "problem": len(prob_ids)}}


if __name__ == "__main__":
    report = check(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(1 if report["errors"] else 0)
