"""Restore drill (B24 C2; PR-026, known trade-off 3). Proves a snapshot directory can really restore.

  python tools/restore_drill.py SNAP_DIR [ROOT]      exit 1 on any problem

SNAP_DIR is either one release_txn snapshot (has manifest.json) or a parent holding several
(``ckpt-NNNN`` from loop_controller, ``gate_*`` from stage_gate). Per snapshot: every pre-change file exists and
matches its recorded hash (release_txn.restore_drill). Across ckpt-NNNN: each ``after`` must equal the next
``before`` for shared files (a break means something outside the transactions touched the state). With ROOT:
live files are classified against the newest snapshot (PARTIAL = problem), then the whole chain is rolled back
newest-to-oldest on a scratch copy; every step must verify. ROOT and SNAP_DIR are never modified.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import sys
import tempfile
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "runtime"))

import release_txn  # noqa: E402

CKPT = re.compile(r"^ckpt-(\d{4,})$")


def discover(snap_dir: str) -> list[str]:
    """Snapshot dirs under snap_dir (or snap_dir itself), ckpt-NNNN in numeric order, others by name first."""
    if os.path.isfile(os.path.join(snap_dir, "manifest.json")):
        return [snap_dir]
    kids = [os.path.join(snap_dir, n) for n in sorted(os.listdir(snap_dir))
            if os.path.isfile(os.path.join(snap_dir, n, "manifest.json"))] if os.path.isdir(snap_dir) else []
    ck = sorted((k for k in kids if CKPT.match(os.path.basename(k))), key=lambda k: int(CKPT.match(os.path.basename(k)).group(1)))
    return [k for k in kids if k not in ck] + ck


def _manifest(d: str) -> dict[str, Any] | None:
    try:
        with open(os.path.join(d, "manifest.json"), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _chain_problems(ckpts: list[str]) -> list[str]:
    out: list[str] = []
    last: dict[str, Any] = {}  # rel -> (after hash, snapshot name) from the previous committed ckpt
    for d in ckpts:
        m = _manifest(d)
        if not m or m.get("state") != "COMMITTED":
            continue
        for rel, info in m["files"].items():
            if rel in last and last[rel][0] != info["before"]:
                out.append(f"chain break: {rel} changed between {last[rel][1]} and {os.path.basename(d)}")
            last[rel] = (info["after"], os.path.basename(d))
    return out


def _rehearse(root: str, snaps: list[str]) -> list[str]:
    """Roll the whole chain back on a scratch copy; every step must verify. Only committed snapshots are rolled back."""
    problems: list[str] = []
    with tempfile.TemporaryDirectory() as scratch:
        sroot, ssnap = os.path.join(scratch, "root"), os.path.join(scratch, "snap")
        os.makedirs(sroot)
        for d in snaps:
            shutil.copytree(d, os.path.join(ssnap, os.path.basename(d)))
            for rel in (_manifest(d) or {}).get("files", {}):
                src = os.path.join(root, rel)
                if os.path.isfile(src):
                    os.makedirs(os.path.dirname(os.path.join(sroot, rel)), exist_ok=True)
                    shutil.copyfile(src, os.path.join(sroot, rel))
        for d in reversed(snaps):
            m = _manifest(d)
            if not m or m.get("state") != "COMMITTED":
                continue
            try:
                out = release_txn.rollback(sroot, os.path.join(ssnap, os.path.basename(d)))
            except Exception as exc:  # noqa: BLE001 - a drill reports, never raises
                problems.append(f"{os.path.basename(d)}: rollback raised {type(exc).__name__}: {exc}")
                continue
            if not out.get("rollback_verified"):
                problems.append(f"{os.path.basename(d)}: rollback not verified")
    return problems


def drill(snap_dir: str, root: str | None = None) -> dict[str, Any]:
    snaps = discover(snap_dir)
    report: dict[str, Any] = {"snapshots": [], "chain_problems": [], "rehearsal_problems": [], "ok": False}
    if not snaps:
        report["problems"] = ["no snapshot found"]
        return report
    for d in snaps:
        entry: dict[str, Any] = {"dir": os.path.basename(d.rstrip("/")) or d, "state": None, "problems": [], "live": None}
        try:
            entry["state"] = release_txn._load(d)["state"]
            entry["problems"] = release_txn.restore_drill(d)
        except release_txn.TxnError as exc:
            entry["problems"] = [str(exc)]
        report["snapshots"].append(entry)
    ckpts = [d for d in snaps if CKPT.match(os.path.basename(d))]
    report["chain_problems"] = _chain_problems(ckpts)
    if root is not None:
        newest = report["snapshots"][-1]
        try:
            newest["live"] = release_txn.classify(root, snaps[-1])
        except release_txn.TxnError as exc:
            newest["problems"].append(str(exc))
        if newest["live"] == "PARTIAL":
            newest["problems"].append("live files match neither before nor after (PARTIAL); run release_txn.recover")
        report["rehearsal_problems"] = _rehearse(root, snaps)
    report["ok"] = not (report["chain_problems"] or report["rehearsal_problems"] or any(s["problems"] for s in report["snapshots"]))
    return report


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: restore_drill.py SNAP_DIR [ROOT]")
    rep = drill(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    sys.exit(0 if rep["ok"] else 1)
