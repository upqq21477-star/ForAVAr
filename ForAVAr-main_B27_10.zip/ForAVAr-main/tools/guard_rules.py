"""Static guard rules (K2): derived from the source, nothing typed by hand. Read-only; stdlib only; tools layer.

  dynamic_import  runtime/ may not use importlib / __import__ / exec / eval (the import graph is static, so coupling stays visible).
  entry_guard     run_vertical_slice may be referenced outside tests only by ENTRY_ALLOWED (new call sites need a recorded reason).
  ledger_ruling   every function row carries a ruling (ADOPT / MERGE_INTO / DEFER): reuse-or-merge is decided, never implied.
  change_log      docs/change_log.json (append-only update log): every mechanism in features.json is covered by an entry; each entry states
                  need / owner (existing file or mechanism) / ruling / change / why / not_this and a closed replan; supersession links resolve.
                  From CL-011 on each entry also carries echelon_check (blueprint echelons): E1-E3 simulated checks recorded PASS or NOT_APPLICABLE
                  with a note, and E4 (real run) NOT_TRIGGERED / PENDING_REAL_RUN / DONE_REAL; NOT_TRIGGERED is refused when replan.scope touches
                  the frozen set (final_test_run FROZEN_DIRS / FROZEN_FILES, read by ast).
                  Form only: it cannot judge the quality of the reasons, nor prove the log was written before the code, nor that a recorded PASS was earned.
check_consistency calls ``findings(root, ledger)`` and reports each tuple as an ERROR.
"""
from __future__ import annotations

import ast
import json
import os
import posixpath
import re
from typing import Any

ENTRY = "run_vertical_slice"
ENTRY_ALLOWED = {  # integrator and the FINAL_TEST runners; the slice defines it. Add here only with a reason in the handoff.
    "runtime/foravar_vertical_slice.py", "runtime/loop_controller.py", "tools/final_test_run.py", "tools/final_test_harness.py",
}
RULINGS = {"ADOPT", "MERGE_INTO", "DEFER"}
DYNAMIC_CALLS = {"__import__", "exec", "eval"}
LOG_RULINGS = {"ADOPT", "MERGE_INTO", "NEW", "NO_CHANGE"}  # reuse as is / fold into owner / new responsibility (reason in need) / nothing to do
LOG_STATUS = {"ACCEPTED", "SUPERSEDED"}
LOG_TEXT = ("need", "change", "why")
ECHELON_FROM = 11  # entries CL-011 and later must carry echelon_check; earlier entries predate the rule (blueprint echelons, CL-011)
ECHELON_SIM = ("E1", "E2", "E3")  # simulated echelons: only PASS or NOT_APPLICABLE can be recorded (a failing check blocks closing the replan)
SIM_RESULTS = {"PASS", "NOT_APPLICABLE"}
E4_RESULTS = {"NOT_TRIGGERED", "PENDING_REAL_RUN", "DONE_REAL"}


def _trees(root: str, folders: tuple[str, ...]) -> dict[str, ast.AST]:
    out: dict[str, ast.AST] = {}
    for folder in folders:
        d = os.path.join(root, folder)
        for n in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if n.endswith(".py"):
                try:
                    with open(os.path.join(d, n), encoding="utf-8") as fh:
                        out[f"{folder}/{n}"] = ast.parse(fh.read())
                except (OSError, SyntaxError):
                    continue
    return out


def dynamic_import(root: str) -> list[tuple[str, str]]:
    res = []
    for rel, tree in _trees(root, ("runtime",)).items():
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in DYNAMIC_CALLS:
                res.append(("dynamic_import", f"{rel}:{node.lineno} calls {node.func.id}()"))
            elif isinstance(node, ast.Import) and any(a.name.split(".")[0] == "importlib" for a in node.names):
                res.append(("dynamic_import", f"{rel}:{node.lineno} imports importlib"))
            elif isinstance(node, ast.ImportFrom) and (node.module or "").split(".")[0] == "importlib":
                res.append(("dynamic_import", f"{rel}:{node.lineno} imports from importlib"))
    return res


def entry_guard(root: str) -> list[tuple[str, str]]:
    res = []
    for rel, tree in _trees(root, ("runtime", "adapters", "tools")).items():
        if rel in ENTRY_ALLOWED:
            continue
        for node in ast.walk(tree):
            hit = (isinstance(node, ast.Name) and node.id == ENTRY) or (isinstance(node, ast.Attribute) and node.attr == ENTRY) or \
                  (isinstance(node, ast.ImportFrom) and any(a.name == ENTRY for a in node.names))
            if hit:
                res.append(("entry_guard", f"{rel}:{node.lineno} references {ENTRY}; allowed only in {sorted(ENTRY_ALLOWED)}"))
                break
    return res


def ledger_ruling(led: Any) -> list[tuple[str, str]]:
    return [("ledger_ruling", f"{e.get('id')}: ruling {e.get('ruling')!r} not in {sorted(RULINGS)}")
            for e in (led or {}).get("functions", []) if e.get("ruling") not in RULINGS]


def _json(root: str, rel: str) -> Any:
    try:
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _frozen(root: str) -> tuple[tuple[str, ...], tuple[str, ...]] | None:
    """FROZEN_DIRS / FROZEN_FILES as written in tools/final_test_run.py (ast; nothing typed here)."""
    try:
        with open(os.path.join(root, "tools", "final_test_run.py"), encoding="utf-8") as fh:
            tree = ast.parse(fh.read())
        got = {t.id: ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign) for t in n.targets
               if isinstance(t, ast.Name) and t.id in ("FROZEN_DIRS", "FROZEN_FILES")}
        return (tuple(got["FROZEN_DIRS"]), tuple(got["FROZEN_FILES"]))
    except (OSError, SyntaxError, ValueError, KeyError, TypeError):
        return None


def _norm(x: str) -> str:
    return posixpath.normpath(x.replace("\\", "/")).lstrip("/").casefold()


def _touches_frozen(scope: list[Any], fz: tuple[tuple[str, ...], tuple[str, ...]]) -> list[str]:
    """Scope entries that are, sit under, or contain (a parent directory of) a frozen file. Paths are normalised (./, ../, //, case, leading /);
    a bare directory such as 'runtime' or 'tools' counts as touching, because it contains frozen files (conservative: may over-report)."""
    dirs, files = (tuple(_norm(x) for x in part) for part in fz)
    out = []
    for x in scope:
        if not isinstance(x, str) or not x.strip():
            continue
        p = _norm(x)
        under = any(p.startswith(d + "/") and p.endswith(".py") for d in dirs)
        contains = p == "." or any(f == p or f.startswith(p + "/") for f in (*files, *dirs))
        if under or contains:
            out.append(x)
    return out


def _echelon_check(e: dict[str, Any], root: str, bad: Any) -> None:
    ec = e.get("echelon_check")
    if not isinstance(ec, dict):
        bad("echelon_check missing (CL-011 and later): record E1-E3 (PASS / NOT_APPLICABLE + note) and E4 (NOT_TRIGGERED / PENDING_REAL_RUN / DONE_REAL + note)")
        return
    if set(ec) != {*ECHELON_SIM, "E4"}:
        bad(f"echelon_check keys must be exactly E1, E2, E3, E4 (got {sorted(ec)})")
        return
    for k in (*ECHELON_SIM, "E4"):
        row = ec[k]
        allowed = SIM_RESULTS if k in ECHELON_SIM else E4_RESULTS
        if not (isinstance(row, dict) and row.get("result") in allowed):
            bad(f"echelon_check.{k}.result must be one of {sorted(allowed)}")
            continue
        if not (isinstance(row.get("note"), str) and row["note"].strip()):
            bad(f"echelon_check.{k}.note must say what was checked (or why not applicable)")
        if row.get("result") == "DONE_REAL" and not (isinstance(row.get("evidence"), str) and row["evidence"].strip()):
            bad("echelon_check.E4 DONE_REAL needs evidence (pointer to the real-run result)")
    e4 = ec["E4"]
    if isinstance(e4, dict) and e4.get("result") == "NOT_TRIGGERED":
        rp = e.get("replan")
        scope = rp.get("scope") if isinstance(rp, dict) and isinstance(rp.get("scope"), list) else []
        fz = _frozen(root)
        if fz is None:
            bad("cannot derive the frozen set from tools/final_test_run.py, so E4 NOT_TRIGGERED cannot be checked")
        else:
            hit = _touches_frozen(scope, fz)
            if hit:
                bad(f"echelon_check.E4 NOT_TRIGGERED but replan.scope touches the frozen set {hit}: the freeze fingerprint changes, so a real run is pending (PENDING_REAL_RUN)")


def change_log(root: str) -> list[tuple[str, str]]:
    log = _json(root, "docs/change_log.json")
    entries = log.get("entries") if isinstance(log, dict) else None
    if not isinstance(entries, list) or not entries:
        return [("change_log", "docs/change_log.json missing, unreadable or has no entries")]
    feats = _json(root, "docs/features.json")
    mech = set((feats or {}).get("mech", {})) if isinstance(feats, dict) else set()
    res: list[tuple[str, str]] = []
    ids = [e.get("id") for e in entries if isinstance(e, dict)]
    covered: set[str] = set()
    for e in entries:
        if not isinstance(e, dict):
            res.append(("change_log", "entry is not an object"))
            continue
        i = e.get("id")
        bad = lambda msg: res.append(("change_log", f"{i}: {msg}"))  # noqa: E731
        if not (isinstance(i, str) and re.fullmatch(r"CL-\d{3}", i)) or ids.count(i) != 1:
            bad("id must be unique and look like CL-001")
        if not (isinstance(e.get("date"), str) and re.fullmatch(r"\d{4}-\d{2}-\d{2}", e["date"])):
            bad("date must be YYYY-MM-DD")
        if e.get("status") not in LOG_STATUS:
            bad(f"status {e.get('status')!r} not in {sorted(LOG_STATUS)}")
        if e.get("status") == "SUPERSEDED" and e.get("superseded_by") not in ids:
            bad("SUPERSEDED needs superseded_by pointing at an existing entry")
        for ref in e.get("supersedes") or []:
            if ref not in ids:
                bad(f"supersedes unknown entry {ref}")
        for k in LOG_TEXT:
            if not (isinstance(e.get(k), str) and e[k].strip()):
                bad(f"{k} must be a non-empty text")
        if not (isinstance(e.get("not_this"), list) and e["not_this"] and all(isinstance(x, str) and x.strip() for x in e["not_this"])):
            bad("not_this must be a non-empty list of texts (what a successor must NOT infer)")
        if e.get("ruling") not in LOG_RULINGS:
            bad(f"ruling {e.get('ruling')!r} not in {sorted(LOG_RULINGS)}")
        live = e.get("status") != "SUPERSEDED"  # a superseded entry is history: it may name files/mechanisms retired since (CL-024)
        owner = e.get("owner")
        if not (isinstance(owner, list) and owner):
            bad("owner must list the existing file(s) or mechanism key(s) that hold the responsibility")
        elif live:
            for o in owner:
                if not (isinstance(o, str) and (o in mech or os.path.isfile(os.path.join(root, o)))):
                    bad(f"owner {o!r} is neither an existing file nor a mechanism key")
        rp = e.get("replan")
        if not (isinstance(rp, dict) and isinstance(rp.get("scope"), list)):
            bad("replan must be {scope: [...], status}")
        elif rp.get("status") != "CLOSED":
            bad(f"replan status {rp.get('status')!r}: close it (scope re-checked at planning criteria, direct tests passed) before verify")
        n = re.fullmatch(r"CL-(\d{3})", i) if isinstance(i, str) else None
        if n and int(n.group(1)) >= ECHELON_FROM:
            _echelon_check(e, root, bad)
        for m in e.get("mechanisms") or []:
            if live and m not in mech:
                bad(f"mechanism {m!r} not in docs/features.json")
            covered.add(m)
    res += [("change_log", f"mechanism {m} has no change-log entry (add one: need / owner / ruling / why)") for m in sorted(mech - covered)]
    return res


def findings(root: str, led: Any) -> list[tuple[str, str]]:
    return dynamic_import(root) + entry_guard(root) + ledger_ruling(led) + change_log(root)
