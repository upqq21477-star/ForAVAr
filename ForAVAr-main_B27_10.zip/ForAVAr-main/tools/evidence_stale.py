"""Evidence staleness (LT-09): after a freeze, which rows must be re-verified because a frozen file changed. Read-only.

A result is bound to the file hashes it was run against (the freeze record). This compares that record with the current
tree, takes the changed files, derives the affected ledger rows through the import graph and the mechanisms the rows cite
(tools/closure_report.py impact, run as a subprocess), and lists the rows whose evidence no longer applies. It never edits the ledger: the
owner downgrades ACCEPTED rows to CONTRACT_TESTED by hand and records E4=PENDING_REAL_RUN in the change log.

  python tools/evidence_stale.py FREEZE_FILE [ROOT]      exit 1 when any frozen file differs from the record
FREEZE_FILE: the record saved by ``final_test_run.py --freeze`` (or just its ``freeze`` block). The current freeze is
produced by running that same command in a subprocess; both helpers are subprocess calls so this tool imports neither the
frozen runner nor closure_report (keeps their blast ceilings unchanged).
Limit: row mapping goes through cited mechanisms; a changed frozen file no mechanism cites has an empty row list but the
version is still stale (the result no longer matches that file set).
"""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from typing import Any

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

ROOT = os.path.join(HERE, "..")
ROW_KINDS = ("architecture", "functions", "problems", "invariants")


def combined(files: dict[str, str]) -> str:
    return hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest()[:16]


def diff_freeze(recorded: dict[str, Any], current: dict[str, Any]) -> dict[str, list[str]]:
    a, b = recorded.get("files") or {}, current.get("files") or {}
    return {"changed": sorted(p for p in set(a) & set(b) if a[p] != b[p]),
            "added": sorted(set(b) - set(a)), "removed": sorted(set(a) - set(b))}


def _run_text(root: str, script: str, *args: str) -> str:
    r = subprocess.run([sys.executable, os.path.join(root, "tools", script), *args], cwd=root, capture_output=True, text=True)
    if r.returncode:
        raise RuntimeError(f"{script} failed: {(r.stdout + r.stderr)[-300:]}")
    return r.stdout


def _run_json(root: str, script: str, *args: str) -> Any:
    return json.loads(_run_text(root, script, *args))


def stale_rows(root: str, files: list[str]) -> dict[str, Any]:
    """Ledger rows touched by changing ``files`` (direct and transitive mechanisms). Impact comes from closure_report in a subprocess."""
    existing = [f for f in files if os.path.exists(os.path.join(root, f))]
    imp = _run_json(root, "closure_report.py", "impact", *existing) if existing else {"mechanisms_direct": [], "mechanisms_indirect": []}
    mechs = set(imp["mechanisms_direct"]) | set(imp["mechanisms_indirect"])
    with open(os.path.join(root, "docs", "progress_ledger.json"), encoding="utf-8") as fh:
        led = json.load(fh)
    rows = [{"id": r["id"], "kind": k, "status": r.get("status", "")}
            for k in ROW_KINDS for r in led.get(k, []) if set(r.get("mechanisms") or []) & mechs]
    return {"mechanisms": sorted(mechs), "rows": rows}


def current_freeze(root: str) -> dict[str, Any]:
    """Current tree's freeze, produced by the runner itself in a subprocess (no import: keeps this tool out of the frozen import graph)."""
    with tempfile.TemporaryDirectory() as tmp:
        out = os.path.join(tmp, "freeze_now.json")
        _run_text(root, "final_test_run.py", "--freeze", out)
        with open(out, encoding="utf-8") as fh:
            rec = json.load(fh)
    return rec.get("freeze", rec)


def evaluate(root: str, record: dict[str, Any], current: dict[str, Any] | None = None) -> dict[str, Any]:
    rec = record.get("freeze", record)
    if not isinstance(rec.get("files"), dict) or not rec["files"]:
        raise ValueError("freeze record has no files block")
    cur = current if current is not None else current_freeze(root)
    d = diff_freeze(rec, cur)
    touched = d["changed"] + d["added"] + d["removed"]
    hit = stale_rows(root, touched) if touched else {"mechanisms": [], "rows": []}
    return {"record_combined": rec.get("combined"), "record_consistent": rec.get("combined") == combined(rec["files"]),
            "current_combined": cur.get("combined"), "version_stale": bool(touched), **d,
            "mechanisms": hit["mechanisms"], "stale_rows": hit["rows"],
            "must_downgrade": [r["id"] for r in hit["rows"] if r["status"] == "ACCEPTED"]}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: evidence_stale.py FREEZE_FILE [ROOT]")
    with open(sys.argv[1], encoding="utf-8") as fh:
        rec = json.load(fh)
    out = evaluate(sys.argv[2] if len(sys.argv) > 2 else ROOT, rec)
    print(json.dumps(out, ensure_ascii=False, indent=2))
    sys.exit(1 if out["version_stale"] or not out["record_consistent"] else 0)
