# FINAL_TEST 執行清單（擁有者用，一頁）

目標：跑真實檢測，把結果交回。**預設走手機路徑（GitHub Actions）**；有電腦才用後段的電腦路徑。只照做，不改程式。
規則：真實運行只在 F2／F3；模擬或 fake 結果不得升 ACCEPTED；凍結後改了 `runtime/`、`adapters/` 或下列 tools 檔 → 重跑 F2。
凍結的 tools 檔：final_test_harness、final_test_samples_v2、confirm_set、final_test_run、llm_backend、backend_profiles.json（只算 protocol／base_url／model／temperature／max_tokens；調 rpm／逾時不算改動）。（`ci_support.py` 與 `.github/` 不在凍結集合。）

**開始前**：B27.8 已重新凍結（建置完成）；最終凍結 combined＝`9395e827c511b366`（梯次四前若再動凍結集合會再變，以 ledger 為準）。OWNER-3：`--freeze` 後核對此值，不符就停下來找接手者。OWNER-1／2（推 GitHub、Secrets）可同時做。

## 凍結規則（完整版見 blueprint echelons.E4.freeze_policy）
- 凍結不是禁止修改，是『改了就作廢重跑』。F2 可修缺陷：重新 --freeze、重跑 F2，最多重新凍結 2 次，超過停下來找擁有者。
- F3 確認集只在 F2 版本定版後產生；第一次 F3 呼叫起不得再改凍結檔或 rubric。看過 F3 結果後改了＝該確認集已污染，需重產。
- 結束：F3 通過並升級 ACCEPTED，或 F3 未通過，或擁有者中止 → 凍結解除（解除後改凍結檔仍須在變更紀錄標 PENDING_REAL_RUN）。

## 手機路徑

### 0 一次性準備（手機瀏覽器開 GitHub 網頁版；找不到按鈕就切「桌面版網站」）
1. 把 repo 推上 GitHub（OD-2），並確認 `.github/workflows/final_test.yml` 在預設分支。若網頁上傳漏掉點開頭的資料夾：Add file → Create new file，檔名欄輸入 `.github/workflows/final_test.yml`，貼上檔案內容。
2. 免費金鑰：受測用 Groq；確認集產生器要**不同家族**（例 Gemini）。Repo → Settings → Secrets and variables → Actions → New repository secret，名稱必須一字不差：`GROQ_API_KEY`、`GEMINI_API_KEY`（可選：`CEREBRAS_API_KEY`、`OPENROUTER_API_KEY`、`NVIDIA_API_KEY`、`ANTHROPIC_API_KEY`）。金鑰不貼進檔案或聊天。
3. 之後每次：Actions → final_test → Run workflow，填欄位。

### F2：v2 樣本 × C0／C1／C2 × 3 次
1. 小試：phase=`f2`、backend=`groq`、repeats=`1`、tag=`v2_trial`（fake 估算 239 次，含 C3 約 76 次；真實模型 C3 會重入，上限約 405 次）。看該次 Summary：第一行 commit、`freeze combined`（記下）、digest。
2. 正式：phase=`f2`、repeats=`3`、tag=`v2_groq`，其餘同上（fake 估算 565 次，含 C3 約 76 次；真實上限約 730 次＝C3 最多 20 樣本×3 次嘗試×4 呼叫＝240，C3 每樣本只跑一次、不隨 repeats 增加；以結果檔 `backend_stats` 為準；額度不夠先跑小試）。
3. 被限流／額度用完而中斷（工作顯示紅色）：用**同一組參數**再按一次 Run workflow，會續跑。續跑時 `expect_combined` 填步驟 1 記下的雜湊，凍結後有人改過程式會被擋。進度快取閒置約 7 天會被 GitHub 清掉；另有 30 天 artifact 備份。
4. 完成後把 Summary 裡 digest 區塊整段貼給接手者（或下載 artifact `data-v2_groq-f2` 的結果檔上傳）。

### F3：確認集（不同家族產生、凍結後再跑）
1. phase=`f3_gen`、backend=`groq`、gen_backend=`gemini`、gen_model=`<非 gpt 系列的模型名>`。工作流程會擋同模型／同名稱家族（以名稱判斷，最終由審查人判斷）。Summary 會列出候選與 run id。
2. 抽查候選字句；只看字句是否合理，真值由程式固定。不合理就重跑步驟 1，不要手改。
3. phase=`f3_run`、backend=`groq`、cand_run_id=`<步驟 1 的 run id>`、repeats=`3`、tag=`v2_confirm`。它會自動凍結確認集、再查一次獨立性、再跑；中斷續跑同 F2。
4. 回傳同 F2 步驟 4。

## 電腦路徑（可選）
環境：Python 3.10+、網路、金鑰放環境變數（名稱見 `tools/backend_profiles.json` 的 `key_env`）。解壓後在根目錄：
```
python tools/standard_verify.py                                    # 必須輸出 OK
python tools/final_test_run.py --freeze data/freeze_B26.json
# F2
python tools/final_test_run.py --backend llm:groq --samples v2 --repeats 3 --resume data/ck_v2_groq.json --out data/result_v2_groq.json
# F3（產生器必須與受測模型不同家族；gemini／openrouter／nvidia 的 profile 沒有預設 model，要 --set）
python tools/confirm_set.py gen --backend llm:gemini --set model=<非 gpt 系列> --per-kind 3 --out data/cand.json
python tools/confirm_set.py freeze data/cand.json --out data/confirm_frozen.json
python tools/final_test_run.py --backend llm:groq --samples confirm --confirm-file data/confirm_frozen.json --repeats 3 --resume data/ck_confirm.json --out data/result_confirm.json
python tools/result_digest.py data/result_*.json --freeze-file data/freeze_B26.json
```
先小試用 `--repeats 1` 並另用檔名；中斷時同一指令重跑即續跑。換模型：`--set model=...`，結果另存新檔名。

## 手動模式（不需金鑰，可隨時做）
`python tools/manual_eval.py packets --out packets.md` → 每個條件開新對話、貼封包、記錄回答 → `python tools/manual_eval.py score answers.txt --out result_manual.json`

## 凍結後改了檔（ACCEPTED 之後）
`python tools/evidence_stale.py data/freeze_B26.json` → 列出變更檔、受影響機制與列、須降級的 ACCEPTED 列（唯讀，不改 ledger）。

## 結果怎麼讀
摘要含：`decision`、`report`、失敗樣本、弱項 kind、`axis_comparison`、`stability`、`backend_stats`、警示。
- `closed_loop`（C3，每樣本一次）：`gate` 必須 PASS（無失控出口、無未授權副作用）；只驗迴圈紀律，不驗修復品質；`flips_vs_c2` 交 F3 審查人。`axis_comparison`、`stability` 只回報，不進通過判定；`rework_saved` 要大於 `human_turns_c2a` 才值得（F3 審查人判斷）。
- 結果檔 `evidence_class`＝`REAL_RUN_UNREVIEWED`，F3 獨立審查（OD-5）通過前不升任何狀態。
