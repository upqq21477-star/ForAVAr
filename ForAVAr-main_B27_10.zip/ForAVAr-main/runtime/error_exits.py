"""Runtime error exits (blueprint architecture.closed_loop.error_exits; R6).

Every adapter exception, contract violation, bad input, persistence failure or change-set
mismatch becomes a named terminal status + feedback action + failure_class + error receipt.
Nothing here retries; the loop controller (R7) consumes ``feedback.action``.
Stdlib only.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

# event key -> (terminal status, feedback action, failure_class). Mirrors blueprint error_exits.
ERROR_EXITS: dict[str, tuple[str, str, str]] = {
    "TASK_INVALID": ("BLOCKED", "FIX_TASK_INPUT", "GOAL_OR_SEMANTIC_ERROR"),
    "ADAPTER_FAULT": ("FAILED", "FIX_OR_REPLACE_ADAPTER", "TOOL_OR_ADAPTER_ERROR"),
    "EXECUTE_FAULT_UNKNOWN_EFFECT": ("INCONCLUSIVE", "INSPECT_ACTUAL_STATE_BEFORE_RETRY", "TOOL_OR_ADAPTER_ERROR"),
    "EXECUTE_FAULT_NO_EFFECT": ("FAILED", "CLASSIFY_FAILURE_BEFORE_RETRY", "TOOL_OR_ADAPTER_ERROR"),
    "EVALUATE_FAULT": ("NOT_PROVEN", "RERUN_EVALUATION_ONLY", "ACCEPTANCE_OR_MEASUREMENT_ERROR"),
    "AUTHORIZATION_FAULT": ("BLOCKED", "STOP_AND_REQUEST_AUTHORIZATION", "AUTHORIZATION_OR_POLICY_BLOCK"),
    "PERSISTENCE_FAULT": ("BLOCKED", "ROLLBACK_AND_REPORT", "PERSISTENCE_OR_STATE_ERROR"),
    "CHANGE_SET_MISMATCH": ("BLOCKED", "RESTORE_AND_REPLAN", "INTEGRATION_OR_DEPENDENCY_UPDATE_ERROR"),
    "EVIDENCE_CONFLICT_OR_STALE": ("PARTIAL", "RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE", "SOURCE_OR_EVIDENCE_ERROR"),
}

STAGE_EVENT = {"task": "TASK_INVALID", "frame": "ADAPTER_FAULT", "evidence": "ADAPTER_FAULT", "model": "ADAPTER_FAULT", "synthesis": "ADAPTER_FAULT",
               "route": "ADAPTER_FAULT", "evaluate": "EVALUATE_FAULT"}


def exit_for(event: str) -> tuple[str, str, str]:
    if event not in ERROR_EXITS:
        raise KeyError(f"unknown error event: {event}")
    return ERROR_EXITS[event]


def error_receipt(stage: str, exc: BaseException) -> dict[str, str]:
    """Bounded, serialisable description of the fault (never the traceback)."""
    return {"stage": stage, "type": type(exc).__name__, "message": str(exc)[:300]}


def envelope(task_id: str, event: str, reason: str, *, stage: str = "", receipt: Mapping[str, Any] | None = None,
             **extra: Any) -> dict[str, Any]:
    status, action, failure_class = exit_for(event)
    out: dict[str, Any] = {
        "task_id": task_id, "status": status, "event": event, "failure_class": failure_class,
        "feedback": {"action": action, "reason": reason},
        "error": dict(receipt) if receipt else {"stage": stage, "type": "", "message": reason[:300]},
    }
    out.update(extra)
    return out


def evidence_envelope(task_id: str, reason: str, *, hard_block: bool, **extra: Any) -> dict[str, Any]:
    """Row 9: unresolved conflict / STALE evidence -> PARTIAL, or BLOCKED for high-risk / side-effecting work."""
    out = envelope(task_id, "EVIDENCE_CONFLICT_OR_STALE", reason, stage="evidence_gate", **extra)
    if hard_block:
        out["status"] = "BLOCKED"
    return out


def persistence_guard(task_id: str, fn, *args: Any, **kwargs: Any) -> dict[str, Any]:
    """Run a persist/txn call; success -> {'status':'PERSISTED', 'result':...}; any failure -> PERSISTENCE_FAULT.

    release_txn restores snapshots on failure, so the envelope reports a rolled-back state.
    """
    try:
        return {"status": "PERSISTED", "task_id": task_id, "result": fn(*args, **kwargs)}
    except Exception as exc:  # noqa: BLE001 - every failure must surface as a named exit
        return envelope(task_id, "PERSISTENCE_FAULT", f"state write failed ({type(exc).__name__}); transaction rolled back",
                        stage="persist", receipt=error_receipt("persist", exc), rolled_back=True)


def change_set_guard(task_id: str, plan: Mapping[str, Any], actually_changed: Iterable[str]) -> dict[str, Any]:
    """Compare real writes with the planned change set (rule 3); mismatch -> CHANGE_SET_MISMATCH."""
    try:
        extra = sorted(set(actually_changed) - set(plan["allowed_to_change"]))
    except Exception as exc:  # noqa: BLE001
        return envelope(task_id, "CHANGE_SET_MISMATCH", f"change set unreadable ({type(exc).__name__})",
                        stage="change_set", receipt=error_receipt("change_set", exc), unexpected=[])
    if not extra:
        return {"status": "WITHIN_PLAN", "task_id": task_id, "unexpected": []}
    return envelope(task_id, "CHANGE_SET_MISMATCH", f"changed outside plan: {extra}", stage="change_set", unexpected=extra)
