"""Stage FRAME (N02-N03): adapter frame, contract checks, optional frame gate (R4). Body moved verbatim from the slice."""
from __future__ import annotations

from typing import Any

try:
    from .frame_gate import assess_frame
    from .stage_common import ContractError, _bind_task, _call, _early, _text, Run
except ImportError:  # direct imports when runtime/ is on sys.path
    from frame_gate import assess_frame
    from stage_common import ContractError, _bind_task, _call, _early, _text, Run


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, ctx, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.ctx, r.trace
    ctx["stage"] = "frame"
    frame = _call(adapters, "frame", task_obj)
    trace.append("FRAME")
    ctx["frame"] = frame
    _bind_task(frame, task_id, "frame")
    frame_status = frame.get("status")
    if frame_status != "READY":
        status = "BLOCKED" if frame_status == "BLOCKED" else "NOT_PROVEN"
        return _early(status, task_id, trace, str(frame.get("reason", "problem framing is incomplete")), frame=frame)
    _text(frame.get("frame_id"), "frame.frame_id")
    _text(frame.get("problem_statement"), "frame.problem_statement")
    for key in ("in_scope", "out_of_scope", "unknowns"):
        if not isinstance(frame.get(key), list):
            raise ContractError(f"frame.{key} must be a list")
    frame_gate: dict[str, Any] | None = None
    if profile.get("frame_gate") is True:  # R4 (opt-in): boundary/dependency/competing-frame completeness
        frame_gate = assess_frame(profile, frame)
        ctx["frame_gate"] = frame_gate
        trace.append("FRAME_GATE")
        if not frame_gate["ok"]:
            reason = "frame incomplete: " + "; ".join(x["rule"] for x in frame_gate["violations"])
            return _early(frame_gate["status"], task_id, trace, reason, frame=frame, frame_gate=frame_gate,
                          failure_class="GOAL_OR_SEMANTIC_ERROR")
    r.frame, r.frame_gate = frame, frame_gate
    return None
