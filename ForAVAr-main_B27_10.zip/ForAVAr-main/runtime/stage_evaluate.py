"""Stage EVALUATE (N13): adapter evaluate, criteria normalisation, status, receipt + evidence gate (R8). Moved verbatim (LT-20c)."""
from __future__ import annotations

from typing import Any

try:
    from .evidence_gate import assess as assess_evidence
    from .stage_common import CRITERION_STATES, ContractError, Run, _bind_task, _call, _now, _record, _text, _validate_evidence
except ImportError:  # direct imports when runtime/ is on sys.path
    from evidence_gate import assess as assess_evidence
    from stage_common import CRITERION_STATES, ContractError, Run, _bind_task, _call, _now, _record, _text, _validate_evidence


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, ctx, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.ctx, r.trace
    criteria, evidence, execution, run_record = r.criteria, r.evidence, r.execution, r.run_record
    execution_status = execution.get("status")
    ctx["stage"] = "evaluate"

    evaluation = _call(adapters, "evaluate", task_obj, execution, evidence)
    trace.append("EVALUATION")
    _bind_task(evaluation, task_id, "evaluation")
    raw_results = evaluation.get("criteria_results")
    if not isinstance(raw_results, list):
        raise ContractError("evaluation.criteria_results must be a list")
    results: dict[str, dict[str, Any]] = {}
    required_ids = {c["id"] for c in criteria}
    for i, raw in enumerate(raw_results):
        result = _record(raw, f"evaluation.criteria_results[{i}]")
        criterion_id = _text(result.get("criterion_id"), f"criteria_results[{i}].criterion_id")
        if criterion_id not in required_ids:
            raise ContractError(f"evaluation returned unknown criterion: {criterion_id}")
        if criterion_id in results:
            raise ContractError(f"duplicate evaluation result for criterion: {criterion_id}")
        if result.get("status") not in CRITERION_STATES:
            raise ContractError(f"invalid status for criterion {criterion_id}")
        results[criterion_id] = result

    all_records = list(evidence.get("records", [])) + list(execution.get("evidence_records", []))
    evidence_index = _validate_evidence(all_records, "evidence_records", adapters.get("content_semantic"))
    normalized: list[dict[str, Any]] = []
    for criterion in criteria:
        criterion_id = criterion["id"]
        result = dict(results.get(criterion_id, {"criterion_id": criterion_id, "status": "NOT_RUN", "evidence_ids": []}))
        evidence_ids = result.get("evidence_ids", [])
        if not isinstance(evidence_ids, list) or any(not isinstance(x, str) for x in evidence_ids):
            raise ContractError(f"evidence_ids must be a list of strings for {criterion_id}")
        cited = [evidence_index.get(x) for x in evidence_ids]
        traceable = bool(cited) and all(item is not None and item.get("status") == "OBSERVED" for item in cited)
        required_kinds = set(criterion["required_evidence_kinds"])
        available_kinds = {item.get("kind") for item in cited if item is not None and item.get("status") == "OBSERVED"}
        if result["status"] in {"PASS", "FAIL"} and (not traceable or not required_kinds.issubset(available_kinds)):
            result["status"] = "UNKNOWN"
            result["reason"] = "evaluation claim lacks linked observed evidence of the required kind"
        result["evidence_ids"] = evidence_ids
        normalized.append(result)

    if any(x["status"] == "FAIL" for x in normalized):
        status = "FAILED"
    elif any(x["status"] in {"UNKNOWN", "NOT_RUN"} for x in normalized):
        status = "NOT_PROVEN"
    elif execution_status == "PARTIAL":
        status = "PARTIAL"
    else:
        status = "PASS"
    rr_note = ""
    if status == "PASS" and run_record["required"] and not run_record["complete"]:
        # A receipt is not acceptance, but a required receipt must not be silently missing.
        status = "PARTIAL"
        rr_note = "required run_record incomplete: " + ", ".join(run_record["missing"])
    claims = evaluation.get("conflict_resolutions", [])
    if not isinstance(claims, list):
        raise ContractError("evaluation.conflict_resolutions must be a list")
    # Known trade-off 1 (tests/test_closure_regression test_19): every OBSERVED record is checked, cited or not. Records
    # the validator quarantined or downgraded are no longer OBSERVED, so they are neither trusted nor flagged stale.
    gate = assess_evidence(profile=profile, evidence=evidence, records=list(evidence_index.values()), index=evidence_index,
                           target_revision=task_obj.get("target_revision"), now=_now(adapters), extra_resolutions=claims)
    if "EVIDENCE_GATE" not in trace:
        trace.append("EVIDENCE_GATE")
    gate_note = ""
    if status == "PASS" and gate["blocks_pass"]:
        status = "PARTIAL"
        gate_note = "evidence gate: " + "; ".join(gate["reasons"])
    r.evaluation, r.all_records, r.evidence_index, r.normalized = evaluation, all_records, evidence_index, normalized
    r.status, r.rr_note, r.gate, r.gate_note = status, rr_note, gate, gate_note
    return None
