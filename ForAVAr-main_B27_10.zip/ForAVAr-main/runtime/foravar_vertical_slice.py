"""Minimal forAVAr thinking-loop integration seam.

This module orchestrates caller-supplied cognitive/tool adapters. It does not
implement a language model, permissions engine, task registry, persistence layer,
retry loop, or GitHub operations. An optional cancel_requested adapter can stop a task
before execution (status CANCELLED). It builds an in-memory RunRecord receipt
(run_record.py) but never persists it; retry decisions live in retry_policy.py and
are made by the caller, not by this module. Authorization remains an explicit adapter gate.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

try:
    from .error_exits import STAGE_EVENT, envelope, error_receipt
    from .run_record import build_run_record
    from .common import FAILURE_BRANCHES, FAILURE_CLASSES  # noqa: F401 - re-exported (loop_controller, tests)
    from .stage_common import (IMPLEMENTATION_STATUS, IMPLEMENTATION_VERSION, CRITERION_STATES, EXECUTION_STATES, ContractError, Run, _bind_task, _call, _downgrades, _early,  # noqa: F401 - re-exported (tests)
                               _feedback, _now, _observed_ids, _record, _text, _validate_evidence, _validate_task)
    from . import (stage_frame, stage_evidence, stage_model, stage_route, stage_authorize, stage_cancel, stage_execute,
                   stage_evaluate, stage_synthesis, stage_feedback)
except ImportError:  # supports direct imports when runtime/ is on sys.path
    from error_exits import STAGE_EVENT, envelope, error_receipt
    from run_record import build_run_record
    from common import FAILURE_BRANCHES, FAILURE_CLASSES  # noqa: F401
    from stage_common import (IMPLEMENTATION_STATUS, IMPLEMENTATION_VERSION, CRITERION_STATES, EXECUTION_STATES, ContractError, Run, _bind_task, _call, _downgrades, _early,  # noqa: F401
                              _feedback, _now, _observed_ids, _record, _text, _validate_evidence, _validate_task)
    import stage_frame, stage_evidence, stage_model, stage_route, stage_authorize, stage_cancel, stage_execute
    import stage_evaluate, stage_synthesis, stage_feedback


# Stage registry (LT-20): order = trace order. Each stage is run(r) -> early result | None; the last returns the receipt.
# Add/replace a stage here and in tests/test_stage_registry.py; stages never call each other.
STAGES = (stage_frame.run, stage_evidence.run, stage_model.run, stage_route.run, stage_authorize.run, stage_cancel.run,
          stage_execute.run, stage_evaluate.run, stage_synthesis.run, stage_feedback.run)
PRE_STAGES = STAGES[:3]  # frame / evidence / model: before routing


def _run_core(task: Mapping[str, Any], adapters: Mapping[str, Callable[..., Any]], ctx: dict[str, Any]) -> dict[str, Any]:
    """Run one conditional thinking loop; return a traceable, non-persistent receipt.

    Required adapters: frame(task), evidence(task, frame), route(task, frame, evidence),
    execute(task, frame, evidence, route), evaluate(task, execution, evidence).
    A low-risk direct task may bypass evidence gathering only when all short-circuit
    profile fields are explicitly false/LOW. A selected route never grants permission.
    """
    ctx["stage"] = "task"
    task_obj = _record(task, "task")
    criteria, profile = _validate_task(task_obj)
    task_id = task_obj["task_id"]
    ctx.update(task_id=task_id, profile=profile)

    r = Run(task_obj, task_id, profile, adapters, ctx)
    r.criteria = criteria
    for stage in STAGES:  # each returns an early/final result or None
        out = stage(r)
        if out is not None:
            return out
    raise ContractError("stage registry ended without a final receipt")  # unreachable: stage_feedback always returns


def run_vertical_slice(task: Mapping[str, Any], adapters: Mapping[str, Callable[..., Any]]) -> dict[str, Any]:
    """Public entry (R6): never lets an adapter exception or ContractError escape.

    Faults map to blueprint closed_loop.error_exits via ``error_exits.envelope``: a named terminal status,
    feedback action, failure_class and an ``error`` receipt. Execute-stage faults are treated as
    possible side effects (INCONCLUSIVE) unless the profile explicitly declares side_effects=False.
    """
    ctx: dict[str, Any] = {"trace": [], "stage": "task"}
    try:
        return _run_core(task, adapters, ctx)
    except Exception as exc:  # noqa: BLE001 - R6: every fault must surface as a named exit
        return _fault_exit(task, ctx, exc)


def _fault_exit(task: Any, ctx: dict[str, Any], exc: Exception) -> dict[str, Any]:
    stage = ctx.get("stage", "task")
    raw_id = task.get("task_id") if isinstance(task, Mapping) else None
    task_id = ctx.get("task_id") or (raw_id if isinstance(raw_id, str) and raw_id.strip() else "UNKNOWN")
    trace = list(ctx["trace"])
    parts = {k: ctx[k] for k in ("frame", "evidence", "model", "route", "execution", "run_record", "synthesis") if k in ctx}
    receipt = error_receipt(stage, exc)
    if stage == "execute":
        profile = ctx.get("profile", {})
        no_effect = profile.get("side_effects") is False
        event = "EXECUTE_FAULT_NO_EFFECT" if no_effect else "EXECUTE_FAULT_UNKNOWN_EFFECT"
        trace.append("EXECUTION")
        parts["run_record"] = build_run_record(
            task_id, None, result_status="TIMEOUT_UNKNOWN_SIDE_EFFECT" if not no_effect else "FAILED", required=True)
        out = envelope(task_id, event, f"execute stage fault ({type(exc).__name__}): {receipt['message']}", stage=stage, receipt=receipt)
        if not no_effect:
            out["unknown_side_effect"] = True
    else:
        event = STAGE_EVENT[stage]
        out = envelope(task_id, event, f"{stage} stage fault ({type(exc).__name__}): {receipt['message']}", stage=stage, receipt=receipt)
    out.update(implementation_version=IMPLEMENTATION_VERSION, implementation_status=IMPLEMENTATION_STATUS, trace=trace, **parts)
    return out
