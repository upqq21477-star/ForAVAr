"""Problem-model gate (R3-model; blueprint N07-N09). Pure, stdlib, never raises, fail-closed.

Optional stage: the slice calls ``adapters["model"](task, frame, evidence)`` after the evidence gate when that adapter
is supplied, then runs ``assess_model``. Model shape: elements[{id,label}], relations[{id,source,target,basis}],
conditions[{id,statement,applies_to}], unknowns[{id,statement,affects}], hypotheses[{id,statement,discriminating_test}].
Rules (each violation names its rule):
  elements non-empty with unique ids; relations/conditions/unknowns are lists, and an empty one needs ``omitted_basis[<name>]``;
  relation endpoints exist; basis EVIDENCED needs >=1 evidence_ids that are OBSERVED in the evidence records, otherwise the
  relation must be basis HYPOTHESIS (no-evidence relation presented as fact = violation); condition.applies_to and
  unknown.affects reference existing element/relation ids; >=2 hypotheses, unique ids, each with a discriminating_test and
  pairwise-different tests; the model never claims OBSERVED (no status OBSERVED / observed_at on model items).
Status: any violation -> BLOCKED when high-stakes (risk HIGH/CRITICAL, side_effects not False, governance >= G2) else NOT_PROVEN.
Checks form and traceability only, not whether the model is right.
"""
from __future__ import annotations

from collections.abc import Collection, Mapping
from typing import Any

try:
    from .common import claims_observed as _claims_observed, is_text as _s, stakes as _stakes
except ImportError:  # direct import with runtime/ on sys.path
    from common import claims_observed as _claims_observed, is_text as _s, stakes as _stakes

BASES = {"EVIDENCED", "HYPOTHESIS"}
CATEGORIES = ("relations", "conditions", "unknowns")


def _items(model: Mapping[str, Any], key: str) -> list[Any]:
    v = model.get(key)
    return v if isinstance(v, list) else []


def assess_model(profile: Mapping[str, Any], model: Mapping[str, Any], observed_evidence_ids: Collection[str]) -> dict[str, Any]:
    v: list[dict[str, str]] = []
    add = lambda rule, detail: v.append({"rule": rule, "detail": detail})  # noqa: E731
    observed = set(observed_evidence_ids)
    ids: dict[str, str] = {}  # id -> kind (element|relation)

    def uniq(kind: str, n: int, item: Any) -> str | None:
        i = item.get("id") if isinstance(item, Mapping) else None
        if not _s(i):
            add(f"{kind.upper()}_MALFORMED", f"{kind}[{n}] needs a non-blank id")
            return None
        return i

    elements = _items(model, "elements")
    if not elements:
        add("ELEMENTS_MISSING", "elements must be a non-empty list")
    element_ids: set[str] = set()
    for n, e in enumerate(elements):
        i = uniq("element", n, e)
        if i is None:
            continue
        if not _s(e.get("label")) or i in ids:
            add("ELEMENT_MALFORMED", f"elements[{n}] needs a label and a unique id")
            continue
        ids[i] = "element"
        element_ids.add(i)
    omitted = model.get("omitted_basis") if isinstance(model.get("omitted_basis"), Mapping) else {}
    for cat in CATEGORIES:
        if not isinstance(model.get(cat), list):
            add(f"{cat.upper()}_MISSING", f"{cat} must be a list")
        elif not model[cat] and not _s(omitted.get(cat)):
            add(f"{cat.upper()}_MISSING", f"empty {cat} need omitted_basis.{cat}")
    hypothesis_relations = 0
    for n, r in enumerate(_items(model, "relations")):
        i = uniq("relation", n, r)
        if i is None:
            continue
        if i in ids or r.get("source") not in element_ids or r.get("target") not in element_ids:
            add("RELATION_MALFORMED", f"relations[{n}] needs a unique id and existing source/target elements")
            continue
        ids[i] = "relation"
        ev = r.get("evidence_ids")
        basis = r.get("basis")
        if basis not in BASES:
            add("RELATION_BASIS", f"relations[{n}].basis must be EVIDENCED or HYPOTHESIS")
        elif basis == "EVIDENCED":
            if not (isinstance(ev, list) and ev and all(x in observed for x in ev)):
                add("RELATION_UNSUPPORTED", f"relations[{n}] is EVIDENCED without OBSERVED evidence; mark it HYPOTHESIS")
        else:
            hypothesis_relations += 1
    for n, c in enumerate(_items(model, "conditions")):
        refs = c.get("applies_to") if isinstance(c, Mapping) else None
        if not (isinstance(c, Mapping) and _s(c.get("id")) and _s(c.get("statement")) and isinstance(refs, list) and refs
                and all(x in ids for x in refs)):
            add("CONDITION_MALFORMED", f"conditions[{n}] needs id, statement and applies_to existing ids")
    for n, u in enumerate(_items(model, "unknowns")):
        refs = u.get("affects") if isinstance(u, Mapping) else None
        if not (isinstance(u, Mapping) and _s(u.get("id")) and _s(u.get("statement")) and isinstance(refs, list) and refs
                and all(x in ids for x in refs)):
            add("UNKNOWN_MALFORMED", f"unknowns[{n}] needs id, statement and affects existing ids")
    hyps = _items(model, "hypotheses")
    tests: set[str] = set()
    hids: set[str] = set()
    good = 0
    for n, h in enumerate(hyps):
        ok = (isinstance(h, Mapping) and _s(h.get("id")) and _s(h.get("statement")) and _s(h.get("discriminating_test"))
              and h["id"] not in hids and h["discriminating_test"].strip() not in tests)
        if not ok:
            add("HYPOTHESIS_MALFORMED", f"hypotheses[{n}] needs unique id, statement and a discriminating_test different from the others")
            continue
        hids.add(h["id"])
        tests.add(h["discriminating_test"].strip())
        good += 1
    if good < 2:
        add("COMPETING_HYPOTHESES_MISSING", "at least 2 competing hypotheses, each with its own discriminating_test")
    for key in ("elements", "relations", "conditions", "hypotheses"):
        if any(_claims_observed(x) for x in _items(model, key)):
            add("MODEL_CLAIMS_OBSERVED", f"{key}: a model cannot mark its own content OBSERVED")
    status = "OK" if not v else ("BLOCKED" if _stakes(profile) else "NOT_PROVEN")
    return {"ok": not v, "status": status, "violations": v, "hypothesis_relations": hypothesis_relations,
            "hypotheses_counted": good}
