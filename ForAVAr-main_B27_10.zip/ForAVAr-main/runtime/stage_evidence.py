"""Stage EVIDENCE (+ pre-execution evidence gate, R8). Body moved verbatim from the slice."""
from __future__ import annotations

from typing import Any

try:
    from .error_exits import evidence_envelope
    from .evidence_gate import ACTION as EVIDENCE_ACTION, assess as assess_evidence
    from .stage_common import ContractError, _bind_task, _call, _downgrades, _early, _now, _simple_fast_path, _validate_evidence, Run
except ImportError:  # direct imports when runtime/ is on sys.path
    from error_exits import evidence_envelope
    from evidence_gate import ACTION as EVIDENCE_ACTION, assess as assess_evidence
    from stage_common import ContractError, _bind_task, _call, _downgrades, _early, _now, _simple_fast_path, _validate_evidence, Run


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, ctx, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.ctx, r.trace
    frame = r.frame
    pre_gate: dict[str, Any] = {"conflicts": [], "stale": [], "blocks_pass": False, "reasons": []}
    evidence_index_pre: dict[str, dict[str, Any]] = {}
    if _simple_fast_path(profile):
        evidence = {"task_id": task_id, "status": "NOT_REQUIRED", "records": [], "critical_unknowns": [], "reason": "explicit low-risk short path"}
        trace.append("EVIDENCE_SHORT_CIRCUIT")
    else:
        ctx["stage"] = "evidence"
        evidence = _call(adapters, "evidence", task_obj, frame)
        trace.append("EVIDENCE")
        ctx["evidence"] = evidence
        _bind_task(evidence, task_id, "evidence")
        if evidence.get("status") not in {"READY", "PARTIAL", "CONFLICT", "BLOCKED"}:
            raise ContractError("adapter.evidence status must be READY, PARTIAL, CONFLICT, or BLOCKED")
        evidence_index_pre = _validate_evidence(evidence.get("records", []), "evidence.records", adapters.get("content_semantic"))
        if evidence.get("status") == "BLOCKED":
            return _early("BLOCKED", task_id, trace, str(evidence.get("reason", "evidence collection is blocked")), frame=frame, evidence=evidence)
        critical_unknowns = evidence.get("critical_unknowns", [])
        if not isinstance(critical_unknowns, list):
            raise ContractError("evidence.critical_unknowns must be a list")
        if critical_unknowns and (profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is True):
            return _early("BLOCKED", task_id, trace, "critical unknown affects a high-risk or side-effecting task", frame=frame, evidence=evidence)
        # R8: conflict / stale gate before execution. High-risk or side-effecting work is BLOCKED here;
        # lower-risk work proceeds but cannot PASS (checked again at acceptance).
        hard = profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is not False
        pre_gate = assess_evidence(profile=profile, evidence=evidence, records=list(evidence_index_pre.values()),
                                   index=evidence_index_pre, target_revision=task_obj.get("target_revision"), now=_now(adapters))
        ctx["evidence_gate"] = pre_gate
        trace.append("EVIDENCE_GATE")
        if pre_gate["blocks_pass"] and hard:
            out = evidence_envelope(task_id, "; ".join(pre_gate["reasons"]), hard_block=True)
            return _early("BLOCKED", task_id, trace, out["feedback"]["reason"], EVIDENCE_ACTION, frame=frame, evidence=evidence,
                          failure_class="SOURCE_OR_EVIDENCE_ERROR", evidence_gate=pre_gate, event="EVIDENCE_CONFLICT_OR_STALE",
                          evidence_downgrades=_downgrades(evidence.get("records"), evidence_index_pre))
    r.evidence, r.evidence_index_pre, r.pre_gate = evidence, evidence_index_pre, pre_gate
    return None
