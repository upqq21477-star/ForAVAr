"""Stage CANCEL (F5, optional adapter cancel_requested): checked once, after the policy gate, before execution. Moved verbatim (LT-20b)."""
from __future__ import annotations

from typing import Any

try:
    from .stage_common import Run, _early
except ImportError:  # direct imports when runtime/ is on sys.path
    from stage_common import Run, _early


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, adapters, trace = r.task_obj, r.task_id, r.adapters, r.trace
    frame, evidence, route, authorization = r.frame, r.evidence, r.route, r.authorization
    # Nothing has executed yet, so no receipt exists. Cancelling mid-execution is out of scope (OD-4).
    cancel_check = adapters.get("cancel_requested")
    if callable(cancel_check):
        trace.append("CANCEL_CHECK")
        try:
            cancelled = cancel_check(task_obj)
        except Exception as exc:  # fail closed: do not execute if cancellation state is unknown
            return _early("BLOCKED", task_id, trace, f"cancel check failed ({type(exc).__name__}); execution not started", frame=frame, evidence=evidence, route=route, authorization=authorization)
        if cancelled is True:
            return _early("CANCELLED", task_id, trace, "cancellation requested before execution", frame=frame, evidence=evidence, route=route, authorization=authorization)
    return None
