"""Stage MODEL (optional, N07-N09): adapter model + model gate. Body moved verbatim from the slice."""
from __future__ import annotations

from typing import Any

try:
    from .model_gate import assess_model
    from .stage_common import _bind_task, _call, _downgrades, _early, _observed_ids, Run
except ImportError:  # direct imports when runtime/ is on sys.path
    from model_gate import assess_model
    from stage_common import _bind_task, _call, _downgrades, _early, _observed_ids, Run


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, ctx, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.ctx, r.trace
    frame, evidence, evidence_index_pre = r.frame, r.evidence, r.evidence_index_pre
    model: dict[str, Any] | None = None
    model_gate: dict[str, Any] | None = None
    if "model" in adapters:  # R3-model (optional stage, N07-N09): validated before routing
        ctx["stage"] = "model"
        model = _call(adapters, "model", task_obj, frame, evidence)
        trace.append("MODEL")
        ctx["model"] = model
        _bind_task(model, task_id, "model")
        if model.get("status") != "READY":
            status = "BLOCKED" if model.get("status") == "BLOCKED" else "NOT_PROVEN"
            return _early(status, task_id, trace, str(model.get("reason", "problem model is incomplete")), frame=frame, evidence=evidence, model=model)
        model_gate = assess_model(profile, model, _observed_ids(evidence_index_pre))
        ctx["model_gate"] = model_gate
        trace.append("MODEL_GATE")
        if not model_gate["ok"]:
            reason = "model incomplete: " + "; ".join(x["rule"] for x in model_gate["violations"])
            return _early(model_gate["status"], task_id, trace, reason, frame=frame, evidence=evidence, model=model,
                          model_gate=model_gate, failure_class="INFERENCE_OR_MODEL_ERROR",
                          evidence_downgrades=_downgrades(evidence.get("records"), evidence_index_pre))
    r.model, r.model_gate = model, model_gate
    return None
