"""Shared helpers and the Run state object for the slice stage modules (LT-20).

Leaf module: stage_* files and the slice import this; it imports no stage and no gate. Moved verbatim from foravar_vertical_slice.py."""
from __future__ import annotations

from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from typing import Any

try:
    from .content_guard import quarantine_if_injected
except ImportError:  # direct imports when runtime/ is on sys.path
    from content_guard import quarantine_if_injected

IMPLEMENTATION_VERSION = "0.9.0"
IMPLEMENTATION_STATUS = "EVIDENCE_GATE_INTEGRATED_RUNTIME_NOT_VALIDATED"

EVIDENCE_KINDS = {
    "SOURCE_OBSERVATION",
    "STATIC_CHECK",
    "RETROSPECTIVE_REPLAY",
    "PROGRAM_TEST",
    "RUNTIME_OBSERVATION",
    "EXECUTION_OBSERVATION",
}
CRITERION_STATES = {"PASS", "FAIL", "UNKNOWN", "NOT_RUN"}
EXECUTION_STATES = {"EXECUTED", "PARTIAL", "BLOCKED", "FAILED", "NOT_RUN", "TIMEOUT_UNKNOWN_SIDE_EFFECT"}
RISK_LEVELS = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}


class ContractError(ValueError):
    """Raised when an adapter violates the vertical-slice contract."""


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(f"{field} must be a non-empty string")
    return value.strip()


def _record(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ContractError(f"{field} must be an object")
    return dict(value)


def _validate_task(task: Mapping[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    _text(task.get("task_id"), "task.task_id")
    _text(task.get("goal"), "task.goal")
    raw_criteria = task.get("acceptance_criteria")
    if not isinstance(raw_criteria, list) or not raw_criteria:
        raise ContractError("task.acceptance_criteria must be a non-empty list")
    criteria: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_criteria):
        item = _record(raw, f"task.acceptance_criteria[{index}]")
        criterion_id = _text(item.get("id"), f"acceptance_criteria[{index}].id")
        _text(item.get("description"), f"acceptance_criteria[{index}].description")
        if criterion_id in seen:
            raise ContractError(f"duplicate acceptance criterion: {criterion_id}")
        seen.add(criterion_id)
        required_kinds = item.get("required_evidence_kinds", [])
        if not isinstance(required_kinds, list) or any(kind not in EVIDENCE_KINDS for kind in required_kinds):
            raise ContractError(f"invalid evidence kind requirement for {criterion_id}")
        criteria.append({**item, "id": criterion_id, "required_evidence_kinds": required_kinds})

    profile = task.get("profile", {})
    if not isinstance(profile, Mapping):
        raise ContractError("task.profile must be an object")
    profile = dict(profile)
    risk = profile.get("risk_level")
    if risk is not None and risk not in RISK_LEVELS:
        raise ContractError(f"invalid task.profile.risk_level: {risk}")
    for key in ("requires_external_evidence", "requires_diagnostic", "has_source_conflict", "has_critical_unknowns", "side_effects", "frame_gate"):
        if key in profile and not isinstance(profile[key], bool):
            raise ContractError(f"task.profile.{key} must be boolean")
    return criteria, profile


def _simple_fast_path(profile: Mapping[str, Any]) -> bool:
    """Short-circuit only when every condition is explicit and low-risk."""
    return (
        profile.get("risk_level") == "LOW"
        and profile.get("requires_external_evidence") is False
        and profile.get("requires_diagnostic") is False
        and profile.get("has_source_conflict") is False
        and profile.get("has_critical_unknowns") is False
        and profile.get("side_effects") is False
    )


def _call(adapters: Mapping[str, Callable[..., Any]], name: str, *args: Any) -> dict[str, Any]:
    fn = adapters.get(name)
    if not callable(fn):
        raise ContractError(f"missing callable adapter: {name}")
    return _record(fn(*args), f"adapter.{name} result")


def _now(adapters: Mapping[str, Callable[..., Any]]) -> datetime:
    """Optional ``clock`` adapter returns an ISO timestamp (deterministic tests); default is real UTC time."""
    clock = adapters.get("clock")
    if callable(clock):
        dt = datetime.fromisoformat(str(clock()).replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc)


def _bind_task(value: Mapping[str, Any], task_id: str, field: str) -> None:
    if value.get("task_id") != task_id:
        raise ContractError(f"{field}.task_id does not match the active task")


def _early(status: str, task_id: str, trace: list[str], reason: str, action: str | None = None, **extra: Any) -> dict[str, Any]:
    action = action or {
        "BLOCKED": "STOP_BLOCKED",
        "NOT_PROVEN": "PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE",
        "FAILED": "CLASSIFY_FAILURE_BEFORE_RETRY",
        "REJECTED": "REJECT_WITH_REASON",  # F5: no feasible solution within hard constraints
        "CANCELLED": "STOP_AND_REPORT_STATE_NO_EXECUTION",  # F5: stopped on request before execution
        "INCONCLUSIVE": "INSPECT_ACTUAL_STATE_BEFORE_RETRY",
    }.get(status, "STOP_AND_PRESERVE_STATE")
    return {
        "task_id": task_id,
        "implementation_version": IMPLEMENTATION_VERSION,
        "implementation_status": IMPLEMENTATION_STATUS,
        "status": status,
        "trace": list(trace),
        "feedback": {"action": action, "reason": reason},
        **extra,
    }


def _validate_evidence(records: Any, field: str, semantic: Callable[[str], Any] | None = None) -> dict[str, dict[str, Any]]:
    """``semantic``: optional LT-04 stage-2 slot (adapters['content_semantic']); None = stage-1 regex only (unchanged)."""
    if not isinstance(records, list):
        raise ContractError(f"{field} must be a list")
    index: dict[str, dict[str, Any]] = {}
    for n, raw in enumerate(records):
        record = _record(raw, f"{field}[{n}]")
        evidence_id = _text(record.get("evidence_id"), f"{field}[{n}].evidence_id")
        if evidence_id in index:
            raise ContractError(f"duplicate evidence_id: {evidence_id}")
        kind = record.get("kind")
        if kind not in EVIDENCE_KINDS:
            raise ContractError(f"invalid evidence kind for {evidence_id}: {kind}")
        # Declared or linked material is not evidence unless an observation is recorded. An OBSERVED claim that lacks
        # the observation fields is not trusted: it is downgraded (never counts as OBSERVED downstream) rather than
        # skipping the stricter per-kind checks below.
        required = ("target_revision", "observed_at", "summary")
        missing = [k for k in required if not (isinstance(record.get(k), str) and record[k].strip())]
        if record.get("status") == "OBSERVED" and missing:
            record = {**record, "status": "UNVERIFIED", "downgrade_reason": "OBSERVED claim lacks " + ", ".join(missing)}
        if record.get("status") == "OBSERVED":
            if kind in {"PROGRAM_TEST", "RUNTIME_OBSERVATION"}:
                if not isinstance(record.get("run_id"), str) or not record["run_id"].strip():
                    raise ContractError(f"{kind} evidence {evidence_id} requires run_id")
                if not isinstance(record.get("command"), str) or not record["command"].strip():
                    raise ContractError(f"{kind} evidence {evidence_id} requires command")
                if not isinstance(record.get("exit_code"), int):
                    raise ContractError(f"{kind} evidence {evidence_id} requires integer exit_code")
            if kind == "RUNTIME_OBSERVATION":
                for key in ("environment", "output_digest"):
                    if not isinstance(record.get(key), str) or not record[key].strip():
                        raise ContractError(f"RUNTIME_OBSERVATION evidence {evidence_id} requires {key}")
        index[evidence_id] = quarantine_if_injected(record, semantic)
    return index


def _observed_ids(index: Mapping[str, Mapping[str, Any]]) -> set[str]:
    """Ids that are still OBSERVED after validation (quarantine / downgrade applied); the only ids any gate may trust."""
    return {i for i, r in index.items() if r.get("status") == "OBSERVED"}


def _downgrades(raw: Any, index: Mapping[str, Mapping[str, Any]]) -> list[dict[str, str]]:
    """Records the adapter declared OBSERVED that validation did not leave OBSERVED (traceable, never silent)."""
    out: list[dict[str, str]] = []
    for r in raw if isinstance(raw, list) else []:
        i = r.get("evidence_id") if isinstance(r, Mapping) else None
        now = index.get(i) if isinstance(i, str) else None
        if now is not None and r.get("status") == "OBSERVED" and now.get("status") != "OBSERVED":
            hits = ", ".join(f["pattern_id"] for f in now.get("injection_findings", []))
            why = now.get("downgrade_reason") or (f"instruction-like content: {hits}" if hits else "validation")
            out.append({"evidence_id": i, "from": "OBSERVED", "to": str(now.get("status")), "reason": why})
    return out


def _feedback(status: str, failure_branch: str, reason: str = "") -> dict[str, str]:
    actions = {
        "PASS": "CLOSE",
        "PARTIAL": "PARTIAL_CLOSEOUT_WITH_OPEN_ITEMS",
        "BLOCKED": "STOP_BLOCKED",
        "NOT_PROVEN": "PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE",
        "FAILED": {
            "LOCAL_FAILURE": "REPAIR_LOCAL_NODE_AND_REGRESS",
            "METHOD_FAILURE": "REROUTE_METHOD",
            "MODEL_FAILURE": "REVISE_PROBLEM_MODEL",
            "FRAME_FAILURE": "REFRAME_PROBLEM",
            "AUTHORIZATION_FAILURE": "STOP_AND_REQUEST_AUTHORIZATION",
            "EVIDENCE_GAP": "GATHER_DISCRIMINATING_EVIDENCE",
            "NO_FEASIBLE_SOLUTION": "REJECT_WITH_REASON",
            "NONE": "CLASSIFY_FAILURE_BEFORE_RETRY",
        }[failure_branch],
    }
    action = actions[status]
    return {"action": action, "reason": reason or failure_branch}


class Run:
    """Mutable state of one task run, passed to every stage. Stages talk to each other only through this object."""

    def __init__(self, task_obj: Mapping[str, Any], task_id: str, profile: Mapping[str, Any],
                 adapters: Mapping[str, Callable[..., Any]], ctx: dict[str, Any]) -> None:
        self.task_obj, self.task_id, self.profile, self.adapters, self.ctx = task_obj, task_id, profile, adapters, ctx
        self.trace: list[str] = ctx["trace"]
        self.frame: dict[str, Any] | None = None
        self.frame_gate: dict[str, Any] | None = None
        self.evidence: dict[str, Any] | None = None
        self.evidence_index_pre: dict[str, dict[str, Any]] = {}
        self.pre_gate: dict[str, Any] = {"conflicts": [], "stale": [], "blocks_pass": False, "reasons": []}
        self.model: dict[str, Any] | None = None
        self.model_gate: dict[str, Any] | None = None
        self.criteria: list[dict[str, Any]] = []  # set by the slice after task validation
        self.route: dict[str, Any] | None = None
        self.authorization: dict[str, Any] | None = None
        self.execution: dict[str, Any] | None = None
        self.run_record: dict[str, Any] | None = None
        self.evaluation: dict[str, Any] | None = None
        self.all_records: list[Any] = []
        self.evidence_index: dict[str, dict[str, Any]] = {}
        self.normalized: list[dict[str, Any]] = []
        self.status: str = ""
        self.rr_note, self.gate_note, self.synth_note = "", "", ""
        self.gate: dict[str, Any] | None = None
        self.synthesis: dict[str, Any] | None = None
        self.synthesis_gate: dict[str, Any] | None = None
        self.synth_failure: bool = False
