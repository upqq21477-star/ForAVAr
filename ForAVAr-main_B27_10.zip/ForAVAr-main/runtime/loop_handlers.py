"""Re-entry handlers for the closed loop (LT-13; blueprint architecture.closed_loop.reentry).

``make_handlers(adapters)`` returns ``{action: handler(ctx) -> dict}`` for the four upstream re-entry actions
(REROUTE_METHOD, REVISE_PROBLEM_MODEL, REFRAME_PROBLEM, GATHER_DISCRIMINATING_EVIDENCE) in the interface
``loop_controller.run_closed_loop(handlers=...)`` already consumes (the controller is unchanged).

What a handler does is mechanical and side-effect free: it returns replacement ``adapters`` (and ``method``) only.
  * REROUTE_METHOD     : picks a candidate method not yet tried from the previous route and replays that route with the
                         new selection (no model call). No untried candidate -> {} (decide_retry then stops).
  * REVISE_PROBLEM_MODEL / REFRAME_PROBLEM / GATHER_DISCRIMINATING_EVIDENCE : wrap the stage's adapter so the stage sees a
                         bounded ``retry_context`` (why the last attempt failed, which criteria are open, methods tried).
                         The task itself is not replaced, so the controller's upstream replay stays valid.
  * No adapter for the stage, or nothing new to say -> {} (no new information; the controller stops, never loops).
Whether the revised model/frame/evidence is any good is NOT verified here (POST_E4, LT-13.eval); this module only
guarantees the re-entry is different, bounded and has no side effects. Stdlib only; imports nothing from runtime.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

REASON_CAP, CRITERIA_CAP = 300, 8
ACTIONS = ("REROUTE_METHOD", "REVISE_PROBLEM_MODEL", "REFRAME_PROBLEM", "GATHER_DISCRIMINATING_EVIDENCE")
STAGE_OF = {"REVISE_PROBLEM_MODEL": "model", "REFRAME_PROBLEM": "frame", "GATHER_DISCRIMINATING_EVIDENCE": "evidence"}


def retry_context(ctx: Mapping[str, Any]) -> dict[str, Any]:
    """Bounded, deterministic summary of why the last attempt did not close (no model call, no new claims)."""
    last = ctx.get("last_result") or {}
    acc = last.get("acceptance") or {}
    open_criteria = [{"criterion_id": r.get("criterion_id"), "status": r.get("status")}
                     for r in acc.get("criteria_results", []) if isinstance(r, Mapping) and r.get("status") != "PASS"]
    return {
        "attempt": ctx.get("attempt"), "action": ctx.get("action"), "failure_class": ctx.get("failure_class") or "UNKNOWN",
        "reason": str((last.get("feedback") or {}).get("reason", ""))[:REASON_CAP],
        "open_criteria": open_criteria[:CRITERIA_CAP],
        "methods_tried": _tried(ctx),
    }


def _tried(ctx: Mapping[str, Any]) -> list[str]:
    out: list[str] = []
    for h in ctx.get("history") or []:
        m = h.get("method") if isinstance(h, Mapping) else None
        if isinstance(m, str) and m not in out:
            out.append(m)
    return out


def _reroute(ctx: Mapping[str, Any]) -> dict[str, Any]:
    route = (ctx.get("last_result") or {}).get("route")
    if not isinstance(route, Mapping) or not isinstance(route.get("candidate_methods"), list):
        return {}
    tried = set(_tried(ctx)) | ({route["selected_method"]} if isinstance(route.get("selected_method"), str) else set())
    untried = [m for m in route["candidate_methods"] if isinstance(m, str) and m.strip() and m not in tried]
    if not untried:
        return {}  # nothing new to try: no new information, the controller stops
    chosen = untried[0]
    forced = {**route, "selected_method": chosen, "reason": f"untried candidate after {ctx.get('failure_class') or 'failure'} on {route.get('selected_method')}"}
    return {"method": chosen, "adapters": {"route": lambda *_a, _r=forced: dict(_r)}}


def _wrap(stage: str, base: Callable[..., Any], ctx: Mapping[str, Any]) -> dict[str, Any]:
    rc = retry_context(ctx)
    return {"adapters": {stage: lambda t, *a, _b=base, _rc=rc: _b({**t, "retry_context": _rc}, *a)}}


def make_handlers(adapters: Mapping[str, Callable[..., Any]]) -> dict[str, Callable[[dict[str, Any]], dict[str, Any]]]:
    """Handlers bound to the ORIGINAL adapters (each retry wraps the base, never an earlier wrapper)."""
    base = dict(adapters)

    def stage_handler(action: str) -> Callable[[dict[str, Any]], dict[str, Any]]:
        stage = STAGE_OF[action]

        def handle(ctx: dict[str, Any]) -> dict[str, Any]:
            fn = base.get(stage)
            return _wrap(stage, fn, ctx) if callable(fn) else {}
        return handle

    handlers: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {a: stage_handler(a) for a in STAGE_OF}
    handlers["REROUTE_METHOD"] = _reroute
    return handlers
