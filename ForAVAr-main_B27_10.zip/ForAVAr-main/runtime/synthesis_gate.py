"""Synthesis gate (R3-synthesis; blueprint N14-N15, P1-F39/F44/F47). Pure, stdlib, never raises, fail-closed.

Optional stage: after evaluate, the slice calls ``adapters["synthesis"](task, evaluation, evidence)`` when supplied, then
``assess_synthesis``. Shape: conclusions[{id,statement,basis,confidence,evidence_ids,merged_from?}],
unresolved[{id,statement}], omitted_basis{conclusions?}.
Rules (each violation names its rule):
  conclusions is a list (empty needs omitted_basis.conclusions); ids unique; basis EVIDENCED|HYPOTHESIS; confidence HIGH|MEDIUM|LOW;
  EVIDENCED needs >=1 evidence_ids, all OBSERVED in the records; HYPOTHESIS must not be HIGH;
  confidence tracks evidence: no OBSERVED evidence -> LOW only; HIGH needs >=1 OBSERVED evidence;
  every open item (unknown / conflict / stale / unmet criterion) must be carried in ``unresolved`` by id (nothing dropped);
  merged_from (cross-round merge) must name known prior conclusion ids; the synthesis never claims OBSERVED.
Status: any violation -> BLOCKED when high-stakes (risk HIGH/CRITICAL, side_effects not False, governance >= G2) else NOT_PROVEN.
Checks form and traceability only, not whether the conclusions are right.
"""
from __future__ import annotations

from collections.abc import Collection, Mapping
from typing import Any

try:
    from .common import claims_observed as _claims_observed, is_text as _s, stakes as _stakes
except ImportError:  # direct import with runtime/ on sys.path
    from common import claims_observed as _claims_observed, is_text as _s, stakes as _stakes

BASES = {"EVIDENCED", "HYPOTHESIS"}
CONFIDENCE = {"HIGH", "MEDIUM", "LOW"}


def collect_open_items(frame: Any, model: Any, criteria_results: Any, gate: Any) -> list[str]:
    """Ids the synthesis must carry: frame/model unknowns, unmet criteria, unresolved conflicts, stale evidence."""
    out: list[str] = []

    def add(x: Any) -> None:
        if _s(x) and x not in out:
            out.append(x)

    for u in (frame.get("unknowns") if isinstance(frame, Mapping) else None) or []:
        add(u.get("id") if isinstance(u, Mapping) else u)
    for u in (model.get("unknowns") if isinstance(model, Mapping) else None) or []:
        add(u.get("id") if isinstance(u, Mapping) else None)
    for r in criteria_results if isinstance(criteria_results, list) else []:
        if isinstance(r, Mapping) and r.get("status") in {"UNKNOWN", "NOT_RUN"}:
            add(r.get("criterion_id"))
    if isinstance(gate, Mapping):
        for c in gate.get("conflicts") or []:
            add(c.get("conflict_id") if isinstance(c, Mapping) else None)
        for s in gate.get("stale") or []:
            add(s.get("evidence_id") if isinstance(s, Mapping) else None)
    return out


def assess_synthesis(profile: Mapping[str, Any], synthesis: Mapping[str, Any], observed_evidence_ids: Collection[str],
                     open_item_ids: Collection[str] = (), prior_conclusion_ids: Collection[str] = ()) -> dict[str, Any]:
    v: list[dict[str, str]] = []
    add = lambda rule, detail: v.append({"rule": rule, "detail": detail})  # noqa: E731
    observed, prior = set(observed_evidence_ids), set(prior_conclusion_ids)
    conclusions = synthesis.get("conclusions") if isinstance(synthesis, Mapping) else None
    omitted = synthesis.get("omitted_basis") if isinstance(synthesis, Mapping) and isinstance(synthesis.get("omitted_basis"), Mapping) else {}
    if not isinstance(conclusions, list):
        add("CONCLUSIONS_MISSING", "conclusions must be a list")
        conclusions = []
    elif not conclusions and not _s(omitted.get("conclusions")):
        add("CONCLUSIONS_MISSING", "empty conclusions need omitted_basis.conclusions")
    seen: set[str] = set()
    for n, c in enumerate(conclusions):
        if not (isinstance(c, Mapping) and _s(c.get("id")) and _s(c.get("statement")) and c["id"] not in seen
                and c.get("basis") in BASES and c.get("confidence") in CONFIDENCE):
            add("CONCLUSION_MALFORMED", f"conclusions[{n}] needs unique id, statement, basis EVIDENCED|HYPOTHESIS, confidence HIGH|MEDIUM|LOW")
            continue
        seen.add(c["id"])
        ev = c.get("evidence_ids") if isinstance(c.get("evidence_ids"), list) else []
        good = [x for x in ev if x in observed]
        if c["basis"] == "EVIDENCED" and not (ev and len(good) == len(ev)):
            add("CONCLUSION_UNSUPPORTED", f"conclusions[{n}] is EVIDENCED without OBSERVED evidence; mark it HYPOTHESIS")
        if c["basis"] == "HYPOTHESIS" and c["confidence"] == "HIGH":
            add("CONFIDENCE_EXCEEDS_EVIDENCE", f"conclusions[{n}] is a HYPOTHESIS and cannot be HIGH")
        elif not good and c["confidence"] != "LOW":
            add("CONFIDENCE_EXCEEDS_EVIDENCE", f"conclusions[{n}] has no OBSERVED evidence; confidence must be LOW")
        mf = c.get("merged_from")
        if mf is not None and not (isinstance(mf, list) and mf and all(x in prior for x in mf)):
            add("MERGE_SOURCE_UNKNOWN", f"conclusions[{n}].merged_from must list known prior conclusion ids")
        if _claims_observed(c):
            add("SYNTHESIS_CLAIMS_OBSERVED", f"conclusions[{n}]: a synthesis cannot mark its own content OBSERVED")
    unresolved = synthesis.get("unresolved") if isinstance(synthesis, Mapping) else None
    carried: set[str] = set()
    if not isinstance(unresolved, list):
        add("UNRESOLVED_MISSING", "unresolved must be a list (empty is fine when no open items)")
        unresolved = []
    for n, u in enumerate(unresolved):
        if not (isinstance(u, Mapping) and _s(u.get("id")) and _s(u.get("statement"))):
            add("UNRESOLVED_MALFORMED", f"unresolved[{n}] needs id and statement")
            continue
        carried.add(u["id"])
        if _claims_observed(u):
            add("SYNTHESIS_CLAIMS_OBSERVED", f"unresolved[{n}]: a synthesis cannot mark its own content OBSERVED")
    dropped = sorted(x for x in open_item_ids if x not in carried)
    if dropped:
        add("UNRESOLVED_DROPPED", "open items not carried into the synthesis: " + ", ".join(dropped))
    status = "OK" if not v else ("BLOCKED" if _stakes(profile) else "NOT_PROVEN")
    return {"ok": not v, "status": status, "violations": v, "conclusions_counted": len(seen), "carried": sorted(carried)}
