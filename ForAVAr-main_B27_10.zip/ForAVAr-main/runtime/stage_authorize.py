"""Stage AUTHORIZE (N11 policy gate + authorization): a selected route never grants permission. Moved verbatim (LT-20b)."""
from __future__ import annotations

from typing import Any

try:
    from .policy_gate import evaluate_authorization
    from .stage_common import Run, _early
except ImportError:  # direct imports when runtime/ is on sys.path
    from policy_gate import evaluate_authorization
    from stage_common import Run, _early


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.trace
    frame, evidence, route = r.frame, r.evidence, r.route
    authorization = evaluate_authorization(task_obj, profile, route, adapters)
    trace.append("POLICY_GATE")
    if authorization.get("required"):
        trace.append("AUTHORIZATION")
        if authorization.get("status") != "AUTHORIZED":
            return _early(
                "BLOCKED",
                task_id,
                trace,
                str(authorization.get("reason", "authorization was not granted")),
                frame=frame,
                evidence=evidence,
                route=route,
                authorization=authorization,
                failure_class="AUTHORIZATION_OR_POLICY_BLOCK",
            )
    else:
        trace.append("AUTHORIZATION_NOT_REQUIRED")
    r.authorization = authorization
    return None
