"""Stage ROUTE (N10): adapter route + route contract checks. Body moved verbatim from the slice (LT-20b)."""
from __future__ import annotations

from typing import Any

try:
    from .stage_common import ContractError, Run, _bind_task, _call, _early, _text
except ImportError:  # direct imports when runtime/ is on sys.path
    from stage_common import ContractError, Run, _bind_task, _call, _early, _text


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, adapters, ctx, trace = r.task_obj, r.task_id, r.adapters, r.ctx, r.trace
    frame, evidence = r.frame, r.evidence
    ctx["stage"] = "route"
    route = _call(adapters, "route", task_obj, frame, evidence)
    trace.append("ROUTE")
    ctx["route"] = route
    _bind_task(route, task_id, "route")
    if route.get("status") in {"BLOCKED", "NOT_PROVEN", "REJECTED", "CANCELLED"}:
        return _early(route["status"], task_id, trace, str(route.get("reason", "route did not authorize execution")), frame=frame, evidence=evidence, route=route)
    if route.get("status") != "ROUTED":
        raise ContractError("adapter.route status must be ROUTED or a supported terminal status")
    candidates = route.get("candidate_methods")
    if not isinstance(candidates, list) or not candidates or any(not isinstance(x, str) or not x.strip() for x in candidates):
        raise ContractError("route.candidate_methods must be a non-empty list of method IDs")
    if len(set(candidates)) != len(candidates):
        raise ContractError("route.candidate_methods must not contain duplicates")
    selected = _text(route.get("selected_method"), "route.selected_method")
    if selected not in candidates:
        raise ContractError("route.selected_method must be one of candidate_methods")
    _text(route.get("reason"), "route.reason")
    _text(route.get("stop_rule"), "route.stop_rule")
    if not isinstance(route.get("requires_authorization"), bool):
        raise ContractError("route.requires_authorization must be boolean")
    required_scope = route.get("required_scope", [])
    if not isinstance(required_scope, list) or any(
        not isinstance(scope, str) or not scope.strip() for scope in required_scope
    ):
        raise ContractError("route.required_scope must be a list of non-empty scope strings")
    route["required_scope"] = required_scope
    r.route = route
    return None
