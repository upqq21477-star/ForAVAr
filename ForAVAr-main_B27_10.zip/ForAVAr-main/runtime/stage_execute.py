"""Stage EXECUTE (N12): adapter execute, timeout/fault exits, execution contract, run record. Moved verbatim (LT-20b)."""
from __future__ import annotations

from typing import Any

try:
    from .run_record import build_run_record, run_record_required
    from .stage_common import EXECUTION_STATES, ContractError, Run, _bind_task, _call, _early, _text
except ImportError:  # direct imports when runtime/ is on sys.path
    from run_record import build_run_record, run_record_required
    from stage_common import EXECUTION_STATES, ContractError, Run, _bind_task, _call, _early, _text


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, ctx, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.ctx, r.trace
    frame, evidence, route = r.frame, r.evidence, r.route
    rr_required = run_record_required(profile, r.criteria)
    ctx["stage"] = "execute"
    try:
        execution = _call(adapters, "execute", task_obj, frame, evidence, route)
    except TimeoutError as exc:
        trace.append("EXECUTION")
        receipt = build_run_record(task_id, None, result_status="TIMEOUT_UNKNOWN_SIDE_EFFECT", required=rr_required)
        if profile.get("side_effects") is False:
            return _early("FAILED", task_id, trace, f"execution timed out ({exc}); no side effects declared", frame=frame, evidence=evidence, route=route, failure_class="TOOL_OR_ADAPTER_ERROR", run_record=receipt)
        return _early("INCONCLUSIVE", task_id, trace, f"execution timed out ({exc}); external side effects unknown", frame=frame, evidence=evidence, route=route, failure_class="TOOL_OR_ADAPTER_ERROR", unknown_side_effect=True, run_record=receipt)
    trace.append("EXECUTION")
    ctx["execution"] = execution
    _bind_task(execution, task_id, "execution")
    execution_status = execution.get("status")
    if execution_status not in EXECUTION_STATES:
        raise ContractError(f"invalid execution.status: {execution_status}")
    if execution_status == "TIMEOUT_UNKNOWN_SIDE_EFFECT":
        receipt = build_run_record(task_id, execution, result_status=execution_status, required=rr_required)
        return _early("INCONCLUSIVE", task_id, trace, str(execution.get("reason", "execution timed out; external side effects unknown")), frame=frame, evidence=evidence, route=route, execution=execution, failure_class="TOOL_OR_ADAPTER_ERROR", unknown_side_effect=True, run_record=receipt)
    if execution_status in {"BLOCKED", "FAILED", "NOT_RUN"}:
        status = "BLOCKED" if execution_status == "BLOCKED" else ("FAILED" if execution_status == "FAILED" else "NOT_EXECUTED")
        extra = {}
        if execution_status == "FAILED":  # something actually ran: keep its receipt
            extra["run_record"] = build_run_record(task_id, execution, result_status=execution_status, required=rr_required)
        return _early(status, task_id, trace, str(execution.get("reason", f"execution status: {execution_status}")), frame=frame, evidence=evidence, route=route, execution=execution, **extra)
    _text(execution.get("execution_id"), "execution.execution_id")
    _text(execution.get("result_summary"), "execution.result_summary")
    run_record = build_run_record(task_id, execution, result_status=execution_status, required=rr_required)
    ctx["run_record"] = run_record
    r.execution, r.run_record = execution, run_record
    return None
