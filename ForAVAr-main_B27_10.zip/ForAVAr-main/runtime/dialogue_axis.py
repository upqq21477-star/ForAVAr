"""对話主軸 (dialogue axis): an opt-in, switchable conversation front door. Pure, stdlib; extends P2-F24 / preflight (never a second control system).

When the switch is ON, a new conversation must first settle its axis chain (nodes below) with the user. Until every REQUIRED node is
CONFIRMED the gate says HOLD and names at most MAX_QUESTIONS questions (PR-045: no over-interrupting), asked in dependency order starting
from the core (purpose). If the opening message already carries a complete chain, ``open_conversation`` echoes it and proceeds
(ECHO_AND_PROCEED) with no extra questions. Ambiguous nodes carry 2-4 clearly different branches plus a free-text "other" (the user may
always type a correction). Editing one node only re-opens the nodes that depend on it (changing the purpose re-opens the chain).
Confirming an axis is NOT authorization: policy_gate still decides protected actions. The OFF switch is the user's way out of HOLD;
a malformed switch/config reads as OFF (this is a UX aid, so the safe direction is not to trap the user). The model fills node
contents (a SLOT); this module only keeps the bookkeeping deterministic. Default is OFF.

Placement (B25.1e): the axis runs BEFORE any task exists, so it needs nothing from inside the slice and must not live in it (the slice is a hub:
touching it widens the impact set to most tests/tools). ``run_with_axis`` is the single call site: callers pass the runner in, so this
module imports nothing from the slice and the slice never imports this module (tests/test_dialogue_axis.py enforces both).
Single source of intent: a confirmed axis seeds task.goal (purpose) and acceptance_criteria (done condition) only where the task leaves
them out; an explicit task value always wins and is never overwritten.
"""
from __future__ import annotations

import copy
from collections.abc import Mapping
from typing import Any

MAX_QUESTIONS = 2
MAX_BRANCHES = 4
# (id, label, required, depends_on) -- order is the dependency/question order.
NODES = (
    ("purpose", "目的（核心）", True, ()),
    ("object", "對象／產出", True, ("purpose",)),
    ("start", "起點（現況與已有材料）", True, ("object",)),
    ("done", "完成條件", True, ("purpose",)),
    ("constraints", "約束與非目標", True, ("purpose",)),
    ("method", "方法", False, ("purpose", "done")),
)
IDS = tuple(n[0] for n in NODES)
LABEL = {n[0]: n[1] for n in NODES}
REQUIRED = tuple(n[0] for n in NODES if n[2])
DEPS = {n[0]: n[3] for n in NODES}
STATUSES = {"CONFIRMED", "ASSUMED", "UNKNOWN", "BRANCHES", "STALE"}
SOURCES = ("ai_proposed", "user_edit", "user_choice")  # who authored a node value; a node without "source" reads as ai_proposed (older states stay valid)


def dependents(node: str) -> list[str]:
    """All nodes that depend on ``node`` (transitively), in NODES order."""
    found: set[str] = set()
    grew = True
    while grew:
        grew = False
        for nid, deps in DEPS.items():
            if nid not in found and (node in deps or found & set(deps)):
                found.add(nid)
                grew = True
    return [n for n in IDS if n in found]


def is_enabled(settings: Any) -> bool:
    """Switch lives in the caller's settings: {"dialogue_axis": {"enabled": true}}. Anything else is OFF."""
    cfg = settings.get("dialogue_axis") if isinstance(settings, Mapping) else None
    return isinstance(cfg, Mapping) and cfg.get("enabled") is True


def new_state() -> dict[str, Any]:
    return {"nodes": {}}


def _node(state: Mapping[str, Any], nid: str) -> dict[str, Any]:
    n = state.get("nodes", {}).get(nid) if isinstance(state, Mapping) and isinstance(state.get("nodes"), Mapping) else None
    ok = isinstance(n, Mapping) and n.get("status") in STATUSES and (n.get("status") in {"UNKNOWN", "BRANCHES"} or (isinstance(n.get("value"), str) and n["value"].strip()))
    if not ok:
        return {"status": "UNKNOWN", "value": None}
    out = {k: v for k, v in n.items() if k not in ("source", "quote")}
    if n.get("source") in SOURCES:
        out["source"] = n["source"]
    if isinstance(n.get("quote"), str) and n["quote"].strip():
        out["quote"] = n["quote"].strip()
    return out


def source_of(state: Mapping[str, Any], nid: str) -> str:
    """Origin of a node's value: ai_proposed (also the default for nodes without a recorded source), user_edit or user_choice."""
    _check_id(nid)
    return _node(state, nid).get("source", "ai_proposed")


def _keep(n: Mapping[str, Any]) -> dict[str, Any]:
    return {k: n[k] for k in ("source", "quote") if k in n}


def _check_id(nid: str) -> None:
    if nid not in IDS:
        raise ValueError(f"unknown axis node {nid!r}")


def propose(state: Mapping[str, Any], nid: str, value: str | None = None, branches: list[Mapping[str, str]] | None = None) -> dict[str, Any]:
    """Model fills a node: a value (ASSUMED), 2-4 distinct branches (BRANCHES), or neither (UNKNOWN). A CONFIRMED node is never overwritten."""
    _check_id(nid)
    st = copy.deepcopy(dict(state)) if state.get("nodes") is not None else new_state()
    if _node(st, nid)["status"] == "CONFIRMED":
        raise ValueError(f"node {nid} is already CONFIRMED; use edit()")
    if branches:
        ids = [b.get("id") for b in branches]
        labels = [b.get("label") for b in branches]
        if not 2 <= len(branches) <= MAX_BRANCHES or len(set(ids)) != len(ids) or len(set(labels)) != len(labels) or \
                not all(isinstance(x, str) and x.strip() for x in ids + labels + [b.get("meaning") for b in branches]):
            raise ValueError(f"branches for {nid} need 2-{MAX_BRANCHES} entries with distinct non-blank id/label and a meaning")
        st["nodes"][nid] = {"status": "BRANCHES", "value": None, "branches": [dict(b) for b in branches]}
    elif isinstance(value, str) and value.strip():
        st["nodes"][nid] = {"status": "ASSUMED", "value": value.strip()}
    else:
        st["nodes"][nid] = {"status": "UNKNOWN", "value": None}
    return st


def confirm(state: Mapping[str, Any], nid: str) -> dict[str, Any]:
    _check_id(nid)
    n = _node(state, nid)
    if n["status"] not in {"ASSUMED", "STALE"}:
        raise ValueError(f"node {nid} is {n['status']}: choose a branch or type a value first")
    st = copy.deepcopy(dict(state))
    st["nodes"][nid] = {"status": "CONFIRMED", "value": n["value"], **_keep(n)}  # no source recorded = ai_proposed: confirming an untouched proposal stays byte-identical to before
    return st


def confirm_all(state: Mapping[str, Any]) -> dict[str, Any]:
    """User says 'all correct': confirms every ASSUMED/STALE node that has a value; UNKNOWN/BRANCHES stay open."""
    st = copy.deepcopy(dict(state)) if state.get("nodes") is not None else new_state()
    for nid in IDS:
        if _node(st, nid)["status"] in {"ASSUMED", "STALE"}:
            st = confirm(st, nid)
    return st


def _invalidate(st: dict[str, Any], nid: str) -> list[str]:
    hit = []
    for d in dependents(nid):
        n = _node(st, d)
        if n["status"] in {"CONFIRMED", "ASSUMED"}:
            st["nodes"][d] = {"status": "STALE", "value": n["value"], **_keep(n)}  # old value (and who wrote it) kept as a proposal to re-confirm
            hit.append(d)
    return hit


def edit(state: Mapping[str, Any], nid: str, text: str, quote: str | None = None, _source: str = "user_edit") -> tuple[dict[str, Any], dict[str, Any]]:
    """User types a correction for one node (circle-and-fix). Returns (state, {"changed", "reopened", "core_changed"}).
    The node records who wrote it (source) and, if given, the user's original sentence (quote); an explicit edit is always the user's act."""
    _check_id(nid)
    if not isinstance(text, str) or not text.strip():
        raise ValueError("edit text must be non-blank")
    st = copy.deepcopy(dict(state)) if state.get("nodes") is not None else new_state()
    old = _node(st, nid)
    changed = old["value"] != text.strip()
    st["nodes"][nid] = {"status": "CONFIRMED", "value": text.strip(), "source": _source}
    if isinstance(quote, str) and quote.strip():
        st["nodes"][nid]["quote"] = quote.strip()
    reopened = _invalidate(st, nid) if changed and old["status"] == "CONFIRMED" else []
    return st, {"changed": changed, "reopened": reopened, "core_changed": changed and nid == "purpose" and old["status"] == "CONFIRMED"}


def choose(state: Mapping[str, Any], nid: str, branch_id: str, quote: str | None = None) -> tuple[dict[str, Any], dict[str, Any]]:
    _check_id(nid)
    n = _node(state, nid)
    match = [b for b in n.get("branches", []) if b.get("id") == branch_id] if n["status"] == "BRANCHES" else []
    if not match:
        raise ValueError(f"node {nid} has no branch {branch_id!r}")
    return edit(state, nid, f"{match[0]['label']}：{match[0]['meaning']}", quote, "user_choice")


def reopen(state: Mapping[str, Any], nid: str) -> dict[str, Any]:
    """Scope expansion: the node and everything depending on it must be re-confirmed (values kept as proposals)."""
    _check_id(nid)
    st = copy.deepcopy(dict(state)) if state.get("nodes") is not None else new_state()
    n = _node(st, nid)
    if n["value"]:
        st["nodes"][nid] = {"status": "STALE", "value": n["value"], **_keep(n)}
    _invalidate(st, nid)
    return st


def _question(state: Mapping[str, Any], nid: str) -> dict[str, Any]:
    n = _node(state, nid)
    q: dict[str, Any] = {"node": nid, "label": LABEL[nid], "kind": {"BRANCHES": "CHOICE", "UNKNOWN": "OPEN"}.get(n["status"], "CONFIRM")}
    if n["status"] == "BRANCHES":
        q["options"] = [dict(b) for b in n["branches"]] + [{"id": "OTHER", "label": "其他", "meaning": "自行輸入"}]
    elif n["value"]:
        q["proposed"] = n["value"]
    return q


def assess(state: Mapping[str, Any], enabled: bool) -> dict[str, Any]:
    """OFF -> release. Else release only when every REQUIRED node is CONFIRMED; otherwise HOLD with <= MAX_QUESTIONS questions."""
    if enabled is not True:
        return {"mode": "OFF", "release": True, "pending": [], "questions": []}
    pending = [n for n in REQUIRED if _node(state, n)["status"] != "CONFIRMED"]
    if not pending:
        return {"mode": "CONFIRMED", "release": True, "pending": [], "questions": []}
    ready = [n for n in pending if all(_node(state, d)["status"] == "CONFIRMED" for d in DEPS[n])]  # ask from the core outward
    return {"mode": "HOLD", "release": False, "pending": pending, "questions": [_question(state, n) for n in ready[:MAX_QUESTIONS]]}


def open_conversation(state: Mapping[str, Any], enabled: bool) -> tuple[dict[str, Any], dict[str, Any]]:
    """First turn. A complete chain in the opening message (all required nodes carry a value, none UNKNOWN/BRANCHES/STALE) is echoed
    and auto-confirmed (ECHO_AND_PROCEED, no questions); anything less goes through ``assess`` (HOLD)."""
    if enabled is not True:
        return dict(state), assess(state, False)
    complete = all(_node(state, n)["status"] in {"ASSUMED", "CONFIRMED"} for n in REQUIRED)
    if complete:
        st = confirm_all(state)
        return st, {"mode": "ECHO_AND_PROCEED", "release": True, "pending": [], "questions": [], "echo": render(st)}
    return dict(state), assess(state, True)


def gate(cfg: Any) -> dict[str, Any]:
    """Slice entry: cfg = {"enabled": bool, "state": axis state}. Never raises. Malformed cfg or enabled != True reads as OFF;
    enabled with an unreadable state is HOLD (the user asked for the axis, so an unreadable one cannot count as confirmed)."""
    if not isinstance(cfg, Mapping) or cfg.get("enabled") is not True:
        return assess({}, False)
    state = cfg.get("state")
    return assess(state if isinstance(state, Mapping) else {}, True)


def to_task_seed(state: Mapping[str, Any]) -> dict[str, Any]:
    """Confirmed axis -> task fields it can supply. Unconfirmed nodes supply nothing (never seed from a proposal)."""
    seed: dict[str, Any] = {}
    purpose, done = _node(state, "purpose"), _node(state, "done")
    if purpose["status"] == "CONFIRMED":
        seed["goal"] = purpose["value"]
    if done["status"] == "CONFIRMED":
        seed["acceptance_criteria"] = [{"id": "AXIS-DONE", "description": done["value"], "required_evidence_kinds": []}]
    cons = _node(state, "constraints")
    if cons["status"] == "CONFIRMED":
        seed["confirmed_constraints"] = [cons["value"]]  # reaches the frame stage through the task (frame is that stage's output, not a task field)
    return seed


def run_with_axis(task: Any, adapters: Any, run: Any) -> dict[str, Any]:
    """The call site. ``run`` is the task runner (e.g. run_vertical_slice). Without ``dialogue_axis`` in the task, behaviour is unchanged.
    Unconfirmed axis -> NOT_EXECUTED / ASK_USER_TO_CONFIRM_AXIS and ``run`` is never called. Otherwise the field is stripped, the axis
    seeds missing goal/acceptance_criteria, and the axis gate result is attached to the receipt."""
    if not isinstance(task, Mapping) or "dialogue_axis" not in task:
        return run(task, adapters)
    cfg = task["dialogue_axis"]
    axis = gate(cfg)
    if not axis["release"]:
        return {"task_id": task.get("task_id"), "status": "NOT_EXECUTED", "trace": ["DIALOGUE_AXIS"], "dialogue_axis": axis,
                "feedback": {"action": "ASK_USER_TO_CONFIRM_AXIS", "reason": "dialogue axis unconfirmed: " + ", ".join(axis["pending"])}}
    seed = to_task_seed(cfg.get("state", {})) if axis["mode"] != "OFF" and isinstance(cfg, Mapping) else {}
    merged = {**seed, **{k: v for k, v in task.items() if k != "dialogue_axis"}}
    receipt = run(merged, adapters)
    if isinstance(receipt, dict):
        receipt = {**receipt, "dialogue_axis": axis}
    return receipt


def render(state: Mapping[str, Any]) -> str:
    """Compact axis text: replaces long history when the conversation grows, and is the echo shown to the user."""
    mark = {"CONFIRMED": "已確認", "ASSUMED": "待確認", "STALE": "需重新確認", "UNKNOWN": "未定", "BRANCHES": "待選"}
    lines = []
    for nid in IDS:
        n = _node(state, nid)
        if n["status"] == "UNKNOWN" and nid not in REQUIRED:
            continue
        lines.append(f"{LABEL[nid]}：{n['value'] or '—'}（{mark[n['status']]}）")
    return "\n".join(lines)
