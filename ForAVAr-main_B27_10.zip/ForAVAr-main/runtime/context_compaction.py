"""Context compaction with a must-keep set and a rejecting validator (LT-05; blueprint delivery_program).

Shrinks a long working context to a character budget WITHOUT losing what the task stands on. Distinct from
``state_bundle.compact_bundle`` (that one thins run_records inside a persisted bundle; this one thins the free-form
history that is fed back to a model). Neither calls the other.

Context shape (mapping). Must-keep keys are never dropped, rewritten or reordered:
  goal                    str  -- purpose of the task
  axis                    list -- axis chain (dialogue_axis nodes or lines)
  unknowns                list -- open / critical unknowns
  decisions               list -- decisions WITH their evidence references (evidence_ids stay attached)
  pending_authorizations  list -- authorizations still awaited
Compactable key: ``entries`` (oldest -> newest list of history items). Every other key passes through untouched.

Deterministic baseline (no model): keep must-keep verbatim, keep the newest ``entries`` that fit the budget, replace the
omitted older ones by ONE marker {count, sha256}. The marker is recomputed by the validator, so a forged or stale marker is
rejected. Optional SLOT ``summarizer(omitted_entries, must_keep) -> str``: its text is stored as an UNVERIFIED_SUMMARY
(never evidence, never OBSERVED), capped and trimmed to the room left (dropped if under 20 chars fit); an exception or an unusable return falls back to the
baseline. ``validate_compaction`` is the gate: any lost/changed must-keep item, rewritten or reordered entry, bad marker, or
over-budget result is REJECTED and the caller gets the ORIGINAL context back (fail-closed: no compaction beats a lossy one).
Whether a semantic summary is any good is NOT checked here (LT-05.eval, POST_E4). Stdlib only; imports nothing from runtime (so no existing gate's blast radius grows).
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping
from typing import Any

SCHEMA = "foravar.context_compaction/1"
MUST_KEEP_KEYS = ("goal", "axis", "unknowns", "decisions", "pending_authorizations")
ENTRIES = "entries"
SUMMARY_CAP, MIN_SUMMARY = 1200, 20
SUMMARY_STATUS = "UNVERIFIED_SUMMARY"
MARKER_KEY = "compacted"
MARKER_COST = 160  # reserved budget for the omission marker
SLACK = 40  # reserved for the "entries"/"summary" keys and separators


def is_text(v: Any) -> bool:
    return isinstance(v, str) and bool(v.strip())


def _canon(v: Any) -> str:
    return json.dumps(v, ensure_ascii=False, sort_keys=True, default=str)


def _size(v: Any) -> int:
    return len(_canon(v))


def _digest(items: list[Any]) -> str:
    return hashlib.sha256(_canon(items).encode("utf-8")).hexdigest()


def must_keep_set(context: Mapping[str, Any]) -> dict[str, Any]:
    """The must-keep part of ``context`` (only keys that are present)."""
    return {k: context[k] for k in MUST_KEEP_KEYS if k in context}


def _is_marker(x: Any) -> bool:
    return isinstance(x, Mapping) and x.get(MARKER_KEY) is True


def _split_entries(entries: Any) -> tuple[Mapping[str, Any] | None, list[Any]]:
    """(leading marker or None, real entries) -- a context may already be compacted once."""
    if isinstance(entries, list) and entries and _is_marker(entries[0]):
        return entries[0], list(entries[1:])
    return None, list(entries) if isinstance(entries, list) else []


def validate_compaction(original: Mapping[str, Any], compacted: Mapping[str, Any], budget: int) -> list[str]:
    """Problems that make ``compacted`` unacceptable (empty = acceptable). Never raises; pure."""
    if not isinstance(original, Mapping) or not isinstance(compacted, Mapping):
        return ["context must be an object"]
    probs: list[str] = []
    for k in MUST_KEEP_KEYS:  # must-keep: verbatim, same position inside the list, nothing added/removed
        if k in original and _canon(original[k]) != _canon(compacted.get(k, "__MISSING__")):
            probs.append(f"must-keep changed or lost: {k}")
        if k not in original and k in compacted:
            probs.append(f"must-keep appeared from nowhere: {k}")
    for k in original:  # every other non-entries key passes through untouched
        if k != ENTRIES and k not in MUST_KEEP_KEYS and _canon(original[k]) != _canon(compacted.get(k, "__MISSING__")):
            probs.append(f"pass-through key changed or lost: {k}")
    probs += _validate_entries(original, compacted)
    summ = compacted.get("summary")
    if summ is not None:
        # exactly {status, text}: no observed/observed_at/evidence fields can ride along, so it can never pass as evidence
        if not (isinstance(summ, Mapping) and set(summ) == {"status", "text"} and summ["status"] == SUMMARY_STATUS and is_text(summ["text"])):
            probs.append("summary must be exactly {status: UNVERIFIED_SUMMARY, text}")
        elif len(summ["text"]) > SUMMARY_CAP:
            probs.append("summary exceeds cap")
    if _size(compacted) > budget and _size(must_keep_set(compacted)) <= budget:
        probs.append(f"over budget: {_size(compacted)} > {budget}")
    return probs


def _validate_entries(original: Mapping[str, Any], compacted: Mapping[str, Any]) -> list[str]:
    if ENTRIES not in original:
        return [f"{ENTRIES} appeared from nowhere"] if ENTRIES in compacted else []
    if not isinstance(original[ENTRIES], list):  # not a history list: pass-through, never touched
        return [] if _canon(original[ENTRIES]) == _canon(compacted.get(ENTRIES, "__MISSING__")) else [f"{ENTRIES} changed or lost"]
    old_marker, old = _split_entries(original[ENTRIES])
    new_marker, new = _split_entries(compacted.get(ENTRIES))
    old_canon = [_canon(x) for x in old]
    # kept entries: a verbatim, order-preserving suffix of the original entries (newest kept, oldest dropped)
    if new and [_canon(x) for x in new] != old_canon[len(old) - len(new):]:
        return ["entries rewritten, reordered or not a suffix of the original"]
    dropped = old[:len(old) - len(new)]
    prior = (old_marker.get("omitted_count", 0) if old_marker else 0)
    if not dropped:
        return [] if _canon(new_marker) == _canon(old_marker) else ["marker changed although nothing was omitted"]
    want = {MARKER_KEY: True, "omitted_count": prior + len(dropped)}
    if not isinstance(new_marker, Mapping) or new_marker.get("omitted_count") != want["omitted_count"]:
        return ["omission marker missing or its count is wrong"]
    expect = _digest(([dict(old_marker)] if old_marker else []) + dropped)
    return [] if new_marker.get("omitted_sha256") == expect else ["omission marker digest does not match the omitted entries"]


def _summary(summarizer: Callable[..., Any] | None, omitted: list[Any], keep: Mapping[str, Any], room: int) -> dict[str, Any] | None:
    if summarizer is None or not omitted:
        return None
    try:
        text = summarizer(list(omitted), dict(keep))
    except Exception:  # noqa: BLE001 -- a failing SLOT must never break or loosen compaction
        return None
    if not is_text(text):
        return None
    overhead = _size({"status": SUMMARY_STATUS, "text": ""})
    text = text.strip()[:max(0, min(SUMMARY_CAP, room - overhead))]  # trimmed to the room left, never over budget
    return {"status": SUMMARY_STATUS, "text": text} if len(text) >= MIN_SUMMARY else None


def compact(context: Mapping[str, Any], budget_chars: int, summarizer: Callable[..., Any] | None = None) -> dict[str, Any]:
    """Compact ``context`` to ``budget_chars`` (characters of canonical JSON). Never mutates the input.

    Returns {schema, accepted, compacted, context, problems, stats}. ``context`` is ALWAYS safe to use: the compacted one when
    accepted, otherwise the original. A must-keep set larger than the budget is kept whole (flag ``must_keep_over_budget``).
    """
    if isinstance(budget_chars, bool) or not isinstance(budget_chars, int) or budget_chars < 1:
        raise ValueError("budget_chars must be a positive integer")
    if not isinstance(context, Mapping):
        raise ValueError("context must be an object")
    original = json.loads(_canon(context))  # deep copy
    if _size(original) <= budget_chars:
        return _result(original, original, True, False, [], budget_chars)
    marker, entries = _split_entries(original.get(ENTRIES))
    listed = isinstance(original.get(ENTRIES), list)
    out = {k: v for k, v in original.items() if k != ENTRIES}
    room = budget_chars - _size(out) - MARKER_COST - SLACK
    kept: list[Any] = []
    for e in reversed(entries):  # newest first
        if _size(e) + 2 > room:
            break
        kept.insert(0, e)
        room -= _size(e) + 2
    dropped = entries[:len(entries) - len(kept)]
    if not listed:
        if ENTRIES in original:
            out[ENTRIES] = original[ENTRIES]
    elif dropped or marker:
        prior = (marker.get("omitted_count", 0) if marker else 0)
        head = {MARKER_KEY: True, "omitted_count": prior + len(dropped),
                "omitted_sha256": _digest(([dict(marker)] if marker else []) + dropped)}
        out[ENTRIES] = [head] + kept
    else:
        out[ENTRIES] = kept
    summ = _summary(summarizer, dropped, must_keep_set(original), room - 20)
    if summ:
        out["summary"] = summ
    problems = validate_compaction(original, out, budget_chars)
    if problems:
        return _result(original, original, False, False, problems, budget_chars)
    return _result(original, out, True, True, [], budget_chars)


def _result(original: Mapping[str, Any], chosen: Mapping[str, Any], accepted: bool, compacted: bool,
            problems: list[str], budget: int) -> dict[str, Any]:
    must = _size(must_keep_set(original))
    return {
        "schema": SCHEMA, "accepted": accepted, "compacted": compacted, "context": dict(chosen), "problems": problems,
        "stats": {"budget": budget, "before": _size(original), "after": _size(chosen), "must_keep_size": must,
                  "must_keep_over_budget": must > budget,
                  "summary": SUMMARY_STATUS if isinstance(chosen.get("summary"), Mapping) else "NONE"},
    }
