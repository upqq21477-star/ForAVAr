"""Stable shared definitions for runtime modules (B24 C2). Leaf: imports nothing local; stdlib only.

Why this file exists: runtime modules other than the integrators (slice, loop_controller) may import only this file
(tools/check_consistency.py rule ``runtime_coupling``). It holds the contract vocabulary and the few predicates that
must have ONE definition across gates (what counts as high-stakes, what counts as a claim of observation).
Keep it small and deliberate: a change here reaches every gate (see ``tools/closure_report.py impact``).
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

# F5 repair branches (how far back to go). Orthogonal to FAILURE_CLASSES below.
FAILURE_BRANCHES = {
    "NONE",
    "LOCAL_FAILURE",
    "METHOD_FAILURE",
    "MODEL_FAILURE",
    "FRAME_FAILURE",
    "AUTHORIZATION_FAILURE",
    "EVIDENCE_GAP",
    "NO_FEASIBLE_SOLUTION",
}
# Blueprint runtime_contract.failure_classes: root-cause categories (optional field).
FAILURE_CLASSES = {
    "GOAL_OR_SEMANTIC_ERROR",
    "SOURCE_OR_EVIDENCE_ERROR",
    "INFERENCE_OR_MODEL_ERROR",
    "METHOD_OR_ROUTING_ERROR",
    "TOOL_OR_ADAPTER_ERROR",
    "AUTHORIZATION_OR_POLICY_BLOCK",
    "PERSISTENCE_OR_STATE_ERROR",
    "INTEGRATION_OR_DEPENDENCY_UPDATE_ERROR",
    "ACCEPTANCE_OR_MEASUREMENT_ERROR",
    "COST_OR_STOP_ERROR",
}


def is_text(v: Any) -> bool:
    return isinstance(v, str) and bool(v.strip())


def claims_observed(item: Any) -> bool:
    """True if a model/synthesis item presents itself as an observation (only evidence records may)."""
    return isinstance(item, Mapping) and (item.get("status") == "OBSERVED" or "observed_at" in item or item.get("observed") is True)


def stakes(profile: Mapping[str, Any]) -> bool:
    """High-stakes: risk HIGH/CRITICAL, side effects not explicitly False, or governance >= G2."""
    g = profile.get("governance")
    g_hi = g is not None and not (isinstance(g, str) and g in {"G0", "G1"}) and g not in (0, 1) or g is True
    return profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is not False or bool(g_hi)
