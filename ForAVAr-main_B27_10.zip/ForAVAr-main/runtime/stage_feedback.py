"""Stage FEEDBACK (N16-N17): failure branch/class contract, feedback action, final receipt. Last stage: always returns the result. Moved verbatim (LT-20c)."""
from __future__ import annotations

from typing import Any

try:
    from .common import FAILURE_BRANCHES, FAILURE_CLASSES
    from .evidence_gate import ACTION as EVIDENCE_ACTION
    from .stage_common import IMPLEMENTATION_STATUS, IMPLEMENTATION_VERSION, ContractError, Run, _downgrades, _feedback
except ImportError:  # direct imports when runtime/ is on sys.path
    from common import FAILURE_BRANCHES, FAILURE_CLASSES
    from evidence_gate import ACTION as EVIDENCE_ACTION
    from stage_common import IMPLEMENTATION_STATUS, IMPLEMENTATION_VERSION, ContractError, Run, _downgrades, _feedback


def run(r: Run) -> dict[str, Any]:
    """Build the final receipt from the state the earlier stages left on ``r``."""
    task_id, trace, evaluation, status = r.task_id, r.trace, r.evaluation, r.status
    gate, gate_note, rr_note, synth_note = r.gate, r.gate_note, r.rr_note, r.synth_note
    failure_branch = evaluation.get("failure_branch")
    failure_class = evaluation.get("failure_class")
    if failure_branch is None and failure_class in FAILURE_BRANCHES:  # legacy key: failure_class held the repair branch
        failure_branch, failure_class = failure_class, None
    failure_branch = "NONE" if failure_branch is None else failure_branch
    if failure_branch not in FAILURE_BRANCHES:
        raise ContractError(f"invalid evaluation.failure_branch: {failure_branch}")
    if failure_class is not None and failure_class not in FAILURE_CLASSES:
        raise ContractError(f"invalid evaluation.failure_class: {failure_class}")
    reason = str(evaluation.get("reason", ""))
    for note in (rr_note, gate_note, synth_note):
        if note:
            reason = f"{reason}; {note}" if reason else note
    feedback = _feedback(status, failure_branch, reason)
    if gate_note:  # R8: the gate, not the receipt, is why this PASS was withheld -> refresh/resolve, not generic closeout
        feedback = {"action": EVIDENCE_ACTION, "reason": reason}
        failure_class = failure_class or "SOURCE_OR_EVIDENCE_ERROR"
    if r.synth_failure:
        failure_class = failure_class or "INFERENCE_OR_MODEL_ERROR"
    trace.append("FEEDBACK")
    return {
        "task_id": task_id,
        "implementation_version": IMPLEMENTATION_VERSION,
        "implementation_status": IMPLEMENTATION_STATUS,
        "status": status,
        "trace": trace,
        "frame": r.frame,
        "evidence": r.evidence,
        "route": r.route,
        "authorization": r.authorization,
        "execution": r.execution,
        "run_record": r.run_record,
        "acceptance": {"criteria_results": r.normalized, "failure_branch": failure_branch, "failure_class": failure_class, "reason": reason},
        "feedback": feedback,
        "evidence_gate": gate,
        "evidence_downgrades": _downgrades(r.all_records, r.evidence_index),
        "frame_gate": r.frame_gate,
        "model": r.model,
        "model_gate": r.model_gate,
        "synthesis": r.synthesis,
        "synthesis_gate": r.synthesis_gate,
        "runtime_observation_present": any(
            item.get("kind") == "RUNTIME_OBSERVATION" and item.get("status") == "OBSERVED"
            and all(isinstance(item.get(k), str) and item[k].strip() for k in ("run_id", "command", "target_revision", "observed_at", "environment", "output_digest"))
            and isinstance(item.get("exit_code"), int)
            for item in r.evidence_index.values()
        ),
    }
