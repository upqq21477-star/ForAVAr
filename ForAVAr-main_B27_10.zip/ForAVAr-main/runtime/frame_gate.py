"""Frame completeness gate (R4; blueprint N02 boundary/dependency, N03 competing frames). Pure, stdlib, never raises.

Opt-in: the slice runs it when ``task.profile.frame_gate`` is True. Rules (each violation names its rule):
  N02  in_scope non-empty; every out_of_scope entry is {item, reason}; ``dependencies`` is a list of
       {id, direction UPSTREAM|DOWNSTREAM|EXTERNAL, status KNOWN|UNKNOWN, impact LOW|MEDIUM|HIGH}; an empty list needs
       ``no_dependencies_basis``; a HIGH-impact UNKNOWN dependency must be carried in ``unknowns`` (never assumed absent).
  N03  when risk is HIGH/CRITICAL or governance >= G2 (unparseable governance fails closed): >=2 competing frames
       (adopted + >=1 distinct alternative {frame_id, summary, rejected_reason}) and a non-blank ``adopted_reason``.
Result status: any violation -> BLOCKED if the task is high-stakes (risk HIGH/CRITICAL, side_effects not False,
governance >= G2, or a HIGH-impact UNKNOWN dependency), else NOT_PROVEN. This checks form, not whether the frames are good.
"""
from __future__ import annotations

from collections.abc import Mapping
from typing import Any

DIRECTIONS = {"UPSTREAM", "DOWNSTREAM", "EXTERNAL"}
DEP_STATUS = {"KNOWN", "UNKNOWN"}
IMPACTS = {"LOW", "MEDIUM", "HIGH"}


def _s(v: Any) -> bool:
    return isinstance(v, str) and bool(v.strip())


def g_level(profile: Mapping[str, Any]) -> int:
    """Governance level from profile.governance ('G0'..'G3' or int 0..3); missing -> 0; unparseable -> 3 (fail closed)."""
    g = profile.get("governance")
    if g is None:
        return 0
    if isinstance(g, bool):
        return 3
    if isinstance(g, int):
        return g if 0 <= g <= 3 else 3
    if isinstance(g, str) and len(g) == 2 and g[0] == "G" and g[1] in "0123":
        return int(g[1])
    return 3


def competing_required(profile: Mapping[str, Any]) -> bool:
    return profile.get("risk_level") in {"HIGH", "CRITICAL"} or g_level(profile) >= 2


def _carried(unknowns: Any, dep_id: str) -> bool:
    for u in unknowns if isinstance(unknowns, list) else []:
        if u == dep_id or (isinstance(u, Mapping) and dep_id in (u.get("id"), u.get("dependency_id"))):
            return True
    return False


def assess_frame(profile: Mapping[str, Any], frame: Mapping[str, Any]) -> dict[str, Any]:
    v: list[dict[str, str]] = []
    add = lambda rule, detail: v.append({"rule": rule, "detail": detail})  # noqa: E731
    scope = frame.get("in_scope")
    if not (isinstance(scope, list) and scope and all(_s(x) for x in scope)):
        add("BOUNDARY_IN_SCOPE", "in_scope must be a non-empty list of non-blank strings")
    out = frame.get("out_of_scope")
    for n, e in enumerate(out if isinstance(out, list) else []):
        if not (isinstance(e, Mapping) and _s(e.get("item")) and _s(e.get("reason"))):
            add("EXCLUSION_REASON", f"out_of_scope[{n}] needs item and reason")
    deps = frame.get("dependencies")
    high_unknown: list[str] = []
    if not isinstance(deps, list):
        add("DEPENDENCIES_UNDECLARED", "dependencies must be a list")
    else:
        if not deps and not _s(frame.get("no_dependencies_basis")):
            add("DEPENDENCIES_UNDECLARED", "empty dependencies need no_dependencies_basis")
        seen: set[str] = set()
        for n, d in enumerate(deps):
            ok = (isinstance(d, Mapping) and _s(d.get("id")) and d.get("direction") in DIRECTIONS
                  and d.get("status") in DEP_STATUS and d.get("impact") in IMPACTS and d["id"] not in seen)
            if not ok:
                add("DEPENDENCY_MALFORMED", f"dependencies[{n}] needs unique id, direction, status, impact")
                continue
            seen.add(d["id"])
            if d["status"] == "UNKNOWN" and d["impact"] == "HIGH":
                high_unknown.append(d["id"])
                if not _carried(frame.get("unknowns"), d["id"]):
                    add("HIGH_IMPACT_UNKNOWN_DEPENDENCY_NOT_CARRIED", f"{d['id']} must appear in unknowns, not be assumed absent")
    alts = frame.get("alternatives")
    need = competing_required(profile)
    valid_alts = 0
    ids = {frame.get("frame_id")}
    for n, a in enumerate(alts if isinstance(alts, list) else []):
        if not (isinstance(a, Mapping) and _s(a.get("frame_id")) and _s(a.get("summary")) and _s(a.get("rejected_reason"))
                and a["frame_id"] not in ids):
            add("ALTERNATIVE_MALFORMED", f"alternatives[{n}] needs distinct frame_id, summary, rejected_reason")
            continue
        ids.add(a["frame_id"])
        valid_alts += 1
    if alts is not None and not isinstance(alts, list):
        add("ALTERNATIVE_MALFORMED", "alternatives must be a list")
    if need:
        if valid_alts < 1:
            add("COMPETING_FRAMES_MISSING", "high-risk or G>=2 task needs >=2 frames (adopted + >=1 alternative)")
        if not _s(frame.get("adopted_reason")):
            add("ADOPTION_REASON_MISSING", "adopted_reason required when competing frames are required")
    stakes = (profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is not False
              or g_level(profile) >= 2 or bool(high_unknown))
    status = "OK" if not v else ("BLOCKED" if stakes else "NOT_PROVEN")
    return {"ok": not v, "status": status, "violations": v, "competing_required": need,
            "frames_counted": 1 + valid_alts, "high_impact_unknown_dependencies": high_unknown}
