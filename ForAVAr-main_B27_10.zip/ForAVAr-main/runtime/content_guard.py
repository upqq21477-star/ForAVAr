"""Content-level scan of untrusted text (PR-009). Heuristic, fail-closed, stdlib only.

Authorization stays fail-closed in policy_gate regardless of content; this adds a second,
content-level layer: evidence whose summary looks like an embedded instruction is
QUARANTINED (status != OBSERVED), so the slice can no longer cite it as proof -> UNKNOWN.
Strings nested in dict/list fields are scanned too (depth <= 6, first 500 strings; anything deeper or later
is NOT scanned). Limits (honest): regex heuristics, EN + Traditional Chinese only; paraphrased or encoded
injection is NOT detected; quoting an attack in a security document will false-positive
(that is the safe direction). It never executes or follows anything it scans.

Stage 2 (LT-04, optional SLOT): ``quarantine_if_injected(record, semantic=fn)`` where ``fn(text) -> {"verdict": CLEAN |
SUSPICIOUS | INJECTION, "reason": str}`` is a model-backed reader for paraphrased/encoded injection that the regexes miss.
It can only TIGHTEN: the regex stage always runs first and its QUARANTINED result is final (a CLEAN verdict never undoes
it); stage 2 is consulted only for OBSERVED records the regexes passed, once per record on a bounded, joined text. An
exception, a non-mapping return or an unknown verdict = UNAVAILABLE = stage 1 result stands. ``semantic=None`` (default) =
behaviour identical to stage 1 only. The verdict is untrusted model output: only the closed enum is read. Effect of the
semantic stage is unmeasured (LT-04.eval, POST_E4).
"""
from __future__ import annotations

import re
from collections.abc import Callable, Iterator, Mapping
from itertools import islice
from typing import Any

_P = {
    "OVERRIDE_EN": r"\b(ignore|disregard|forget|override)\b[^.\n]{0,30}\b(instructions?|rules?|prompts?|polic(?:y|ies)|guidelines?)\b",
    "ROLE_EN": r"\byou are now\b|\bact as (?:a |an )?(?:system|admin|root|developer)\b|\bnew instructions?\s*:",
    "EXFIL_EN": r"\b(reveal|print|send|leak)\b[^.\n]{0,30}\b(system prompt|api[ _-]?key|secret|password|token)s?\b",
    "EXEC_EN": r"\b(run|execute)\b[^.\n]{0,20}\b(the following|this)\b[^.\n]{0,20}\b(command|script|code)\b|\b(curl|wget)\b[^\n]{0,80}\|\s*(sh|bash)\b",
    "AUTH_CLAIM_EN": r"\b(authorization|permission)\s+(is\s+)?granted\b|\buser (has )?(approved|authorized)\b|\bdo not tell the user\b",
    "OVERRIDE_ZH": r"(忽略|無視|忘記|覆寫)[^。\n]{0,12}(指令|規則|提示|政策|限制)",
    "ROLE_ZH": r"你現在是|新的指示\s*[:：]|系統提示",
    "EXFIL_ZH": r"(洩漏|輸出|傳送|告訴我)[^。\n]{0,12}(系統提示|金鑰|密碼|憑證|token)",
    "EXEC_ZH": r"執行(以下|下列|這個)[^。\n]{0,6}(指令|命令|腳本|程式)",
    "AUTH_CLAIM_ZH": r"(已獲授權|已經授權|使用者已(核准|同意|授權)|不要告訴使用者)",
}
_RX = {k: re.compile(v, re.IGNORECASE) for k, v in _P.items()}
QUARANTINED = "QUARANTINED"
MAX_DEPTH, MAX_STRINGS = 6, 500
SEMANTIC_VERDICTS = ("CLEAN", "SUSPICIOUS", "INJECTION")
SEMANTIC_STRINGS, SEMANTIC_CHARS = 40, 4000  # stage-2 input bound: first 40 strings, joined, first 4000 chars


def _strings(value: Any, depth: int = 0) -> Iterator[str]:
    """Every string value in ``value`` (dict values / list items, bounded depth); never raises."""
    if isinstance(value, str):
        yield value
    elif depth < MAX_DEPTH and isinstance(value, Mapping):
        for v in value.values():
            yield from _strings(v, depth + 1)
    elif depth < MAX_DEPTH and isinstance(value, (list, tuple)):
        for v in value:
            yield from _strings(v, depth + 1)


def scan_untrusted(text: Any) -> list[dict[str, str]]:
    """Return findings [{pattern_id, excerpt}] for instruction-like content in ``text``."""
    if not isinstance(text, str):
        return []
    out = []
    for pid, rx in _RX.items():
        m = rx.search(text)
        if m:
            out.append({"pattern_id": pid, "excerpt": m.group(0)[:40]})
    return out


def semantic_verdict(text: str, semantic: Callable[[str], Any] | None) -> dict[str, str]:
    """Stage 2 on one bounded text -> {verdict, reason}; verdict is UNAVAILABLE when the slot is absent or unusable."""
    if semantic is None or not isinstance(text, str) or not text.strip():
        return {"verdict": "UNAVAILABLE", "reason": ""}
    try:
        got = semantic(text[:SEMANTIC_CHARS])
    except Exception:  # noqa: BLE001 -- a failing SLOT must not break or loosen stage 1
        return {"verdict": "UNAVAILABLE", "reason": ""}
    v = got.get("verdict") if isinstance(got, Mapping) else None
    if v not in SEMANTIC_VERDICTS:
        return {"verdict": "UNAVAILABLE", "reason": ""}
    reason = got.get("reason")
    return {"verdict": v, "reason": reason[:80] if isinstance(reason, str) else ""}


def quarantine_if_injected(record: Mapping[str, Any], semantic: Callable[[str], Any] | None = None) -> dict[str, Any]:
    """Copy of an evidence record; OBSERVED + instruction-like text -> status QUARANTINED.

    Scans every string field, including nested ones. Findings are attached as ``injection_findings`` (never executed).
    ``semantic`` is the optional stage-2 slot (see module doc): it can only add a quarantine, never remove one, and with
    ``semantic=None`` the output is exactly the stage-1 result.
    """
    rec = dict(record)
    texts = list(islice(_strings(rec), MAX_STRINGS))
    findings = [f for t in texts for f in scan_untrusted(t)]
    if findings:
        rec["injection_findings"] = findings
        if rec.get("status") == "OBSERVED":
            rec["status"] = QUARANTINED
    elif semantic is not None and rec.get("status") == "OBSERVED":
        sem = semantic_verdict("\n".join(texts[:SEMANTIC_STRINGS]), semantic)
        rec["semantic_status"] = sem["verdict"]
        if sem["verdict"] in {"SUSPICIOUS", "INJECTION"}:
            rec["injection_findings"] = [{"pattern_id": f"SEMANTIC_{sem['verdict']}", "excerpt": sem["reason"][:40]}]
            rec["status"] = QUARANTINED
    return rec
