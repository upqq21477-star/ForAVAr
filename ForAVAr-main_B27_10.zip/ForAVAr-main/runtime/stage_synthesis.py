"""Stage SYNTHESIS (optional, N14-N15): adapter synthesis + synthesis gate, runs after evaluate. Moved verbatim (LT-20c)."""
from __future__ import annotations

from typing import Any

try:
    from .synthesis_gate import assess_synthesis, collect_open_items
    from .stage_common import Run, _bind_task, _call, _observed_ids
except ImportError:  # direct imports when runtime/ is on sys.path
    from synthesis_gate import assess_synthesis, collect_open_items
    from stage_common import Run, _bind_task, _call, _observed_ids


def run(r: Run) -> dict[str, Any] | None:
    """Return an early result (terminal exit) or None to continue; shared state lives on ``r``."""
    task_obj, task_id, profile, adapters, ctx, trace = r.task_obj, r.task_id, r.profile, r.adapters, r.ctx, r.trace
    frame, evidence, model, evaluation, normalized, gate, evidence_index = r.frame, r.evidence, r.model, r.evaluation, r.normalized, r.gate, r.evidence_index
    status = r.status
    synthesis: dict[str, Any] | None = None
    synthesis_gate: dict[str, Any] | None = None
    synth_note = ""
    synth_failure = False
    if "synthesis" in adapters and status != "FAILED":  # R3-synthesis (optional stage, N14-N15): runs after evaluate
        ctx["stage"] = "synthesis"
        synthesis = _call(adapters, "synthesis", task_obj, evaluation, evidence)
        trace.append("SYNTHESIS")
        ctx["synthesis"] = synthesis
        _bind_task(synthesis, task_id, "synthesis")
        synthesis_gate = assess_synthesis(profile, synthesis, _observed_ids(evidence_index), collect_open_items(frame, model, normalized, gate))
        if synthesis.get("status") != "READY":
            synthesis_gate = {**synthesis_gate, "ok": False, "status": "BLOCKED" if synthesis.get("status") == "BLOCKED" else synthesis_gate["status"],
                              "violations": synthesis_gate["violations"] + [{"rule": "SYNTHESIS_NOT_READY", "detail": str(synthesis.get("reason", "synthesis not READY"))}]}
            if synthesis_gate["status"] == "OK":
                synthesis_gate["status"] = "NOT_PROVEN"
        ctx["synthesis_gate"] = synthesis_gate
        trace.append("SYNTHESIS_GATE")
        if not synthesis_gate["ok"]:
            synth_failure = True
            synth_note = "synthesis gate: " + "; ".join(x["rule"] for x in synthesis_gate["violations"])
            if synthesis_gate["status"] == "BLOCKED" and status in {"PASS", "PARTIAL"}:
                status = "BLOCKED"
            elif status == "PASS":
                status = "PARTIAL"
    r.synthesis, r.synthesis_gate, r.synth_note, r.synth_failure, r.status = synthesis, synthesis_gate, synth_note, synth_failure, status
    return None
