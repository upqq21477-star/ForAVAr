---
name: p2-brain
description: Operate the P2 repository using its Current-first Brain workflow. Use when the user starts P2, asks for P2 progress, research, planning, code implementation, acceptance, handoff, or self-optimization.
---

# P2 Brain Skill

Use this skill to operate the P2 project with its own authority model. The skill defines the reusable workflow; it does not claim that any unconnected program or runtime is active.

## Authoritative startup

When the user invokes ！P2啟動, or a task clearly requires P2 project operation:

1. Choose the read set. If a non-STALE Brain Brief exists (newest P1-Central-Control/briefs/<brief_session_id>.json), read this Skill plus that Brief. Otherwise read this Skill plus the HOT summary of P1-CURRENT.json (the fields listed for the STARTUP route in P1-Central-Control/brief_slots.json). Never fall back to reading everything.
2. Judge whether the loaded context is enough for the request. If yes, continue. If not, ask the user to run ！備料; if the gap needs outside information, propose ！研究.
3. The former startup list (Active Work and Active Construction paths, the blueprint, the activation interface, the plan, Evidence Matrix, schemas, code, tests) lives in brief_slots.json as routes and slots. Fetch it only when the task needs it, through a brief request (topic, function ID, question; at most 5 items).
4. Record the read main SHA, the Brief session ID (or "degraded"), Active Work status, scope, acceptance criteria, blockers and evidence level.
5. Do not scan the entire repository, load full conversation history, infer execution truth from plans, or create a second Current.

The first response after startup should state the conversation Brain mode, the read set used (Brief or degraded), latest SHA/Current/Active Work checked, the main blocker, the selected work route and the next concrete action. Then continue with the user's task.

## Official conversation commands

The single command table is docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md; this skill keeps no second copy. Treat ！幫助 as a request to list every official command in that file with its purpose.

Natural-language requests remain valid; the user does not need to prefix every request with a command. Legacy phrases such as “P2 收斂”, “P2 重新診斷”, “P2 任務交接” and “P2 自我優化” map to the corresponding official commands.

## ！備料 and text rules (POLICY_ONLY: followed by the AI, not enforced by code)

- ！備料 opens a librarian session (ROLE:CONTROL_RESEARCH): list the slots of the route in brief_slots.json, copy each source excerpt verbatim with commit, path and line range, write P1-Central-Control/briefs/<brief_session_id>.json (≤ 8 KB), then re-read 3 sampled slots and compare. Steps: activation interface §1.3a. It is recognised only here, not by role_command_router.
- A leading ASCII ! on any official command counts as ！. Code enforces this only for router-registered role commands.
- Before any write, all three must hold, otherwise stop and return to the Brain: (1) the goal is CONFIRMED (or a CLARIFICATION_RESOLVED answer); (2) a change preview lists files, actions and estimated diff lines against write_scope (amber needs user confirmation, red needs a split or explicit authorization); (3) a recovery point exists (base_commit, new branch). Protected paths (canonical/, schemas/, P1-CURRENT.json, archived blueprints) need explicit user authorization.
- Ask a clarifying question only when the ambiguity changes the route; offer options, and end the task result with one line: questions asked, chosen, redirected, skipped.

## Brain task loop

For consequential work, construct a compact Task Frame:

- GOAL: intended result and output.
- CURRENT: latest relevant authority, revision, scope and state.
- EVIDENCE: read sources, observations, code checks, test outputs and external research.
- EPISTEMIC_STATE: confirmed facts, assumptions, UNKNOWN, CONFLICT and BLOCKED.
- OPTIONS: materially different feasible options and trade-offs.
- AUTHORITY: who decides, who implements, who independently verifies and what requires approval.
- DECISION: selected smallest sufficient route, rationale and rejected alternatives.
- ACTION: bounded implementation or explicit reason to research, plan, clarify or stop.
- ACCEPTANCE: observable success/failure conditions and relevant counterexamples.
- READBACK: verify the real saved result and record the next action.

Choose only the necessary primary route: ANSWER, RESEARCH, ANALYZE, PLAN, IMPLEMENT, VERIFY, CLARIFY or BLOCK. Simple, low-risk questions should be answered directly rather than wrapped in a large process.

## Authority and implementation boundaries

- Brain / Cognitive Decision owns intent understanding, problem modeling, option comparison, decision proposal and change classification.
- Knowledge Acquisition obtains sourced context and preserves uncertainty.
- Central / Coordinator checks contracts, authorization, routing and state transitions; it is not the semantic decision maker.
- Executor implements only within the authorized scope.
- Assurance / Verifier independently checks acceptance and evidence.
- Governance controls high-impact authorization, stop conditions and non-reversible actions.
- Evolution distills verified reusable rules; it does not store full chat traces.

Classify reusable change as ONE_OFF, LOCAL_RULE, SYSTEMIC_CAPABILITY or ARCHITECTURE_INVARIANT. Reuse an already accepted rule for matching circumstances. A single incident can reveal a systemic gap, but a root-cause hypothesis must not be reported as a confirmed root cause.

Before writing code or authoritative project files, verify Current, Active Work, exact write_scope and acceptance. Do not make a second Current, bypass the active work unit, or change the acceptance criteria to fit a result. If the requested change exceeds the current scope, state the exact proposed scope change and its impact before crossing that boundary.

## Evidence rules and execution

- Conversation reasoning, external research, GitHub save/readback, static inspection, actual program execution and runtime observation are different evidence levels.
- GitHub presence or a zero exit code alone is not proof of expected behavior. Verify structured result status and required invariants.
- Never label unexecuted tests PASS. Use NOT_EXECUTED when no real execution output exists; PATCHED_UNVERIFIED for code changes not yet executed.
- Python 3.11 and the repository's pinned runtime dependencies are the current executable validation target. Use the established scripts and test suites; avoid adding another runtime language or unnecessary dependency.
- GitHub Actions is archived and must not be dispatched, retried or replaced with a diagnostic workflow unless the user explicitly changes that authorization.
- BASELINE remains AI dialogue plus GitHub. Do not require API keys, paid API access, an IDE, CLI, Python or Actions for the conversational baseline. Local program execution is an optional verification upgrade when an approved computer/runtime is available.

## Task closeout

At completion, blockage or handoff:

1. Compare the requested result, actual change and readback.
2. State what materially advanced, what remains unverified, and the next concrete action.
3. Identify whether any improvement is reusable and classify it.
4. Update only the correct authority and only when authorized; read the changed content back.
5. Preserve the current Current and Active Work as authoritative; do not imply that this skill wires an unconnected Brain/Central runtime.

## Primary project references

- Current: P1-CURRENT.json
- Unique blueprint: docs/architecture/P2-System-Blueprint-v1.0.md
- Conversation command interface: docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md
- Formal Brain implementation plan: docs/plans/P2-Relay-Update-Plan.md
- Active Work and Construction: paths named by Current
