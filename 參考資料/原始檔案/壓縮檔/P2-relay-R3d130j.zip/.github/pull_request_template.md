## 變更目的

- 關聯 Construction Packet：CONSTRUCTION:...
- 關聯 Work Packet：M...
- 本次變更是否修改 Current Authority：是／否

## 建構範圍

- Read First：
- Write Scope：
- Forbidden Scope：
- Required State Delta：

## 實作結果

- 新增／修改的 runtime：
- schema／policy：
- 是否建立第二份 truth：否
- 是否修改既有 canonical object：是／否

## 驗收

- Acceptance command：
- 初次驗收結果：
- 是否因 FAIL 重跑：是／否
- Execution head SHA：
- Evidence / artifact：

## 合併前檢查

- [ ] 有實際 source-state delta
- [ ] 未超出 Construction Packet write scope
- [ ] 未建立第二 Current Authority
- [ ] 未把研究結果直接升級為 canonical truth
- [ ] 已記錄驗收 evidence
