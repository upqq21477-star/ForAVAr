# P2 參考資料

## 狀態：待蒸餾後退場

本目錄是設計輸入，**不是現況**。R2c 把仍有效的結論蒸餾進藍圖 v4.0 後，R3 刪除整個目錄（見企劃附錄 A）。

- `企劃/`：只留 Synthesis Matrix（去重裁決）與 Research Sources（外部來源清單）；其餘企劃已蒸餾進 `docs/plans/P2-Feature-Triage.md` 附錄並刪除（原文在 R3d7 zip）。
- `P2-*.md`（4 份）：整批更新與語意保真驗收、模擬運行標準、系統性變更分類、適應式呈現——概念已在藍圖。
- 已移除：舊 r48 交接（資訊已併入 `docs/handoffs/HANDOFF.md`）、與 P2 無關的圖檔、重複的更新包 zip。

## 架構權威分工

- P2 目標架構：`../docs/architecture/P2-System-Blueprint-v1.0.md`.
- 實作與證據：`../docs/plans/P2-Feature-Triage.md`.
- 下一步工作排序：`../docs/plans/P2-Relay-Update-Plan.md`.
- 程式重建藍圖仍在 `../P1-Central-Control/canonical/blueprint.json`，用途只限程式檔案組成與 Clean Build，不取代 P2 總體藍圖。

## 驗收聲明界線

來源 `HANDOFF-r48.md` 記錄 M32／M33 為 `VERIFIED / SIMULATION_ONLY`，`OBSERVED_RUNTIME = 0`、Brain 仍為 STAND-IN。這是來源交接紀錄，不代表本輪已重新執行所有測試。當前版本的測試證據必須綁定新的 commit SHA。

## 最低操作標準：AI 對話＋GitHub（MUST）

P2 的最低運行環境是 **AI 對話＋GitHub 儲存庫**，不是「完全本地」或「只能離線」運行。AI 對話負責讀取理解、規劃、分析、產出修改與靜態檢查；GitHub 負責保存檔案、版本、工作紀錄與可回讀的證據。

最低標準不得依賴：
- API 金鑰或模型 API。
- GitHub Actions、Hosted Runner 或 CI 工作流程。
- 額外外部軟體、IDE、命令列、Python 執行環境或套件安裝。
- 本地資料夾或本地程式執行能力。

最低工作循環：
1. 從 GitHub 讀取唯一 Current、工作單元／交接和本次任務相關檔案。
2. 在 AI 對話中界定任務、修改範圍、輸入／輸出、接受條件、風險和回復方式。
3. 由 AI 產出完整檔案內容或明確差異，並透過可用的 GitHub 介面保存；若無直接寫入能力，交付可直接貼入 GitHub 網頁的內容。
4. 從 GitHub 讀回保存後版本，以 commit SHA、檔案路徑和內容確認變更已持久化。
5. 在 AI 對話中檢查規格、引用、契約、跨檔一致性、狀態、反例和極端情境。
6. 將檢查結果、未解風險、證據層級和下一步寫回 GitHub，確保新對話可恢復工作。

## 證據與額外執行能力

- 未寫入 GitHub 並讀回確認的聊天草稿，不算已保存的工程進度。
- AI 對話審查與靜態檢查不等於程式已執行。沒有實際執行輸出時，標記為 `NOT_EXECUTED_BASELINE_LIMIT`／`IMPLEMENTED_UNVERIFIED`，不得宣稱測試 PASS 或 Runtime 已觀測。
- 單元測試、Clean Build、本地執行、其他外部工具及 GitHub Actions 都是額外證據路徑，不是最低操作前置條件。環境不可用時，應記錄未執行狀態，不能把它誤判為程式 PASS／FAIL，也不能因此阻止可在 AI＋GitHub 下繼續的工作。
- 既有 GitHub Actions workflow 可以保留作為可選工具，但任何核心讀取、規劃、修改、保存、最低檢查、交接及恢復流程都不得等待或要求它運作。
- **整合式實測節奏：** 先完成整批更新與完整模擬，只有關鍵模擬項目通過後，才啟動一次整合式 GitHub Actions 測試；不為每個小修改分開跑，以節省額度。實測後對照原始意圖、模擬預期與實際輸出，再進行以模擬為主的極端情境測試。細則以 `P1-Central-Control/archive/reference/P2-模擬運行與語意保真驗證標準-v1.0.md`（已封存） 為準。

## 版本規則

- 原始 r48 程式路徑保留，避免未盤點所有 import、fixture、schema ref、workflow、Current reference 前進行危險的全域改名。
- `P1-CURRENT.json` 暫時仍是唯一執行狀態權威；禁止另造第二份 Current。
- 原始企劃是設計來源，不能直接覆寫程式實況或 Runtime 證據。
