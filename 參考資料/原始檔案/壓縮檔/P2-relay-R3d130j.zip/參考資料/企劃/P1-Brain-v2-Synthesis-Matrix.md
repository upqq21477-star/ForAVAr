# P1 Brain v2 — 三份企劃蒸餾矩陣

| 原企劃 | 蒸餾後主責 | 保留核心 | 與其他企劃合併 |
|---|---|---|---|
| 01 Brain v2 | Cognition / Library / Engineering | Problem Model、Method Map、Capability、Pattern、Dynamic Team、Planner Boundary | Context、Progressive Disclosure、Library lifecycle 合併 |
| 02 Knowledge | Knowledge Lifecycle | Manifest、Segment、Reading Ledger、Coverage、Observation、Evidence、Claim、Version、Conflict、Temporal、Retrieval | Provenance、Context Reconstruction 與 03 合併 |
| 03 Active/Archive | Governance / Reconstruction | Active、Archive、Blueprint、Reconstruction Input Set、Lifecycle、Clean Rebuild | Lifecycle、Scope、Evidence 與 02 合併 |

## 重複內容的處理

### Progressive Disclosure
統一為：
Planner → Card → Full Skill → References / Scripts

### Context Budget
不再作獨立 Memory 系統，改成：
Retrieval Scope + Working Context

### Provenance
不再分 Brain provenance / Knowledge provenance，統一成 Evidence / Provenance layer。

### Lifecycle
不建立三套 lifecycle，統一：
Asset / Claim / Artifact 都使用同一類 lifecycle semantics，但各自政策不同。

### Archive
不再視為單獨 Memory Store，定位為：
Cold historical source + explicit retrieval boundary。

### Reconstruction
統一：
Context Reconstruction + System Reconstruction
兩者共用「權威輸入 → 重建 → 驗證」原則。

### Dynamic Team
只屬 Engineering Assembly，不進 Brain，不進 Library 本體，不永久存在。

## 正式主軸

1. Cognition
2. Knowledge
3. Library
4. Engineering Assembly
5. Control / Execution
6. Evidence / Verification
7. Active / Archive / Blueprint
8. Governance / Security