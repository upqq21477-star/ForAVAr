# P1 Brain v2 — 外部研究來源登錄

本文件記錄本企劃使用的外部來源。來源只作為架構參考與研究依據，不直接構成 P1 規範。

## 官方／標準來源

1. OpenAI — Skills
https://developers.openai.com/api/docs/guides/tools-skills
用途：Skills、progressive disclosure、SKILL.md、references/scripts/assets、能力目錄。

2. OpenAI — Agents SDK
https://developers.openai.com/api/docs/guides/agents/sdk
用途：Agent、tool、multi-agent、context、runtime capability 的官方模型。

3. Anthropic — Agent Skills
https://www.anthropic.com/engineering/equipping-agents-for-the-real-world-with-agent-skills
用途：progressive disclosure、SKILL.md、metadata → full instructions → supporting files。

4. W3C — PROV Primer
https://www.w3.org/TR/prov-primer/
用途：Entity、Activity、Agent、Usage、Generation、Derivation、provenance。

5. W3C — PROV-N
https://www.w3.org/TR/prov-n/
用途：PROV conceptual model 與 provenance 表示。

6. DBOS — Architecture
https://docs.dbos.dev/architecture
用途：durable workflow、checkpoint、failure recovery、durable queue、execution engine。

7. DBOS — Python Workflows
https://docs.dbos.dev/python/tutorials/workflow-tutorial
用途：workflow / step recovery 的實作模型。

8. NIST — Agent Tool Use
https://www.nist.gov/news-events/news/2025/08/lessons-learned-consortium-tool-use-agent-systems
用途：agent tool taxonomy、reliability、安全與能力描述。

9. NIST — Agent Security RFI
https://www.nist.gov/news-events/news/2026/01/caisi-issues-request-information-about-securing-ai-agent-systems
用途：agent security、autonomous action、外部系統與資料風險。

10. NIST — AI Agent Standards Initiative
https://www.nist.gov/news-events/news/2026/02/announcing-ai-agent-standards-initiative-interoperable-and-secure
用途：agent identity、security、interoperability、standards。

11. NIST — Agent Hijacking
https://www.nist.gov/news-events/news/2025/01/technical-blog-strengthening-ai-agent-hijacking-evaluations
用途：indirect prompt injection / agent hijacking。

12. OWASP — Agent Security Cheat Sheet
https://cheatsheetseries.owasp.org/cheatsheets/AI_Agent_Security_Cheat_Sheet.html
用途：prompt injection、tool abuse、memory poisoning、data exfiltration、privilege。

13. OWASP — Excessive Agency
https://genai.owasp.org/llmrisk/llm062025-excessive-agency/
用途：tool / skill / plugin permissions、excessive agency、multi-agent risk。

## 研究來源

14. DeepPlanning
https://arxiv.org/abs/2601.18137
用途：long-horizon planning、constraint optimization、information acquisition。

15. RoadmapBench
https://arxiv.org/abs/2605.15846
用途：long-horizon software development、multi-file / version upgrade planning。

16. Agent Zero Memory
https://arxiv.org/abs/2608.29606
用途：provenance-aware long-term memory、timeline、entity-event graph、citation-locked memory。

17. SodaMem
https://arxiv.org/abs/2608.08055
用途：evidence-grounded temporal graph memory、SUPERSEDES / CONTRADICTS / UPDATES、provenance。

## Implementation Case Study

18. subdavis/selfhosted
https://github.com/subdavis/selfhosted
用途：declarative service configuration、Traefik routing、network isolation、service composition。

19. subdavis/selfhosted commit c08d682
https://github.com/subdavis/selfhosted/commit/c08d68249d7e565a5bd993c6eb2fdc794b5ae37f
用途：逆向分析基線；2026-08-01 commit。

## 使用原則

- Official / Standard：用於定義概念與安全／架構參考。
- Research：用於判斷目前研究問題與方法是否合理。
- Repository：用於 reverse engineering 與 implementation pattern。
- 外部來源不得覆蓋本專案的核心設計決策。
- 論文中的 benchmark 結果只能作研究證據，不得直接轉成 P1 驗收聲明。