---
id: 0001
title: M23-P13 Checkpoint Index 決定 REUSE（沿用，不另建）
status: accepted
date: 2026-10-15
decision-makers: [P2-relay（事後補登，原決策者 UNKNOWN）]
scope: [DISCUSS, BUILD]
supersedes: null
superseded-by: null
reversal-condition: 若沿用的 Checkpoint Index 在基線比對或收尾鏈出現現有欄位無法表達的缺口，才另提 ADR 重新評估自建
links: [docs/plans/P2-Relay-Update-Plan.md]
basis: 事後補登；決策句引自企劃 R4R-S1（v2.2 §57）；原文不在本 repo，理由段 UNKNOWN
---

決定：Checkpoint Index 沿用既有（REUSE），不另建新索引。來源：藍圖前版 v2.2 §57 的 M23-P13 結論，經企劃 R4R-S1 引用。理由與替代方案原文未隨 repo 保存，不在此臆測。
