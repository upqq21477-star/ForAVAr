---
id: 0090
title: CAP-CLUSTER／TREND／ANOMALY 宣告 DORMANT
status: accepted
date: 2026-10-16
decision-makers: [qaaq, P2-relay]
scope: [NONE]
supersedes: null
superseded-by: null
reversal-condition: 出現至少 1 個要求分群／趨勢／異常偵測的消費者任務，且 CAP-STATISTICS 已 DONE
links: [P1-Central-Control/policy/capability_declarations.v1.0.json, tools/capability_gate.py]
basis: 規劃稿 §16 CAP-CLUSTER 卡（Q8a）；TREND、ANOMALY 同構（HYPOTHESIS，未讀其卡）；證據 NOT_EXECUTED
---

三者無提供者（DECLARED_NO_TOOL）、consumers 0，方法選型未查（UNKNOWN）。登記為 DORMANT，被呼叫回 DORMANT（不執行、不算失敗）。`capability_gate.verify_declarations` 檢查 ADR 存在、狀態檔 mode＝DORMANT、consumers＝0。
