---
id: 0002
title: 模型時代分流：不照原規劃完成 5 個獨立 System／48 Functions
status: accepted
date: 2026-10-01
decision-makers: [qaaq, P2-relay]
scope: [DISCUSS, BUILD]
supersedes: null
superseded-by: null
reversal-condition: 若新模型版本實測仍無法自行保證某項結構、證據或驗證，該項才恢復為獨立功能並另提 ADR
links: [docs/plans/P2-Feature-Triage.md]
basis: 事後補登；依據企劃 Feature-Triage A16 的蒸餾結論（2026-10-01 分流）
---

決定：不照原規劃完成 5 個獨立 System／48 Functions；P1 改為只提供模型無法自行保證的結構、證據、狀態、限制、驗證與可重現工具。
