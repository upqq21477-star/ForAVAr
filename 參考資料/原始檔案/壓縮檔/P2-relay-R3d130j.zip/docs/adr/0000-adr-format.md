---
id: 0000
title: P2 ADR 格式與狀態轉移
status: accepted
date: 2026-10-15
decision-makers: [qaaq, P2-relay]
scope: [NONE]
supersedes: null
superseded-by: null
reversal-condition: 若 precheck adr 的規則造成無法記錄真實決策（反覆要繞過規則）才改格式並以新 ADR 取代
links: [P1-Central-Control/scripts/architecture_decision.py, docs/plans/P2-Relay-Update-Plan.md]
basis: R4R-S1 任務卡；外部：MADR 4 frontmatter、hve-core adr-author 的單一繼任者規則（2026-10-15 比對，採欄位與單一繼任者，不採 rejected／withdrawn 狀態）
---

## 格式
每份 ADR＝docs/adr 目錄下的 `NNNN-<slug>.md`，開頭 YAML frontmatter（一行一欄，只用 `key: value`、`null`、`[a, b]`），欄位全必填：id、title、status、date、decision-makers、scope、supersedes、superseded-by、reversal-condition、links、basis。
- status：proposed → accepted → deprecated｜superseded（不可倒退；未被採納的提案不入庫，由版本控制保存）。
- supersedes／superseded-by：各至多一個 ADR id；取代時新 ADR 為 accepted，舊 ADR 同次改為 superseded 並填 superseded-by（雙向）；一個舊 ADR 只能有一個繼任者。
- reversal-condition：必填，寫「什麼觀察到時要推翻」，不可空泛。
- scope：Brief 路由名（見 brief_slots.json）、ALL 或 NONE；只有 accepted 且 scope 含該路由或 ALL 者進 Brief 的 decisions[]。
- links：`ADR-NNNN` 或 repo 相對路徑；不得懸空。basis：依據與證據層級；事後補登的標明「事後補登」。
## 驗證與手動等價流程（Track A）
1. 在 docs/adr 新增 `NNNN-<slug>.md`，status 先寫 proposed 並填滿欄位。
2. `python3 P1-Central-Control/scripts/architecture_decision.py` 必須印出 `adr OK`。
3. 採納：status 改 accepted；若取代舊 ADR，舊檔同次改 superseded 並填 superseded-by。
4. 再跑步驟 2；`--simulate` 重跑閉環情境（應印 `SIMULATED_PASS`）。
## 登記簿（新增 ADR 時在此補一行；孤兒檢查會擋未登記者）
- docs/adr/0001-checkpoint-index-reuse.md
- docs/adr/0002-model-era-split.md
- docs/adr/0003-librarian-brief.md
