---
id: 0003
title: D12–D14：大腦只讀館員產出的 Brief，缺口分級再分流
status: accepted
date: 2026-10-12
decision-makers: [qaaq, P2-relay]
scope: [STARTUP, DISCUSS, BUILD]
supersedes: null
superseded-by: null
reversal-condition: 若 R5 閉環實測出現 Brain 因 Brief 缺口以猜測補空，且缺口分級無法修正，則重新評估讀集策略
links: [docs/plans/P2-Relay-Update-Plan.md, P1-Central-Control/scripts/librarian.py]
basis: 企劃 D12–D14（2026-10-12 增補）；實作證據 R4L-M1／M2／M3 PROGRAM_EXECUTED_PASS
---

D12：大腦只讀館員產出的 Brief。D13：Brief 是暫存、可覆寫、可重建的衍生品，權威仍在原始檔。D14：館員以代碼評 SUFFICIENT／PARTIAL／MISSING；缺口窄化重請求或派研究任務，網路結果標 UNTRUSTED_CANDIDATE，驗收後才進 Knowledge。
