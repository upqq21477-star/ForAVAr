# LEDGER 時間線封存（R3d130e 逐字搬移，未改寫）

- **R3d12g～s：** R4L-M1～M3、XM0、R4R-M1～M3（ADR 0000–0003、`lifecycle_sweep`、`closure_chain`）；s 場清理（OPEN-ISSUES／帳本 68→10 KB、README 單一權威＋`pointer_audit`）。
- **R3d12t～y：** R4R-S4、XM1；R4L／R4R DONE；020c 四鏈 WIRED_EXECUTED；R5 結案（capability_run 實測 4 能力、UNWIRED 15；真實 Track A 會話 NOT_EXECUTED）。
- **R3d12z～zb：** R6（FP1～3，回放 61/61）、R7（`rebuild_check`、FP4～7）、R8（`hands_adapter` FP8～10）完成；R9 待使用者實測。
- **R3d12zc（DOC_ONLY）：** 閉環稽核——FP4～10 無生產呼叫者、T3 不查呼叫者、23 能力僅 4 WIRED、`Run` 無中斷續跑；規劃、研究規程（Q1～Q8）、進度、閉環卡併為 `docs/plans/P2-Closure-Audit-and-Plan.md`；缺陷 025c～031c。
