# R1-S3h 交接歷史表（從交接檔搬出；封存、非權威）

## 歸因表（歸因表（24 列；A 雜湊漂移／B 宣告漂移／C 真缺陷／D 修補或其測試；? 表示未定））

| 檔（略 test_） | 失敗/跑 | 類 | 判斷依據（觀察） | 假說與預定修補（HYPOTHESIS） | 信心 |
|---|---|---|---|---|---|
| blueprint_update_transaction | 0/6（R1-S2 後） | C | （已修） | 【R1-S2 已修】new_ids 上移＋測試第 206 行筆誤；PATCHED_UNVERIFIED（3.12.3 實跑 6/6 OK） | 高 |
| brain_mode_controller | 2/15 | A | construction_efficiency_review.py:118 _source_budget 拋 REVIEW_BLUEPRINT_REF_INVALID；canonical/blueprint.json 雜湊不符（觀察） | 藍圖引用核對含雜湊；隨藍圖處理（S4） | 中 |
| brain_mode_runtime_interface | 0/5（R1-S3c 後） | D | （已修） | 【R1-S3c 已修】全為夾具：schema 複製、漂移子案例有效副本、contract.work_unit_id、control 補必填鍵、patch validate_fina | 高 |
| central_role_interface | 0/24（R1-S3d 後） | D | 裸 AssertionError；經 tests/_function_tests.py:34 lambda，test 行 297（觀察）；R1-S2b 觀察：夾具把 work／stage 設為待驗收狀態，入口檢查回 WORK_UNIT_NOT_OPEN／NOT_READY；程式或測試期望何者偏離待裁決 | 【R1-S3d 已修】`_construction_root()` 夾具；3 項保留原期望，work_complete 改期望；PATCHED_UNVERIFIED（3.12.3：24/24） | 高 |
| construction_progress_watchdog | 0/23（R1-S3c 後） | B＋D | （已修） | 【R1-S3c 已修】裁決 C 改資料後 6→1；餘 1 項為測試筆誤（work_path 未定義）；PATCHED_UNVERIFIED（3.12.3：23/23） | 高 |
| current_projection_sync | 0/4（R1-S3 後） | D? | （已修） | 【R1-S3 已修】測試斷言改為實際渲染格式；PATCHED_UNVERIFIED（3.12.3：4/4） | 低 |
| debug_escalation_policy | 0/7（R1-S3d 後） | C（測試） | 輔助方法 run() 覆蓋 TestCase.run，loader 計 7、實跑 0、rc=5；暫存副本改名後 7 跑 6 過 1 敗（觀察） | 【R1-S3d 已修】裁決 B：期望 2→1；PATCHED_UNVERIFIED（3.12.3：7/7） | 高 |
| feature_batch_orchestrator | 0/11（R1-S3b 後） | D | （已修） | 【R1-S3b 已修】測試補該鍵；PATCHED_UNVERIFIED（3.12.3：11/11）；前場 ModuleNotFoundError 為執行方式問題 | 高 |
| lifecycle_sweep | 0/25（R1-S3g 後） | B＋D | （已修） | 【R1-S3g 已修】政策登記接力工具與 Skill 設定檔為入口根、9 筆宣告入口（複審 2026-11-08）；PATCHED_UNVERIFIED（3.12.3：25/25） | 高 |
| local_acceptance | 1/6 | A? | 'FAIL'!='PASS'，test 行 58（觀察） | 可能承接雜湊不符的 CONTINUATION_BOX／task JSON；先做 S4 再重判 | 低 |
| m32_close_vertical_slice | 1/1 | A? | 'FAIL'!='PASS'，test 行 387；checkpoints/CONTINUATION_BOX__pkt-M32-CLOSE.json 雜湊不符（觀察） | 兩者同在 M32 路徑；S4 後重跑再判 | 低 |
| planner_library | 0/13（R1-S3g 後） | D | （已修） | 【R1-S3g 已修】夾具改為政策對應的 C1 能力；政策不動；PATCHED_UNVERIFIED（3.12.3：13/13） | 中 |
| progressive_repository_scanner | 0/8（R1-S2c 後） | D | （已修） | 【R1-S2c 已修】測試夾具改可執行 Python；PATCHED_UNVERIFIED（3.12.3：8/8） | 中 |
| quality_metrics | 0/4（R1-S2c 後） | D | （已修） | 【R1-S2c 已修】零樣本先回 None，不建 Retriever；PATCHED_UNVERIFIED（3.12.3：4/4） | 中 |
| reconstruction | 4/19 | A | reconstruction.py:66 BLUEPRINT_INVALID:content_hash（觀察）；blueprint.json 儲存 a7e7… 重算 9b90… | 藍圖封存後內容被改（HYPOTHESIS）；藍圖受契約指紋綁定，重封前先確認改動是否有意（S4／R3 更新交易） | 高 |
| regression_executor | 0/11（R1-S2c 後） | D | （已修） | 【R1-S2c 已修】測試補 validate_report patch；PATCHED_UNVERIFIED（3.12.3：11/11） | 中 |
| repo_budget | 1/3 | B | P1-CURRENT.json 17,923 B > 12,000 B；R1-S3f 另測得 docs／progress／scripts／tests／TOTAL 五項超標（見第 4 章，無 .git 目錄遍歷） | 【R1-S3f 部分修】P1-CURRENT 15,317 B、max→15,500（D-S3f-M2）；其餘 5 項為宣告落後現實，docs 沿用 R3-S3，其餘待決；仍在基線。HYPOTHESIS：有 git 時 TOTAL 因忽略檔會較小，其餘為追蹤目錄應相近 | 高 |
| reverse_reconstruction | 2/4 | A? | 得 UNKNOWN，期望 BROKEN／STUB，test 行 67（觀察） | 可能因藍圖無效而回 UNKNOWN；S4 後重判 | 低 |
| role_operational_closure | 0/11（R1-S3e 後） | D | （已修） | 【R1-S3e 已修】補 schema 夾具；2 項改用可達夾具／直接呼叫；2 項依現行流程改期望並註明；PATCHED_UNVERIFIED（3.12.3：11/11） | 中 |
| role_session_isolation | 1/3 | A | result_packet.schema.json content_hash 不正確 expected=sha256:3cea…（觀察） | schema 檔雜湊漂移；本場掃描未涵蓋 schema 檔；S4 用專案工具重生 | 中 |
| run_p2_validation | 0/15（R1-S3c 後） | B | （已修） | 【R1-S3c】裁決 C：work.json formal_caller→UNKNOWN；PATCHED_UNVERIFIED（3.12.3：15/15） | 高 |
| system_factory_strategy | 0/3（R1-S2c 後） | D? | （已修） | 【R1-S2c 已修】warning 補「unscanned」；PATCHED_UNVERIFIED（3.12.3：3/3） | 低 |
| system_independence_repository_gate | 0/4（R1-S2 後） | D | （已修） | 【R1-S2 已修】改解 4 值＋BOUNDED_RECONSTRUCTION；PATCHED_UNVERIFIED（3.12.3 實跑 4/4 OK） | 高 |
| task_admission_gate | 1/5 | A?／D? | 得 BLOCK，期望 PASS，test 行 141；CONTINUATION_BOX 雜湊不符（觀察） | 承接雜湊不符，或修補 011 的 state_revision 核對偏離；S4 後重判 | 低 |

## 變更檔案與待驗證清單（完整）

| 檔案 | 要跑的測試 | 狀態 |
|---|---|---|
| （歷次變更 7 列，R4L-S0d～R1-S3f，已隨 zip 交付） | 見 zip 內對應測試 | 歷史摘要：當時 PASS；本場未重驗 |
| P1-Central-Control/scripts/blueprint_update_transaction.py（new_ids 上移） | tests.test_blueprint_update_transaction | PATCHED_UNVERIFIED（3.12.3：6/6 OK） |
| P1-Central-Control/tests/test_blueprint_update_transaction.py（第 206 行換行筆誤） | tests.test_blueprint_update_transaction | PATCHED_UNVERIFIED（同上） |
| P1-Central-Control/scripts/repository_architecture_evidence.py（4 值＋BOUNDED_RECONSTRUCTION＋2 新鍵） | tests.test_system_independence_repository_gate；另跑引用 collect 的檢查 | PATCHED_UNVERIFIED（3.12.3：4/4 OK；collect 的其他呼叫端未查） |
| P1-Central-Control/tests/test_debug_escalation_policy.py（run→run_rec） | tests.test_debug_escalation_policy | PATCHED_UNVERIFIED（7 跑 6 過 1 敗，1 敗待裁決） |
| P1-Central-Control/scripts/quality_metrics.py（provenance_completeness 零樣本先回 None） | tests.test_quality_metrics；另查 `provenance_completeness` 的其他呼叫端 | PATCHED_UNVERIFIED（3.12.3：4/4） |
| P1-Central-Control/tests/test_regression_executor.py（startup error 案例補 validate_report patch） | tests.test_regression_executor | PATCHED_UNVERIFIED（3.12.3：11/11） |
| P1-Central-Control/tests/test_progressive_repository_scanner.py（byte 上限案例夾具改可執行 Python） | tests.test_progressive_repository_scanner | PATCHED_UNVERIFIED（3.12.3：8/8） |
| P1-Central-Control/scripts/system_factory_strategy.py（partial inventory warning 文字） | tests.test_system_factory_strategy | PATCHED_UNVERIFIED（3.12.3：3/3） |
| P1-Central-Control/tests/test_current_projection_sync.py（第 51 行斷言改實際渲染格式） | tests.test_current_projection_sync | PATCHED_UNVERIFIED（3.12.3：4/4） |
| P1-Central-Control/scripts/run_p2_validation.py（EXPECTED_TEST_COUNTS projection_sync 3→4） | tests.test_run_p2_validation（含 test_declared_suite_counts_match_source_methods） | PATCHED_UNVERIFIED（3.12.3：15/15，裁決 C 後） |
| P1-Central-Control/tests/test_run_p2_validation.py（兩案例以 NO_BATCH_GATE 隔離批次閘門） | tests.test_run_p2_validation | PATCHED_UNVERIFIED（3.12.3：同上） |
| P1-Central-Control/tests/test_feature_batch_orchestrator.py（final gate 測試補 official_test_roster_complete） | tests.test_feature_batch_orchestrator（以 precheck 方式執行） | PATCHED_UNVERIFIED（3.12.3：11/11） |
| P1-Central-Control/tests/test_brain_mode_runtime_interface.py（暫存 repo 補 schema；漂移子案例有效副本；contract.work_unit_id；control 以 initial_control_state 為底；兩處 patch validate_final_test_gate；acceptance_ref 期望用 original_unit；備註期望泛化） | tests.test_brain_mode_runtime_interface | PATCHED_UNVERIFIED（3.12.3：5/5） |
| P1-Central-Control/progress/P2-B1-B8.work.json（第 501 行 formal_caller WIRED_UNVERIFIED→UNKNOWN；裁決 C①） | tests.test_run_p2_validation、test_construction_progress_watchdog、test_brain_mode_runtime_interface | PATCHED_UNVERIFIED（3.12.3：15/15、23/23、5/5） |
| P1-Central-Control/tests/test_construction_progress_watchdog.py（第 172 行 work_path→self.root / work_ref） | tests.test_construction_progress_watchdog | PATCHED_UNVERIFIED（3.12.3：23/23） |
| P1-Central-Control/tests/test_debug_escalation_policy.py（raw-run 測試期望 2→1＋註解） | tests.test_debug_escalation_policy | PATCHED_UNVERIFIED（3.12.3：7/7） |
| P1-Central-Control/tests/test_central_role_interface.py（新增 `_construction_root()`；progress／final_acceptance_request／final_batch_flags 改用；work_complete 改期望；補 import atexit／shutil／tempfile） | tests.test_central_role_interface | PATCHED_UNVERIFIED（3.12.3：24/24） |
| P1-Central-Control/tests/test_role_operational_closure.py（sandbox 補 schema 複製；`_construction_mode` 夾具；④ 執行者兩段改期望；②③ 改夾具／直接呼叫 `compute_next_stage_admission`；⑤ 對 (OPEN, EXECUTOR, WORK_COMPLETE) 放寬為僅工作包審計寫入；新增 import shutil、compute_next_stage_admission） | tests.test_role_operational_closure | PATCHED_UNVERIFIED（3.12.3：11/11） |
| P1-CURRENT.json（四個敘述欄位改濃縮版；17,923→15,317 B） | tests.test_current_projection_sync、test_run_p2_validation、test_acceptance_context；precheck | PATCHED_UNVERIFIED（3.12.3：4/4、15/15、3/3） |
| docs/archive/current-history/P1-CURRENT-prose-2026-10-13.json（新檔，四欄位原文） | precheck（[refs]／lifecycle_sweep 是否視為未宣告） | NOT_EXECUTED（以收尾 precheck 為準） |
| P1-Central-Control/policy/repo_budget.json（P1-CURRENT max 12,000→15,500；新增頂層 decisions） | tests.test_repo_budget（其餘 5 項仍敗） | PATCHED_UNVERIFIED（3.12.3：P1-CURRENT 項已消失） |
| P1-Central-Control/policy/lifecycle.v1.0.json（roots 加 tools/、.agents/、MANIFEST.sha256；declared_entries＋9） | tests.test_lifecycle_sweep | PATCHED_UNVERIFIED（3.12.3：25/25） |
| P1-Central-Control/tests/test_planner_library.py（第 211–220 行夾具：INFORMATION_GAP＋CAP-INGEST→SOURCE_CONFLICT＋CAP-PROVENANCE，附原因註解） | tests.test_planner_library | PATCHED_UNVERIFIED（3.12.3：13/13） |
| docs/architecture/P2-Expansion-Design-v0.1.md（新檔，8,373 B；無程式變更） | python3 tools/precheck.py | PROGRAM_EXECUTED_PASS（precheck PASS；內容為設計，無可執行驗證） |
| tools/expansion_probe.py（新檔，stdlib） | python3 tools/expansion_probe.py --selftest；實跑 python3 tools/expansion_probe.py | PROGRAM_EXECUTED_PASS（自測 4 組 OK；實跑 11/12；--holdout 實跑） |
| docs/architecture/P2-Expansion-Checks-v0.1.md（新檔，3.9 KB）；Design §7 加指向一行 | python3 tools/precheck.py | PROGRAM_EXECUTED_PASS（precheck PASS）；設計文件 |
| docs/architecture/P2-Expansion-External-Review-v0.1.md（新檔）；Design §1 凍結規則與種子表改寫；Checks 新增 §5 | python3 tools/precheck.py | PROGRAM_EXECUTED_PASS（precheck PASS）；設計文件 |
