# P1 治理規則 v1.0（併自 M14-13／M14-14／M15／M16 計畫；原文見 git 歷史）

狀態：ACTIVE GOVERNANCE BASELINE

只存規則；實作位置以 `P1-CURRENT.json` 與 registry 為準，本檔不得覆寫 Current。

## 1. 長程運行（原 M14-13）

- 目標：只在正確時間取得足以決定正確下一步的最小充分狀態，失憶、重啟、換模型／工具後仍可恢復；不是「記住更多」。
- Current／Projection／Runtime 有衝突→`RECONCILIATION_REQUIRED`，不得進 CLEAN_READY；Projection／README／Handoff 只能由 Current 派生。
- Context Sufficiency：Sufficient→執行；Insufficient→定向取回；Oversized→拆分；Corrupted（stale／衝突／無依據推論）→先對帳。
- Segment 大小由責任邊界、Context 密度、依賴距離、驗收複雜度、失敗復原成本、預期輸出共同決定；接近 hard ceiling、重複 history 比例高、長距依賴多、驗收責任獨立則拆；輸入共用且驗收相同則併。
- Checkpoint：邏輯上每 Segment 一筆，物理上不必一檔一筆；只存 identity／status／revision／summary／各類 refs（confirmed／inference／unknown／conflict／decision／evidence／provenance／artifact）／next legal action／resume point。
- 儲存分層：L0 Current 熱態；L1 現行 workflow 必要 checkpoint；L2 歷史索引（metadata／refs）；L3 正式 Evidence／Artifact；L4 raw／debug／regression 僅依 retention 存在。Source tree 只放 Schema／Contract／Test／Fixture／Baseline，runtime 紀錄不得入 tree。
- Retention 預設：Raw Result 暫存；Distillation／Checkpoint 正式；Trace 最小；Debug 按需；Regression／Evidence 保留；歷史敘事不進 Hot Context。
- 失憶後讀取順序：CURRENT→ACTIVE SEGMENT→最新有效 CHECKPOINT→定向歷史查詢→必要 ARTIFACT／EVIDENCE→必要時才讀 RAW。歷史查詢維度：workflow／segment／artifact／evidence／decision／conflict／未決項／capability／revision。
- Capability 先載 id＋摘要＋呼叫契約，定義按需載入。Effort 依複雜度、風險、證據需求、Context 密度、失敗成本、可用能力分 LIGHT／STANDARD／DEEP／CRITICAL。
- 長期觀測四組：Context（峰值／均值／重複 history 比／無關負載比）、Token（每 segment 輸入輸出、驗證與 checkpoint 開銷）、Storage（checkpoint 數與位元組、raw、artifact、source-tree 成長）、Quality（重做已完成工作、stale／conflict 誤採）。
- 100k Segment 驗收＝邏輯紀錄約 100k、source-tree runtime 檔 0、Hot Context 有界、歷史檢索走索引、raw 依政策、checkpoint 大小有界、可 resume；缺資料須回報 `DATA_GAP`、不猜測。
- 禁止的錯誤優化：全 history embedding／retrieval；每次 tool call 建 checkpoint；每 checkpoint 一個 source 檔；summary 取代 canonical state；用更大 window 掩蓋檢索／狀態問題；為省 token 刪 unknown／conflict；把 stale 狀態壓進新 context；cleanup＝全刪。

## 2. 資料生命週期與退場（原 M14-14）

- 原則：保留是為了完成工作，不是永久堆積。流程 CREATE→CLASSIFY→USE→INTEGRATE→RETAIN／ARCHIVE／RETIRE→DISPOSE→需要時再生成。
- 六類：CANONICAL（永久，除非被新 canonical 取代）、WORKING（完成後判定整合或退場）、DERIVED（可重建，不與 canonical 重複存）、CHECKPOINT（整合後壓縮再退出 Hot／Active）、EVIDENCE（依 policy 保留）、HISTORICAL（失效但有「為何改變」價值→archive 唯讀）。
- 狀態機：WORKING→INTEGRATED→RETIRED／ARCHIVED／DISPOSAL_CANDIDATE→DISPOSED；決策 ACCEPTED→SUPERSEDED→ARCHIVED（ADR 模式，不靜默改寫）；程式 ACTIVE→RETIRE_CANDIDATE→QUARANTINED→VERIFIED_UNUSED→REMOVED。
- Checkpoint 退場須同時：segment 已整合、下一段不依賴、canonical artifact 已形成、必要 evidence refs 存在、無未決依賴、無進行中 recovery。
- 重大更新後掃描：IMPACT→ASSET_REFERENCE→DEAD_CODE→DEAD_DOCUMENT→DUPLICATE→REPLACEMENT→REGRESSION_SELECTION→CLEANUP_DECISION。對象：無入參模組／無 entrypoint script／被取代實作／過時相容層；被取代、無有效引用、與 Current 矛盾、重複語意、描述已不存在 code 的文件；tree 內不該有的 runtime／生成物。
- 「未被引用」只得 RETIRE_CANDIDATE，不得直接刪（可能是 CLI／workflow entrypoint、動態 import、registry、外部契約、相容路徑、人工指令）；刪前過 Reference＋Entrypoint＋Registry＋Workflow＋Regression。Quarantine 期間不作新路由目標、不作新文件 Authority、保留最小驗證。
- 版本：active 只留現行版；SUPERSEDED→archive；RETIRED→retired；DISPOSED 自 active 移除。Archive 非垃圾桶，需定期審查（superseded／retired／disposal candidate／disposed）。
- Git 工作樹與歷史分治：清 active tree，需追溯者留 git 歷史或 archive；一般清理不重寫歷史，僅在 repo 體積、敏感資料、重大污染達明確門檻時另評估。
- 長期垃圾控制：每 100／1k／10k／100k segment 量測 source-tree 檔數、active 文件／程式數、working 紀錄、active checkpoint、disposal／removed、重複語意、stale 資產、dead code 候選、重跑已完成 segment。

## 3. 變更範圍隔離（原 M15）

- 四原則：Change Radius Lock（開工前固定 Target System／Responsibility／Read／Write Scope／Allowed Interfaces／Non-goals／Expected Artifacts／Regression Set，越界→HANDOFF／SPLIT／BLOCK）；One System per Work Slice（跨 Domain 拆片；Central＋Domain 跨層預設 BLOCK，除非明定 Interface／Integration Update）；Scope Audit（該改什麼）≠ Closure Audit（該完成的是否完成、證據在、Current 同步、舊物退出）；CLEAN_READY≠Runtime PASS。
- Change Impact v2：Change Event→路徑分類（rename／delete／add）→Owner／System→直接／傳遞依賴→Interface→canonical object→regression set；不得用 path 級 `ALL`。Radius 欄位：檔數、行數、target systems／capabilities、affected interfaces／canonical objects、regression sets、unknown paths、cross_system_write、context units；風險 GREEN／AMBER／RED。變更 Context 預算：SUFFICIENT／OVERSIZED（拆）／CORRUPTED（先對帳）／UNKNOWN（定向取回）。
- System Independence v2 檢查實際 repo：registry 依賴、import／call、共享可變狀態、跨系統直接寫檔、直接 handoff API、他系統 Current 變更、未宣告整合路徑→INDEPENDENT／VIOLATION／UNKNOWN。
- Lifecycle Effectiveness：active 唯一、superseded 離開 active、archive 有 supersedes trace、working 於 closure 後退出、checkpoint 依規退場、retired 不被 Current 引用、disposal 候選不過久、孤兒不增、archive 不成垃圾桶。
- Update Closure Reconciliation：Changed Scope／Impact／System Boundary／Artifacts／Evidence／Regression／Lifecycle／Current／Projection／Archive／Next Cursor 須一致；OLD 無 NEW 對應、NEW 無來源、Changed 與 Actual Scope 不符、Projection／Current stale、artifact 缺失→不得完成。
- 維護健康：Change Radius 均值／P95；Context 均值／P95／最大；cycle 與直接系統依賴數；active 重複、孤兒、stale 引用、退場延遲；resume／stale 偵測／replay；選中測試／總測試與漏選案例。目標是低誤判，不是全部 BLOCK。
- 閉環：CHANGE→IMPACT→RADIUS→ONE SYSTEM→CONTEXT BUDGET→EXECUTE→REGRESSION→CLOSURE→LIFECYCLE→RECONCILIATION→CLEAN_READY；任一環無證據不得宣告完成。

## 4. 模型能力演化與退場（原 M16）

- 補足模型能力的 Skill／Harness／Router／Wrapper＝PROVISIONAL CAPABILITY，須有 capability_id、owner_system、role、contract、model_support_matrix、load_bearing_evidence、baseline_eval、current_eval、fallback、lifecycle、retirement_policy；缺者不得宣告可退場。
- 模型更新流程：MODEL_UPDATE→CAPABILITY INVENTORY→NATIVE SUFFICIENCY→DIFFERENTIAL EVAL→ROUTING 重評→RETAIN／REDUCE／OPTIONAL／PROBATION／DORMANT／RETIRE／BLOCKED→REGRESSION→CLOSURE→LIFECYCLE→RECONCILIATION。禁止升級後沿用全部舊支架，也禁止直接刪除。觸發：換模型族／快照、推理／工具／context／多模態能力變化、provider runtime 變、成本延遲顯著變、長期觀測使用率下降、失敗模式顯示舊支架非瓶頸（單次低使用率不自動退）。
- 差分評估：A 舊模型＋支架；B 新模型＋支架；C 新模型＋移除候選；必要時 D 舊模型＋移除候選。C 在代表任務、負向案例、recovery、邊界案例達門檻才可成退場候選；比較 task success／correctness／failure／recovery／latency／model calls／tool calls／context／artifacts。
- 支援矩陣＝model_family × capability × workload_class；全部受支援模型皆不需要才進 GLOBAL RETIREMENT REVIEW。
- Load-bearing：以 Role 為單位（PRIMARY_EXECUTION／ROUTING／VALIDATION／SAFETY_BOUNDARY／FALLBACK／OBSERVABILITY／DATA_CONTRACT_ADAPTER）；原生能力只取代 PRIMARY_EXECUTION，不使 VALIDATION／BOUNDARY／FALLBACK 自動可刪。
- 退場生命週期：ACTIVE→NATIVE_REVIEW→RETIRE_CANDIDATE→PROBATION_DORMANT→RETIRED→ARCHIVED／DISPOSED，可由明確故障自 PROBATION_DORMANT 回 ACTIVE；DORMANT 不進路由與 Hot Context，保留最小 rollback package 與 acceptance／golden eval refs；RETIRE_CANDIDATE 不得直接刪。
- 防抖（建議值）：≥1 個 baseline 比較、≥2 個獨立評估窗、≥1 組負向／recovery 案例、無 critical regression、退場收益明確大於成本。收益＝移除的 Capability Debt（Context＋Routing＋Regression＋Maintenance＋Failure Surface＋Version Surface）−遷移風險−復原成本，須穩定為正且通過驗收。
- Hot Registry 只留 active capability、狀態、契約、最小路由 metadata、評估新鮮度、fallback ref；完整 eval 紀錄入 Runtime／Evidence／History；capability 按需載入。
- 整合 M15：Capability owner＝唯一寫入責任；屬 P1 於 P1 內退場；屬 Domain System 由該系統自行 NATIVE_REVIEW→PROBATION→RETIREMENT，P1 只收 Projection／Result／Contract 更新，不得改其 Current；跨系統→HANDOFF／SPLIT；退場須經 Capability→Role→Function→Interface→System→Regression Set，發現跨系統直寫、他系統 Current 變更、未宣告介面、未知依賴→BLOCK／HANDOFF。
- 新 System 只裝 Minimum-Sufficient Capability Set（Architecture Fit→既有能力搜尋→Native Sufficiency→最小集合→Factory→Local Controller→P1 Contract）；每項須回答為何需要、哪個 model／workload、沒有它會失敗什麼、有無原生替代、退場條件。
- 總則：模型越強，不是 P1 越大；舊支架越少、必要支架越精準、Context 越小、System 越獨立、退場越可靠。
