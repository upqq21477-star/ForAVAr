# P2 接力更新企劃（唯一企劃文件）

**版本：3.5**（版本寫在內文，檔名不帶版本）｜**狀態：PLANNING_INPUT**——依唯一藍圖 §3-24，本文件到 R3 納入藍圖 v4.0 為止只規範「接力方式與批次內容」，之後縮為批次路線。
**讀法（省上下文）：** 用 `python3 tools/slice.py docs/plans/P2-Relay-Update-Plan.md --heading "## 3."` 讀協議，用 `--heading "### R1"` 讀本場批次卡。
**分工：** 藍圖是架構與功能要求的唯一權威；本文件只規範批次與驗收，不另立架構規則。本文件＝要做什麼、怎麼驗收（規劃，慢變）；`docs/handoffs/HANDOFF.md`＝做到哪、卡在哪、下一步（狀態，每場覆寫）；`docs/audit/OPEN-ISSUES.md`＝未結缺陷清單。三者各一份。

---

## 0. 一頁摘要

- **終局（願景文檔）：** P2 =「可自我治理、可重建的 AI 工程大腦（Cognitive Control System）」，解決「系統如何長期正確地工作」；需要執行層時，把 Agent-S 類工具當「手」。
- **現況（R0 實測）：** 治理骨架完整，但 ① 意圖判斷是關鍵字、Brain 是檔案替身；② 134 個測試檔中 24 個失敗，其中至少 4–5 個是「從未執行過的 AI 對話修補」所附新測試；③ 從未端到端跑通真實任務；④ 文件與資料遠超專案自己宣告的預算。
- **做法：四個梯次。** 梯次 1 整理與收斂 → 梯次 2 接腦與閉環 → 梯次 3 路徑蒸餾與知識 → **梯次 4 統一實測與驗收**。梯次 1–3 只做快速檢查與模擬運行；完整測試與評測集中在梯次 4 一次進行。
- **載體：** 每場一個新對話，交付兩樣東西：更新後的 zip＋交接檔。
- **思考環境（2026-10-12 增補）：** 大腦只讀「館員」產出的 Brief（每個 session 一檔，放 `briefs/`）；啟動必讀集分 Brief 與降級兩種模式，各有位元組預算（見 §3B.3；R1-S1 實測現況約 300 KB），每任務 Brief ≤ 8 KB。決策 D12–D14、批次 R4L、介面契約 §3B、外部借鏡見附錄 B。
- **澄清、保護與分級（2026-10-12 增補）：** 目標不明確先澄清、確認前零寫入（§3B.10）；寫入前有變更預覽與回復點；任務按風險分輕量／標準／深度（§3B.11，待使用者確認）。
- **介面契約（R4L-S0，2026-10-12 已定）：** 0 個新狀態、0 個新指令類型（`brain_proposal` 的命令集不變）、0 個新角色；`！備料` 只是 Skill 層對話指令。現行規則、裁決與驗收情境見 §3B。
- **功能復原（2026-10-12 增補）：** v2.2 舊藍圖與 2026-10-01 決策承諾的功能逐項判定（§1B 共 14 列：正常淘汰或合併 2、更新失誤或遺漏 11、更正 1）。保留者在 R4L、R4R、R5 補回並閉環；依據見 D15–D18、附錄 B2。

```mermaid
flowchart LR
  U[任務] --> B[Brain Provider<br/>真模型 / 腳本替身]
  B -->|brief_request 經 Central| Lb[館員 Librarian<br/>查閱・蒸餾・分級]
  Lb -->|Brief 每 session 一檔| B
  B -->|Proposal| G[Central Gate<br/>範圍・權限・預算・模式]
  G --> F{fast path?}
  F -->|命中| C[代碼執行<br/>機械步驟]
  F -->|未命中| S[語意運行<br/>需判斷的步驟]
  C --> V[Verifier]
  S --> V
  V --> L[(Hash-chained Trace)]
  L --> K[Knowledge / Current / Blueprint]
  L -.路徑蒸餾.-> F
```

---

## 1. 願景主張清冊（Vision Claims Ledger）

願景文檔每一句承諾對應一個可驗證主張；有證據才對外宣稱。「出處」＝願景文檔章節；卡片以「承接清冊」行標註 V 編號。

| ID | 主張 | 出處 | 通過所需最低證據 | 批次 |
|----|------|------|------------------|------|
| V1 | 可從 Blueprint＋Current 重建 | §1、§4-2 | 乾淨副本只靠必要檔重建，衍生物雜湊一致 | R7、R9 |
| V2 | 職權邊界由 Gate 以代碼強制 | §1、§4-3 | 越權寫入／危險指令／超預算的模擬情境全部 BLOCK | R5、R9 |
| V3 | 知識生命週期（觀察→主張→版本→衝突→封存） | §1、§4-1 | 一個情境腳本跑完五態，查詢結果隨之變化 | R7、R9 |
| V4 | 根因蒸餾：問題變成可重用規則 | §1、§2 | 一個真實失敗→規則→回歸測試→評測分數改善 | R9 |
| V5 | 證據分層，標記與實況一致 | §1 | precheck／交接驗證以代碼核對標記 | R1 起 |
| V6 | 自選思考模式 | §2 | 模式控制器對 Brain 輸出生效，非法轉移被擋 | R4、R5 |
| V7 | 模糊意圖收斂為規格＋最小澄清 | §2 | 評測「模糊請求」類達到事先凍結的門檻；目標不明確時確認前零寫入；澄清事件可重算先澄清率與過度澄清率（§3B.10） | R4、R9 |
| V8 | 變更先分類（ONE_OFF／LOCAL／SYSTEMIC／INVARIANT） | §2 | 真實變更經分類器路由並被抽查 | R9 |
| V9 | 可審計：結論追得到證據與裁決 | §3、§4-3 | 任一結果可由 trace 鏈回放驗證（鏈斷即失敗） | R5 |
| V10 | 資源受限下仍能工作 | §4-4 | 每場預算被遵守；Cost Gate 預設封閉 | 全程 |
| V11 | 元運行優化：少重試、少載無關上下文 | §4-5 | 步數／token 代理量相對基線下降 | R6、R9 |
| V12 | 可呼叫外部「手」 | §3 | Hands 契約＋替身＋契約測試 | R8 |
| V13 | 決定動用哪些能力與角色；錯配被擋 | §2 | 能力／角色選擇被記錄；`role_session_gate`、`role_capability_binding` 對錯配 BLOCK | R5、R9 |
| V14 | 知識與權限乾淨：Active／Archive 分離，封存不進常態上下文 | §2 | 封存資料不出現在 Brain 輸入包 | R7 |
| **V15** | **閉環後，機械性流程由代碼執行，語意運行只用在需判斷的步驟** | §4-5 與本企劃決策 D11 | `fast_paths.json` ≥ 3 條，回放與原輸出雜湊一致，步數／token 代理量下降 | R6、R9 |
| **V16** | **思考環境乾淨：大腦必讀集有位元組預算（兩種啟動模式各有預算，見 §3B.3）；資料由館員蒸餾為每 session 一檔的 Brief；缺口走研究路徑** | 藍圖「思考環境與施工環境的邊界」與本企劃 D12–D14 | `precheck [startup]` 兩模式實測皆在 §3B.3 的預算內、每任務 Brief ≤ 8 KB；模擬情境涵蓋缺口分流、並行與降級 | R4L、R9 |
| **V17** | **功能復原：舊設計與決策承諾的功能皆有判定；保留者形成閉環（生產者→消費者→驗證者→回饋），宣告不超前實況** | §1B 清冊；v2.2 §45–§57；2026-10-01 決策 | 輸入＝§1B 清冊（FR-01 至 FR-14）；預期＝14 列各有五狀態之一與依據，保留者各有閉環情境與 Track A 流程；失敗條件＝任一列無狀態或無依據、保留者缺閉環情境或 Track A 流程、宣告超前接線；產物＝`precheck [wiring]` 輸出與 R9 清冊驗收表 | R1-S3、R4L、R4R、R5、R9 |

**願景文檔核對：** §1 三層 → V1–V5；§2 六項 → V6、V7、V13、V8、V4、V14；§3 業界座標 → V12；§4 五項價值 → V1、V9、V10、V11（含 V15）、V3；§5 非主張 → 下列宣稱範圍。

V16 的出處是藍圖，不在願景文檔內，因此不列入上述核對。

**宣稱範圍：** P2 的價值在「長期、可審計、可重建地組織工程活動」。OSWorld 成績、消費級產品、取代簡單 agent 不在宣稱內。

---

## 1B. 功能復原清冊（Function Recovery Ledger）

**判定規則：** 見 D15；判定用五種狀態：確認實作遺失／規格遺失／已合併／正常淘汰／待查證（文件沒有記錄不等於功能遺失，查無依據標待查證）。下表的判定詞在 R2b 覆核時對應到其中之一。**證據層級：** 「現況」欄是觀察（檔案存在、import 與名稱比對，漏掉動態呼叫與別名）；「判定」欄是 HYPOTHESIS，R2b 覆核後才動手。**背景：** 現行藍圖對 v2.2 的引用為 0 次，Roadmap 與符合性報告仍把「P1→P2 能力處置矩陣」列為未完成，因此 v2.2 第 45–57 節的消失沒有任何處置紀錄；v2.2 點名的 9 個腳本與 1 個決策檔已不在 repo，且全庫無引用。

| ID | 功能（出處） | 原設計目的 | 現況（觀察） | 判定 | 處置與閉環 | 批次 |
|----|--------------|------------|--------------|------|------------|------|
| FR-01 | 三層投影與歷史查詢（v2.2 §46、§57） | Current 只放 HOT；歷史按範圍有界查詢；投影可重建，歷史不線性進入熱上下文 | `history_query.py`、`multitimescale_projection.py` 與決策檔已不在；Current 的 `history_policy` 仍宣告「按需」；大腦啟動讀約 300 KB | 更新失誤（與啟動過重同源） | RESTORE-CORE：HOT＝Brief.state、ACTIVE＝近期 ref、HISTORICAL＝有界查詢。閉環：event log→投影→大腦→`brief_use`→槽位調整；重建位元組相同 | R4L |
| FR-02 | 決策紀錄 ADR（§45） | 保存事實、替代方案、反轉條件；新決策以 supersedes 取代舊決策 | `architecture_decision.py` 已不在；決策散在 Roadmap 與各文件；`knowledge_canon` 已有 supersedes 機制 | 更新失誤 | RESTORE-LITE：P2 自訂 ADR 格式（參考 MADR；欄位、狀態轉移、驗證器由 P2 定義）放 `docs/adr/`＋驗證器。閉環：重評估→ADR→Brief（只載 accepted）→實作證據→反轉條件複查 | R4R-S1 |
| FR-03 | 隔離區與分段退場（§49） | 疑似失效資產依 QUARANTINED→VERIFIED_UNUSED→REMOVED 退場，不以單一條件刪除 | `retention_gate` 等四個舊機制被 `test_lifecycle_sweep` 明定移除，併入 `lifecycle_sweep`；`asset_quarantine.py` 去向未記載；取代者有 1 項測試失敗，且缺隔離階段 | 正常合併（有測試明定與取代者），但取代者未過測試、缺階段 | RESTORE-LITE：`lifecycle_sweep` 加 QUARANTINED 階段（可回復、附雜湊清單）。閉環：可達性→隔離→觀察→移除→棘輪 | R4R-S2 |
| FR-04 | 留存分類（§56） | 七類資料各自 RETAIN／ARCHIVE／REVIEW／EPHEMERAL | 只剩 archive 資產類別；`progress/` 實測 272 KB，預算 13.5 KB | 遺漏（合併時未帶入） | RESTORE-LITE：`lifecycle.v1.0.json` 增 `data_classes`（政策檔，不新增模組）。閉環：預算超標→分類建議→R3 處置 | R4R-S2 |
| FR-05 | 更新收尾鏈（§49 上半） | 依 CHANGE SCOPE→IMPACT→ARTIFACTS→EVIDENCE→REGRESSION→LIFECYCLE→CURRENT→CLOSURE 收尾 | `update_closure_reconciliation.py` 已不在；八步由分散模組各自負責，多為 NOT_WIRED 或測試失敗，無人核對順序與完整 | 部分合併（職責分散、閉環缺） | RESTORE-LITE：`closure_chain.py` 只核對，不持有 Current。閉環：R5 迴圈收尾呼叫→缺步回 INCOMPLETE | R4R-S3 |
| FR-06 | 隔離更新與交接基線（§54） | 工作片段鎖定語意基線、變更半徑、交接目標；恢復時比對基線 | `isolated_update_handoff_recovery.py` 已不在；`semantic_baseline`、`change_radius`、`handoff_target` 在程式與 schema 全無；M33 角色隔離承接拓撲；DEFECT-011 的版本保護測試失敗 | 部分合併（拓撲由 M33 取代，基線欄位遺失） | RESTORE-LITE：work unit 與 continuation box 增三欄；admission 恢復時比對，不符回 STALE。閉環：交接→恢復比對→STALE 或續跑 | R4R-S3 |
| FR-07 | 正式根與暫存根分離（§52） | 唯讀正式 Registry 與暫存施工根分開 | 以 `canonical_registry_root` 保留於 `construction_*` 與 schema | 仍有效（我前一輪依名稱比對誤報為消失，在此更正） | 保留；Track B 以 `git worktree add --detach` 建隔離根，唯讀由檔案權限或掛載控制（`--detach` 本身不等於唯讀） | R8 |
| FR-08 | 容量壓力與失憶復原（§53） | 100 至 100,000 段壓力；失憶復原 10 案例 | `long_run_lifecycle_simulation.py` 已不在；`state_growth_1000` 只到 1,000；`simulated_amnesia_resume` 有 1 個測試檔 | 部分保留 | RESTORE-LITE：規模參數化到 10⁵，補缺的案例，只在 R9 跑 | R9 |
| FR-09 | 能力命名空間預算（§56） | 常駐只留 ID＋摘要＋呼叫契約，定義按需載入 | `capability_namespace_budget.py` 已不在；`planner_library` 的「只看卡片」無人消費；Brain Skill 啟動全載 | 更新失誤（與啟動過重同源） | RESTORE-CORE：槽位卡片優先，定義經 `brief_request` 展開；`precheck [startup]` 把關 | R4L |
| FR-10 | 對話記錄與指令路由 | 對話輪次可記錄、指令可路由、可重建 | CAP-CONVERSATION-RECORD、CAP-INSTRUCTION-ROUTING 登記 ACTIVE；文件宣稱的三個檔不存在（DEFECT-015）；`role_command_router` 存在 | 從未落成，文件與登記超前 | RESTORE-LITE：`event_log` 加 `DIALOGUE_TURN`（conversation_id、輪次、內容雜湊、ref，不存全文）。閉環：輪次→event log→Brief.recent→續談 | R4R-S4 |
| FR-11 | 工具支撐的分析能力（2026-10-01 決策 B 類） | 統計／聚類／趨勢／週期／異常由模型提出、代碼驗證 | 決策本身正常（48 項中 47 項 ROUTE_ONLY）；23 項能力全標 CANONICAL／ACTIVE，scripts 無對應實作函式 | 正常淘汰，登記超前 | 登記改 `DECLARED_NO_TOOL`；有消費者才以程式化工具呼叫（沙箱）加 Gate 復原，否則 RETIRE 並記 ADR。五欄位（設計）：提供者＝R4T 的沙箱工具；消費者＝需統計、聚類、趨勢、週期或異常檢測的任務；可用模式＝Track B；成功條件＝輸入雜湊與輸出 schema 通過 Gate；失敗回饋＝未觸發即 RETIRE 並記 ADR | R1-S3、R4T |
| FR-12 | 分析迴圈契約（同決策 C 類，F39–F48） | 下一輪須有新證據或新問題、保留未知、防重複、可完成 | 決策要求改成「Contract＋Verification」，但迴圈守門、穩定度、全程追溯驗證全無實作 | 決策承諾未履行 | RESTORE-LITE：`loop_contract` 驗證併入 R5 迴圈；施工與研究共用。五欄位（設計）：提供者＝`loop_contract`（R5）；消費者＝R5 迴圈與研究任務；可用模式＝Track A 手動核對清單、Track B 程式驗證；成功條件＝下一輪附新證據或新問題、重複狀態雜湊即停、未知保留、完成條件明確；失敗回饋＝停止並由 Brain 提 `WAIT` 或 `BLOCK` | R5 |
| FR-13 | Library 卡片（原企劃 Axis C） | 規劃器只看卡片，Skill 按需載入；20 標籤與 15 溝通規則映射成 Method／Pattern | `planner_library.v1.0.json` 只有 5 methods、5 patterns；自述 SIMULATION_ONLY；Brain 未消費 | 未完成 | 補卡片（R2b 分流決定哪些進 CORE）；由館員槽位載入；`brief_use` 決定留存 | R4L-S3、R6 |
| FR-14 | 知識取用鏈 | 上下文組裝、資料通道、Pack | `knowledge_context`、`operational_reference_pack`、`external_skill_adapter` 無非測試 import | 未接線 | 接入館員與 R5 迴圈；外部候選的晉升接入點＝R7-S2（`knowledge_intake`、`research_source_normalization`，對接待核，見 §3B.9） | R4L、R5 |

## 2. 十八個戰略決策

- **D1 先整理後新增：** 梯次 1 只做整理與修補；新功能從梯次 2 開始。
- **D2 規則凍結：** R3 完成前維持現有規則數；新增想法先寫進交接檔「待決」欄，由 R2／R3 處理。
- **D3 薄 harness、真大腦：** 路由與意圖交給模型的結構化輸出；程式守硬約束（範圍、權限、預算、驗證）。關鍵字意圖判斷降為離線備援。
- **D4 對照決定去留：** 新機制先以模擬運行落實功能；是否納入核心，由梯次 4 的基線對照決定，未改善者退回封存。
- **D5 失敗驅動治理：** 每道閘門與規則對應一個真實失敗案例；沒有案例的規則封存。
- **D6 保留資產：** hash-chained trace、event log／replay、schema 先行、證據標記、knowledge_* 生命週期、continuation box、Skill 漸進揭露。
- **D7 一個功能一份文件：** 企劃、交接、未結問題各一份；歷史交給版本控制與舊 zip。`precheck [hygiene]` 以代碼把關（圖檔、壓縮檔、多份交接、多份企劃、歷史日誌）。
- **D8 每份文件與資料三選一：** 權威、被有效引用、或刪除。實驗數據、執行輸出、圖檔、fixture 同理：被測試或權威文件引用的留下並集中，其餘刪除；可由腳本重生的輸出只留腳本。檔名版本寫在內文。蒸餾順序：先把仍有效的結論寫進權威文件，再刪來源。`precheck [refs]` 列出懸空引用與孤兒檔。
- **D9 規則寫進代碼，文件只寫該做什麼：** 重要約束由閘門（precheck、Gate、schema）執行；文件用短句、正向、單一出處的語句描述動作。`precheck [style]` 統計否定式用語，作為文件瘦身的量測。
- **D10 實測集中：** 梯次 1–3 的每一場只做快速檢查（編譯、JSON、衛生、引用，約 3 秒）與模擬運行；完整測試套件與評測在梯次 4 一次進行。每個未實測的修補登記到交接檔「待驗證清單」，由梯次 4 成批驗證。（梯次 2、3 的功能落地以 D19 為準。）
- **D19 梯次 2、3 的落地要求（使用者 2026-10-13；覆寫 D10 的「只做模擬」）：** 梯次 2 每個完結任務的功能，須落實為實際運行的代碼（有可執行入口與實跑退出碼 0 的證據；只有模擬運行不算完結）。梯次 3 每個完結任務須推進到閉環（輸入→處理→驗證→寫回完整跑通）；閉環後把其中機械式的運作流程蒸餾、重組為代碼結構，用代碼運行取代語意運作，語意只留給需要判斷的節點。每一梯次的階段任務都要確實完成；預算不足造成的 PARTIAL 只是暫存，下一場必須補完。完整測試與評測仍集中在梯次 4。
- **D11 先閉環、再蒸餾：** 功能先以語意運行跑通並完成閉環（R5），再由 R6 把機械性步驟換成代碼執行（fast path），語意運行保留給需判斷的步驟。
- **D12 館員分流：** 大腦只讀館員產出的 Brief。次序為：大腦分解任務→Central 派工→館員查閱並蒸餾→大腦讀 Brief 後決策。館員依 D17 雙軌執行，對應藍圖既有的 Knowledge Acquisition 角色。
- **D13 Brief 是暫存、可覆寫、可重建的衍生品：** 每個 `brief_session_id` 一個覆寫檔，放 `P1-Central-Control/briefs/`（不放 `state/`）；內容只含來源追溯、工作識別、有效性檢查與生命週期清理所需的最小資料，加任務所需的逐字摘錄（附來源定位）與缺口清單；權威仍在原始檔，歷史由版本控制與 trace 保留。細則見 §3B.3。
- **D14 缺口分級再分流：** 館員以代碼評 SUFFICIENT／PARTIAL／MISSING；缺口由大腦決定窄化重請求，或派研究任務上網。網路結果標 UNTRUSTED_CANDIDATE，驗收後才進 Knowledge。
- **D15 復原判定規則：** 正常淘汰或合併須同時具備四項：書面裁定、取代者通過測試、舊入口無引用、無未處理依賴（驗收對象是這四項，被淘汰功能本身是否通過測試不列入驗收）；其餘為更新失誤，列入 §1B 並處置。判定用五種狀態（見 §1B）。判定先經 R2b 覆核，再動手。
- **D16 先承載、後新增：** 復原優先放進現有模組（`lifecycle_sweep`、`event_log`、continuation box、`planner_library`、`role_command_router`、`librarian.py`）；新增模組須寫明現有模組無法承載的理由。v2.2 的九個舊檔不原樣重建。
- **D17 雙軌運行：** 最低運行標準是 AI 對話＋GitHub（Track A）；程式只作加速（Track B）。每個復原功能都寫出 Track A 的手動等價流程，輸出格式兩軌一致。外部執行工具（程式化工具呼叫、MCP 伺服器等）只能選配，屬 Track B。
- **D18 閉環四要素與宣告棘輪：** 每個功能宣告生產者、消費者、驗證者、回饋；`capability_registry.json` 的 implementation 由接線證據（非測試 import、入口引用、測試狀態）推導，宣告以接線證據為上限；四要素的完成條件見 §3B.5。

---

## 3. 接力協議

### 3.1 載體
每場結束產出 **`P2-relay-<場次>.zip`**（例 `P2-relay-R1-S2.zip`），內含 `MANIFEST.sha256` 與：
- `docs/handoffs/handoff.data.json`——交接**唯一資料來源**（專案原有機制，上限 24,000 字，由 `handoff_render.py` 驗證）。
- `docs/handoffs/HANDOFF.md`——上者的生成檢視，每場覆寫。

**回寫 GitHub：** zip 是接力載體，GitHub 是真源。每場結束後，你把 zip 內容解壓覆蓋到 repo 並 commit（訊息＝場次 id）；下一場以該 commit 重新打包為準。repo 上若有接力以外的變更，先用 `MANIFEST.sha256` 比對再人工合併。

**既有 Active Work（`P2-B2.2`、`P2-B1-B8`）：** 在 R0–R2 期間維持現狀，R3-S3 以專案更新交易決定「結案」或「改指向本計畫」。B2.2 的 Operational Pack 屬 CORE 候選，由 R2b 判定去留。

指令：`python3 tools/pack_handoff.py --batch R1-S2 --out <目錄>`（驗證交接完整、全庫可編譯、衛生檢查通過，再渲染檢視並打包）；收件端 `--verify <zip>`；`--skeleton R1-S3` 印出下一場的空白資料；`--render` 只重渲染。

### 3.2 場次預算（免費額度）
- **每場：讀 ≤ 40 KB 文字、寫 ≤ 30 KB、工具呼叫 ≤ 25 次。** 免費額度的實際上限未知，所以每場做完一張場次卡就交接。
- **讀取順序：** `HANDOFF.md` → 本場卡（`slice.py --heading`）→ 卡片列出的檔案。
- **大檔用 `tools/slice.py`**（`--toc`／`--heading`／`--lines`／`--grep`／`--json-path`，輸出自動截斷）。大檔包括：藍圖 131 KB、Roadmap 44 KB、Test-Strategy 49 KB、Conformance Review 61 KB、`progress/*.json` 最大 78 KB、`central_role_interface.py` 150 KB。
- **`slice.py` 的定位：** 它是有沙箱的接力場次的效率工具；沒有 Python 時以標題手動定位並只讀所需節。本企劃不列入 P2 運行時的啟動讀集。
- **失敗歸因：** 交接檔已附 24 檔首個錯誤表；梯次 4 需要重新取得時用 `tools/failfirst.py`（約 6 KB 輸出）。
- **70% 規則：** 預算用到 70% 就寫部分交接，再用剩餘額度做最小任務。
- 估算：中文約 2.5 bytes／token，程式與英文約 4 bytes／token。
- 沙箱無網路：使用專案自帶 `scripts/jsonschema` shim；依賴版本差異記為 UNKNOWN。
- 建議把 §3.6 啟動提示詞貼進 Claude Project 的自訂指令，每次新對話只附 zip。

### 3.3 任務分級與持續前進
- 任務分 **MUST／SHOULD／COULD**；MUST 全成標 DONE，否則標 PARTIAL，兩者都交接。
- 同一問題試 **2 次**（＝初次加 1 次重試，與 §3B.4 的重試語義一致）；仍未解就在交接檔寫 BLOCKER（現象、已試、假說，標 HYPOTHESIS），換下一個獨立任務。
- 沒有執行環境時，做標 `DOC_ONLY` 的任務；程式變更標 `PATCHED_UNVERIFIED` 並登記到「待驗證清單」。
- 測試期望維持原樣；需要改期望時，在交接檔寫「原期望為何是錯的」。

### 3.4 證據詞彙
`PROGRAM_EXECUTED_PASS`（實際執行且退出碼 0，限於跑過的範圍）／`SIMULATED_PASS`（模擬運行通過）／`IMPLEMENTED_UNVERIFIED`／`PATCHED_UNVERIFIED`／`NOT_EXECUTED`／`OBSERVED_RUNTIME`（真實模型＋真實任務跑過才用）／`AI_ATTESTED`（AI 自述已遵守，沒有獨立檢查）。**執行約束軸 `enforcement`** 與證據等級是兩個獨立欄位：`POLICY_ONLY`（只靠文字約定，由 AI 自行遵守）／`PROGRAMMATIC`（由程式、schema 或 Gate 強制）；Track A 的介面一律標 `POLICY_ONLY`，`PROGRAMMATIC` 只用於 Track B 的程式化強制。根因在區分測試通過前標 `HYPOTHESIS`；`failfirst` 的首個錯誤行是事實，由它推出的原因是假說。

### 3.5 收尾（梯次 1–3 每場）
1. `python3 tools/precheck.py`（快速檢查，約 3 秒）。
2. 把本場所有程式修補登記到交接檔「待驗證清單」（檔案→梯次 4 要跑的測試）。
3. 覆寫 `handoff.data.json`（格式用 `--skeleton`）。
4. `python3 tools/pack_handoff.py --batch <場次> --out <目錄>`。
5. 對外回報：zip 路徑＋一段摘要。

梯次 4 的 R9-S1 另跑 `python3 tools/precheck.py --run-tests`，並依結果縮小基線。

### 3.6 啟動提示詞
**場次規則已內建於交接檔「接力規則」章（`pack_handoff.py` 每場自動帶入）；與下列提示詞不一致時，以交接檔為準。**
> 你是 P2 接力工作者，執行 **<場次>**。附件：上一場的 `P2-relay-*.zip`。
> 1) 解壓後執行 `python3 tools/pack_handoff.py --verify <zip>`，再讀 `docs/handoffs/HANDOFF.md`。
> 2) 用 `python3 tools/slice.py docs/plans/P2-Relay-Update-Plan.md --heading "### <批次>"` 讀本場卡，再讀卡片列出的檔案（一律用 slice，預算：讀 ≤ 40 KB、寫 ≤ 30 KB、工具 ≤ 25 次）；沒有 Python 時依 §3.2 以標題手動定位。
> 3) 依 MUST→SHOULD→COULD 施工；同一問題試 2 次，之後記 BLOCKER 換下一組；測試期望維持原樣。
> 4) 收尾：`python3 tools/precheck.py`（約 3 秒）→ 修補登記到「待驗證清單」→ 覆寫 `handoff.data.json` → `pack_handoff.py`；對話內回報 zip 與摘要。完整測試留到梯次 4。

---

### 3.7 證據階梯與免費額度條件（A9 蒸餾；現行規則）
- **證據階梯（對應 §3.4 詞彙）：** T0 靜態審查（只證明已檢查的契約沒被違反，標 `NOT_EXECUTED`）→ T1 schema 真正執行 → T2 單元／模擬在真正 Python 跑完（`PROGRAM_EXECUTED_PASS`／`SIMULATED_PASS`）→ T3 真實 repo 唯讀預檢 → T4 Pack 暫存建立、驗證、冪等重建後升格 → T5 正式 caller 端到端 → T6 `OBSERVED_RUNTIME`。**界線：** 低層不得宣稱高層結論（T2 全過不得標 T4／T5／T6 或通用 PASS）；AI 在對話內手動推演是案例設計，不算執行證據。
- **計量服務條件（CostGate 的規格，程式見 R4 M2；GitHub 官方文件 2026-10-14 核對）：** 用任何計量服務前須核實費率、剩餘免費額度、耗盡後的行為與費用歸屬，任一未知即 BLOCK；禁止加值、自動續費、付費升級。Codespaces：個人 Free 每月 120 core-hours 與 15 GB-month，任一用盡且無付款方式即封鎖；確認剩餘額度後才建立或恢復，否則走 AI 對話＋GitHub 的靜態路徑。Vercel Sandbox、Replit、瀏覽器自動化等不得因已連線或有餘額就視為免費。無法核實時只做零額外用量的工作，結果不得冒充程式執行驗收；成本證據須來自官方帳單或額度頁，AI 推估不算餘額事實。

**使用者裁決（2026-10-14，D-REAL-DEFER）：** 進入 R9 前不做任何真實測驗（解壓、寫入 GitHub 工作量大）；R9 一次實測、一起修。R9 前一律模擬運行（標 SIMULATED_PASS）與後備驗證器本地測試；`P1-Central-Control/policy/fixed_deps.v1.0.json` 的 `real_testing_mode` 為 `DEFERRED_TO_R9`（F2 債上限、F3 暫停，債仍計量），R9 開始時改 `ENFORCED`。

## 3B. 介面契約結論（R4L-S0；現行規則）

本節整合 R4L-S0 的結論，不是第二份企劃：架構與功能要求以藍圖為準，本節只定批次與驗收所需的介面規則。規則落地後，條文移入藍圖（架構規則）或 schema／政策檔（可執行規則），本節縮為指針；與藍圖衝突時以藍圖為準。R4L-S0 的審查紀錄（事實核對、缺陷逐項決策、兩輪審查處置）不在 repo，屬非權威參考資料，不入啟動讀集。

**範圍：** 0 個新狀態、0 個新指令類型（`brain_proposal` 的命令集不變）、0 個新角色。缺上下文由現有 `brain_proposal`（`WAIT`＋`problem_class=INFORMATION_GAP`＋`epistemic_state=NEEDS_EVIDENCE`＋`contract_gap_refs`）、`ASK_INPUT`、`NEEDS_BRAIN` 承載；指令類型、角色綁定、結果映射、結果路由、狀態轉移五份契約不改（R5 釐清 `result_routing` 中 `FAIL` 的 `terminal_state` 值為 `"BLOCK"` 的語意）。實際新增：2 個 schema（`brief_request`、`brain_brief`）、`！備料` 的 Skill 層登記、router 的字元正規化、`event_log` 事件類型擴充、失敗階梯轉接函式。

### 3B.1 使用者裁決（2026-10-12）

| ID | 裁決 | 落點 |
|----|------|------|
| OD1 | 批准：`！備料` 放 Skill 層，不改 `canonical/` | §3B.2、R4L-S1 |
| OD2 | 批准：Brief 放 `P1-Central-Control/briefs/`，不放 `state/`；只留最小資料 | §3B.3、R4L、R4R-S2 |
| OD3 | 批准並定義重試語義：可重試步驟首次失敗後最多自動重試 1 次 | §3B.4、R5-S1-M5 |
| OD4 | 有條件批准：降級模式採獨立預算與硬上限，不取代 Brief 模式的原上限 | §3B.3、R1-S3-M2、R4L-S1-M3 |

### 3B.2 指令（OD1）

- **`！備料`：** 在 Skill 官方指令清單與 `docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md` §1.3 指令表各登記一次（`！幫助` 以該表為準），R4L-S1-M4 的檢查比對兩處清單一致。`canonical/` 不改；`！備料` 不經 `role_command_router`，辨識只靠 Skill（`POLICY_ONLY`，證據 `AI_ATTESTED`）。Track B 若需要程式化角色鎖定，另案提出。
- **`!` 與 `！` 的正規化分兩層，各自的強制力不同：**

| 層 | 涵蓋指令 | 做法 | enforcement | 驗證 |
|----|----------|------|-------------|------|
| Skill 層 | 全部 Skill 官方指令（含 `！備料`、`！研究`、`！收斂`） | Skill 文字規則：開頭的 ASCII `!` 視同 `！` | `POLICY_ONLY` | 只能由 Track A 乾跑觀察（`AI_ATTESTED`） |
| router 層 | router 已登記的 `role.activate`：`！施工`、`！驗收`、`！討論`、`！指導` | `resolve()` 入口單點映射（R4L-S1-M5） | `PROGRAMMATIC` | `test_role_command_router` 新案例（SC-08） |

- 兩層互不涵蓋：router 的映射對 `！備料` 等 Skill 層指令無效；Skill 層的文字規則只是約定，程式強制只存在於 router 層。文件與 Skill 的指令一律寫全形。
- `！研究`、`！收斂` 已是 Skill 官方指令，不加進 router；`！收斂` 保留 Skill 既有定義（比較目標與實際、分類可重用學習、帶剩餘缺口收尾）。

### 3B.3 Brief 與啟動讀集（OD2、OD4）

**Brief 的位置與最小資料（OD2）：** 每個 `brief_session_id` 一個檔，路徑 `P1-Central-Control/briefs/<brief_session_id>.json`；歸 `RESEARCH_ARTIFACTS`，資料類別 `EPHEMERAL`。Brief 是可丟棄、可重建的衍生品；兩個 session 的檔並存，衝突時以最新 session 重建，不做事件化合併。只保留四類用途的資料，再加任務所需內容（見 R4L 設計）：

- 來源追溯：`provenance`（`base_commit`、`sources[]`、`readback`）。
- 工作識別：`brief_session_id`、`work_id`。
- 有效性檢查：`sources[]` 的變動比對與 HOT 欄位指紋。
- 生命週期清理：`lifecycle`（資料類別、建立時間、是否活動中）；已過期的檔由 `lifecycle_sweep` 清，活動中的 session 檔不清。

不放：歷史事件內容、Current 或 `state/` 契約檔的整份複本、其他檔已有的重複狀態。`brief_session_id` 由 `！備料` 會話（Track A）或 `librarian.py`（Track B）產生。

**啟動模式與預算（OD4）：** 有 Brief 且未 STALE → 讀 Skill＋Brief；無 Brief 或 STALE → 讀降級讀集（Skill＋Current 的 HOT 摘要），Brain 先判斷資訊是否足夠，足夠就繼續，不足才提示 `！備料`；降級時不退回讀全部。

| 模式 | 完整讀集 | 上限 | 目標 | 強度 |
|------|----------|------|------|------|
| Brief 模式 | Skill＋Brief＋必要讀取包裝 | 16 KiB（16,384 B） | — | 沿用原上限；R4L 完成前 WARN，完成後 HARD |
| 降級模式 | Skill＋Current 的 HOT 摘要＋必要讀取包裝 | 20 KiB（20,480 B） | ≤ 18 KiB（18,432 B） | HARD；獨立預算，不取代 16 KiB |

- **核算：** `precheck [startup]` 的確定性腳本按 UTF-8 實際位元組加總完整讀集（Skill、Current 或 Brief、讀取程序加入的標頭／分隔／指示文字），輸出每項位元組、合計、讀取檔數、被排除 ref 數。降級模式合計 > 18 KiB 時，輸出每個無法精簡的必要項目、位元組與理由；> 20 KiB 為 FAIL；任何超額都在輸出中明列。
- **精簡方向（觀察＋算術）：** 現況 Skill 7,683 B、Current 17,923 B；R1-S3-M2 達 12,000 B 後降級讀集 19,683 B（尚未計入讀取包裝），距目標至少再精簡 1,251 B。順序：先縮 Current 的 HOT 摘要（只留該路由所需欄位），再改寫 Skill 啟動段（R4L-S3-M3b）。Brief 模式 7,683 B＋Brief 8,000 B＝15,683 B，餘量 701 B，Skill 變大就可能超標。
- **單位：** 啟動預算的 KiB 為 1,024 B；其他處的 KB 為概略值。

### 3B.4 重試與失敗階梯（OD3）

1. **重試類步驟：** 首次失敗後最多自動重試 1 次（初次加重試共 2 次嘗試）。重試類＝暫時性或原因未明的執行失敗（工具逾時、測試未過、輸出格式不合）。
2. **終止類錯誤（OD3 中直接進失敗處理、不再重試的錯誤）：** 不重試，直接進正式失敗處理（Central 依 `result_routing` 發 `FAIL`，或 Brain 提 `BLOCK`）。終止類＝契約或授權性錯誤（schema 或契約驗證失敗、越權或超出 `write_scope`、預算硬上限、雜湊或 trace 鏈驗證失敗、無法回復的操作）。錯誤碼清單由 R5-S1-M5 登記為 `retry_class`；未登記的失敗類型一律視為終止類。
3. **再次失敗：** Central 不再 `REQUEUE`；記錄原因（事件）；進既有出口：`WAIT`＋`INFORMATION_GAP`（再 `ASK_INPUT` 或 `！研究`）、`BLOCK`，或 Brain 附新證據的 `REPLAN`（過 Gate，沿用 `loop_contract`「下一輪必附新證據」）。
4. **終點可見：** 重試次數有上限，停住時必有紀錄；每個終點都有事件紀錄與可見狀態（`WAITING`、`BLOCKED` 或 `FAILED`）。
5. **計數單位：** 同一 `work_id` 內連續失敗，成功一次歸零；`REPLAN` 不重置計數。
- **實作定位：** 重用 `debug_escalation_policy.decide()` 的等級語意（等級 1＝重試 1 次；等級 ≥ 2＝停止自動重試），由 R5-S1-M5 的轉接函式把 segment 嘗試事件轉成 `decide()` 的 run 形狀。`parallel_scheduler` 現況預設 `default_max_attempts = 1`（無重試），Brain 的 `REQUEUE` 會把 `max_attempts` 設為「已用次數＋1」；「最多重試 1 次」在轉接層或 segment 的 `retry_policy` 落實，`REQUEUE` 受同一上限約束。本輪不改程式。
- **Track A：** 等價流程＝§3.3 的 BLOCKER 流程（同一問題試 2 次，之後換任務或 `ASK_INPUT`）。

### 3B.5 三層投影與 D18 完成條件

- **HOT**＝`Brief.state`，啟動必讀。**ACTIVE**＝`Brief.recent` 與 `slots[]`，任務需要時載入。**HISTORICAL**＝`event_log` reducer 的有界只讀查詢，預設不載入。
- **升級：** 任務路由的必要槽（`brief_slots.json`）進 ACTIVE；事後補查命中的 ref 補進 `brief_slots.json`（D5）。**降級：** 連續 N 個任務未被引用的槽降為 HISTORICAL，只留 ref（N 在 R9 以數據定）。
- **找不到資料：** 槽標 `MISSING`，ref 記入 `coverage.gaps`，內容留空，不以舊內容或模型記憶補寫。
- **可觀察行為：** Brief 的 `budget` 欄位與 `precheck [startup]` 輸出同樣三項：讀取檔數、讀取位元組、被排除 ref 數。

| D18 要素 | 完成條件（可驗證） |
|----------|--------------------|
| 生產者 | 有一個非測試的呼叫點，產出該功能的輸出 |
| 消費者 | 有一個非測試的讀取點，且讀取失敗有出口 |
| 驗證者 | 有一個不同於生產者的檢查（測試、Verifier 或讀回），其結果進證據欄 |
| 回饋 | 驗證失敗或使用落差會改變下一次行為（例：補進 `brief_slots.json`、降級、停用），有事件或檔案紀錄 |

### 3B.6 Run Contract 與外部候選晉升

- **P2 Run Contract＝任務生命週期：** RECEIVE → BRIEF → PROPOSE → GATE → ACT → VERIFY → INGEST → PROJECT → CLOSE。每一步各有 Track A 的人工等價流程與 Track B 的函式對映（INGEST＝`repository_result_ingestion`、PROJECT＝`current_projection_sync`、CLOSE＝`closure_chain`；閉環演練＝`minimal_closed_loop_runner`）。`scripts/p2_run.py` 是 Track B 轉接器，不是最低模式的必經路徑。
- **外部候選狀態：** `UNTRUSTED_CANDIDATE → VERIFIED → ACCEPTED／REJECTED／EXPIRED`。`CONTROL_RESEARCH` 蒐集並寫入研究產物；`VERIFIER` 以 `INSPECT_ARTIFACT` 比對來源文字與主張、寫 `WRITE_EVIDENCE`；是否採納由 Brain 依任務與藍圖提案，經 Gate。Build 只把 VERIFIED 以後的資料寫成設計依據。R4L 階段 `Brief.external[]` 只標 `UNTRUSTED_CANDIDATE`，Brain 不以它單獨作決策依據（Track A＝`POLICY_ONLY`）；晉升實作隨 R7-S2。

### 3B.7 介面索引

契約先於實作：每個功能先在本表有一列；其他文件引用 ID，不重抄契約內容。`enforcement` 與證據等級分欄（§3.4）；證據等級的目標見 §3B.8。

| ID | 介面 | Producer → Consumer | 契約與失敗出口 | enforcement | 批次 |
|----|------|---------------------|----------------|-------------|------|
| I01 | `brief_request` | Brain → 館員 | `schemas/brief_request.schema.json`（≤ 5 項：主題、功能 ID、問題）；超過 5 項截斷並記入 `omitted_refs`，缺欄位拒絕 | A: POLICY_ONLY／B: PROGRAMMATIC | R4L-S1 |
| I02 | `brain_brief` | 館員 → Brain | `schemas/brain_brief.schema.json`；`state` ≤ 3 KB、整檔 ≤ 8 KB；缺槽→`coverage.gaps`，STALE→重建 | A: POLICY_ONLY／B: PROGRAMMATIC | R4L-S1 |
| I03 | `！備料` 入口 | 使用者 → 館員會話 | Skill 官方指令＋Activation Interface §1.3 指令表（§3B.2）；指令不明由 Skill 提示 | POLICY_ONLY | R4L-S1 |
| I04 | 缺上下文回饋 | Brain → Central | `brain_proposal`：`WAIT`＋`INFORMATION_GAP`＋`NEEDS_EVIDENCE`＋`contract_gap_refs`；需要 schema 之外的欄位→回本節修訂 | PROGRAMMATIC（schema 驗證） | R4L-S1 |
| I05 | `brief_use` 記錄 | Central → event log → 統計 | `BRIEF_DELIVERED` 與提案事件，統計腳本重算；事件缺漏→標 `UNMEASURED` | A: AI_ATTESTED／B: PROGRAMMATIC | R4L-S2、S3 |
| I06 | STALE 判定 | 館員／Gate → Brain | `provenance.base_commit`＋`sources[]`；STALE→重建，重建失敗→降級讀集 | A: POLICY_ONLY／B: PROGRAMMATIC | R4L-S2 |
| I07 | 讀回驗證 | 館員 → 館員自驗／Verifier | 抽樣 3 槽，比對逐字摘錄與來源行範圍，結果寫 `provenance.readback`；不符→Brief 標 `READBACK_FAILED` 並重建 | POLICY_ONLY | R4L-S1 |
| I08 | 失敗階梯 | 嘗試事件 → 轉接函式 → `decide()` → Brain／Central | §3B.4；第 2 次失敗→停止自動重試並進既有出口 | A: POLICY_ONLY／B: PROGRAMMATIC | R5 |
| I09 | 結果匯入 | 角色結果 → `repository_result_ingestion` → 事件／狀態 | 既有；Track A 手動提交結果封包並讀回；匯入失敗→結果保留於提交處並回報 Brain | A: POLICY_ONLY／B: PROGRAMMATIC | R5 |
| I10 | Current 投影 | 事件 → `current_projection_sync` → `P1-CURRENT.json`、README | 既有；投影不符→標 STALE，不覆寫 Current | PROGRAMMATIC | R3、R5 |
| I11 | 外部候選晉升 | `CONTROL_RESEARCH` → `VERIFIER` → Brain | §3B.6；`REJECTED`／`EXPIRED`→不進 Knowledge | POLICY_ONLY（R7 前） | R7 |
| I12 | 指令正規化與清單 | 使用者文字 → Skill／router | §3B.2 兩層；未知指令→router 層回 `UNKNOWN_ROLE_COMMAND` | Skill 層 POLICY_ONLY／router 層 PROGRAMMATIC | R4L-S1 |
| I13 | P2 Run Contract | 任務 → 九步生命週期 | §3B.6；任一步失敗→依 I08 | A: POLICY_ONLY／B: PROGRAMMATIC | R5 |
| I14 | 收尾鏈與交接 | R5 迴圈 → `closure_chain` → HANDOFF | FR-05 的八步；缺步→`INCOMPLETE` | A: POLICY_ONLY／B: PROGRAMMATIC | R4R-S3 |
| I15 | 澄清紀錄 | Brain → event log → 統計 | `CLARIFICATION_ASKED`／`CLARIFICATION_RESOLVED`（§3B.10）；事件缺漏→標 `UNMEASURED` | A: AI_ATTESTED／B: PROGRAMMATIC | R4 |
| I16 | 寫入保護 | Brain／Gate → 工具 → Verifier | §3B.10；缺前置或碰受保護路徑→BLOCK；事後差異超出預覽→FAIL 並還原 | A: POLICY_ONLY（平台層：GitHub 分支保護，待確認）／B: PROGRAMMATIC | R5 |

### 3B.8 驗收情境

三原則：契約先於實作；最低模式真能運作（核心閉環不依賴封存的 Actions、額外 Python 環境或外部服務，這些屬 Track B）；證據強度誠實（靜態讀檔、設計模擬、程式實際執行、驗收通過是四個等級，不混用）。執行狀態記在交接檔，本表只規定規格。

| ID | 情境 | 輸入 | 預期 | 失敗條件 | 軌 | 證據級（目標） |
|----|------|------|------|----------|----|----------------|
| SC-01 | 冷啟動無 Brief | 無 Brief 檔 | 讀降級讀集，判斷是否需備料；讀集在 §3B.3 的降級預算內，超過目標時列出無法精簡的必要項目 | 讀集含藍圖全文；超過硬上限；超額未列明 | A、B | `SIMULATED_PASS` |
| SC-02 | Brief 缺上下文 | 缺槽的 Brief | Brain 提 `WAIT`＋`INFORMATION_GAP`，補查次數計 1 | 需要新狀態或新欄位 | A、B | `SIMULATED_PASS` |
| SC-03 | 連續失敗 | 同一 `work_id` 的重試類步驟連續失敗 2 次 | 第 1 次失敗後重試 1 次；第 2 次失敗後不再 `REQUEUE`，進 `WAITING`（或 `BLOCKED`），原因已記錄；終止類錯誤不重試，直接進正式失敗處理 | 第 3 次自動嘗試被排入；失敗後無事件紀錄 | A、B | `SIMULATED_PASS` |
| SC-04 | STALE | 提交 Brief；再改一個來源檔 | 前者非 STALE，後者 STALE | 提交 Brief 本身導致 STALE | A、B | `SIMULATED_PASS` |
| SC-05 | 並行 | 兩個 session 同時提交 Brief | 兩檔並存於 `briefs/` | 一檔覆蓋另一檔 | A、B | `SIMULATED_PASS` |
| SC-06 | 外部未驗證 | 一個 `UNTRUSTED_CANDIDATE` | 不進 Knowledge；標記保留 | 未經 VERIFIED 被採用 | A、B | `SIMULATED_PASS` |
| SC-07 | Track A 乾跑 | 只用對話＋GitHub，不跑 Python，完成一次 `！備料`＋讀回驗證 | 產出 Brief 與 `readback` 結果 | 任一步要求執行 Python | A | 先標 `NOT_EXECUTED`；演練後以真實會話為準標 `OBSERVED_RUNTIME` |
| SC-08 | router 層指令字元 | `!施工`、`！施工` | 同一 `ROLE:EXECUTOR` 會話清單 | 結果不同 | B | `PROGRAMMATIC` 測試；只涵蓋 router 層，Skill 層的 `!` 規則不在本情境判定 |
| SC-09 | 主軸逐層收斂 | 使用者依序說「寫情詩」「青春的」「學生時代的暗戀」 | 鏈＝愛情 ⊃ 青春的愛情 ⊃ 學生時代的暗戀；每次收斂記一行原因且確認者為使用者；焦點為最深一層 | AI 在使用者未說明時自行收斂；鏈出現未經確認的節點 | A、B | Track A 演練後 `SIMULATED_PASS`（現為 `NOT_EXECUTED`） |
| SC-10 | 偏離處置 | 焦點為「學生時代的暗戀」，請求「寫戰亂中的離別」 | 標 DRIFT，先問「新支線還是換主軸？」，確認前不生成 | 直接生成；或默默改鏈 | A、B | 同上 |
| SC-11 | 主軸檢查負例 | 壞檔：虛構節點、不存在的 § 指標、規範性用語；專案主軸的確認者為 AI、焦點≠最深層、缺非目標 | `axis_lint.py` 退出碼 1；好檔退出碼 0 | 壞檔通過 | B | `PROGRAM_EXECUTED_PASS`（R4L-S0e 已跑，限所列案例） |

### 3B.9 未驗證項

| ID | 事項 |
|----|------|
| U01 | 並行覆寫、聊天路徑無攔截、外部候選晉升、度量反向誘因四項屬設計層推論，未對照執行結果 |
| U02 | 呼叫者判斷來自名稱 grep，不是完整呼叫圖（動態呼叫、別名未涵蓋）；I09 至 I13 與 §1B 同 |
| U03 | `briefs/` 與 `state/` 是否落在 `RESEARCH_ARTIFACTS`、`CANONICAL_STATE` 寫入目標：repo 內只找到 `RESEARCH_ARTIFACTS` 作為角色登記與測試中的標籤，未找到「寫入目標→路徑」對映；R4L-S1 開工前核對 |
| U04 | `capability_registry.json` 的 23 筆能力是否足以覆蓋館員流程（R2b 確認） |
| U05 | `knowledge_intake`、`research_source_normalization` 與外部候選狀態的對接 |
| U06 | 附錄 B、B2 的外部資料取自搜尋片段，未回查原文 |
| U07 | 完整測試套件未執行；24 個基線失敗檔狀態沿用 R1-S1 |
| U08 | OD3 的實作點屬設計：`REQUEUE` 受同一上限約束、以 `work_id` 計連續失敗、未登記失敗類型視為終止類，皆未動態驗證 |
| U09 | `decide()` 現況只在等級 ≥ 3 時回 `auto_recovery_allowed=False`，OD3 要求等級 2 即停止自動重試；轉接函式須補這一差；`test_raw_github_run_shape_is_sufficient`（level 1 對 2）待 R1-S2 裁決 |
| U10 | `briefs/` 在 R4R-S2 前未宣告於生命週期政策，`lifecycle_sweep` 可能視為未宣告項（推論，未執行） |
| U11 | 降級讀集的 19,683 B 是算術，不是 `precheck [startup]` 輸出；Current 的 HOT 摘要與讀取包裝目前無實測值 |
| U12 | Skill 與 Activation Interface §1.3 兩處指令清單的一致性檢查尚不存在，「`！幫助` 列得出 `！備料`」目前只是設計 |
| U13 | `protected_paths` 的內容與 `change_scope_policy.json` 現有門檻是否適用寫入保護尚待使用者確認；該政策檔在聊天模式沒有執行者；GitHub 分支保護（需 code owner 審查）的啟用狀態未知 |
| U14 | 「確認前零寫入」是設計：`brain_proposal` 是否有承載目標確認引用的欄位未核對；澄清事件類型尚未實作 |
| U15 | 任務分級的承載欄位（`brain_proposal` 的 `problem_class`、`route_mode` 或新欄位）未核對；Gate 的下限規則未實作；三級的成本差異未量測 |
| U16 | 主軸文檔納入 Brain 啟動讀集：2,834 B 對 Brief 模式餘量 701 B（算術，無 `precheck [startup]` 實測）；需以主軸取代 Skill 內重複段落或只讀核心樹；Skill 內可被取代的段落未查（UNKNOWN） |
| U17 | 「是否圍繞主軸」的語意判斷在 Track A 只靠 AI 自律，漂移研究指出單靠提示脆弱；距離三級的邊界案例與誤報率未實測 |
| U18 | `intent_handoff.schema.json` 無非目標與主軸欄位；是否需要新欄位待 R3／F28 更新交易，Track A 以 `AXIS.md` 承載 |

### 3B.10 澄清紀錄與寫入保護

**澄清紀錄（R4-M4）：**
- 事件：`CLARIFICATION_ASKED`（`request_id`、觸發原因、選項 id 與標籤）、`CLARIFICATION_RESOLVED`（所選 `option_id` 或「其他」、被否定的解釋 id、是否略過）。只存 id、標籤與選擇，全文對話不入紀錄。事件類型擴充放在 `event_log`，與 `BRIEF_DELIVERED`、`DIALOGUE_TURN` 同一擴充點。
- 統計（由事件重算）：先澄清率、過度澄清率（目標清楚仍提問）、澄清後改向率（所選與 Brain 首選不同）、歧義型態重複次數。同一型態重複達 N 次（N 在 R9 以數據定）成為候選規則，進 R9-S3 的蒸餾流程（藍圖 Evolution 職權）；一次性選項與對話不入長期記憶。
- Track A：任務結果封包附一行澄清摘要（提問數、所選、是否改向、是否略過），證據級 `AI_ATTESTED`；R9-S2 的模糊請求題集取得獨立量測。

**寫入保護（防亂改；R5-S1-M2 的 `edit` 與 Track A 的寫入共用）：**
1. **寫入前三項前置，缺一項即停止並回 Brain：**
   - ① 目標已確認：引用 `CONFIRMED` 的目標；直接明確的要求由 Brain 標為 `CONFIRMED`，經澄清者引用 `CLARIFICATION_RESOLVED`。
   - ② 變更預覽：列出將改的檔、動作（新增／修改／刪除）、預估差異行數，對照 `write_scope`。檔數與行數沿用 `change_scope_policy.json` 的 green／amber／red 門檻；amber 需使用者確認，red 需拆分或明確授權。
   - ③ 回復點：記錄 `base_commit`；Track A 在新分支上提交，Track B 在隔離的 worktree 或以 commit 前雜湊清單保存。
2. **受保護清單：** 在既有 `change_scope_policy.json` 增 `protected_paths`（至少含 `canonical/`、`schemas/`、`P1-CURRENT.json`、已封存的藍圖）；落在清單內的寫入需使用者明確授權，並記錄授權事件（路徑、授權引用）。清單內容在 R5-S1 開工前由使用者確認。
3. **事後核對：** Verifier 比對實際差異與預覽；出現預覽外的檔或超出門檻即 FAIL，依回復點還原。
4. **適用範圍與授權：** 範圍是工作成果（程式、文件、政策、schema）；`briefs/`（`EPHEMERAL`）、交接檔與 zip、event log 與 trace 由各自的寫入目標與角色權限管理，不經變更預覽。批次卡列出的產物視為使用者對該場次的預先授權（授權事件記批次 ID，含 amber 門檻）；red 仍需拆分或明確授權；卡片外的受保護路徑寫入另行授權。經專案更新交易（`blueprint_update_transaction`、`current_projection_sync`）寫入者，以該交易自身的授權與核對為準，仍記回復點。
5. **強制層級：** Track B 由 Gate 對缺前置或碰受保護路徑的 `edit` 回 BLOCK（`PROGRAMMATIC`）。Track A 由 AI 遵守前置（`POLICY_ONLY`）；平台層的強制點是 GitHub：主線經分支與 PR 合併，`CODEOWNERS` 已把 `/P1-Central-Control/`、`/docs/architecture/`、`/P1-CURRENT.json` 指給 owner。分支保護是否已啟用「需 code owner 審查」，由使用者在 GitHub 設定並確認（本計畫尚未驗證）。

### 3B.11 任務分級（輕量／標準／深度）

分級是 Brain 的任務路由選擇加 Gate 的確定性下限，沿用 Skill 的 ANSWER／RESEARCH／ANALYZE／PLAN／IMPLEMENT／VERIFY／CLARIFY／BLOCK 路由與 `brain_mode_controller`；新增 0 個狀態、模式或角色。

| 級 | 適用 | 讀集 | 流程 |
|----|------|------|------|
| 輕量 | 簡單問答、明確指令、低風險、不寫入 | 降級讀集（Skill＋Current 的 HOT 摘要，§3B.3）；不建 Brief | Brain 直接回答或執行；啟動完整的 Brain → Build → 驗收流程屬標準以上 |
| 標準 | 一般研究、規劃、中等複雜度；有檔案修改 | Brief（依路由的必要槽擷取 ACTIVE 資料） | Brain 建任務 Brief 範圍；需修改檔案時才進 Build，按風險與驗收要求做必要檢查；寫入受 §3B.10 保護 |
| 深度 | 複雜工程、重大決策、深度研究、高風險 | Brief＋按需補查 | 完整研究、跨角色、介面契約、失敗恢復、閉環驗收；需要並行探索的問題才考慮真正獨立的子代理（成本高：需 Cost Gate 放行，屬 Track B；Track A 以依序的獨立會話替代） |

- **定級：** 由 Brain 提出。Gate 以確定性訊號設下限：有寫入→至少標準；寫入 `protected_paths`、跨系統寫入、無法回復的操作、授權變更→深度。Brain 可往上提；低於下限的提案由 Gate 退回並要求重提。
- **與澄清的順序：** 歧義會改變結果時先澄清（§3B.10、R4-M4）再定級；輕量任務中途發現需要寫入，升級並補齊寫入前置。
- **成本量測：** R9-S2 量輕量任務的讀集位元組與步數相對標準流程的下降（V11）。

### 3B.12 主軸文檔與討論主軸（F24 擴充；2026-10-13 使用者授權採用）

兩種用途，同一種格式：**系統主軸**（`docs/architecture/P2-Axis-v0.1.md`，慢變，索引 P2 自身的核心架構）與**專案主軸**（每個新方案一份 `AXIS.md`，隨討論逐層收斂）。兩者是索引，只記「是什麼、怎麼連、去哪讀」，不是施工準則（藍圖 §2 對索引與 README 的既有規定）；新增 0 個狀態、模式或角色。外部借鏡見附錄 B3。

**系統主軸：**
- 固定四塊：一句話、樹（≤ 3 層，節點名稱為藍圖標題原文）、怎麼連、不在此文件；≤ 4,096 B（現 2,834 B）。數字、門檻、不變式留在藍圖，狀態留在 Current；以描述句寫成，避開規範性用語。
- 讀取：`tools/pack_handoff.py` 每場把它的一句話、樹、怎麼連帶入交接檔第 2 章（單一來源，交接檔內是生成檢視），開工不增加工具呼叫。
- 同步：`tools/axis_lint.py` 檢查大小、樹深度、節點名稱、§指標、用語、引用檔名；`pack_handoff.py --batch` 以它為閘門。藍圖改版後 lint 轉 FAIL＝主軸需同步（R3-S1b 同批處理）。

**專案主軸 `AXIS.md`（≤ 3,072 B）由六塊組成：** 一句話目標；`焦點：` 一行（＝主軸鏈最深一層）；主軸鏈（縮排樹，例：愛情 → 青春的愛情 → 學生時代的暗戀）；支線（每條一句，註明如何服務焦點）；非目標（界外清單）；修改紀錄（表：版本｜類型｜確認者｜原因）。只存鏈與每次修改的一行原因，不存對話。`python3 tools/axis_lint.py --project AXIS.md` 檢查：焦點＝鏈最深一層、有非目標、紀錄類型合法且確認者為使用者。

| 修正類型 | 定義 | 處理 |
|---|---|---|
| 收斂 | 新焦點是目前焦點的子類 | AI 可提議；使用者明說或確認後生效；記一行原因 |
| 轉向 | 新焦點落在上層之外 | 先問「這是換主軸嗎？」；確認後在紀錄保留舊鏈 |
| 擴張 | 往上放寬範圍 | 使用者確認後生效 |

**偏離判斷（距離三級）：** 在焦點內＝放行；在上層但不在焦點內＝標註後放行，或問一句；界外或命中非目標＝標 DRIFT，先問「這是新支線還是換主軸？」再生成。使用者自己岔題時只提醒，不阻擋。

**行為規則：** ① AI 只提議收斂，使用者確認才生效（主軸本身不被 AI 悄悄帶偏）；② 每條支線能回答「如何服務焦點」；③ 每次生成前把「鏈＋焦點＋非目標」壓成 1–2 行貼近生成處（Author's Note 式；Track A 是自律步驟）；④ 不確定時問，不硬擋。

**承載：** Track A 以 `AXIS.md` 檔承載；`intent_handoff.schema.json` 無非目標欄位（觀察），schema 受指紋綁定，本批不改（U18）；Brief.state 只放焦點一行與鏈的指標。驗收：SC-09–SC-11。


---

## 4. 梯次與批次總覽

| 梯次 | 批次 | 目標 | 場次（每場一個新對話） | 驗證方式 |
|------|------|------|------------------------|----------|
| **1 整理與收斂** | R0 | 穩定化、清理、接力機制 | 已完成 | 快速檢查 |
| | R1 | 依歸因表修補 24 個失敗檔 | S1 歸因／S2 真缺陷＋修補測試／S3 宣告與預算／S4 雜湊 | 快速檢查＋待驗證清單 |
| | R2 | 瘦身分流與文件蒸餾（僅文件） | S1 原則∥S2 功能∥S3 文件處置 | 快速檢查 |
| | R3 | 藍圖 v4.0、封存、達成預算 | S1 藍圖／S2 封存搬移／S3 Current 同步 | 快速檢查（每次搬移後） |
| **2 接腦與閉環** | R4L-S0 | 介面契約與決策表（DOC_ONLY；排在 R4 之前；結論整合於 §3B） | 單場 | 快速檢查 |
| | R4 | Brain Provider（真模型介面＋替身＋Cost Gate） | 單場 | 模擬運行 |
| | R4L | 館員與 Brain Brief（雙軌；含三層投影、卡片優先載入） | S1 契約與索引／S2 館員／S3 情境與切換 | 模擬運行 |
| | R4R | 功能復原（ADR、隔離區與留存、交接基線、收尾鏈、對話記錄） | 場次順序 S2 → S3 → S1 → S4 | 模擬運行 |
| | R4T | 工具支撐能力（DEFER，有消費者才啟動） | 單場 | 模擬運行 |
| | R5 | 薄迴圈＋Gate 接線，完成端到端閉環 | S1 迴圈與工具／S2 模擬情境與閉環 | 模擬運行 |
| **3 路徑蒸餾與知識** | R6 | 路徑蒸餾：機械流程改由代碼執行 | S1 路徑盤點／S2 fast path 與回放 | 模擬回放 |
| | R7 | 重建證明、知識生命週期、Active/Archive | S1 重建／S2 續跑與生命週期 | 模擬運行 |
| | R8 | Hands 轉接契約（替身） | 單場 | 模擬運行 |
| **4 統一實測與驗收** | R9 | 一次完整測試、評測、治理、最終驗收 | S1 全測試與修綠（預留 2 場）／S2 評測與真模型抽樣／S3 失敗驅動治理／S4 清冊驗收與定位文件 | 完整測試套件＋評測 |

可平行：R2 的三場；R7 與 R8。其餘串行；R4L-S0 在 R4 之前（DOC_ONLY）；R4L、R4R 在 R4 之後、R5 之前（R4R 在 R4L 之後）。前置依賴：R1-S2（`new_ids`、debug 測試裁決）→ R1-S4（雜湊）→ R3 → R4L-S3 的藍圖更新交易。

**旁支（執行者接口 XM）：** XM0 已完成（LISTED，範圍縮小）；見 §5 的 XM 卡與 `11-XM0` 矩陣；XM1 為 SHOULD，不佔梯次。

**旁支（優化軸 OB）：** 不佔梯次；OB5-1／2／3 為小型程式批次、OB4／OB6 已裁決不另立，分批與閘門見 `docs/research/P2-OPT-REF/10-優化企劃定稿.md`。

---

## 5. 批次卡

> 格式：目標／讀取／任務（M＝MUST、S＝SHOULD、C＝COULD）／驗收／停止條件。假說只是起點，不是已確認根因。

### R1 依歸因表修補（梯次 1；快速檢查）
**承接清冊：** V5
**目標：** 24 個失敗檔都有歸因與修補；真缺陷修好；修補全數登記到「待驗證清單」，等梯次 4 成批驗證。
**起點事實：** 交接檔附 24 檔首個錯誤表（R0 實測）。其中 7 檔屬雜湊／宣告漂移型（`content_hash 不正確`、`BLUEPRINT_INVALID:content_hash`、計數 4≠3、Current 17,923 B > 12,000 B）；4 檔對應未驗證修補所附新測試（`quality_metrics`←018、`regression_executor`←017/019、`progressive_repository_scanner`←016、`system_independence_repository_gate`←002/014）；`blueprint_update_transaction` 有 `UnboundLocalError: new_ids` 真缺陷；`debug_escalation_policy` 回報「Ran 0 tests」但 loader 載入可得 7 個。缺 `.git` 已排除為原因。
**假說（HYPOTHESIS）：** H-A 雜湊漂移；H-B 宣告與現實漂移；H-C 真程式缺陷；H-D 未驗證修補或其新測試本身有誤（`OPEN-ISSUES.md` §1）。判斷方式：用專案雜湊函式重算；讀測試與被測函式，看哪一邊偏離修補意圖。
- **S1 歸因（讀 ≤ 25 KB）：** M1 依交接檔首錯表，把 24 檔分到 A／B／C／D，寫成歸因表（檔｜類別｜判斷依據｜預定修補）。M2 H-A 類用專案雜湊函式重算，判定「只差雜湊」或「內容被改壞」。S3 釐清 `debug_escalation_policy` 的 0 tests。
- **S2 真缺陷與修補測試：** M1 修 `new_ids`。M2 修 `system_independence_repository_gate` 的 unpack。M3 H-D 四檔逐一裁決：程式偏離意圖就修程式；程式符合意圖而測試用舊期望就修測試，理由寫進交接檔。
- **S3 宣告追上現實：** M1 `test_current_projection_sync` 計數 3→4，並連動 `run_p2_validation.EXPECTED_TEST_COUNTS`。M2 `P1-CURRENT.json` 超預算：把可移出的歷史欄位移出常駐位置（必須調高預算時寫理由）；降級讀集（Skill＋Current 的 HOT 摘要）的位元組目標見 §3B.3，移出時一併考慮。M3 `feature_batch_orchestrator`、`brain_mode_runtime_interface`（`BATCH_FILE_MISSING`）、`construction_progress_watchdog`（6 項）。**M4（FR-11、D18）** `tools/wiring_audit.py`：把 R1-S1 手動做的接線核對腳本化，由非測試 import、入口引用與測試狀態推導每個能力的 implementation；統計、聚類、趨勢、週期、異常等無工具的能力改標 `DECLARED_NO_TOOL`；`precheck [wiring]` 先為 WARN。輸出每項能力的五欄位：提供者、消費者、可用模式、成功條件、失敗回饋（查無依據標 `UNKNOWN`，不補猜）。
- **S4 雜湊：** S1 H-A 以專案工具重生雜湊，或還原被改壞的內容。
**驗收：** `precheck` 快速檢查 PASS；歸因表 24 列齊全；每個修補都在「待驗證清單」有一行（檔案＋要跑的測試）。
**停止：** 某組試 2 次仍未解 → BLOCKER，換下一組。
- **S4 補記（R1-S3h）：** 設計判定雜湊重封不受展開設計影響：只重封、不改藍圖內容；重封後重跑 `python3 tools/expansion_probe.py`（Open-Items OI-11）。本批不動展開設計。

### R1-SX 展開缺口設計場（插入；2026-10-13 使用者確認先於 R1-S4；排在 R1-S3h）
**缺陷（使用者提出，觀察已核對）：** 系統能拆解、歸納、濃縮，但沒有「由濃縮結果反向展開」與「統一骨架先行」。`reconstruction.py` 的 Clean Build 是複製現有元件加跑測試；Blueprint 宣告元件與歸屬並記雜湊，不是可展開的規格；`reverse_reconstruction.py` 為 68 行相容入口。後果：建構缺全局骨架，產物零碎（類比生圖未先定版面）。HYPOTHESIS：只讀檔頭與函式名，細節未逐行核對。
**外部借鏡（2026-10-13 搜尋，轉述）：** 先規劃版面再生成（LayoutLLM-T2I、PlanGen）；規格→重建→等價檢查，失敗歸因為規格不準／規格含糊／重建能力不足並以反例修規格（SpecLoop）；『抽象後重生』：自然語言抽象的往返最佳僅約 23%，可執行程式碼抽象約 52%（RTL-BenchLS，2026-10-13 已讀全文）；「73.6%」與其他轉述數字在該論文查無，不採用。
**設計方向：** 種子（小而可執行的規格：不變式、介面、依賴圖、展開規則）→ 先凍結骨架 → 由粗到細展開（下層只能在骨架內填）→ 與原件比對得殘差 → 殘差歸因後修種子而非修產物；殘差在容限內才算『公式成立』。展開器分兩層：決定性模板展開為基線（離線、可測），LLM 補細節為選配（Track B，D17）。還原級別先定：結構／介面／行為。
- **MUST：** S1 種子最小格式、骨架凍結規則、還原級別與殘差度量。S2 決定性展開器規格與 LLM 選配層邊界。S3 殘差三類歸因與回饋流程。S4 與現有 reconstruction gate、Brain／Central／Factory、R3 藍圖 v4.0 的接點；判定 R1-S4 重封雜湊是否受影響。
- **SHOULD：** 選一個小子系統手動展開一次並量殘差（候選：capability_registry→提供者骨架；P1-CURRENT 投影）；結果標證據等級，模擬不得標為實跑。
- **驗收：** 設計文件 ≤ 12 KB；0 新狀態、0 新角色（沿用 §3B 介面契約）；試點有殘差數字；R1-S4 處置寫入決定。
**停止：** 同一問題試 2 次未解 → BLOCKER。
- **狀態（R1-S3h，DONE，2026-10-13）：** 已交付三份設計文件（`docs/architecture/P2-Expansion-Design／Checks／External-Review-v0.1.md`）與 `tools/expansion_probe.py`。上方設計方向已修正：種子用於**推導**（法則＋情境→新內容），還原只是校準；驗收三道（擬合、推廣、容許）；歸因改為 D／E／S；上列「73.6%」仍未回查，不作依據。**未完項與補法的唯一清單：`P2-Expansion-Open-Items-v0.1.md`。**

### R2 瘦身分流與文件蒸餾（梯次 1；僅文件）
**承接清冊：** 為 V1、V5 備料。三場互相獨立，沒有執行環境也能做；程式維持原樣。
- **R2a 原則分流（讀 ≤ 40 KB）：** 用 `slice.py --heading "## 3."` 分兩次讀藍圖 §3。M 為每條原則填 `ID｜一句話｜現有強制機制（測試／閘門／無）｜KEEP-ENFORCED／KEEP-PRINCIPLE（≤1 行）／MERGE／DELETE`；S 標出互相重複者。另把藍圖現有 11 個 `####` 小節（如「使用者意圖理解與最小化澄清」「思考環境與施工環境的邊界」）逐一判定 KEEP／MERGE／DELETE 並附理由，DELETE 項交使用者確認。輸出 `docs/plans/P2-Invariant-Triage.md`（待建，≤ 8 KB）。
- **R2b 功能分流：** 讀 `P2-Implementation-Evidence-Matrix-v1.0.md`（33 KB）＋ `capability_registry.json`（9 KB）。M 將 F01–F30 分為 CORE（≤ 8）／DEFER／ARCHIVE，附對應腳本與測試檔；CORE 候選：模式控制器、Brain 提案介面、意圖理解與澄清（`intent_resolution`〔P2-F24〕與 R4-M4）、Central 狀態轉移與 Gate、event log／trace、Verifier／驗收、knowledge_canon 最小子集、continuation box、Operational Pack。S 估算 ARCHIVE 可移除的腳本位元組。輸出 `docs/plans/P2-Feature-Triage.md`（待建，≤ 10 KB）。 另把 §1B 的 FR-01 至 FR-14 併入分流：每項標 RESTORE／MERGE／RETIRE 並附判定依據（找書面裁定），確認 CORE 清單包含承載模組（`event_log`、`lifecycle_sweep`、continuation box、`planner_library`、`role_command_router`）。
- **R2c 文件與資料處置（讀 ≤ 40 KB）：** 對**附錄 A** 每一列，用 ≤ 5 行把仍有效的結論寫進「蒸餾稿」（附在 R2a／R2b 輸出末尾，不另開檔），確認最終處置（KEEP／DISTILL→藍圖／ARCHIVE／DELETE）。資料列（evidence、fixtures、examples、progress）逐一確認「被誰引用」。
**驗收：** 兩檔存在、列數完整（原則數／30 項）、每個 CORE 標明現有測試檔；附錄 A 每列都有最終處置。

### R3 藍圖 v4.0、封存、達成預算（梯次 1；快速檢查）
**承接清冊：** V1、V5
**讀：** 兩份 Triage、藍圖 §1–§2（≤ 12 KB）、本文件 §0–§3。
- **S1 藍圖改寫：** M 以同一路徑把唯一藍圖改寫為 v4.0（**≤ 24 KB**）：目的、權威分工、KEEP 的原則（每條 ≤ 2 行，註明強制機制）、「使用者意圖理解與最小化澄清」整節保留（≤ 8 行，含「幫我優化」示例與寫入前確認規則）、4.0 架構（§0 圖）、批次路線指向本文件。「思考環境」一節以一句話寫入 D12–D14，細節指向 R4L。規則句用「做什麼」的正向語句，由代碼閘門承擔強制。舊版全文移到 `docs/archive/`，標「封存、非權威」。
- **S1b 主軸同步：** M 同批把 `docs/architecture/P2-Axis-v0.1.md` 的節點與 § 指標對齊 v4.0，`python3 tools/axis_lint.py` PASS；藍圖 §2 責任表登記主軸索引；附錄 A 對 `P1-Architecture-Spine` 的判定以「有效部分已由主軸承接」為據。見 §3B.12。
- **S2 封存搬移：** M 依 Triage 把 ARCHIVE 類腳本與測試移到 `P1-Central-Control/archive/`（`git mv` 風格；相依者先處理；每次搬移後跑快速檢查；附還原清單）。M 附錄 A 中處置為 DELETE／DISTILL 的文件與資料，在內容進入藍圖後刪除（含 `參考資料/`），並移除 precheck 的 `LEGACY_RUN_ALLOWED`。S 決定 `.agents/skills/p2-brain/` 的去留（`lifecycle_sweep` 目前把它列為未宣告項）；S 封存與已封存 Actions 相關的 `.github/workflows`（R3d9 判定：`p2-brain` 保留並改指唯一指令表；8 個 workflow 皆只手動觸發、只指向現行路徑，維持現狀；`tools/workflow_audit.py` 在 precheck 以 HARD 執行）。
- **S3 Current 同步與預算：** M 用專案既有更新交易同步 `P1-CURRENT.json` 的藍圖指標與版本；README 投影以 `current_projection_sync` 重生。M 達成 `repo_budget.json` 既有上限（docs ≤ 148,000 B、progress ≤ 13,500 B、scripts ≤ 943,000 B、tests ≤ 696,000 B、全 repo ≤ 2,354,000 B）；做不到的項目逐項寫明實測值與調高理由。C 把 `precheck [refs]` 升為棘輪（懸空引用只會變少）。
**驗收：** 快速檢查 PASS（含 hygiene）；藍圖 ≤ 24,576 B；舊藍圖 11 個 `####` 小節各有判定且 DELETE 項已經使用者確認；`grep -c ARCHITECTURE_INVARIANT` ＝ Triage 的 KEEP-ENFORCED 數；每條 KEEP-ENFORCED 指向一個測試；`[refs]` 懸空數 ＝ 0 或每項有理由；`[style]` 否定式用語數相對 R0 下降。
- **S4 展開種子（來自 R1-S3h；見 Open-Items OI-1、3、4、7、8、14）：** M 把 `dependency_graph`、`expansion_rules`、`residual_policy`、`context_schema` 放進藍圖體系（預設：作為 `canonical/blueprint.json` 的可選欄位並在 `blueprint.schema.json` 補宣告；24 KB 上限指敘述性的唯一藍圖，不是這個 JSON）；每元件宣告目標還原級別與容限；成熟度不另加 registry 欄位，由 `tools/wiring_audit.py` 推導（D-R2c-D18、D-R3a-ACT；OI-7 已裁決）。**驗收：** 藍圖 JSON 通過 schema、reconstruction 閘門 PASS；敘述藍圖仍 ≤ 24,576 B；每元件有一行級別與容限；`expansion_probe.py` 仍可執行。



**R3d10 完成（R3e、S4、R3g）：** `[refs]` 為 HARD 棘輪（`tools/baseline_refs.txt`，現為空）；`tools/pointer_audit.py` 核對 Current／README／藍圖版本與路徑（README 的「v2.7」三處已改 v4.0），進 precheck HARD。展開種子 5 欄（`dependency_graph`、`expansion_rules`、`residual_policy`、`law_meta`、`context_schema`）已寫入 `canonical/blueprint.json`，`blueprint.schema.json` 補宣告（皆可選），`tools/seed_audit.py`（SD1–SD6＋11 個負例）進 precheck HARD，reconstruction 閘門 PASS。R3g：`tools/batch_gate.py`、`tools/assurance_audit.py`、`tools/wiring_chain_audit.py` 與 `policy/batch_acceptance.v1.0.json` 把 D19、019c、020c 變成可執行檢查。

### R4 Brain Provider（梯次 2；模擬運行）
**承接清冊：** V6、V7、V10
**讀：** `scripts/brain_input.py`、`brain_proposal.py`、`brain_mode_controller.py`（各 ≤ 12 KB 切片）、`schemas/brain_proposal.schema.json`、`brain_input_packet.schema.json`。
- **M1** `scripts/brain_provider.py`：`propose(task_frame) -> BrainProposal`（沿用既有 schema）；三實作：`FileProvider`（現有替身格式）、`ScriptedProvider`（確定性、離線）、`ModelProvider`（Messages API，標準庫 `urllib`，結構化輸出用 tool-use JSON schema；金鑰從環境變數讀取）。
- **M2** `CostGate` 預設 BLOCK：`cost_gate.json` 明列「已核實的免費餘額、單次上限、超額停止行為」才放行，任一項缺少就維持 BLOCK。
- **M3** `intent_resolution.py` 降為備援：Provider 可用時先走 Provider，輸出經既有驗證。備援現有的固定三選項不含「其他」入口，也不依上下文產生，與藍圖「根據上下文產生選項」不符；備援補上「其他」入口，只在 Provider 失效時使用。
- **M4** 最小澄清（藍圖「使用者意圖理解與最小化澄清」；由 S 上調為 M）：Brain 先唯讀讀取現況，再依「不同解釋是否改變範圍、結果、風險或授權」選一個動作：直接做、明示假設、2–4 個情境化選項（互斥，含「其他」）、單一澄清問題。歧義會改變結果時，目標確認前不寫入任何檔案（寫入類工具由 Gate 擋下，對應 R5-S1-M2）。選項由 Brain 依上下文產生，沿用 `clarification_options` 欄位；有按鈕介面就用按鈕，沒有就退回純文字選項。每輪 ≤ 4 題、每題一個決策點；低風險且上下文支持單一解釋時，允許明示假設後繼續；使用者確認的部分才標 CONFIRMED。澄清紀錄與統計見 §3B.10。
- **S5** 任務分級（§3B.11）：Brain 在提案中標示輕量／標準／深度，Gate 以確定性訊號設下限。
- **S6** 專案主軸（§3B.12）：Brain 在新方案開始時建立 `AXIS.md`；F24 輸出加主軸鏈、支線、非目標；收斂由 AI 提議、使用者確認；`axis_lint.py --project` 檢查；驗收 SC-09、SC-10。
- **S7 Brain 最小循環（A11 蒸餾；`brain_provider.propose` 的輸出契約）：** 一次重要任務依序產生六項：讀 Current 後的現況；正規化意圖（目標、輸出、範圍、限制、成功與停止條件、授權）；問題模型（觀察事實／來源支持的主張／推論假設／UNKNOWN／CONFLICT／阻塞／風險；沒查到不等於不存在）；方法與模式選擇（至少比較直接處理、局部修正、架構修正、延後、停止；硬限制、安全、正確性先於成本與速度）；變更分類（`ONE_OFF`／`LOCAL_RULE`／`SYSTEMIC_CAPABILITY`／`ARCHITECTURE_INVARIANT`）加主責職權；反例挑戰（重要缺口未解就輸出 BLOCKED／INCOMPLETE，不繼續施工）。**程式化（D19）：** `brain_provider` 以固定欄位檢查器驗證六項齊全，缺項退回；`brain_proposal` schema 已有 `problem_class`、`epistemic_state`、`decision_code`，其餘欄位放 `task_frame` 的 `brain_cycle` 區塊，不改鎖定的 `schemas/`。**驗收：** 缺一項被退回、BLOCKED 時無任何寫入各一個負例；證據 `SIMULATED_PASS`。`tools/brain_guard.py`（R3d9）已實作六項欄位檢查器與負例並在 precheck 以 HARD 執行；R4 把它接進 `brain_provider`，證據升為 `PROGRAM_EXECUTED_PASS`。
**驗收：** 模擬運行：`ScriptedProvider` 走完全路徑；`ModelProvider` 以假 HTTP 層驗證請求格式、金鑰缺失、Cost Gate BLOCK 三種情況。CI 內的 Provider 全為替身。澄清情境：「幫我優化」→ 產生 ≥ 2 個依上下文的選項（含「其他」），確認前無任何寫入；目標清楚的要求直接執行、不被詢問；澄清事件寫入 event log，先澄清率與過度澄清率可由事件重算。證據層級 `SIMULATED_PASS`。

**D19 驗收（R3g；`python3 tools/batch_gate.py` 機械判定，precheck HARD）：** 任務 DONE ＝ 入口檔存在，且 `batch_gate record <任務ID> --entry <檔> --command <指令>` 寫入 exit_code 0 的證據，入口檔雜湊與紀錄一致（改檔後重跑）；批次 DONE ＝ 全部 M 任務 DONE、S／C 任務 DONE 或附理由 SKIPPED。登記表：`policy/batch_acceptance.v1.0.json`。純文件不構成梯次 2 的完成。 R4 入口：`python3 scripts/brain_provider.py --simulate`；S7 把 `tools/brain_guard.py` 接進 `brain_provider` 後，證據升為 `PROGRAM_EXECUTED_PASS`。020c：R4 結束時 `CH-PLAN-TASK-COMMAND`、`CH-KNOWLEDGE-BRAIN` 至少 `WIRED_STATIC`（`tools/wiring_chain_audit.py`）。

### R4L 館員與 Brain Brief（梯次 2；模擬運行）
**承接清冊：** V16；承載 FR-01、FR-09、FR-13、FR-14（§1B）。依使用者 2026-10-12 的指示直接寫入本企劃；內容屬梯次 2 的新功能，另含一組規則文字（Skill 與啟動接口的啟動段、`！備料` 指令），規則文字於 R4L-S3 以一次藍圖更新交易提交（`R4L-S3-M3b`）。
**問題：** `brain_input_packet` 只含 enum／id／ref，沒有任何一步把 `semantic_refs`、`evidence_refs` 展開成蒸餾內容；Brain Skill 與啟動接口因此要求大腦自己讀 Current、Active Work、Active Construction 與藍圖全文（約 300 KB）。v2.2 §46 的三層投影與 §56 的能力命名空間預算正是為此而設，現已不在 repo。
**雙軌（D17）：**
- **Track A（最低標準：AI 對話＋GitHub）：** 館員是角色會話，由 `！備料` 開啟；依 `brief_slots.json` 的槽位清單讀 GitHub 上的來源，逐字摘錄並記 commit＋path＋行號（Track A 不宣稱已算雜湊），寫成 Brief 後提交到 `briefs/<brief_session_id>.json`；`brief_session_id` 由 `！備料` 會話在開始時自行產生。品質由「讀回驗證」把關：抽樣 3 個槽，重新讀取來源的行範圍，比對逐字摘錄與實際文字，結果寫在 `provenance.readback`。
- **Track B（有執行環境）：** `scripts/librarian.py` 做同樣的事，速度快且可重現；輸出與 Track A 相同，同一個讀回驗證可檢查兩軌；Track B 另補算 sha256 與 `content_hash`。
**設計：**
- **每個 session 一個覆寫檔** `P1-Central-Control/briefs/<brief_session_id>.json`（≤ 8 KB；不放 `state/`；最小資料原則與清理規則見 §3B.3）：`state`（HOT 摘錄：只取該路由列出的 Current 欄位，含模式、Active Work 簡報、主要阻塞、下一步；≤ 3 KB；Current 仍是唯一真值）、`recent[]`（ACTIVE：近期 checkpoint／result／event 的 ref，不放內容）、`decisions[]`（只載 accepted 的 ADR，見 R4R）、`slots[]`（卡片優先：capability ID＋摘要＋呼叫契約，另有來源定位〔commit＋path＋行範圍；Track B 加 sha256〕、逐字摘錄、覆蓋狀態）、`coverage`（`grade`＋`gaps[]`）、`external[]`（UNTRUSTED_CANDIDATE）、`omitted_refs[]`、`budget`、`brief_session_id`、`work_id`、`provenance`（`base_commit`、`sources[]`、`readback`）、`lifecycle`、`content_hash`（Track B）。顯示文字由 `render_brief()` 即時產生。
- **三層投影（FR-01）不重建 v2.2 的舊檔：** HISTORICAL 以 `event_log` 的 reducer 為來源，由有界、只讀的歷史查詢函式回答，不存查詢結果；投影是可丟棄的衍生品，由 event log 加快照重建，同一事件集得到位元組相同的結果。函式放在 `librarian.py`（D16）。升降級與找不到資料的規則見 §3B.5。
- **館員步驟（Track B）：** 驗證請求→依 `brief_slots.json`（路由→必要槽）列槽位→以 `function_capability_registry.json`、`capability_registry.json` 為索引，用 `knowledge_retrieval` 定位→依標題或 JSON 路徑逐字擷取並記雜湊→`context_sufficiency` 與槽位覆蓋評級→暫存檔寫完再改名→Reading Ledger 與 event log 各記一筆。沿用 `knowledge_context`（資料通道、預算、省略清單）與 `operational_reference_pack`。
- **角色與指令：** 對應藍圖既有的 Knowledge Acquisition（`ROLE:CONTROL_RESEARCH`）；`！備料` 只在 Skill 層，不改 `canonical/`、不經 `role_command_router`（OD1，細節見 §3B.2）。`！收斂` 保留 Skill 既有定義；館員整併由 `！收斂` 的收尾步驟完成後的收尾流程呼叫。
- **大腦端：** 啟動必讀：有 Brief 且未 STALE ＝ Skill＋Brief；無 Brief 或 STALE ＝ 降級讀集（Skill＋Current 的 HOT 摘要），大腦先判斷資訊是否足夠，足夠就繼續，不足才提示 `！備料`，不退回讀全部（預算見 §3B.3）；任務中需要資料時發 `brief_request`（主題、功能 ID、問題，≤ 5 項）。啟動接口與 Pack 計畫改為按指令才讀。
- **缺口分流（代碼分級）：** SUFFICIENT→進行；PARTIAL→帶缺口進行，或窄化後重請求（≤ 2 輪）；MISSING→大腦派研究任務（`！研究`），結果進下一份 Brief 的 `external`。Brief 內容走資料通道（`instruction_content=False`），規則句只來自已驗收的 `distilled_rules`。
- **過期與回饋：** STALE＝`provenance.sources[]` 內任一來源在 `base_commit` 之後有變動；Brief 檔自身不在 `sources[]`，提交 Brief 不致 STALE；HOT 欄位以欄位指紋比對，不比對 Current 整檔；`base_commit` 只供追溯。STALE 由館員重建，重建失敗進降級讀集。每個任務結束記 `brief_use`（送出槽數、被引用槽數、事後補查次數）；事後補查次數＝Brief 送出（`BRIEF_DELIVERED` 事件）之後的 `INFORMATION_GAP` 提案數，由事件重算，不在 schema 維護計數欄位；遺漏 ≥ 1 時把該 ref 補進 `brief_slots.json`（D5 失敗驅動）。
- **離線整併：** `！收斂` 的收尾步驟完成後，由收尾流程呼叫館員更新 Knowledge 與 Pack 候選，新事實取代舊事實時標失效日期並保留舊紀錄（R7 承接）。
**讀：** `brain_input.py`、`operational_reference_pack.py`、`knowledge_retrieval.py`、`context_sufficiency.py`、`knowledge_context.py`、`event_log.py`、`role_command_router.py`（各 ≤ 12 KB 切片）、`schemas/brain_input_packet.schema.json`、`operational_pack_request.schema.json`；R2b 的 CORE 清單。
- **S1 契約與索引（讀 ≤ 30 KB）：** **M1** `schemas/brain_brief.schema.json`、`brief_request.schema.json`。**M2** `brief_slots.json`：路由 ≥ 4 條（啟動、討論、施工、驗收），各列必要槽；槽到來源的對映取自 R2b 的 CORE 清單與兩份 registry。**M3** `precheck [startup]` 雙模式：以確定性腳本按 UTF-8 實際位元組核算完整讀集（Skill、Current 或 Brief、必要讀取包裝內容），預算與核算規則見 §3B.3；強度：Brief 模式 R4L 完成前為 WARN、完成後為 HARD，降級模式自本任務交付起為 HARD。**M4** Track A 手動流程：`！備料` 的會話指令清單與讀回驗證步驟（≤ 2 KB）；`！備料` 登記到 Skill 官方指令清單與 `docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md` §1.3 指令表（`！幫助` 以該表為準），並以一項檢查比對兩處清單一致。**M5** `role_command_router.resolve()` 入口把 `!` 映射為 `！`（單一位置）並補 `test_role_command_router` 案例；只作用於 router 已登記的 `role.activate` 指令（§3B.2）；兩層清單（Skill 13 條與 `command_shortcuts.json`）的差異以一張對照表消除（`！指導` 只在 registry）。**S5** `render_brief()`。
- **S2 館員：** **M1** `scripts/librarian.py`（含有界歷史查詢與三層投影函式）；在 `event_log` 擴充 `BRIEF_DELIVERED` 事件類型（`make_segment_event` 只收 9 個 `SEGMENT_*`，需擴充清單或建構器；不新增模組）。**M2** `tests/test_librarian.py` ≥ 14 案例：槽位齊全、缺槽、超預算、雜湊不符、STALE、原子覆寫（中途失敗保留舊檔）、資料通道、外部結果標記、同輸入同 `content_hash`、投影重建位元組相同、讀回驗證抓得到被改動的來源；其中「雜湊不符」「同輸入同 `content_hash`」只適用 Track B，Track A 的對應案例是「讀回驗證抓得到被改動的來源」。**M3** `！備料` 會話的 Track B 入口（`librarian.py` 讀 `brief_request`、產生 `brief_session_id`）；指令辨識只在 Skill 層。
- **S3 情境與切換：** **M1** `python3 scripts/librarian.py --simulate`：≥ 12 情境（冷啟動、足量、部分缺口窄化、缺失→研究、STALE、來源內含指令句、超預算、連續兩任務覆寫、Track A 的讀回驗證失敗；另加並行兩會話、STALE 自我指涉〔提交 Brief 不致 STALE〕、ASCII 指令）。ASCII 指令一項屬 Skill 層（`POLICY_ONLY`），由 Track A 乾跑觀察，不由 `--simulate` 判定，也不計為程式化通過。**M2** 以 `precheck [startup]` 量測兩模式的啟動讀集位元組（現況約 300 KB→達到 §3B.3 的兩模式預算）與每任務 Brief 位元組（≤ 8 KB），寫進交接檔。**M3b** 把 Skill 與啟動接口的啟動段改為「讀 Brief／降級讀集」，原清單移到 `brief_slots.json`；`！備料` 規則文字與藍圖的對應規則以一次 `blueprint_update_transaction` 提交（前置：R1-S2-M1 修好 `new_ids`）；Skill 文字並含 §3B.10 的寫入前三項前置與澄清規則（`POLICY_ONLY`）。**S4** `brief_use` 統計腳本；`planner_library` 卡片由槽位載入（FR-13）。
**驗收：** `--simulate` 全部符合預期；`precheck [startup]` 兩模式實測皆在 §3B.3 的預算內；Brief ≤ 8 KB；證據層級 `SIMULATED_PASS`。真實 Brain 會話的端到端試跑留到 R9-S2。
**停止：** `knowledge_retrieval` 或 `context_sufficiency` 的介面對不上時寫轉接層，同一問題試 2 次後記 BLOCKER。Operational Pack 建構器（F25，修補後待重驗）未通過時，館員自帶最小打包，等 R9 驗證後再接 Pack。
- **主軸讀集（§3B.12）：** 啟動讀集納入系統主軸時，以主軸取代 Skill 內重複的架構／參考段落，不疊加（U16）；`precheck [startup]` 納入 `axis_lint.py`；Skill 加一行指向主軸文檔。
- **S-X 展開度量與試點（來自 R1-S3h；見 Open-Items OI-2、5、6、9、10）：** C 在 precheck 加 `[expansion]`（WARN）；M 選一個元件做種子→骨架→展開→三道驗收的端到端試點（並把 `current_projection_sync.render` 寫成第一條展開規則）；推廣道實質試點改用單位 ≥ 10 且答案可機器判定的資料。**驗收：** `[expansion]` 輸出格式符合 Open-Items OI-5；試點報告含擬合／推廣／容許三項殘差與 D／E／S 歸因。

**D19 驗收（R3g；`python3 tools/batch_gate.py` 機械判定，precheck HARD）：** 任務 DONE ＝ 入口檔存在，且 `batch_gate record <任務ID> --entry <檔> --command <指令>` 寫入 exit_code 0 的證據，入口檔雜湊與紀錄一致（改檔後重跑）；批次 DONE ＝ 全部 M 任務 DONE、S／C 任務 DONE 或附理由 SKIPPED。登記表：`policy/batch_acceptance.v1.0.json`。純文件不構成梯次 2 的完成。 R4L 的 Track B 入口須能離線執行；Track A 的手動等價流程 ≤ 10 行另列為文件任務（`doc_only` 僅限梯次 1）。

### R4R 功能復原（梯次 2；模擬運行）
**承接清冊：** V17；承載 FR-02、03、04、05、06、10（§1B）。**前置：** R2b 覆核判定、R3、R4L。**後續：** R5 的迴圈呼叫本批的 `closure_chain` 與對話事件。依 D16，先在既有模組承載。
- **S1 決策紀錄（FR-02）：** **M1** `docs/adr/`：P2 自訂 ADR 格式（參考 MADR；YAML frontmatter：status、decision-makers、supersedes；欄位、狀態轉移、驗證器由 P2 定義）與 0000 起點；補登記至少三則既成事實：M23-P13 Checkpoint Index 決定 REUSE（v2.2 §57）、2026-10-01 模型時代分流、D12–D14 館員與 Brief。**M2** `scripts/architecture_decision.py` 只做驗證：status 生命週期（proposed→accepted→deprecated／superseded）、supersedes 對應、反轉條件必填、懸空連結。**M3** `precheck [adr]`＋≥ 8 測試。**S4** Brief 的 `decisions[]` 只載 accepted 且與範圍相關者；superseded 視為歷史。
- **S2 生命週期（FR-03、FR-04）：** **前置：** 修復 `lifecycle_sweep` 的失敗測試（R1-S1 歸因：宣告為存活的條目與實際檔案不一致）。**M1** `policy/lifecycle.v1.0.json` 增 `data_classes`（七類→處置）與 `quarantine`（觀察期以驗收批次數計，不以日曆）。**M2** `lifecycle_sweep` 讀取並新增 QUARANTINED：移至 `archive/quarantine/<run-id>/` 附 sha256 清單與 restore 指令；進 REMOVED 前入口、registry、workflow、回歸證據須齊備。`EPHEMERAL` 類的清理涵蓋 `briefs/`：已過期的 session 檔清除，活動中的 session 檔不清。**M3** 測試 ≥ 10：隔離後回復位元組相同、證據不全時停在 VERIFIED_UNUSED 之前、`progress/` 超預算時給出分類建議。R3 的檔案搬移先以 `git mv` 加清單執行同一規則。
- **S2 設計定稿（R3d12p；可推翻；外部：Azure／Google Cloud soft delete 官方文件、DataJoint GC 設計討論）：** 業界一致＝隔離（soft delete）→ 寬限期 → 清除，寬限期內可還原，清除前重查引用；隔離狀態直接編碼在儲存佈局，不另建中繼表；生命週期規則不處理已隔離項。P2 取捨：寬限期以驗收批次數計（無常駐執行環境，日曆會在無人 sweep 時空轉）。**銜接既有 `policy/archive_scope.v1.0.json`（已有 dispositions KEEP／ARCHIVE／DISPOSE 與 archive_lifecycle RETAIN→REVIEW→COMPRESS→DELETE）：** `data_classes` 描述「活檔案區域」的處置，disposition＝RETAIN／REVIEW／ARCHIVE／EPHEMERAL；ARCHIVE 交給 `archive_governance.archive_assets`（進入後走 archive_lifecycle），不重造。七類（原文藍圖 §56 不在 repo，UNKNOWN；以下為依 repo 現況自訂）：CANONICAL（canonical／policy／schemas／P1-CURRENT）RETAIN；EVIDENCE（evidence/）RETAIN；HANDOFF_RECORDS（docs/handoffs、docs/adr）RETAIN；PROGRESS（progress/，budget_bytes 13,500；現 284 KB）REVIEW；RESEARCH_REFERENCE（參考資料/、docs/research）REVIEW（review_after 2026-11-08）；ARCHIVE_STORE（docs/archive、archive/）ARCHIVE；SESSION_EPHEMERAL（briefs/）EPHEMERAL。路徑最長前綴比對；未分類回 UNCLASSIFIED 只報告不清。**M1** 政策加 `data_classes`＋`quarantine`{observation_batches:2、unit:ACCEPTED_BATCHES、dir:`P1-Central-Control/archive/quarantine`}。**M2** `lifecycle_sweep` 新函式：`classify_path`、`removal_evidence`（入口、registry、workflow、回歸證據缺項清單）、`quarantine_batch`（僅限既有候選且證據齊；`os.replace` 搬到 `quarantine/<run-id>/files/<原路徑>`，manifest 記 sha256、size、`batches_done_at`、restore 指令）、`restore_batch`（逐檔雜湊比對；原路徑已有檔就拒絕）、`advance_quarantine`（QUARANTINED→觀察滿→重查引用→VERIFIED_UNUSED→REMOVED；重查發現被引用即停並標 REFERENCED_AGAIN）、`sweep_ephemeral`（讀檔內 `expires_at`／`active`；目錄不存在＝無事）、`suggest_budget`（超預算列最大檔與分類建議，只建議不處置）；CLI 加 `--classify／--quarantine／--restore／--advance／--ephemeral／--simulate-quarantine`；候選掃描與可達性排除 quarantine 目錄。**M3** 新測試檔 `tests/test_lifecycle_quarantine.py` ≥ 12（不加進 `EXPECTED_TEST_COUNTS`）：最長前綴、UNCLASSIFIED、隔離搬移與 manifest、回復位元組相同、回復拒絕覆蓋、證據不全不隔離、觀察以批次計、清除前重查擋下、ephemeral 過期清／活動留／目錄缺、超預算建議、sweep 忽略 quarantine；突變：跳過重查、跳過雜湊比對、以日曆計皆須被抓到。入口＝`lifecycle_sweep.py --simulate-quarantine`（暫存迷你 repo 跑 候選→隔離→觀察→還原／清除 閉環，標 SIMULATED_PASS）。估改 4–5 檔；先 slice 讀 `find_candidates`、`delete_batch`、`run_retirement`，不全讀。
- **S3 交接基線與收尾鏈（FR-05、FR-06）：** **M1** work unit 與 continuation box 增 `baseline_revision`、`semantic_baseline_hash`、`change_radius`；admission 恢復時比對，不符回 STALE（先處理 DEFECT-011 的版本保護）。**M2** `scripts/closure_chain.py`：核對八步各有產出 ref 與證據層級，不持有 Current。**M3** 測試：缺任一步回 INCOMPLETE；順序顛倒被拒絕；基線不符回 STALE。
- **S4 對話記錄與指令（FR-10）：** **M1** `event_log` 新增 `DIALOGUE_TURN`（只存 conversation_id、輪次、內容雜湊、ref；全文保存待有消費者）與讀取函式；事件類型的擴充放在 `event_log` 內，與 R4L-S2 的 `BRIEF_DELIVERED` 同一擴充點；欄位名參考 OpenTelemetry GenAI 的 `gen_ai.conversation.id`（命名參考，不是儲存或鎖）。**M2** `！` 指令路由紀錄接 `role_command_router`。**M3** `capability_registry` 的 CAP-CONVERSATION-RECORD 與文件宣稱對齊（DEFECT-015）。
**每個 FR 的交付：** 閉環情境（生產者→消費者→驗證者→回饋各一步）＋Track A 的手動等價流程（≤ 10 行）。
**驗收：** 各 FR 的閉環情境 `SIMULATED_PASS`；`precheck [adr]` 通過；證據層級 `SIMULATED_PASS`。**停止：** 同 R4L。

**D19 驗收（R3g；`python3 tools/batch_gate.py` 機械判定，precheck HARD）：** 任務 DONE ＝ 入口檔存在，且 `batch_gate record <任務ID> --entry <檔> --command <指令>` 寫入 exit_code 0 的證據，入口檔雜湊與紀錄一致（改檔後重跑）；批次 DONE ＝ 全部 M 任務 DONE、S／C 任務 DONE 或附理由 SKIPPED。登記表：`policy/batch_acceptance.v1.0.json`。純文件不構成梯次 2 的完成。 每個 FR 的閉環情境是一支可重跑的腳本（生產者→消費者→驗證者→回饋），入口＝該腳本。

### R4T 工具支撐能力（梯次 2；DEFER，有消費者才啟動）
**承接清冊：** FR-11。**觸發：** R2b 或 R5 出現實際需要統計、聚類、趨勢、週期或異常檢測的任務。**做法：** 以程式化工具呼叫（沙箱執行，只回傳最終結果）加 Gate：驗證輸入雜湊、輸出 schema 與證據層級；演算法先用標準庫 `statistics`，需要其他函式庫時走 R8 的轉接契約。**未觸發：** R9-S4 以 ADR 記錄 RETIRE。單場。

### XM 執行者接口（旁支；LISTED，最小範圍；2026-10-14 使用者提出）
**來源與意圖：** 使用者目前只有手機＋免費會員；一般設計、規劃、思考全在對話進行（不耗 API），內容建在 GitHub；實際施工與運作檢測才動用 Codex。Codex 是**備用選項**：先設好接口與架構，日後有電腦與會員可直接切換，並讓兩種狀態通用。
**閘門與結論（XM0 已於 R3d12l 完成，結果在 `docs/research/P2-OPT-REF/11-XM0-執行者接口外部比對.md`）：** G1 過、G2 過、G3 過（Codex 事實≥2 獨立來源；Actions 單一廠商降級）、G4 過（C26、不重複 F30）→ **LISTED，範圍縮到與廠商無關的最小集（XM1）**。修正：手機可操作 Codex，有無電腦不是唯一門檻；Free 方案能否跑雲端任務有分歧（UNKNOWN）。廠商專屬做法一律 DEFER。
**設計（已採納的部分）：**
- 同一份契約、可替換的執行者：任務卡、政策、證據檔、交接檔全在 GitHub；執行者列舉值 `CHAT`（預設，現狀）、`ACTIONS`、`CODEX`；切換只改 `policy/executor_mode.v1.0.json` 的一個模式值；做到一半可換手。
- 基線必須只靠 `CHAT` 跑完；`ACTIONS`／`CODEX` 只加速與提供真實驗證，不得成為必要條件（C26）。
- 證據多記 `executor`（加在 `batch_gate` 的批次證據，不另立登記表）；沿用 SIMULATED_PASS／PROGRAM_EXECUTED_PASS，互不冒充。
- 任務卡與執行者無關（要改的檔、不准動的檔、驗收指令、證據輸出位置）；規格不清一律寫 BLOCKER 退回對話，設計決定留在對話端。
**XM1（單場，模擬運行；SHOULD，排在 R4L-M3 的 S3-M3b／S4 之後）：** ① `policy/executor_mode.v1.0.json`（`mode`、`allowed`、`baseline=CHAT`）；② `batch_gate` 證據加 `executor`（先查批次證據目前由哪個 schema 或程式驗證，再動）並檢查列舉值與「基線只靠 CHAT」（DONE 不得要求非 CHAT）；③ `tools/task_card.py --check`：任務卡必填欄位與 BLOCKER 形狀檢查；④ 測試含負例與突變（把檢查改成恆放行須轉紅）。**不做：** 產生 `AGENTS.md`、Actions 觸發步驟、額度計算、任何廠商 API 呼叫（DEFER，待使用者有該管道）。

### R5 薄迴圈＋Gate 接線，完成閉環（梯次 2；模擬運行）
**承接清冊：** V2、V6、V9、V13
**讀：** `scripts/central_controller.py`、`state_transition.py`、`event_log.py`、`repository_result_writer.py`、`debug_escalation_policy.py`、`parallel_scheduler.py`（切片）；R1-S2 對 `test_raw_github_run_shape_is_sufficient`（level 1 對 2）的裁決；`evidence/r1-vertical-slice/run_slice.py`（15 KB，接線範例）。
- **S1 M1** `scripts/p2_run.py`（Track B 轉接器，對映 P2 Run Contract〔§3B.6〕，不是最低模式的必經路徑）：任務→館員備 Brief→Provider 提案→模式控制器→Gate→工具→Verifier→trace；`brief_use` 寫入 trace；呼叫既有函式，狀態規則維持原樣。**M2** 工具四個：`read`、`search`、`edit`、`run_tests`；範圍限定在 `workdir`，路徑白名單、指令白名單、輸出截斷；`edit` 受 §3B.10 的寫入保護（三項前置、`protected_paths`、事後差異核對）。**M3（V13）** 記錄能力與角色選擇，錯配由 `role_session_gate`、`role_capability_binding` 擋下。**M4b（FR-12、FR-05、FR-10）** `loop_contract` 驗證：下一輪必附新證據或新問題、重複的狀態雜湊即停止、未知保留、完成條件明確，並對每項能力驗五欄位（提供者、消費者、可用模式、成功條件、失敗回饋）；任務收尾呼叫 `closure_chain`；對話輪次寫入 `DIALOGUE_TURN`。**M5（§3B.4）** 失敗階梯轉接函式：在 `debug_escalation_policy` 內加一個函式，把 segment 的嘗試事件轉成 `decide()` 接受的 run 形狀，並套用 OD3 的重試語義（可重試步驟首次失敗後最多自動重試 1 次，再失敗即停止並進既有出口）；不複製等級邏輯、不新增模組。
- **S2 M4** 模擬情境集 `python3 scripts/p2_run.py --simulate`：一次跑完 ≥ 11 個 Gate 負向情境（越界寫入、路徑穿越、危險指令、超出 write_scope、預算耗盡、非法模式轉移、未授權施工、trace 鏈被竄改、目標未確認即寫入、差異超出預覽、寫入受保護路徑）。**M5** 閉環情境：ScriptedProvider 修一個玩具 repo 的錯誤，Verifier 以玩具 repo 的測試為準，trace 鏈驗證通過。**S6** 失敗後回到 THINKING 路徑的情境一次；分級情境三個：輕量簡答（無 Brief、無 Build）、有寫入自動升至標準、寫入受保護路徑升至深度，低於下限的提案被退回；另加兩個情境：「連續失敗到停止自動重試」（第 2 次失敗後不再 `REQUEUE`，進 `WAITING`，原因已記錄；見 SC-03）與「Track A 乾跑」（只用對話＋GitHub，不執行 Python；見 SC-07）。
**驗收：** `--simulate` 全部情境符合預期；trace 驗證函式對竄改回報失敗。閉環完成後，把本批的模擬 trace 保存為 R6 的輸入。對應 `OPEN-ISSUES` 006c、009c。
**停止：** 既有函式介面對不上時，寫轉接層；仍卡住就記 BLOCKER。

**D19 驗收（R3g；`python3 tools/batch_gate.py` 機械判定，precheck HARD）：** 任務 DONE ＝ 入口檔存在，且 `batch_gate record <任務ID> --entry <檔> --command <指令>` 寫入 exit_code 0 的證據，入口檔雜湊與紀錄一致（改檔後重跑）；批次 DONE ＝ 全部 M 任務 DONE、S／C 任務 DONE 或附理由 SKIPPED。登記表：`policy/batch_acceptance.v1.0.json`。純文件不構成梯次 2 的完成。 **019c：** R5 的驗收記錄採 `tools/assurance_audit.py` 格式（`outcome`＝Verifier、`process`＝Gate／trace 各有 producer、verdict、level、evidence_ref；`claimed_level` ≤ 兩者較低者）。**020c：** 四條接線鏈（`policy/wiring_chains.v1.0.json`）在 R5 結束時全為 `WIRED_EXECUTED`（`evidence/wiring-chains/<chain_id>.json` 記錄 exit_code 0 與 `links_exercised`），UNWIRED 能力數低於基線 19（`tools/baseline_wiring.json`，只降不升）。R5 `closes_loop: true`，DONE 後才放行梯次 3。

### R6 路徑蒸餾（梯次 3；模擬回放）
**承接清冊：** V11、V15
**目標：** 閉環跑通後，把機械性流程從語意運行換成代碼運行。
**讀：** R5 保存的模擬 trace；`scripts/operational_reference_pack.py`、`root_cause_distillation.py`（切片）；`docs/plans/P2-Code-First-Execution-and-Distilled-Operational-Pack-v1.0.md`（用 `slice.py --toc` 取相關段落）。
- **S1 路徑盤點：** M1 `scripts/path_distill.py`：逐步讀 trace，把每一步標成「機械」或「語意」。機械步驟的判準由代碼可檢驗：同樣輸入在 ≥ 3 次模擬得到同樣輸出、輸出可由規則或 schema 決定（路由、範圍檢查、預算、狀態轉移、封包組裝、報告格式化、測試執行與結果判讀）、不含自然語言判斷。M2 輸出 `fast_paths.json`：觸發條件、對應函式、等價證據。
- **S2 fast path 與回放：** M3 把清單上前 ≥ 3 個機械步驟寫成代碼函式；迴圈先查 fast path，命中就由代碼執行，未命中回到 Brain。M4 等價回放：用已保存 trace 重放，fast path 輸出與原輸出雜湊一致；不一致的案例退回語意路徑並登記。M5 量測：步數與 token 代理量相對 R5 版本的下降幅度，門檻在跑前凍結（雜湊記錄）。S6 把「新能力先以語意運行跑通，再蒸餾」寫進藍圖的能力生命週期（≤ 2 行）。
**驗收：** `fast_paths.json` ≥ 3 條；回放等價率 100%；代理量下降達到門檻，未達則保留語意路徑並記錄原因。證據層級 `SIMULATED_PASS`。

**D19 驗收（梯次 3；`tools/batch_gate.py` 機械判定）：** 任務 DONE ＝ 梯次 2 的條件（可執行入口、exit_code 0 證據、雜湊一致）加 ① `closure_ref` 指向 `closes_loop` 且 DONE 的 R5（先閉環）② `distilled`：fast path 編號、存在於 `scripts/` 的函式（`module:func`）、`equivalence_rate` ＝ 1.0、重放證據檔；機械流程由該函式執行，未命中才回語意路徑。無機械流程的任務以 `distill_waiver`（理由）登記並計數。 R6 批次另需 `min_fast_paths` ＝ 3（B4）。蒸餾結果由 `p2_run` 先查 fast path，語意運作只留給未命中者。

### R7 重建證明、知識生命週期、Active/Archive（梯次 3；模擬運行）
**承接清冊：** V1、V3、V14
**讀：** `scripts/reconstruction.py`、`simulated_amnesia_resume.py`、`knowledge_canon.py`、`knowledge_versioning.py`、`continuation_context_box.py`、`lifecycle_sweep.py`、`archive_governance.py`（切片）。
- **S1 M1** `tools/rebuild_check.py`：只取「藍圖＋Current＋canonical＋schemas＋scripts」到全新目錄，重生可重生物，比對雜湊，不一致時列出差異。
- **S2 M2** 失憶續跑：跑到一半中斷，只靠 continuation box＋trace 續跑，最終狀態與不中斷版一致。**M3** 知識生命週期情境：觀察→主張→新版本→衝突→封存，各態前後的查詢結果被斷言。**M4（V14）** 封存資料不出現在 Brain 輸入包。**M6（FR-14、§3B.6）** 外部候選晉升情境：`UNTRUSTED_CANDIDATE → VERIFIED → ACCEPTED／REJECTED／EXPIRED`，每次轉移有責任角色與證據 ref；候選未經 VERIFIED 不進 Knowledge；接入點＝`knowledge_intake`、`research_source_normalization`（對接尚未核對）。**S5** R1 遺留雜湊問題收口。
**驗收：** 四組模擬情境（失憶續跑、知識生命週期、封存不入輸入包、外部候選晉升）符合預期；`rebuild_check` 在 R3 封存後的結構上通過。對應 `OPEN-ISSUES` 008c。

**D19 驗收（梯次 3；`tools/batch_gate.py` 機械判定）：** 任務 DONE ＝ 梯次 2 的條件（可執行入口、exit_code 0 證據、雜湊一致）加 ① `closure_ref` 指向 `closes_loop` 且 DONE 的 R5（先閉環）② `distilled`：fast path 編號、存在於 `scripts/` 的函式（`module:func`）、`equivalence_rate` ＝ 1.0、重放證據檔；機械流程由該函式執行，未命中才回語意路徑。無機械流程的任務以 `distill_waiver`（理由）登記並計數。 R7 的每個情境（失憶續跑、知識生命週期、封存不入輸入包、外部候選晉升）在閉環後各蒸餾成一個可重跑函式，`rebuild_check` 本身即代碼。

### R8 Hands 轉接契約（梯次 3；模擬運行）
**承接清冊：** V12
**讀：** `integrations/25d/README.md`、`adapter.py`（切片）。
- **M1** `schemas/hands_adapter.schema.json`＋`scripts/hands_adapter.py`：定義「請求外部執行者做一件事、回傳結果與證據」的契約；附替身實作與契約情境。真實 Agent-S／Computer Use 的整合列為後續工作。
**驗收：** 契約情境全部符合預期。

**D19 驗收（梯次 3；`tools/batch_gate.py` 機械判定）：** 任務 DONE ＝ 梯次 2 的條件（可執行入口、exit_code 0 證據、雜湊一致）加 ① `closure_ref` 指向 `closes_loop` 且 DONE 的 R5（先閉環）② `distilled`：fast path 編號、存在於 `scripts/` 的函式（`module:func`）、`equivalence_rate` ＝ 1.0、重放證據檔；機械流程由該函式執行，未命中才回語意路徑。無機械流程的任務以 `distill_waiver`（理由）登記並計數。 R8 的契約情境蒸餾為 `hands_adapter` 的契約檢查函式。

### R9 統一實測與最終驗收（梯次 4）
**承接清冊：** V1–V17 全部回查
前三個梯次累積的修補與模擬結果，在這個梯次一次實測。
- **S1 全測試與修綠（預留 2 場）：** M1 `python3 tools/precheck.py --run-tests` 一次，結果與「待驗證清單」逐項對照。M2 依對照結果修綠，每場修一組並更新待驗證清單。M3 `--write-baseline` 縮小基線，目標基線為 0 或每個遺留項有書面理由。C4 固定依賴（jsonschema 4.26、Python 3.11）環境下複核，結果寫進交接檔。
- **S2 評測與真模型抽樣：** M0 先凍結門檻（雜湊記錄）：V7 先澄清率與過度澄清率、V11 步數／token 相對 B0 的下降幅度、危險請求誤放行率上限。M1 `evals/`：20 題玩具任務（含隱藏測試）：Bug 修復 8、加功能 4、受限重構 2、模糊請求 3（應先澄清）、危險請求 3（應 BLOCK）。M2 指標：成功率、步數、token 代理量、誤放行率、過度澄清率、能力／角色選擇正確率，另加輕量任務的讀集位元組與步數（相對標準流程）。**M2b** Brief 品質三指標：證據精確度（已引用主張中有來源支持者）、必要證據覆蓋率（必要主張中有充分依據者）、遺漏率（相對 `brief_slots.json` 必要槽漏掉者）；三項配對判讀，送出槽數不計優劣；題集加「缺槽」題與 ≥ 5 題的參考答案集，取得獨立量測（最低模式下三項皆為 `AI_ATTESTED`）。先澄清率、過度澄清率、改向率由澄清事件重算（Track A 取任務結果的澄清摘要）。M3 三組對照：B0 單次提案、B1 迴圈無 Gate、P2 完整（含 fast path）。M4 `evals/report.json`＋簡短 md；P2 沒贏基線時如實寫入。S5 真模型抽樣（你在有金鑰且 Cost Gate 放行的環境）：`ModelProvider` 跑 ≥ 5 題；沒跑則 V6、V7 標 PARTIAL（`SIMULATED_PASS`）。
- **S3 失敗驅動治理：** M1 取 S1／S2 最嚴重的 1–2 個真實失敗，走完：事實→HYPOTHESIS→區分測試→確認根因→分類（ONE_OFF／LOCAL／SYSTEMIC／INVARIANT）。M2 判 SYSTEMIC 以上：寫入藍圖 v4.0（≤ 2 行）＋可執行檢查＋回歸測試，重跑評測，分數需有可比較的改善，否則撤回規則。M3 維護預算 `maintenance / construction` ≤ 0.20，量不到標 `UNMEASURED`。S4 把「新規則附一個失敗案例」寫成 precheck 文件檢查；新能力走一次 R6 的蒸餾流程。
- **S4 清冊驗收與定位文件：** M1 逐條填寫清冊 V1–V17：PASS／PARTIAL／FAIL＋證據路徑；FAIL／PARTIAL 寫原因與下一步。M2 `docs/architecture/P2-Positioning.md`（待建）：以願景文檔為底，只留有證據支持的句子，其餘標「目標」。S3 仍開啟的未知與阻塞整理成維護待辦。
**驗收：** 完整測試套件結果與基線一致或更好；評測報告含三組指標；清冊 17 條皆有狀態與證據路徑；定位文件每個「已能」句指向證據；precheck（含 `--run-tests`）PASS。

---

## 6. 風險與反證

| 風險 | 早期訊號 | 對策 |
|------|----------|------|
| **延後實測會累積未驗證修補**（現有 24 檔失敗正是這樣來的） | 「待驗證清單」超過 30 行 | 每個修補登記檔案與對應測試；R9-S1 預留 2 場修綠；R1 修補以最小改動為原則 |
| 修綠時被迫改很多測試 | R1 內「改期望」數量 > 修程式數量 | 回到歸因；每次改期望寫理由 |
| 封存誤傷隱性相依 | R3 搬移後快速檢查或 `rebuild_check` 失敗 | 搬一批驗一次；用還原清單回滾 |
| 蒸餾時丟掉仍有效的內容 | R2c 蒸餾稿與來源對不上 | 先寫入權威文件、再刪來源（D8）；舊 zip 可回查 |
| fast path 與語意運行結果不一致 | R6 回放等價率 < 100% | 不一致案例退回語意路徑並登記；門檻跑前凍結 |
| 真模型輸出不穩，薄迴圈不如預期 | R9-S2 的 P2 組成功率低於 B0 | 如實記錄；先查 Provider 提示與 schema，再判斷治理是否有害 |
| 免費額度不足以跑完整評測 | Cost Gate 阻擋 | 腳本替身為主，真模型只抽樣 |
| 文件與規則再度膨脹 | 藍圖 > 24 KB、hygiene 失敗、`[style]` 上升 | D2、D5、D7、D9 與 R9-S3 的 S4 |
| 單場做不完 | 70% 規則觸發 | 部分交接；場次可再切 |
| 館員漏查，大腦在不完整的 Brief 上決策 | `brief_use` 的事後補查次數 ≥ 1 | 缺口分級、窄化重請求；遺漏的 ref 補進 `brief_slots.json`；R9-S2 加「缺槽」題量測 |
| 對話模式沒有執行環境，Brief 無人生成 | 來源變動：`sources[]` 內任一檔在 `base_commit` 之後有變動（STALE） | 由工作者會話（Track A）或本機執行館員（Track B）寫入 `briefs/`；STALE 時重建，重建失敗進降級讀集 |
| 兩個 session 同時寫 Brief 而互相覆蓋 | 同一路徑被後者覆寫 | 每個 `brief_session_id` 一個檔；衝突時以最新 session 重建（SC-05） |
| Track A 的規則只靠 AI 自述遵守（`POLICY_ONLY`、`AI_ATTESTED`），被誤當成程式強制 | 介面索引的 Track A 列宣稱 `PROGRAMMATIC` | 強制力與證據等級分欄標示；強制力需要 Track B 的程式化檢查；R9-S2 的缺槽題取得獨立量測 |
| 目標未確認就寫入、改壞既有成果 | 事後差異超出預覽、`protected_paths` 命中、Track A 無平台強制 | §3B.10 的三項前置、受保護清單、事後核對與回復點；Track A 以 GitHub 分支與 PR 為平台強制點（保護設定待使用者確認） |
| 降級讀集超過預算 | `precheck [startup]` 降級模式超過 §3B.3 的目標或硬上限 | 優先精簡 Skill 啟動段與 Current 的 HOT 摘要；無法精簡的必要項目逐項列出理由，不靜默超額 |
| 檢索內容夾帶指令句影響大腦 | R4L-S3 的來源含指令句情境失敗 | Brief 走資料通道；逐字摘錄附雜湊；規則句只取已驗收的 `distilled_rules` |
| 多代理成本膨脹（二手資料轉述 Anthropic：多代理約 15 倍 token；採用前回查原文） | 館員生成 Brief 需要模型呼叫 | 館員以代碼擷取；改寫式摘要只用已驗收規則 |
| 把 Brief 當真值引用 | 證據欄只指向 Brief | Brief 標明衍生品；證據引用指向來源 ref 與雜湊 |
| 復原件膨脹，新增模組過多 | 新增腳本 > 3 個 | D16：先在既有模組承載；v2.2 的九個舊檔不原樣重建 |
| 復原後再度與現況脫節 | `precheck [wiring]` 出現宣告超前 | 宣告由接線證據推導；每個 FR 的閉環情境納入 R9 |
| 判定錯誤：把有意移除當成遺失 | R2b 覆核時找到書面裁定 | §1B 的判定附依據；R2b 覆核後才動手復原 |

**本企劃可能錯在哪：** ① CORE 砍太小而丟掉有價值的治理——由 R9-S2 的對照決定。② 玩具評測不代表真實工程任務——R9-S4 標明外推限制。③ 「失敗多半來自未驗證修補」只是假說，R1-S1 的歸因表會確認或推翻。④ 梯次 1–3 沒有實測，若 R9-S1 的失敗數量遠超預期，修綠場次要增加。⑤ 梯次劃分（1 整理、2 接腦、3 蒸餾、4 實測）是依你的描述所定，若你的「第四梯次」範圍不同，調整第 4 節即可，批次卡不受影響。⑥ 館員的槽位清單可能漏掉隱性相依，以 `brief_use` 與 R9-S2 的缺槽題檢驗。

## 7. 完成定義
1. 梯次 4 的完整測試套件通過，基線為 0 或每個遺留項有書面理由。
2. 一條端到端路徑：任務→Brain（真或替身）→Gate→fast path／語意運行→Verifier→trace，可重播。
3. 評測報告含基線對照，結果如實。
4. 願景主張清冊 17 條皆有狀態與證據。
5. 藍圖 ≤ 24 KB，每條保留規則有強制機制或標為原則；`repo_budget.json` 達標或有記錄的決定。
6. precheck 的 hygiene、refs、style 皆在目標內。
7. 大腦啟動必讀集：兩種模式皆在 §3B.3 的預算內（`precheck [startup]` 實測）；每任務 Brief ≤ 8 KB；缺口分流情境全部通過；啟動讀集位元組、Brief 位元組、補查次數三項可量測，成敗指標＝下次啟動以更少上下文完成工作並留下證據。
8. 功能復原清冊 14 列皆有判定；保留者各有閉環情境（生產者、消費者、驗證者、回饋）與 Track A 的手動等價流程；`precheck [wiring]` 通過（宣告不超前實況）。
9. 澄清與寫入保護：目標不明確的請求，確認前零寫入；每次寫入有目標確認引用、變更預覽與回復點；先澄清率與過度澄清率可由事件重算。

---

## 8. 新增與修改的既有優先流程（EXISTING-FIRST）與 F30 通用化（R3d130i 定；取代 R3d130g／h「另建 feature_lifecycle」的方向）

**8.1 原則。** 任何新增功能、修改、規劃、新建系統，動手前依序：①找出原有流程 ②逐一比對覆蓋度 ③決定 REUSE／MODIFY／MERGE／NEW ④決定 NEW 須寫明每個既有候選為何不能改 ⑤先更新本規劃，再施工。比對紀錄欄位：需求、既有候選（路徑與功能）、各候選覆蓋度、決定、理由。「搜名字找不到」不算比對；須讀藍圖對應章節與候選程式的檔頭。

**8.2 原有流程盤點（讀碼與藍圖確認；邏輯未逐行驗證＝HYPOTHESIS）**

| 梯次 | 既有功能 | 缺口 | 處置 |
|---|---|---|---|
| 進件（1） | F24 `intent_resolution`、F28 `change_classification_router`（藍圖：每次相關變更必先分類） | 結果沒接到批次 | MODIFY：接線（W5） |
| 藍圖規劃（1） | `blueprint_update_transaction`（P0～P4 排序、依賴拓撲、影響矩陣、來源指紋、原子寫入讀回）；`change_impact_scan`／`change_impact_v2`、`architecture_fit`／`architecture_decision`（尚未讀＝W0） | 不要求大綱節點重點內容 | MODIFY：PLANNING 出口加節點內容檢查（W3） |
| 四階段骨架（1～4） | F30 `feature_batch_orchestrator`：PLANNING → REALIZATION → CLOSURE → FINAL_TEST | 寫死 `P2-B1-B8`、30 功能；藍圖標 CODE PRESENT／UNVERIFIED | MODIFY：通用化（W2） |
| 能運行（2） | F30 REALIZATION：實作指紋＋本地案例收據 | 無 | REUSE |
| 閉環（3） | F30 CLOSURE 8 項 `closure_checks`；`batch_gate` 第 3 級蒸餾；`lifecycle_sweep` | F30 CLOSURE（8 個布林）與 `closure_chain`（FR-05 八步，`p2_run` 在用）是兩套八步閉環；兩者都沒有真的退場與蒸餾（`closure_chain` 的 LIFECYCLE 步只收字串） | MERGE：以 `closure_chain.STEPS` 為閉環步驟來源，F30 CLOSURE 引用它；LIFECYCLE 步改為真檢查（W4） |
| 實際運行（4） | F30 FINAL_TEST、`run_p2_validation` | 只擋階段未到，不自己實跑；真實運行屬 R9 | MODIFY；真實執行延 R9（W6） |
| 新系統 | `system_factory_strategy` → `construction_entrypoint` → `construction_factory` | 不讀批次階段 | MODIFY：讀階段（W5） |
| 工作迴圈 | `p2_run` | 不讀批次階段 | MODIFY：讀階段（W5） |
| 已交付重複品 | `feature_lifecycle.py`、`policy/feature_lifecycle.v1.0.json`、其 2 個測試檔、`p2_run` 的 BUILD 觸發 | 與 F30 重複 | MERGE：節點內容檢查併入 F30（W3），其餘移除；併入前不再擴充 |

**8.3 施工順序（每項先看 W0 結論再動手）**
- **W0 盤點（只讀不寫；R3d130j 完成全功能重疊比對 §9 與規則分類 §10，剩餘閱讀見 §9.3）：** 讀上表標「尚未讀」的模組與 F30 全部階段條件，更新缺口欄；查 `schemas/feature_batch_manifest.schema.json` 是否把功能數鎖成 30。
- **W1 防再發（先看能否擴充 `precheck`／`caller_audit`／`workflow_audit`，優先併入既有）：** 把 8.1 變機械檢查；新增 .py 須附比對紀錄，`close_session` 執行。 **併入 §10 的「規則轉功能」項：鎖定檔比對、測試期望變動、進度百分比、決策欄位。**
- **W2 F30 通用化：** 批次編號、功能清單、數量改讀清單；既有 B1-B8 測試期望不改。若須動 `schemas/`，先問使用者。
- **W3 PLANNING 出口：** 併入 F28 分類與 P0～P4 排序結果，加節點內容檢查。
- **W4 CLOSURE：** 加「退場」（`lifecycle_sweep` 結果）與「蒸餾」（`batch_gate` 第 3 級規則）。
- **W5 進件與執行接線：** F28 分類完自動開批次；`p2_run` 與建系統流程讀批次階段，階段未到不得說完成。
- **W7 常設規則單一來源（§10.2）：** 啟動提示詞由 `pack_handoff` 從固定規則產生，只有本場 ID 與任務是變數；進度百分比由登記表自動算進交接。
- **W8 小工具合併（低優先）：** `canonical_json`／`content_hash` 等各自定義的重複，逐一確認輸出格式相同才合併。
- **W6 FINAL_TEST 實跑：** 屬 R9；之前一律標 NOT_EXECUTED 或 SIMULATED_PASS。

**8.4 裁決（沒回覆＝我決定；可推翻）。** ①所有變更分類（含 ONE_OFF）都走四階段，ONE_OFF 只縮小範圍、不跳階段。②不另建階段引擎，一律改造 F30。③動 `schemas/` 前先問使用者。

**8.5 完成定義。** 新增功能時，批次清單看得到：原有流程比對紀錄、四階段各自的機械退出條件結果；沒有比對紀錄的新增 .py，結案被擋。

## 9. 全功能重疊比對（R3d130j 的 W0 結果；182 個模組＝scripts 155＋tools 27；程式掃描加讀檔頭與函式名，邏輯未逐行驗證＝HYPOTHESIS）

**9.1 結論：** 另外有相同情形。除 `retire_gate`、`feature_lifecycle`，還有五處階段／閉環骨架並存，以及多組「蓋好卻沒接進流程」的模組。

| 重疊組 | 證據 | 判定 | 處置 |
|---|---|---|---|
| 階段／閉環骨架（5 套） | F30 四階段；`closure_chain.STEPS` 八步；`construction_lifecycle.EXPECTED_STAGES`（建系統用）；`lifecycle_sweep`＋`archive_governance`（退場）；`feature_lifecycle` | 重複 | F30 當唯一階段骨架；`closure_chain` 供 CLOSURE 步驟；`construction_lifecycle` 保留為建系統的實作階段（先讀其階段表）；`feature_lifecycle` 併入後移除 |
| 跑出證據（8 個） | `runtime_evidence_probe`、`capability_run`、`scenario_oracle`、`regression_executor`、`execution_truth`、`local_acceptance`、`run_p2_validation`、`minimal_closed_loop_runner` | 分工待確認；`feature_lifecycle` 階段 2 手填 `runs`，沒用既有探針 | 階段 2／4 的證據改讀 `runtime_evidence_probe`／`execution_truth` |
| 蒸餾（5 個） | `path_distill`、`scenario_distill`（0 處引用）、`result_distillation`、`root_cause_distillation`、`distill_coverage`（0 引用 0 測試） | `path_distill`／`scenario_distill` 就是「機械流程蒸餾成程式」的既有功能，未接進新增流程 | 階段 3 的蒸餾直接呼叫它們，驗收用 `caller_audit`＋`batch_gate` 第 3 級 |
| 影響範圍（4 個） | `change_impact_scan`（1 處引用）、`change_impact_v2`（0 引用、1 測試）、`change_scope_gate`（0 引用 0 測試）、`blueprint_update_transaction` 內影響評估 | v2 疑似未接線的後繼版 | W0 剩餘：判斷 v2 取代或廢棄 |
| 日誌（4 個） | `event_log`（20 處引用，標準）、`run_journal`（雜湊鏈 JSONL，`p2_run` 用）、`event_reducer`、`dialogue_loop` | 兩套 append-only 記錄 | W0 剩餘：比對欄位與用途再定是否合併 |
| 閘門（15 個） | `change_scope_gate`、`function_capability_gate`、`local_control_gate`、`capability_independence_gate` 無引用無測試，只被登記表或文件提及 | 疑似未接線 | W0 剩餘：逐一接線，或交 `lifecycle_sweep` 退場 |
| 失敗重試（3 個） | `debug_escalation_policy`（RETRY_MAX＝1）、`iterate_control`（只數回合）、`Run.ladder`（呼叫前者） | 有意分層，不重複 | REUSE |
| 稽核（8 個） | `wiring_audit`／`wiring_chain_audit`／`caller_audit` 問不同問題，`precheck` 彙整 | 有意分工 | REUSE |
| 來源追溯（4 個） | `evidence_outer` 檔頭自述包在 `evidence_provenance_guard` 外；`provenance_trace` 多跳 | 疑似有意分層，未讀全 | 暫不動 |
| 小工具各自定義 | `canonical_json` 12 處、`content_hash` 13 處、自寫原子寫入 5 處（14 個模組用 `os.replace`，只 12 個匯入 `atomic_write`）、sha256 出現在 60 個模組 | 重複，但各處輸出格式未必相同 | W8，逐一驗證輸出相同才合併 |

**9.2 孤兒與蓋好未接：** 無引用也無測試共 15 個（`analysis_report_cli`、`capability_independence_gate`、`capability_usage_aggregator`、`change_scope_gate`、`external_tool_candidate_review`、`external_tool_radar`、`function_capability_gate`、`local_control_gate`、`state_growth_1000`、`axis_lint`、`distill_coverage`、`expansion_probe`、`failfirst`、`ref_retarget`、`slice`）；其中 `ref_retarget` 連文件都沒引用，疑似死碼；`slice`、`failfirst`、`axis_lint`、`expansion_probe` 是命令列工具。另有 `external_skill_adapter`、`knowledge_context`、`quality_metrics` 無引用且無 `__main__`（有測試）。另外 `session_driver`（Run.resume／close 的正式入口）、`path_distill`／`scenario_distill`、`brain_chains`、`task_card` 等在程式內無人引用；是否已登記為入口、是否已由 `caller_audit` 管，尚未核對。

**9.3 W0 剩餘閱讀：** ①`construction_lifecycle.EXPECTED_STAGES` 與 F30 全部階段條件 ②`schemas/feature_batch_manifest.schema.json` 是否鎖死 30 ③`run_journal` 對 `event_log` ④`change_impact_v2` ⑤四個無引用閘門 ⑥上述「蓋好未接」模組的登記狀態。

## 10. 規則分類：哪些是功能、哪些才是本場暫時條件（R3d130j）

**10.1 誤判成暫時條件的證據：** 啟動提示詞每場由上一位工作者手寫，常設規則混在「本場」文字裡；使用者 10-14、10-15、10-16 三度重述同一組常設規則（沒回覆＝我決定、分批顧及上下文、可查外部、梯次 2 要實際運行、梯次 3 要閉環蒸餾、完成各梯次階段任務），其中「每場列進度百分比」在現行規則與交接裡完全沒有。

| 規則 | 目前放哪 | 機械強制？ | 判定 | 處置 |
|---|---|---|---|---|
| 四階段、先比對既有 | 規則文字＋F30＋`batch_gate` | 部分 | 應為功能 | W1～W6 |
| 梯次 2 要實際運行代碼、梯次 3 閉環後蒸餾 | `batch_gate`（D19） | 有，但只管登記表任務、綁 R 批次名 | 已是功能，需脫鉤 | W2／W5 |
| 閉環條件（啟動、結束、中斷或出錯可運行） | 啟動提示詞，每場手抄 | 部分（`closure_chain`、F30 CLOSURE） | 應為功能（＝階段 3 定義） | W4 |
| 測試期望不改 | 守則文字 | 無（失敗棘輪只擋失敗檔，不擋改斷言） | 應為功能 | W1 |
| 先紅後綠 | 守則文字 | 無（`failfirst` 是失敗分診，未接線，不是紅綠檢查） | 應為功能，較難機械 | W1：先在交接加「紅證據」欄 |
| `canonical/`、`schemas/`、`P1-CURRENT.json` 不動 | 守則文字 | 沒找到機械檢查（precheck 只審 canonical 內的種子） | 應為功能 | W1：與前一版比對雜湊，例外列於卡片 |
| 每場列進度百分比 | 無；`session_start` 只在工作者終端印 DONE 數 | 無 | 被遺漏的常設要求 | W7：由登記表自動算進交接 |
| 沒回覆＝自己決定，可查外部、借鏡 | 啟動提示詞末行，手抄 | 無 | 接力常設規則；決策紀錄應為資料欄位 | W7；`handoff.data.json` 加決策欄位與格式檢查 |
| 分批、顧及上下文、預算與 70% 收尾 | 啟動提示詞，手抄 | 無（只驗交接大小；呼叫數無法機械計） | 接力常設（免費額度），非 P2 功能 | W7 固定規則；維持文字 |
| 無搜尋工具標 NOT_EXECUTED、不假裝搜尋 | 使用者 10-16 指示 | P2 功能層有（`research_request` 降級帳）；接力規則層沒有 | 常設 | W7 固定規則加一行 |
| 模擬標 SIMULATED_PASS、有實跑才說完成 | 守則＋`closure_chain.LEVELS`＋`batch_gate` | 有（部分）；藍圖 §14 與交接用兩套標記詞 | 已是功能 | 補對映表 |
| 單一自足交接、每場交付 zip＋HANDOFF | 偏好＋`close_session` | 有 | 已是功能 | 無 |
| 本場 ID、R9 前不做真實測驗（D-REAL-DEFER）、依賴債上限 10 | 交接＋policy | 有 | 正確屬於暫時／專案階段條件 | 保持 |

**10.2 結構性修法：** 啟動提示詞由 `pack_handoff` 從固定規則（單一來源）產生，只有本場 ID 與本場任務是變數；常設規則不再放在手寫文字裡。

## 附錄 A　剩餘文件與資料處置表（R2c 確認、R3 執行；執行完刪除本附錄）

「綁定」＝被 `P1-CURRENT.json`、`progress/*.json`、測試或程式以路徑引用，R3 以 Current 更新交易同步後才動。

| 文件／資料 | 大小 | 綁定 | 暫定處置 |
|------------|------|------|----------|
| `architecture/P2-System-Blueprint-v1.0.md` | 131 KB | Current、程式 | 唯一權威；R3 改寫為 v4.0（≤24 KB），舊版封存 |
| `architecture/P2-Implementation-Evidence-Matrix-v1.0.md` | 33 KB | progress、schema | R2b 輸入；CORE 現況併入 Feature-Triage 後刪 |
| `architecture/P2-Run-Mode-Contract-v1.0.md` | 14 KB | progress | 蒸餾（最低模式＝AI 對話＋GitHub；證據層級）→ 藍圖後刪 |
| `architecture/P2-Design-Conformance-Review-v1.0.md` | 61 KB | progress | 蒸餾未結差異 → `OPEN-ISSUES` 後刪 |
| `architecture/P1-Architecture-Spine`／`P1-Governance-Rules`／`P1-代碼化控制層…基線-v2.2` | 4／11／31 KB | Current／ledger | R2c 判定：有效部分併入藍圖，其餘 ARCHIVE |
| `plans/P2-Post-r48-Roadmap-v1.0.md` | 44 KB | Current、程式 | 已被本文件取代；Current 同步後刪 |
| `plans/P2-Test-Strategy-and-Free-Execution-Paths-v1.0.md` | 49 KB | Current、程式 | 蒸餾（免費執行路徑、整批驗證節奏）→ 本文件 §3 後刪 |
| `plans/P2-Code-First-Execution-and-Distilled-Operational-Pack-v1.0.md` | 35 KB | Current、`test_operational_reference_pack` | R6 的設計來源；蒸餾進 R6 與藍圖後，由 R2b 決定去留 |
| Brain-Formal-Activation-Plan（25 KB） | 25 KB | 僅文件 | R3d8 已蒸餾進 R4 S7 並刪除 |
| `plans/P2-Conversation-Brain-Activation-Interface-v1.0.md` | 16 KB | Skill、README、R4L | R3d8 判 KEEP：唯一指令表（R4L I03、U12 依賴），不蒸餾不刪 |
| `plans/P1-M32-…`、`P1-M33-…` | 19／13 KB | progress | 驗收契約已結案；ARCHIVE |
| `acceptance/P2-B2-AI-GitHub-Minimum-Loop-v1.0.md` | 8 KB | 文件 | 併入藍圖後刪 |
| `acceptance/P2-AI-GitHub-Baseline-Run-001.md` | 6 KB | progress | 一次性 Run 紀錄；Current 同步後刪 |
| `capabilities/P1-對話記錄與指令系統.md`、`decisions/P1-模型時代…`、`research/P1-48功能…` | 14／6／5 KB | registry | R2c 判定；採用的結論進藍圖，其餘刪 |
| `參考資料/P2-*.md`（4 份） | 52 KB | progress（1 份） | 概念已在藍圖；確認後刪 |
| `參考資料/企劃/`（8 份） | 170 KB | 僅文件 | 蒸餾進藍圖 v4.0 後整個 `參考資料/` 刪除 |
| `P1-Central-Control/progress/`（9 檔） | 272 KB | Current、測試 | 已結案紀錄蒸餾進交接檔後封存；達成 13.5 KB 預算 |
| `P1-Central-Control/evidence/r1-vertical-slice/runs/`（實驗輸出） | ≈25 KB | `test_r1_vertical_slice` | `run_slice.py` 可重生；測試改為執行時重生後，刪除已提交的輸出 |
| `P1-Central-Control/fixtures/`、`examples/`、`evidence/m31-close-01/` | 17／29／6 KB | 測試 | 被測試引用者集中保留；`[refs]` 列為孤兒者（目前含 `M31-CLOSE-01.reconciliation.json`）刪除 |

---

## 附錄 B　外部借鏡與取捨（2026-10-12；R4L、R4R 的設計依據）

> 證據層級：下列內容取自搜尋結果片段，尚未逐篇通讀原文。數字（90.2%、約 15 倍 token）為二手轉述，採用前回查原文。

**方案比較**

| 方案 | 大腦上下文 | 成本與基礎設施 | 適配本系統 | 結論 |
|------|------------|----------------|------------|------|
| A 現況：大腦自讀固定清單 | 約 300 KB | 無 | 與藍圖的乾淨思考環境相反 | 取代 |
| B 只瘦身檔案 | 縮小但仍由大腦決定讀什麼 | 低 | 是 R1-S3、R3 的必要前置，單獨使用不足 | 保留為前置 |
| C Letta 式：大腦用工具自管記憶 | 檢索結果進入大腦 | 向量庫、執行環境 | 與 K10（不依賴外部 API 索引）衝突 | 只借概念 |
| D 子代理館員（模型） | 乾淨 | 多代理 token 成本高；對話模式沒有執行環境 | 成本與環境條件不合 | 只借分工 |
| E 雙軌館員（對話＋GitHub 為底、程式加速）＋每 session 一檔 Brief＋分級＋漸進揭露 | 啟動預算見 §3B.3、≤ 8 KB／任務 | 沿用既有 `knowledge_*`、Pack、`context_sufficiency` | 吻合 code-first 與 D6 保留資產 | **採用** |
| F 時序知識圖（Zep／Graphiti） | 乾淨 | 圖資料庫與模型抽取 | 基礎設施過重 | 只借「有效期＋來源＋失效不刪除」 |

**借鏡明細**

| 來源 | 借什麼 | 不借什麼 |
|------|--------|----------|
| Anthropic〈Effective context engineering for AI agents〉https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents | 注意力預算；啟動先給小摘要、其餘按需檢索；壓縮先求召回再求精準 | 讓大腦自己 grep（雜訊會回到大腦） |
| Anthropic〈How we built our multi-agent research system〉https://www.anthropic.com/engineering/multi-agent-research-system | 領導者分解並派工、保存計畫；子代理在獨立上下文探索後回傳濃縮結果 | 以模型當館員（成本） |
| Letta／MemGPT https://docs.letta.com/guides/agents/memory 、https://docs.letta.com/guides/legacy/memgpt-agents-legacy | 常駐小區塊＋外部封存的兩層結構；sleep-time 離線整併 | 大腦自管記憶；整併吃進外部可觸及內容的風險已寫入資料通道規則 |
| LangChain〈Context Engineering〉https://www.langchain.com/blog/context-engineering | write／select／compress／isolate 四分法：Brief 寫入、槽位選取、逐字摘錄、角色會話隔離 | — |
| Blackboard：Han 與 Zhang 2025 https://arxiv.org/abs/2507.01701 ；Salemi 等 2025 https://arxiv.org/abs/2510.01285 ；確定性管線版 https://zenodo.org/records/19068475 | Brief 是大腦的黑板區；Central 擔任確定性排程；請求發到黑板、由分區檢索或網路檢索的知識源回應 | 讓知識源自由競爭啟動（難以追蹤） |
| Corrective RAG（Yan 等 2024）https://arxiv.org/abs/2401.15884 | 檢索分 Correct／Ambiguous／Incorrect 三級，內部不足才補網路 | 模型評估器；改以槽位覆蓋與 `context_sufficiency` 的代碼分級 |
| Zep／Graphiti https://pypi.org/project/graphiti-core/0.29.1/ | 保留原始 episodes、事實有效期、失效不刪除、來源可追溯 | 圖資料庫與模型抽取 |
| Claude Agent Skills 漸進揭露 https://www.claude.com/blog/equipping-agents-for-the-real-world-with-agent-skills | 啟動只載中繼資料，觸發才載全文，資源再按需 | — |
| 二手：Hyperspell〈Multi-Agent Context and Memory〉https://www.hyperspell.com/blog/multi-agent-memory | 多代理的共享與私有記憶分層；約 15 倍 token 的成本警示 | 其數字待回查原文 |

### B2　功能復原的外部借鏡（FR-02 至 FR-12）

| FR | 來源 | 借什麼 | 不借什麼 |
|----|------|--------|----------|
| FR-02 | MADR 4.0 與 ADR 工具（adr-kit https://github.com/kschlt/adr-kit 、AdrMcp https://www.nuget.org/packages/AdrMcp ）；O'Reilly〈ADR 與編碼代理〉https://www.oreilly.com/radar/?p=19867 | （P2 自訂 ADR 格式，參考 MADR 的欄位設計）YAML frontmatter 讓狀態可解析；status 生命週期與 supersedes；ADR 發布後保持原樣，變更以新 ADR 取代。警示：代理可能死守已過時的 accepted 決策，所以 Brief 只載現行有效者，並要求反轉條件 | 以 MCP 伺服器管理 ADR（需執行環境，留給 Track B） |
| FR-01 | 事件溯源與 CQRS 投影 https://codemia.io/archive/event-sourcing-explained | 投影是可丟棄的讀模型，由事件重播重建；快照讓重播有界；重建必須能從零開始 | 完整事件溯源基礎設施（架構借鏡，不引入實作） |
| FR-03 | Meta SCARF https://engineering.fb.com/2023/10/17/data-infrastructure/automating-product-deprecation/ ；flutter_pruner https://pub.dev/packages/flutter_pruner/versions/1.0.0 ；scream test 說明 https://brainbound.blog/scream-test-guide-feature-deprecation | 依賴範圍分析決定刪除順序；變動前先進隔離區，隔離清單附校驗與回復；靜默觀察期後才刪除 | 以日曆天數計觀察期（P2 以驗收批次數計） |
| FR-05、06 | GitHub Spec Kit https://www.augmentcode.com/guides/github-spec-kit-practical-guide-sdd-workflow | 憲章、規格、計畫、任務的順序，以及用 `/speckit.converge` 對照程式碼補列剩餘任務的收斂動作，對應 `closure_chain` | 它的自由格式 Markdown 規格（P2 的規格要有 schema） |
| FR-06、10 | LangGraph 持久化 https://docs.langchain.com/oss/python/langgraph/persistence.md ；耐久執行比較 https://hackernoon.com/durable-execution-for-ai-agents-langgraph-dbos-inngest-and-temporal-compared | thread_id 加 checkpoint_id；在 super-step 邊界存檔；恢復時不重跑已成功的步驟；同樣提醒留存與清理政策要及早規劃 | 另設資料庫式 checkpoint 儲存（M23-P13 已決定 REUSE）；LangGraph 為架構借鏡，不引入實作 |
| FR-07 | Claude Code 工作樹 https://www.morphllm.com/claude-code-worktrees ；git worktree 與代理 https://blog.openreplay.com/git-worktrees-ai-agents/ | 每個代理一個隔離目錄；用 `git worktree add --detach` 建隔離根（唯讀由檔案權限或掛載控制，`--detach` 本身不等於唯讀）；合併回主線前要審查 | 並行代理的規模（瓶頸在審查頻寬） |
| FR-08、R9 | Anthropic〈Demystifying evals for AI agents〉https://anthropic.com/engineering/demystifying-evals-for-ai-agents | 程式型評分器為主、模型型與人工為輔；評結果狀態而非代理的說法；capability 與 regression 分開，達標後轉入回歸 | 以模型當主要評分器 |
| FR-10 | OpenTelemetry GenAI 語意慣例 https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans/ | `gen_ai.conversation.id` 串起同一段對話；欄位以雜湊與 ref 為主，避免把個資寫進紀錄 | 完整遙測堆疊；`gen_ai.conversation.id` 只是命名參考，不是儲存或鎖 |
| FR-11 | Anthropic 程式化工具呼叫 https://www.anthropic.com/engineering/advanced-tool-use ；CodeAct https://arxiv.org/abs/2402.01030 | 由模型寫程式、在沙箱執行，只把最終結果回到上下文；可成功的程式動作存成工具 | 自行實作統計與機器學習演算法；程式化工具呼叫需要對應的執行工具，屬 Track B |

> 證據層級同附錄 B 開頭：取自搜尋結果片段，尚未逐篇通讀原文。

### B3　主軸文檔的外部借鏡（2026-10-13；§3B.12 的設計依據；取自搜尋片段，R4L 開工前回查原文）

| 來源 | 借的原理 | 不借的 |
|---|---|---|
| Claude Code CLAUDE.md／MEMORY.md | 啟動讀簡短索引、細節按需讀；官方建議每檔 < 200 行 | 規則清單屬規範，與描述性主軸不同 |
| llms.txt | 標題＋摘要＋每項一句話與連結；索引不是語料 | 平面連結無層級；llms-full 的合併語料與目標相反 |
| C4 模型 | 一圖一層、由大到小，避免混層 | UML／arc42 過重 |
| Letta 記憶區塊 | 小而常駐的區塊 | AI 自改權限，與「AI 只提議收斂」衝突 |
| NovelAI Author's Note | 貼近生成處的短注入 | 靜態，不判斷偏離 |
| Sudowrite Story Bible | 上層餵下層的分層 | 人工更新、封閉商品 |
| Rasa CALM Conversation Repair | 修正／岔題／取消三型；處理完回主流程 | 預寫業務流程、需執行環境 |
| Ragas／DeepEval Topic Adherence | 以主題清單評分偏離，可作驗收 | 二元、事後、有 LLM 成本 |
| NeMo Guardrails／Spec Kit／Ouroboros／Semantic Router | 禁區式規則、規格先行、凍結規格加偏離偵測、向量路由 | 需執行環境，或「凍結」與逐層收斂衝突 |

沒有找到把主題當逐層收斂的鏈、並以距離判斷偏離的現成產品（本輪搜尋範圍內；未涵蓋對話主題轉移偵測的學術工具）。
