# P1 M33｜Role-Isolated Session Topology v1.0

版本：v1.0
狀態：CLOSED — VERIFIED / SIMULATION_ONLY；OBSERVED_RUNTIME = 0
原始前置條件（歷史）：M32-CLOSE VERIFIED 後才啟用角色契約、指令路由與隔離測試。
目前證據邊界：P1-CURRENT 記錄 M33-CLOSE 為程式層 SIMULATION_ONLY 驗收；尚無真實角色 session／真實 Brain 的 OBSERVED_RUNTIME 證據。本文件不得單獨作為真實整合完成的證明。

## 1. 目的

把 P1 的人機操作拆成三個互斥工作身份：

1. ROLE:CONTROL_RESEARCH
2. ROLE:EXECUTOR
3. ROLE:VERIFIER

三者共用 P1 的 Canonical Authority，但不共享 conversational context、角色權限或工作責任。

核心目標：

CONTROL / RESEARCH
→ 決策、研究、診斷、修正規劃

EXECUTOR
→ 只承接 Task Packet，失憶重建後施工

VERIFIER
→ 只承接驗證目標，失憶後獨立驗收

驗證完成前不得由 Executor 自行進入下一 Work Unit。

## 2. 核心不變量

1. P1-CURRENT.json 仍是唯一 Current Authority。
2. 不新增第二套 State / Result / Retry / Current / Memory Truth。
3. Role Contract 不是 Truth Store，只是權限與 Context Admission Contract。
4. conversational history 永遠不是 canonical handoff。
5. Executor 與 Verifier 必須 AMNESIA_REQUIRED。
6. Executor 不得 VERIFY / ACCEPT / REPLAN / EXTERNAL_RESEARCH。
7. Verifier 不得 EXECUTE / MODIFY_SOURCE / MODIFY_PLAN / EXTERNAL_RESEARCH。
8. Control 可以研究、診斷、修改規劃與建立施工內容，但不能自行產生 VERIFIED。
9. 所有 Role 都禁止直接修改 P1-CURRENT。
10. 所有 Role 都只與 Central 交互；不得建立 Role→Role 直接交接。Cross-role lifecycle transition 必須由 Central 執行。
11. Role Session 只能取得自己被授權的 capability。
12. Role Gate 必須 fail closed。

## 3. Session Topology

核心拓撲不是 Role→Role handoff，而是：

ROLE → CENTRAL → ROLE

三個 canonical role：

CONTROL_RESEARCH
→ 規劃、研究、診斷
→ Central

EXECUTOR
→ Central 取得 Task Context
→ 執行
→ Result / Progress → Central

VERIFIER
→ Central 取得 Acceptance Context
→ 驗收
→ Verification Result / Evidence → Central

Central 是唯一 lifecycle switch：

1. 決定目前允許哪個 Role。
2. 產生該 Role 的最小 Context Projection。
3. 接收 Role progress / result。
4. 判定 Work Unit 是否到達 lifecycle boundary。
5. 由施工完成狀態產生 Acceptance Request / Context。
6. 接收 Verification Result / Evidence。
7. 執行 PASS / FAIL / BLOCK / INCOMPLETE 的 lifecycle transition。
8. 依 canonical state 計算下一 Work Unit 的 Admission Decision。

禁止：

EXECUTOR → VERIFIER
VERIFIER → EXECUTOR
任一 Role → 直接啟動其他 Role

Failure path：

VERIFIER FAIL / BLOCK / INCOMPLETE
→ CENTRAL
→ CONTROL_RESEARCH
→ 新 Task / Repair Plan
→ EXECUTOR

修復完成後仍重新回 CENTRAL，再建立新的 Acceptance Request / Context。

## 4. Context Policy

### CONTROL_RESEARCH

Context mode：RESEARCH_EXPANDED

可載入：
- P1-CURRENT
- active architecture / plan
- progress
- historical evidence when relevant
- research artifacts
- external sources
- failure evidence

控制原則：
- Chat context 可以比較長。
- Canonical State 仍在 repository。
- 不得把 conversational history 直接變成 Current Truth。

### EXECUTOR

Context mode：AMNESIA_REQUIRED

每次 Task Admission 必須：
- history_loaded = 0
- transient_context_loaded = false
- targeted_retrieval_only = true

最小輸入：
- P1-CURRENT
- active Work Packet
- Construction Packet
- Task Packet
- Continuation Context Box when present
- required source refs

禁止：
- 載入上一個 Executor session transcript
- 載入 Control Chat transcript
- 載入 Verifier transcript
- 主動擴大 architecture research

### VERIFIER

Context mode：AMNESIA_REQUIRED

最小輸入：
- Current
- target Task / Work Unit
- Acceptance Contract
- implementation artifacts
- Result
- Evidence / Provenance
- required test sources

禁止：
- 載入 Executor 的 conversational reasoning
- 依 Executor 自我宣稱判定完成
- 載入 Control 的未驗證結論作為 PASS 依據

## 5. Authority Boundary

### CONTROL_RESEARCH

可以：
- READ / ANALYZE
- EXTERNAL_RESEARCH
- DIAGNOSE
- PROPOSE
- MODIFY_PLAN
- MODIFY_CONSTRUCTION
- CREATE_TASK
- WRITE_RESEARCH_ARTIFACT
- MODIFY_SOURCE_VIA_CONSTRUCTION_ENTRYPOINT

不可：
- VERIFY
- ACCEPT_RESULT
- COMMIT_CURRENT
- BYPASS_TASK_ADMISSION
- 宣布 VERIFIED

### EXECUTOR

可以：
- TASK_ADMIT
- EXECUTE_TASK
- RUN_TASK_TESTS
- REPAIR_IN_SCOPE
- WRITE_RESULT
- WRITE_CHECKPOINT

不可：
- VERIFY
- ACCEPT_RESULT
- REPLAN
- MODIFY_BLUEPRINT
- MODIFY_TASK_CONTRACT
- EXTERNAL_RESEARCH
- DIRECT_CURRENT_MUTATION
- OUT_OF_SCOPE_WRITE

### VERIFIER

可以：
- VERIFY_TASK
- RUN_ACCEPTANCE
- INSPECT_ARTIFACT
- INSPECT_DIFF
- WRITE_VERIFICATION_RESULT
- WRITE_EVIDENCE

不可：
- EXECUTE_TASK
- MODIFY_SOURCE
- MODIFY_TASK
- MODIFY_BLUEPRINT
- REPLAN
- EXTERNAL_RESEARCH
- COMMIT_CURRENT
- SELF_REPAIR

## 6. Cross-role isolation

任何 Session Request 都必須帶有 role_id。

Role Gate 必須驗證：
- role_id 有效且 ACTIVE
- operation 屬於 role allowed_operations
- denied_operations 不得出現
- requested write target 不得超出 role scope
- forbidden target 永遠 BLOCK
- Executor / Verifier 必須完成 amnesia admission
- 任何 role 都不得直接 current mutation

Role Gate 是運作邊界，不是模型 Prompt。

## 7. Verification Gate

Work Unit implementation 完成後：

EXECUTOR
→ REPORT_PROGRESS / SUBMIT_ROLE_RESULT
→ CENTRAL

Central 先判定是否達到 Work Unit Close boundary。

若達到：

CENTRAL
→ 建立 ACCEPTANCE REQUEST / ACCEPTANCE CONTEXT
→ 新 VERIFIER SESSION

VERIFIER
→ GET_ROLE_CONTEXT
→ ACCEPTANCE
→ VERIFICATION_RESULT / EVIDENCE
→ CENTRAL

只有 Central 可以把驗收結果映射為 lifecycle transition：

PASS
→ 下一 Work Unit Admission 可計算為 ALLOW

FAIL / BLOCK / INCOMPLETE
→ 回 CENTRAL
→ CONTROL_RESEARCH
→ 新 Task / Repair Plan
→ EXECUTOR

Verifier 不得：

- 直接叫 Executor
- 自行修復
- 自行產生下一 Work Unit
- 自行宣布 VERIFIED
- 修改 P1-CURRENT

Acceptance Request / Context 是 lifecycle request artifact，不是第二 Truth。Acceptance Result 仍由既有 Verification Result / Evidence / Current canonical path 決定。

## 8. 外部研究邊界

只有 CONTROL_RESEARCH 可以使用：
- public web
- GitHub research
- papers
- external architecture comparison

EXECUTOR 預設禁止外部研究。

VERIFIER 預設禁止 architecture research；只使用 Task / Acceptance / Evidence 指定來源。

目的不是限制模型能力，而是避免 execution context 漂移成 planning context。

## 9. Implementation Phases

### Phase A：Role Contract
- schema
- canonical registry
- role session request schema
- 維持 role_id / profile / operation / write-target isolation

### Phase B：Role Admission
- executable role_session_gate.py
- fail-closed checks
- amnesia requirement
- operation / write-target isolation
- 所有角色啟動都必須通過 Central role admission

### Phase C：Independent Verification
- dedicated role isolation test suite
- independent GitHub Actions workflow
- 驗證 Role 不可直接修改 Current、不可互相啟動

### Phase D：Canonical Integration（M32-CLOSE VERIFIED 後）
- Task Admission carries role_id
- Central 提供 ROLE_ACTIVATE / GET_ROLE_CONTEXT / REPORT_PROGRESS / SUBMIT_ROLE_RESULT
- Executor 透過 Central 取得 Task / Work / Construction Context
- Executor 完成後只回 Central，不直接交給 Verifier
- Central 產生 Acceptance Request / Context
- Verifier 透過 Central 取得 Acceptance Context
- Verifier 結果與 Evidence 回 Central
- Central 依 canonical state 計算 next-stage admission
- 不新增 unlock state / role state / acceptance state owner

### Phase E：Operational Closure
- simulate direct Executor → Verifier handoff attempt
- simulate Verifier → Executor direct activation attempt
- simulate unauthorized Acceptance Request creation
- simulate next-stage admission without PASS
- simulate PASS with stale head_sha
- simulate transcript leakage
- simulate unauthorized source mutation
- simulate Executor self-verification
- simulate Verifier self-repair
- verify no Current mutation bypass exists

## 10. 不做的事情

本 Work Unit 不建立：
- second Controller
- second Memory
- second Session Truth
- second Result
- second State
- second Acceptance Engine
- Role-specific Current
- Role-specific Scheduler

Role topology is an access/context boundary over existing P1 canonical owners. 2026-10-05 amendment：Role 不再被視為 lifecycle handoff peers；Central 是唯一 Role lifecycle switch、Context projection 與 next-stage admission authority.

## 11. 外部研究依據

本設計的外部依據：

- Anthropic｜Effective harnesses for long-running agents：長任務應以離散 session、增量工作與持久化進度跨 context 繼續；單靠 compaction 不足以避免遺漏與過早完成。
  https://www.anthropic.com/engineering/effective-harnesses-for-long-running-agents

- Anthropic｜Scaling Managed Agents：將 brain、hands、session 分離，session 是可持久查詢的 context object，而非等同模型當前 context window。
  https://www.anthropic.com/engineering/managed-agents

- OpenAI Agents SDK｜Handoffs：handoff 可使用 input filter，決定下一個 agent 真正收到哪些 history；預設情況下下一 agent 會看到前一段 history，因此需要明確過濾才能形成乾淨交接。
  https://openai.github.io/openai-agents-python/handoffs/

- OpenAI Agents SDK｜Guardrails：tool guardrails 可在每次工具呼叫前後執行檢查；需要逐工具控制時，不應只依賴 agent-level guardrails。
  https://openai.github.io/openai-agents-python/guardrails/

外部研究只作為 architecture evidence，不直接成為 P1 Current Truth。



## 12. User-facing locked commands

本設計提供四個使用者入口，但只有三個 canonical role：

### ！施工 → ROLE:EXECUTOR

固定用途：
- 承接 Task Packet。
- 失憶式最小 Context。
- 直接施工，不做架構研究。
- 施工錯誤只允許同一 error_id 一次 repair attempt。
- 一次維修成功則繼續。
- 一次維修失敗立即寫回同一 Construction Session Operational Record 並回報。
- 施工完成只執行任務指定的 simulation close，不擴張成正式驗收。
- 正式驗收交給 ！驗收。

身份鎖定：
- 本 Session 不得切換到驗收、討論或指導。
- 要換身份建立新 Session。

### ！驗收 → ROLE:VERIFIER

固定用途：
- 新 Session、失憶、獨立讀取驗收目標。
- 可一次承接多個已完成目標，例如 M32、M33、M34。
- 每項目標仍產生獨立 Verification Result。
- 只依 Acceptance Contract 驗收，預設 simulation-first。
- 不修碼、不改藍圖、不研究架構、不自行重跑施工。

結果：
- PASS → 允許回 Control 建立下一 Work Unit。
- FAIL / BLOCK / INCOMPLETE → 回 Control。
- 驗收身份不能把修復後結果當成同一輪自我驗收。

### ！討論 → ROLE:CONTROL_RESEARCH

固定用途：
- 全局讀取、除錯、外部研究、工具比較、架構復盤、藍圖修改。
- 工作單元告一段落時做一次「全局復盤」，而不是每一步都檢驗。
- 局部修正前先對照 P1 核心理念與既有 canonical owner。
- 形成新 Task Packet 後交給 ！施工。
- 不自行宣布正式 VERIFIED。

### ！指導 → ROLE:CONTROL_RESEARCH + IP:GUIDANCE-REVIEW

不建立第四個 canonical role。

這只是討論身份的一個固定審查配置，適合：
- 全面評分。
- 找致命問題。
- 與業界方法／產品比較。
- 指出優勢、主要缺口與優先修正路線。
- 防止局部除錯陷入專牛角尖。

正式施工仍回 ！施工；正式驗收仍回 ！驗收。

## 13. Construction Session Operational Record

施工紀錄是「操作追蹤」，不是第二套 Truth Store。

固定規則：
- \`authority = OPERATIONAL_TRACE_ONLY\`
- 一個 Work Unit 使用同一 \`record_id\` 持續追加。
- 施工錯誤、repair attempt、repair pass/fail、simulation close、return report 都在同一記錄。
- canonical Current / Result / Event / Evidence 仍為真正權威來源。
- 同一 \`error_id\` 的 \`REPAIR_ATTEMPT\` 最多一次，由 \`construction_session_record.py\` 機器強制。

## 14. Anti-oververification policy

施工身份故意不承擔：
- 完整 CI 驗收。
- 全庫回歸。
- 架構審查。
- 外部工具比較。
- 重複一致性掃描。

原因：這些工作屬於驗收或討論身份。施工身份只需要知道「能不能把目前任務往前推進」。

驗收身份也不得因沒有安全感而自行擴張驗收範圍；只執行 Acceptance Contract 需要的證據與 simulation-first 路徑。

## 15. Built-in failure playbook

常見施工錯誤已整理到：
\`P1-Central-Control/canonical/construction_failure_playbook.json\`

它只提供第一反應建議，不是真相來源；新紀錄與實際 Evidence 優先於 playbook。

目前特別納入的歷史痛點：
- Current / Runtime 狀態不同步。
- CI 紅燈無法歸因。
- external runner 啟動失敗與程式失敗混淆。
- Result re-entry / duplicate identity。
- 施工身份越界進入研究。
- 過度驗證造成施工停滯。
- Task Contract / Blueprint 本身有問題。
- 語意空殼取代真正 runnable artifact。
- 角色邊界被要求跨越。

