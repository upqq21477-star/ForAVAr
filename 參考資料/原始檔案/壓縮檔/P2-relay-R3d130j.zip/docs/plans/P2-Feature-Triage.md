# P2 功能分流（R2b；DOC_ONLY；非權威）
（R2c 起超過原 10 KB 上限：Plan R2c 規定蒸餾稿附於本檔末尾；§1–6 為 R2b 原文，§7–8 為 R2c。）

來源：證據矩陣 F01–F30（程式入口／測試欄）、Relay-Update-Plan §1B（FR-01～14）、對 scripts 的靜態掃描（import 與名稱比對）。
HYPOTHESIS：未讀模組與測試內文；「0 個非測試呼叫者」可能漏掉動態呼叫。未動任何程式或藍圖。使用者已採納 R2a（2026-10-13），藍圖等 R3 同批處理。

## 1. 判定規則
- **CORE（≤ 8）**：系統脊椎，或承載 §1B 必備模組（event_log、lifecycle_sweep、continuation box、planner_library、role_command_router）。
- **DEFER**：程式留原位、不新增工作。理由碼：C＝模組由 CORE 承載，不能移；M＝R2a 的 KEEP-ENFORCED 或合併組（G1–G6）機制；W＝後續批次（R4L–R9）要接入；D＝純文件。
- **ARCHIVE**：非測試呼叫者極少、計畫與 R2a 機制都不依賴；移前須先解耦。

## 2. F01–F30（腳本 KB 為該列模組加總，共用模組會重複計）
| ID | 責任 | 處置 | 依據 | KB | 測試（CORE 必列） |
|---|---|---|---|---|---|
| F01 | 問題輸入封包 | DEFER | C（F21 匯入 brain_input） | 6.3 | test_brain_input |
| F02 | Brain Proposal | DEFER | C（F21）；R4L 接 Brief | 11.3 | test_needs_brain |
| F03 | Planner／Capability Cards | **CORE** | 承載 planner_library（FR-13） | 38.8 | test_planner_library、test_task_set |
| F04 | Method→Task Set | DEFER | C（task_set 有 7 個呼叫者，隨 F03） | 10.7 | test_task_set |
| F05 | Central 路由與狀態轉移 | **CORE** | 承載 event_log（12 個呼叫者；FR-01、FR-10） | 84.9 | test_parallel_scheduler、test_event_log_reducer_replay、test_segment_event_replay |
| F06 | Role 隔離與獨立驗收 | **CORE** | Verifier 路徑；central_role_interface 匯入 role_command_router（矩陣未列此模組） | 169.4 | test_role_session_gate、test_role_operational_closure、test_role_result_ingestion、test_role_command_router、test_central_role_interface |
| F07 | Current／執行真相 | DEFER | C（event_log 在 F05）；M（G2） | 56.5 | — |
| F08 | 知識匯入與追溯 | **CORE**（最小：knowledge_canon＋intake；research_source_normalization 隨 R7-S2） | FR-02 用 canon 的 supersedes；R7-S2 接點 | 31.7 | test_knowledge_canon、test_knowledge_intake、test_research_source_normalization |
| F09 | 檢索、Context、失憶恢復 | **CORE** | 承載 continuation box（FR-06）；R4L 館員用 retrieval | 37.2 | test_knowledge_retrieval、test_continuation_context_box、test_simulated_amnesia_resume |
| F10 | 程式重建 Blueprint | DEFER | M（原則 9）；政策與工具共 21 處引用 | 14.5 | — |
| F11 | 生命週期與封存 | **CORE** | 承載 lifecycle_sweep（FR-03、04） | 44.0 | test_archive_governance、test_lifecycle_sweep、test_reconstruction_artifact_lifecycle |
| F12 | 外部工具雷達 | DEFER | W（R7-S2 外部候選晉升；FR-14 external_skill_adapter 待接線） | 21.6 | — |
| F13 | 自我評估、演進回退 | DEFER | M＋W（regression_executor 在待驗清單；control_gate_runtime 引用 change_impact_v2；lifecycle 政策引用 quality_metrics） | 42.1 | — |
| F14 | 投影與交接一致性 | DEFER | M（G2：current_projection_sync） | 9.6 | — |
| F15 | 最低操作驗收 | DEFER | D（R2c 附錄 A 處置） | 0 | — |
| F16 | 對話＋GitHub 最低模式 | DEFER | D＋M（原則 9） | 0 | — |
| F17 | Current-first 生命週期 | DEFER | C（lifecycle_sweep 在 F11）；M | 26.9 | — |
| F18 | 能力納入與退場 | DEFER | C（planner_library 在 F03） | 38.8 | — |
| F19 | UNKNOWN 診斷 | DEFER | M（原則 2、4：progressive_repository_scanner） | 33.6 | — |
| F20 | 系統建置工廠 | DEFER | W（藍圖 4.6 主軸；construction_factory 被工具引用） | 25.0 | — |
| F21 | Brain 常態認知控制 | **CORE** | 模式控制器（原則 11、15、17、22） | 201.4 | test_brain_mode_controller、test_brain_mode_runtime_interface |
| F22 | 根因蒸餾 | DEFER | M（原則 13） | 14.4 | — |
| F23 | 思考／施工隔離 | DEFER | C（模組同 F06） | 173.2 | — |
| F24 | 意圖理解與澄清 | **CORE**（只留現有範圍） | Brain 輸入側脊椎；R2a：設計超前，實作僅關鍵字＋三選項 | 56.6 | test_intent_resolution、test_central_feature_decision_routes |
| F25 | Operational Pack | DEFER | M（原則 9）＋W（FR-14 接 R5）；卡片候選但 CORE 名額已滿；0 個非測試呼叫者 | 42.0 | — |
| F26 | 整批更新 | DEFER | M（G4） | 48.5 | — |
| F27 | 適應式呈現 | **ARCHIVE** | 非測試呼叫者只有 central_role_interface 的 PRESENTATION_DECISION；Axis 索引無對應節點；計畫無引用 | 8.0 | — |
| F28 | 變更分類與藍圖演進 | DEFER | M（G3、G6、原則 28） | 46.8 | — |
| F29 | 健康回溯 | DEFER | M（原則 23） | 44.7 | — |
| F30 | 四階段批次與藍圖交易 | DEFER | M（G4、G6） | 82.1 | — |

合計：CORE 8、DEFER 21、ARCHIVE 1＝30。DEFER 不是刪除，檔案不動。

## 3. CORE 與必備模組核對
| 必備模組 | 承載 | 結果 |
|---|---|---|
| event_log | F05 | 在 CORE |
| lifecycle_sweep | F11 | 在 CORE |
| continuation box | F09 | 在 CORE |
| planner_library | F03 | 在 CORE |
| role_command_router | F06 | 在 CORE；但證據矩陣沒有任何 F 列出它（矩陣漏列，R2c 或 R3 補） |

CORE 共 23 個不重複模組、466,339 B（scripts 124 檔、1,404,346 B 的 33.2%）、23 個測試檔，皆存在於 zip。

## 4. ARCHIVE 可移除估算
- 可移：F27 的 presentation_selector.py 7,970 B＋test_presentation_selector.py 2,496 B＋presentation_decision.schema.json 1,774 B＝12,240 B（腳本約 8.0 KB，占 scripts 0.6%）。
- 移前須解耦 central_role_interface 的 PRESENTATION_DECISION caller，並處理 test_central_feature_decision_routes 的相關案例與 feature-batch manifest 的引用；這是程式變更，歸 R3 之後，並與藍圖「適應式呈現」小節（R2a 判 DISTILL）同批，需固定依賴下驗證。
- HYPOTHESIS：F 層程式幾乎都有人依賴或承擔 R2a 機制，瘦身重點不在移程式。較大的量在 progress/*.json（272,083 B，FR-04 預算 13.5 KB）與 docs/plans（Relay-Update-Plan 108.9 KB）；R3-S3 預算 slimming 先看這些。

## 5. §1B FR-01～14（書面依據＝Relay-Update-Plan §1B 同列，已有裁定；本表只轉成三種標籤）
| FR | 標籤 | 內容與承載 | 批次 |
|---|---|---|---|
| 01 | RESTORE | 三層投影與歷史查詢；event_log（F05） | R4L |
| 02 | RESTORE | ADR；用 knowledge_canon 的 supersedes（F08） | R4R-S1 |
| 03 | RESTORE | lifecycle_sweep 加 QUARANTINED 階段（F11） | R4R-S2 |
| 04 | RESTORE | lifecycle.v1.0.json 增 data_classes（F11） | R4R-S2 |
| 05 | RESTORE | closure_chain.py 只核對，不持有 Current | R4R-S3 |
| 06 | RESTORE | work unit 與 continuation box 增三欄（F09） | R4R-S3 |
| 07 | MERGE | 已在 construction_*／schema；Plan 判仍有效，無新工 | R8 |
| 08 | RESTORE | 規模參數化到 10⁵；simulated_amnesia_resume（F09） | R9 |
| 09 | RESTORE | 槽位卡片優先；planner_library（F03）＋precheck [startup] | R4L |
| 10 | RESTORE | event_log 加 DIALOGUE_TURN（F05）；role_command_router（F06） | R4R-S4 |
| 11 | RETIRE | 登記改 DECLARED_NO_TOOL；有消費者才復原，否則 RETIRE＋ADR（Plan 已列五欄位） | R1-S3、R4T |
| 12 | MERGE | loop_contract 併入 R5 迴圈 | R5 |
| 13 | RESTORE | 補卡片，由館員槽位載入（F03） | R4L-S3、R6 |
| 14 | MERGE | 接入館員與 R5；knowledge_intake、research_source_normalization（F08）為 R7-S2 接點 | R4L、R5 |

## 6. 需要使用者注意（不阻擋 R2c）
- F25 是卡片候選卻未入 CORE（名額滿）；它是原則 9 的強制機制，故 DEFER 並受保護。若要升 CORE，需換出 F08 或 F03 其一。
- F12 不 ARCHIVE：R7-S2 要接外部候選，且你的偏好是做工具前先比對相似工具。
- F27 ARCHIVE 與 R3 同批，不在 R2b 動檔。

## 7. R2c：附錄 A 蒸餾稿與最終處置（2026-10-13；DOC_ONLY；非權威）

**方法與界線：** 「引用者」＝對附錄 A 每列做靜態掃描（路徑或檔名出現在非計畫、非封存、非交接檔內；PROGRAM_EXECUTED 觀察，漏動態引用為 HYPOTHESIS）。內文只讀了：Run-Mode §1／§4、Test-Strategy §1.2／§2、Conformance §5／§7、Spine 不變量、Governance 各節首段、決策文結論；其餘列依標題與引用判定，標「未讀」。處置值：KEEP／DISTILL→藍圖／ARCHIVE／DELETE（DELETE 全部交你確認）。「前置」＝R3 動檔前須同批處理的綁定。

**與附錄 A 暫定處置不同之處（3 項，皆因實測引用）：** ① 參考資料/ 不能整個刪（R2a 把原則 9、10 的詳述指定搬進其中兩份）；② 對話記錄與指令系統.md 不是可刪孤兒（疑為 FR-10 設計來源）；③ evidence/r1 的 runs/ 不必改測試，測試本就重生輸出。

- **A1 藍圖 v1.0（131 KB）**｜引用者：P1-CURRENT.json、progress 5 檔、examples/operational_reference_pack.request.example.json（8 處）｜蒸餾：無（R2a 已分流）｜**KEEP**，R3 改寫 v4.0 後舊版 ARCHIVE｜前置：example json 與 progress 內的藍圖路徑同批改；§3 與 11 小節搬移逐段覆核。
- **A2 證據矩陣（33 KB）**｜引用者：progress 4 檔、Brain-Activation-Interface、README、Baseline-Run｜蒸餾：CORE 現況已在 §2；DEFER 21 項的「F→入口腳本／測試」對照未複製（HYPOTHESIS：R4L–R9 動手時會查）｜**DISTILL→本檔**（補一欄 F→腳本，約 2 KB）後 DELETE；補欄前不刪｜前置：progress 封存（R3-S3）。
- **A3 Run-Mode-Contract（14 KB）**｜引用者：藍圖 4、progress 4、example json 2、Conformance 2、README｜蒸餾：①最低模式＝AI 對話＋GitHub，GitHub 是唯一持久化與讀回來源，聊天內「已完成」不是工程狀態；②BASELINE 只能支持 GITHUB_PERSISTENCE_CONFIRMED／AI_DIALOGUE_REVIEWED／STATIC_REVIEW_PASS，不能把函式存在、靜態推理、測試檔存在升成程式實跑 PASS；③PASS 須直接證據，空清單、零樣本、跳過項不得推導 PASS（改 INCOMPLETE／BLOCK／NOT_APPLICABLE），UNKNOWN≠PASS，NOT_EXECUTED 不壓成 PASS/FAIL；④差異分級 MATCHED／PARTIAL／NOT_WIRED／MISMATCH／NOT_IMPLEMENTED；⑤無寫入能力時交付可貼入的完整內容並標「未保存」｜**DISTILL→藍圖 v4.0（≤1.5 KB）後 DELETE**｜未讀 §2.1–2.4（功能先行、Current 工作單位身份解析、RESEARCH 最小證據、施工健康回溯）→ R3 逐節覆核（UNKNOWN）。
- **A4 Conformance Review（62 KB）**｜引用者：藍圖 4、README 3、progress 3、roadmap、Baseline-Run｜蒸餾：文內 16 個 DEFECT-NNN 編號全已在 docs/audit/OPEN-ISSUES.md（PROGRAM_EXECUTED；002、012 只以斜線形式出現，002 已見於表，012 未單獨核）；修正順序＝P0 假 PASS／真值混淆 → P1 寫入原子性與知識完整性 → P1/P2 Scheduler／重試 → 量測證據完整性 → 文件與退場一致｜**DELETE**（交你確認）；排序一行併入 OPEN-ISSUES 表頭｜前置：未讀 §6（最低運行標準符合性）與 §8（原始包對帳），刪前讀標題確認無活項（UNKNOWN）；引用同批清。
- **A5 Architecture-Spine（4 KB）**｜引用者：P1-CURRENT.json、M31 驗證證據｜蒸餾：8 條基線不變量（Identity 不隨重構順序變；Topology 變動須新 baseline revision；未 VERIFIED 不得成 CURRENT；SUPERSEDED 不進預設 hot context；施工包須指定讀寫範圍、state delta、驗收；無 state delta 不算完成；驗收首次只跑一次、僅 FAIL 才可二次；新基線驗證後舊者降 SUPERSEDED）｜**KEEP**（Current 綁定，4 KB 無瘦身價值）；藍圖 v4.0 只留指標。
- **A6 Governance-Rules（11 KB）**｜引用者：canonical/update_learning_ledger.json 的 evidence_refs 路徑（canonical 維持原狀）｜蒸餾：①長程運行＝只取最小充分狀態，Current／Projection／Runtime 衝突→RECONCILIATION_REQUIRED；②資料生命週期六類（本稿只讀到 CANONICAL／WORKING／DERIVED／CHECKPOINT／EVIDENCE）；③變更範圍＝Change Radius Lock＋One System per Work Slice；④補強型 Skill／Harness／Router 屬 PROVISIONAL CAPABILITY，缺 load_bearing_evidence 等欄位不得宣告退場｜**KEEP**（ARCHIVE 會讓 canonical 帳本的路徑懸空）；藍圖只留指標。
- **A7 代碼化控制層…基線 v2.2（31 KB）**｜引用者：policy/lifecycle.v1.0.json（路徑條目，理由寫「R3 決定封存或退場」，複審日 2026-11-08）｜蒸餾：FR-01～14 判定已在 Plan §1B 與本檔 §5，舊基線只供對照｜**ARCHIVE**｜前置：同批改 lifecycle.v1.0.json 條目。
- **A8 Post-r48-Roadmap（44 KB）**｜引用者：P1-CURRENT.json、progress 5、整批更新方案、README；test_central_feature_decision_routes.py 把它放進 candidate_derived_views 路徑字串（未讀測試是否檢查檔案存在）｜蒸餾：已被 Relay-Update-Plan 取代｜**DELETE**（交你確認）｜前置：Current 同步（更新交易）；該測試字串改指 Relay Plan，或先確認它不檢查存在。
- **A9 Test-Strategy（49 KB）**｜引用者：Current、progress 5、example json 3、整批更新方案｜蒸餾→Plan §3：①證據階梯 T0 STATIC_REVIEW／T1 SCHEMA_EXECUTED／T2 UNIT_SIMULATION_EXECUTED（Python 3.11）／T3 REPOSITORY_PREFLIGHT_EXECUTED／T4 PACK_INTEGRATION_EXECUTED，每層只能支持自己那層的結論；②用任何計量服務前須核實費率、剩餘額度、超額行為與計費歸屬，任一未知即 BLOCK，禁加值與自動續費；③Codespaces 只在確認個人帳戶有剩餘額度且超額不會計費時才建立（外部核對 2026-10-13：GitHub Free 個人帳戶每月 120 core-hours、15 GB-month，用完且無付款方式即封鎖；組織帳戶無免費額度）；④未讀：§3 先模擬再執行、LOCAL_CASE_SIM、§5 免費方案、整批驗證節奏｜**DISTILL→Plan §3 後 DELETE**｜前置：Current／progress／example json 引用同批改。
- **A10 Code-First-Execution…Operational-Pack（35 KB）**｜引用者：test_operational_reference_pack.py（source_ref 字串）、P1-CURRENT.json、construction json、藍圖｜蒸餾：R6 設計來源（F25 維持 DEFER）｜**KEEP 至 R6**，之後 DISTILL→R6 卡與藍圖再刪｜前置：測試 source_ref 同批改。
- **A11 Brain-Formal-Activation-Plan（25 KB）、Conversation-Brain-Activation-Interface（16 KB）**｜引用者：.agents/skills/p2-brain/SKILL.md（共 5 處）、README、證據矩陣｜蒸餾：→R4 卡（正式指令清單、收口檢查、自我更新權限表）；內文未讀（HYPOTHESIS）｜**DISTILL→R4 卡後 DELETE**｜前置：先改 SKILL.md 的引用（技能入口不能指向已刪檔）。
- **A12 M32／M33 計畫（19／13 KB）**｜引用者：M32／M33 的 progress、update_learning_ledger、instruction_profiles 4 檔（以 `DOC:` 邏輯 ID 引用；已核 guidance-review.json，其餘 3 檔同為 1 處，形式未逐一核）｜**ARCHIVE**，保留原檔名（邏輯 ID 仍對得上）｜前置：progress 的 M32／M33 小檔保留。
- **A13 B2 最低閉環驗收（8 KB）**｜引用者：README｜蒸餾：接受條件一句＝AI 對話＋GitHub 可完成最低閉環（內文未讀）｜**DISTILL→藍圖後 DELETE**｜前置：README 1 處（README 為 Current 投影，隨投影重生）。
- **A14 Baseline-Run-001（6 KB）**｜引用者：藍圖 4、progress 3、證據矩陣 2、roadmap、README、tools/precheck.py｜蒸餾：一次性 Run 紀錄｜**DELETE**（交你確認）｜書面依據：precheck.py 的 LEGACY_RUN_ALLOWED 註解寫明「Current-bound until R3; then delete this line」→ 前置：同批刪該行。
- **A15 對話記錄與指令系統（14 KB）**｜引用者：只有計畫（無程式、無 registry）｜蒸餾：！討論紀錄／！會議紀錄、三次門檻習慣歸納、完整原始資料與整理資料分離｜**KEEP 至 R4R-S4**，完成後 DISTILL→藍圖再刪｜理由：HYPOTHESIS，它是 FR-10（event_log 加 DIALOGUE_TURN、role_command_router）的設計來源；附錄 A 把它當孤兒刪，會失去復原依據。
- **A16 模型時代能力重評估（6 KB）＋48 功能對照（5 KB）**｜引用者：policy/lifecycle.v1.0.json（路徑條目）、function_capability_registry.json（source_ref＝對照檔名）｜蒸餾：結論＝不照原規劃完成 5 個獨立 System／48 Functions；P1 改為提供模型無法自行保證的結構、證據、狀態、限制、驗證與可重現工具｜**ARCHIVE**（不 DELETE：registry 的 source_ref 要有可查檔）｜前置：藍圖 v4.0 收一句結論；同批改 lifecycle 政策與 registry 的 source_ref。
- **A17 參考資料/P2-*.md（4 份，52 KB）**｜引用者：整批更新方案＝藍圖、progress 4、roadmap、Code-First；系統性變更分類、適應式呈現＝彼此與 README；模擬運行＝只有 參考資料/README｜**KEEP 3 份**（適應式呈現、系統性變更分類是 R2a 搬移原則 9、10 的目的地，F27 ARCHIVE 的設計文也在此；整批更新方案被藍圖與 progress 引用）；**模擬運行與語意保真驗證標準（10 KB）→ ARCHIVE**（HYPOTHESIS：概念可能已在藍圖，內文未讀）｜修正 Plan：「整個 參考資料/ 刪除」改為「只刪 企劃/」。
- **A18 參考資料/企劃（8 份，170 KB）**｜引用者：README 2、roadmap、OPEN-ISSUES、Conformance、Baseline-Run｜**DISTILL→藍圖 v4.0 後 DELETE 6 份**（交你確認）；暫留 P1-Brain-v2-Research-Sources（3.9 KB）與 Synthesis-Matrix（1.8 KB）（HYPOTHESIS：前者是外部來源清單，你偏好做工具前先比對）｜內文全未讀。
- **A19 progress/（9 檔，272 KB）**｜小檔 4 個（M32／M33 的 work 與 construction，各 2–3 KB）**KEEP**（被 m32-close-acceptance.yml、測試、lifecycle 政策、acceptance json 引用）；大檔 5 個合計約 250 KB（B1-B8 feature-batch 78、B1-B8 work 52、B1-B8 construction 53、B2.2 work 41、B2.2 construction 26）→ **蒸餾進交接檔後 ARCHIVE**｜前置（R3-S3）：P1-CURRENT.json（更新交易）、scripts/blueprint_update_transaction.py（引用 B1-B8 兩檔）、tests/test_brain_mode_runtime_interface.py（引用 B2.2 construction）、README。13.5 KB 預算只靠小檔無法達成，須整批搬走大檔。
- **A20 evidence/r1-vertical-slice/runs/（約 24 KB）**｜引用者：無（測試把輸出重生到暫存目錄）｜PROGRAM_EXECUTED_PASS（3.12.3）：在拋棄式複本刪掉 runs/ 後 test_r1_vertical_slice＋test_repository_hygiene_gate 9/9 OK（含 runs/ 也是 9/9）｜**DELETE**（交你確認）；附錄 A 寫的「測試改為執行時重生」已是現況，不必改測試；保留 run_slice.py 與 brain/reply-001.json。
- **A21 fixtures／examples／evidence/m31-close-01**｜fixtures 11/11 皆被測試或程式引用、無孤兒 → **KEEP**；examples 10/10 皆被 workflow（p1-analysis-runtime.yml 等）或測試引用 → **KEEP**；m31：M31-CLOSE-01.reconciliation.json 0 引用 → **DELETE**（交你確認）；architecture-baseline-verification.json 唯一引用者是 reconciliation.json，刪後成孤兒，但它是 Spine「VERIFIED」的證據 → 暫 KEEP，R3 隨 Spine 決定。

**交你確認的 DELETE 清單：** A4、A8、A14、A20、A21 的 reconciliation.json，以及 A2／A3／A9／A11／A13／A18 在蒸餾完成後的刪除。

## 8. R2c 自行裁決（授權：2026-10-13「先上網比對、找最優解、先自行解決，有問題我會說」）

- **D-R2c-RTB（RUNTIME_TRUTH_BOUNDARY）＝選 (b)，併入 (a)，否決 (c)。** 事實：local_acceptance.py 第 218–221 行要求「整份 Current 原文含 SIMULATION_ONLY」且「頂層 latest_runtime_observation.evidence 為 False」；真實 Current 的觀察欄已改版（有 step_evidence、classification＝SIMULATION_FAIL、program_regression_status＝INCOMPLETE，沒有 evidence 鍵），所以真實樹檢查值為 False。外部比對：in-toto／SLSA 以具型別的欄位（predicateType）區分證據種類，測試結果、執行追蹤各自獨立；不用旗標加原文子字串。決定：改用型別欄位判斷「此觀察不是真實驗收證據」（classification 屬 SIMULATION_*，或 program_regression_status 不是 PASS），不再比對原文子字串與舊 evidence 鍵；(a)「讀 capture 後的觀察」已包含其中；(c) 否決：讓檢查反過來驅動 Current 資料，且 Current 是受保護檔。實作規格（NOT_EXECUTED，下個有執行環境的場次）：改 local_acceptance.py 一處；tests/_pending_repo.py 的頂層 evidence 夾具可刪；測試期望不變（夾具仍 PASS）；新增負例：classification 為真實通過時須 FAIL。
- **D-R2c-D18（OI-7）＝不降宣告值；改修稽核。** 事實（PROGRAM_EXECUTED 讀取）：capability_independence_gate.py 要求每個能力 `implementation == CANONICAL`（否則 BLOCK），且 global_rules.canonical_implementation_per_capability 必須為 true；registry 23/23 皆 CANONICAL。HYPOTHESIS 成立：該欄是「每能力一個正本實作」的身分約束，不是成熟度。降宣告值會讓閘門 BLOCK。決定：registry 不動；tools/wiring_audit.py 把 OVERCLAIM（CANONICAL 且推導值不是 WIRED／NO_TOOL）改成「推導成熟度報告」（WIRED／UNWIRED／NO_TOOL），不再以宣告值為上限。比對依據：身分與對它的型別化主張分開記錄（in-toto 的 subject／predicate 分工）。實作排入同一個程式小批。
- **D-R1-S3f／S3e (a)(b)(c)、D-S3g-LS／PL＝確認維持原決定。** 舊流程退役、程式不動、(c) 視為死路徑；lifecycle 以政策宣告入口（複審日 2026-11-08）、planner 以政策為權威。依據：已實施且 134/134（3.12.3）、與 D18 後「政策為單一權威」方向一致。限制：本場沒重讀封存 E 全文，也沒對這兩項另做外部比對。
- **D-R2c-F25＝不升 CORE，維持 DEFER（受保護）。** 依據：CORE ≤ 8 是 Plan 的上限；升格要換出 F08（知識正本最小子集）或 F03（planner_library），兩者承載必備模組；F25 目前 0 個非測試呼叫者，設計來源 A10 又 KEEP 至 R6。重判條件：R6 開工時出現第一個非測試呼叫者；屆時改上限需寫 ADR，不靠換出。
- **D-R2c-S0c（protected_paths）＝採用建議清單並加 `.github/` 整個目錄。** 清單：P1-Central-Control/canonical/、schemas/、P1-CURRENT.json、docs/architecture/（含已封存藍圖）、.github/。事實：CODEOWNERS 已涵蓋 `*`、/.github/CODEOWNERS、P1-CURRENT.json、P1-Central-Control/、docs/architecture/；GitHub 文件建議為 CODEOWNERS 檔本身或整個 .github 指定擁有者（已有前者）。UNKNOWN：分支保護或 ruleset 是否已啟用，無法從本環境查。HYPOTHESIS（未在查到的文件原文中，來自 GitHub「作者不能核准自己的 PR」的一般規則）：單一擁有者時若開「Require review from Code Owners」會擋住自己的 PR；較穩做法是 ruleset 要求 PR 與必過狀態檢查（p1-control-gate），並把你設為 bypass actor。
- **D-R2c-VALID（固定依賴下驗證的 BLOCKER）＝走 Codespaces，2 核機型，開機前先看額度。** 外部核對（GitHub 文件，2026-10-13）：個人 Free 帳戶每月 120 core-hours 與 15 GB-month，用完且無付款方式即封鎖；2 核機型約 60 小時。Current 內已有 2026-10-10 的 Codespaces 執行（Python 3.11.13）可證明路徑可行。須你操作：到 github.com/settings/billing 確認 Codespaces 剩餘額度、未設付款方式（Test-Strategy §1.2 規則），再跑 handoff §6 的測試清單。

## 9. R2d 實作與處置（2026-10-13；程式小批；Python 3.12.3）

- **RTB 已實作（D-R2c-RTB）。** `scripts/local_acceptance.py` 新增 `observation_is_not_real_evidence()`：觀察的 classification 屬 `SIMULATION_*`，或 program_regression_status 不是 PASS 才成立；缺觀察或型別錯誤一律 False（fail closed）。不再比對 Current 原文子字串與舊 evidence 鍵。`tests/_pending_repo.py` 夾具移除 `evidence: False`；`tests/test_local_acceptance.py` 新增 4 個測試，含負例（真實通過須 FAIL）。PROGRAM_EXECUTED_PASS：test_local_acceptance＋test_m32_close_vertical_slice 11/11；真實 Current 的檢查值 False → True。
- **D18 已實作（D-R2c-D18）。** `tools/wiring_audit.py`：移除 OVERCLAIM（`overclaim`／`overclaims`），改輸出每能力 `maturity`（WIRED／UNWIRED／NO_TOOL）與 `maturity_counts`、`unwired`；`--strict` 改為有 UNWIRED 才退出 1；`tools/precheck.py` [wiring] 同步（仍是 WARN）。registry 與 capability_independence_gate 未動。實跑：selftest 8/8 ok；真實樹 WIRED 0／UNWIRED 19／NO_TOOL 4（與舊 OVERCLAIM 19 同數）。限制：稽核只認 DECLARED_PROVIDERS 內宣告的提供者，UNKNOWN＝未宣告而非無程式（HYPOTHESIS：該表不完整，R3 起逐項補來源）。
- **刪除（SHOULD ③，使用者未回覆，依實測自行處置）。** 已刪 `P1-Central-Control/evidence/r1-vertical-slice/runs/`（24,023 B）與 `evidence/m31-close-01/M31-CLOSE-01.reconciliation.json`（0 引用）；刪後 test_r1_vertical_slice＋test_repository_hygiene_gate 9/9，`precheck --run-tests` 134/134、NEW failures 0。[refs] WARN 8 → 9：多出的是 `M31-CLOSE-01.architecture-baseline-verification.json` 成為孤兒資料檔，與 §7 A21 預告一致（暫 KEEP，R3 隨 Spine 決定）。**未刪：** A4、A8、A14（前置是 Current 同步，R3）、A2／A3／A9／A11／A13／A18（前置是蒸餾完成）。
- **S0c HYPOTHESIS 已查（外部，2026-10-13）。** GitHub Community 討論 #131419、#150545 的使用者回報：單一 code owner 自己開的 PR 無法自己核准，開「Require review from Code Owners」或必要核准後只能靠管理員 bypass 才能合併；#150545 另指出 classic branch protection 與 Rulesets 的 bypass 設定不同。證據性質：使用者回報，非官方文件原文。結論：HYPOTHESIS → 與觀察一致；D-R2c-S0c 不變（ruleset 要求 PR＋必過檢查 p1-control-gate，你設為 bypass actor；不單獨開 Require review from Code Owners）。另有一則外部提醒：Actions 若有寫入權限可自動核准並合併自己的 PR，組織設定有「Allow GitHub Actions reviews to count towards required approval」可關閉（Palo Alto Cortex 文件）；本 repo 的 workflow 是否有核准動作 UNKNOWN。
- **過期指標。** `docs/architecture/P2-Expansion-Open-Items-v0.1.md` 第 7 列仍寫「需使用者裁決 D18：新增 activation 欄位」，已被 D-R2c-D18 取代（registry 不動）。該目錄屬 S0c 保護範圍，本場未改，R3 改藍圖時一併更正。

## 10. R3a：藍圖 v4.0 改寫地圖與決策（2026-10-13；DOC_ONLY；非權威）

**為什麼先做地圖：** R3 批次卡 S1 要把約 134 KB 的藍圖 v3.3 改成 ≤ 24,576 B，卡片只列了目的、權威分工、原則、意圖整節、4.0 架構、批次路線；§5–§14 約 58 KB 沒有明列去向。以下逐節定去向與位元組預算（預算合計約 23.3 KB，留約 0.7 KB 餘裕）。舊版全文整份移到 `docs/archive/`（標封存、非權威），所以「縮出藍圖」不等於內容遺失。

| v3.3 節（約 B） | v4.0 去向 | 預算 KB |
|---|---|---|
| 檔頭、§1 目的、§2 權威分工（約 3.9 K） | 保留並收緊；§2 責任表新增「主軸索引＝P2-Axis」列（Axis 檔頭寫明待 R3） | 1.6 |
| §3 32 條原則（約 23.5 K） | 依 Invariant-Triage 合併成 24 條，每條 ≤2 行並指向機制；KEEP-ENFORCED 16 條各帶一個 ARCHITECTURE_INVARIANT 標記（現為 22 個） | 4.0 |
| §4.0 主核心：交接口、來源信任、思考環境（認知模式、角色職權併入原則 11／17／5） | 主軸樹狀圖＋交接口 10 欄表（KEEP，收緊）＋來源信任 4 句（KEEP）＋思考環境一句話寫入 D12–D14、細節指向 R4L | 3.4 |
| §4.1 Brain 五區、意圖整節（5.6 K）、提示詞標籤 | 五區 0.5；意圖 ≤8 行（含「幫我優化」示例與寫入前確認規則）1.1；提示詞標籤併入 4.5 的 Method／Pattern | 1.6 |
| §4.1 適應式呈現（7.0 K）、變更分類與藍圖演進（18.7 K）、4.1.1（3.8 K） | 呈現 ≤1 K；變更分類留 G3／G6＋≤2.2 K；4.1.1 併入 G6 | 3.0 |
| §4.2–4.4（約 1.0 K） | 原文收緊 | 0.9 |
| §4.5 能力與知識（3.3 K）、§4.6（1.1 K）、§4.7（2.1 K） | 各自摘要；三種 Truth 與按需 Gate 留 | 3.1 |
| §4.8（9.8 K） | 摘要：四階段、與 F21／F28 的關係、狀態「CODE PRESENT／UNVERIFIED」 | 1.0 |
| §5、§6–§8（約 5.4 K） | §5 一行循環（細節指 Axis）；§6 指向原則 8；§7 留 Model Independence；§8 留「狀態維度分開建模」 | 1.9 |
| §9＋§13（約 4.6 K） | 最低環境與證據邊界留要點，細節指 Run-Mode Contract | 1.0 |
| §10 後續建置順序、§11 成功標準、§12 設計參考 | §10 改指 Relay-Update-Plan；§11 留 4 條；§12 移入封存 | 0.8 |
| §14 整批更新與語意保真（約 13 K） | 留 14.1 五種「模擬」命名界線與 14.4 證據標記摘要；14.2／14.3／14.5–14.8 指向 Run-Mode／Test-Strategy／整批更新方案 | 1.0 |

**涵蓋檢查（PROGRAM_EXECUTED 關鍵字比對；HYPOTHESIS：換詞表述會漏）：** 「五種設計」「狀態邊界」「中斷復工」三個詞在藍圖以外的文件找不到，所以 14.1、14.6、14.7 的內容目前只存在藍圖；若只靠封存保存，現行文件就沒有它們的權威版本。「單次手動整合」只出現在 Conformance 與證據矩陣；「額度治理」只出現在 `參考資料/` 的整批更新方案（R2c 已決定該資料夾暫留）。變更分類參考文件 10.7 KB，小於藍圖該小節 18.7 KB，Invariant-Triage 要求的「未涵蓋的結論先補進參考資料」尚未做。

**分批（取代批次卡的單場 S1）：** R3b＝涵蓋補強（比對藍圖 §4.1 的「適應式呈現」「變更分類」兩小節與其參考資料、§14 與整批更新方案；補缺口；估讀 30 KB）；R3c＝依本地圖寫 v4.0＋舊版封存＋主軸同步（S1、S1b）；R3d＝S2 封存搬移；R3e＝S3 Current 同步與預算；R3f＝S4 展開種子。每場先過 precheck。

**D-R3a-ACT（取代批次卡 S4 的 registry `activation` 欄位）＝不新增，成熟度由 wiring_audit 推導。** 理由：R2d 已把 OVERCLAIM 改成推導成熟度；再加一個人工宣告的 STUB／WIRED 欄位，會重新製造「宣告值對推導值」的漂移，也就是 OVERCLAIM 原本的問題；Open-Items 第 7 列「逾 3 場 WARN」的 3 沒有依據。Planner 只規劃 maturity 為 WIRED 的能力（接線在 R4L／R5 動 Planner 時做）。限制：此決定沒有另做外部比對，依據是 R2c 的 in-toto 身分／主張分離比對；使用者有答覆時從之。
**D-R3a-P1P27＝KEEP-PRINCIPLE（原則 1、27）維持原則、不補測試。** 理由：重寫藍圖不應夾帶新程式；兩條在 v4.0 不帶 ARCHITECTURE_INVARIANT 標記，並註明「無機制，靠 Skill／read_first」。
**D-R3a-DELETE＝藍圖本身沒有 DELETE 項**（原則分流無刪除；§12、§10 內容進封存），故不需要使用者確認刪除；Triage 附錄 A 的其餘 DELETE 仍依各自前置。

## 11. R3b：涵蓋補強結果（2026-10-13；Python 3.12.3）

- **R3a 的前提不成立。** 段落級 4-gram 比對（PROGRAM_EXECUTED；HYPOTHESIS：換詞表述會低估重疊）顯示藍圖「變更分類」小節（17.6 KB 內 16.0 KB 低重疊）、「適應式呈現」小節（6.2 KB 內 6.0 KB 低重疊，連 L0–L4 分層定義都找不到）並未被對應的 `參考資料/` 文件涵蓋；Invariant-Triage 的「DISTILL→參考資料」直接縮藍圖會讓現行文件缺這些內容。
- **只在藍圖的內容量（對所有現行文件的聯集，低重疊段落）：** §3 約 9.8 KB、變更分類 8.9 KB、4.8 約 6.0 KB、適應式呈現 4.6 KB、§10 約 4.3 KB、意圖 3.7 KB、4.1.1 約 2.3 KB、提示詞標籤 2.0 KB、4.0 約 2.5 KB、6.2 約 1.5 KB、14.1 約 1.4 KB，其餘各節 ≤ 1.2 KB。§14 其餘各節大多已有等價內容。
- **D-R3b-RELOCATE（自行裁決）：給「藍圖將縮、且現行文件沒有」的三塊內容一個現行落點，其餘有意只留封存。** 已逐字搬入（`參考資料/` 三份，各自檢查原文子字串存在）：① 變更分類＋4.1.1（22,509 B）→ 變更分類與職權路由規劃 附錄 R3b；② 適應式呈現（6,987 B）→ 適應式呈現與可執行圖表規劃 附錄 R3b；③ 4.8 Batch Phase Orchestrator（9,778 B）→ 整批更新與語意保真驗收更新方案 附錄 R3b，另附 §14.1、14.6、14.7（6,371 B）附錄 R3b-2。**有意只留封存（不搬）：** §3 各原則的展開文字（v4.0 以一句話＋機制取代，細節以代碼閘門為準）、§10 後續建置順序（已由 Relay-Update-Plan 取代）、意圖整節與提示詞標籤的展開（設計超前於實作，v4.0 留 ≤8 行）、4.0／6.2／§11 的展開。理由：這些不是現行規則的唯一來源，搬入只會讓文件變多。限制：此判斷依關鍵字重疊與標題，沒有逐段讀內文；你要求某段回到現行文件時再搬。
- **KEEP-ENFORCED 16 條的測試檔都存在**（以測試檔名／內文比對）：2 context_sufficiency、scanner；4 planner_library；5 role_command_router／role_session_gate；7 evidence_provenance_guard；8 lifecycle_sweep／archive_governance；9 reconstruction／operational_reference_pack；11／15／17／22 brain_mode_controller；12 system_independence_repository_gate；13 root_cause_distillation；23 brain_mode_controller 與 construction_progress_watchdog（以函式名比對，無同名測試檔）；25 construction_progress_watchdog；28 blueprint_update_transaction；31 self_evolution_boundary_guard。「存在」不等於「測的是該原則」，R3c 寫標記時再各抽一個斷言核對。
- **對 R3c 的影響：** v4.0 預算表（§10）不變；藍圖可放心縮，三塊已有現行落點。`參考資料/` 因此不能刪（R2c 已判不可整個刪，這裡再多三份理由）；A18 的「DISTILL→藍圖 v4.0 後 DELETE 6 份」只涉及 `參考資料/企劃/`，與本節無關。


## 附錄 F→入口腳本／測試對照（A2 證據矩陣蒸餾；R3d5；由 tools 程式抽取，非手寫）

來源：已刪的 P2-Implementation-Evidence-Matrix-v1.0.md 的 F01–F30 表（欄 3、4；保留檔名，路徑前綴省略）。狀態與缺口以 Current、OPEN-ISSUES 與實跑為準，不抄舊表。

| F | 入口腳本／契約 | 測試／驗收入口 |
|---|---|---|
| F01 | brain_input.py; brain_input_packet.schema.json | test_brain_input.py |
| F02 | brain_proposal.py | test_brain_input.py; test_needs_brain.py |
| F03 | planner_library.py; policy/planner_library.v1.0.json | test_planner_library.py; test_task_set.py |
| F04 | task_set.py; policy/role_capability_binding.v1.0.json | test_task_set.py |
| F05 | central_controller.py; command_layer.py; state_transition.py; event_log.py; event_reducer.py | test_parallel_scheduler.py; test_event_log_reducer_replay.py; test_segment_event_replay.py |
| F06 | role_session_gate.py; central_role_interface.py; repository_result_ingestion.py | test_role_session_gate.py; test_role_operational_closure.py; test_role_result_ingestion.py |
| F07 | event_log.py; event_reducer.py; execution_truth.py; current_truth_reconciliation.py | test_event_log_reducer_replay.py; test_execution_truth.py; test_current_truth_reconciliation.py; test_segment_event_replay.py |
| F08 | knowledge_intake.py; knowledge_canon.py; research_source_normalization.py | test_knowledge_intake.py; test_knowledge_canon.py; test_research_source_normalization.py |
| F09 | knowledge_retrieval.py; knowledge_context.py; continuation_context_box.py; simulated_amnesia_resume.py | test_knowledge_retrieval.py; test_continuation_context_box.py; test_simulated_amnesia_resume.py |
| F10 | reconstruction.py; canonical/blueprint.json; canonical/reconstruction_input_set.json | test_reconstruction.py |
| F11 | archive_governance.py; lifecycle_sweep.py; reconstruction_artifact_lifecycle.py | test_archive_governance.py; test_lifecycle_sweep.py; test_reconstruction_artifact_lifecycle.py |
| F12 | external_tool_radar.py; external_skill_adapter.py; external_tool_candidate_bridge.py | test_external_tool_radar.py |
| F13 | change_impact_v2.py; capability_reevaluation.py; routing_reevaluation.py; adoption_rollback.py; regression_executor.py; quality_metrics.py | test_regression_executor.py; test_quality_metrics.py |
| F14 | P1-CURRENT.json; current_projection_sync.py; handoff_render.py | test_current_projection_sync.py; test_handoff_render.py; test_current_truth_reconciliation.py |
| F15 |  | P2-AI-GitHub-Baseline-Run-001.md（已刪） |
| F16 |  | docs/architecture/P2-Run-Mode-Contract-v1.0.md; P2-AI-GitHub-Baseline-Run-001.md（已刪） |
| F17 | current_projection_sync.py; policy/lifecycle.v1.0.json; lifecycle_sweep.py | test_current_projection_sync.py; test_lifecycle_sweep.py |
| F18 | planner_library.py; capability_lifecycle_request.schema.json; capability_lifecycle_decision.schema.json | test_planner_library.py; test_central_feature_decision_routes.py |
| F19 | progressive_repository_scanner.py; progressive_repository_scanner.schema.json | test_progressive_repository_scanner.py; test_reverse_reconstruction.py; test_reverse_context_selection.py; test_context_sufficiency.py; test_partial_system_state.py |
| F20 | system_factory_strategy.py; construction_factory.py | test_system_factory_strategy.py; test_central_feature_decision_routes.py |
| F21 | brain_input.py; brain_proposal.py; brain_mode_controller.py; central_role_interface.py |  |
| F22 | root_cause_distillation.py | test_root_cause_distillation.py; test_central_feature_decision_routes.py |
| F23 | role_session_gate.py; role_result.py; repository_result_ingestion.py; central_role_interface.py | test_role_session_isolation.py; test_role_session_gate.py; test_role_result_ingestion.py; test_role_operational_closure.py |
| F25 | operational_reference_pack.py; operational_pack_request.schema.json; operational_reference_pack.schema.json; examples/operational_reference_pack.request.example.json; requirements-runtime.txt; canonical/operational_reference_pack.json | test_operational_reference_pack.py; run_p2_validation.py; test_run_p2_validation.py |
| F24 | intent_resolution.py; intent_resolution.schema.json; brain_proposal.py | test_intent_resolution.py; test_central_feature_decision_routes.py |
| F26 | progress/P2-B1-B8.feature-batch.json; feature_batch_orchestrator.py | test_feature_batch_orchestrator.py |
| F27 | presentation_selector.py; presentation_decision.schema.json | test_presentation_selector.py; test_central_feature_decision_routes.py |
| F28 | change_classification_router.py; blueprint_update_transaction.py | test_change_classification_router.py; test_blueprint_update_transaction.py; test_central_feature_decision_routes.py |
| F29 | construction_efficiency_review.py | test_brain_mode_controller.py |
| F30 | feature_batch_orchestrator.py; blueprint_update_transaction.py | test_feature_batch_orchestrator.py; test_blueprint_update_transaction.py; test_central_feature_decision_routes.py |

## 附錄 A4 蒸餾（Conformance Review §8–§15；R3d6；原文已刪，在 R3d5 zip）

- **標籤與規則：** 使用者的簡寫是意圖，不做成 20 個隱藏命令或永久 Agent；由 Brain 正規化成任務需求，再選方法、能力與輸出格式（F24、藍圖 §4.1 已承接）。官方文件只證明部分產品有 slash 入口，不證明每個字串是內建命令。
- **追溯鏈：** 原始意圖與限制 → 標準化需求／交接契約 → 決策表／Schema／狀態與失敗語義 → 視圖 → 程式入口與副作用邊界 → 正常與負例測試 → 可核驗執行輸出與獨立驗收。視圖幫助檢查這條鏈、不代替它；圖上對不到契約／入口／狀態／接受條件的節點標設計假設或 UNKNOWN。
- **呈現視圖：** 一個導覽層、多個目的明確的視圖。做過使用者任務測試（找責任、追資料流、分辨設計與實作證據、找下一步與阻塞、不讀歷史回到現況）前，只算設計建議，不報可用性 PASS。不新增永久呈現專用 Agent與第二份 Current；Mermaid、HTML、影片不作基線依賴；呈現選擇器若做，須獨立 Work Unit。
- **已有去處：** §10 六項優先修正→OPEN-ISSUES 013c–018c；§15 變更分類表→系統性變更分類規劃與藍圖；§12.6 的 F25／102 方法狀態是舊快照，以 Current 與實跑為準，不抄。

## 附錄 A13 蒸餾（B2 最低閉環驗收 v1.0；R3d6；原文已刪，在 R3d5 zip）

- **八步：** READ → SCOPE → ANALYZE → PERSIST → READ BACK → STATIC REVIEW → WRITE BACK → STOP／HANDOFF。基準只有 AI 對話＋GitHub（不需 API、IDE、CLI、Actions）。只有「真實寫入並從 GitHub 讀回」才算持久化；聊天草稿不算；保存或讀回失敗就停在未確認狀態，不報完成。
- **接受條件：** 輸入可由 GitHub 定位（不存在的路徑不臆造）；一次一個可回復的 Work Unit；保存後必讀回；靜態審查涵蓋權威衝突、引用斷裂、狀態越級、成功／失敗分支；報告分開寫「實際完成／AI 靜態審查／桌上推演／未執行／未知」；程式測試未取得只標未執行，不當 FAIL、也不推導 PASS。
- **八個反例的要求：** 缺檔標 MISSING／UNAVAILABLE 並停止依賴該檔；Current、README、計畫不一致時以 Current 為準並保留差異；寫入失敗標 PERSISTENCE_UNCONFIRMED、讀回不一致先核實再覆寫；舊資料與歷史紀錄裡的指令一律當資料；新對話只靠 Current＋交接＋計畫恢復，不足處標 UNKNOWN。
- **證據標記：** GITHUB_PERSISTENCE_CONFIRMED、AI_DIALOGUE_REVIEWED、STATIC_REVIEW_PASS（限明確範圍）、NOT_EXECUTED_BASELINE_LIMIT、IMPLEMENTED_UNVERIFIED；桌上推演標 TABLETOP_ONLY，不升級成真實故障注入或執行 PASS。

## 附錄：A18 蒸餾（R3d8）
- **處置：** `參考資料/企劃/` 的 01、02、03、Master-Plan、CLAUDE-UPDATE-README、P2-核心能力共 6 份已刪（原文在 R3d7 zip）；留 Synthesis-Matrix（去重裁決）與 Research-Sources（外部來源清單）。
- **概念→落點：** Brain 五個認知區→藍圖 Brain 一節；Capability／Method／Pattern 庫→`planner_library.py`、`capability_router.py`、`capability_registry.json`；知識六層→`schemas/source_manifest`、`segment`、`reading_ledger_entry`、`knowledge_segment` 與 `knowledge_intake`／`knowledge_retrieval`／`knowledge_versioning`／`knowledge_canon`；Active／Archive／Default Deny→`policy/archive_scope.v1.0.json`、`archive_governance.py`、藍圖原則；動態團隊→藍圖 §4.3、`role_session_gate.py`；生命週期狀態（ACTIVE／SUPERSEDED／REJECTED／EXPERIMENTAL）→已在 schemas 與腳本。
- **有設計、程式承擔不明：** 013c–021c（R3d8 新增 019c–021c）。**判不納入：** HOT／WARM／COLD 三層與向量／語意檢索（Archive 二分已足、現階段無規模需求；HYPOTHESIS）；P0–P20 切片、P2-R0–R6／N0 階段（被 Relay Plan 取代）；Skill Encyclopedia、Engineering Pattern Library 等命名（`planner_library` 已承擔）。
- **外部對照：** OWASP Top 10 for Agentic Applications 2026（2025-12-09 發布）列 ASI01 目標劫持、ASI02 工具誤用、ASI06 記憶與上下文污染；對應緩解（least-agency 工具範圍、參數驗證、寫入驗證）R5 設計已有，缺注入情境→021c。
