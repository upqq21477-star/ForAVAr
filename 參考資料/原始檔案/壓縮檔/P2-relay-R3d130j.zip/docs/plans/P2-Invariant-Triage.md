# P2 原則分流（R2a；DOC_ONLY；非權威，待使用者確認後才動藍圖）

來源：藍圖 §3 全 32 條（約 23.5 KB）。「強制機制」欄＝以關鍵字比對 tests／scripts 的結果（HYPOTHESIS：漏掉別名與動態呼叫，「未找到」不等於沒有）。未讀測試內文，未實跑。

## 1. 32 條原則
| ID | 一句話 | 現有強制機制 | 處置 |
| --- | --- | --- | --- |
| 1 | Current-first，不重建歷史 | 未找到（關鍵字）；靠 Skill／read_first | KEEP-PRINCIPLE |
| 2 | 最小充分資料 | context_sufficiency、scanner | KEEP-ENFORCED |
| 3 | 保留價值不保留慣性 | 無 | MERGE→G1 |
| 4 | Unknown≠Missing | planner_library（INFORMATION_GAP，部分） | KEEP-ENFORCED |
| 5 | 職權先於舊模組 | role_capability_binding、role_command_router、role_session_gate | KEEP-ENFORCED |
| 6 | Current 只有一份 | current_projection_sync | MERGE→G2 |
| 7 | 證據不得越級 | evidence_provenance_guard | KEEP-ENFORCED |
| 8 | 資料要能退場 | lifecycle_sweep、archive_governance | KEEP-ENFORCED |
| 9 | 最低環境＝對話＋GitHub | reconstruction、operational_reference_pack（無 API 可運行） | KEEP-ENFORCED |
| 10 | P2 原生思考優先 | 無 | MERGE→G1 |
| 11 | 思考與施工分隔 | brain_mode_controller | KEEP-ENFORCED |
| 12 | 系統獨立、契約交接 | system_independence_*gate | KEEP-ENFORCED |
| 13 | 從根因改進機制 | root_cause_distillation | KEEP-ENFORCED |
| 14 | 變更先分類 | change_classification_router | MERGE→G3 |
| 15 | 免費額度與成本封閉 | brain_mode_controller（cost_authority） | KEEP-ENFORCED |
| 16 | 整批規劃、施工、收口 | feature_batch_orchestrator、watchdog | MERGE→G4 |
| 17 | 常態認知監督 | brain_mode_controller（事件來源檢查） | KEEP-ENFORCED |
| 18 | 功能先行、整批驗收 | brain_mode_controller | MERGE→G4 |
| 19 | 驗收證據鏈不可由旗標替代 | acceptance_context（6 測試檔） | MERGE→G5 |
| 20 | 穩定契約指紋綁定 | 未找到（關鍵字）；與 19 同機制 | MERGE→G5 |
| 21 | 工作單位身份解析 | run_p2_validation、runtime_interface | MERGE→G5 |
| 22 | 研究須有來源與反證 | brain_mode_controller | KEEP-ENFORCED |
| 23 | 事件觸發式健康回溯 | build_construction_health_review | KEEP-ENFORCED |
| 24 | 唯一藍圖與規劃蒸餾 | blueprint_update_transaction | MERGE→G3 |
| 25 | 計量單位與差異重算 | NOT_MEASURED 檢查、watchdog（部分） | KEEP-ENFORCED |
| 26 | 四階段整批更新 | actions_execution_*、blueprint_update_transaction | MERGE→G4 |
| 27 | 風險導向比較決策 | 未找到（關鍵字） | KEEP-PRINCIPLE |
| 28 | 使用者紅線實測解鎖 | blueprint_update_transaction＋redline policy | KEEP-ENFORCED |
| 29 | 進度感知藍圖交易 | blueprint_update_transaction | MERGE→G6 |
| 30 | 每種資料只有一個權威 | reconstruction（擁有權） | MERGE→G2 |
| 31 | 核心原則受保護 | self_evolution_boundary_guard（部分） | KEEP-ENFORCED |
| 32 | 需求排序與受控交易 | blueprint_update_transaction | MERGE→G6 |

## 2. 合併組（S：互相重複者）
- G1＝3＋10 價值取向（保留價值；P2 原生優先）。G2＝6＋30 唯一權威來源。G3＝14＋24 變更先分類、規劃先蒸餾。
- G4＝16＋18＋26 整批規劃→功能先行→四階段驗收（同一套批次紀律）。G5＝19＋20＋21 最終驗收證據鏈與身份綁定（B2.2 專屬細節移到 Run-Mode Contract）。G6＝29＋32 藍圖更新交易。
- 結果：32→24 條（KEEP-ENFORCED 16、KEEP-PRINCIPLE 2、合併組 6）。每條改一句話＋指向機制，細節搬到 Run-Mode Contract。粗估 §3 由約 23.5 KB 降到約 8 KB（HYPOTHESIS，未實作）。
- 無 DELETE 項，故無待使用者確認的刪除；KEEP-PRINCIPLE（1、27）缺機制，R3 時決定補測試或維持原則。

## 3. 藍圖 11 個 #### 小節（HYPOTHESIS：依標題、大小與和 §3 重疊判斷，內文未讀）
| ID | 小節 | 約 KB | 判定 |
| --- | --- | --- | --- |
| 1 | 認知模式與施工模式切換 | 2.3 | MERGE→§3.17（事件規則重複） |
| 2 | 思考環境與施工環境的邊界 | 1.0 | MERGE→§3.11 |
| 3 | 乾淨交接口最小契約欄位 | 1.9 | KEEP（無對應原則） |
| 4 | 角色職權原則 | 1.6 | MERGE→§3.5 |
| 5 | 來源信任、Scope 與權限 | 1.1 | KEEP（唯一涉及來源信任） |
| 6 | Brain 最小工作模型 | 0.8 | KEEP |
| 7 | 意圖理解與最小化澄清 | 5.6 | KEEP，縮減（實作僅關鍵字＋三選項，設計超前） |
| 8 | 提示詞標籤與溝通準則 | 2.6 | KEEP，讀後可能 MERGE→7 |
| 9 | 適應式呈現與圖表即程式碼 | 7.0 | DISTILL→參考資料/P2-適應式呈現…（藍圖留 ≤1 KB） |
| 10 | 系統性變更分類與藍圖演進 | 18.7 | DISTILL→參考資料/P2-系統性變更分類…（藍圖留 G3／G6＋≤3 KB） |
| 11 | 4.1.1 需求優先級與施工順序 | 3.8 | MERGE→G6（§3.32 重疊） |

搬移 9、10 前，先逐段比對參考資料是否已涵蓋；未涵蓋的結論先補進參考資料再縮藍圖。
