# P2｜Code-First Execution & Distilled Operational Pack

**版本：** v1.7  
**狀態：** BUILDER IMPLEMENTED / BRAIN MODE CONTROLLER WIRED / FINAL 102-METHOD BATCH NOT EXECUTED / END-TO-END NOT VERIFIED  
**目的：** 把 P2 的功能規劃變成可執行、可重複、可驗收的機械流程；每次正常運作只讀當前有效、已蒸餾且有明確來源的作業依據，不依賴歷史聊天、舊交接鏈或全庫搜尋。  
**狀態權威：** 過渡期仍是唯一的 `P1-CURRENT.json`。本計畫新增的 operational pack 是由 Current 與指定權威輸入推導的快取／運行包，不是第二份 Current，也不能反向覆蓋 Current。**施工準則：** P2 架構與共用施工規則只以 Current 的 `p2_target_blueprint_ref` 所指唯一藍圖為準；本計畫保留 Builder／Pack 的操作細節，不能作為替代藍圖。會議、研究或臨時規劃若產生可重用規則，必須先蒸餾並保存至唯一藍圖，再同步本計畫的執行細節。

---

## 1. 不可妥協的執行規則

1. **程式負責確定性的事情。** Hash、正規化、分段、schema 驗證、範圍／權限檢查、狀態轉移、覆蓋率、去重、預算、完整性、冪等寫入及接受條件比對，必須由程式完成，不應每輪要求 LLM 重新推理一遍。
2. **AI 只負責不能可靠地純機械化的語義判斷。** 例如意圖解讀、反例生成、主張是否真的受證據支持、哪些研究結論值得蒸餾。AI 輸出先是候選；程式檢查結構和證據鏈，必要時由獨立 Verifier／使用者確認後才能提升為有效依據。
3. **正常運行採顯式輸入，不掃全庫。** 每個 Work Unit 必須提供明確的 Current、任務、契約、所需資料 ID、能力卡及驗收條件。禁止為找單一指定物件而遞迴搜尋整個 Repository、全部 checkpoints、舊交接或 Git History。
4. **唯一運行依據是蒸餾後的 Operational Pack。** Pack 包含實際可使用的規則／卡片／必要摘要，而不只是指向舊文件的長串路徑。來源 ID、位置及 hash 只用來驗證來源與追溯，不代表正常運行要重讀所有來源全文。
5. **每一輪都覆寫當前有效內容，不追加歷程。** 同一份 Operational Pack 以驗證後的新內容取代舊內容。GitHub commit 歷史可供儲存層回復，但正常 Runtime 不讀取它來重建日常 Context。原始研究／失敗材料若有保留價值，進獨立 Cold Archive 並預設拒讀；其餘 Dispose。
6. **輸入不完整就阻擋，不靠猜測補全。** 必要來源缺失、hash 不一致、狀態過期、衝突未解、預算超限或接受條件不符時，產生明確的 BLOCKED／INCOMPLETE／STALE／INTEGRITY_FAILED／BUDGET_EXCEEDED 與原因碼。
7. **冪等比重試重要。** 相同的標準化輸入、契約版本與程式版本重跑，必須產生相同的 Pack Hash，且不得複製資料或重複執行具副作用的動作。對外部副作用需有穩定 Operation ID、重試上限和明確終態。
8. **不把文件存在當作運行證據。** 區分 SOURCE_PRESENT、CALL_PATH_CONFIRMED、TEST_EXECUTED_PASS、ACCEPTANCE_PASS、OBSERVED_RUNTIME。不能實際執行時只報告已完成的靜態檢查／GitHub 讀回，不可把測試結果推想成 PASS。
9. **整批工作與有界驗收。** 以單一 Work Unit 一次界定範圍、完整變更集合、測試與接受條件；相關程式／測試／Schema 修改批次完成後，做一次完整驗收，不設逐步驗收閘門。失敗時先讀完整報告並把同輪所有失敗按根因分組，一次修補後整批重驗；一般最多兩次完整執行，第二次仍失敗就停止重試並重新診斷。安全、成本、權限與不可逆副作用的硬性閘門不得省略。此規則是工作規劃契約，不代表 Brain caller 已接通。

### 落實期局部案例模擬與整批階段邊界

施工時使用簡易、有限、可執行的局部案例模擬檢查新程式／改動是否有設計缺陷與明顯錯誤；每項功能按接受條件選擇正常路徑、最相關負例及必要邊界／狀態／權限情境，記錄輸入、預期輸出、實際輸出和判定。不要求每次 patch 重跑正式全套測試，也不得只靠 AI 語言推演就記為執行通過。局部模擬失敗時先修正並重跑受影響案例；若發現需求、架構或批次範圍問題，回到 THINKING／RESEARCH／PLANNING。只有批次所有功能的局部案例都通過，才可整批進入 CLOSURE；完整回歸／正式 Runner／Integration 延後至所有閉環接通後的 FINAL_TEST。這項執行細節服從唯一藍圖 §3.25／§4.8，不能建立第二份階段狀態權威。

## 2. 建議的唯一正常運行資料流

```text
唯一 Current + 單一 Active Work Unit
                |
                v
        明確輸入 Ref 清單
 (Blueprint / Contract / Capability Cards /
  必要已接受 Claim / 當前資料位置)
                |
                v
   直接讀取指定來源並驗證 hash / schema
                |
                v
    BOUNDED OPERATIONAL CONTEXT / PACK
                |
                v
    Brain Proposal（只提出有限候選）
                |
                v
 Central 驗契約、Scope、權限、狀態版本
                |
                v
       Executor 執行純機械步驟
                |
                v
      獨立 Assurance / Acceptance
                |
      +---------+---------+
      |                   |
    BLOCK               PASS
      |                   |
記錄原因碼／最小缺口    蒸餾可重用結論
停止或定點補資料           |
                          v
             驗證後覆寫 Current Pack
             更新唯一 Current 的必要欄位
             清除不再需要的中間資料
```

「歷史查詢」是旁路，不是上述正常資料流的一部分：只有有明確目的與授權的 RECOVERY／FORENSICS／HISTORICAL_RESEARCH／RECONSTRUCTION_SUPPORT，才能走 ArchiveAccess，回傳有限材料；取回結果先視為 UNTRUSTED_CANDIDATE，不能直接成為 Canonical Truth。

## 3. Operational Pack：要保存的實際內容

建議只建立一份現行檔案：`P1-Central-Control/canonical/operational_reference_pack.json`，搭配一份 schema 和一個 Builder。這是初步落地位置；在 P2 接管狀態權威之前不得因此新增第二份 Current。Pack 必須可由權威資料重建，且驗證後原位覆寫，不累積 `pack-v1`、`pack-v2` 等常駐歷史檔。

Pack 的欄位是**實際運行資料**，不是描述性口號：

- 身分與新鮮度：schema_version、pack_id、builder_version、current_fingerprint、blueprint_ref／version／hash、生成來源 hash。
- 單一當前工作：active_work_unit、goal、scope、constraints、allowed_actions、stop_conditions、next_action。
- 具體執行內容：被選中的 Capability／Method／Pattern Cards、已核准且當前有效的操作規則、必要的輸入欄位、輸出 schema、錯誤碼與回退步驟。
- 必要的知識依據：已接受 Claim 的蒸餾文字、適用條件／失效條件、Evidence／Source／Segment refs、版本／有效時間、未解衝突與未知；不嵌入全部歷史版本。
- 執行及驗收：required_refs、required_coverage、expected_outputs、acceptance_checks、retry_limit、resource_budget、最後可執行的下一步。
- 完整性：pack_content_hash、input_fingerprint、生成狀態、明確省略項與阻塞原因。

Pack 不能只是指標清單，也不能複製整份企劃／對話。每項規則需能被執行者直接採用：`purpose + trigger + inputs + steps + outputs + constraints + failure_codes + acceptance_checks`。來源引用和 hash 是證據鏈，並非要求 Runtime 把來源內容一律讀回。

## 4. 蒸餾協定：十輪資料如何變成一份乾淨運行依據

1. 收集當前工作產生的必要原始片段、觀察、結果與來源定位；不將歷輪完整對話併回下一輪 Context。
2. 機械步驟先做來源識別、hash、正規化、切段、去重、必要段落覆蓋檢查。
3. AI 對重要發現提出蒸餾候選，必須附：主張／規則、適用範圍、觸發條件、必要輸入、明確步驟、限制／反例、驗收方式、來源／證據引用、未知與信心水平（若有校準依據）。
4. 獨立驗證來源支持度、衝突、版本、時間有效性與是否只是個案。不能把相似摘要當作相互獨立證據，也不能將推論標為已確認。
5. 給候選明確處置：PROMOTE_TO_OPERATIONAL_PACK、KEEP_PROJECT_ONLY、ARCHIVE_RAW、DISPOSE。只有有可重複操作價值且通過條件的結論可以進 Pack。
6. Pack Builder 只從唯一 Current、當前 Blueprint／Contract、選定的 Capability Cards 及明確核准的 Canonical Claims 生成 Pack；不得從舊交接、全量 History 或 Git 提交紀錄推測目前狀態。
7. 重新計算 fingerprint／hash，跑 schema、引用、Coverage、Scope、budgets、acceptance rules。任一必要條件不通過即 BLOCKED，保留舊的有效 Pack，不用不完整候選覆寫。
8. 驗證通過後原位覆寫 Pack，更新唯一 Current 中必要的有效指標與下一步。原始臨時資料按政策 Archive 或 Dispose。
9. 同樣的輸入再次執行，輸出 hash 不變；資料來源或規則變更時產生新 fingerprint，只重建受影響的 Pack，不重讀無關資料。
10. Runtime 只讀現行 Pack 與指定的即時輸入。若 fingerprint 過期，回 PACK_STALE 並用其明確來源清單重建；不允許自動退回全庫搜尋。

**重要限制：** 機械程式可以做 hash、去重、schema、引用與流程 Gate；「這項結論是否正確、是否適用、是否值得提升為可重用規則」仍是語義判斷，必須經有來源的候選、核准／驗收及可推翻記錄，不能假裝用字串相似度便完成蒸餾。

## 5. 目前程式對帳：先整合，禁止重造

| 目前程式／物件 | 可重用的確定性工作 | Code-first 下一步 |
|---|---|---|
| `scripts/knowledge_intake.py` | source hash、正規化、切段、Ledger、必要 Segment Coverage | 確認 Required／Optional／Derived／Blocked dependency 契約；將錯誤 Coverage 阻擋接至唯一工作入口 |
| `scripts/knowledge_canon.py` | Observation→Evidence→Claim 的來源鏈與升格 Gate | 建立可執行串接測試，證明 UNKNOWN／INFERENCE／CONFLICT 不會被錯誤升格 |
| `scripts/knowledge_versioning.py` | 版本、supersedes、衝突與有效時間 | 確認有效版本取用不必載入所有舊版本內容；完整歷史只供明確查詢 |
| `scripts/knowledge_retrieval.py` | Exact／Structural retrieval、Scope、結果上限、快照完整性 | 正常 Runtime 只允許明確選定 refs；保持 Archive default-deny，不以全量搜尋作 fallback |
| `scripts/archive_governance.py` | 資產生命週期、授權、最小取回、存取紀錄、hash | 封存原始材料與可運行 Pack 分離；回收結果先作不可信候選 |
| `scripts/knowledge_context.py` | 有預算限制的 Context 組裝、指令／資料隔離、狀態報告 | 先前測試 commit 的 Knowledge Retrieval 套件（18 項）實際通過；後續程式／測試修補仍須在當前版本重新驗收，正式 Brain caller 尚未確認 |
| `scripts/continuation_context_box.py` | 有 hash 的恢復封包、Current fingerprint、無 transient history 的重建契約 | 先前測試 commit 的 Continuation Context 套件（11 項）實際通過；後續程式／測試修補仍須在當前版本重新驗收。現存舊 checkpoint 因缺欄位刻意不列入 Active 索引 |
| `P1-CURRENT.json` | 過渡期唯一執行狀態權威 | 只從當前 Active Work／明確 refs 決定要讀取哪些文件；不可把整個 `read_first` 當作每次無條件全載清單 |
| `context_budget_registry.json` | 既有 Context 目標／硬上限及超限規則 | 針對各類 Work Unit 實測必要上下文大小；不得因上限很大就默許傳送龐大資料 |

先前完整執行曾在 commit `3c6e92ebca1501cfdad416391b5a953f706d8a62` 上實際跑過五組回歸：Continuation Context 的 11 項與 Knowledge Retrieval 的 18 項均通過；這只證明該 commit／該環境下的結果。後續補丁與測試變更尚未在最新版本重跑，不能沿用舊版 PASS 作為最新版本證據。
- `continuation_context_box.locate()` 改用 `continuation_box_index.json` 直接查找並驗證指定目標，不再用 `rglob`；舊 M32 checkpoint 缺少新契約必填的 Current fingerprint，故不放入 Active 索引。
- `knowledge_context.status_report()` 不讀取 `store.history(ref)`，並移除一般輸出中的 versions 欄位；目前 Claim 仍需維持 Evidence→Observation→Segment／Source 可追溯鏈。

### F25 程式落地與最新驗收狀態

已新增：
- `P1-Central-Control/scripts/operational_reference_pack.py`：顯式請求→Bounded Operational Pack，固定來源清單、Current 最小投影、Current fingerprint、來源 SHA-256、Provenance closure、步驟／輸入／輸出預算、stale verification 與原子寫入。
- `schemas/operational_pack_request.schema.json` 與 `schemas/operational_reference_pack.schema.json`：分別約束輸入請求和實際輸出包。
- `examples/operational_reference_pack.request.example.json`：一份明確的範例請求，不是 Current、不是已啟用的 Pack，也沒有自動寫入 canonical。
- `tests/test_operational_reference_pack.py`：35 個測試，涵蓋同輸入決定性、冪等寫入、Current／來源漂移、必要／選擇性資料缺失、路徑穿越、未知 provenance、預算超限與阻止覆寫 Current，且只允許正式 canonical Pack 或隔離暫存 Pack 輸出；Runner 的 report writer 另以實際 reports 子樹與 symlink 檢查限制寫入。

**最新驗收事實：** commit `3c6e92ebca1501cfdad416391b5a953f706d8a62` 已以 Python 3.11.13 執行全部 82 個預期方法，但 Operational Pack 35 項中有 3 個斷言失敗，故整體為 `SIMULATION_FAIL`／exit 2；其後修補 commits `b2d07b3b87d120072d35e2d3d68990c36880e558`、`9902a092c2f01efcc3e64f76a6b2fab806cc0dd4`、`317d1395776fd0269b4efbeb48641c04dc234412` 尚未重驗。尚未在 canonical 位置生成現行 Pack，也尚未證明正式 caller 與跨模組端到端閉環；不得宣稱 CODE_LOOP_PASS。

另須審核可重建環境的依賴封閉性：Knowledge／Pack 使用 `jsonschema`、部分 Knowledge 模組使用 `referencing` 等第三方函式庫，已由 `P1-Central-Control/requirements-runtime.txt` 固定可執行模式依賴。此前 commit `3c6e92ebca1501cfdad416391b5a953f706d8a62` 已在 Python 3.11.13 環境實際核對 pinned dependencies 為 `MATCH` 並執行五組測試；後續修補版本仍須重新驗收。此檔不屬 AI＋GitHub 文件操作基線的前置。

## 6. 最小可運行閉環與實作順序

### Slice 0 — 唯一入口與可重現環境
- 明確唯一 Current、單一 Active Work Unit、程式／Schema 版本、必要相依套件及實際執行載體。
- 程式入口必須接受顯式輸入參數，不自行掃描 Repository 來猜要做什麼。
- 結果含 operation_id、input_hash、output_hash、status、reason_codes、evidence_refs。
- 完成條件：同一輸入可重跑、結果 hash 一致、相依環境可重建、未提供必要輸入就明確阻擋。

### Slice 1 — Source → Segment → Coverage
- 用現有 B1 程式與 schema；明確 REQUIRED／OPTIONAL／DERIVED／BLOCKED_BY_DEPENDENCY 契約。
- 完成條件：缺少 REQUIRED Segment 必定 INCOMPLETE；OPTIONAL 缺失不阻擋；同一輸入產生同一 hash；變更來源生成新 hash；不靠 AI 自述覆蓋率。

### Slice 2 — Observation → Evidence → Claim
- 用現有 B2 程式，不重寫平行知識庫。
- 完成條件：每個 CANONICAL Claim 都可追溯至 Evidence→Segment→Source；未讀、無引用、錯誤引用、未解衝突和未核准的候選都被程式拒絕或保持候選狀態。

### Slice 3 — Current Knowledge → Operational Pack
- 新增單一 Pack Schema／Builder，僅讀明確允許的必要輸入與已核准 Claims。
- 完成條件：Pack 可離線重建；不包含完整歷史／完整對話；相同輸入 byte-stable；必要來源或 hash 不符時阻止覆寫；Run-time 可直接消費 Pack 的步驟、I/O、限制與 Gate。

### Slice 4 — Context／Handoff 直接查找
- 移除無界的遞迴搜尋與預設歷史內容注入；改由 ID 索引／確定性 locator 及 Current fingerprint 控制。
- 完成條件：指定一個 ID 只讀該 ID 的檔案／記錄；輸入 Pack 過期時顯示 STALE 並列出精確缺口；不因找不到就搜尋全庫／全歷史。

### Slice 5 — 執行、驗收、蒸餾、覆寫
- Central 驗權限、狀態 revision、輸入契約與接受條件；Executor 只執行允許範圍；Verifier 與產生結果的程式／角色分離。
- 只有驗收通過的有效結果能更新 Pack／Current；失敗時保留前一份有效 Pack、記錄最小原因碼，停止或進行定點診斷。
- 完成條件：重跑不重複副作用、不重複輸出、Current 無雙重權威；一次性 Trace 不進下一輪 Context。

### Slice 6 — Archive／重建／模型替換
- 完成 explicit Archive Query gate、最小回傳、hash／來源核對、蒸餾後回流契約。
- 移除非必要 Active 材料後，只用 Reconstruction Input Set、Blueprint、Code、Schema、Contract 及有效 Pack 重建。
- 完成條件：Amnesia／Context Reset、Coverage Failure、False Promotion、Conflict Injection、Temporal Regression、Archive Leakage、Skill／Tool Poisoning、Runner Failure、Model Replacement 均有測試入口和清楚結果。
- 未跑 Clean Build 或行為測試時，不能宣稱這一切已完成。

### Active Work 與 Active Construction Packet 都必須綁定 Current

每個 Pack 必須保留明確的 `request_ref` 與 `request_fingerprint`；建置時確認檔案內容和傳入 request 一致；Verify 重新讀取該 request，阻擋 `PACK_STALE_REQUEST`，並重算 `input_fingerprint`。Writer 會保護 `request_ref`，禁止 Pack 輸出覆寫它。

Builder 不接受 request 自己杜撰一份操作契約。request 的 `active_work_ref` 必須同時列於 `source_refs`、必須為 required，且必須與 `P1-CURRENT.json` 中 `implementation_control.active_work_packet` 完全相同。Builder 讀取這一個明確檔案，以 `operational_work_unit.schema.json` 驗證；`work_id`／`work_unit` 必須與 Current 的 stage／work unit 一致。Pack 的 `active_work` 步驟直接來自該 Work Packet 的 `operational_contract`。所有 path-like `required_inputs` 都必須出現在已宣告且實際納入的 manifest，不會退回檔名搜尋或歷史查找。Verify 階段再次對照 Current 指標、Work Packet ID、契約內容與步驟數；不一致即 BLOCK。

### F25 Builder 的 CLI 契約（修補後版本尚待重驗）

範例請求僅供確認契約，不會因為存在就自動成為 Active Pack。可重現環境中的預定操作順序：

```bash
python3 P1-Central-Control/scripts/operational_reference_pack.py build \
  --request P1-Central-Control/examples/operational_reference_pack.request.example.json \
  --check-only

python3 P1-Central-Control/scripts/operational_reference_pack.py build \
  --request P1-Central-Control/examples/operational_reference_pack.request.example.json

python3 P1-Central-Control/scripts/operational_reference_pack.py verify \
  --pack P1-Central-Control/canonical/operational_reference_pack.json
```

第一個命令只驗證請求與建立 Pack 的預算結果，不寫檔；第二個才會原子覆寫唯一衍生輸出；第三個直接檢查 Current fingerprint 與明確 manifest 裡的來源 hash。這三個命令在可重現環境實際執行並產生可讀回結果前，狀態一律是 NOT_EXECUTED；不得從程式入口存在或 JSON Schema 可解析推導 PASS。若範例內容不適合當前工作，應先建立新的明確請求，而不是改寫 Current 或從舊交接自動推導 Active 任務。

### 測試執行入口

若使用者指定 `--report` 而最終報告無法保存，Runner 必須先將頂層狀態改為 `REPORT_WRITE_FAIL`，保留原驗收狀態／原因／細節於 `validation_status_before_report_write`、`validation_reason_code_before_report_write`、`validation_detail_before_report_write`，再將報告保存失敗寫入新的 `reason_code`／`detail`；以非零退出後才輸出結果，不可先輸出 PASS 再以保存錯誤結束。

本計畫中的離線測試入口是 `P1-Central-Control/scripts/run_p2_validation.py`；整批 workflow 的設計權威則為唯一藍圖 v2.3 §14 與 `參考資料/P2-整批更新與語意保真驗收更新方案-v1.0.md`。兩者用途不同：Runner 的 `--mode simulation` 是程式測試模式，不等於 AI 對話的 `AI_SEMANTIC_SIMULATION_PASS`。 Runner 會先用 `P1-Central-Control/schemas/p1_current.schema.json` 驗證實際 Current，再檢查 pinned dependencies、Active Work／Construction／Blueprint 和明列來源；Current 不合規就先 BLOCK，不啟動測試。它另以 `tests/test_run_p2_validation.py`（15 個測試，含測試方法計數自稽核、Current schema preflight、無效報告路徑（路徑穿越、symlink、目標目錄、非目錄中間層）禁止副作用）測試自身的摘要解析、精確依賴鎖、路徑限制和失敗退出碼。每個套件輸出的 `Ran N tests` 必須等於預期數，不允許只因退出碼為 0 就宣稱測試完整。Runner 現也逐階段核對 Pack CLI 的語意狀態：check-only=`READY` 且 `write_performed=false`、temporary build=`WRITTEN`、verify=`VERIFIED`、冪等重建=`UNCHANGED`、canonical build 僅允許 `WRITTEN`／`UNCHANGED`。即使 subprocess 退出碼為 0，狀態不符也會阻擋並分類為 `SIMULATION_FAIL`／`INTEGRATION_FAIL`；並將對應 step 標記為 `RESULT_CONTRACT_FAIL`，另保留真實子程序結果 `process_status`、failure_class、reason_code 與 detail，避免單一 step 因 exit code 0 仍顯示 PASS。若程序退出碼為 0、JSON 卻回傳 `status=BLOCKED`，仍須依預期階段狀態判作 `SIMULATION_FAIL`／`INTEGRATION_FAIL`，並保留 CLI 自帶的 reason_code／detail。零退出碼但輸出不是有效 JSON 或不是 JSON 物件時，也必須走相同的 per-step `RESULT_CONTRACT_FAIL` 路徑。所有 CLI JSON 都必須帶有非空字串 `status`；缺少、空字串、list／object 型別狀態皆必須分類為階段契約失敗。此補強的程式與既有 15-method Runner 測試仍為 PATCHED_UNVERIFIED／NOT_EXECUTED。先執行 `--mode simulation`：七個回歸套件（11／18／35／3／15／15／5，共 102 個預期方法）+ 真實 repo 的非寫入式 `build --check-only`，不得寫入 canonical。只有結果為 `SIMULATION_PASS` 才執行 `--mode integration`；正式 Pack promotion 的 `canonical_pack_write_outcome` 必須保持 `NOT_ATTEMPTED` → `UNKNOWN` → `WRITTEN`／`UNCHANGED`；只有解析出契約有效結果才能將 `canonical_pack_write_occurred` 設為 true／false，程序失敗或輸出不合規時不可把未知誤寫成 false。由於 `canonical_pack_write_occurred` 變為 nullable 且新增 `canonical_pack_write_outcome`，Runner 回報的 `report_schema_version` 必須為 `2.1`（包含 canonical 寫入三態、canonical Pack SHA-256、cycle_gate_evidence 與穩定契約指紋綁定），並由既有 Runner 契約測試覆蓋。後者重新跑測試，在短生命週期暫存目錄執行 build／verify／冪等重建，通過後才寫入唯一 canonical Pack，並再次 verify／確認 `UNCHANGED`。詳細的證據邊界與失敗分類見 [P2 Test Strategy and Free Execution Paths](P2-Test-Strategy-and-Free-Execution-Paths-v1.0.md)。

`SIMULATION_PASS` 只支持 fixture 條件下的邏輯與真實 repo preflight 可行性；`PACK_INTEGRATION_PASS` 只代表 F25 Pack 局部閉環。F21 的確定性 Brain mode controller 已由 Central role interface 接線，但最新 HEAD 尚未執行；`P2_PACK_CYCLE_PASS` 必須由外層循環器把 Simulation／Integration 的 102/102 計數、退出碼、同一 HEAD 與乾淨工作目錄證據封存至 `cycle_gate_evidence`。中央在開啟或讀取 Verifier Context 時，還會重算 canonical Pack 的 SHA-256，拒絕報告後的執行產物漂移。 Runner／Central 也會核對 Current 接受條件與 regression_tests，以及 Active Work／Construction 穩定契約 SHA-256；合法 lifecycle 欄位可以改變，目標 Scope、接受條件與 Construction implementation contract 不可在報告後改寫。即使該局部循環通過，也不能宣稱完整 B1→B7 或真實 Runtime 已完成。

### F25 固定資源硬上限

Pack 請求不只攜帶自訂預算，也受 Builder 硬上限約束：顯式輸入總量 5,000,000 bytes、Pack 5,000,000 bytes、上下文 100,000 chars、單一 Work Unit 100 steps、請求 JSON 檔案 1,000,000 bytes。輸入／輸出 Schema 與程式入口均檢查這些上限；超出在讀取所有來源前就 BLOCK。較小的任務應使用更小的 request-level budget。這些是保護性上限，不是建議目標值；實際目標應由任務所需的最小資料量決定。

## 7. 資源節省的機械規則

- **不搜尋大資料庫來開始任務。** 先讀唯一 Current；由 Active Work Unit 明確提供必要 refs。只有必要 ref 缺少時才執行定點查詢。
- **把大來源處理成本前置一次。** 以源／解析器／正規化器／segment hash 快取已完成的機械步驟；來源 hash 未變且 parser／normalizer 版本未變就重用結果。
- **失效範圍最小化。** 只重建引用了變更來源的 Segment、Claim／Pack；其他已驗證資料不重做。
- **限制 Context 組裝。** 使用任務類型對應的 target／hard budget，明確列出 omitted refs；超限時縮小範圍或拆 Work Unit，不默默截斷後照常執行。
- **預設只用當前有效狀態。** 一般 Pack 不帶版本時間線；版本／衝突詳細資料需明確目的後才查。
- **避免無效重試。** 相同 Operation ID、相同輸入 hash 若已成功，回傳既有結果／不重複副作用；輸入改變必須用新 ID 或新 fingerprint。達到 retry limit 後 BLOCKED。
- **計量只產生一份收據，重算依變更觸發。** GitHub 文字大小只作規劃估算；正式輸入／輸出 bytes 與 Context 字元數只由 Builder 對明列來源和 canonical context 實測，寫入 `source_manifest`／`resource_usage`。`context_chars` 是 canonical JSON 解碼後的 Unicode code point 數，不是 UTF-8 bytes，也不是模型 Token。未呼叫可識別模型／tokenizer 的真實計量器時，Token 用量標記 `NOT_MEASURED`。施工期間沿用同一 fingerprint 與計量契約下的量測收據；只有來源、request／Current、序列化／Schema／計量版本或預算輸入變更時，重測受影響項。最終獨立 Verify 仍要重新讀取來源並重算 hash／長度／Context 以查出漂移，這是必要完整性檢查，不得省略；但不得因此在每個小修補後另外人工重算整組來源。乾淨環境精確預檢集中在整批功能完成後、官方驗收前執行一次。
- **用測量證明省算力。** 每個執行包記錄輸入 refs 數、讀取 bytes、segments 處理數、Context chars、輸出 bytes、重用命中、未讀項與原因；Model Token 數只有在實際 tokenizer 計量時才能填入，否則為 `NOT_MEASURED`。未有基準前不填虛構的百分比改善。Pack 輸出新增必填計量欄位屬格式契約變更，Schema `$id`、頂層 `schema_version` 與 Builder 輸出版本需一致升為 `1.1`；舊格式 `1.0` 不得通過新 Schema 驗證。
- **快取不是權威。** 快取／Pack 缺失時可以由明確權威輸入重建；不能只有快取而無可驗證來源。GitHub 官方文件也區分快取（可再下載／生成）與工作產物（供保存／傳遞），本設計沿用該界線，但不依賴 GitHub Actions。參考：https://docs.github.com/en/actions/concepts/workflows-and-actions/dependency-caching

### P2-F29：事件觸發式施工健康回溯的實作邊界

- `scripts/construction_efficiency_review.py` 只接受明確觸發參數：`user_requested`、`slowdown`、`stalled`、`repeated_rework`、`recurring_failure`、`budget_exceeded` 或 `anomaly_reported`；不設排程、不作常態或逐切片監控，不呼叫外部模型／計量服務，不保存永久審查歷史。
- 從 Git 取得最多 3 筆 commit 摘要與每筆最多 20 筆 numstat 檔案列；到第 20 筆立即終止子程序，不讀第 21 筆。因不再多讀一列來猜測是否還有資料，碰到上限時 `file_rows_truncated` 表示剩餘資料未知／可能被截斷，不是已觀察到更多檔案的證據。不得載入完整 diff、遞迴掃描 repository 或另建稽核歷史。
- Source-budget 審查只讀 Current、request manifest 與 manifest 明列 refs，並檢查 active-work 指標、Current 引用、ref 去重、路徑越界／symlink、空路徑、來源必須是一般檔案及正確的 resource-budget 物件。缺少或不可用的來源要明確阻擋；不能把目錄的大小當成來源檔案大小，也不能在 malformed JSON 結構上拋出無界 traceback。
- 輸入位元組估算是 Current bytes 加上明列來源檔案 bytes，和維護資源比率分開。維護資源只在 construction_units 與 maintenance_units 都是真實、同單位且有效的量測時比較；`maintenance_units / construction_units > 0.20` 時產生優先處理的 `MAINTENANCE_RESOURCE_BUDGET_EXCEEDED` 訊號。缺少可比較量測即標 `UNMEASURED`，不得以 Git 行數、檔案位元組、字元或 AI 自評代替 token／時間用量。
- 相關正常／負例已折入既有 15-method `test_brain_mode_controller.py` 測試方法，不增加官方 102 方法總數；測試仍為 `NOT_EXECUTED`，此程式與測試原始碼不能宣稱 PASS。

## 8. 最低測試合約

| 測試 | 輸入條件 | 必須結果 |
|---|---|---|
| Determinism | 相同源 bytes、parser／normalizer、契約版本 | source／segment／pack hashes 穩定 |
| Idempotency | 同 Operation ID 同輸入連續執行兩次 | 第二次 no-op／返回同一結果，不重複輸出 |
| Input drift | 同 ref 的內容或 parser 版本改變 | fingerprint 變更；只重建受影響項 |
| Required gap | 缺少一個 required ref／segment | INCOMPLETE／BLOCKED，禁止 PASS |
| Optional gap | 缺一個 OPTIONAL ref | 可繼續並明確列出缺項 |
| Stale pack | Current／Blueprint／Contract fingerprint 已改變 | PACK_STALE；不直接執行舊 Pack |
| Direct lookup | 查一個 box_id，其他 checkpoint 包含大量不相關／畸形檔案 | 只讀確定的目標檔，不能被其他 checkpoint 數量拖慢或影響結果 |
| No history injection | Canonical Claim 有十個歷史版本 | 一般 Context 只載入有效 Claim 與必要 supersedes metadata，不載入歷史版本全文 |
| Archive default deny | 一般任務要求 Archive 資料 | 拒絕；有明確目的／scope／權限後只回傳有上限的必要片段 |
| Evidence chain | Claim 缺 Evidence／Segment／Source 或引用 hash 錯 | 不升格，回傳精確 reason code |
| Budget exceeded | 必要輸入超過該 Work Unit budget | BUDGET_EXCEEDED／SPLIT_REQUIRED，不默默截斷 |
| Clean reconstruction | 移除非必要歷史材料後依權威輸入重建 | 重建與驗收 Gate 通過，或明確 BLOCKED／列缺失輸入 |

## 9. 關於最低運行方式的必要區分

「AI 對話＋GitHub」足以做需求分析、編輯程式／契約、提交、讀回、靜態邏輯審查與規格反例檢查；**GitHub 作為儲存服務本身不會執行 Repository 內的 Python 程式**。因此：
- 沒有可用的程式執行載體時，狀態最多是 AI_DIALOGUE_REVIEWED／GITHUB_PERSISTENCE_CONFIRMED／STATIC_REVIEW_PASS。
- 要聲稱真正的機械流程已跑通，必須有一個可重現的 Python／程式執行環境及實際執行輸出。它不必是付費 API 或 GitHub Actions；但不能在完全禁止任何程式執行載體的同時要求真實程式 PASS。
- 不把未執行測試標成 PASS，也不因 Actions 失敗而阻止 AI＋GitHub 能做的工作。

---

## 10. 成功標準

只有在以下條件均有可讀回、可驗證的證據時，才可將這條縱向切片標為 CODE_LOOP_PASS：

1. 明確的程式入口與相依環境可重建；
2. Same input → same hashes，重跑不重複副作用；
3. Source／Segment／Evidence／Claim／Pack 具備完整可追溯鏈；
4. 例外／缺失／超限可明確阻擋；
5. 正常 Runtime 只讀唯一 Current、現行 Operational Pack 與明確所需 refs；
6. 不遞迴掃描歷史路徑、不將整份版本歷史放入預設 Context；
7. 通過本計畫第 8 節相關測試；
8. 有實際執行輸出；若缺少就維持 NOT_EXECUTED／DESIGN_SPECIFIED_UNVERIFIED。

此計畫定義功能契約，不是完整閉環驗收結果；最新執行狀態以 `P1-CURRENT.json`／Active Work／Construction 為準。B2.2 目前仍須在修補後版本取得新的完整驗收證據。

## 11. 外部研究與採用原則

外部實作只作模式參考，不變成 P2 的依賴：

- **確定性工作流與冪等重試：** DBOS 文件要求 workflow 在相同輸入／已完成 step 結果下維持確定性；步驟可安全重試，並以 workflow ID 支援去重。P2 只採用確定性、冪等、checkpoint 與有界恢復原則，不要求安裝 DBOS。https://docs.dbos.dev/architecture https://docs.dbos.dev/python/tutorials/workflow-tutorial
- **冪等接收者：** 同一個請求在回應遺失後可能被重送；必須用穩定 ID 識別已處理請求，回傳先前結果而不重複副作用。P2 的 operation_id／input fingerprint 應落在自身 schema／程式中。https://martinfowler.com/articles/patterns-of-distributed-systems/idempotent-receiver.html
- **Cache 不是權威：** GitHub 文件區分快取（可重新取得／生成）與 Artifact（保存／傳遞執行產物）；P2 Operational Pack 是有 hash 且可重建的衍生物，來源權威仍是唯一 Current、已接受 Claims、藍圖與契約。P2 不依賴 GitHub Actions。https://docs.github.com/en/actions/concepts/workflows-and-actions/dependency-caching https://docs.github.com/en/actions/concepts/workflows-and-actions/workflow-artifacts
- **Prompt caching 不是歷史蒸餾：** OpenAI 的 Prompt Caching 屬 API 呼叫的輸入 token 成本／延遲優化，且需量測 cached tokens、cache writes 等；這不能取代將歷史資訊蒸餾成短小運行資料，也不能滿足 P2 的 AI 對話＋GitHub 最低模式，因此不是前置依賴。若未來真有 API 模式，再依實際 token／成本資料評估。https://developers.openai.com/api/docs/guides/prompt-caching

本計畫的第一目標不是使用分布式 workflow engine，而是在現有 Python 模組中用明確 contracts、hash、直接索引、有限範圍、失敗封閉與 idempotent writes 先完成最小縱向閉環。只有在真實需求與故障證據證明必要時，才增加 runtime／queue／database 等元件。
