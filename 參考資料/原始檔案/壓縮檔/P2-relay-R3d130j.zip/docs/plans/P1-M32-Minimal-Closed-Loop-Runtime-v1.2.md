# P1 M32｜Minimal Closed-Loop Runtime Blueprint v1.2

版本：v1.2
狀態：SUPERSEDED / HISTORICAL M32 WORK PLAN
前版：v1.1（SUPERSEDED）
本文件保留施工歷史，不再作為 P2 的下一步權威；後續以 P2-System-Blueprint 與 P2-Post-r48-Roadmap 為規劃依據。

## 1. 本版修正目的

v1.1 的主線方向正確，但交接層與部分 runtime semantics 尚未完全同步。本版一次收口以下問題：

1. P1-CURRENT / Work / Construction / Task / Agent 交接資料必須與本版一致。
2. `read_first` 定義為索引，不是批次讀取命令。
3. Trusted Runtime 的 executable action 與 State Command 必須分離；不得把 state-transition command 當成 OS execution allowlist。
4. Acceptance command 的信任層級必須明確：它是受信任的 construction/CI harness，不是模型或 Work Packet 可自由注入的 runtime action。
5. GitHub Actions startup failure + local replay PASS 不得直接變成一般 PROGRAM_VERIFIED；外部 runtime 未實際執行時，Current Truth 仍為 INCOMPLETE / PROGRAM_UNRESOLVED。
6. Current Truth reconciliation 必須具有明確的新舊 observation 排序規則。
7. Crash recovery 必須涵蓋 partial/truncated event evidence，而不只 process restart。
8. 舊 M32-C01 的 runtime implementation/evidence 保留為歷史事實，不得被新 C01-A 覆寫。

## 2. M32 主線

COMMAND TRUST BOUNDARY
→ THIN CONTINUATION
→ FAILURE / REPLAY
→ CRASH RECOVERY
→ CURRENT TRUTH RECONCILIATION
→ CI / ACTIONS SECURITY
→ E2E VERTICAL SLICE
→ M32-CLOSE

Lazy Context Activation 維持移出 M32，待 M32-CLOSE VERIFIED 後再作為 M33 candidate。

## 3. 不變量

1. P1-CURRENT.json 是唯一 Current Authority。
2. Architecture Baseline 只有 VERIFIED 才能成為 CURRENT。
3. 不建立第二套 Task / State / Result / Retry / Registry / Checkpoint。
4. Brain 只能 PROPOSE；不得直接提交 Global State。
5. Commander / Command Layer 是正式 command admission 與 state mutation 邊界。
6. ResultPacket decision_code 仍只允許 WORK_COMPLETE / UNRESOLVED / FAIL / BLOCK。
7. TIMEOUT 屬 Attempt / Execution Truth / Scheduler 語義，不建立第二 Result taxonomy。
8. Reducer 不呼叫模型、工具或外部副作用。
9. Runner 不擁有新的 workflow state、retry、result 或 persistence model。
10. M32-C01 是單一 Work Unit；A–F 只是按順序實作步驟，不各自建立 acceptance gate。
11. external runner startup failure 且沒有 step evidence 時，不能直接視為 PROGRAM_VERIFIED。
12. 驗證只放在高影響邊界。
13. 未被目前工作需要的 capability definition 不進 Hot Context。
14. 新機制必須先證明既有 runtime 無法完成，才可新增。
15. Blueprint / Agent handoff / README 都不是 Current Truth；衝突時以 P1-CURRENT 為準。

## 4. Slice A｜Command Trust Boundary

唯一目標：禁止 Trusted Runtime 直接執行模型/packet 提供的 arbitrary argv。

錯誤舊路徑：

next_command → subprocess.run(argv)

新路徑：

COMMAND PROPOSAL
→ COMMAND LAYER ADMISSION
→ EXECUTION ACTION
→ FIXED HANDLER
→ OBSERVATION
→ EXISTING EVENT / RESULT / STATE PATH

### 4.1 State Command 與 Executable Action 分離

現有 Command Layer 的 `command_type` 代表 state transition semantics，不自動等於 executable action。

Executable action 必須：

- 使用固定 implementation-level handler mapping。
- 只能接受明確 command type。
- 不建立第二套 canonical registry。
- unknown command type → BLOCK。
- handler args 依固定 typed contract 驗證。
- 不接受 arbitrary executable argv。
- 不進行 shell interpretation。
- workspace path 必須限制範圍。
- 禁止 `..` traversal、workspace 外 symlink escape、敏感路徑。
- 預設不傳 secrets / credentials。
- 沒有安全 idempotency / retry 語義的副作用 action 不得自動 retry。

### 4.2 Acceptance command 邊界

`RUN_ACCEPTANCE_COMMAND` / `local_acceptance.py` 屬於 construction / CI harness。

它：

- 不是模型提出的 runtime action；
- 不得成為 Work Packet 的 arbitrary executable interface；
- 必須由 repository-controlled workflow / fixed acceptance harness 呼叫；
- 本輪不把它誤當成 Trusted Runtime execution API。

因此 C01-A 主要封鎖的是「模型/packet → Trusted Runtime」邊界，不因修正而建立第二個 acceptance engine。

### 4.3 完成條件

- arbitrary argv 作為 runtime action → BLOCK。
- unknown command type → BLOCK。
- legal typed action → PASS。
- invalid typed args → BLOCK。
- state transition authority 仍只在既有 Command Layer。
- 不新增第二 Command / State / Result / Retry / Registry。

## 5. Slice B｜Thin Continuation

Runner 只負責：

LOAD → COMMAND REQUEST → INVOKE EXISTING CONTROL PATH → OBSERVE → RETURN OBSERVATION

不得複製：

central_controller / scheduler / execution_truth / reducer / retry policy。

結果必須重新進入既有 canonical runtime path。

## 6. Slice C｜Failure / Replay

使用既有 Attempt / Execution / Result / Command identity。

驗收：

1. worker exit failure
2. timeout
3. duplicate result
4. stale revision
5. duplicate command / idempotency replay
6. late result

規則：

- retry 語義與 Scheduler 一致。
- duplicate result 不產生第二 canonical effect。
- stale revision 不得修改 state。
- TIMEOUT 不等價 FAIL。
- unresolved side effect 不可盲目 retry。

## 7. Slice D｜Crash Recovery / Replay

流程：

DISPATCH
→ process interruption / crash
→ restart
→ load Current + Event / Execution evidence
→ derive next legal action

除一般 restart 外，至少加入：

- partial event write
- truncated JSONL line
- restart 後仍能區分已提交、未提交、未知 execution。

禁止透過 Python process memory 恢復。

Event / Current / Execution evidence 必須足以重建合法 continuation。

## 8. Slice E｜Current Truth Reconciliation

沿用既有：

- current_truth_reconciliation.py
- actions_execution_truth_adapter.py
- current_projection_sync.py

不新增 truth store。

Observation ordering 必須至少比較：

1. observed_at
2. workflow/run identity
3. run attempt
4. attempt identity
5. head_sha
6. evidence completeness

要求：

- 新 observation 不得被舊 observation 覆蓋。
- 無 step evidence 的 runner startup failure → INCOMPLETE。
- PROGRAM_VERIFIED 必須有實際 execution evidence。
- local replay PASS 只證明 local execution，不能單獨把 external runner failure 轉成 PROGRAM_VERIFIED。
- projection drift 必須可被偵測並修正。

## 9. Slice F｜CI / Actions Security

只修改既有 workflow。

要求：

- 最小 permissions。
- Acceptance execution job 僅 `contents: read`；需要寫入 Current 的 finalizer job 才可取得 `contents: write`。
- write-capable finalizer 不執行 repository Python；只搬運 acceptance job 產出的 immutable artifact 並進行 git commit/push。
- 第三方 actions full commit SHA pinning。
- 保持 Control Gate / Observer / Fallback evidence boundary。
- platform failure 與 program regression 分離。
- 不建立第二 CI engine。

### 9.1 Actions Observation / Recovery Closure

M32-CLOSE 的 acceptance infrastructure 不得只負責「執行 acceptance」。

控制鏈必須是：

ACCEPTANCE REQUEST
→ ACTIONS RUN / MISSING RUN
→ ACTIONS EXECUTION DIAGNOSTIC
→ EXISTING RECOVERY DECISION
→ EXISTING RECOVERY DISPATCH
→ CURRENT TRUTH EVIDENCE

規則：
- workflow completed → 由 workflow_run observation 進入既有 diagnostic。
- acceptance workflow 未出現 → scheduled watchdog 在 grace period 後分類 NOT_DISPATCHED。
- NOT_DISPATCHED → 自動 workflow_dispatch 同一 logical close request，受 bounded recovery budget 約束。
- RUNNER_STARTUP_FAILURE → local diagnostic；diagnostic PASS 後才可 bounded redispatch。
- WORKFLOW_EXECUTION_FAILURE 不得當成 infrastructure failure 自動重跑；依既有 local replay / program regression semantics。
- observation / recovery 是 acceptance infrastructure control path，不是 acceptance result owner。
- M32 Close Acceptance 的唯一 program-truth 來源是 SIMULATION_ONLY acceptance result。
- Actions workflow/run 只負責承載或觀察這次 simulation acceptance；其 run evidence 不是額外 acceptance gate。
- simulation mode 不等於停止 observation；只代表 observation 不得被升格成 production runtime truth。

## 9.2 Debug Escalation Distillation

M32 acceptance/recovery 只保留一條失敗階梯：

1. 第一次失敗 → 使用既有 recovery path；不得新增功能。
2. 第二次同一 Work / head 的連續失敗 → 只允許增加一個最小必要能力，仍沿既有 canonical path。
3. 第三次或以上連續失敗 → 停止自動修復，強制進入 DEEP_RESEARCH。

失敗次數由既有 Actions run metadata + Current observation 推導，不建立第二狀態庫。

DEEP_RESEARCH 必須：
- 比對外部官方資料；
- 比對成熟系統處理方案；
- 找出根因，而不是只增加 retry / gate；
- 提出最小修復；
- 從「失憶」狀態以觀測資料重建決策；
- 修復後才重新進入既有 recovery / acceptance 流程。

禁止：
- 第一次失敗就擴張架構；
- 第二次失敗一次增加多個新機制；
- 第三次仍繼續盲目 retry；
- 為了通過驗收修改 Current / evidence 數據；
- 用 process memory 作為失敗次數真相。

## 10. M32-CLOSE

單一完整 vertical slice：

CURRENT
→ BRAIN / PROPOSAL
→ COMMAND
→ TASK
→ EXECUTION
→ RESULT
→ EVIDENCE
→ EVENT
→ REDUCER
→ CURRENT
→ NEXT / TERMINAL

至少通過：

1. normal completion
2. worker failure
3. timeout
4. duplicate result
5. stale revision
6. command replay
7. crash / restart
8. partial/truncated event recovery
9. external runner startup failure
10. Current reconciliation
11. command trust boundary
12. acceptance/runtime boundary separation

## 11. Active Work / Handoff

目前實作 Work Unit：

M32-C01｜MINIMAL CLOSED-LOOP RUNTIME

實作順序：

A COMMAND TRUST BOUNDARY
→ B THIN CONTINUATION
→ C FAILURE / REPLAY
→ D CRASH RECOVERY
→ E CURRENT TRUTH RECONCILIATION
→ F CI / ACTIONS SECURITY

A–F 都是同一 Work Unit 的 implementation steps，不各自建立 VERIFIED gate。
只有完成 F 後，C01 才進行一次完整 acceptance。

Simulation acceptance 是 M32-CLOSE 的正式 Work Unit Close 驗收；通過即完成本輪 program closure。
真正 runtime evidence 僅在實際使用出現可重現問題時補充，不能反向成為本輪 simulation close 的必要條件。

本輪新增 lifecycle 規則：M32-CLOSE 完成施工後，不由 Executor 直接交給 Verifier；必須回到 Central，由 Central 建立 Acceptance Request/Context，再由 Verifier 向 Central 取得驗收上下文。驗收結果再回 Central，由 Central 決定 lifecycle transition 與下一 Work Unit admission。

未開始的步驟只存在於 Blueprint / handoff metadata，不進 P1-CURRENT.active_work_packet。

舊 M32-C01 runtime implementation/evidence 保留為 historical evidence；不得因新 C01 施工而覆寫。


### 11.1 Task Packet Amnesia Boundary

每次系統更新後，只要取得新的 Task Packet 並準備進入施工，必須先經過一次無記憶重建。

規則：
- 只從 P1-CURRENT、active Work Packet、Construction Packet 與 Task Packet 重建當前工作上下文。
- 不載入上一輪對話、模型暫存上下文或非 canonical 敘事。
- 使用既有 simulated_amnesia_resume runtime，不建立第二套 memory/state store。
- 重建失敗 → BLOCK / RECONCILE_OR_BLOCK；不得帶著不完整上下文直接施工。
- 重建成功 → 立即依 Task Packet objective / constraints / stop / failure / acceptance / retry / timeout 繼續既定任務。
- 這是 Task Admission 邊界，不是額外 acceptance gate。

## 11.2 Central-mediated Role Lifecycle Boundary｜2026-10-05 規劃修正

本輪補充一個既有 Canonical Control 的 lifecycle 邊界，不建立第二 Controller、第二 State、第二 Acceptance Engine。

### 角色不得互相交接

Role 不是 peer-to-peer workflow participant。

固定方向：

ROLE → CENTRAL → ROLE

禁止：

ROLE:EXECUTOR → ROLE:VERIFIER  
ROLE:VERIFIER → ROLE:EXECUTOR

任何角色完成工作後，只能回報 Central；下一個角色是否啟動、何時啟動、取得什麼 Context，全部由 Central 決定。

### Central Role Interface

所有角色只使用既有中央控制面的四類入口語義：

1. ROLE_ACTIVATE
2. GET_ROLE_CONTEXT
3. REPORT_PROGRESS
4. SUBMIT_ROLE_RESULT

這些入口不建立新的 truth store；輸入與輸出仍回到既有 P1-CURRENT / Task / Work / Construction / Result / Evidence / Verification canonical owners。

### Construction → Acceptance

施工角色完成 Task Packet 後：

ROLE:EXECUTOR
→ REPORT_PROGRESS / SUBMIT_ROLE_RESULT
→ CENTRAL

Central 驗證施工是否已到 Work Unit close boundary。

成立後由 Central 產生：

ACCEPTANCE REQUEST / ACCEPTANCE CONTEXT

Acceptance Request 是 lifecycle request/context artifact，不是 acceptance result，也不是第二 Truth。

### Acceptance → Next Stage

驗收角色啟動後：

ROLE:VERIFIER
→ GET_ROLE_CONTEXT
→ CENTRAL
→ ACCEPTANCE CONTEXT

驗收完成：

ROLE:VERIFIER
→ SUBMIT_ROLE_RESULT
→ CENTRAL

Central 才執行：

Verification Result / Evidence
→ Current lifecycle reconciliation
→ PASS / FAIL / BLOCK / INCOMPLETE
→ 下一 Work Unit admission decision

不得建立獨立的 UNLOCK_STATE、NEXT_STAGE_PERMISSION 或其他第二套權限狀態。

「解鎖下一階段」是由 Central 根據既有 canonical state 計算出的 Admission Decision，而不是新的 state owner。

### Context Projection

不同 Role 不讀取彼此 Session transcript。

Central 依 Role 產生最小 Context Projection：

- EXECUTOR：Task / Work / Construction / required source
- VERIFIER：Acceptance / implementation artifacts / Result / Evidence / required checks
- CONTROL_RESEARCH：Current / architecture / progress / failure evidence / research sources

這延續 M32 的 Context Budget、Amnesia Boundary 與既有 Task Admission，而非增加新的 Context Controller。

### Lifecycle Authority

只有 Central 可以執行：

- Role activation decision
- Acceptance Request creation
- lifecycle transition
- next-stage admission
- BLOCK / STOP / RETURN_TO_CONTROL

任何 Role 都不得自行宣布：

- VERIFIED
- ACCEPTED
- NEXT_STAGE_OPEN
- OTHER_ROLE_ACTIVATED

### Fail / Block / Incomplete

驗收失敗不回到 Executor 直接修復。

固定路徑：

VERIFIER
→ CENTRAL
→ CONTROL_RESEARCH
→ 新 Task / Repair Plan
→ EXECUTOR

修復後必須重新經 Central 建立新的驗收上下文。

## 12. Current / Read Context

`read_first` 是「索引與依賴定位」，不是「全部先讀」。

實際讀取：

P1-CURRENT
→ active work
→ current task dependencies
→ 必要 capability summary
→ 真正執行時才載入必要 source / definition

不得因 `read_first` 把完整歷史、所有 capability definition 或整個 repository 載入 Hot Context。

Work Unit 內每個 implementation step 僅讀最小充分 context。

取得 Task Packet 後，施工前先經過 `AMNESIA_RECONSTRUCTED`：
只用 P1-CURRENT + active Work Packet + Construction Packet + Task Packet 重建工作上下文；上一輪上下文不屬於執行輸入。

## 13. Acceptance 策略

正常：

WORK UNIT IMPLEMENT
→ ONE SIMULATION ACCEPTANCE
→ SIMULATION ACCEPTANCE RESULT
→ VERIFIED / BLOCKED

A–F implementation steps 不各自驗收；只有 Work Unit 結尾進行一次 acceptance。
只有 simulation acceptance FAIL 或其自身 evidence conflict 才重跑；外部 runtime evidence missing 不阻塞本輪 close。

程序化強制：
- progress_execution_contract.py 禁止同一 Work Unit 出現多個 acceptance step。
- acceptance step 必須標記 WORK_UNIT_CLOSE，且只能位於 Work Unit 最後一個施工操作之前。
- local_acceptance.py 執行前必須確認 P1-CURRENT 與 active Work Packet 已進入 IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE / READY_FOR_CLOSE_ACCEPTANCE。
- implementation-in-progress 狀態不得呼叫 canonical close acceptance。
- acceptance PASS 後不得再次執行同一 close acceptance。
- Trusted Runner 不得執行 construction lifecycle 或 acceptance；其責任只到 typed action admission、execution、observation。

外部 startup failure：

RUNNER_STARTUP_FAILURE
→ INCOMPLETE

即使 local replay PASS，也只能表示 local execution evidence；不得直接把 external execution 變成 PROGRAM_VERIFIED。

## 14. 明確禁止

- universal workflow engine
- second Controller
- second State
- second Result taxonomy
- second Retry engine
- second Current / Memory Truth
- Activation Registry
- arbitrary argv trusted interface
- Brain 直接 subprocess
- packet 直接 shell command
- 第二 CI engine
- 每一步獨立 gate
- M32 內 Multi-Agent / Best-of-N / Self-Evolution
- 把 State Command 自動當成 OS executable handler
- 把 local replay PASS 當作 external execution PASS
- 用 process memory 補造 crash recovery truth

## 15. M33 Candidate

M32-CLOSE VERIFIED 後才評估：

1. Lazy Context / deferred capability loading
2. Multi-Attempt / Candidate Execution
3. 成本與成功率觀測

採用與否由 M32 runtime evidence 決定。

## 16. 本版與前版

v1.1 → HISTORICAL / SUPERSEDED
v1.2 → CURRENT WORKING BLUEPRINT（r48 當時的文件標籤；對 P2 後續施工已屬歷史標記，不構成現行入口）

P1-CURRENT 必須指向本版。

外部研究仍沿用 v1.1 所列 OpenAI Agents SDK、Temporal、Anthropic、GitHub security references。


## Repository Result Writeback Boundary

External execution results MUST return through the existing canonical ResultPacket path.

- External runners may produce only the existing System Result / Execution Record inputs; they do not introduce a second Result taxonomy.
- `P1-Central-Control/scripts/system_result_adapter.py --persist-repository` converts the existing canonical ResultPacket into repository persistence.
- `P1-Central-Control/scripts/repository_result_writer.py` is a persistence adapter only: it validates the existing ResultPacket, writes it under `P1-Central-Control/results/`, returns `CREATED` or `IDEMPOTENT_REPLAY`, and blocks conflicting reuse of the same result_id.
- The writer does not mutate Current, retry execution, decide program truth, or create a second registry/state store.
- Repository persistence is the durable return channel. GitHub Actions artifacts remain transport/audit material and are not the P1 truth store.
- The executable return path is:
  `Task Packet → external execution → existing System Result / Execution Record → existing ResultPacket → repository ResultPacket persistence → repository_result_ingestion adapter → existing central_controller.receive_result_and_schedule() → existing Execution Truth / Scheduler / Event Log / Current path`.
- `repository_result_ingestion.py` is a thin re-entry adapter only. It may validate identity/hash and load existing canonical inputs; it must not create State, Retry, Result taxonomy, Registry, or Truth.
- The external runtime API is optional for P1 correctness; repository persistence is sufficient as the durable return channel, but a persisted ResultPacket is classified as `PERSISTED_PENDING_CENTRAL` until the existing Central path consumes it.
- Current Truth Reconciliation may observe this distinction, but does not promote repository persistence into a second truth owner.
