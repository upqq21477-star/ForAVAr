# 交接蒸餾帳本（舊資料只留關鍵，不堆疊）

**規則（D-R3d12s-DISTILL）：** 開發期容易改方向，舊記錄原樣保留會堆疊、污染、拖累交接。所以已結案或沒人使用的舊資料一律**極致蒸餾**：①每場收尾把已結案列、逐項變更、裁決理由蒸餾成一行要點併入；**不貼原文、不留檔案清單與指令**（它們在 policy／evidence／登記表）；②一條決策一行（ID＋結論＋仍約束什麼）；③被推翻或過期者直接刪；④本檔 ≤ 10 KB，超出就再蒸餾。蒸餾前的完整帳本（68 KB）在 `P2-relay-R3d12r.zip` 的同名檔。查找：`python3 tools/slice.py docs/handoffs/LEDGER.md --grep <ID>`。

## 時間線（一場一行，只留結果）
- **R3d12g～zc：** 已封存至 `docs/archive/LEDGER-timeline-archive.md`（逐字搬移）。
- **R3d12zn：** S1a／S1b：`caller_audit`＋T4、FP4～10 重分類、DORMANT＋ADR 0090、23 能力狀態檔、`capability_gate` 警告模式。
- **R3d12zo：** S2：`atomic_write`、`run_journal`、`Run.step`／`resume`／`ladder`／`outcome_class`；新測試 34 案 SIMULATED_PASS；移出 R1-S3m 封存檔（sha256 30e0ca5fdb77ff0b，自 R3d12zn zip 可取回）。
- **R3d130c：** 工具優化（任務表 DONE；細節 R3d130e 未重讀）。
- **R3d130d：** 壓縮場：退役 4 個零引用模組與專屬測試（scripts −41,393 B／tests −25,177 B）；`precheck --run-tests` 174/174、新失敗 0；再縮須拆子系統，未做。
- **R3d130e：** 閉環關卡（部分）：repo_budget 以實測重推（D-R3d130e-TARGET）；LEDGER 壓縮補行；新增的 `retire_gate` 與既有 `lifecycle_sweep` 重複，R3d130f 已刪。
- **R3d130f：** 退場機制查因：`lifecycle_sweep`／`archive_governance`／`data_lifecycle_policy` 早已存在卻從未接進結案，兩套預算矛盾；close_session 新增退場閘門 `exit_steps`；progress/ 與 docs/plans 瘦身排下一場。

## 決策（仍有約束力者；一條一行）
**治理與驗收**
- **D19／D-R3d10-D19：** 梯次 2 須有實際運行代碼；梯次 3 先閉環（R5）再蒸餾並代碼化，`closure_ref` 須指向已 DONE 的 R5（`batch_gate` 強制）；等價率 1.0；`doc_only` 只准梯次 1；門檻不放寬；「算數的代碼」＝運行入口＋負例或突變測試。
- **D-R3d11-SIMLABEL／NOAPI／STDLIB：** 模擬通過一律標 SIMULATED_PASS；API 非基線相依（無金鑰、Cost Gate BLOCK、HTTP 失敗皆備援）；`brain_provider` 只用標準庫核對 proposal，完整驗證留 R5。
- **D-REAL-DEFER（使用者 2026-10-14）：** R9 前不做真實測驗；`real_testing_mode`＝`DEFERRED_TO_R9` 時債上限（F2）與 F3 暫停、債仍計量，F1（本地全測試證據新鮮）照舊；R9 改 `ENFORCED`；代價＝R9 修復量增加。
- **D-R3d11d-DEBT：** 債＝自基線（或上次真依賴驗證）變動的範圍檔案數；上限 10（`policy/fixed_deps.v1.0.json`，可調）；Actions 工作流只能手動觸發（2026-10-10 暫停自動執行不動）。
- **D-R3d11b-BYTECAP：** 交接 ≤ 18,000 B（UTF-8）。
- **D-R3d12s-DISTILL：** 已修（後備實跑通過）的 DEFECT 併成 OPEN-ISSUES 一行（`FIXED_FALLBACK`），R9 真依賴複驗通過才刪行；後備是替身，真依賴未驗前不得宣稱已驗證。
- **D-R3d12s-SSOT：** 進度唯一權威＝HANDOFF；README、`P1-CURRENT.json` 進度欄為衍生或凍結投影，`pointer_audit` PT5／PT6 把關，不改凍結檔。

**鎖定檔、保留與紀錄**
- **鎖定檔例外先例（可推翻）：** D-R3d5-SCHEMACONST（舊 const 指向已刪文件）、D-R3d8-P1CURRENT（Spine→P2-Axis 一行）、D-R3d9-GOVREF（單行指標；未走藍圖交易，因交易要求沙箱收據）。
- **D-R3d3／R3d9-F27、PROGRESS：** F27 schema 列舉保留、操作固定 BLOCK，殘留 12 檔保留至 R9；`progress/` 大檔維持（Current 的 active packet；target 13,500 B 列 R9）。
- **保留至 2026-11-08（review_after）：** `參考資料/企劃/` 五份孤兒與 Research-Sources、Synthesis-Matrix（未讀完不刪）；Conversation-Brain-Activation-Interface（活指令表）與 Governance-Rules（活規則）。
- **D-R3d9-S2E／WFAUDIT：** p2-brain Skill 保留（Codex 入口）；workflow 8 檔維持。
- **D-R3d10-RUNREC：** 執行紀錄須歸屬非建置元件（否則每寫證據都使輸入集過期）；`record` 只寫證據檔，DONE 時手動把 `entrypoint`／`evidence_file` 寫進登記表。
- **D-R3d10-REFS／SEEDS／CHAINS：** [refs] 基線空＝零容忍；種子容限全 0；`WIRED_EXECUTED` 需 `evidence/wiring-chains/<id>.json`。
- **D-R3d6-AUDIT／COVTOOL：** 原則核對＝靜態名稱比對（弱證據，只作棘輪）；`distill_coverage` 只當索引，不當刪除證明。

**Brain 與優化**
- **D-R3d11-OTHER：** 「其他」放 Provider 備援與 M4 選項（schema `clarification_options maxItems:3` 鎖定）。
- **D-R3d11c-AXIS：** 主軸語意由 Brain 標籤，代碼只驗確認者、原因、非目標、預算、轉向留舊鏈、確認前不生成；F24 主軸鏈留 R5。
- **D-R3d9-GUARD：** `brain_guard`（六項循環＋021c 注入負例）為零依賴獨立檢查器，R5 再接線。
- **D-R3d11f-GOVRULES：** 治理規則＝對照表＋短文件（43 條：ENFORCED 4／PARTIAL 21／POLICY_ONLY 7／NOT_IMPLEMENTED 11；原文逐字封存、refs 由測試核對）。
- **D-OPT-0～11：** 先蒸餾再研究；文件批次先行、程式批次模擬運行；試點用 P2 自身架構樹、L3K-p2 唯讀；階層只存 parent_id；schema 預設平面；回歸基準只用程式評分；驗收口徑＝Current 的 F01–F30＋90 案例（未跑）。

**R4L／XM**
- **D-R4L-MAP、D-R4R-MAP：** 登記表 M 項對映企劃卡片 S 組；組內子項全做完才算 DONE。
- **D-R4L-HOT：** `hot_fields` 取 Current 頂層欄位；Brief state ≤ 3 KB，超出進 `omitted_refs`；降級模式只受 18／20 KiB 核算；槽位＝「檔案＋符號」，`validate_slots` 核對存在。
- **D-R4L-CMD：** 指令表唯一來源＝Interface §1.3；兩層差異以 `policy/command_layers.v1.0.json`；雙份清單必漂移，故單一來源＋一致檢查；ASCII `!` 的 Skill 文字規則為 POLICY_ONLY。
- **D-R4L-M2：** 缺來源槽＝MISSING；超預算先縮摘錄再丟槽（PARTIAL，state 放不下則拒絕）；STALE＝逐槽讀回含雜湊＋HOT 欄位比對；`BRIEF_DELIVERED` 掛 SEGMENT；同事件集投影位元組相同。
- **D-R4L-M3（外部：CRAG）：** `resolve_gaps`＝足量→進行、部分→窄化重請求 ≤ 2 輪、缺失→`！研究`（UNTRUSTED_CANDIDATE）；`select_startup_mode`＝新鮮→BRIEF、過期→重建一次、其餘→DEGRADED。
- **D-R4L-S4／M3b：** 使用事實用 SEGMENT 事件；缺口 ref＝`<檔>::<符號>`；FR-13 一能力一卡、未知即擋；藍圖只經 `blueprint_update_transaction` 改。
- **D-XM／XM1：** 基線只靠 `CHAT`，`CODEX`／`ACTIONS` 可選，廠商專屬 DEFER；證據 `executor` 缺欄＝舊證據＝CHAT，值須在 `allowed`，任務不得 `requires_executor` 非 CHAT（X0／X1／X2）；任務卡與執行者無關，規格不清寫 blocker 退回對話（退出碼 3）。矩陣在 `docs/research/P2-OPT-REF/11-XM0-*.md`。

**R4R**
- **D-R4R-ADR：** 欄位全必填；proposed→accepted→deprecated｜superseded；取代為單一繼任者且雙向；僅 accepted 且 scope 含該路由或 ALL 者進 decisions[]（≤5 則、每則 ≤160 字元）；新增 ADR 須在 0000 登記簿補行。
- **D-R4R-DC：** 隔離→批次數觀察→重查→清除，可還原；`data_classes` 七類自訂（藍圖 §56 原文 UNKNOWN）。
- **D-R4R-S2：** 寬限期＝2 個驗收批次；每次轉移前重查引用；被引用即停；已 REMOVED 不可還原；`--budget` 只給建議。
- **D-R4R-S3：** 基線＝`change_radius` 內檔案位元組雜湊（缺檔 MISSING）＋`baseline_revision`；半徑外變動不算過期；`baseline` 為可選欄位；收尾鏈優先序 REJECTED > STALE > INCOMPLETE > COMPLETE；`NOT_EXECUTED` 不算有證據；`handoff_target` 不做（box 的 `next_exact_action` 與 task_packet 已承擔續行目標）。
- **D-R4R-BUDGET：** `repo_budget` TOTAL 4,976,000→5,250,000；R9 清理後再降。
- **D-R4R-S4：** 事件掛在 SEGMENT aggregate（鍵＝work id；單一 Log 只能一個 workflow），conversation_id 在內容裡、輪次每對話獨立編號；只存雜湊不存全文；被擋指令也記（ref＝ROLE_ROUTE_BLOCKED／ROUTE_UNHANDLED）；Brief 落後於 Log＝BRIEF_BEHIND 要重建，領先或雜湊不符＝REJECTED。

## 踩過的坑
- 新 schema 須在某 scripts 檔以字面檔名引用（否則 `lifecycle_sweep` 判不可達）；新腳本須被可達檔引用；新測試不進 `run_p2_validation.EXPECTED_TEST_COUNTS`（與 `TEST_FILES` 成對）；sh 下 `precheck` 不可前綴 `time`。
- 突變測試一律 `python3 -B` 並清 `__pycache__`（同大小同秒的突變檔會被位元組碼快取吃掉）；示範紀錄不可跟著被突變（`closure_chain` 凍結示範順序後才成立）。
- 改到被 `batch_gate` 當入口的檔（如 `pointer_audit.py`＝R3-S3e、`librarian.py`＝R4L）須 `batch_gate record` 重錄證據。

- Q1／Q2（R3d12zd／ze）：蒸餾加 mode＋錯誤路徑回放、FP4～10 重分類、T4 棘輪；Run 用雜湊鏈 journal＋intent 對帳＋原子寫。Q3：`step` 例外回 ERROR、重試只在 ladder 一層；見 §16、P2-RS-Q1／Q2／Q3。

## 外部資料
外部資料（STATIC_CHECK，多為搜尋摘要）：CRAG；MADR 4；Azure／GCS soft delete；LangGraph checkpoint；OWASP Agentic Top 10 2026；Swift JIRA（兩段結案）；Google Testing Blog（替身保真度）；OpenTelemetry GenAI（`conversation.id` 命名參考）；subprocess 文件、AWS Builders Library、Temporal 文件（Q3）。可靠性：官方文件與真實專案高，廠商部落格僅輔證。
- R3d130g：查證四梯次未成基礎功能（p2_run 無批次／階段引用、tier 寫死 1～3）；新增通用 `feature_lifecycle.py`＋`policy/feature_lifecycle.v1.0.json`（第 1 階段大綱檢查＋2～4 階段退出條件，12 測試 SIMULATED_PASS）；僅檢查器、未接線，接線留 R3d130h。
- R3d130h：四階段改成基本能力——`p2_run.Run` 遇 BUILD brief 自動開清單、`close` 階段未完成不回 PASSED；接力規則（pack_handoff RULES_BLOCKS）自動帶入四階段；26 測試 SIMULATED_PASS。餘：close_session／非 Run 進件／退場自動填。
- R3d130i：只更新規劃——查明四梯次對應 F30 四階段＋F28 排序，另建的 feature_lifecycle 屬重複（第二次重複造輪）；規劃新增 §8（既有優先、W0～W6）；接力規則改為「既有優先」與「四階段＝F30」；未打包的入口補丁已還原。
- R3d130j：W0 部分——全功能重疊比對（規劃 §9：5 套階段骨架、15 個無引用無測試、蓋好未接）與規則分類（§10：常設規則手抄、進度百分比遺漏）；無新程式；W7 常設規則單一來源、W8 小工具合併。
