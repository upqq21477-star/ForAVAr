# 未結問題（唯一一份）

**用途：** 只列「仍會影響目前工作」的缺陷與待核實項。已 `CLOSED`、已被證明無關的項目**直接刪行**，不寫歷史；已修項蒸餾成一行（見 §1）。
**來源：** 舊全庫掃描（487 檔靜態審計）已蒸餾於此；原日誌已移除（舊版 `P2-relay-R0.zip` 可回查）。

## 1. 已提交但尚未在真依賴驗證的修補（AUDIT-DEFECT）

結案分兩段（D-R3d12s-CLOSE）：對應測試在後備驗證器（3.12.3）實跑通過＝`FIXED_FALLBACK`，蒸餾成一行（不留表列、不留 R0 失敗訊息）；R9 真依賴（3.11＋jsonschema 4.26）複驗通過＝`CLOSED`，刪該行。後備是替身，不等於真實驗證。

**FIXED_FALLBACK（2026-10-15）：** DEFECT 001～020 共 20 項（015＝`capability_registry` 的 CAP-CONVERSATION-RECORD 已對齊實作，R4R-S4，`test_dialogue_record` 的 RegistryAlignmentTests）。證據：002／014／016～020 為 R0 失敗後轉綠；001、003～005、007～013 為既有測試（已讀斷言：空 registry、attempt 超限 BLOCKED、缺事件 RECONCILIATION_REQUIRED、retry 只計同 workflow／branch／head、Ledger 與 AccessLog 寫入失敗回滾、Evidence hash 竄改、state_revision STALE、來源 schema 錯誤結構化 BLOCK 等）；006 本場新增 `test_control_gate_missing_refs`（拿掉修補分支即失敗）；`new_ids` 編為 020。`baseline_failing_tests.txt` 為空。


## 2. 未結候選（CANDIDATE）

| ID | 待核實什麼 | 歸屬批次 |
|----|------------|----------|
| 002c | `P1-CURRENT.json`、README、`handoffs/handoff.data.json`、M32／M33／B1–B8 工作紀錄之間的狀態、head SHA、下一步是否互相矛盾 | R3（Current 同步）；R3d12s：README 已指向 HANDOFF（PT5／PT6），`P1-CURRENT.json` 進度欄凍結不同步，其餘矛盾待核 |
| 003c | 內嵌 validator fallback 對 date-time／uri 格式檢查不完整；找出全部呼叫點與反例 | R1（固定依賴下複核） |
| 004c | 最低路徑（`session_start`、`precheck`、`run_p2_validation`）靜態核對**未** import `actions_*`；待核：`local_control_gate`、`p14_d_recovery_entrypoint` 是否屬最低路徑 | R3（封存 Actions 相關） |
| 006c | 任務接納→規劃→dispatch→role→result→event/state→evidence→停止 的實際入口與終態是否真的接線 | R5（薄迴圈接線即驗證） |
| 007c | 文件路徑引用已由 `precheck [refs]`（HARD、基線空）覆蓋；**待核**：schema／registry／fixture／測試之間的路徑引用是否也被檢查 | R3（precheck 引用檢查擴充） |
| 008c | context 容量與分批恢復是否會被誤判（continuation box、amnesia resume） | R7 |
| 009c | `ingest_role_result`、`commit_brain_proposal` 等在測試外是否有正式 caller | R5；R3d12s 靜態核對：非測試呼叫端只有 `repository_result_ingestion.py` 自己的 CLI main，中央迴路無 caller | R5 |
| 010c | `system_registry.json systems=[]`；F01–F18 的 ROUTING 狀態 | R2b |
| 012c | 以字串組合的動態載入，文字層掃描抓不到 | R3（記為 UNKNOWN，不推論不存在） |
| 013c | 語意／知識狀態六維度（Epistemic、Adjudication／使用者確認、Conflict Resolution、Lifecycle、Temporal Validity、Authorization／Execution State）是否各有獨立 schema；所有 producer／consumer 不得同名共用或互相推升（A4 §10 P0）；R3d12s 靜態：六維度無各自獨立 schema（Epistemic、Temporal 各只在 1 個 schema 出現，Adjudication 只在 `claim.schema`） | R4（暫定） |
| 014c | 原始包→P2 能力處置矩陣：每項標 REUSE／ADAPT／REPLACE／DEFER／RETIRE，附責任域、權威位置、契約、驗收入口、UNKNOWN；不可用檔案存在代替映射；R3d12s 靜態：repo 內無此矩陣文件 | R3g（暫定） |
| 015c | Knowledge／Library 契約層映射：Source→Segment→Reading Ledger→Coverage→Observation→Evidence→Claim→Provenance→Temporal→Conflict；Planner Card→Skill 按需載入與升降級條件；R3d12s 靜態：契約層映射只存在於程式（`knowledge_intake`／`canon`／`retrieval`），無映射文件 | R4（暫定） |
| 016c | Archive／Reconstruction／Security Gate：冷資料獨立儲存與明確調用邊界；Context 與 System Reconstruction 區分；Identity／Role／Capability／Scope／Resource 授權契約與外部資料不可信邊界 | R7（暫定） |
| 017c | 接受與故意失敗案例對應測試：Coverage 不完整、錯誤來源、衝突注入、時間回歸、Archive 洩漏、Skill／Tool 污染、權限越界、Runner 不可用、Context Reset、重建失敗；無執行證據保持 NOT_EXECUTED | R5–R7（暫定） |
| 018c | 品質指標（如 Memory Contamination Rate）對 P2 是否仍有價值；定義前不得宣稱量測，零樣本不得報 100% | R9（暫定） |
| 019c | 驗收分兩層：Outcome Assurance（結果對不對，Verifier）與 Process Assurance（流程有沒有照規則，Gate／trace）各自輸出，Acceptance Authority 不得自動推升證據等級（來源：P2-核心能力 C4；程式只有 12 檔提到 outcome，是否分離 UNKNOWN；R3d10：`tools/assurance_audit.py`（AS1–AS5＋10 個負例）進 precheck HARD，R5 驗收記錄以此格式產生） | R5（暫定） |
| 020c | 四條接線鏈的運行證據：Planner Card→Task Set→Command；Runtime Receipt／Result Packet→Result Ingestion→Evidence／Acceptance→Current；Knowledge Retrieval→Brain。驗收以 `wiring_audit.py` 的 UNWIRED 數量下降為準（R3d7 為 19），不以文件宣稱（D19；R3d10：`tools/wiring_chain_audit.py`＋`policy/wiring_chains.v1.0.json`，實測四鏈皆 BROKEN，棘輪基線 4 鏈／19 能力，只降不升；R3d12s：鏈 2／3 的 Result Ingestion 模組對映已核＝`repository_result_ingestion`；鏈 1 的 `task_admission_errors` 運行路徑不可達，見 022c） | R4–R5（暫定） |
| 021c | 間接提示注入負向情境：檔案或工具輸出內含指令時，不得改變目標、模式或寫入範圍；對照 OWASP Top 10 for Agentic Applications 2026 的 ASI01（目標劫持）、ASI02（工具誤用）、ASI06（記憶／上下文污染）；least-agency 的工具範圍與寫入保護 R5 已有，缺這一類情境（擴充 017c）；R3d9：`tools/brain_guard.py` 的 `check_injection` 已有欄位層負例（precheck HARD），接進 R5 運行路徑前仍屬 IMPLEMENTED_UNVERIFIED | R5（暫定） |
| 022c | `task_admission_errors` 在 `execute_command` 路徑不可達：Task＝segment，但 `execute_command` 只支援 aggregate_type＝WORKFLOW 且 target_id＝workflow_id（schema 有 SEGMENT／ATTEMPT 卻被拒為 UNSUPPORTED），stale task 實際由 `task_set.void`＋排程層擋。待決：保留純函式、待 SEGMENT 命令支援才接，或擴充命令路徑；鏈 1 的 WIRED_STATIC 只代表 import | R5（暫定） |
| 023c | Brief 覆蓋分級（`librarian` 自帶 SUFFICIENT／PARTIAL／MISSING）與 `context_sufficiency`（`required_refs`／`available_refs`／`stale_refs`＋三個預算，介面可轉接）兩套並存，等價性未驗 | R5（接線時決定） |
| 024c | 館員與使用紀錄未接入運行路徑：`librarian` 的非測試 import 只有 `brief_use`、`startup_budget`；`brief_use.record_use`（`BRIEF_SLOTS_CITED`／`INFORMATION_GAP_PROPOSED` 的唯一寫入者）無呼叫端；`！收斂` 收尾呼叫館員依 Plan §3B 屬 R7 | R5／R7（暫定） |
| 025c | FP4～FP10 無非測試、非登記表的呼叫者；`batch_gate` T3 不查呼叫者，致 FP4～FP10 名不副實地 DONE；FP4～FP10 未登記 `mirrors`（規劃稿 §2、§5） | R10-A（Q1 先研究） |
| 026c | `Run.step` 不攔 `subprocess.TimeoutExpired`、`OSError`、`UnicodeDecodeError`；trace 只在記憶體；`Run` 無 checkpoint／resume；預設寫檔非原子（規劃稿 §6 G1～G4，讀碼所得，未實跑） | R10-B（Q2、Q3） |
| 027c | 藍圖 §4.5「Planner 只規劃 WIRED」未在 planner／task_set／router／gate 實作；`role_capability_binding` 名單含 15 個 UNWIRED 與 4 個 NO_TOOL 能力（規劃稿 E-1；靜態 grep，HYPOTHESIS） | R11-A（Q4） |
| 028c | STATISTICS／CLUSTER／TREND／ANOMALY 宣告 `DECLARED_NO_TOOL`，但 F17、F19、F22、F23、F26 政策為 TOOL_GUARD／TOOL_REQUIRED（規劃稿 E-3） | R11-H（Q8a） |
| 029c | 能力演進狀態檔只有 `CAP-SEARCH`（rev 0，未評估）；`evolution_cycle` 無腳本呼叫者（規劃稿 E-4、E-5） | R11-A（Q4） |
| 030c | scripts 有 48 個模組無其他腳本 import，其中 29 個（C～G 組）啟動條件不明（規劃稿 §3） | R10-F |
| 031c | F01～F48 的 `runtime_owner` 全空；14 項 TOOL_REQUIRED 無提供者；23 能力僅 4 個有 `capability_run` 實測入口（規劃稿 §4、E-7） | R10-F、R11（Q5～Q8） |
| 032c | `p2_run` 的 import 掃描只命中 path_distill、scenario_distill 與測試，未命中規劃稿 §2 註所列的 result_chain／track_a_dryrun／batch_gate（別名或動態載入？HYPOTHESIS；本場 R3d12zd 掃描） | R10-F（Q1） |
| 033c | FP4～FP10 的 import 者僅測試（及 p2_run→scenario_distill）；`tools/caller_audit.py` 與 `batch_gate` T4 皆不存在（PROGRAM_EXECUTED_PASS） | R10-F（Q1） |
| 034c | 回放缺錯誤路徑對等（FP3 G1 同源）與 shadow 無副作用規則；外部函式庫明言錯誤路徑不在範圍（S4） | R10-F（Q1、Q3） |
| 035c | 規劃稿 §6 G2 需修正：`Run.close()` 只寫兩筆對話記錄與收尾狀態，trace 本身從未寫入 EventLog（讀碼；R3d12ze） | 待排程（Q2） |
| 036c | `resume_check` 有非測試呼叫者 `closure_chain.py`（grep），但驗的是上下文盒不是 `Run` 狀態；`closure_chain` 是否在主評估路徑 UNKNOWN | 待排程（Q2） |
| 037c | `to_mode`、`begin_work_unit`、`select_role` 設定的 role／capability／baseline／revision 能否由 journal 重建，本場未讀本體，UNKNOWN | 待排程（Q2） |
| 038c | G1 實測：`step` 對非 UTF-8 檔、`TimeoutExpired`、`FileNotFoundError` 皆穿出，trace／attempts 為 0、預算未扣（PROGRAM_EXECUTED_PASS；腳本在 P2-RS-Q3 §3；R3d12zf） | 待排程（Q3） |
| 039c | `attempts_to_runs` 把非 success 一律轉 failure；`fp_test_outcome` 只收 exit code。新增 incomplete 若不同改這兩處，逾時會被計成失敗，與 FP3 卡原寫「不計失敗次數」不符（讀碼） | 待排程（Q3） |
| 040c | `Run.ladder`／`retry_decision` 掃描所得呼叫者只有模擬 harness 與 tests，無生產呼叫者；動態呼叫 UNKNOWN | 待排程（Q3） |
| 041c | `retry_decision` 在 attempts 為空時回 PROCEED；attempts 只在記憶體（G2），中斷重建後 `RETRY_MAX=1` 上限歸零（讀碼推得，HYPOTHESIS，未實測） | 待排程（Q3） |
| 042c | `COMMANDS` 是 list、無 shell，逾時只殺直接子行程（S1）；測試若再起子行程可能殘留，process group 作法（S4）是否採用待施工場決定，未實測 | 待排程（Q3） |
| 043c | `task_set`、`capability_router`、`planner_library`、`role_session_gate`、`central_controller` 對 WIRED／maturity 命中皆 0，藍圖 §4.5「只規劃 WIRED」沒有執行力（掃描實測） | 待排程（Q4／R11-A） |
| 044c | `evolution_cycle` 無程式匯入者，再評估不會自動觸發；`.github` 與 registry 的引用見 P2-RS-Q4 §1（動態呼叫 UNKNOWN） | 待排程（Q4） |
| 045c | VERIFY 提供者候選 `closure_chain` 無 VERIFY 字串；`loop_contract`、`role_capability_binding` 在 scripts/ 無檔，位置 UNKNOWN；GAP 無提供者 | 待排程（Q5a） |
| 046c | `state/capabilities` 在解壓根目錄不存在，E-4 狀態檔實際位置 UNKNOWN；`docs/handoffs/LEDGER.md` 10,223 B，超過自訂的 10 KB 上限（R3d12zh 發現） | 待確認 |
| 047c | `evidence_provenance_guard` 三缺口：失敗只有 ValueError，分不出 INCOMPLETE 與 FAILED（G-EV1）；只綁 ResultPacket、不涵蓋研究結論（G-EV2）；「支持」為結構檢查，不驗內容與 locator 可解析（G-EV3）；guard 本身不改 | 待排程（Q7b／R11） |
| 048c | F48 完整回溯沒有多跳回溯函式（名稱掃描，非窮盡）；`knowledge_versioning.py` 命中相關字樣但用途未讀 | 待排程（Q7b） |
| 049c | INSTRUCTION-ROUTING 習慣詞偵測無程式；CONVERSATION-RECORD 的 `dialogue_loop` 只被量測工具 import，無生產呼叫者（G-CR1），登記表 WIRED 名不副實；`p2_run.py` 第 401 行是固定字串，是否為一般路徑未讀（靜態掃描，非窮盡） | 待排程（Q5b／R11-C） |
| 050c | `hands_adapter`：零呼叫者；`DENIED_ACTIONS` 只有 `run_shell`，其餘動作預設放行（G-H1）；逾時只能模擬（G-H2）；`check_exchange` 不去重（G-H3）。R10-E 採選項 1（降為契約原型），登記表未動 | 待排程（Q8b／R11） |
| 051c | RETIRE 的「批次上限」「TASK_SCOPE」在 `lifecycle_sweep.py` 掃描未命中（關鍵字窄，UNKNOWN）；STATISTICS 無提供者；CLUSTER／TREND／ANOMALY 待登記表標 DORMANT＋ADR | 待排程（Q5b／Q8a／R11） |
| 052c | PATTERN、HYPOTHESIS 無程式（MODEL_NATIVE，guard 為設計）；`planner_library.pattern_card` 與 PATTERN 同名異義，施工時避免誤接；N_min 門檻 UNKNOWN；HYPOTHESIS 升格依賴尚不存在的 `counterexample_log`（Q6c 設計）與 G-EV2 的外層綁定 | 待排程（Q7a／R11） |
| 053c | SYNTHESIS 無提供者；`apply_synthesis` 只查必填鍵、不查 VERIFIED 與 Coverage，不能當 guard；「主張」的切分粒度 UNKNOWN；`synthesis_guard` 依賴尚不存在的 `verify_verdict`、`provenance_trace`、`counterexample_log`、`gap_ledger`（施工順序要先做這四個） | 待排程（Q7a／R11-G） |
