# P2-RS-Q1 研究紀錄：蒸餾與呼叫者稽核（FP1～FP10、T4、`caller_audit`）

題組：Q1。場次：R3d12zd。工具：web_search（standard）4 次；web_fetch 0 次（**只讀到搜尋摘要，未讀全文**）。來源日期：頁面未顯示者一律寫 UNKNOWN，不憑記憶補。

## 1. 確認問題（先於研究；repo 內證據）

| 項目 | 結果 | 證據 |
|---|---|---|
| `tools/caller_audit.py` 是否存在 | 不存在 | PROGRAM_EXECUTED_PASS（檔案存在檢查） |
| `batch_gate` 是否有 T4 | 沒有；規則集為 B1～B4、REG、RUN、T1～T3、X0～X2 | PROGRAM_EXECUTED_PASS（字串掃描） |
| `scenario_distill`、`hands_adapter` 的 import 者 | 僅各自的測試檔 | PROGRAM_EXECUTED_PASS（僅 import／字面字串形式；動態載入未排除，HYPOTHESIS） |
| `path_distill` 的 import 者 | `p2_run.py` 與其測試 | 同上 |
| `p2_run` 的 import 者 | `path_distill.py`、`scenario_distill.py` 與測試；**未命中** §2 註所列的 `result_chain`、`track_a_dryrun`、`batch_gate` | 同上；與 §2 註不一致，原因 UNKNOWN（可能別名或動態載入，HYPOTHESIS），列為 OPEN-ISSUES 032c |
| `fast_paths.json` 只登記 FP1～FP3 | 本場僅確認檔案存在、頂層鍵為 evidence_level／inventory_ref／fast_paths／note；登記內容未逐項讀 | PARTIAL；§2 的說法維持 NOT_EXECUTED |
| 本場未做 | 未讀 §7、§13.2、§12（預算）；未重跑回放 61/61；未跑任何單元測試 | NOT_EXECUTED |

## 2. 查詢紀錄（4 次）

| # | 查詢 | 類別 |
|---|---|---|
| Q-1 | shadow mode differential testing replace legacy code path equivalence verification | 精確詞＋方法論 |
| Q-2 | detect code only referenced by tests dead code reachability from entry points Python vulture | 類似問題＋工具 |
| Q-3 | distill LLM agent workflow into deterministic code trace replay compare agent vs compiled path | 業內案例 |
| Q-4 | characterization test golden master limitations shadow testing pitfalls side effects error paths not covered | 失敗案例／限制（反向） |

§14.4 第二輪（用第一批新術語擴大）**NOT_EXECUTED**（預算）。第三輪反向搜尋只做 Q-4 一次。未做的查詢清單：`mutation testing Python mutmut equivalence`、`Python AST call graph importlib dynamic import detection`、`idempotent request id executor retry`（後者屬 Q8b）。

## 3. 來源與可靠性（只讀搜尋摘要；網址為搜尋結果所給）

| 編號 | 來源與網址 | 日期 | 身份／原始性 | 證據性 | 限制 | 參考價值 |
|---|---|---|---|---|---|---|
| S1 | tsouza/cerberus PR #136 https://github.com/tsouza/cerberus/pull/136 | UNKNOWN | 專案 PR，原始 | 有程式與測試計畫 | 單一專案；預言（oracle）尚為替身 | 僅提供方向：預言缺失要明確退出碼，不當作通過 |
| S2 | OpenClaw 串流重構計畫 https://docs.openclaw.ai/experiments/plans/acp-unified-streaming-refactor | UNKNOWN | 專案計畫文件 | 計畫，無結果數據 | 是計畫不是成果 | 僅提供方向：先 shadow 後刪舊路徑 |
| S3 | fsqlite-pager 證明包 https://docs.rs/crate/fsqlite-pager/latest/source/RECLAMATION_PROOF_PACK.md | UNKNOWN | 套件作者文件，原始 | 有三態 auto／legacy／shadow 與比對描述 | 領域是資料庫快取，規模與環境不同 | **條件式參考**：三態開關可映射 `use_fast` |
| S4 | shadow-tool（Go）https://pkg.go.dev/github.com/aaukhatov/shadow-tool | UNKNOWN（僅偽版本） | 函式庫文件，原始 | 有 API 與行為說明 | 明言錯誤路徑對等不在範圍 | **條件式參考／反例**：正好指出 P2 不能只比成功路徑 |
| S5 | freeCodeCamp 差分測試教學 https://www.freecodecamp.org/news/differential-testing-legacy-migration/ | UNKNOWN | 教學文章 | 範例，無獨立數據 | 偏 JS 範例 | 條件式參考：比對前先正規化非決定值、先有邊界 |
| S6 | techinterview.org shadow 模式 LLD https://www.techinterview.org/post/3233473181/lld-shadow-mode-testing/ | 2026-04-18（頁面標示更新日） | 面試教材，二手 | 無實測 | 通用說明 | 條件式參考：shadow 路徑不得有外部可見副作用，用注入替身 |
| S7 | clud 的 Python 死碼稽核技能 https://skillsmp.com/creators/zackees/clud/crates-clud-bin-assets-skills-clud-python-lint-deadcode | UNKNOWN | 工具技能說明（目錄站轉載） | 有規則與退出碼定義，無評測 | 動態分派、entry point 看不到；會有鏈式死碼 | **可直接參考（規則）**：僅測試可達＝生產死碼 |
| S8 | pycmdcheck CQ006 https://py-pkg.thecoatlessprofessor.com/pycmdcheck/checks/CQ006.html | UNKNOWN | 檢查工具文件 | 有行為定義 | 明言動態程式碼誤報多；工具未裝＝NOT_APPLICABLE | 僅提供方向：工具缺失不得算通過 |
| S9 | RightNow-AI/auto wiki https://github.com/RightNow-AI/auto/wiki | UNKNOWN | 廠商專案頁，原始但自述 | 數字為自家宣稱，未獨立驗證 | 宣傳性高 | 僅提供方向：編譯快路徑＋守衛＋退回前沿模型 |
| S10 | TraceCompiler https://arxiv.org/pdf/2608.02680 | UNKNOWN（僅 arXiv 編號） | 論文，原始 | 有指標；作者自承回放比對是自洽檢查，且未量測編譯成本 | 領域 AppWorld | **條件式參考**：「自己比自己」不等於等價，正是 FP4～FP7 的問題 |
| S11 | Reelier releases https://github.com/seldonframe/reelier/releases | UNKNOWN | 專案發布頁 | 倍數為自家宣稱 | 宣傳性 | 僅提供方向：重放時擋有副作用工具、漂移時 exit 1 |
| S12 | 確定性重放文章 https://tianpan.co/blog/2026/04/12/deterministic-replay-debugging-non-deterministic-ai-agents | 2026-04（網址含 2026/04/12） | 部落格 | 無實測 | 單一作者 | 僅提供方向：軌跡格式要版本化 |
| S13 | Wikipedia「Characterization test」 https://en.wikipedia.org/wiki/Characterization_test | UNKNOWN | 百科 | 概念定義 | 二手 | 可直接參考（概念）：只偵測變動，不證明正確 |
| S14 | developertoolkit 特徵化測試 https://developertoolkit.ai/en/workflows/test/characterization-tests/ | UNKNOWN | 教學 | 有流程 | 二手 | 條件式參考：用突變測試證明測試能紅 |
| S15 | Blind Golden Master https://dev.to/rnowif/the-blind-golden-master-67h | UNKNOWN | 個人文章 | 無數據 | 作者自述僅適用無副作用 | 條件式參考：兩路徑並行、回傳舊結果、直到零差異才切換 |

獨立支持：「shadow 回傳舊結果、僅記錄差異」見 S3、S4、S15；「僅測試可達算死碼」只有 S7 明講，S8 僅支持限制面，故證據強度只給中等。

## 4. 與 P2 比對

相同：把舊路徑換成新路徑並要證明等價（FP1～FP3）。不同：P2 是單行程 Python、無網路、無新相依（D-NOAPI）、宿主是模擬 harness；外部多為服務流量取樣，P2 是離線回放。S9、S10 的「編譯 agent 行為」與 P2 的方向相近，但 P2 沒有編譯步驟，只有手寫快路徑。

## 5. 研究結論

1. FP1～FP3 維持真蒸餾。補強兩點：加 mode 三態（fast／legacy／shadow，S3），回放要含**錯誤路徑**（S4 反例，連 G1 逾時也要比）。shadow 時有寫入的步驟用注入的替身 `write_fn`（S6、S15）；比對前先正規化非決定值（S5）。
2. 回放一致只證明「同舊路徑」，不證明正確（S13）；回放要用突變證明會轉紅（S14）。
3. FP4～FP10 不是蒸餾：自比自（S10）。重分類為 scenario／integration／prototype，`mirrors: null`，不計入「蒸餾 DONE」。
4. `caller_audit`：生產呼叫者＝非測試、非 batch_acceptance、非自身、非登記表；僅測試可達算 dead（S7）；動態或 entry point 看不到者列 UNRESOLVED，不算呼叫者也不算 dead（S7、S8）；以 stdlib `ast` 自寫，不引入 vulture（先例 `wiring_audit`；約束）。
5. T4＝新增規則，不改 T1～T3；既有 FP4～FP10 以棘輪式 baseline＋waiver 過渡（只減不增）；`caller_audit` 失敗或不完整＝T4 失敗，不是通過（S1、S8）。
