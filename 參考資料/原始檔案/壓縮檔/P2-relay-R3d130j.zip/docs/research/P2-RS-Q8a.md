# P2-RS-Q8a｜STATISTICS、CLUSTER、TREND、ANOMALY（R3d12zj）

## 1. 確認問題（§14.5）
- 規劃稿 §11.2 稱四項皆 NO_TOOL：本場未另掃描 scripts/ 做名稱搜尋（只靠既有登記表與 §11），HYPOTHESIS 保留。
- 容器是 Python 3.12，`statistics` 為標準庫；`stats_summary` 不需新增相依。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源）
- **S4｜Python 文件《statistics》**，https://docs.python.org/3.4/library/statistics.html （搜尋 1 次，只讀摘要；頁面是 3.4 版，非現行版）。內容：`median` 等函式遇空資料拋 `StatisticsError`；`variance`／`stdev` 需至少兩筆，少於兩筆拋 `StatisticsError`；`pstdev`、`pvariance` 空資料亦拋。
- 同一次搜尋另回傳 chromium.googlesource.com 的 CPython 原始碼鏡像：屬轉載，不採用。

## 3. 可靠性、與 P2 比對、參考價值
- S4：Python 官方文件，原始來源，但版本舊（3.4），細節可能已變；用於「n 下限與例外」這一點，與 P2 條件相同（stdlib、無相依）。參考價值＝**可直接參考**（須在 3.12 以實測確認，UNKNOWN）。
- CLUSTER／TREND／ANOMALY：沒有查任何來源，無參考價值判定。

## 4. NOT_EXECUTED 查詢清單
1. NIST/SEMATECH e-Handbook 的離群值與四分位距、z 分數基線
2. Python `statistics` 現行 3.12 頁面（取代 3.4 頁）
3. scikit-learn 官方使用手冊的分群章節（僅在啟用 CLUSTER 時需要）
4. 趨勢檢定（Mann-Kendall）的官方或標準機構說明
5. 失敗案例：小樣本統計被誤用的官方警示

## 5. 方案評分（約束、失敗覆蓋、可測性、成本、可逆、證據）
- STATISTICS：A stdlib 2/2/2/2/2/1＝11；B pandas 0/1/1/0/1/1＝4；C 模型心算 0/0/1/2/0/0＝3。
- 其餘三項：A DORMANT＋ADR 2/2/2/2/2/1＝11；B 現在自寫 0/1/1/0/1/0＝3；C RETIRE 2/1/1/2/1/1＝8。

## 6. 結論
STATISTICS 做最小 stdlib 純函式；CLUSTER、TREND、ANOMALY 標 DORMANT＋ADR，等消費者出現才啟用。施工在 R11，登記表更新另排。
