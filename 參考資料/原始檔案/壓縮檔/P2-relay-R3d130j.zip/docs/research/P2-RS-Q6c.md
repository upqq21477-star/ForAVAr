# P2-RS-Q6c｜GRAPH、COUNTEREXAMPLE（R3d12zh）

## 1. 確認問題（§14.5）
- 一次性程式掃描（PROGRAM_EXECUTED_PASS；只數字串命中，不證明有呼叫，結論一律 HYPOTHESIS）：
  - GRAPH 相關字串：67 檔，最高 `central_role_interface.py`（54）、`knowledge_versioning.py`（46）；樣式含 cycle，過寬，不代表已有圖模組。
  - COUNTEREXAMPLE 字串：8 檔，最高 `tools/brain_guard.py`（5）、`brain_provider.py`（2）。
- E-4：解壓根目錄下 `state/capabilities` 不存在（`os.path.exists`＝False）；狀態檔實際位置本場 UNKNOWN，未查。
- E-6／E-8：沿用規劃稿 §11、§12 的敘述，本場未重驗登記表。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源）
- **S1｜Python 文件《graphlib》**，https://docs.python.org/3/library/graphlib.html ，頁面標示最後更新 2026-10-14，取得 2026-10-16（搜尋 1 次＋整頁讀取 1 次）。重點：`TopologicalSorter` 自 3.9 起；`prepare()` 檢查循環，有環時拋 `CycleError`（`ValueError` 子類），**多環時只回報其中任意一個**，環在 `args[1]`、首尾同點；`add()` 把未出現過的前驅節點**自動加入圖**；`static_order()` 內部已呼叫 `prepare()`，不可再自行呼叫；3.14 起 `prepare()` 可重複呼叫。
- **S2｜W3C《PROV-O: The PROV Ontology》**，W3C Recommendation，2013-04-30，https://www.w3.org/TR/2013/REC-prov-o-20130430/ （搜尋 1 次＋整頁讀取 1 次）。內容：Entity／Activity／Agent 三類；`wasDerivedFrom`（含子屬性 `wasQuotedFrom`、`hadPrimarySource`）、`used`、`wasGeneratedBy`；`Collection` 與 `hadMember`；`Bundle`＝可被描述來源的具名來源集合；`invalidatedAtTime` 標示實體失效。

## 3. 可靠性、與 P2 比對、參考價值
- S1：Python 官方文件（原始來源）；有日期；描述 API 行為，非宣傳；限制＝只涵蓋標準庫行為，不含 P2 的邊數上限、輸入格式。
- S2：W3C 規格本身（原始來源）；日期明確；是詞彙規範，不是宣傳；W3C 流程有多方審查；限制＝只定義詞彙，不含切分、抽取、搜尋方法。
- GRAPH × S1：問題相同（有向圖循環偵測）、環境相同（標準庫，py3.9+ 涵蓋固定依賴）；參考價值＝**可直接參考**，但有兩處與卡片原假設不符，已就地修正（見下）。
- COUNTEREXAMPLE × S2：問題不同（S2 不談反例）；僅有「集合＝範圍」可借的詞彙；參考價值＝**僅提供方向**。
- **S1 推翻的原假設：** ①卡片原寫「列出環」，實際只能得一個見證環；要列全部環須自寫強連通分量。②卡片原靠「端點缺失→拒收」，但 `graphlib` 會自動補節點、不會報端點缺失，必須自己先檢查。

## 4. NOT_EXECUTED 查詢清單
1. 有向圖 循環偵測 與 可達性 的官方或標準教材（若要自寫強連通分量）
2. 知識圖 端點缺失 dangling edge 驗證 做法
3. 反例搜尋 falsification 在 LLM agent 假設驗證的官方說明
4. 「未找到」不等於「不存在」：檢索覆蓋範圍紀錄的官方指引
5. 失敗案例：LLM 自述「已搜尋」未實際執行
（已執行：graphlib 行為＝S1；PROV 對範圍的詞彙＝S2）

## 5. 方案評分（0～2 × 6 項：約束、失敗覆蓋、可測性、成本、可逆、證據）
- GRAPH：A 純函式（graphlib＋自寫端點檢查）2,2,2,2,2,2＝12；B 圖套件 0,2,1,1,1,0＝5；C 模型判斷循環 1,0,0,2,2,0＝5。取 A。
- COUNTEREXAMPLE：A `counterexample_log` 2,2,2,2,2,1＝11；B 模型自述已搜 0,0,1,2,2,0＝5；C 強制外部搜尋 0,1,0,1,1,0＝3。取 A。

## 6. 結論
GRAPH 採標準庫，但卡片已修正兩處（單一見證環、端點檢查在前）。COUNTEREXAMPLE 仍是本地記錄＋降級，證據只在詞彙層。
