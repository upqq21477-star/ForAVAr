# P2-RS-Q7b｜EVIDENCE、PROVENANCE（R3d12zi）

## 1. 確認問題（§14.5）
- **讀碼核實（`evidence_provenance_guard.py` 全檔 6.1 KB 已讀；未實跑）：** 登記表稱 WIRED 成立——`execution_truth.py` 呼叫 `guard_success`、`result_chain.py` 呼叫 `validate_evidence`／`validate_provenance`、`tools/capability_run.py` 有入口；非測試呼叫者 4 個（其中 `tools/wiring_audit.py` 只是稽核工具）。
- 發現三個缺口：G-EV1（失敗只有 ValueError，分不出 INCOMPLETE 與 FAILED）；G-EV2（只綁 ResultPacket，不涵蓋研究結論）；G-EV3（「支持」只是結構檢查，不驗內容、不驗 locator 可解析）。
- F48 完整回溯：函式名稱掃描（trace_back、ancestors、lineage 等）只命中 `knowledge_versioning.py`，用途未讀＝UNKNOWN；掃描非窮盡，判定為「未實作」是 HYPOTHESIS。
- 容器純 python 沒有 `jsonschema`；固定依賴以 repo 後備或 REAL 4.26 提供（`fixed_deps_gate.py` 內有說明）。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源）
- **S2｜W3C《PROV-O》**（2013-04-30，https://www.w3.org/TR/2013/REC-prov-o-20130430/ ）：R3d12zh 已整頁讀取，內容見 `docs/research/P2-RS-Q6a.md` §2；本場沿用，未重讀。
- **S5｜W3C《Constraints of the PROV Data Model》**，W3C Recommendation 2013-04-30，https://www.w3.org/TR/prov-constraints/ （搜尋 1 次，只讀摘要）。內容：定義「有效的 PROV 實例」，約束分四類——唯一性、事件順序、不可能、型別；唯一性與推論用來正規化，其餘在正規形上檢查；例：同一實體與活動只能有一次產生、產生須早於使用；檢查有效性為「建議但不強制」。W3C 版本庫（dvcs）的修訂紀錄為編輯歷史，不採用。
- **S6｜Anthropic〈Reduce hallucinations〉**，https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/reduce-hallucinations （搜尋 1 次，只讀摘要，無發布日期＝UNKNOWN）。內容：明確允許模型承認不確定；要求引文以便稽核，並可事後為每個主張找支持引文；多次執行比對一致性；限制只用提供的文件；文末聲明這些技巧只降低、不能消除錯誤。社群貼文與科技媒體轉述不採用。
- **S1｜Python 文件《graphlib》**（https://docs.python.org/3/library/graphlib.html ）：R3d12zh 已整頁讀取，內容見 `docs/research/P2-RS-Q6c.md` §2；本場沿用。
- **參考價值：** S5＝**條件式參考**（約束分類與兩條可借的檢查；全套 53 條對 P2 過度）；S2＝僅提供方向；S6＝條件式參考（逐項主張找支持引文，作為 VF 的輔助）。

## 3. 可靠性、與 P2 比對、參考價值
- S5：W3C Recommendation，原始來源，日期明確；限制＝本場只讀摘要，約束全文未讀，條號與內容以官方頁為準；檢查有效性屬「建議」。
- S2、S6、S1：見各自前述研究檔與本檔 §2。
- 與 P2 比對：EVIDENCE／PROVENANCE 的單跳檢查與 PROV 的產生／使用關係同型；P2 缺的是多跳與順序約束。

## 4. NOT_EXECUTED 查詢清單
1. PROV-CONSTRAINTS 全文整頁（只讀了摘要；條號與推論規則待核）
2. PROV-DM 對「來源鏈」的定義與衍生鏈（derivation chain）
3. 引用忠實度（citation faithfulness／attribution）評估方法的官方或標準來源
4. 證據支持的語意驗證（NLI 類）限制
5. 失敗案例：引文存在但不支持主張

## 5. 方案評分（0～2 × 6 項：約束、失敗覆蓋、可測性、成本、可逆、證據）
- EVIDENCE：A 維持現有 guard＋外層補三缺口 2,2,2,1,2,1＝10；B 重寫 guard 1,1,1,0,0,0＝3；C 模型審證據語意當 VF 輔助 1,1,0,1,2,1＝6。取 A。
- PROVENANCE：A `provenance_trace`＋兩條約束 2,2,2,2,2,1＝11；B 完整實作 PROV-CONSTRAINTS 0,1,0,0,1,1＝3；C 維持單跳 2,0,2,2,2,0＝8。取 A。

## 6. 結論
Q7b 不是「只需核實」：WIRED 成立，但有三個缺口與一個未實作功能（F48）。現有 guard 不動（不放寬 gate），缺口在外層補。G-EV2 會影響 Q7a（研究結論需要證據綁定）。
