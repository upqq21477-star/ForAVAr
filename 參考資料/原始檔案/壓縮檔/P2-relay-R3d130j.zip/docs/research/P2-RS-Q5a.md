# P2-RS-Q5a｜VERIFY、GAP、ITERATE（R3d12zg，與 Q4 併場）

證據標記：確認問題＝PROGRAM_EXECUTED_PASS（一次性掃描）；外部來源證據強度最高 1。

## 1. 確認問題（提供者候選，原 HYPOTHESIS）
| 項目 | 結果 |
|---|---|
| VERIFY 由 closure_chain＋Run.close＋role_session_gate 承擔 | 未獲支持：字串命中 closure_chain 0、role_session_gate 1、p2_run 2；是否以他詞實作 UNKNOWN |
| ITERATE 由 Run.ladder／dependency／loop_contract 承擔 | 部分：`dep`＝`debug_escalation_policy`，p2_run 已匯入；`Run.ladder` 在 p2_run 第 233 行；`loop_contract` 在 scripts/ 無此檔（位置 UNKNOWN） |
| `wiring_audit --json` | VERIFY：UNWIRED，consumer 僅字串引用；GAP：UNWIRED，provider／consumer UNKNOWN；ITERATE：UNWIRED，consumer 僅字串引用 |

## 2. 查詢紀錄（日期 2026-10-16）
- Q-4 `Anthropic "Building effective agents" evaluator-optimizer stopping conditions`：結果皆二手（部落格、教學站、摘要站），不採。
- Q-5 `anthropic.com engineering building effective agents`：結果內文帶出一手網址，改以整頁讀取（F-2）取得 S4。
- NOT_EXECUTED（5 條）：① LLM-as-a-judge 的偏誤與限制（原論文，如 MT-Bench 論文） ② OpenAI Agents SDK 的最大回合設定文件 ③ LangGraph 遞迴上限文件 ④ Anthropic 長時間代理（harness）工程文章 ⑤ 反例：迭代迴圈不收斂或自評過鬆的案例。

## 3. 來源與可靠性
| 編號 | 來源 | 身份 | 內容（改寫） | 限制 |
|---|---|---|---|---|
| S4 | Anthropic〈Building effective agents〉https://www.anthropic.com/engineering/building-effective-agents（2024-12-19 發布；頁面標 2026-08-10 修改；2026-10-16 整頁讀取） | 官方、原始 | evaluator-optimizer 適用於評估標準明確且迭代有可量測收益；代理每步應取環境的真實回饋（工具結果、程式執行）；常加最大迭代數等停止條件；測試可驗功能，但仍需人工審查系統層面需求 | 未給迭代上限數字；文內自註工具環境自 2024-12 已有變動；不是驗證獨立性的研究 |

未採用：agentpatterns.ai、skills.sh、promptlayer 等二手頁（其中「參考實作無上限迴圈」「5～15 輪」等說法未在一手頁面找到，不引用）。

## 4. 與 P2 比對與參考價值
- S4：**條件式參考**。可借：以環境證據（exit code）為準、必有停止條件、人工審查保留（對應 R9）。不借：用 LLM 當評估者（D-NOAPI；且判官限制未查）。
- 差異：P2 的 VERIFY 須獨立 session、有 INCOMPLETE 第三態；ITERATE 的重試只准在 ladder 一層（Q3 結論）。

## 5. 最優解（0～2：約束／失敗覆蓋／可測／成本／可逆／證據）
| 方案 | 分 | 說明 |
|---|---|---|
| A 決定論薄模組 `verify_verdict`／`gap_ledger`／`iterate_control`，接 `Run.close` | 10（2,2,2,1,2,1） | 不用 API；同輸入同輸出；可退回原路徑 |
| B LLM 評估者＋evaluator-optimizer 迴圈 | 3（0,1,0,0,1,1） | 違反 D-NOAPI；不可重現；測不了 |
| C 三者降為 NO_TOOL，由 Brain 語意執行 | 7（2,0,1,2,2,0） | 無中斷與出錯處理；與 §11 表衝突 |
結論：採 A，一行理由：三者都是機械判斷，用程式取代語意操作（符合接力規則）。卡片見規劃稿 §16（VERIFY、GAP、ITERATE 3 張）。
