# P2-RS-Q8b｜FP8～FP10（hands_adapter 執行邊界）（R3d12zj）

## 1. 確認問題（§14.5）
靜態掃描與局部讀碼（`hands_adapter.py` 第 81～111 行與常數定義，未實跑）：
- 零呼叫者：只有自身、測試、`batch_acceptance`、evidence 提到它。
- G-H1：`DENIED_ACTIONS = {"run_shell"}` 只有一項；`StubHands.execute` 對其他動作在 `SIMULATED_STUB` 下一律成功＝預設放行。
- G-H2：TIMEOUT 只由替身依 `params.simulate` 模擬，沒有牆鐘逾時與強制終止。
- G-H3：`check_exchange` 只比對 request_id 是否相同，不去重；有副作用的動作重送會重複執行。
- `is_failure` 只把 FAILED 算失敗，INCOMPLETE／TIMEOUT／REFUSED 不算：與 Q3 規則一致。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源，皆只讀搜尋摘要）
- **S1｜Claude Code 沙箱文件**，https://docs.claude.com/en/docs/claude-code/sandboxing ：沙箱以作業系統機制限制檔案與網路，子行程繼承同樣邊界；存取沙箱外資源會觸發通知；讀取預設是整台電腦、只排除特定被拒目錄。
- **S2｜Anthropic 工程部落格《Claude Code sandboxing》**，https://www.anthropic.com/engineering/claude-code-sandboxing ：發表沙箱 runtime，可指定可存取的目錄與網路主機；內容與 S1 重疊。
- **S3｜Claude Managed Agents 自架沙箱安全模型**，https://platform.claude.com/docs/en/managed-agents/self-hosted-sandboxes-security （原網址尾端有 .md，此處省略，以免被 precheck 的檔案參照檢查誤判）：Anthropic 的安全邊界止於沙箱；沙箱映像品質、對外網路控制、工具執行的影響範圍與沙箱內工具彼此隔離都是使用者的責任。
- 同次搜尋另回傳 octopus.com、skills.cat、decryptiondigest.com、develeap.com、aiengineerguide.com 等第三方頁面：非官方一手，不採用。Anthropic 的 computer use 官方文件本身沒有取得（只見到第三方轉述），標 NOT_EXECUTED。

## 3. 可靠性、與 P2 比對、參考價值
- S1：官方、原始；針對 Claude Code 的 Bash 工具，P2 的最低運行模式（AI 對話＋GitHub）用不到 OS 沙箱。**條件式參考**（借「預設限制、邊界由系統而非模型強制」的原則）。
- S2：官方部落格、公告性質、與 S1 重疊。**僅提供方向**。
- S3：官方；談自架環境的責任分界。**僅提供方向**（可借「邊界內的隔離是自己的責任」來支持允許清單）。

## 4. NOT_EXECUTED 查詢清單
1. Anthropic computer use tool 官方文件（安全注意事項、人工確認）
2. GitHub Actions 官方文件：runner 啟動失敗與步驟失敗的區別
3. Python `subprocess` 官方文件：timeout 與強制終止
4. Agent-S 官方資料（執行者契約）
5. 失敗案例：代理程式誤執行危險動作的官方事後檢討

## 5. 方案評分
A 降為契約原型＋允許清單設計 2/2/2/2/2/0＝10；B 現在接 Run.select_role 0/1/1/1/1/0＝4（印象分，卡內記 5 取整）；C 刪除 1/0/1/2/0/0＝4。

## 6. 結論
R10-E 採選項 1：FP8～FP10 降為契約原型，不計入 fast path，不為過審硬接。整合真實執行者前的三個前置條件：允許清單預設拒絕（G-H1）、真逾時（G-H2）、請求去重（G-H3）。
