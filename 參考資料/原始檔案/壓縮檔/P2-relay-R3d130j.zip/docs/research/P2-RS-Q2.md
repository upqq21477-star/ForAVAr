# P2-RS-Q2 研究紀錄：中斷續跑與持久化（G2、G3、G4、FP4）

題組：Q2。場次：R3d12ze。工具：web_search（standard）4 次；web_fetch 0 次（**只讀搜尋摘要，未讀全文**）。頁面未顯示的日期一律 UNKNOWN。

## 1. 確認問題（讀 `p2_run.py` 的 `Run.__init__`、`_log`、`step`、`_edit`、`_run_tests`、`ladder`、`close`；行為皆未執行）

| 項目 | 結果 | 證據 |
|---|---|---|
| G1 `step` 只攔 `GateReject`、`TypeError`；`_run_tests` 有 `timeout=30` 卻不攔 `TimeoutExpired`；預算扣除與 `_log` 在工具回傳之後 | **確認** | 讀碼；行為 NOT_EXECUTED（細節歸 Q3） |
| G2 trace／attempts／diffs 只在記憶體 | **確認，但需修正**：`close()` 只寫兩筆對話記錄與收尾狀態，**trace 本身從未被寫入 EventLog**；正常結束也不留 trace，只把鏈頭雜湊放進 refs | 讀碼 |
| G3 `Run` 無續跑入口 | **確認**：`p2_run.py` 內無 resume 字樣。另發現 `resume_check` **有**非測試呼叫者 `closure_chain.py`（grep，PROGRAM_EXECUTED_PASS），但它驗的是 Current／任務包／上下文盒，不是 `Run` 狀態；`closure_chain` 是否在主評估路徑仍 UNKNOWN | grep＋讀碼 |
| G4 預設 `write_fn` 直接 `write_text`；`_edit` 回滾也是 `write_text` | **確認**；`p2_run.py` 內無暫存檔、`os.replace`、`fsync` | 讀碼＋grep（PROGRAM_EXECUTED_PASS，限字串缺席） |
| 可利用的既有結構 | trace 每筆已有 `prev`／`hash` 鏈，且有 `verify_trace`；`budget` 只在 ALLOW 時遞減，故可由 ALLOW 筆數重算 | 讀碼 |
| 未讀、仍 UNKNOWN | `to_mode`、`begin_work_unit`、`select_role` 本體；role／capability／baseline／revision 是否都能由 journal 重建 | 本場預算 |

## 2. 查詢紀錄（4 次）

| # | 查詢 | 類別 |
|---|---|---|
| Q-1 | durable execution checkpoint resume agent workflow idempotent steps replay after crash | 精確詞＋業內案例 |
| Q-2 | Python atomic file write temp file fsync os.replace directory fsync crash safe | 工具／方法論 |
| Q-3 | append-only JSONL write-ahead log torn last line recovery hash chain replay verify | 相似結構 |
| Q-4 | idempotency key pitfalls resume after crash side effect executed but not recorded duplicate checkpoint limitations | 失敗案例／限制（反向） |

第二輪（用新術語擴大）NOT_EXECUTED。未做清單：`sqlite3 WAL mode stdlib crash safety`、`fcntl flock stale lock detection Python`、`saga compensation local file edits`。

## 3. 來源與可靠性（只讀摘要）

| 編號 | 來源與網址 | 日期 | 身份／原始性 | 限制 | 參考價值 |
|---|---|---|---|---|---|
| S1 | livingai（PyPI）https://pypi.org/project/livingai/ | UNKNOWN | 套件頁，自述 | 效能數字自家宣稱；超出開銷預算就丟棄 checkpoint | 僅作反例：P2 不得為省開銷而漏記 |
| S2 | LangGraph durable execution https://docs.langchain.com/oss/python/langgraph/durable-execution/index.html | UNKNOWN | 廠商文件，原始 | 前提是步驟決定性、副作用包進 task | 條件式參考：P2 的 `Run` 由外部逐步驅動，不需重播程式碼 |
| S3 | durare 耐久模型 https://docs.rs/crate/durare/latest/source/src/durability.rs | UNKNOWN | 套件原始碼註解 | Rust 非同步環境 | **條件式參考**：效果與 checkpoint 是兩次寫入，中間可被崩潰切開 |
| S4 | Diagrid 部落格 https://www.diagrid.io/blog/durable-execution-runtime-primitive-agents | UNKNOWN | 廠商行銷 | 宣傳性 | 僅提供方向：重試不等於續跑 |
| S5 | atomic-json-io https://pypi.org/project/atomic-json-io/ | UNKNOWN | 小型套件頁 | 僅 Linux；同檔案系統才原子 | **可直接參考（配方）**：同目錄暫存檔→flush＋fsync→`os.replace` |
| S6 | safeatomic https://pypi.org/project/safeatomic/ | UNKNOWN | 套件頁 | 自述保證是模型假設 | 條件式參考：加做父目錄 fsync |
| S7 | NVIDIA cuda.core 檔案快取 https://nvidia.github.io/cuda-python/cuda-core/latest/generated/cuda.core.utils.FileStreamProgramCache.html | UNKNOWN | 大廠官方文件，原始 | 領域不同 | **可直接參考（限制面）**：不做目錄 fsync 則對讀者原子但不耐當機；Windows 的 replace 會因檔案被占用失敗 |
| S8 | logdb 復原文件 https://docs.rs/crate/logdb/latest/source/docs/en/usage/recovery（網址結尾的 .md 省略，避免被 refs 檢查當成 repo 路徑） | UNKNOWN | 套件文件 | Rust 資料庫 | 條件式參考：尾端撕裂截到最後完整記錄；雜湊鏈另驗 |
| S9 | bernstein replay https://bernstein.readthedocs.io/en/latest/operations/replay/ | UNKNOWN | 專案文件 | 規模與領域不同 | **條件式參考（最相近）**：開啟時重驗整條雜湊鏈；撕裂尾行與竄改分開處理；損毀時 fail closed 並隔離檔案 |
| S10 | zeph-session 日誌模組 https://docs.rs/zeph-session/0.22.4/zeph_session/log/ | UNKNOWN | 套件文件 | Rust | 條件式參考：先寫日誌再更新下游；撕裂只可能在最後一行；無鎖的讀取不得改檔；單一寫入者 |
| S11 | registry-stack issue 196 https://github.com/registrystack/registry-stack/issues/196 | UNKNOWN | 使用者通報（單一案例） | 非獨立重現 | **反例**：撕裂尾行加上 fail closed 的鏈驗證，結果是沒有受支援的復原路徑、只能手動搬檔 |
| S12 | car-workflow checkpoint https://docs.rs/crate/car-workflow/latest/source/src/checkpoint.rs | UNKNOWN | 套件原始碼註解 | Rust | 條件式參考：領取標記保證至多一次續跑；**不是**跨崩潰的恰好一次，非冪等副作用要在效果邊界用冪等鍵 |
| S13 | DEV「Stopped My AI Agent…」https://dev.to/yureki_lab/how-i-stopped-my-ai-agent-from-doing-the-same-thing-twice-after-a-crash-3bi3 | UNKNOWN | 個人文章 | 無數據 | 僅提供方向：做完與記錄之間有空隙；意圖帳與效果分開 |
| S14 | tianpan 非同步 agent 設計 https://tianpan.co/blog/2026-03-07-async-agent-workflows-long-running-task-design | 2026-03-07（網址） | 部落格 | 無數據 | 僅提供方向：冪等鍵＝任務編號加步驟序號；執行前先存 checkpoint |

獨立支持：效果與紀錄之間有空隙——S3、S12、S13；原子寫配方與目錄 fsync——S5、S6、S7；撕裂尾行與竄改要分開——S8、S9、S10。

## 4. 與 P2 比對

相同：崩潰後不重做已完成工作、不重複副作用。不同：P2 的 `Run` 每步由外部呼叫者驅動、單行程、步數上限＝預算（預設 12），副作用只有檔案編輯與跑測試；外部多為長時間分散式工作流。所以重播決定性程式碼（S2、S3）不需要，狀態重建即可；S11 提醒要先設計損毀後的出路。

## 5. 研究結論

1. 持久化用追加式 JSONL journal，沿用現有 `prev`／`hash` 鏈；每筆 flush＋fsync 後才算完成；寫入失敗就停（S1 反例）。
2. 副作用步驟前寫 intent，效果後寫完成；續跑時用檔案雜湊對帳 intent，不重跑 `_edit`（重跑會得 EDIT_NO_MATCH）。冪等鍵＝run_id:seq。
3. 續跑＝重建狀態（預算由 ALLOW 筆數重算），不重播步驟。
4. 讀取時：只有最後一行壞＝撕裂，丟棄並警告；鏈中間壞＝損毀，拒絕續跑並指名行號，由人決定隔離，不自動重啟新鏈、也不卡死（S9、S11）。無鎖讀取不改檔；寫入者用非阻塞檔案鎖，不強拆（S10、S12）。
5. 原子寫：同目錄暫存檔→fsync→`os.replace`→fsync 目錄（S5、S6、S7），stdlib 自寫。
