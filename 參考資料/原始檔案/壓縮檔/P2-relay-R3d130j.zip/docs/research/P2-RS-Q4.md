# P2-RS-Q4｜能力啟用閘門、狀態檔、再評估觸發（R3d12zg，與 Q5a 併場）

證據標記：確認問題＝PROGRAM_EXECUTED_PASS（一次性掃描）；外部來源＝讀取所得，證據強度最高 1（一手規格，但不是同規模系統）。

## 1. 確認問題
| 項目 | 原標記 | 結果 |
|---|---|---|
| E-1 | HYPOTHESIS | 證實：`planner_library`(660 行)、`task_set`(212)、`capability_router`(203)、`role_session_gate`(208)、`central_controller`(892) 對 WIRED／maturity／wiring_audit／capability_maturity 命中皆 0。`scripts/role_capability_binding.py` 不存在，位置 UNKNOWN（未查） |
| E-4 | 事實 | 證實：`state/capabilities/` 只有 `CAP-SEARCH.json`（1/23） |
| E-5 | HYPOTHESIS | 部分證實：`evolution_cycle` 在 scripts／tools 無任何匯入者（import 掃描）；`.github` 內引用它的檔：無。其餘字串引用如下（schema／policy／registry）：
```
P1-Central-Control/control_gate_registry.json:13:    "P1-Central-Control/tests/test_evolution_cycle.py",
P1-Central-Control/policy/governance_rule_map.v1.0.json:523:   "gap": "evolution_cycle 只有 eval 欄位，無 A／B／C／D 結構"
```
是否由工作流以命令呼叫：以上命中為準，未見則視為無自動觸發（動態呼叫可能漏，HYPOTHESIS） |

## 2. 查詢紀錄（5 次搜尋＋讀取中的 Q4 部分；日期 2026-10-16）
- Q-1 `Kubernetes feature gates alpha beta GA stages official documentation`：結果全是 GKE 與第三方託管文件，屬二手，不採。
- Q-2 `kubernetes.io docs reference command-line feature-gates ...`：取得 S1、S2。
- Q-3 `modelcontextprotocol.io specification lifecycle capability negotiation initialization`：取得 S3b；再讀 S3。
- NOT_EXECUTED（4 條）：① kubernetes.io 完整 feature-gates（Alpha/Beta）頁 ② Kubernetes 畢業準則（KEP）頁 ③ OpenFeature 規格（旗標評估失敗的處理） ④ 反例：能力登記表過期造成誤放行的案例。

## 3. 來源與可靠性
| 編號 | 來源（網址，日期） | 身份／原始性 | 內容（改寫） | 限制 |
|---|---|---|---|---|
| S1 | kubernetes.io 部落格〈Moving Forward From Beta〉https://v1-34.docs.kubernetes.io/blog/2020/08/21/moving-forward-from-beta/（日期取自網址） | 專案官方、原始 | 功能走 Alpha→Beta→GA，用 feature gate 開關；beta 的 REST API 若三個版本內未畢業，下一版就棄用 | 規模與 P2 差很多；本頁是搜尋摘要，非整頁讀取 |
| S2 | kubernetes.io 〈Feature Gates (removed)〉https://kubernetes.io/docs/reference/command-line-tools-reference/feature-gates-removed/（無發布日期；2026-10-16 讀取） | 官方參考文件 | 每個 gate 有 預設值／階段／起訖版本；GA 或棄用的 gate 仍被辨識但不再改變行為，移除的才不被辨識 | 同上 |
| S3 | modelcontextprotocol.io 〈Versioning and Compatibility〉https://modelcontextprotocol.io/specification/latest/basic/lifecycle（導向 2026-07-28 修訂；2026-10-16 整頁讀取） | 規格官方、原始 | 新修訂不再握手，能力隨每個請求宣告；雙方一方不支援某擴充時，支援方須退回核心行為或回錯誤，不得默默照做 | 傳輸協定規格，不是任務規劃 |
| S3b | 同站〈Lifecycle〉2025-11-25 版（搜尋摘要） | 同上 | 舊版：初始化必須是第一個互動，雙方交換能力；初始化完成前不送其他請求 | 已被新修訂取代 |

未採用：GKE 與其他託管商文件（二手）。

## 4. 與 P2 比對與參考價值
- S1／S2：階段表（預設值＋階段＋起訖）對應 P2 的 maturity；借「預設關閉」與「限期未畢業就標記」；**條件式參考**（單機單程序、無版本發佈週期）。
- S3：「能力不符時退回核心或拒絕」直接對應 `task_set` 看到非 WIRED 能力時的行為；**可直接參考（原則，不照搬協定）**。
- 差異：P2 的消費者與提供者在同一程序內，能力狀態由 `wiring_audit` 靜態掃出，不是執行期協商。

## 5. 最優解（6 項各 0～2：約束／失敗覆蓋／可測／成本／可逆／證據）
| 方案 | 分 | 說明 |
|---|---|---|
| A 成熟度檔（wiring_audit 產生）＋閘門＋惰性狀態檔 | 10（2,2,2,1,2,1） | 不增相依；缺檔或過期＝拒絕；可退回原路徑 |
| B 引入旗標框架／服務 | 3（0,1,1,0,1,0） | 新相依，違反約束；未研究（④ NOT_EXECUTED） |
| C 預建 23 個狀態檔＋閘門 | 8（2,2,2,0,1,1） | 22 個空檔沒有評估內容，成本高 |
結論：採 A，一行理由：最少新增物、缺口一律 fail closed。卡片見規劃稿 §16（閘門、狀態檔、再評估觸發 3 張）。
