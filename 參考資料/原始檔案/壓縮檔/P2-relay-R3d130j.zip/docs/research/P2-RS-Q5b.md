# P2-RS-Q5b｜INSTRUCTION-ROUTING、CONVERSATION-RECORD、RETIRE（R3d12zj）

## 1. 確認問題（§14.5）
以下皆為靜態字串掃描，不是呼叫證據，且掃描非窮盡：
- **INSTRUCTION-ROUTING：** 規劃稿的提供者候選（`role_command_router`）部分成立。`role_command_router.resolve_and_record` 被 `p2_run.py` 第 401 行呼叫（傳入固定字串，是否為一般路徑＝UNKNOWN），`central_role_interface.py` 呼叫 `resolve`。習慣詞偵測（三次確認）：掃「習慣／三次／high-freq」零命中＝無程式。登記表的 UNWIRED 只對習慣半部成立。
- **CONVERSATION-RECORD：** `dialogue_loop` 只被 `tools/capability_run.py`（量測工具）import；`resume_from_brief`、`verify_dialogue` 沒有生產呼叫者（G-CR1）。登記表自承全文保存與會議合併未實作。
- **RETIRE：** `lifecycle_sweep` 有三個生產呼叫者（`control_gate_runtime`、`local_acceptance`、`repository_result_ingestion`），`_is_protected` 存在；§11 所稱批次上限與 TASK_SCOPE 在掃描中未命中（關鍵字窄，UNKNOWN）。

## 2. 外部研究
本題組沒有執行任何外部查詢。

## 3. 可靠性、與 P2 比對、參考價值
不適用（無來源）。

## 4. NOT_EXECUTED 查詢清單
1. Claude Code 官方文件的 slash command／自訂指令說明（指令表與未知指令處理）
2. 官方文件：使用者確認與權限提示的設計（重複確認後才授權）
3. append-only 事件日誌／event sourcing 的官方或標準機構說明
4. 資料保留與刪除（retention）的官方指南，尤其冪等刪除
5. 失敗案例：誤刪、批次刪除中斷的官方事後檢討

## 5. 方案評分
- ROUTING：A router＋`habit_counter` 2/2/2/1/2/0＝9（卡內記 10 為估計偏高，以此為準）；B 模型判斷 0/0/0/2/1/0＝3；C 只留！指令 2/1/2/2/2/0＝9。平手取較簡單且可逆者＝C 作過渡，A 為目標。
- RECORD：A 接生產呼叫者＋明列缺口 2/2/2/1/2/1＝10；B 全文保存 1/1/1/0/1/0＝4；C 現狀 0/0/1/2/0/0＝3。
- RETIRE：A 沿用並核實 2/2/2/2/2/0＝10；B 新閘門 1/1/1/0/1/1＝5；C 不動 0/0/1/2/1/0＝4。

## 6. 結論
三項都不新增模組（ROUTING 的習慣半部除外）；先核實再接線。CONVERSATION-RECORD 的 WIRED 標記名不副實，應在登記表降級說明（R11-C）。
