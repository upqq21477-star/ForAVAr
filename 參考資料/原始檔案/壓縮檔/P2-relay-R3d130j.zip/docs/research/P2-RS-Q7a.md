# P2-RS-Q7a｜PATTERN、HYPOTHESIS、SYNTHESIS（D1＋D2）（R3d12zj）

## 1. 確認問題（§14.5）
- 名稱掃描（scripts/、tools/ 的 def／class，非窮盡）：沒有 PATTERN 或 HYPOTHESIS 的程式；只命中 `planner_library.pattern_card`、`select_patterns`，那是規劃用設計模式，與本能力同名不同義。
- 登記表：兩者 kind＝MODEL_NATIVE、dependencies 空；§11.3 初始模式＝MODEL_PLUS_GUARD。結論：模型產生、決定論 guard 檢查，guard 是新模組（`pattern_guard`、`hypothesis_guard`），施工在 R11。
- SYNTHESIS（D2）：`conversation_analysis_report.apply_synthesis`（第 248～262 行已讀）只檢查必填鍵並推進階段，不查 VERIFIED 與 Coverage，唯一呼叫者是同檔 CLI；`run_p2_validation_cycle.selected_final_integration_report` 只選報告檔名。兩者都不是 CAP-SYNTHESIS 的提供者。
- 上游沿用：Q6c 的 COUNTEREXAMPLE 卡（`counterexample_log`、SCOPE_LIMITED 語意）、Q7b 的 G-EV2（研究結論未被證據 guard 涵蓋）。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源）
- **S5｜NIST/SEMATECH e-Handbook of Statistical Methods，第 1 章 Exploratory Data Analysis**，https://itl.nist.gov/div898/handbook/eda/eda.htm （搜尋 1 次，只讀摘要；章節摘要作者 Heckert、Filliben，2003）。內容：EDA 是一種分析哲學，先不預設資料遵循哪種模型，讓資料自己顯露結構；技術以圖形為主、少量量化；分析者應先指認與問題相關的問題，才用得上針對性技術；常見問題包括典型值、離群值、能否從多變量資料取出結構；章節目標含找出結構、偵測離群值、檢驗基本假設。
- 同次搜尋另回傳 slideshare 的第三方投影片：非一手，不採用。

## 3. 可靠性、與 P2 比對、參考價值
- S5：美國政府機構出版、原始來源；內容是通用方法論，不是針對 LLM 代理；以圖形為主，P2 最低運行模式（AI 對話＋GitHub）沒有圖形工具。參考價值＝**條件式參考**：只借「先寫明問題與範圍」與「結構由資料顯露、模型後出」兩點，對應 PATTERN 的 scope 欄與 CANDIDATE 標記。
- HYPOTHESIS：沒有取得任何來源，無參考價值判定。

## 4. NOT_EXECUTED 查詢清單
1. 官方資料談科學假設的證偽、替代解釋（例如 NIST 或大學出版社以外的官方科學方法說明）
2. Anthropic 官方關於讓模型列出替代解釋或反證的提示指引
3. 樣本數門檻（N_min）的官方統計指引
4. 失敗案例：模型編造模式、過度擬合的官方警示
5. SYNTHESIS：帶不確定性的整合、citation faithfulness／attribution 評估（官方資料）；Anthropic 官方關於讓模型標明「待驗證」與「部分結論」的提示指引
6. 失敗案例：整合階段把未驗證結論寫成完整結論的官方事後檢討

## 5. 方案評分（SYNTHESIS：A 模型撰寫＋決定論 guard 2/2/2/1/2/0＝9；B 模型自述 0/0/1/2/0/0＝3；C 全人工 2/1/0/0/2/0＝5）

### 5.1 PATTERN、HYPOTHESIS（約束、失敗覆蓋、可測性、成本、可逆、證據）
- PATTERN：A 模型＋決定論 guard 2/2/2/1/2/1＝10；B 純規則探勘 1/1/1/0/1/0＝4；C 只靠模型 0/0/1/2/0/0＝3。
- HYPOTHESIS：A 薄 guard＋版本化 2/2/2/1/2/1＝10（評分時證據項實為 0，總分記 10 為偏高估計，以 9 為準）；B 模型自述 0/0/1/2/0/0＝3；C 全人工審 2/1/0/0/2/0＝5。

## 6. 結論
兩個能力都不自己「判斷對錯」，只確保：有證據引用、有範圍、有替代解釋、等級 2 以上有反例紀錄，否則不得升格（fail closed）。SYNTHESIS 同一原則：結論中每個主張都要綁到 VERIFIED 的 claim，假設只有 ACCEPTABLE 才能當事實，有未結缺口就只能是部分結論。D2 沒有外部查詢。
