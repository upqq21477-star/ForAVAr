# P2-RS-Q6b｜CLASSIFY、RELATION、TEMPORAL（R3d12zi）

## 1. 確認問題（§14.5）
- 本題組三個能力登記表皆 UNWIRED（§11）；提供者掃描沿用 §12 的歸屬（RELATION 與 CLASSIFY 為 MODEL_PLUS_GUARD、TEMPORAL 為 SKILL），未另做程式掃描。
- 程式掃描（PROGRAM_EXECUTED_PASS，字串命中，不證明呼叫）：時間相關字串 14 檔，最高 `knowledge_versioning.py`（31）；關係相關 61 檔，最高 `knowledge_canon.py`（45）；分類相關 37 檔；樣式過寬，雜訊高，不當作提供者證據。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源）
- **S4｜W3C《Time Ontology in OWL》**，W3C Working Draft 2016-07-12，https://www.w3.org/TR/2016/WD-owl-time-20160712/ （搜尋 1 次，只讀摘要；同批結果另有 2006 年草案與 2020 年 W3C Note〔instants 關係擴充〕）。內容：區間關係詞彙（equals、before、meets、overlaps、starts、during、finishes 及其反向），源自 Allen 區間代數；before＝前者終點早於後者起點；標準區間演算假設區間起迄不同。**終版（Recommendation）狀態在本場未獲官方頁確認＝UNKNOWN**；一個非 W3C 的目錄頁稱有 2022 年草案，屬二手，不採用。
- **S6｜Anthropic〈Reduce hallucinations〉**，https://platform.claude.com/docs/en/test-and-evaluate/strengthen-guardrails/reduce-hallucinations （搜尋 1 次，只讀摘要，無發布日期＝UNKNOWN）。內容：明確允許模型承認不確定；要求引文以便稽核，並可事後為每個主張找支持引文；多次執行比對一致性；限制只用提供的文件；文末聲明這些技巧只降低、不能消除錯誤。社群貼文與科技媒體轉述不採用。
- **S2｜W3C《PROV-O》**（2013-04-30，https://www.w3.org/TR/2013/REC-prov-o-20130430/ ）：R3d12zh 已整頁讀取，內容見 `docs/research/P2-RS-Q6a.md` §2；本場沿用，未重讀。
- **參考價值：** S4＝**僅提供方向**（詞彙層，且為草案）；S6＝**條件式參考**（承認不確定、引文稽核可借，但它是提示技巧，不是守門機制）。

## 3. 可靠性、與 P2 比對、參考價值
- S4：W3C 技術文件，原始來源；日期明確；詞彙規範非宣傳；限制＝草案、只談詞彙。
- S6：供應商官方文件，原始來源；無日期；功能與建議的宣稱，無獨立驗證；自述不能消除錯誤。
- 與 P2 比對：問題相近（有證據的關係、可排序的時間、可棄權的分類）；條件不同（S6 面向提示，P2 要確定性守門）；因此兩者都只當設計依據，不照搬。

## 4. NOT_EXECUTED 查詢清單
1. 實體解析（entity resolution）端點正規化、別名表與模糊比對的官方或標準說明
2. 分類棄權與信心校準（classification with abstention、calibration）的官方指引
3. 關係抽取 方向與條件 的標註規格
4. 時區與 `datetime` naive／aware 比較行為（docs.python.org）
5. 週期偵測的最小確定性判定（官方或標準來源）
6. bitemporal（有效時間與記錄時間）的官方說明
7. 失敗案例：LLM 關係抽取的幻覺端點

## 5. 方案評分（0～2 × 6 項：約束、失敗覆蓋、可測性、成本、可逆、證據）
- CLASSIFY：A `classify_guard` 2,2,2,1,2,1＝10；B 純模型自分類 1,0,1,2,2,0＝6；C 外部分類器套件 0,1,1,1,1,0＝4。取 A。
- RELATION：A `relation_guard` 2,2,2,1,2,1＝10；B 模型輸出直接入圖 0,0,1,2,2,0＝5；C 外部實體解析套件 0,1,0,0,0,0＝1。取 A。
- TEMPORAL：A 純函式 2,2,2,2,2,1＝11；B 模型排序 1,0,0,2,2,0＝5；C 引入時間函式庫 0,1,1,1,1,0＝4。取 A。

## 6. 結論
三卡都採確定性守門（決定論薄模組），模型只負責語意判斷、且都有「不強分、不入圖、標 UNKNOWN」的出口。證據強度 1。實體解析整題未查，是 RELATION 的最大未知。
