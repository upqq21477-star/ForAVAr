# P2-RS-Q6a｜INGEST、SEARCH、EXTRACT（R3d12zh）

## 1. 確認問題（§14.5）
- 一次性程式掃描（PROGRAM_EXECUTED_PASS；只數字串命中，不證明有呼叫，結論一律 HYPOTHESIS）：
  - INGEST 相關字串：53 檔，最高 `parallel_scheduler.py`（62）、`result_chain.py`（27）；`knowledge_intake.py` 為候選提供者（未讀碼）。
  - SEARCH 相關字串：11 檔，最高 `librarian.py`（7）。
  - EXTRACT 相關字串：85 檔，最高 `construction_factory.py`、`progressive_repository_scanner.py`（各 5）；樣式過寬，雜訊高。
- E-4：解壓根目錄下 `state/capabilities` 不存在（`os.path.exists`＝False）；狀態檔實際位置本場 UNKNOWN，未查。
- E-6／E-8：沿用規劃稿 §11、§12 的敘述，本場未重驗登記表。

## 2. 外部研究（取得日 2026-10-16；只用官方一手來源）
- **S2｜W3C《PROV-O: The PROV Ontology》**，W3C Recommendation，2013-04-30，https://www.w3.org/TR/2013/REC-prov-o-20130430/ （搜尋 1 次＋整頁讀取 1 次）。內容：Entity／Activity／Agent 三類；`wasDerivedFrom`（含子屬性 `wasQuotedFrom`、`hadPrimarySource`）、`used`、`wasGeneratedBy`；`Collection` 與 `hadMember`；`Bundle`＝可被描述來源的具名來源集合；`invalidatedAtTime` 標示實體失效。
- **S3｜Anthropic 結構化輸出文件**，https://platform.claude.com/docs/en/build-with-claude/structured-outputs （搜尋 1 次，只讀到各語言版本的摘要，未整頁讀，「JSON Schema 限制」章節未讀；頁面無發布日期＝UNKNOWN）。摘要內容：以 `output_config.format`（`json_schema`）約束回應符合 schema；列出支援模型；舊 beta 標頭與 `output_format` 在過渡期仍可用。另有一份舊版快取頁仍寫「公開 beta」，與新版「正式提供」衝突，採新版。
- **S3b｜Agent SDK 結構化輸出**，https://code.claude.com/docs/en/agent-sdk/structured-outputs （搜尋結果給的是其 markdown 版本；同一次搜尋的結果）：SDK 依 JSON Schema 驗證輸出，不符時重新提示。

## 3. 可靠性、與 P2 比對、參考價值
- S2：W3C 規格本身（原始來源）；日期明確；是詞彙規範，不是宣傳；W3C 流程有多方審查；限制＝只定義詞彙，不含切分、抽取、搜尋方法。
- S3／S3b：供應商官方文件（原始來源）；是功能宣稱，沒有獨立驗證；無日期；限制＝API 功能，P2 受 D-NOAPI 約束，不是基線相依。
- INGEST × S2：問題不同（S2 不談切分），結構部分相似（來源→衍生片段）；參考價值＝**僅提供方向**（欄位命名）。
- EXTRACT × S3／S3b：目標相同（schema 約束的抽取）、條件不同（API、非基線）；參考價值＝**條件式參考**：重提示重試的型態可借，約束靠供應商保證不可依賴。
- SEARCH：本場沒有讀到任何來源，參考價值＝UNKNOWN。

## 4. NOT_EXECUTED 查詢清單
1. 文件切分 穩定 chunk ID 冪等 匯入（官方文件）
2. JSON Schema 驗證規格（json-schema.org）與 S3 的「JSON Schema 限制」章節整頁
3. 摘要抽取 欄位來源定位 citation／grounding 官方說明
4. retrieval 檢索加引用 coverage 的官方評估指引
5. 搜尋結果當不可信輸入 prompt injection 防護（官方安全文件）
6. 失敗案例：結構化抽取 幻覺補值 限制
（已執行：W3C PROV-O 對應 Source→Segment＝S2；LLM 結構化輸出 schema 驗證與重試＝S3、S3b 摘要）

## 5. 方案評分（0～2 × 6 項：約束、失敗覆蓋、可測性、成本、可逆、證據）
- INGEST：A `segment_ingest` 2,2,2,1,2,1＝10；B 全交模型切分 1,0,1,2,2,0＝6；C 外部切分套件 0,1,1,1,1,0＝4。取 A。
- SEARCH：A 請求台帳＋降級 2,2,2,2,2,0＝10；B 接搜尋 API 0,1,0,1,1,0＝3；C 純模型自述 1,0,0,2,2,0＝5。取 A（B 違 D-NOAPI）。
- EXTRACT：A `extract_guard` 2,2,2,1,2,1＝10；B jsonschema 1,2,1,1,1,0＝6（可用與否看 fixed_deps，UNKNOWN）；C 模型自檢 1,0,1,2,2,0＝6；D 供應商結構化輸出 0,1,0,1,1,1＝4。取 A。

## 6. 結論
各卡仍採 A（決定論薄模組）。證據：INGEST、EXTRACT 為 1（弱），SEARCH 為 0。供應商的結構化輸出只能當「可選的加強」，不能取代本地檢查。外部方案不照搬、不引入相依。
