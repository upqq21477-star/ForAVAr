# P2-RS-Q3 研究紀錄：出錯處理與重試

題組：Q3（`Run.step` 出錯處理 G1、`Run.ladder`、FP3 出錯路徑、INCOMPLETE／FAILED）。狀態：DONE（R3d12zf；外部查詢部分執行，見 §4）。

## 1. 本場做了什麼

- 確認問題（§14.5）：完成，結果見 §2；G1 以腳本實測（PROGRAM_EXECUTED_PASS），其餘為讀碼或 grep。
- 外部研究：執行 5 條查詢（第一輪 2、第二輪 2、第三輪 1），取得 8 個來源（S1～S8）；其餘 7 條 NOT_EXECUTED，清單在 §4。使用者在預算停點後要求繼續，故超出原訂呼叫預算。
- 四張 §16 卡依 §14.5 評分；證據強度最高 1（以官方文件為主，無實測、無獨立重現）。

## 2. 確認問題結果

| 項目 | 結果 | 等級 |
|---|---|---|
| G1 `step` 例外穿出 | 讀非 UTF-8 檔、`subprocess.run` 拋 `TimeoutExpired`、拋 `FileNotFoundError` 三案皆穿出 `step`；trace 0、attempts 0、預算未扣 | PROGRAM_EXECUTED_PASS |
| `attempts_to_runs` | outcome 不是 "success" 就一律轉成 failure；若新增 incomplete 而不改此函式，ladder 會把逾時當失敗計次 | 讀碼 |
| `fp_test_outcome(attempts, exit_code, run_id)` | 只收 exit code，無法表達逾時或啟動失敗 | 讀碼 |
| `Run.ladder`／`retry_decision` 呼叫者 | 範圍 P1-Central-Control 內 grep `.ladder(`／`retry_decision(`，只命中 p2_run 模擬 harness 與 tests；生產呼叫者無（動態呼叫 UNKNOWN） | grep |
| `retry_decision` 空 attempts | 回 PROCEED／NO_FAILURE；attempts 只在記憶體（G2），中斷重建後 `RETRY_MAX=1` 的上限歸零 | 讀碼推得，HYPOTHESIS |
| 命名層次 | closure 狀態為 COMPLETE／INCOMPLETE／STALE（`closure_chain`）；失敗測試與未完成執行現在都只得 INCOMPLETE（C08） | 讀碼 |

補做（外部研究階段）：`COMMANDS` 是 list、無 shell（讀碼）；`step(` 的非測試呼叫者只有 `scenario_distill.py` 第 49 行的回放 lambda（grep，是否屬生產路徑 UNKNOWN）；`close(` 的呼叫者只有 p2_run 模擬 harness（grep）。仍未做：讀 §16 的 G2、G3 卡確認對齊（UNKNOWN）；重跑 61/61。

## 3. G1 重現腳本（一次性；施工場可轉成紅測試）

```python
# 在 P1-Central-Control/scripts 下執行；mock.patch 後 step 應回傳而非拋出
import sys, subprocess, tempfile, pathlib
sys.path.insert(0, '.')
import p2_run as r
from unittest import mock
def mk():
    d = pathlib.Path(tempfile.mkdtemp())
    (d/'a.py').write_bytes(b'\xff\xfe\x00bad'); (d/'ok.py').write_text('x=1\n')
    x = r.Run(d, write_scope=['ok.py'], goal_confirmed=True, use_fast=False); x.mode = 'CONSTRUCTION'
    return x
cases = [('read non-utf8', None, lambda x: x.step('read', {'path': 'a.py'})),
         ('timeout', subprocess.TimeoutExpired('u', 30), lambda x: x.step('run_tests', {})),
         ('launch', FileNotFoundError('py'), lambda x: x.step('run_tests', {}))]
for name, exc, fn in cases:
    x = mk()
    try:
        if exc: mock.patch('subprocess.run', side_effect=exc).start()
        print(name, 'returned', fn(x).get('code'))
    except BaseException as e:
        print(name, 'ESCAPED', type(e).__name__, len(x.trace), len(x.attempts), x.budget)
    mock.patch.stopall()
```

實測輸出（現況）：三案皆 ESCAPED，trace 0、attempts 0、budget 12。

## 4. 查詢紀錄（共 12 條計畫；查詢字串為實際送出者或待跑者）

| # | 輪 | 查詢 | 狀態 |
|---|---|---|---|
| 1 | 1 | python subprocess.run timeout TimeoutExpired kills child process documentation | 已執行 → S1 |
| 2 | 1 | exponential backoff and jitter AWS Architecture Blog | 已執行 → S2 |
| 3 | 1 | retryable vs non-retryable error classification agent tool call | NOT_EXECUTED |
| 4 | 1 | fail closed vs fail open partial failure design | NOT_EXECUTED |
| 5 | 2 | Temporal retry policy non-retryable error types timeout activity | 已執行 → S3 |
| 6 | 2 | LangGraph retry policy node error handling | NOT_EXECUTED |
| 7 | 2 | CI infrastructure failure vs test failure distinction runner start failure | NOT_EXECUTED |
| 8 | 2 | python subprocess timeout shell=True grandchild process not killed process group | 已執行 → S4 |
| 9 | 2 | circuit breaker pattern single process local not useful | NOT_EXECUTED（S5 已涵蓋斷路器的測試難度） |
| 10 | 3 | retries can make outages worse retry amplification criticism（由原 10 改寫） | 已執行 → S5～S8 |
| 11 | 3 | broad except Exception antipattern swallowed errors | NOT_EXECUTED |
| 12 | 3 | automatic test retry masks real failures flaky | NOT_EXECUTED |

三輪都有新術語（process group、token bucket、retry budget、non-retryable error types），但搜尋預算已超，依 §14.4 停止；未執行者不影響卡片欄位完整性，只影響證據強度。

## 5. 來源與可靠性分析（網址為本場搜尋實際取得；沒有直接引用原文）

| 編號 | 來源與網址 | 身份／原始？ | 發布時間 | 證據、宣傳、獨立支持、條件、限制 | 判定 |
|---|---|---|---|---|---|
| S1 | Python 官方文件 subprocess，https://docs.python.org/3/library/subprocess.html | 官方、原始 | 頁面無日期，未取得 | 行為規格：逾時時子行程被殺並等待，之後重拋 TimeoutExpired；非宣傳；CPython 原始碼文件鏡像內容一致；只涵蓋直接子行程，未談孫行程 | 可直接參考 |
| S2 | AWS Architecture Blog「Exponential Backoff And Jitter」，https://aws.amazon.com/blogs/architecture/exponential-backoff-and-jitter/ | 原始，作者 Marc Brooker | 原文發布日未直接取得（頁面稱 8 年後於 2023-05 更新） | 以模擬比較各種 jitter；廠商部落格但屬技術文章；S5、S6 呼應；條件是多客戶端競爭同一遠端服務；不適用單行程本機重試 | 僅提供方向 |
| S3 | Temporal 官方文件 error handling，https://docs.temporal.io/best-practices/error-handling 與 https://docs.temporal.io/develop/python/best-practices/error-handling | 廠商官方文件、原始 | 未取得 | 規格性內容：錯誤分可重試與不可重試；重試次數預設無上限；Worker 做完但未回報就崩潰會被重送；產品文件但宣傳成分低；S6 同樣要求重試前確認冪等；分散式工作流引擎，規模與 P2 差很大 | 條件式參考 |
| S4 | graphene 專案提交說明，https://git-crysp.uwaterloo.ca/miti/graphene/commit/c48228893677f58c817c818d2893267d9209fd62 | 專案提交紀錄、單一案例 | 頁面標約 6 年前，確切日期未取得 | 說明逾時要殺子行程的子行程需用 process group，並註明程序正常結束卻留下孫行程的情況沒涵蓋；非宣傳；另有 gist 作法類似但可靠性低；單一 commit、未驗證 | 僅提供方向 |
| S5 | Amazon Builders' Library「Timeouts, retries, and backoff with jitter」，https://aws.amazon.com/builders-library/timeouts-retries-and-backoff-with-jitter | 原始，Amazon 工程師經驗 | 未取得 | 說明過量重試在過載時會讓情況更糟；斷路器帶來難測的模態行為，改以本地 token bucket 限制重試；S6、S7、S8 皆引用；條件是服務間呼叫；無公開量測資料 | 條件式參考 |
| S6 | AWS Well-Architected 可靠性支柱，https://docs.aws.amazon.com/wellarchitected/latest/reliability-pillar/rel_mitigate_interaction_failure_limit_retries.md | 官方規範 | 未取得 | 規範性建議：限制重試次數、加 jitter、重試前確認服務冪等；與 S5 互證；規範而非實測 | 條件式參考 |
| S7 | OneUptime 部落格，https://oneuptime.com/blog/post/2026-07-29-timeout-outage-cross-layer-retry-budget/view | 廠商部落格、二手 | 2026-07-29（取自網址） | 多層重試會相乘放大，需整體重試預算；引用 S5；有品牌性質、無原始資料 | 僅提供方向 |
| S8 | tianpan.co 部落格，https://tianpan.co/blog/2026-04-23-retry-amplification-agent-tool-error-rate-cascade | 個人部落格、二手 | 2026-04-23（取自網址） | agent 迴圈重試放大的算術與案例；數據來源未能查核；引用 S5 | 僅提供方向（可靠性低） |

## 6. 與 P2 的比對

| 比對面向 | S1／S4（逾時） | S2／S5／S6／S7／S8（重試） | S3（分類與重送） |
|---|---|---|---|
| 問題是否相同 | 相同：子行程逾時 | 部分：重試為何要節制 | 相同：哪些錯誤該重試 |
| 結構是否相似 | 相似 | 不同：來源談多客戶端與多層服務 | 相似：錯誤類型決定動作 |
| 條件、規模、環境 | 相近（Python subprocess） | 差很大：P2 單行程、本機、一次重試 | 差很大：分散式、預設無限重試 |
| 目標是否相同 | 相同：不讓逾時拖垮執行 | 部分：P2 要的是有上限的收斂 | 相同 |
| 差異 | `COMMANDS` 無 shell，孫行程殘留取決於測試內容 | P2 沒有共用下游，不會有退避要解的競爭 | P2 要的是固定上限，不是可設定的政策引擎 |

## 7. 研究結論與對卡片的影響

1. 逾時語意（S1）：`subprocess.run` 逾時只殺直接子行程並重拋 TimeoutExpired，所以 `_run_tests` 與 `step` 必須攔下，與 G1 實測一致；孫行程殘留取決於測試是否再起子行程（S4 建議 process group），列為選配、預設不加（HYPOTHESIS）。
2. 錯誤分類（S3、S5）：重試與否由錯誤類型決定，與卡 1、卡 3 的 error_code 查表一致；`edit` 類錯誤可能已部分寫入，retryable 一律 False，重試前須先對帳（S3、S6 的冪等要求）。
3. 重試層數與上限（S5、S6、S7）：只在 ladder 一層重試、有明確上限；`step`、`_run_tests` 不內建重試。P2 沿用 OD3 的重試一次即可。
4. 不採 backoff、jitter、斷路器：S2、S5 這些機制是為多客戶端競爭遠端服務而設，P2 無此條件；S5 另指出斷路器難測。這是有來源支持的推論，不是任何來源的直接結論。
5. 跨中斷（S3）：做完卻沒回報就崩潰會被重送（至少一次語意），與 P2 attempts 只在記憶體、重建後上限歸零的風險同型；對策是 attempts 由 journal 重建（卡 3）。
6. 卡 4（三層命名）沒有對應來源，證據強度 0，來源 UNKNOWN。

## 8. 未執行與後續

- 7 條查詢 NOT_EXECUTED（見 §4）；施工前可補查 #3、#7、#12，特別是 CI 區分基礎設施失敗與測試失敗的慣例。
- 仍未做：與 §16 的 G2、G3 卡逐項對齊（卡 1、2 的中斷欄位標 UNKNOWN）；孫行程殘留實測。
- 施工場以 §16 四卡的「必備測試」先紅後綠；G1 的紅測試可由 §3 腳本轉成。
