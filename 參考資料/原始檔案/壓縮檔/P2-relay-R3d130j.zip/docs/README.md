# P2 文件索引與資料生命週期

本索引只回答：目前應讀哪份文件、它的責任是什麼、現況資料在哪裡。它不是歷史目錄，也不建立第二份 Current。

## 唯一現況入口

- README.md：專案用途、最低操作方式與目前有效文件位置。
- P1-CURRENT.json：P1 相容基線尚未安全遷移前的唯一執行狀態權威。不得另建第二份 Current。
- docs/architecture/P2-System-Blueprint-v1.0.md：P2 唯一總體藍圖；目前內容為 v1.1 Current-first 設計。
- docs/plans/P2-Feature-Triage.md：每項核心功能的現況、有效位置、主要缺口與下一診斷點。
- docs/architecture/P2-Axis-v0.1.md：P2 主軸索引（樹狀結構、怎麼連、去哪讀）；索引而非規範，隨藍圖同步，每場由 `tools/pack_handoff.py` 帶入交接檔，由 `tools/axis_lint.py` 檢查。
- docs/plans/P2-Relay-Update-Plan.md：舊工作順序；已被接力企劃取代，Current 同步後刪除（R3）。
- docs/plans/P2-Relay-Update-Plan.md：**唯一企劃**（接力批次、願景清冊、協議、文件處置附錄）。
- docs/handoffs/HANDOFF.md：**唯一交接**（由 handoff.data.json 生成；每場覆寫）。
- docs/audit/OPEN-ISSUES.md：**唯一未結問題清單**；驗證關閉即刪行。

## 資料夾責任

### docs/architecture
只放現行藍圖、必要核心契約與最新功能現況矩陣。藍圖描述目標設計；矩陣描述目前實作與證據狀態，兩者不可互相代替。

### docs/plans
只保留目前有效的下一步工作。完成、取消或被新規劃取代的工作要先蒸餾仍有用的結論，再清理不再需要的計畫細節；不維護永久的計畫時間線。

### docs/capabilities
保留目前有效且可重用的能力定位。Capability 只記用途、適用條件、必要輸入／輸出、限制、失敗模式、目前位置與驗收方式；淘汰能力不在活動目錄累積歷史條目。

### docs/acceptance
保留目前的最低驗收契約及仍有判定價值的最新驗收結論。每次操作不需新增永久 Run 歷史；詳細過程完成蒸餾後退出活動資料。

### docs/audit
只有 OPEN-ISSUES.md 一份：仍開啟且影響目前工作的缺陷與待核實項。逐批掃描輸出、執行日誌、檢查點一律不入庫。

### docs/research
外部研究只用於回答明確問題。採用的結論融入目前藍圖或契約；未採用、重複或不再有用的研究內容不作常駐資料。

- `docs/research/P2-OPT-REF/`：P2 優化參考資料（OB0；入口 00-INDEX.md；批次計畫 05-批次計畫.md）。暫存研究輸入；OB2 裁決採用後蒸餾進藍圖與企劃，其餘退場。

### docs/decisions
只有仍然影響目前架構、且不能直接寫入現行藍圖或契約的有效決定才有獨立保存必要。不要把每次討論或被拒絕的候選方案全部堆成永久決策歷史。

### docs/handoffs
只有 handoff.data.json（來源）與 HANDOFF.md（生成檢視）。只保留最新交接。交接需能恢復目前工作，但不得複製完整對話、掃描歷程或整份 Current。

## 資料保留規則

1. 只有目前狀態、有效設計、必要能力、目前資料位置、未解缺口及必要證據可長期保留。
2. Raw、暫存、完整 Trace、逐次掃描輸出與已結案個案只在處理問題期間使用；先蒸餾有用內容，再清理。
3. 不追蹤歷次路徑移動；目前有效位置失效或當前任務需要時才檢查相關範圍。
4. 未掃描／不可取得＝UNKNOWN／UNAVAILABLE；不得以沒找到推論不存在。
5. GitHub commit history 可在必要時按需恢復，不得複製成一套常駐歷史資料庫。
6. 刪除前先確認未解問題與必要現況已被保留；「目前索引未引用」本身不構成刪除證據。


7. 機械強制：`python3 tools/precheck.py` 的 hygiene 檢查禁止圖檔／壓縮檔、多份交接、多份企劃與歷史日誌；refs 檢查列出懸空引用與孤兒文件。
