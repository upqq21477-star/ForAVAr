# P1 治理規則（內容版本 v1.1，對照表版）

狀態：ACTIVE GOVERNANCE BASELINE

只存規則；實作位置以 `P1-CURRENT.json` 與 registry 為準，本檔不得覆寫 Current。

v1.0 全文（四章：長程運行、資料生命週期、變更範圍隔離、模型能力演化）已逐字封存在 `docs/archive/P1-Governance-Rules-v1.0-FULL-ARCHIVED.md`。逐條規則與強制狀態在 `P1-Central-Control/policy/governance_rule_map.v1.0.json`：共 43 條，ENFORCED 4、PARTIAL 21、POLICY_ONLY 7、NOT_IMPLEMENTED 11；每條的程式證據（檔案＋字串）由 `P1-Central-Control/tests/test_governance_rule_map.py` 逐項核對，缺口寫在 `gap`。

## 只能靠判斷的規則（POLICY_ONLY）

程式無法檢驗，必須遵守：

- G1-01：目標是取得最小充分狀態，不是記住更多
- G1-04：Segment 大小由責任邊界、Context 密度、依賴距離、驗收複雜度、復原成本、預期輸出共同決定
- G1-13：禁止的錯誤優化：全 history 檢索、每次 tool call 建 checkpoint、summary 取代 canonical、為省 token 刪 unknown／conflict、cleanup＝全刪
- G2-01：保留是為了完成工作，不是永久堆積；流程 CREATE→CLASSIFY→USE→INTEGRATE→RETAIN／ARCHIVE／RETIRE→DISPOSE
- G2-08：Git 工作樹與歷史分治：一般清理不重寫歷史，僅在體積、敏感資料、重大污染達門檻時另評估
- G3-10：閉環 CHANGE→IMPACT→RADIUS→ONE SYSTEM→CONTEXT BUDGET→EXECUTE→REGRESSION→CLOSURE→LIFECYCLE→RECONCILIATION→CLEAN_READY；任一環無證據不得完成
- G4-11：總則：模型越強，不是 P1 越大；舊支架越少、必要支架越精準、Context 越小、System 越獨立、退場越可靠

## 仍是散文、尚無強制的規則（NOT_IMPLEMENTED）

- G1-09：Capability 先載 id＋摘要＋呼叫契約，定義按需載入（計畫 R4L／FR-09（槽位卡片）承接，尚未實作）
- G1-11：長期觀測四組：Context、Token、Storage、Quality 指標（無對應實作）
- G1-12：100k Segment 驗收（source-tree runtime 檔 0、Hot Context 有界、可 resume）（計畫 R4R／FR-08 承接，現有模擬只到 1,000）
- G2-04：Checkpoint 退場須同時滿足：已整合、下一段不依賴、canonical 已成形、evidence refs 存在、無未決依賴、無…（以 grep 為限未找到實作證據）
- G2-09：每 100／1k／10k／100k segment 量測檔數、active 文件／程式數、working 紀錄、stale 資產、dea…（無對應度量）
- G3-09：維護健康：Change Radius 均值／P95、Context 均值／P95、cycle 與依賴數、選中測試／總測試（無對應度量）
- G4-03：差分評估 A 舊模型＋支架、B 新模型＋支架、C 新模型＋移除候選、D 舊模型＋移除候選（evolution_cycle 只有 eval 欄位，無 A／B／C／D 結構）
- G4-04：支援矩陣＝model_family × capability × workload_class；全部受支援模型皆不需要才進 GLOBAL…（repo 內無 model_support_matrix）
- G4-05：Load-bearing 以 Role 為單位（PRIMARY_EXECUTION／ROUTING／VALIDATION／SAFETY_…（repo 內無 load_bearing 結構）
- G4-07：防抖（建議值）：≥1 baseline 比較、≥2 獨立評估窗、≥1 組負向／recovery 案例、無 critical regres…（evolution_policy 無對應門檻）
- G4-08：Hot Registry 只留 active capability、狀態、契約、最小路由 metadata、評估新鮮度、fallback…（無對應檢查）

## 修改規則的方式

新增或修改治理規則，先改對照表（寫明 status 與 refs 或 gap），再決定要不要寫程式；不要把長文加回本檔。把 NOT_IMPLEMENTED 或 PARTIAL 變成 ENFORCED，要同時補程式與 refs。
