# P2 展開設計・未完項與接手指引 v0.1

狀態：R1-S3h 續（2026-10-13）。這是**設計未完成部分的唯一清單**；三份設計文件、交接檔、企劃卡都指向這裡。

## 0. 接手者怎麼讀（約 20 KB）

1. 本文件 §1、§2。
2. `P2-Expansion-Design-v0.1.md`：§0b、§1、§3。
3. `P2-Expansion-Checks-v0.1.md`：§1、§2、§5。
4. `P2-Expansion-External-Review-v0.1.md`：§5（缺口 G1–G7）。

企劃卡與程式用 `slice.py` 讀，不要全讀。

## 1. 已定，直接照做

- 種子＝法則＋情境；展開＝derive(法則, 情境)；還原只是校準。
- 骨架凍結：不刪上層節點、不改上層簽章；下層只可新增對上層不可見的節點並登記對應；每級先過上一級檢查。
- 驗收三道：擬合（L1–L3）、推廣（留出情境）、容許（法則謂詞）。歸因 D→E→S；同節點同類 2 次未解＝BLOCKER。
- R1-S4 重封不受影響，R1-S3i 照做（只重封、不改藍圖內容）。
- 工具：`python3 tools/expansion_probe.py`（容許）、`--holdout`（推廣機制）、`--selftest`。

## 2. 未完項

| OI | 缺什麼 | 補法 | 驗收 | 場次／決策權 |
|---|---|---|---|---|
| 1 | 四個結構放哪、長什麼樣 | 已查證：`canonical/blueprint.json`（12 KB）的 `blueprint.schema.json` 未設 additionalProperties，可加可選欄位。做法：把四個結構作為**可選欄位**加進 `canonical/blueprint.json`，並在 schema 的 properties 補宣告。24 KB 上限指敘述性的「唯一藍圖」文件，不是這個 JSON。備案（成本高）：獨立 canonical 物件，需改 `canonical_identity.schema.json` 的 kind 列舉、registry 加一筆、新增 schema | 藍圖 JSON 通過 schema、reconstruction 閘門 PASS、雜湊經 F28 重算 | R3-S4；M 自決 |
| 2 | 展開規則的記錄格式與通用展開函式 | ① 把 `current_projection_sync.render` 與 `reconstruction` 的歸屬各寫成一筆規則 ② 寫 `expand(rule, seed)` 重現其輸出 | 同種子輸出與現行位元組相同（D 類殘差＝0） | R4L；M 自決 |
| 3 | 依賴圖初版 | 由 blueprint 的 `architecture`、`components` 導出節點與邊 | 無環、每層 ≤ 9 節點 | R3-S4；M 自決 |
| 4 | 每元件的目標還原級別與容限 | 預設 L1＝0、L2＝0、L3＝該元件測試全過；基線失敗的元件才寫例外與理由 | 每元件一行 | R3-S4；M 自決 |
| 5 | `precheck [expansion]` 輸出格式 | 一行 `[expansion] drift=a/b admissibility=c/d holdout=reported`，只 WARN；數字取自 `expansion_probe.py --json` | 自測通過、precheck 仍 PASS | R4L；C 自決 |
| 6 | 推廣道實質試點的資料與程序 | ① 列候選（planner_library 問題類→能力、capability_registry 其他欄位、歷史 Work Unit；單位數未核）② 選單位 ≥ 10 且答案可機器判定者 ③ k＝0 切分，凍結種子後評分；被用來修種子的切片燒掉 | 報告 OK／ABSTAIN／WRONG 與 D／E／S 歸因 | R4L 前或 R3 後；M 自決 |
| 7 | STUB／WIRED 與逾期門檻 | **已取代（D-R3a-ACT、D18）：** 不新增 `activation` 欄位，成熟度由 wiring_audit 推導（R2d 已實作）；Planner 只規劃 WIRED 能力；「逾 3 場 WARN」的 3 無依據，不採用 | wiring_audit 推導成熟度可重現 | 已結案（R3c2）；理由見 Feature-Triage §10 |
| 8 | 法則的硬／軟與適用條件 | 寫入 `canonical/blueprint.json` 的 `law_meta[]`（以 `invariant_id` 對應，不動現有藍圖欄位）：`strength`（HARD｜SOFT，現有 12 條預設 HARD）、`valid_when`（預設「全域」）；情境超出＝標 OOD，結果只能 UNKNOWN 或人判 | 12 條各有一筆 | R3-S4；M 自決 |
| 9 | 證據等級與現有證據標記的關係 | 兩條軸：現有標記說「結論怎麼得來」，新等級（未驗／已擬合／已推廣／已容許）說「推導物驗到哪一級」；新等級寫在殘差記錄，不改現有標記詞 | 殘差記錄含等級欄 | R4L；M 自決 |
| 10 | 法則全是 T2 型 | 試把 INV-CENTRAL-ENVELOPE-IMPORTS、INV-ROUTING-TABLE-ONLY 各寫一個 T1 靜態謂詞 | 兩個 T1 謂詞可離線跑，結論與現有測試一致 | R4L；M 自決 |
| 11 | 容許道現有 1/12 違反（INV-SIMULATION-FIRST／test_local_acceptance） | R1-S3i 重封後重跑 `expansion_probe.py`；仍違反才依 D→E→S 歸因 | 違反消失或有歸因記錄 | R1-S3i |
| 12 | 無 shell 時的降級 | 規則：沒有 shell 就只做文件與填表，所有數字標 NOT_EXECUTED，並列「待有 shell 者執行的指令」 | 交接檔有該段 | R1-S3i；M 自決 |
| 13 | README 投影漂移（D 類） | 已含於 R3-S3「Current 同步」：先經更新交易更新 `P1-CURRENT.json`，再以 `current_projection_sync` 重生 | `inspect` 回 OK | R3-S3 |
| 14 | 種子大小（壓縮比）怎麼調 | 依 RTL-BenchLS 的發現（長抽象勝短抽象且差距隨規模擴大；可執行程式碼抽象勝自然語言）：每元件記錄 r＝種子位元組／元件位元組；L3 殘差超標且歸 S 類時，先加大種子（補不變式、介面細節），再考慮改規則；種子優先用可執行／可檢查的形式（謂詞、schema、測試）。HYPOTHESIS：來自硬體設計基準，軟體元件未驗 | 每元件有 r 與一筆調整紀錄 | R3-S4；M 自決 |

## 3. 形狀草稿（DRAFT；HYPOTHESIS：未經 schema 驗證）

```json
{"dependency_graph":{"nodes":[{"id":"N1","level":1}],"edges":[["N1","N2"]]},
 "expansion_rules":[{"rule_id":"R-PROJ","applies_to":"projection",
   "template":"scripts/current_projection_sync.py:render",
   "target":"README.md#CURRENT_BLOCK","holes":[]}],
 "residual_policy":[{"component":"C-X","level":"L3",
   "tolerance":{"L1":0,"L2":0,"L3":0}}],
 "law_meta":[{"invariant_id":"INV-ROUTING-TABLE-ONLY",
   "strength":"HARD","valid_when":"全域","predicate_type":"T2"}],
 "context_schema":{"goal":"string","constraints":["string"],"params":{}}}
```

以上為 `canonical/blueprint.json` 的可選頂層欄位。`holes[]` 非空＝留給 LLM 的位置；空＝純決定性。

## 4. 卡住時

- 同一問題試 2 次未解＝BLOCKER（沿用）。
- 設計與現況的工具輸出衝突：以工具輸出為準，寫 UNKNOWN，不補假數據。
- 殘差歸因不確定：標 UNKNOWN，交 Brain 裁。
- 需使用者裁決的項（OI-7）：先給兩個選項與建議，再繼續做不依賴它的項目。
