# P2 運行模式與證據升級契約 v1.8

**狀態：** DESIGN_CONTRACT。它定義不同運行層的責任，不宣稱所有程式已符合。
**設計權威：** `P1-CURRENT.json` 的 `p2_target_blueprint_ref` 唯一指向 `docs/architecture/P2-System-Blueprint-v1.0.md`（現行內容 v2.6），定義 P2 的目標責任、職權與運行方式；本契約只細化 BASELINE／UPGRADE 的模式邊界與證據語義，不得另立架構原則。新規劃／討論若產生可重用設計規則，先更新唯一藍圖，再同步本契約。`P1-Brain-v2-Master-Plan.md` 等 P1 資料只作需求與候選能力來源，不反向決定 P2 架構。另參照 `docs/plans/P2-Feature-Triage.md` 的現況標記。
**唯一原則：** 升級模式增加可取得的證據，不得成為最低工作流的前置條件。

## 1. BASELINE：AI 對話＋GitHub（MUST）

最低操作模式只需要 AI 對話和 GitHub 儲存庫。GitHub 是唯一持久化、版本和可讀回來源；聊天內容本身不是已保存的工程狀態。

必須可在此模式完成：
1. 讀取唯一 Current、目前 Work Unit、P2 藍圖／參考資料與受影響檔案。
2. 在 AI 對話內界定範圍、輸入／輸出、接受條件、風險、停止條件和回復方式。
3. 比較原企劃與目前實作；產出完整檔案或明確差異並保存到 GitHub。
4. 從 GitHub 讀回保存版本，核對 commit/blob SHA、實際內容、schema/引用/狀態欄位，以及受影響的相鄰文件。
5. 進行靜態路徑追蹤、契約核對、反例／極端案例審查，記錄仍未知的地方。
6. 更新必要的目前狀態和短交接，使新的 AI 對話只讀 Current、藍圖、相關契約及資料位置即可恢復工作。
7. 即使外部服務、API、套件、CLI、Python、IDE、本地環境、GitHub Actions 或 Hosted Runner 無法使用，仍能繼續上述文件工程工作；若當下沒有直接寫入能力，必須交付可貼入 GitHub 的完整內容並標記未保存。

BASELINE 可支持的證據：
- `GITHUB_PERSISTENCE_CONFIRMED`：GitHub 回讀內容與已保存版本一致。
- `AI_DIALOGUE_REVIEWED`：本次設計／實作內容經 AI 對照。
- `STATIC_REVIEW_PASS`：明確指定範圍的靜態規則和引用檢查通過。

BASELINE **不能**將函式存在、靜態推理、測試檔存在或聊天中的「已完成」轉成 `PROGRAM_EXECUTED_PASS` 或 `OBSERVED_RUNTIME`。沒有實際執行輸出時用 `NOT_EXECUTED_BASELINE_LIMIT` 或 `IMPLEMENTED_UNVERIFIED`。

## 2. 認知模式控制：THINKING 常態監督

認知模式描述如何判斷工作；BASELINE／UPGRADE 描述可用執行環境，兩者不可混為一談。

| 狀態 | 職責與轉移 |
|---|---|
| THINKING | 每項工作預設進入；核對 Current、目標、證據、未知、成本／權限及接受條件。 |
| RESEARCH | 只在新情境、根因未知、修補失敗／重複、需核實當前外部事實或方案取捨重要時觸發。比較有限假說、來源、支持／反證與最小區分測試；不直接修改程式。 |
| PLAN_READY | Scope、整批變更、接受條件、風險／回復、成本與停止條件完整後才可進施工。 |
| CONSTRUCTION | 依核准方案整批施工；新錯誤、偏差、範圍／環境變更時暫停受影響步驟並返回 THINKING。 |
| SIMULATION | 每個施工切片的局部案例／契約模擬；通過後可繼續施工，但不代表整批程式 PASS。失敗返回 THINKING 並使舊計畫失效。 |
| FINAL_ACCEPTANCE | 僅在全部功能輸出齊備、官方 Simulation／Integration 證據綁定同一 HEAD 且 102／102、退出碼為 0、cycle_gate_evidence 有效、canonical Pack 驗證與冪等證據齊全後開啟；獨立 Verifier PASS 才能結束。 |
| CLOSE | 更新唯一 Current、保存最小證據並清理噪音；下一工作重新進 THINKING。 |

常態開啟的是輕量認知監督，不是無限搜尋。若已有已驗收且精確適用的備援規則，Brain 可確認後沿用，避免不必要的重研究；否則新問題須先研究／規劃，不得直接疊加補丁。程式現況已新增 brain_mode_controller.py，並由 central_role_interface.py 的 COGNITIVE_TRANSITION 接線；這是程式碼接線證據，因最新程式尚未執行，仍為 PROGRAM_TESTS_NOT_EXECUTED，不得宣稱已運作通過。


### 2.1 功能先行與正式驗收後置（MUST）

功能批次期間優先建立真實可呼叫程式，使用局部案例模擬、契約核對及負例推演快速發現設計缺口；不要每改一小段就重跑全套官方回歸。整批功能完成後，才在既有可用且成本已核實的 Python 3.11 環境，執行一次官方最終批次流程。現有 B2.2 Runner 的最終批次為七個測試套件、102 個預期測試方法；只有實際 SIMULATION_PASS／exit 0 才能進入受閘控 Integration；外層循環器必須把兩階段的實際退出碼、102／102 計數、同一 HEAD 與乾淨工作目錄結果封存到 cycle_gate_evidence。Central 缺少該證據時必須 BLOCK；最終驗收另需 canonical Pack 驗證、冪等結果、報告所載 canonical Pack SHA-256 與當前檔案一致，以及獨立 Verifier。 還必須核對報告中的 Current 接受條件／測試清單與當前 Current 一致，並重新計算 Active Work／Construction 的穩定契約指紋；生命週期狀態以外的契約內容若有漂移，一律 BLOCK。失敗時彙整報告、依根因分組後批次修補；禁止把案例推演／靜態檢查當成程式 PASS，也不允許將成本、權限或安全 Gate 延後。

### 2.2 Current 工作單位身份解析（MUST）

B2.2 的 Operational Work Unit pipeline 必須在 Pack Builder、Runner preflight、Central cognitive transition 與 final-report verifier 之間維持唯一的 Current 工作單位解析規則：依序檢查 `current_stage.work_unit_id`、`current_stage.slice_id`、`current_stage.id`。只在較高優先值缺少或為 falsey 時使用下一欄位；選中的候選值必須是非空字串，truthy 非字串或空白字串代表 Current identity invalid，必須 BLOCK，不得偷偷用低優先欄位掩蓋。

解析結果必須與 Current-selected Active Work 的 `work_unit`、Active Construction 的 `work_segment_ref`、Operational Acceptance Context 的 `work_unit_ref` 及 preflight／Integration report 的 Work Unit identity 相符。身份不符必須在任何持久化寫入前 BLOCK。此規則屬架構契約，不是本輪一次性修補；各入口保有模組獨立性，但其解析語義不可分叉。局部案例可以測試解析順序與 malformed candidate 的拒絕，不能取代最終 102 方法正式驗收。Legacy Task Packet acceptance 流程保持獨立，不可把 Work Unit identifier 當作 Task Packet ref。

### 2.3 RESEARCH 完成的最小證據契約（MUST）

研究完成事件只能接受以下有界紀錄；任何一項缺失、型別錯誤或超限皆不得放行至 PLAN_READY。另有事件來源模式硬門檻：`RESEARCH_COMPLETE` 僅可由當前 `RESEARCH` 模式完成，`THINKING_COMPLETE` 僅可由當前 `THINKING` 模式完成；模式不符時一律 BLOCK、清除施工核准／批次旗標、回到 THINKING 並暫停施工。`SIMULATION_FAILED` 僅可由 `SIMULATION` 模式觸發，錯誤模式必須 BLOCK 並回到 THINKING；`FINAL_ACCEPTANCE_FAILED` 僅可由 `FINAL_ACCEPTANCE` 模式觸發，且功能批次、Simulation、Integration 證據旗標都必須成立，否則 BLOCK 並保留當前模式。兩者必須走專用守門分支，不得被一般回退事件集合先行攔截。另，`SIMULATION_PASSED` 必須確認目前位於 SIMULATION 且方案仍獲核准、七項計畫門檻仍完整；`FINAL_BATCH_READY` 必須同時確認功能批次完成、官方 Simulation／Integration 證據成立、來源模式合法、方案核准且七項門檻完整。任何計畫授權條件失效時都不得進入下一模式，必須回 THINKING 並清除過期批次旗標。研究紀錄的欄位契約如下：

- `observations`：1–12 項非空字串，每項最多 1,000 字元。
- `sources`：1–5 項非空來源標識，每項最多 500 字元；空清單不代表「不需要來源」。
- `hypotheses`：1–3 項。每項必須有非空 `statement`（最多 1,000 字元）、`supporting_evidence`（1–5 項、每項最多 500 字元）、`contradicting_evidence`（1–5 項、每項最多 500 字元）及非空 `discriminating_test`（最多 1,000 字元）。
- `candidate_comparison`：1–4 項非空字串，每項最多 1,000 字元；`selected_solution` 與 `stop_condition` 必須為非空字串且各最多 1,000 字元。

支持證據與反證都至少一項，不能以空陣列取代。若任一項缺少來源／反證、欄位格式錯誤或文字超限，Controller 應回傳結構化 BLOCK，維持／回到 THINKING，並避免把研究完成旗標當成可施工證據。以上是規格及最新測試原始碼；最新 HEAD 的 Python 測試尚未執行。

## 3. UPGRADE：可選的程式／外部執行模式

在資源與權限可用、且工作確實需要時，才可啟用下列一個或多個升級能力：

| 升級層 | 可選能力 | 可增加的證據 | 不能取代 |
|---|---|---|---|
| U1 程式驗證 | Python／套件、schema validator、unittest、CLI、靜態分析工具 | `PROGRAM_EXECUTED_PASS/FAIL`（須有版本與實際輸出） | 不取代唯一 Current、規格核對或 GitHub 讀回 |
| U2 重建驗證 | clean reconstruction、build/check、受控 smoke test | 特定 commit 的重建結果 | 不自動證明真實使用情境或完整安全性 |
| U3 外部執行 | GitHub Actions、Hosted Runner、其他 runner | 當前 commit 的 step/job 執行證據 | 不得成為 BASELINE 的 gate；runner 未啟動是基礎設施未執行，不是程式 PASS/FAIL |
| U4 外部整合 | API、外部 provider、網路研究、額外軟體 | 指定服務／版本下的整合證據 | 不得成為無關的基本規劃、文件修改、保存、讀回和交接的前置條件 |

升級必須遵守：
- 明確記錄執行載體、repo commit SHA、測試／命令範圍、輸出來源、結果分類與失敗原因。
- 不可取得升級環境時，將該層標成 `NOT_EXECUTED`／`INFRASTRUCTURE_NOT_EXECUTED`，不把它誤報 PASS 或 FAIL；BASELINE 工程工作仍可繼續。
- 若某項程式功能在 BASELINE 下不能由對話＋GitHub「實際執行」，它仍可被規劃、修改、靜態審查與保存，但其 Runtime 必須標為未驗證，不能假裝已執行。
- 升級模式的失敗不得自動把無關的 BASELINE 工作整體鎖死；只有目前工作本身依賴該升級證據時，才將該工作標為 `BLOCKED` 或 `INCOMPLETE`。

## 4. 結果／狀態語義

- `PASS`：該層必要條件全部被直接證據支持；不得以空清單、零樣本、未知輸入或被跳過項目推導 PASS。
- `FAIL`：有直接反證證明受測要求不滿足。
- `BLOCK`：規則／權限／前置條件明確不允許繼續。
- `INCOMPLETE`：必要資料、環境、樣本、覆蓋或執行證據不足。
- `UNKNOWN`：目前證據不能判定；不得視同 PASS。
- `NOT_EXECUTED`：這一層根本沒有執行，不應強制壓成程式 PASS/FAIL。

對任何完整性／覆蓋性 Gate：零輸入、零 system、零 probe、空選擇集、未讀檔、跳過的壞檔或預算提前停止，都必須以 `INCOMPLETE`、`BLOCK` 或有明確說明的 `NOT_APPLICABLE` 回報，不可以 PASS 代表「沒有發現問題」。

## 5. 參考企劃的對照規則

原始 Brain v2 企劃是目標設計來源，並不等於 P2 已實作。每項差異必須分成：
- `MATCHED`：現行程式路徑與證據支持該設計。
- `PARTIAL`：有部分函式／契約，但整合路徑或必要失敗分支尚缺。
- `NOT_WIRED`：元件存在但沒有已證實的非測試呼叫者。
- `MISMATCH`：程式、schema、Current 或文件互相矛盾。
- `NOT_IMPLEMENTED`：找不到實作或有範圍等價的替代品。
- `NOT_EXECUTED`：這輪沒有執行程式或測試。

P2 現行唯一藍圖決定 P2 的目標設計；Current 決定執行現況，功能證據矩陣與 Roadmap 分別呈現實作狀態／證據及目前工作順序。P1 原始企劃只提供需求、設計候選與能力線索，不是 P2 目標架構的權威。兩者衝突時先登錄差異，不能用修改文件掩蓋程式實況，也不能因舊 P1 存在就自動納入全部舊能力。


### 2.4 事件觸發式施工健康回溯（MUST）

這不是常駐監控器。只有使用者明確要求，或工作出現可觀察的變慢／卡住、重複返工、重複修正、失敗或疑似超過資源標準時才執行。每次僅取最近三筆 commit 摘要，每筆最多二十筆檔案統計；不得載入完整 diff、展開完整歷史或寫入稽核歷史。應比較重複觸碰的檔案、修正型 commit、變更量離群、文件／契約擴張與明列來源位元組預算。這些訊號只能指出需要回查的方向，不能直接判定 AI 降智。維護資源比率為同一單位的 maintenance_units / construction_units，上限 0.20。只有兩個實際、可比較的用量值都存在時才可計算；否則必須回報 UNMEASURED。Git 差異量、來源位元組與字數只能作為結構代理值，不能冒充算力／token 量。異常超限後，才針對證據排查重複讀取、過量上下文／歷史、來源清單膨脹、契約重複及未設硬上限的輸入。不得為追求低成本而省略必要安全與驗收 Gate。

呼叫範例：

    python3 P1-Central-Control/scripts/construction_efficiency_review.py --trigger slowdown

若能取得相同單位的實際用量，可追加 --construction-units、--maintenance-units 與 --resource-unit。此工具只輸出本次有界結果，不安排排程、不執行背景工作、不留存歷史報告。