# P2 展開檢查 v0.1（容許與推廣的機器檢查）

狀態：設計草案（R1-S3h 續），補 `P2-Expansion-Design-v0.1.md` §0b 的兩道驗收。新檔、非規範。

## 1. 容許檢查：推導物是否違反法則

**法則要有謂詞。** 每條法則（不變式）對應一個可執行的檢查，分三型：
- **T1 靜態**：ast、路徑、schema、雜湊；離線、決定性。
- **T2 測試**：`test_ref` 單指令跑完。
- **T3 語意**：只能由 Brain 或人判斷；一律標 UNKNOWN，**不得算通過**。

沒有謂詞的法則＝不可驗收，登記為 UNKNOWN。通過＝該法則所有謂詞通過。違反時先標「違反哪一條」，再依設計文件 §3 歸 D／E／S。

**單一跑法。** 所有容許檢查走同一個 runner（與 `tools/precheck.py` 相同：`PYTHONPATH`＝scripts＋tests、cwd＝repo 根）。試點實證：用裸 `unittest` 跑 INV-AMNESIA-RESUME 會得到 `ModuleNotFoundError: jsonschema` 的**假違反**，加上 `PYTHONPATH=P1-Central-Control/scripts` 後 5/5 通過。跑法不一致會製造假殘差。

**跨部分一致。** 「各部分互不矛盾」＝所有部分過同一批謂詞，加上共用識別字（ID、路徑）引用必須解析。`precheck [refs]` 已是這種檢查的一個實例（目前 WARN 8 項懸空引用）。

**工具：** `python3 tools/expansion_probe.py`（`--selftest`、`--json`、`--holdout`）；對 blueprint 每條不變式跑其 `test_ref`，輸出容許殘差（違反數／總數）；只報告、退出碼恆為 0。

## 2. 推廣檢查：留出情境

**單位**：能獨立成情境的東西（能力、Work Unit、元件、問題類）。

**決定性切分**：`sha256(單位 ID) mod 5 == k` 的單位留出（約 20%，第一輪 k＝0）；種子只用其餘單位歸納；種子凍結（記 `content_hash`）後才讀留出集。

**驗證者獨立**：只拿「最終推導物」與「留出的標準答案」，不讀展開端的中間產物（借鏡 ALDER 的獨立准入）。

**切片燒掉規則**：留出集若被拿來修種子，該切片轉為訓練集，下一輪換 k＋1；最多 5 輪。目的是防止種子偷偷擬合留出集。

**資料量**：單位 ≥ 10 才切分；5–9 個改 leave-one-out；< 5 個標 UNKNOWN（不足以驗推廣）。

**度量與容限**：推廣殘差＝留出單位中推導物與標準答案不符的比例。**前 3 場只報告、不擋**，累積資料後由 R3 依元件定容限（HYPOTHESIS：預設值未定）。

**外推（OOD）**：另設一個超出原範圍的情境（規模更大或新領域）；只報告、不作閘門。

## 3. 試點結果（PROGRAM_EXECUTED，3.12.3）

**容許道**

以 blueprint 的 12 條不變式當法則、現行 repo 當推導物：
- 12 條的 `test_ref` 檔皆存在；11 條通過；**1 條違反**：INV-SIMULATION-FIRST（`test_local_acceptance`，1 項 `'FAIL' != 'PASS'`；該檔本就在基線失敗清單，本場未再歸因）。**容許殘差 1/12≈8.3%。**
- 12 條全是 T2 型；T1、T3 型目前沒有。測試是否真的覆蓋法則陳述，屬語意判斷，未驗（UNKNOWN）。
- 方法教訓：第一次以裸 `unittest` 跑得 10/12（INV-AMNESIA-RESUME 為假違反），改用 precheck 同形 runner 後為 11/12。`expansion_probe.py` 已固定為同形 runner，但本場最終輸出以該工具實跑為準。

**意義**：系統自己的現行世界違反自己的一條法則，而且已知（基線清單）——容許檢查把這類「已知但未被當成法則違反」的失敗，變成可量的殘差。

**推廣道（機制試點）**：`python3 tools/expansion_probe.py --holdout`。對 capability_registry 23 項能力，以 `sha256(ID) mod 5 == 0` 留出 4 項（CLASSIFY、SYNTHESIS、COUNTEREXAMPLE、CONVERSATION-RECORD）；只用其餘 19 項歸納 class→kind 的小法則（查表＋恆等律），凍結後才對留出項評分。結果：**OK 2、ABSTAIN 2、WRONG 0**，覆蓋 2/4。棄權計為 UNKNOWN，不算錯：
- CLASSIFY：`GENERIC` 在訓練集對應兩種 kind＝種子含糊（S 類）。
- COUNTEREXAMPLE：`SEARCH` 在訓練集沒出現＝規則缺口（E 類；歸因未再驗）。
- 旁證：23 項中 15 項 class 與 kind 相同，registry 的兩個分類詞彙高度重疊。
- **限制**：這只是機制試點，不是成效證明——留出僅 4 項、法則是玩具級。它證明的是「凍結→留出評分→棄權計帳」可由機器執行。

## 4. 接點與限制

- 建議 `precheck [expansion]`（WARN）彙整三項：投影漂移（D 類）、容許殘差、推廣殘差（報告）。本場未接入 precheck，避免擴大改動；排 R4L／R3。
- 0 新狀態、0 新角色。
- 推廣道只有機制試點（§3）；留出單位選哪一種（能力／問題類／Work Unit）待在 R3 逐元件定。

## 5. 外部比對後的修正（設計，未實作）

1. **硬／軟法則（G6）**：每條法則標 HARD 或 SOFT。HARD 違反＝擋；SOFT 違反＝只報告。blueprint 現有 12 條不變式預設 HARD。
2. **先擋後驗（G5）**：新設計先在骨架階段跑 T1 靜態謂詞（便宜）再展開；歸納新規則時，不得與既有 HARD 法則衝突。
3. **適用條件（G1）**：每條法則與種子附適用條件。情境超出條件＝標 OOD，結果只能標 UNKNOWN 或交人判，不得標通過（相似律成立不了時要有人做工程判斷）。
4. **證據等級（G2）**：推導物逐項標驗證到哪一級：未驗／已擬合／已推廣／已容許。只給等級，不給機率。
5. **逐級驗證（G3）**：每展開一級，先過上一級的法則檢查，才進下一級（對應 Event-B 每步的證明義務）。
6. **啟用分級（G7）**：新增的節點或能力先以 STUB 加入（不接線，對上層與 Planner 零影響），通過該級檢查才升為 WIRED；Planner 只可規劃 WIRED 的能力。STUB 超過約定場數未升級須告警（否則零影響會變成永遠不接線）。對應 Event-B「新事件對抽象層不可見」，也針對 registry 宣告高於證據的問題。registry 目前沒有此欄位（已查；`implementation` 被閘門強制為 CANONICAL，不可重用），需新增 `activation`（Open-Items OI-7）。