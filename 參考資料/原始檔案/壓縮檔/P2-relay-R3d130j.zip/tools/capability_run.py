#!/usr/bin/env python3
"""capability_run — really execute declared capability providers and check each was entered (R3d12y, stdlib + repo scripts).

Entry for CAP-EVIDENCE / CAP-PROVENANCE (evidence_provenance_guard, via result_chain.run_packet_chain), CAP-RETIRE (lifecycle_sweep.
simulate_quarantine) and CAP-CONVERSATION-RECORD (dialogue_loop.simulate, event_log), plus CAP-VERIFY (verify_verdict), CAP-GAP (gap_ledger) and CAP-ITERATE
(iterate_control) and CAP-INSTRUCTION-ROUTING (habit_counter, role_command_router) added in R3d12zr, CAP-STATISTICS (stats_summary) and CAP-CLASSIFY (classify_guard) in R3d12zu. A capability passes only when its runner succeeds
AND sys.setprofile shows every declared provider module was entered (measured, not typed). Exit 0 only when all pass; simulated = SIMULATED_PASS.
Usage: python3 tools/capability_run.py
"""
from __future__ import annotations

import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

SCRIPTS = Path(__file__).resolve().parents[1] / "P1-Central-Control" / "scripts"
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import classify_guard  # noqa: E402
import dialogue_loop  # noqa: E402
import extract_guard  # noqa: E402
import gap_ledger  # noqa: E402
import habit_counter  # noqa: E402
import iterate_control  # noqa: E402
import lifecycle_sweep  # noqa: E402
import result_chain  # noqa: E402
import segment_ingest  # noqa: E402
import stats_summary  # noqa: E402
import relation_guard  # noqa: E402
import counterexample_log  # noqa: E402
import hypothesis_guard  # noqa: E402
import pattern_guard  # noqa: E402
import synthesis_guard  # noqa: E402
import provenance_trace  # noqa: E402
import research_request  # noqa: E402
import evidence_outer  # noqa: E402
import graph_check  # noqa: E402
import temporal_order  # noqa: E402
import verify_verdict  # noqa: E402

CAPS: dict[str, tuple[tuple[str, ...], str]] = {
    "CAP-EVIDENCE": (("evidence_provenance_guard",), "chain"),
    "CAP-PROVENANCE": (("provenance_trace", "evidence_outer"), "provenance"),
    "CAP-RETIRE": (("lifecycle_sweep",), "sweep"),
    "CAP-CONVERSATION-RECORD": (("dialogue_loop", "event_log"), "dialogue"),
    "CAP-VERIFY": (("verify_verdict",), "verify"),
    "CAP-GAP": (("gap_ledger",), "gap"),
    "CAP-ITERATE": (("iterate_control",), "iterate"),
    "CAP-INGEST": (("segment_ingest",), "ingest"),
    "CAP-EXTRACT": (("extract_guard",), "extract"),
    "CAP-TEMPORAL": (("temporal_order",), "temporal"),
    "CAP-GRAPH": (("graph_check",), "graph"),
    "CAP-RELATION": (("relation_guard",), "relation"),
    "CAP-COUNTEREXAMPLE": (("counterexample_log",), "counterexample"),
    "CAP-HYPOTHESIS": (("hypothesis_guard",), "hypothesis"),
    "CAP-PATTERN": (("pattern_guard",), "pattern"),
    "CAP-SYNTHESIS": (("synthesis_guard",), "synthesis"),
    "CAP-SEARCH": (("research_request",), "search"),
    "CAP-CLASSIFY": (("classify_guard",), "classify"),
    "CAP-STATISTICS": (("stats_summary",), "stats"),
    "CAP-INSTRUCTION-ROUTING": (("habit_counter", "role_command_router"), "routing"),
}


def _chain() -> bool:
    with tempfile.TemporaryDirectory() as tmp:
        r = result_chain.run_packet_chain(Path(tmp))
    return r.get("ingest_status") == "PASS" and r.get("after") == "INGESTED"


def _sweep() -> bool:
    return lifecycle_sweep.simulate_quarantine()["status"] == "SIMULATED_PASS"


def _dialogue() -> bool:
    return all(ok for _n, ok, _note in dialogue_loop.simulate())


def _bad_evidence() -> dict[str, Any]:
    ev: dict[str, Any] = {}
    ev["self"] = ev  # circular: hashing raises, and a verify that errors must end INCOMPLETE, never FAIL
    return ev


_FAIL_EV = {"attempts": [{"step": "t", "outcome": "failure"}]}
_OK_EV = {"attempts": [{"step": "t", "outcome": "success", "exit_code": 0}]}


def _verify() -> bool:
    vv = verify_verdict
    fail, ok = vv.verify("T", _FAIL_EV), vv.verify("T", _OK_EV)
    empty, bad = vv.verify("T", {}), vv.verify("T", _bad_evidence())
    again = vv.verify("T", _FAIL_EV, [fail])
    return (fail["verdict"] == "FAIL" and fail["failed"] == ["attempt:0:outcome=failure"] and ok["verdict"] == "PASS"
            and empty["verdict"] == "INCOMPLETE" and bad["verdict"] == "INCOMPLETE" and bad.get("error_code", "").startswith("VERIFY_ERROR")
            and again.get("reused") is True)


def _gap() -> bool:
    gl, vv = gap_ledger, verify_verdict
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "gaps.json"
        ck = gl.load(path)  # absent file = empty checkpoint
        ck = gl.apply_verdict(ck, vv.verify("T", _FAIL_EV), "T")
        ck = gl.apply_verdict(ck, vv.verify("T", _FAIL_EV), "T")  # rewrite keeps one entry
        gl.save(path, ck)
        back = gl.load(path)
        resolved = gl.apply_verdict(gl.load(path), vv.verify("T", _OK_EV), "T")
        path.write_text("{broken", encoding="utf-8")
        try:
            gl.load(path)
            corrupt_caught = False
        except ValueError:
            corrupt_caught = True
    return len(back["gaps"]) == 1 and back == ck and resolved["gaps"] == [] and corrupt_caught


def _iterate() -> bool:
    ic = iterate_control
    gap = {"id": "g1", "priority": "FAIL"}
    done = ic.decide({"round": 0, "prev_ids": [], "gaps": []})["decision"]
    cont = ic.decide({"round": 0, "prev_ids": [], "gaps": [gap]})["decision"]
    ck = ic.finish_round({"round": 0, "prev_ids": [], "gaps": [gap]}, ic.high_ids({"gaps": [gap]}))
    stalled = ic.decide(ck)["decision"]
    limit = ic.decide({"round": ic.DEFAULT_LIMIT, "prev_ids": [], "gaps": [gap]})["decision"]
    return (done, cont, stalled, limit) == ("DONE", "CONTINUE", "STALLED", "LIMIT") and ck["round"] == 1


def _ingest() -> bool:
    si = segment_ingest
    src = {"id": "S-CAP", "trust": "UNTRUSTED", "text": "甲乙丙。\n\n丁戊己。\n\n庚辛。"}
    with tempfile.TemporaryDirectory() as tmp:
        a, b = si.ingest(src, Path(tmp), max_chars=6), si.ingest(src, Path(tmp), max_chars=6)
        refused = si.ingest({"id": "S", "text": "x"}, Path(tmp))
    return (a["status"] == "OK" and len(a["segments"]) > 1 and b["written"] == 0 and refused["status"] == "FAILED"
            and si.check_coverage(src["text"], a["segments"]) == [])


def _extract() -> bool:
    seg = {"segment_id": "s1", "text": "abcdef", "trust": "UNTRUSTED"}
    schema = {"version": "1", "fields": {"n": "int"}}
    loc = {"segment_id": "s1", "start": 0, "end": 2}
    calls: list[int] = []

    def model(value: Any) -> Callable[..., Any]:
        return lambda s, sc, a: (calls.append(a), {"n": {"value": value, "locator": loc}})[1]

    def down(s: Any, sc: Any, a: Any) -> Any:
        raise RuntimeError("down")

    ok = extract_guard.extract_segment(seg, schema, model(1))
    calls.clear()
    bad = extract_guard.extract_segment(seg, schema, model("x"))
    return (ok["status"] == "OK" and bad["status"] == "PARTIAL" and len(calls) == 3 and bad["fields"]["n"]["value"] is None
            and extract_guard.extract_segment(seg, schema, down)["status"] == "INCOMPLETE")


def _routing() -> bool:
    with tempfile.TemporaryDirectory() as tmp:
        kw = dict(conversation_id="C-CAP", event_log_path=Path(tmp) / "ev.log", workflow_id="W-CAP", occurred_at="2026-10-16T10:00:00+00:00",
                  state_path=Path(tmp) / "routing.json")
        route = habit_counter.route_instruction
        a = route("!施工", source="USER_DIRECT", **kw)
        again = route("!施工", source="USER_DIRECT", **kw)
        unknown = route("!不存在的指令", source="USER_DIRECT", **kw)
        proposed = route("!施工", source="LLM_PROPOSED", **kw)
        vague = route("施工", source="USER_DIRECT", **kw)
    return (a["outcome"], again.get("reused"), unknown["outcome"], proposed["outcome"], vague["outcome"]) == (
        "ROUTED", True, "REFUSED", "REFUSED", "UNRESOLVED")


def _stats() -> bool:
    ss, v = stats_summary, [2, 4, 4, 4, 5, 5, 7, 9]
    a, b = ss.summarize("D", v, "R", "VERIFIED"), ss.summarize("D", v, "R", "VERIFIED")
    return (a["status"] == "OK" and ss.check_result(a, v) and a == b and ss.summarize("D", [1, float("nan")], "R", "VERIFIED")["status"] == "REJECTED"
            and ss.summarize("D", [], "R", "VERIFIED")["status"] == "INSUFFICIENT_DATA")


def _classify() -> bool:
    cg, table = classify_guard, {"version": "v1", "categories": ["A", "B"]}
    items, loc = [{"item_id": "x1"}, {"item_id": "x2"}], {"start": 0, "end": 1}

    def model(cat: Any) -> Callable[..., Any]:
        return lambda i, t, a: {"category": cat, "confidence": 0.9, "locator": loc}

    def down(i: Any, t: Any, a: Any) -> Any:
        raise RuntimeError("down")

    with tempfile.TemporaryDirectory() as tmp:
        ok = cg.classify_items(items, table, model("A"), Path(tmp) / "a")
        bad = cg.classify_items(items, table, model("Z"), Path(tmp) / "b")
        dead = cg.classify_items(items, table, down, Path(tmp) / "c")
    return (ok["status"] == "OK" and bad["status"] == "PARTIAL" and bad["results"]["x1"]["reason"] == "NOT_IN_TABLE"
            and dead["status"] == "INCOMPLETE" and dead["missing"] == ["x1", "x2"])


def _temporal() -> bool:
    to = temporal_order
    cl = [{"id": "b", "time": "2026-01-02T00:00:00+00:00"}, {"id": "a", "time": "2026-01-01T00:00:00+00:00"}, {"id": "x", "time": "later"}]
    r = to.order(cl)
    return (r["status"] == "PARTIAL" and r["order"] == ["a", "b"] and [u["id"] for u in r["unknown"]] == ["x"] and r == to.order(cl)
            and to.relation(cl[1], cl[0]) == "before")


def _graph() -> bool:
    gc, nodes = graph_check, ["a", "b", "c"]
    dag = [{"from": "a", "to": "b", "source": "S"}, {"from": "b", "to": "c", "source": "S"}]
    cyc = dag + [{"from": "c", "to": "a", "source": "S"}]
    ok, cy = gc.check(dag, nodes), gc.check(cyc, nodes)
    ghost = gc.check(dag + [{"from": "c", "to": "ghost", "source": "S"}], nodes)
    return (ok["status"] == "OK" and ok == gc.check(dag, nodes) and cy["status"] == "PARTIAL" and cy["cycle"][0] == cy["cycle"][-1]
            and ghost["status"] == "REJECTED" and gc.path(dag, "a", "c") == ["a", "b", "c"])


def _relation() -> bool:
    rg, ent = relation_guard, {"E1": ["甲"], "E2": ["乙"]}
    obs = [{"obs_id": "o1", "entities": ["甲", "乙"]}, {"obs_id": "o2", "entities": ["乙", "甲"]}]

    def model(a: Any, ev: Any) -> Callable[..., Any]:
        body = {"type": "t", "direction": "A→B", "condition": None, "depends": None, "evidence": [{"ref": ev, "stance": "support"}]}
        return lambda g, o, n: {"a": a, "b": "乙", **body}

    with tempfile.TemporaryDirectory() as tmp:
        ok = rg.build_relations(obs, ent, model("甲", "o1"), Path(tmp) / "a")
        ghost = rg.build_relations(obs, ent, model("甲", "none"), Path(tmp) / "b")
        unreg = rg.build_relations(obs, ent, model("鬼", "o1"), Path(tmp) / "c")
        edges = rg.graph_edges(ok["records"])
    return (ok["status"] == "OK" and len(edges) == 1 and rg.check_graph(ok["records"], ent)["status"] == "OK" and ghost["records"][0]["reason"] == "NO_EVIDENCE"
            and unreg["records"][0]["reason"] == "ENDPOINT_NOT_REGISTERED" and rg.graph_edges(ghost["records"]) == [] and rg.strength([], "R")["value"] == "UNKNOWN")


def _counterexample() -> bool:
    cl, h = counterexample_log, {"id": "H1", "scope_limit": "x", "alternatives": ["a"]}
    with tempfile.TemporaryDirectory() as tmp:
        d = Path(tmp) / "log"
        none = cl.record(h, ["s1", "s2"], lambda hh, s: [], d)
        again = cl.record(h, ["s2", "s1"], lambda hh, s: 1 / 0, d)  # finished key is reused: the searcher must not run
        found = cl.record(h, ["s3"], lambda hh, s: ["s3"], d)
        boom = cl.record(h, ["s4"], lambda hh, s: 1 / 0, d)
        ghost = cl.record(h, ["s5"], lambda hh, s: ["zz"], d)  # ref outside the searched scope
        limited = cl.record(h, ["s6"], lambda hh, s: [], d, search_available=False)
        missing = cl.audit([{"id": "H1", "level": 2}, {"id": "H2", "level": 2}], d)["missing"]
    return (none["status"] == "NONE_IN_SCOPE" and again["ref"] == none["ref"] and found["status"] == "FOUND" and boom["status"] == "INCOMPLETE"
            and ghost["status"] == "INCOMPLETE" and limited["status"] == "SCOPE_LIMITED" and missing == ["H2"])


def _hypothesis() -> bool:
    cl, hg = counterexample_log, hypothesis_guard
    h = {"id": "H1", "scope_limit": "x", "alternatives": ["a"]}
    with tempfile.TemporaryDirectory() as tmp:
        log, store = Path(tmp) / "log", Path(tmp) / "store"
        ref = cl.record(h, ["s1"], lambda hh, s: [], log)["ref"]
        lim = cl.record(h, ["s2"], lambda hh, s: [], log, search_available=False)["ref"]

        def hyp(r: Any, **kw: Any) -> dict[str, Any]:
            return {"id": "H1", "version": 1, "statement": "s", "scope_limit": "x", "alternatives": ["a"], "counterexample_ref": r, "level": 2, **kw}
        ok, again = hg.submit(hyp(ref), log, store), hg.submit(hyp(ref), log, store)
        verdicts = [hg.check(hyp(None), log)["status"], hg.check(hyp(lim), log)["status"], hg.check(hyp(ref, alternatives=[]), log)["status"],
                    hg.check(hyp(ref), Path(tmp) / "none")["status"]]
        hist = hg.history("H1", store)
    return ok["status"] == "ACCEPTABLE" and again["cached"] and verdicts == ["REJECTED", "PROVISIONAL", "REJECTED", "INCOMPLETE"] and hist == [(1, "ACCEPTABLE")]


def _pattern() -> bool:
    pg = pattern_guard
    obs = [{"id": f"o{i}", "source_id": "s"} for i in (1, 2, 3)]
    good = {"type": "共同", "scope": "all", "evidence_refs": ["o1", "o2"], "n": 2}
    with tempfile.TemporaryDirectory() as tmp:
        def run(out: Any, q: str) -> dict[str, Any]:
            return pg.build_patterns(obs, "dh", q, lambda qq, o, a: out, Path(tmp) / q)
        ok, ghost, thin, bad = run([good], "a"), run([dict(good, evidence_refs=["ghost"])], "b"), run([dict(good, n=1)], "c"), run("x", "e")
        few = pg.build_patterns(obs[:1], "dh", "d", lambda *a: 1 / 0, Path(tmp) / "d")
    return (ok["status"] == "PATTERN_FOUND" and ok["patterns"][0]["status"] == "CANDIDATE" and ghost["status"] == "REJECTED" and ghost["patterns"] == []
            and thin["status"] == "NO_SUFFICIENT_DATA" and few["status"] == "NO_SUFFICIENT_DATA" and bad["status"] == "REJECTED")


def _synthesis() -> bool:
    sg, ok_v, bad_v = synthesis_guard, {"verdict": "PASS", "key": "k"}, {"verdict": "FAIL", "key": "k"}

    def inp(c2: Any, gaps: Any = (), prov: Any = True) -> dict[str, Any]:
        return {"claims": [{"id": "c1", "verdict": ok_v}, {"id": "c2", "verdict": c2}], "hypotheses": [{"id": "h1", "state": "ACCEPTABLE"}],
                "gaps": list(gaps), "provenance": {"ok": prov} if prov is not None else None}
    d = {"text": "t", "claim_refs": ["c1", "c2"], "hypothesis_main": ["h1"], "hypothesis_pending": [], "status": "COMPLETE", "gaps": []}
    gap = {"id": "g", "evidence_ref": "k"}
    with tempfile.TemporaryDirectory() as tmp:
        first, again = sg.submit(inp(ok_v), d, tmp), sg.submit(inp(ok_v), d, tmp)
    return (first["status"] == "COMPLETE" and again["cached"] and sg.check(inp(bad_v), d)["status"] == "REJECTED" and sg.check(inp(ok_v, [gap]), d)["status"] == "REJECTED"
            and sg.check(inp(ok_v, [gap]), dict(d, status="PARTIAL", gaps=["g"]))["status"] == "PARTIAL" and sg.check(inp(ok_v, prov=None), d)["status"] == "INCOMPLETE")


def _provenance() -> bool:
    def r(i: str, ins: list[str], outs: list[str], s: int, e: int) -> dict[str, Any]:
        return {"id": i, "activity": "a" + i, "input_refs": ins, "output_refs": outs, "started": s, "ended": e}
    pt, chain = provenance_trace, [r("r1", ["raw"], ["e1"], 1, 2), r("r2", ["e1"], ["e2"], 3, 4)]
    ok, brk = pt.trace(chain, "e2", {"raw"}), pt.trace(chain, "e2")
    cyc = pt.trace([r("r1", ["e2"], ["e1"], 1, 2), r("r2", ["e1"], ["e2"], 3, 4)], "e2")
    return (ok["status"] == "COMPLETE" and brk["status"] == "PARTIAL" and cyc["status"] == "FAILED" and pt.trace("x", "e")["status"] == "INCOMPLETE"
            and pt.provenance_input(ok) == {"ok": True, "breaks": []} and pt.provenance_input(pt.trace("x", "e")) is None
            and _evidence_ext())


def _evidence_ext() -> bool:
    eo, ev = evidence_outer, [{"object_id": "e1", "claim_ref": "h1", "relation": "SUPPORTS", "locator": "https://x.org/p"}]

    def fail(m: str) -> Any:
        def f() -> None:
            raise ValueError(m)
        return f
    c = {"id": "h1", "kind": "HYPOTHESIS", "evidence_refs": ["e1"]}
    return (eo.classify(lambda: {})["status"] == "PASS" and eo.classify(fail("缺少 EvidenceRecord: e1"))["status"] == "INCOMPLETE"
            and eo.classify(fail("成功結果的 Evidence 必須為 SUPPORTS"))["status"] == "FAILED" and eo.check_research_claims([c], ev)["status"] == "PASS"
            and eo.check_research_claims([dict(c, evidence_refs=[])], ev)["status"] == "REJECTED"
            and [w["kind"] for w in eo.locator_warnings(ev, ".")] == ["LOCATOR_UNVERIFIABLE"])


def _search() -> bool:
    rq, c = research_request, {"url": "https://a.org/x", "retrieved_at": "2026-10-16T01:00:00Z"}
    with tempfile.TemporaryDirectory() as tmp:
        ok, again = rq.request("g", ["q"], lambda q: [c, {"url": "x"}], tmp), rq.request("g", ["q"], lambda q: 1 / 0, tmp)
        part, none, many = rq.request("g2", ["q", "r"], lambda q: [], tmp), rq.request("g3", ["q"], None, tmp), rq.request("g4", ["a", "b", "c"], lambda q: [c], tmp)
    return (ok["status"] == "COMPLETE" and len(ok["rejected"]) == 1 and again["candidates"] == ok["candidates"] and part["status"] == "PARTIAL"
            and none["status"] == "NOT_EXECUTED" and many["reason"] == "ROUND_LIMIT")


RUNNERS: dict[str, Callable[[], bool]] = {"chain": _chain, "sweep": _sweep, "dialogue": _dialogue, "verify": _verify, "gap": _gap,
                                          "iterate": _iterate, "routing": _routing, "ingest": _ingest, "extract": _extract, "stats": _stats, "classify": _classify, "temporal": _temporal, "graph": _graph, "relation": _relation,
                                          "counterexample": _counterexample, "hypothesis": _hypothesis,
                                          "pattern": _pattern, "synthesis": _synthesis, "provenance": _provenance, "search": _search}


def check(cap: str, runners: dict[str, Callable[[], bool]] | None = None) -> dict[str, Any]:
    providers, runner = CAPS[cap]
    ok, entered = result_chain.trace_modules((runners or RUNNERS)[runner])
    missing = [p for p in providers if p not in entered]
    return {"capability": cap, "ok": bool(ok) and not missing, "runner_ok": bool(ok), "providers_missing": missing}


def main() -> int:
    rows = [check(c) for c in CAPS]
    for r in rows:
        print("PASS" if r["ok"] else "FAIL", r["capability"], "" if r["ok"] else r)
    return 0 if all(r["ok"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
