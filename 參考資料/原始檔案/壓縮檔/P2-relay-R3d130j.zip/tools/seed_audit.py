#!/usr/bin/env python3
"""P2 seed_audit — mechanical checks for the expansion seeds in canonical/blueprint.json (stdlib only; R3d10 R3f).

Seeds (optional blueprint fields): dependency_graph, expansion_rules, residual_policy, law_meta, context_schema.
Rules
  SD1  dependency_graph is acyclic; node level == longest prerequisite chain + 1; <= 9 nodes per level; edges name known nodes.
  SD2  every component has exactly one residual_policy row (level L1-L3, tolerance for all three levels, non-negative ints);
       a non-zero tolerance needs a non-empty `exception_reason`.
  SD3  every expansion rule template (`path:function`) names an existing file; `target` file exists; rule_id unique.
  SD4  every invariant has exactly one law_meta row (strength HARD|SOFT, valid_when non-empty, predicate_type T1|T2).
  SD5  context_schema is an object with goal / constraints / params.
  SD6  graph nodes == component ids (one source of truth for the component list).
Report only (not a failure): r = rule bytes / target bytes per expansion rule (OI-14; HYPOTHESIS: software components unverified).

Usage: python3 tools/seed_audit.py [--selftest] [--json]     exit 0 = PASS
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BLUEPRINT = "P1-Central-Control/canonical/blueprint.json"
LEVELS = ("L1", "L2", "L3")


def derive_levels(nodes: list[str], edges: list[list[str]]) -> dict[str, int] | None:
    """Longest-prerequisite-chain level (sources = 1). None if the graph has a cycle."""
    preds = {n: [] for n in nodes}
    for a, b in edges:
        preds[b].append(a)
    level: dict[str, int] = {}
    state: dict[str, int] = {}

    def visit(n: str) -> bool:
        if state.get(n) == 2:
            return True
        if state.get(n) == 1:
            return False
        state[n] = 1
        best = 0
        for p in preds[n]:
            if not visit(p):
                return False
            best = max(best, level[p])
        level[n] = best + 1
        state[n] = 2
        return True

    for n in nodes:
        if not visit(n):
            return None
    return level


def audit_blueprint(bp: dict, exists, size) -> dict:
    f: list[dict] = []
    comps = [c["component_id"] for c in bp.get("components", [])]
    invs = [i["invariant_id"] for i in bp.get("invariants", [])]
    g = bp.get("dependency_graph", {})
    nodes = g.get("nodes", [])
    ids = [n["id"] for n in nodes]
    edges = g.get("edges", [])
    if sorted(ids) != sorted(comps):
        f.append({"rule": "SD6", "error": "graph nodes differ from component ids", "nodes": ids})
    unknown = [e for e in edges if len(e) != 2 or e[0] not in ids or e[1] not in ids]
    if unknown:
        f.append({"rule": "SD1", "error": "edge names unknown node", "edges": unknown})
    else:
        lv = derive_levels(ids, edges)
        if lv is None:
            f.append({"rule": "SD1", "error": "cycle in dependency_graph"})
        else:
            for n in nodes:
                if n["level"] != lv[n["id"]]:
                    f.append({"rule": "SD1", "error": "level mismatch", "node": n["id"], "declared": n["level"], "derived": lv[n["id"]]})
            per: dict[int, int] = {}
            for n in nodes:
                per[n["level"]] = per.get(n["level"], 0) + 1
            for k, v in per.items():
                if v > 9:
                    f.append({"rule": "SD1", "error": "more than 9 nodes in a level", "level": k, "count": v})
    pol = bp.get("residual_policy", [])
    seen = [p["component"] for p in pol]
    for c in comps:
        if seen.count(c) != 1:
            f.append({"rule": "SD2", "error": "component needs exactly one residual_policy row", "component": c, "rows": seen.count(c)})
    for p in pol:
        tol = p.get("tolerance", {})
        if p.get("level") not in LEVELS or any((not isinstance(tol.get(k), int)) or tol[k] < 0 for k in LEVELS):
            f.append({"rule": "SD2", "error": "bad level or tolerance", "component": p.get("component")})
        elif any(tol[k] for k in LEVELS) and not p.get("exception_reason"):
            f.append({"rule": "SD2", "error": "non-zero tolerance without exception_reason", "component": p["component"]})
    rules = bp.get("expansion_rules", [])
    rids = [r["rule_id"] for r in rules]
    if len(set(rids)) != len(rids):
        f.append({"rule": "SD3", "error": "duplicate rule_id"})
    ratios = []
    for r in rules:
        tpl = r["template"].split(":")[0]
        tgt = r["target"].split("#")[0]
        for label, path in (("template", tpl), ("target", tgt)):
            if not exists(path):
                f.append({"rule": "SD3", "error": f"{label} file missing", "rule_id": r["rule_id"], "path": path})
        if exists(tgt) and size(tgt):
            ratios.append({"rule_id": r["rule_id"], "r": round(len(json.dumps(r, ensure_ascii=False).encode()) / size(tgt), 4)})
    meta = bp.get("law_meta", [])
    mids = [m["invariant_id"] for m in meta]
    for i in invs:
        if mids.count(i) != 1:
            f.append({"rule": "SD4", "error": "invariant needs exactly one law_meta row", "invariant_id": i, "rows": mids.count(i)})
    for m in meta:
        if m.get("strength") not in ("HARD", "SOFT") or not m.get("valid_when") or m.get("predicate_type") not in ("T1", "T2"):
            f.append({"rule": "SD4", "error": "bad law_meta row", "invariant_id": m.get("invariant_id")})
    cs = bp.get("context_schema")
    if not isinstance(cs, dict) or not {"goal", "constraints", "params"} <= set(cs):
        f.append({"rule": "SD5", "error": "context_schema needs goal / constraints / params"})
    return {"findings": f, "ratios": ratios}


def audit(root: Path = ROOT) -> dict:
    bp = json.loads((root / BLUEPRINT).read_text(encoding="utf-8"))
    return audit_blueprint(bp, lambda p: (root / p).exists(), lambda p: (root / p).stat().st_size)


def selftest() -> int:
    bp = {
        "components": [{"component_id": "C-A"}, {"component_id": "C-B"}],
        "invariants": [{"invariant_id": "INV-1"}],
        "dependency_graph": {"nodes": [{"id": "C-A", "level": 1}, {"id": "C-B", "level": 2}], "edges": [["C-A", "C-B"]]},
        "residual_policy": [{"component": "C-A", "level": "L1", "tolerance": {"L1": 0, "L2": 0, "L3": 0}},
                            {"component": "C-B", "level": "L3", "tolerance": {"L1": 0, "L2": 0, "L3": 0}}],
        "expansion_rules": [{"rule_id": "R-1", "template": "t.py:f", "target": "o.md#B", "holes": []}],
        "law_meta": [{"invariant_id": "INV-1", "strength": "HARD", "valid_when": "全域", "predicate_type": "T2"}],
        "context_schema": {"goal": "string", "constraints": ["string"], "params": {}},
    }
    ex, sz = (lambda p: True), (lambda p: 100)
    import copy

    def mut(fn):
        b = copy.deepcopy(bp)
        fn(b)
        return audit_blueprint(b, ex, sz)["findings"]

    cases = {
        "good": audit_blueprint(bp, ex, sz)["findings"] == [],
        "cycle": any(x["rule"] == "SD1" for x in mut(lambda b: b["dependency_graph"]["edges"].append(["C-B", "C-A"]))),
        "level": any(x["rule"] == "SD1" for x in mut(lambda b: b["dependency_graph"]["nodes"][1].update(level=1))),
        "crowd": any(x["rule"] == "SD1" for x in mut(lambda b: (b["components"].extend({"component_id": f"C-X{i}"} for i in range(9)),
                                                               b["dependency_graph"]["nodes"].extend({"id": f"C-X{i}", "level": 1} for i in range(9)),
                                                               b["residual_policy"].extend({"component": f"C-X{i}", "level": "L1", "tolerance": {"L1": 0, "L2": 0, "L3": 0}} for i in range(9))))),
        "nopolicy": any(x["rule"] == "SD2" for x in mut(lambda b: b["residual_policy"].pop())),
        "tolerance": any(x["rule"] == "SD2" for x in mut(lambda b: b["residual_policy"][0]["tolerance"].update(L3=2))),
        "template": any(x["rule"] == "SD3" for x in (audit_blueprint(bp, lambda p: p != "t.py", sz)["findings"])),
        "nolaw": any(x["rule"] == "SD4" for x in mut(lambda b: b["law_meta"].pop())),
        "badlaw": any(x["rule"] == "SD4" for x in mut(lambda b: b["law_meta"][0].update(strength="MAYBE"))),
        "ctx": any(x["rule"] == "SD5" for x in mut(lambda b: b.pop("context_schema"))),
        "nodes": any(x["rule"] == "SD6" for x in mut(lambda b: b["dependency_graph"]["nodes"].pop())),
    }
    bad = [k for k, v in cases.items() if not v]
    print("seed_audit selftest", "PASS" if not bad else f"FAIL {bad}", f"({len(cases)} cases)")
    return 0 if not bad else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    res = audit()
    if "--json" in sys.argv:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        for x in res["findings"]:
            print(x)
        for r in res["ratios"]:
            print("r", r)
        print("seed_audit", "PASS" if not res["findings"] else "FAIL")
    sys.exit(0 if not res["findings"] else 1)
