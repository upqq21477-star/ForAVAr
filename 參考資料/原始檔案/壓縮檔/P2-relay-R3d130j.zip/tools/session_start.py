#!/usr/bin/env python3
"""開場一個指令：清單驗證、交接大小、固定依賴債、登記表進度與下一批任務（只讀，不改檔；R3d11e）。

用法：python3 tools/session_start.py        （在解壓後的專案根目錄）
取代開場時分開的 verify／status／batch_gate／ls 四次工具呼叫。
"""
from __future__ import annotations

import contextlib
import io
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
READ_BUDGET = 48 * 1024


def _verify() -> str:
    import pack_handoff

    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        rc = pack_handoff.verify(ROOT)
    last = buf.getvalue().strip().splitlines()[-1:] or [""]
    return ("OK  " if rc == 0 else "FAIL  ") + last[0]


def build_report(root: Path = ROOT) -> list[str]:
    import fixed_deps_gate

    g = fixed_deps_gate.Gate(root)
    pol = g.policy()
    reg = json.loads((root / fixed_deps_gate.REGISTRY_REL).read_text(encoding="utf-8"))
    tasks = [(b["batch_id"], b["tier"], t["task_id"], t["status"]) for b in reg["batches"] for t in b.get("tasks", [])]
    done = sum(1 for t in tasks if t[3] in ("DONE", "SKIPPED"))
    nxt = [t for t in tasks if t[3] not in ("DONE", "SKIPPED")]
    hand = (root / "docs/handoffs/HANDOFF.md").read_bytes()
    lines = [f"清單驗證：{_verify()}",
             f"交接檔：{len(hand):,} B（讀取預算的 {len(hand) * 100 // READ_BUDGET}%；上限 12,000 B）",
             "固定依賴：", *("  " + x for x in g.status().splitlines()),
             f"登記表：任務 DONE {done}/{len(tasks)}"]
    has_real = g.load("REAL.json") is not None
    blocked = {b for b in pol["require_real_before_done"]}
    shown = 0
    for batch, tier, tid, status in nxt:
        if shown >= 5:
            break
        note = "（需要 REAL 證據才能標 DONE）" if batch in blocked and not has_real and not g.deferred(pol) else ""
        lines.append(f"  下一項：{tid}（梯次 {tier}，{status}）{note}")
        shown += 1
    if not shown:
        lines.append("  下一項：無（登記表任務全部 DONE／SKIPPED）")
    fd = g.check()
    lines.append("fixed_deps 檢查：" + ("PASS" if not fd else "FAIL → " + "; ".join(e["error"][:60] for e in fd)))
    return lines


def registry_counts(root: Path = ROOT) -> dict:
    """Task and batch progress computed from the registry (single source for handoff counters; OB5-2)."""
    import fixed_deps_gate

    reg = json.loads((root / fixed_deps_gate.REGISTRY_REL).read_text(encoding="utf-8"))
    tasks = [t["status"] for b in reg["batches"] for t in b.get("tasks", [])]
    return {
        "done": sum(1 for x in tasks if x in ("DONE", "SKIPPED")),
        "total": len(tasks),
        "batches_done": sum(1 for b in reg["batches"] if b.get("status") == "DONE"),
        "batches_total": len(reg["batches"]),
    }


def precheck_line(runner=None, root: Path = ROOT) -> str:
    """Baseline check at session start (OB5-3): run precheck once and report PASS or the failing HARD checks."""
    if runner is None:
        def runner():
            r = subprocess.run([sys.executable, str(root / "tools" / "precheck.py")], capture_output=True, text=True, cwd=root)
            return r.returncode, r.stdout
    rc, out = runner()
    bad = [f"{m.group(1)}×{m.group(2)}" for m in re.finditer(r"^\[(\w+)\] HARD errors=(\d+)", out, re.M) if int(m.group(2)) > 0]
    if rc == 0 and not bad:
        return "precheck 基線：PASS"
    return "precheck 基線：FAIL（" + (", ".join(bad) or f"退出碼 {rc}") + "）→ 先修復再開新任務"


def main() -> int:
    lines = build_report()
    if "--no-precheck" not in sys.argv[1:]:
        lines.append(precheck_line())
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    sys.exit(main())
