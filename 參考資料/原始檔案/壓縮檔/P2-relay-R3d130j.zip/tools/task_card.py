#!/usr/bin/env python3
"""P2 task_card — XM1: check an executor-independent task card (stdlib only).

A task card says WHAT to do, never WHO does it: files to change, files that must not be touched, the acceptance command and where the
evidence goes.  Any executor (CHAT baseline, ACTIONS, CODEX) can take the same card.  Unclear spec -> the executor writes a `blocker`
and the card goes back to the chat; design decisions stay on the chat side.  Policy: P1-Central-Control/policy/executor_mode.v1.0.json.

  python3 tools/task_card.py --check <card.json>   exit 0 OK, 3 BLOCKED_TO_CHAT (valid card with a blocker), 1 INVALID
  python3 tools/task_card.py --selftest            good card passes, every bad card is rejected

Card keys: task_id, files_to_change[], files_forbidden[], acceptance_command, evidence_path  (+ optional executor, requires_executor,
blocker{phenomenon, tried[], hypothesis?}, notes).  `requires_executor` may only be the baseline CHAT.  No vendor-specific keys.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY = ROOT / "P1-Central-Control/policy/executor_mode.v1.0.json"
EVIDENCE_PREFIX = "P1-Central-Control/evidence/batch/"
REQUIRED = ("task_id", "files_to_change", "files_forbidden", "acceptance_command", "evidence_path")
OPTIONAL = ("executor", "requires_executor", "blocker", "notes")
BLOCKER_KEYS = {"phenomenon", "tried", "hypothesis"}


def load_policy() -> dict:
    return json.loads(POLICY.read_text(encoding="utf-8"))


def _bad_path(p: object) -> bool:
    return not isinstance(p, str) or not p or p.startswith("/") or ".." in Path(p).parts or "\\" in p


def check_card(card: object, policy: dict | None = None) -> list[str]:
    """Error codes; [] means the card is well formed."""
    pol = policy or load_policy()
    if not isinstance(card, dict):
        return ["CARD_NOT_OBJECT"]
    errs = [f"MISSING:{k}" for k in REQUIRED if k not in card]
    errs += [f"EXTRA_KEY:{k}" for k in card if k not in REQUIRED + OPTIONAL]
    if errs:
        return errs
    if not isinstance(card["task_id"], str) or not card["task_id"].strip():
        errs.append("EMPTY:task_id")
    for k in ("files_to_change", "files_forbidden"):
        v = card[k]
        if not isinstance(v, list) or any(not isinstance(x, str) for x in v):
            errs.append(f"NOT_STRING_LIST:{k}")
        elif any(_bad_path(x) for x in v):
            errs.append(f"BAD_PATH:{k}")
    if isinstance(card["files_to_change"], list) and not card["files_to_change"]:
        errs.append("EMPTY:files_to_change")
    if not errs:
        errs += [f"OVERLAP:{x}" for x in sorted(set(card["files_to_change"]) & set(card["files_forbidden"]))]
    if not isinstance(card["acceptance_command"], str) or not card["acceptance_command"].strip():
        errs.append("EMPTY:acceptance_command")
    ev = card["evidence_path"]
    if _bad_path(ev) or not ev.startswith(EVIDENCE_PREFIX) or not ev.endswith(".json"):
        errs.append("BAD_EVIDENCE_PATH")
    if "executor" in card and card["executor"] not in pol["allowed"]:
        errs.append("EXECUTOR_NOT_ALLOWED")
    if card.get("requires_executor") not in (None, pol["baseline"]):
        errs.append("REQUIRES_NON_BASELINE_EXECUTOR")
    if "blocker" in card:
        b = card["blocker"]
        if not isinstance(b, dict) or set(b) - BLOCKER_KEYS or not str(b.get("phenomenon", "")).strip():
            errs.append("BLOCKER_SHAPE")
        elif not isinstance(b.get("tried"), list) or not b["tried"] or any(not isinstance(x, str) or not x.strip() for x in b["tried"]):
            errs.append("BLOCKER_TRIED_REQUIRED")
        elif "hypothesis" in b and not str(b["hypothesis"]).startswith("HYPOTHESIS"):
            errs.append("BLOCKER_HYPOTHESIS_UNLABELED")
    return errs


def status_of(card: object, policy: dict | None = None) -> tuple[str, list[str]]:
    errs = check_card(card, policy)
    if errs:
        return "INVALID", errs
    return ("BLOCKED_TO_CHAT", []) if "blocker" in card else ("OK", [])  # type: ignore[operator]


GOOD = {"task_id": "T-1", "files_to_change": ["P1-Central-Control/scripts/a.py"], "files_forbidden": ["P1-Central-Control/canonical/x.json"],
        "acceptance_command": "python3 tools/precheck.py", "evidence_path": EVIDENCE_PREFIX + "T-1.json"}


def _bad_cards() -> dict[str, object]:
    def g(**kw):
        c = {**GOOD, **kw}
        for k in [k for k, v in kw.items() if v is KeyError]:
            c.pop(k)
        return c
    return {
        "not_object": [], "missing_task_id": g(task_id=KeyError), "missing_forbidden": g(files_forbidden=KeyError),
        "missing_command": g(acceptance_command=KeyError), "missing_evidence": g(evidence_path=KeyError),
        "empty_task_id": g(task_id=" "), "empty_files": g(files_to_change=[]), "files_not_list": g(files_to_change="a.py"),
        "absolute_path": g(files_to_change=["/etc/passwd"]), "dotdot_path": g(files_to_change=["a/../../b"]),
        "overlap": g(files_forbidden=["P1-Central-Control/scripts/a.py"]), "empty_command": g(acceptance_command=""),
        "evidence_outside": g(evidence_path="docs/x.json"), "evidence_not_json": g(evidence_path=EVIDENCE_PREFIX + "x.txt"),
        "unknown_executor": g(executor="GPT"), "requires_codex": g(requires_executor="CODEX"),
        "vendor_key": g(agents_md=True), "blocker_not_object": g(blocker="stuck"),
        "blocker_no_phenomenon": g(blocker={"tried": ["x"]}), "blocker_no_tried": g(blocker={"phenomenon": "p", "tried": []}),
        "blocker_extra_key": g(blocker={"phenomenon": "p", "tried": ["x"], "plan": "y"}),
        "blocker_unlabeled_guess": g(blocker={"phenomenon": "p", "tried": ["x"], "hypothesis": "maybe the cache"}),
    }


def run_negatives(check_fn=None, policy: dict | None = None) -> list[str]:
    """Names of bad cards that `check_fn` wrongly accepts, plus the good cards it wrongly rejects.  Real checker -> []."""
    check_fn = check_fn or check_card  # resolved at call time so a patched checker is really used
    pol = policy or load_policy()
    wrong = [n for n, c in _bad_cards().items() if not check_fn(c, pol)]
    good = [GOOD, {**GOOD, "executor": "CODEX"}, {**GOOD, "requires_executor": "CHAT"},
            {**GOOD, "blocker": {"phenomenon": "p", "tried": ["a", "b"], "hypothesis": "HYPOTHESIS: stale cache"}}]
    return wrong + [f"good_{i}" for i, c in enumerate(good) if check_fn(c, pol)]


def main(argv: list[str]) -> int:
    if "--selftest" in argv:
        bad = run_negatives()
        status = [status_of(GOOD)[0], status_of({**GOOD, "blocker": {"phenomenon": "p", "tried": ["a"]}})[0]]
        if status != ["OK", "BLOCKED_TO_CHAT"]:
            bad.append(f"status:{status}")
        print("task_card selftest", "PASS" if not bad else f"FAIL {bad}", f"({len(_bad_cards()) + 4} cases)")
        return 0 if not bad else 1
    if "--check" in argv:
        card = json.loads(Path(argv[argv.index("--check") + 1]).read_text(encoding="utf-8"))
        st, errs = status_of(card)
        print(json.dumps({"status": st, "errors": errs}, ensure_ascii=False))
        return {"OK": 0, "BLOCKED_TO_CHAT": 3}.get(st, 1)
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
