#!/usr/bin/env python3
"""Bounded reader — the only sanctioned way to look inside large files (stdlib only).

Why: a free-tier session has a small context. `cat` on the 134 KB blueprint burns it.
This tool always caps output (default 6000 bytes) and says when it truncated.

  python3 tools/slice.py FILE --toc                    # headings + byte offsets (md) or top-level keys (json)
  python3 tools/slice.py FILE --heading "## 3."        # one markdown section (prefix match, to next same/higher heading)
  python3 tools/slice.py FILE --lines 120:180          # line range (1-based, inclusive)
  python3 tools/slice.py FILE --grep PATTERN [--ctx 2] # regex hits with context lines
  python3 tools/slice.py FILE --json-path a.b.0        # one value inside a JSON file
Add --max N to change the byte cap (never above 20000).
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

HARD_MAX = 20000


def emit(text: str, cap: int) -> None:
    data = text.encode("utf-8")
    if len(data) > cap:
        text = data[:cap].decode("utf-8", errors="ignore")
        text += f"\n…[TRUNCATED at {cap} bytes of {len(data)}; narrow the slice]"
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stdout.write(text if text.endswith("\n") else text + "\n")


def toc(text: str, path: Path) -> str:
    if path.suffix == ".json":
        obj = json.loads(text)
        if isinstance(obj, dict):
            return "\n".join(f"{k}: {type(v).__name__} {len(json.dumps(v, ensure_ascii=False))}B" for k, v in obj.items())
        return f"list[{len(obj)}]"
    out, offset = [], 0
    for number, line in enumerate(text.splitlines(keepends=True), 1):
        if line.startswith("#"):
            out.append(f"{number:5d} @{offset:7d}B  {line.rstrip()[:100]}")
        offset += len(line.encode("utf-8"))
    return "\n".join(out) or "(no headings)"


def heading(text: str, key: str) -> str:
    lines = text.splitlines()
    start = next((i for i, l in enumerate(lines) if l.startswith("#") and l.lstrip("#").strip().startswith(key.lstrip("#").strip())), None)
    if start is None:
        return f"NOT_FOUND heading prefix: {key}"
    level = len(lines[start]) - len(lines[start].lstrip("#"))
    end = len(lines)
    for j in range(start + 1, len(lines)):
        if lines[j].startswith("#") and (len(lines[j]) - len(lines[j].lstrip("#"))) <= level:
            end = j
            break
    return "\n".join(lines[start:end])


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("file")
    ap.add_argument("--toc", action="store_true")
    ap.add_argument("--heading")
    ap.add_argument("--lines")
    ap.add_argument("--grep")
    ap.add_argument("--ctx", type=int, default=1)
    ap.add_argument("--json-path")
    ap.add_argument("--max", type=int, default=6000)
    a = ap.parse_args()
    cap = min(a.max, HARD_MAX)
    path = Path(a.file)
    text = path.read_text(encoding="utf-8")
    if a.toc:
        emit(toc(text, path), cap)
    elif a.heading:
        emit(heading(text, a.heading), cap)
    elif a.lines:
        lo, hi = (int(x) for x in a.lines.split(":"))
        emit("\n".join(f"{n:5d}  {l}" for n, l in enumerate(text.splitlines(), 1) if lo <= n <= hi), cap)
    elif a.grep:
        lines, rx, shown, out = text.splitlines(), re.compile(a.grep), set(), []
        for i, line in enumerate(lines):
            if rx.search(line):
                for j in range(max(0, i - a.ctx), min(len(lines), i + a.ctx + 1)):
                    if j not in shown:
                        shown.add(j)
                        out.append(f"{j + 1:5d}{':' if j == i else '-'} {lines[j][:200]}")
        emit("\n".join(out) or "NO_MATCH", cap)
    elif a.json_path:
        node = json.loads(text)
        for part in a.json_path.split("."):
            node = node[int(part)] if isinstance(node, list) else node[part]
        emit(json.dumps(node, ensure_ascii=False, indent=1), cap)
    else:
        ap.error("choose one of --toc/--heading/--lines/--grep/--json-path")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
