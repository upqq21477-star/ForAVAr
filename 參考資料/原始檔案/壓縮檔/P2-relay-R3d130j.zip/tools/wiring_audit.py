#!/usr/bin/env python3
"""wiring_audit — derive each capability's wiring evidence (R1-S3g, S3-M4 / FR-11 / D18).

stdlib `ast` only; no network, no pip dependency. Design decision D-S3f-M4 (see handoff):
vulture / import-linter / pyan3 were compared and not adopted (their unit is a name or a module,
none emits provider/consumer/modes/success/failure, none has an UNKNOWN state). Borrowed ideas:
confidence grades (vulture), a declared whitelist for dynamic entries (vulture), and counting only
non-test imports and entry references (pyan3 over-reports edges).

Per capability in P1-Central-Control/capability_registry.json it prints five fields:
  provider, consumer, usable_modes, success_condition, failure_feedback
Anything without evidence is the literal string UNKNOWN. Nothing is guessed: providers come only from
DECLARED_PROVIDERS below (a human edit, each with its written source). Capabilities with no tool
(statistics / clustering / trend / anomaly) are DECLARED_NO_TOOL.

Derived implementation: WIRED (grade HIGH: non-test import AND entry reference), PARTIAL (grade LOW:
only one of them, only string or dynamic references), DECLARED_NO_TOOL, UNKNOWN. From these the tool
reports a derived maturity per capability: WIRED, UNWIRED (everything else with a provider question
open) or NO_TOOL. The registry value `implementation: CANONICAL` is an identity constraint ("one
canonical implementation per capability", required by capability_independence_gate), not a maturity
claim, so it is NOT used as a ceiling any more (D-R2c-D18; the old OVERCLAIM verdict is retired).
Identity and the typed claim about it are recorded separately (in-toto subject / predicate split).
This tool never edits a registry and never runs tests: test status is read from the files and the
baseline list only, so success_condition is a pointer, not a pass.

Usage:  python3 tools/wiring_audit.py [--json] [--strict] [--selftest]
Exit 0 unless --strict and an UNWIRED capability exists (precheck [wiring] uses WARN, never fails).
"""
from __future__ import annotations

import argparse
import ast
import json
import re
import sys
import tempfile
from pathlib import Path

UNKNOWN = "UNKNOWN"
NO_TOOL = "DECLARED_NO_TOOL"
NO_TOOL_MATURITY = "NO_TOOL"
CORE = "P1-Central-Control"

# Provider declarations. Key = capability id; value = (script stems, written source).
# Add a line only with a written source; never infer from names.
DECLARED_PROVIDERS: dict[str, tuple[tuple[str, ...], str]] = {
    "CAP-RETIRE": (("lifecycle_sweep",), "policy/role_capability_binding.v1.0.json rule: CAP-RETIRE runs on lifecycle_sweep batch list"),
    "CAP-EVIDENCE": (("evidence_provenance_guard",), "scripts/evidence_provenance_guard.validate_evidence; run and measured by tools/capability_run.py (R3d12y); G-EV1~3 outer layer = scripts/evidence_outer (measured under CAP-PROVENANCE)"),
    "CAP-PROVENANCE": (("provenance_trace", "evidence_outer"), "scripts/provenance_trace.trace/provenance_input (multi-hop) + scripts/evidence_outer (G-EV1~3); single-hop guard remains in evidence_provenance_guard; run and measured by tools/capability_run.py (R3d12zy); tests/test_s6_batch3.py; production caller: Run.close -> p2_run._provenance (R3d130b S7a); SYNTHESIS pre-acceptance still 0"),
    "CAP-CONVERSATION-RECORD": (("dialogue_loop", "event_log"), "capability_registry.json purpose: event_log DIALOGUE_TURN; run and measured by tools/capability_run.py (R3d12y)"),
    "CAP-INSTRUCTION-ROUTING": (("habit_counter", "role_command_router"), "scripts/habit_counter.route_instruction wraps role_command_router.resolve_and_record (R3d12zr); run and measured by tools/capability_run.py; tests/test_s3c_routing_retire.py"),
    "CAP-TEMPORAL": (("temporal_order",), "scripts/temporal_order.order/relation/periodicity; run and measured by tools/capability_run.py (R3d12zv); tests/test_s5_temporal.py"),
    "CAP-GRAPH": (("graph_check",), "scripts/graph_check.check/path; run and measured by tools/capability_run.py (R3d12zv); tests/test_s5_graph.py"),
    "CAP-RELATION": (("relation_guard",), "scripts/relation_guard.build_relations/graph_edges/check_graph/strength; run and measured by tools/capability_run.py (R3d12zv); tests/test_s5_relation.py"),
    "CAP-COUNTEREXAMPLE": (("counterexample_log",), "scripts/counterexample_log.record/resolve/lookup/audit/hit_rate; run and measured by tools/capability_run.py (R3d12zw); tests/test_s6_batch1.py; production caller (SYNTHESIS pre-accept check) still 0"),
    "CAP-HYPOTHESIS": (("hypothesis_guard",), "scripts/hypothesis_guard.check/submit/history; run and measured by tools/capability_run.py (R3d12zw); tests/test_s6_batch1.py; production caller (SYNTHESIS pre-accept check, Run.close) still 0"),
    "CAP-PATTERN": (("pattern_guard",), "scripts/pattern_guard.build_patterns; run and measured by tools/capability_run.py (R3d12zx); tests/test_s6_batch2.py; production caller (Run.step task_set) still 0"),
    "CAP-SYNTHESIS": (("synthesis_guard",), "scripts/synthesis_guard.check/submit; run and measured by tools/capability_run.py (R3d12zx); tests/test_s6_batch2.py; production caller (Run.close before final integration) still 0"),
    "CAP-SEARCH": (("research_request",), "scripts/research_request.request (request ledger + degradation, no search of its own); run and measured by tools/capability_run.py (R3d12zz); tests/test_s6_batch4.py; production caller (Brain gap triage) still 0"),
    "CAP-CLASSIFY": (("classify_guard",), "scripts/classify_guard.classify_items/mark_stale; run and measured by tools/capability_run.py (R3d12zu); tests/test_s4b_classify.py"),
    "CAP-STATISTICS": (("stats_summary",), "scripts/stats_summary.summarize/check_result; run and measured by tools/capability_run.py (R3d12zu); tests/test_s4b_statistics.py"),
    "CAP-INGEST": (("segment_ingest",), "scripts/segment_ingest.ingest/check_coverage; run and measured by tools/capability_run.py (R3d12zs); tests/test_s4a_ingest_extract.py"),
    "CAP-EXTRACT": (("extract_guard",), "scripts/extract_guard.extract_segment/run_extraction; run and measured by tools/capability_run.py (R3d12zs); tests/test_s4a_ingest_extract.py"),
    "CAP-VERIFY": (("verify_verdict",), "scripts/verify_verdict.verify; called by Run.close in scripts/p2_run.py (R3d12zq); tests/test_s3b_control.py; run and measured by tools/capability_run.py (R3d12zr)"),
    "CAP-GAP": (("gap_ledger",), "scripts/gap_ledger.apply_verdict/load/save; called by Run.close and session_driver.iterate (R3d12zq); tests/test_s3b_control.py; run and measured by tools/capability_run.py (R3d12zr)"),
    "CAP-ITERATE": (("iterate_control",), "scripts/iterate_control.decide/finish_round; called by session_driver.iterate (R3d12zq); tests/test_s3b_control.py; run and measured by tools/capability_run.py (R3d12zr)"),
}
# Capabilities with no tool (plan FR-11, decision B class, 2026-10-01). The 'period' item has no id of its own.
DECLARED_NO_TOOL = {"CAP-CLUSTER", "CAP-TREND", "CAP-ANOMALY"}
# Dynamic entry points the static scan cannot see: stem -> written source. Empty until someone documents one.
DECLARED_DYNAMIC: dict[str, str] = {}

ENTRY_GLOBS = (".github/workflows/*.yml", ".github/workflows/*.yaml", ".vscode/*.json", ".devcontainer/*.json", "tools/*.py")


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""


def _is_test(path: Path) -> bool:
    return "tests" in path.parts or path.name.startswith("test_")


def scan_imports(root: Path) -> tuple[dict[str, set[str]], dict[str, set[str]], set[str]]:
    """Return (importers, dynamic_refs, stems): importers[stem] = non-test files importing it."""
    scripts = root / CORE / "scripts"
    stems = {p.stem for p in scripts.glob("*.py")}
    importers: dict[str, set[str]] = {s: set() for s in stems}
    dynamic: dict[str, set[str]] = {s: set() for s in stems}
    for path in sorted(root.rglob("*.py")):
        if _is_test(path) or ".git" in path.parts:
            continue
        try:
            tree = ast.parse(_read(path))
        except SyntaxError:
            continue
        me = path.relative_to(root).as_posix()
        for node in ast.walk(tree):
            names: list[str] = []
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                base = node.module or ""
                names = [base] + [f"{base}.{a.name}" if base else a.name for a in node.names]
            elif isinstance(node, ast.Call) and node.args and isinstance(node.args[0], ast.Constant) \
                    and isinstance(node.args[0].value, str):
                fn = node.func
                fname = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
                if fname in {"import_module", "__import__"}:
                    leaf = node.args[0].value.split(".")[-1]
                    if leaf in stems and path.stem != leaf:
                        dynamic[leaf].add(me)
                continue
            for name in names:
                leaf = name.split(".")[-1]
                head = name.split(".")
                if leaf in stems and path.stem != leaf and (len(head) == 1 or head[-2] in {"scripts", ""} or head[0] == "scripts" or node.__class__ is ast.ImportFrom):
                    importers[leaf].add(me)
    return importers, dynamic, stems


def scan_entries(root: Path, stems: set[str]) -> dict[str, set[str]]:
    """Entry references: workflow / editor / devcontainer / tools files that name a script."""
    out: dict[str, set[str]] = {s: set() for s in stems}
    files: list[Path] = []
    for pattern in ENTRY_GLOBS:
        files += sorted(root.glob(pattern))
    for path in files:
        if path.name == Path(__file__).name:  # the audit's own declaration table is not an entry reference
            continue
        text = _read(path)
        me = path.relative_to(root).as_posix()
        for stem in stems:
            if re.search(rf"(?<![\w]){re.escape(stem)}(?:\.py)?(?![\w])", text) and path.stem != stem:
                out[stem].add(me)
    return out


def scan_literal_refs(root: Path, cap_ids: list[str]) -> tuple[dict[str, set[str]], dict[str, set[str]]]:
    """Literal capability-id mentions: (non-test py files = LOW consumer evidence, policy json files)."""
    py_refs = {c: set() for c in cap_ids}
    json_refs = {c: set() for c in cap_ids}
    core = root / CORE
    for path in sorted(core.rglob("*.py")):
        if _is_test(path):
            continue
        text = _read(path)
        for cap in cap_ids:
            if re.search(rf"{re.escape(cap)}(?![\w-])", text):
                py_refs[cap].add(path.relative_to(root).as_posix())
    skip = {"capability_registry.json", "function_capability_registry.json"}
    for path in sorted(core.glob("*.json")) + sorted((core / "policy").glob("*.json")) + sorted((core / "canonical").glob("*.json")):
        if path.name in skip:
            continue
        text = _read(path)
        for cap in cap_ids:
            if re.search(rf"{re.escape(cap)}(?![\w-])", text):
                json_refs[cap].add(path.relative_to(root).as_posix())
    return py_refs, json_refs


def read_baseline(root: Path) -> set[str]:
    path = root / "tools" / "baseline_failing_tests.txt"
    return {l.strip() for l in _read(path).splitlines() if l.strip() and not l.startswith("#")}


def audit(root: Path) -> dict:
    registry = json.loads(_read(root / CORE / "capability_registry.json"))
    caps = registry["capabilities"]
    cap_ids = [c["capability_id"] for c in caps]
    level_names = registry.get("capability_levels", {})
    binding = {}
    try:
        binding = json.loads(_read(root / CORE / "policy" / "role_capability_binding.v1.0.json")).get("roles", {})
    except json.JSONDecodeError:
        pass
    importers, dynamic, stems = scan_imports(root)
    entries = scan_entries(root, stems)
    py_refs, json_refs = scan_literal_refs(root, cap_ids)
    baseline = read_baseline(root)
    tests_dir = root / CORE / "tests"
    rows = []
    for cap in caps:
        cid = cap["capability_id"]
        modes = [level_names.get(str(l), str(l)) for l in cap.get("levels", [])]
        roles = sorted(r for r, lst in binding.items() if cid in lst)
        declared = DECLARED_PROVIDERS.get(cid)
        row = {"capability": cid, "declared_implementation": cap.get("implementation"),
               "usable_modes": {"levels": modes, "roles": roles or UNKNOWN}}
        if cid in DECLARED_NO_TOOL and not declared:
            row.update(provider=NO_TOOL, consumer=NO_TOOL, success_condition=NO_TOOL, failure_feedback=NO_TOOL,
                       derived=NO_TOOL, grade="NONE")
        elif declared:
            provider_stems, source = declared
            prov = [s for s in provider_stems if s in stems]
            imp = sorted(set().union(*(importers[s] for s in prov))) if prov else []
            ent = sorted(set().union(*(entries[s] for s in prov))) if prov else []
            dyn_set = set().union(*(dynamic[s] for s in prov)) if prov else set()
            dyn = sorted(dyn_set | {s for s in prov if s in DECLARED_DYNAMIC})
            tests = [f"test_{s}" for s in prov if (tests_dir / f"test_{s}.py").exists()]
            if prov and imp and ent:
                derived, grade = "WIRED", "HIGH"
            elif prov and (imp or ent or dyn):
                derived, grade = "PARTIAL", "LOW"
            else:
                derived, grade = (UNKNOWN, "NONE") if prov else ("UNWIRED_PROVIDER", "NONE")
            row.update(
                provider={"modules": [f"{s}.py" for s in prov] or UNKNOWN, "source": source},
                consumer={"imports": imp, "entries": ent, "dynamic": dyn} if (imp or ent or dyn) else UNKNOWN,
                success_condition=({"tests": tests, "baseline_failing": [t for t in tests if t in baseline],
                                    "executed_by_audit": False} if tests else UNKNOWN),
                failure_feedback=UNKNOWN, derived=derived, grade=grade)
        else:
            lows = sorted(py_refs[cid])
            row.update(provider=UNKNOWN, success_condition=UNKNOWN, failure_feedback=UNKNOWN,
                       consumer={"string_refs": lows} if lows else UNKNOWN,
                       derived="PARTIAL" if lows else UNKNOWN, grade="LOW" if lows else "NONE")
            row["derived"] = UNKNOWN  # a string mention without a provider is not wiring
        row["policy_refs"] = sorted(json_refs[cid])
        row["maturity"] = "WIRED" if row["derived"] == "WIRED" else NO_TOOL_MATURITY if row["derived"] == NO_TOOL else "UNWIRED"
        row["declared_no_tool_ok"] = row["derived"] == NO_TOOL
        rows.append(row)
    counts: dict[str, int] = {}
    for r in rows:
        counts[r["derived"]] = counts.get(r["derived"], 0) + 1
    maturity_counts: dict[str, int] = {}
    for r in rows:
        maturity_counts[r["maturity"]] = maturity_counts.get(r["maturity"], 0) + 1
    return {"capabilities": rows, "counts": counts, "maturity_counts": maturity_counts,
            "unwired": [r["capability"] for r in rows if r["maturity"] == "UNWIRED"],
            "evidence_level": "PROGRAM_EXECUTED_PASS"}


def selftest() -> int:
    """Fixture run on a temp tree: WIRED, PARTIAL, UNKNOWN and NO_TOOL must all be produced."""
    global DECLARED_PROVIDERS, DECLARED_NO_TOOL
    saved = (DECLARED_PROVIDERS, DECLARED_NO_TOOL)
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / CORE / "scripts").mkdir(parents=True)
        (root / CORE / "tests").mkdir()
        (root / CORE / "policy").mkdir()
        (root / ".github" / "workflows").mkdir(parents=True)
        (root / "tools").mkdir()
        caps = [{"capability_id": c, "implementation": "CANONICAL", "levels": [0], "kind": "TOOL"}
                for c in ("CAP-A", "CAP-B", "CAP-C", "CAP-D")]
        (root / CORE / "capability_registry.json").write_text(json.dumps({"capability_levels": {"0": "QUICK"}, "capabilities": caps}))
        (root / CORE / "scripts" / "prov_a.py").write_text("def f():\n    return 1\n")
        (root / CORE / "scripts" / "prov_b.py").write_text("X = 1\n")
        (root / CORE / "scripts" / "user.py").write_text("import prov_a\nfrom prov_b import X\n")
        (root / CORE / "tests" / "test_prov_a.py").write_text("import prov_a\n")
        (root / ".github" / "workflows" / "w.yml").write_text("run: python scripts/prov_a.py\n")
        (root / "tools" / "baseline_failing_tests.txt").write_text("# x\n")
        DECLARED_PROVIDERS = {"CAP-A": (("prov_a",), "fixture"), "CAP-B": (("prov_b",), "fixture")}
        DECLARED_NO_TOOL = {"CAP-D"}
        try:
            rep = audit(root)
        finally:
            DECLARED_PROVIDERS, DECLARED_NO_TOOL = saved
    by = {r["capability"]: r for r in rep["capabilities"]}
    checks = {
        "A wired": by["CAP-A"]["derived"] == "WIRED" and by["CAP-A"]["grade"] == "HIGH",
        "A test pointer, not executed": by["CAP-A"]["success_condition"]["executed_by_audit"] is False,
        "B partial (import only)": by["CAP-B"]["derived"] == "PARTIAL",
        "C unknown, not guessed": by["CAP-C"]["derived"] == UNKNOWN and by["CAP-C"]["provider"] == UNKNOWN,
        "D no tool": by["CAP-D"]["derived"] == NO_TOOL and by["CAP-D"]["maturity"] == NO_TOOL_MATURITY,
        "maturity A=WIRED, B/C=UNWIRED": (by["CAP-A"]["maturity"], by["CAP-B"]["maturity"], by["CAP-C"]["maturity"]) == ("WIRED", "UNWIRED", "UNWIRED"),
        "unwired = B, C": rep["unwired"] == ["CAP-B", "CAP-C"],
        "no OVERCLAIM verdict left": all("overclaim" not in r for r in rep["capabilities"]) and "overclaims" not in rep,
    }
    for name, ok in checks.items():
        print(f"{'ok  ' if ok else 'FAIL'} {name}")
    return 0 if all(checks.values()) else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--root", default=str(Path(__file__).resolve().parent.parent))
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--strict", action="store_true")
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        return selftest()
    rep = audit(Path(args.root))
    if args.json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        for r in rep["capabilities"]:
            prov = r["provider"] if isinstance(r["provider"], str) else ",".join(r["provider"]["modules"]) if isinstance(r["provider"]["modules"], list) else UNKNOWN
            print(f"{r['capability']:<24}{r['derived']:<18}{r['grade']:<5}provider={prov}  maturity={r['maturity']}  declared={r['declared_implementation']}")
        print(f"counts={rep['counts']}  maturity={rep['maturity_counts']}  unwired={len(rep['unwired'])}")
    return 1 if args.strict and rep["unwired"] else 0


if __name__ == "__main__":
    sys.exit(main())
