#!/usr/bin/env python3
"""P2 wiring_chain_audit — the four runtime wiring chains of OPEN-ISSUES 020c as a derived status (stdlib only; R3d10 R3g).

Data: P1-Central-Control/policy/wiring_chains.v1.0.json (links are module names under scripts/).
Derived status per chain (never declared by hand)
  MISSING_LINK   a listed module file does not exist
  BROKEN         every file exists but neither of link[i], link[i+1] imports the other and the chain's optional
                 `orchestrator` module does not import both (first break is reported)
  WIRED_STATIC   every adjacent pair is connected by an import (structure only; says nothing about execution)
  WIRED_EXECUTED WIRED_STATIC and an executed record exists: <evidence_dir>/<chain_id>.json with exit_code 0 and
                 every link named in `links_exercised`
Ratchet: tools/baseline_wiring.json  {"broken_chains_max": N, "unwired_capabilities_max": M}; counts may only go down.
Usage: python3 tools/wiring_chain_audit.py [--selftest] [--json]      exit 1 when a ratchet is exceeded
"""
from __future__ import annotations

import ast
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = "P1-Central-Control/scripts"
POLICY = "P1-Central-Control/policy/wiring_chains.v1.0.json"
EVIDENCE_DIR = "P1-Central-Control/evidence/wiring-chains"
BASELINE = "tools/baseline_wiring.json"


def imports_of(source: str) -> set[str]:
    out: set[str] = set()
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return out
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            out.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            out.add(node.module.split(".")[0])
            out.update(a.name for a in node.names)
    return out


def chain_status(chain: dict, read_module, run_record) -> dict:
    links = chain["links"]
    sources = {m: read_module(m) for m in links}
    missing = [m for m, s in sources.items() if s is None]
    if missing:
        return {"chain_id": chain["chain_id"], "status": "MISSING_LINK", "at": missing[0]}
    orch = chain.get("orchestrator")
    orch_src = read_module(orch) if orch else None
    orch_imp = imports_of(orch_src) if orch_src else set()
    for a, b in zip(links, links[1:]):
        bridged = a in orch_imp and b in orch_imp  # orchestrator imports both ends (R3d12w; needs an executed record to count)
        if b not in imports_of(sources[a]) and a not in imports_of(sources[b]) and not bridged:
            return {"chain_id": chain["chain_id"], "status": "BROKEN", "at": f"{a} -/-> {b}"}
    rec = run_record(chain["chain_id"])
    if rec and rec.get("exit_code") == 0 and set(links) <= set(rec.get("links_exercised", [])):
        return {"chain_id": chain["chain_id"], "status": "WIRED_EXECUTED"}
    return {"chain_id": chain["chain_id"], "status": "WIRED_STATIC"}


def audit(root: Path = ROOT) -> dict:
    policy = json.loads((root / POLICY).read_text(encoding="utf-8"))

    def read_module(name: str):
        p = root / SCRIPTS / f"{name}.py"
        return p.read_text(encoding="utf-8") if p.exists() else None

    def run_record(chain_id: str):
        p = root / EVIDENCE_DIR / f"{chain_id}.json"
        try:
            return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
        except (OSError, ValueError):
            return None

    chains = [chain_status(c, read_module, run_record) for c in policy["chains"]]
    broken = [c for c in chains if c["status"] in ("BROKEN", "MISSING_LINK")]
    unwired = None
    try:
        sys.path.insert(0, str(root / "tools"))
        import wiring_audit

        unwired = len(wiring_audit.audit(root)["unwired"])
    except Exception:  # noqa: BLE001 - the capability count is optional input to the ratchet
        unwired = None
    base = json.loads((root / BASELINE).read_text(encoding="utf-8")) if (root / BASELINE).exists() else {}
    findings = ratchet_findings(len(broken), unwired, base)
    return {"chains": chains, "broken": len(broken), "unwired_capabilities": unwired, "baseline": base, "findings": findings}


def ratchet_findings(broken: int, unwired: int | None, base: dict) -> list[dict]:
    f = []
    if "broken_chains_max" in base and broken > base["broken_chains_max"]:
        f.append({"error": "broken chains increased", "now": broken, "max": base["broken_chains_max"]})
    if unwired is not None and "unwired_capabilities_max" in base and unwired > base["unwired_capabilities_max"]:
        f.append({"error": "UNWIRED capabilities increased", "now": unwired, "max": base["unwired_capabilities_max"]})
    return f


def selftest() -> int:
    mods = {"a": "import b\n", "b": "from c import f\n", "c": "x = 1\n", "d": "import a\n"}
    rd = lambda m: mods.get(m)  # noqa: E731
    none = lambda cid: None  # noqa: E731
    cases = {
        "static": chain_status({"chain_id": "X", "links": ["a", "b", "c"]}, rd, none)["status"] == "WIRED_STATIC",
        "broken": chain_status({"chain_id": "X", "links": ["a", "d"]}, lambda m: {"a": "x=1\n", "d": "y=2\n"}.get(m), none)["status"] == "BROKEN",
        "reverse_import": chain_status({"chain_id": "X", "links": ["c", "b"]}, rd, none)["status"] == "WIRED_STATIC",
        "missing": chain_status({"chain_id": "X", "links": ["a", "zz"]}, rd, none)["status"] == "MISSING_LINK",
        "executed": chain_status({"chain_id": "X", "links": ["a", "b"]}, rd, lambda c: {"exit_code": 0, "links_exercised": ["a", "b"]})["status"] == "WIRED_EXECUTED",
        "exit1": chain_status({"chain_id": "X", "links": ["a", "b"]}, rd, lambda c: {"exit_code": 1, "links_exercised": ["a", "b"]})["status"] == "WIRED_STATIC",
        "partial": chain_status({"chain_id": "X", "links": ["a", "b"]}, rd, lambda c: {"exit_code": 0, "links_exercised": ["a"]})["status"] == "WIRED_STATIC",
        "orch_bridge": chain_status({"chain_id": "X", "links": ["a", "d2"], "orchestrator": "o"}, lambda m: {"a": "x=1\n", "d2": "y=2\n", "o": "import a, d2\n"}.get(m), none)["status"] == "WIRED_STATIC",
        "orch_one_end_only": chain_status({"chain_id": "X", "links": ["a", "d2"], "orchestrator": "o"}, lambda m: {"a": "x=1\n", "d2": "y=2\n", "o": "import a\n"}.get(m), none)["status"] == "BROKEN",
        "ratchet_up": bool(ratchet_findings(3, 19, {"broken_chains_max": 2, "unwired_capabilities_max": 19})),
        "ratchet_unwired": bool(ratchet_findings(0, 20, {"unwired_capabilities_max": 19})),
        "ratchet_ok": ratchet_findings(1, 18, {"broken_chains_max": 2, "unwired_capabilities_max": 19}) == [],
    }
    bad = [k for k, v in cases.items() if not v]
    print("wiring_chain_audit selftest", "PASS" if not bad else f"FAIL {bad}", f"({len(cases)} cases)")
    return 0 if not bad else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    res = audit()
    if "--json" in sys.argv:
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        for c in res["chains"]:
            print(c)
        print("broken", res["broken"], "unwired_capabilities", res["unwired_capabilities"], "baseline", res["baseline"])
        for x in res["findings"]:
            print("FINDING", x)
    sys.exit(1 if res["findings"] else 0)
