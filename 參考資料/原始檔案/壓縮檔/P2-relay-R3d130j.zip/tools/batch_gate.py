#!/usr/bin/env python3
"""P2 batch_gate — D19 acceptance as code: a batch or task is DONE only when the machine says so (stdlib only; R3d10 R3g).

Registry: P1-Central-Control/policy/batch_acceptance.v1.0.json   Evidence: P1-Central-Control/evidence/batch/<task_id>.json
Tiers (D19)
  tier 1  fast-check batches         DONE task = executed evidence (exit_code 0, entry file unchanged) or `doc_only` with a reason.
  tier 2  batches R4, R4L, R4R, R5   DONE task = running code: `entrypoint` exists, `evidence_file` names the record, evidence exit_code 0, entry sha256 matches the file on disk.
                                     `doc_only` is rejected.
  tier 3  batches R6, R7, R8         DONE task = tier-2 DONE evidence PLUS (a) `closure_ref` -> a DONE batch with closes_loop,
                                     (b) `distilled` {fast_path_id, function "module:func" that exists under scripts/, equivalence_rate 1.0,
                                     replay_evidence_ref} so code execution replaces semantic operation, or a counted `distill_waiver`
                                     {reason} for a step with no mechanical flow.
Batch rules
  B1  batch DONE only if every M task is DONE and every S/C task is DONE or SKIPPED with `skip_reason`.
  B2  batch IN_PROGRESS/DONE only if each `depends_on` batch is DONE and each `requires_tasks` task is DONE.
  B3  a task cannot be DONE inside a NOT_STARTED batch.
  B4  `min_fast_paths` (R6: 3) counts distinct distilled fast paths among DONE tasks of a DONE batch.
Commands
  python3 tools/batch_gate.py                  check the registry (precheck HARD)
  python3 tools/batch_gate.py --run            also re-run every DONE task's entry command, exit_code must be 0
  python3 tools/batch_gate.py record <task_id> --entry <path> --command "<cmd>" [--executor CHAT|ACTIONS|CODEX]    run <cmd>, write the evidence record
Executor (XM1, policy/executor_mode.v1.0.json): evidence carries `executor` (missing = legacy = baseline CHAT); the value must be allowed;
  a task may not set `requires_executor` to anything but the baseline (DONE must be reachable on CHAT alone).
  python3 tools/batch_gate.py --selftest
"""
from __future__ import annotations

import ast
import hashlib
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REGISTRY = "P1-Central-Control/policy/batch_acceptance.v1.0.json"
EVIDENCE = "P1-Central-Control/evidence/batch"
EXEC_POLICY = "P1-Central-Control/policy/executor_mode.v1.0.json"
SCRIPTS = "P1-Central-Control/scripts"
BASELINE_CALLERS = "tools/baseline_callers.json"
CALLER_AUDIT = "tools/caller_audit.py"
STATUS = ("NOT_STARTED", "IN_PROGRESS", "DONE", "PARTIAL", "BLOCKED", "SKIPPED")


def sha_of(path: Path) -> str:
    return "sha256:" + hashlib.sha256(path.read_bytes()).hexdigest()


def check(reg: dict, fs, report: dict | None = None) -> list[dict]:
    """fs: object with exists(rel), read_json(rel), sha(rel), has_function(module, func)."""
    f: list[dict] = []
    batches = {b["batch_id"]: b for b in reg.get("batches", [])}
    tasks = {t["task_id"]: (b, t) for b in batches.values() for t in b.get("tasks", [])}
    if len(tasks) != sum(len(b.get("tasks", [])) for b in batches.values()):
        f.append({"rule": "REG", "error": "duplicate task_id"})
    for b in batches.values():
        if b.get("status") not in STATUS or b.get("tier") not in (1, 2, 3):
            f.append({"rule": "REG", "error": "bad batch status or tier", "batch": b["batch_id"]})
        for d in b.get("depends_on", []):
            if d not in batches:
                f.append({"rule": "REG", "error": "unknown depends_on", "batch": b["batch_id"], "dep": d})
        for r in b.get("requires_tasks", []):
            if r not in tasks:
                f.append({"rule": "REG", "error": "unknown requires_tasks", "batch": b["batch_id"], "task": r})
    for b in batches.values():
        bid, st = b["batch_id"], b.get("status")
        for t in b.get("tasks", []):
            if t.get("status") not in STATUS:
                f.append({"rule": "REG", "error": "bad task status", "task": t["task_id"]})
            elif t["status"] == "DONE":
                if st == "NOT_STARTED":
                    f.append({"rule": "B3", "error": "task DONE in NOT_STARTED batch", "task": t["task_id"]})
                f += task_findings(b, t, batches, fs)
        if st in ("IN_PROGRESS", "DONE"):
            for d in b.get("depends_on", []):
                if d in batches and batches[d].get("status") != "DONE":
                    f.append({"rule": "B2", "error": "dependency batch not DONE", "batch": bid, "dep": d})
            for r in b.get("requires_tasks", []):
                if r in tasks and tasks[r][1].get("status") != "DONE":
                    f.append({"rule": "B2", "error": "required task not DONE", "batch": bid, "task": r})
        if st == "DONE":
            for t in b.get("tasks", []):
                ok = t.get("status") == "DONE" or (t.get("level") in ("S", "C") and t.get("status") == "SKIPPED" and t.get("skip_reason"))
                if not ok:
                    f.append({"rule": "B1", "error": "batch DONE with unfinished task", "batch": bid, "task": t["task_id"], "level": t.get("level"), "status": t.get("status")})
            need = b.get("min_fast_paths", 0)
            if need:
                paths = {t["distilled"]["fast_path_id"] for t in b.get("tasks", []) if t.get("status") == "DONE" and t.get("distilled")}
                if len(paths) < need:
                    f.append({"rule": "B4", "error": "too few distilled fast paths", "batch": bid, "have": len(paths), "need": need})
    if hasattr(fs, "caller_audit"):
        f += t4_findings(reg, fs, report)
    return f


def executor_findings(rec: dict, t: dict, fs) -> list[dict]:
    """XM1: evidence `executor` must be an allowed value; DONE may never require a non-baseline executor."""
    if not fs.exists(EXEC_POLICY):
        return []
    pol, f = fs.read_json(EXEC_POLICY), []
    if rec.get("executor", pol["baseline"]) not in pol["allowed"]:
        f.append({"rule": "X1", "error": "evidence executor is not an allowed value", "task": t["task_id"], "executor": rec.get("executor")})
    if t.get("requires_executor") not in (None, pol["baseline"]):
        f.append({"rule": "X2", "error": "DONE must not require a non-baseline executor (baseline runs on CHAT alone)", "task": t["task_id"]})
    return f


def executor_policy_findings(fs) -> list[dict]:
    if not fs.exists(EXEC_POLICY):
        return [{"rule": "X0", "error": "executor policy file missing"}]
    pol = fs.read_json(EXEC_POLICY)
    ok = (pol.get("baseline") == "CHAT" and "CHAT" in pol.get("allowed", []) and pol.get("mode") in pol.get("allowed", [])
          and len(set(pol.get("allowed", []))) == len(pol.get("allowed", [])))
    return [] if ok else [{"rule": "X0", "error": "executor policy invalid: baseline must be CHAT, mode and CHAT must be in allowed"}]


def task_findings(b: dict, t: dict, batches: dict, fs) -> list[dict]:
    f, tid, tier = [], t["task_id"], b["tier"]
    if t.get("doc_only"):
        if tier != 1 or not t.get("doc_only_reason"):
            f.append({"rule": "T1", "error": "doc_only allowed only in tier 1 with a reason", "task": tid})
        return f
    ep = t.get("entrypoint")
    if not ep or not fs.exists(ep.get("path", "")) or not ep.get("command"):
        f.append({"rule": "T2", "error": "DONE needs an existing entrypoint path and command", "task": tid})
        return f
    rec_path = f"{EVIDENCE}/{tid}.json"
    if t.get("evidence_file") != f"{tid}.json":
        f.append({"rule": "T2", "error": "evidence_file must name the record (run `record`)", "task": tid})
    if not fs.exists(rec_path):
        f.append({"rule": "T2", "error": "no evidence record", "task": tid})
    else:
        rec = fs.read_json(rec_path)
        if rec.get("exit_code") != 0:
            f.append({"rule": "T2", "error": "evidence exit_code is not 0", "task": tid})
        if rec.get("entry_path") != ep["path"] or rec.get("entry_sha256") != fs.sha(ep["path"]):
            f.append({"rule": "T2", "error": "evidence is stale: entry changed since the recorded run", "task": tid})
        f += executor_findings(rec, t, fs)
    if tier == 3:
        cr = t.get("closure_ref")
        if not cr or cr not in batches or not batches[cr].get("closes_loop") or batches[cr].get("status") != "DONE":
            f.append({"rule": "T3", "error": "closure_ref must name a DONE batch with closes_loop", "task": tid})
        d, w = t.get("distilled"), t.get("distill_waiver")
        if d:
            mod, _, func = d.get("function", "").partition(":")
            if not mod or not func or not fs.has_function(mod, func):
                f.append({"rule": "T3", "error": "distilled function does not exist", "task": tid})
            if d.get("equivalence_rate") != 1.0:
                f.append({"rule": "T3", "error": "equivalence_rate must be 1.0 (mismatches go back to the semantic path)", "task": tid})
            if not d.get("fast_path_id") or not fs.exists(d.get("replay_evidence_ref", "")):
                f.append({"rule": "T3", "error": "fast_path_id and an existing replay_evidence_ref required", "task": tid})
        elif not (w and w.get("reason")):
            f.append({"rule": "T3", "error": "tier 3 DONE needs `distilled` or a `distill_waiver` with a reason", "task": tid})
    return f


def t4_findings(reg: dict, fs, report: dict | None = None) -> list[dict]:
    """T4: every DONE tier-3 `distilled` function needs a PRODUCTION caller (caller_audit run live), minus counted waivers.

    Waivers live in BASELINE_CALLERS {"waivers": [{"function", "reason"}], "waivers_max": N}; the list may only shrink.
    A crashed, timed-out or INCOMPLETE audit fails T4 (never passes); an interrupt (BaseException) propagates and writes nothing.
    """
    specs = sorted({t["distilled"]["function"] for b in reg.get("batches", []) if b.get("tier") == 3
                    for t in b.get("tasks", []) if t.get("status") == "DONE" and t.get("distilled")
                    and t["distilled"].get("kind", "distilled") == "distilled"})
    base = fs.read_json(BASELINE_CALLERS) if fs.exists(BASELINE_CALLERS) else {}
    waivers = {w.get("function"): w.get("reason") for w in base.get("waivers", [])}
    f: list[dict] = []
    if len(base.get("waivers", [])) > base.get("waivers_max", 0):
        f.append({"rule": "T4", "error": "baseline waivers grew beyond waivers_max (ratchet: may only shrink)"})
    for fn, why in waivers.items():
        if not why:
            f.append({"rule": "T4", "error": "waiver needs a reason", "function": fn})
    try:
        res = fs.caller_audit(specs)
    except Exception as e:
        f.append({"rule": "T4", "error": f"caller_audit failed: {type(e).__name__}: {e}"})
        return f
    if res.get("status") != "COMPLETE":
        f.append({"rule": "T4", "error": "caller_audit INCOMPLETE (unparsed files)", "unparsed": res.get("unparsed", [])})
    got = {f"{r['module']}:{r['function']}": r["classification"] for r in res.get("results", [])}
    waived = []
    for s in specs:
        c = got.get(s, "MISSING")
        if c == "PRODUCTION":
            if s in waivers:
                f.append({"rule": "T4", "error": "stale waiver: function now has a production caller; remove it and lower waivers_max", "function": s})
        elif waivers.get(s):
            waived.append({"function": s, "classification": c, "reason": waivers[s]})
        else:
            f.append({"rule": "T4", "error": f"distilled function has no production caller ({c})", "function": s})
    if report is not None:
        report["t4_waived"] = waived
    return f


class RealFS:
    def __init__(self, root: Path):
        self.root = root

    def exists(self, rel: str) -> bool:
        return bool(rel) and (self.root / rel).exists()

    def read_json(self, rel: str) -> dict:
        return json.loads((self.root / rel).read_text(encoding="utf-8"))

    def sha(self, rel: str) -> str:
        return sha_of(self.root / rel)

    def has_function(self, module: str, func: str) -> bool:
        p = self.root / SCRIPTS / f"{module}.py"
        if not p.exists():
            return False
        try:
            return any(isinstance(n, (ast.FunctionDef, ast.ClassDef)) and n.name == func for n in ast.walk(ast.parse(p.read_text(encoding="utf-8"))))
        except SyntaxError:
            return False

    def caller_audit(self, specs):
        """Run tools/caller_audit.py live (never a cached file); crash, timeout or bad output raises -> T4 fails."""
        if not specs:
            return {"status": "COMPLETE", "unparsed": [], "results": []}
        cmd = [sys.executable, str(self.root / CALLER_AUDIT), "--root", str(self.root), "--functions", *specs]
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if p.returncode not in (0, 1):
            raise RuntimeError(f"caller_audit exit {p.returncode}: {p.stderr.strip()[:200]}")
        return json.loads(p.stdout)


def record(root: Path, task_id: str, entry: str, command: str, executor: str = "CHAT") -> int:
    pol_path = root / EXEC_POLICY
    if pol_path.exists() and executor not in json.loads(pol_path.read_text(encoding="utf-8"))["allowed"]:
        print(f"refused: executor {executor} is not allowed")
        return 2
    proc = subprocess.run(command, shell=True, cwd=root, capture_output=True, text=True, timeout=600)
    rec = {"task_id": task_id, "command": command, "exit_code": proc.returncode, "entry_path": entry,
           "entry_sha256": sha_of(root / entry), "python": sys.version.split()[0], "executor": executor,
           "stdout_tail": proc.stdout[-300:]}
    out = root / EVIDENCE / f"{task_id}.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(rec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"recorded {task_id}: exit_code={proc.returncode}")
    return 0 if proc.returncode == 0 else 1


def rerun(reg: dict, root: Path) -> list[dict]:
    f, seen = [], {}
    for b in reg["batches"]:
        for t in b.get("tasks", []):
            if t.get("status") == "DONE" and t.get("entrypoint"):
                cmd = t["entrypoint"]["command"]
                if cmd not in seen:  # tasks sharing one command run it once
                    seen[cmd] = subprocess.run(cmd, shell=True, cwd=root, capture_output=True, text=True, timeout=600).returncode
                if seen[cmd] != 0:
                    f.append({"rule": "RUN", "error": "re-run failed", "task": t["task_id"], "exit_code": seen[cmd]})
    return f


def stale_groups(reg: dict, root: Path) -> dict:
    g: dict = {}
    for b in reg["batches"]:
        for t in b.get("tasks", []):
            ep = t.get("entrypoint")
            if t.get("status") != "DONE" or not ep:
                continue
            ev = root / EVIDENCE / t.get("evidence_file", f"{t['task_id']}.json")
            try:
                rec = json.loads(ev.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                rec = {}
            if rec.get("entry_path") != ep["path"] or rec.get("entry_sha256") != sha_of(root / ep["path"]) or rec.get("exit_code") != 0:
                g.setdefault((ep["path"], ep["command"]), []).append((t["task_id"], ev))
    return g


def rerecord(root: Path, reg: dict, executor: str = "CHAT") -> int:
    pol_path = root / EXEC_POLICY
    if pol_path.exists() and executor not in json.loads(pol_path.read_text(encoding="utf-8"))["allowed"]:
        print(f"refused: executor {executor} is not allowed")
        return 2
    groups, n, bad = stale_groups(reg, root), 0, 0
    for (entry, cmd), tasks in groups.items():  # one run per (entry, command), evidence written for every task
        sha = sha_of(root / entry)

        def put(rc, tail):
            for tid, ev in tasks:
                rec = {"task_id": tid, "command": cmd, "exit_code": rc, "entry_path": entry, "entry_sha256": sha,
                       "python": sys.version.split()[0], "executor": executor, "stdout_tail": tail}
                ev.parent.mkdir(parents=True, exist_ok=True)
                ev.write_text(json.dumps(rec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        put(0, "provisional: command running")  # a command such as precheck reads this evidence itself; final record always replaces it
        rc, tail = -1, "interrupted"
        try:
            proc = subprocess.run(cmd, shell=True, cwd=root, capture_output=True, text=True, timeout=600)
            rc, tail = proc.returncode, proc.stdout[-300:]
        finally:
            put(rc, tail)
        n += len(tasks)
        bad += rc != 0
    print(f"rerecorded {n} stale tasks from {len(groups)} runs, failing runs {bad}")
    return 1 if bad else 0


class FakeFS:
    def __init__(self, files: dict):
        self.files = files

    def exists(self, rel):
        return rel in self.files

    def read_json(self, rel):
        return self.files[rel]

    def sha(self, rel):
        return self.files[rel] if isinstance(self.files[rel], str) else "sha-x"

    def has_function(self, module, func):
        return (module, func) in self.files.get("__functions__", set())

    def caller_audit(self, specs):
        if self.files.get("__ca_raise__"):
            raise self.files["__ca_raise__"]
        cl = self.files.get("__ca_class__", "PRODUCTION")
        return {"status": self.files.get("__ca_status__", "COMPLETE"), "unparsed": [],
                "results": [{"module": s.partition(":")[0], "function": s.partition(":")[2], "classification": cl, "callers": []} for s in specs]}


def selftest() -> int:
    import copy

    def reg():
        return {"batches": [
            {"batch_id": "R1", "tier": 1, "status": "DONE", "tasks": [{"task_id": "T1", "level": "M", "status": "DONE", "doc_only": True, "doc_only_reason": "plan text"}]},
            {"batch_id": "R5", "tier": 2, "status": "DONE", "closes_loop": True, "depends_on": ["R1"], "tasks": [
                {"task_id": "T5", "level": "M", "status": "DONE", "evidence_file": "T5.json", "entrypoint": {"path": "s/p2_run.py", "command": "python3 s/p2_run.py"}}]},
            {"batch_id": "R6", "tier": 3, "status": "DONE", "depends_on": ["R5"], "min_fast_paths": 1, "tasks": [
                {"task_id": "T6", "level": "M", "status": "DONE", "evidence_file": "T6.json", "entrypoint": {"path": "s/pd.py", "command": "python3 s/pd.py"}, "closure_ref": "R5",
                 "distilled": {"fast_path_id": "FP1", "function": "m:f", "equivalence_rate": 1.0, "replay_evidence_ref": "e/replay.json"}}]}]}

    def fs(**over):
        files = {"s/p2_run.py": "A", "s/pd.py": "B", "e/replay.json": {}, "__functions__": {("m", "f")},
                 f"{EVIDENCE}/T5.json": {"exit_code": 0, "entry_path": "s/p2_run.py", "entry_sha256": "A"},
                 f"{EVIDENCE}/T6.json": {"exit_code": 0, "entry_path": "s/pd.py", "entry_sha256": "B"}}
        files.update(over)
        return FakeFS(files)

    XPOL = {"mode": "CHAT", "allowed": ["CHAT", "ACTIONS", "CODEX"], "baseline": "CHAT"}

    def xfs(executor=None):
        base = fs().files
        rec = dict(base[f"{EVIDENCE}/T5.json"])
        if executor:
            rec["executor"] = executor
        return FakeFS({**base, EXEC_POLICY: XPOL, f"{EVIDENCE}/T5.json": rec})

    def run(mut=None, fsx=None):
        r = reg()
        if mut:
            mut(r)
        return check(r, fsx or fs())

    def rule(found, name):
        return any(x["rule"] == name for x in found)

    def task(r, tid):
        return next(t for b in r["batches"] for t in b["tasks"] if t["task_id"] == tid)

    B1 = {"waivers": [{"function": "m:f", "reason": "wiring planned"}], "waivers_max": 1}

    def t4_interrupt():
        x = fs(__ca_raise__=KeyboardInterrupt())
        before = dict(x.files)
        try:
            run(fsx=x)
        except KeyboardInterrupt:
            return x.files == before
        return False

    cases = {
        "good": run() == [],
        "tier2_doc_only": rule(run(lambda r: task(r, "T5").update(doc_only=True, doc_only_reason="x")), "T1"),
        "no_evidence_file": rule(run(lambda r: task(r, "T5").pop("evidence_file")), "T2"),
        "no_entrypoint": rule(run(lambda r: task(r, "T5").pop("entrypoint")), "T2"),
        "no_evidence": rule(run(fsx=fs(**{f"{EVIDENCE}/T5.json": None}) if False else FakeFS({k: v for k, v in fs().files.items() if k != f"{EVIDENCE}/T5.json"})), "T2"),
        "exit1": rule(run(fsx=fs(**{f"{EVIDENCE}/T5.json": {"exit_code": 1, "entry_path": "s/p2_run.py", "entry_sha256": "A"}})), "T2"),
        "stale": rule(run(fsx=fs(**{"s/p2_run.py": "CHANGED"})), "T2"),
        "no_closure": rule(run(lambda r: task(r, "T6").pop("closure_ref")), "T3"),
        "closure_not_done": rule(run(lambda r: r["batches"][1].update(status="IN_PROGRESS")), "T3"),
        "no_distill": rule(run(lambda r: task(r, "T6").pop("distilled")), "T3"),
        "waiver_ok": not rule(run(lambda r: (task(r, "T6").pop("distilled"), task(r, "T6").update(distill_waiver={"reason": "no mechanical flow"}), r["batches"][2].pop("min_fast_paths"))), "T3"),
        "fn_missing": rule(run(fsx=fs(**{"__functions__": set()})), "T3"),
        "equiv": rule(run(lambda r: task(r, "T6")["distilled"].update(equivalence_rate=0.9)), "T3"),
        "too_few_paths": rule(run(lambda r: r["batches"][2].update(min_fast_paths=2)), "B4"),
        "unfinished_M": rule(run(lambda r: task(r, "T6").update(status="PARTIAL")), "B1"),
        "skip_M": rule(run(lambda r: task(r, "T6").update(status="SKIPPED", skip_reason="x")), "B1"),
        "dep_not_done": rule(run(lambda r: r["batches"][0].update(status="IN_PROGRESS")), "B2"),
        "task_in_unstarted": rule(run(lambda r: r["batches"][2].update(status="NOT_STARTED")), "B3"),
        "x_good_chat": run(fsx=xfs(executor="CHAT")) == [],
        "x_legacy_no_field": run(fsx=xfs()) == [],
        "x_actions_ok": run(fsx=xfs(executor="ACTIONS")) == [],
        "x_unknown_executor": rule(run(fsx=xfs(executor="GPT")), "X1"),
        "x_requires_codex": rule(run(lambda r: task(r, "T5").update(requires_executor="CODEX"), fsx=xfs()), "X2"),
        "x_requires_chat_ok": not rule(run(lambda r: task(r, "T5").update(requires_executor="CHAT"), fsx=xfs()), "X2"),
        "x_policy_missing": rule(executor_policy_findings(fs()), "X0"),
        "x_baseline_not_chat": bool(executor_policy_findings(FakeFS({EXEC_POLICY: {**XPOL, "baseline": "CODEX"}}))),
        "x_mode_not_allowed": bool(executor_policy_findings(FakeFS({EXEC_POLICY: {**XPOL, "mode": "GPT"}}))),
        "x_policy_good": executor_policy_findings(FakeFS({EXEC_POLICY: XPOL})) == [],
        "t4_no_prod_caller": rule(run(fsx=fs(__ca_class__="NONE")), "T4"),
        "t4_test_only": rule(run(fsx=fs(__ca_class__="TEST_ONLY")), "T4"),
        "t4_unresolved_no_waiver": rule(run(fsx=fs(__ca_class__="UNRESOLVED")), "T4"),
        "t4_incomplete": rule(run(fsx=fs(__ca_status__="INCOMPLETE")), "T4"),
        "t4_audit_crash_fails": rule(run(fsx=fs(__ca_raise__=RuntimeError("exit 2"))), "T4"),
        "t4_waiver_ok": run(fsx=fs(__ca_class__="NONE", **{BASELINE_CALLERS: B1})) == [],
        "t4_waiver_no_reason": rule(run(fsx=fs(__ca_class__="NONE", **{BASELINE_CALLERS: {"waivers": [{"function": "m:f", "reason": ""}], "waivers_max": 1}})), "T4"),
        "t4_baseline_grew": rule(run(fsx=fs(__ca_class__="NONE", **{BASELINE_CALLERS: {"waivers": [{"function": "m:f", "reason": "x"}], "waivers_max": 0}})), "T4"),
        "t4_stale_waiver": rule(run(fsx=fs(**{BASELINE_CALLERS: B1})), "T4"),
        "t4_interrupt_no_state": t4_interrupt(),
    }
    bad = [k for k, v in cases.items() if not v]
    print("batch_gate selftest", "PASS" if not bad else f"FAIL {bad}", f"({len(cases)} cases)")
    return 0 if not bad else 1


def _selftest_rerecord() -> int:
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        (root / "e.py").write_text("x", encoding="utf-8")
        cmd = f"{sys.executable} -c \"open('n.txt','a').write('1')\""
        tasks = [{"task_id": t, "status": "DONE", "evidence_file": f"{t}.json", "entrypoint": {"path": "e.py", "command": cmd}} for t in ("A", "B")]
        reg = {"batches": [{"tasks": tasks}]}
        ok = rerecord(root, reg) == 0 and (root / "n.txt").read_text() == "1"
        ok = ok and all((root / EVIDENCE / f"{t}.json").exists() for t in ("A", "B"))
        ok = ok and not stale_groups(reg, root) and rerecord(root, reg) == 0 and (root / "n.txt").read_text() == "1"
        evp = root / EVIDENCE / "A.json"
        rec = json.loads(evp.read_text(encoding="utf-8")); rec["exit_code"] = 1
        evp.write_text(json.dumps(rec), encoding="utf-8")  # failing evidence counts as stale and is re-run
        ok = ok and len(stale_groups(reg, root)) == 1 and rerecord(root, reg) == 0 and not stale_groups(reg, root)
        selfcmd = f"{sys.executable} -c \"import json,sys;sys.exit(json.load(open('{EVIDENCE}/S.json'))['exit_code'])\""
        sreg = {"batches": [{"tasks": [{"task_id": "S", "status": "DONE", "evidence_file": "S.json", "entrypoint": {"path": "e.py", "command": selfcmd}}]}]}
        ok = ok and rerecord(root, sreg) == 0 and json.loads((root / EVIDENCE / "S.json").read_text())["exit_code"] == 0  # command reads its own evidence
        (root / "e.py").write_text("y", encoding="utf-8")
        ok = ok and len(stale_groups(reg, root)) == 1
    print("rerecord selftest " + ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


def main(argv: list[str]) -> int:
    if "--selftest" in argv:
        return selftest() or _selftest_rerecord()
    if len(argv) > 1 and argv[1] == "rerecord":
        return rerecord(ROOT, json.loads((ROOT / REGISTRY).read_text(encoding="utf-8")), argv[argv.index("--executor") + 1] if "--executor" in argv else "CHAT")
    if len(argv) > 1 and argv[1] == "record":
        tid = argv[2]
        entry = argv[argv.index("--entry") + 1]
        cmd = argv[argv.index("--command") + 1]
        executor = argv[argv.index("--executor") + 1] if "--executor" in argv else "CHAT"
        return record(ROOT, tid, entry, cmd, executor)
    reg = json.loads((ROOT / REGISTRY).read_text(encoding="utf-8"))
    rep: dict = {}
    found = check(reg, RealFS(ROOT), rep) + executor_policy_findings(RealFS(ROOT))
    if "--run" in argv:
        found += rerun(reg, ROOT)
    for x in found:
        print(x)
    for w in rep.get("t4_waived", []):
        print({"rule": "T4", "WAIVED": w})
    done = sum(1 for b in reg["batches"] for t in b.get("tasks", []) if t.get("status") == "DONE")
    total = sum(len(b.get("tasks", [])) for b in reg["batches"])
    print(f"batch_gate {'PASS' if not found else 'FAIL'}  tasks DONE {done}/{total}  batches DONE {sum(1 for b in reg['batches'] if b.get('status') == 'DONE')}/{len(reg['batches'])}")
    return 0 if not found else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
