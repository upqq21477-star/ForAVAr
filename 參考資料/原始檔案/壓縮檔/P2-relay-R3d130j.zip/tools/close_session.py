#!/usr/bin/env python3
"""One-call session close-out (stdlib only).

Lean default (minimum required): render handoff -> precheck -> reseal -> pack.

  python3 tools/close_session.py <ID> [--code] [--full] [--out DIR]

--code  adds precheck --run-tests (use whenever any .py changed).
--full  adds batch_gate, zip verify and rebuild_check --strict on an unzipped copy
        (on drift: reseal the source tree and pack once more); use when the task registry changed
        or for the final overall acceptance.
Stops at the first failing step and prints CLOSE_FAIL step=<name>; on success prints CLOSE_OK.
"""
import argparse, json, pathlib, shutil, subprocess, sys, tempfile, time, zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
PY = sys.executable


def run(label, cmd, cwd=ROOT, tail=5):
    t0 = time.perf_counter()
    p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True)
    lines = (p.stdout + p.stderr).strip().splitlines()
    print(f"[{'OK' if p.returncode == 0 else 'FAIL'}] {label} (rc={p.returncode}, {time.perf_counter() - t0:.1f}s)")
    for ln in lines[-tail:]:
        print("   " + ln[:180])
    return p.returncode == 0


def fail(step):
    print(f"CLOSE_FAIL step={step}")
    sys.exit(1)


def preflight_id(bid):
    d = json.loads((ROOT / "docs/handoffs/handoff.data.json").read_text(encoding="utf-8"))
    bad = [k for k in ("handoff_id", "store_key") if bid not in str(d.get(k, ""))]
    if bad:
        print(f"preflight: {','.join(bad)} lacks {bid}")
        fail("handoff id")


def early_budget():
    sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
    try:
        import repository_hygiene_gate as g
        errs = g.budget_errors(ROOT, g.tracked_files(ROOT))
    except Exception as e:  # noqa: BLE001 - preflight must not block on its own failure
        print(f"[WARN] budget preflight skipped: {type(e).__name__}")
        return
    for e in errs:
        print("   " + e)
    if errs:
        fail("budget preflight")
    print("[OK] budget preflight")


_GATE = """import json,subprocess,sys
r=subprocess.run([sys.executable,"-B",sys.argv[1],sys.argv[2]],capture_output=True,text=True)
try:
    d=json.loads(r.stdout)
except Exception:
    print("EXIT-GATE BLOCKED: sweep output unreadable rc=%s"%r.returncode); sys.exit(2)
rec=d.get("records",{})
bad=d.get("status")!="PASS" or d.get("candidate_count") or rec.get("expired") or rec.get("invalid") or r.returncode
print("EXIT-GATE %s: status=%s candidates=%s expired=%s invalid=%s reasons=%s"%("BLOCKED" if bad else "OK",d.get("status"),d.get("candidate_count"),len(rec.get("expired",[])),len(rec.get("invalid",[])),d.get("reason_codes")))
sys.exit(1 if bad else 0)
"""


def exit_steps(root=".", sweep="P1-Central-Control/scripts/lifecycle_sweep.py"):
    """Exit mechanism at close (existing lifecycle_sweep engine): no retire candidates / expired records, budgets only ratchet down."""
    return [("exit gate: lifecycle sweep", [PY, "-B", "-c", _GATE, sweep, root]),
            ("exit gate: budget ratchet (down only)", [PY, "-B", sweep, root, "--ratchet"])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("batch_id")
    ap.add_argument("--code", action="store_true", help="also run precheck --run-tests")
    ap.add_argument("--full", action="store_true", help="also batch_gate, verify, rebuild_check")
    ap.add_argument("--out", default="/mnt/user-data/outputs")
    a = ap.parse_args()
    preflight_id(a.batch_id)
    out = pathlib.Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    seal = [PY, "P1-Central-Control/scripts/reconstruction.py", "write"]
    steps = exit_steps() + [("render handoff", [PY, "tools/pack_handoff.py", "--render"])]
    # --run-tests already includes every plain precheck check, so run exactly one of them
    steps.append(("precheck --run-tests", [PY, "tools/precheck.py", "--run-tests"]) if a.code
                 else ("precheck", [PY, "tools/precheck.py"]))
    if a.full:
        steps.append(("batch_gate", [PY, "tools/batch_gate.py"]))
    steps.append(("reseal", seal))
    for label, cmd in steps:
        if not run(label, cmd):
            # evidence whose command is precheck itself can only pass after the test run: rerecord, then a cheap plain precheck
            if a.code and label == "precheck --run-tests" and run("batch_gate rerecord", [PY, "tools/batch_gate.py", "rerecord"]) \
                    and run("precheck (after rerecord)", [PY, "tools/precheck.py"]):
                continue
            fail(label)
        if label == "render handoff":
            early_budget()
    z = out / f"P2-relay-{a.batch_id}.zip"
    for attempt in (1, 2):
        if not run(f"pack {a.batch_id}", [PY, "tools/pack_handoff.py", "--batch", a.batch_id, "--out", str(out)]):
            fail("pack")
        if not a.full:
            break
        if not run("verify zip", [PY, "tools/pack_handoff.py", "--verify", str(z)], tail=1):
            fail("verify")
        with tempfile.TemporaryDirectory() as td:
            zipfile.ZipFile(z).extractall(td)
            ok = run("rebuild_check --strict (unzipped copy)", [PY, "tools/rebuild_check.py", "--strict"], cwd=td)
        if ok:
            break
        if attempt == 2:
            fail("rebuild_check")
        print("drift -> reseal source tree, pack again")
        if not run("reseal", seal):
            fail("reseal")
    h = out / f"{a.batch_id}-HANDOFF.md"
    shutil.copy(ROOT / "docs/handoffs/HANDOFF.md", h)
    print(f"handoff {h.stat().st_size:,} B; zip {z.stat().st_size:,} B")
    print(f"CLOSE_OK deliver: {z.name} + {h.name}")


if __name__ == "__main__":
    main()
