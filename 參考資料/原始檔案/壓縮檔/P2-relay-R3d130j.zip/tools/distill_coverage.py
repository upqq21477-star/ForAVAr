#!/usr/bin/env python3
"""Distillation coverage report (R3d7; stdlib only).

Why: "distill, then delete" was a manual judgement ("is anything live left in this
doc?"). This turns the first half into code: extract the doc's key terms and report
which ones appear in NO other live file. Uncovered terms are the candidates that a
human/AI must either move into the blueprint/Triage or consciously drop.

Key terms = `backticked` identifiers, CamelCase words, Title Case English phrases
(2-3 words), P/F ids (P2-F24, F27 ...), file-like names (x.py, x.json, x.md).
Live files = every text file except: the docs under test, archive dirs, handoffs,
MANIFEST, .git, and --exclude paths. Matching is case-insensitive substring.

Usage:
  python3 tools/distill_coverage.py DOC [DOC ...] [--top N] [--exclude PATH ...]
  python3 tools/distill_coverage.py --selftest
Exit 0 always for a report; with --max-uncovered N exit 1 if any doc exceeds N.
"""
import os
import re
import sys
import tempfile
from collections import Counter

TEXT_EXT = {".md", ".json", ".py", ".yml", ".yaml", ".txt", ".toml", ".sha256"}
SKIP_DIRS = {".git", "archive", "handoffs", "__pycache__", "node_modules"}
STOP = {"The", "This", "That", "These", "Those", "And", "For", "With", "When", "Not", "But", "Our",
        "Each", "Any", "All", "One", "Two", "Three", "See", "Use", "Must", "Should", "Can", "Only",
        "Draft", "Version", "Note", "Notes", "If", "In", "On", "It", "Is", "As", "At", "By", "To", "Of"}
RX_TICK = re.compile(r"`([^`\n]{3,60})`")
RX_CAMEL = re.compile(r"\b[A-Z][a-z]+(?:[A-Z][a-z0-9]+)+\b")
RX_TITLE = re.compile(r"\b[A-Z][a-z]{2,}(?: [A-Z][a-z]{2,}){1,2}\b")
RX_ID = re.compile(r"\b(?:P\d+-)?[FBMR]\d{1,3}[a-z]?\b|\bP\d+-[A-Z0-9.]+\b")
RX_FILE = re.compile(r"\b[\w./-]+\.(?:py|json|md|yml)\b")


def root_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def terms_of(text):
    c = Counter()
    for m in RX_TICK.findall(text):
        if " " not in m.strip():
            c[m.strip()] += 1
    for rx in (RX_CAMEL, RX_TITLE, RX_ID, RX_FILE):
        for m in rx.findall(text):
            if m.split(" ")[0] in STOP:
                continue
            c[m] += 1
    return c


def live_corpus(root, under_test, extra_exclude):
    skip = {os.path.normpath(os.path.join(root, p)) for p in list(under_test) + list(extra_exclude)}
    parts = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in SKIP_DIRS]
        for fn in fns:
            p = os.path.normpath(os.path.join(dp, fn))
            if p in skip or os.path.splitext(fn)[1] not in TEXT_EXT or fn == "MANIFEST.sha256":
                continue
            try:
                parts.append(open(p, encoding="utf-8", errors="ignore").read().lower())
            except OSError:
                pass
    return "\n".join(parts)


RX_NORM = re.compile(r"[^0-9a-z\u4e00-\u9fff]+")


def norm(s):
    """lowercase, drop separators: 'Problem Model' == problem_model == problem-model == ProblemModel."""
    return RX_NORM.sub("", s.lower())


def report(root, docs, top=25, extra_exclude=()):
    corpus = live_corpus(root, docs, extra_exclude)
    corpus_n = norm(corpus)
    out = []
    for d in docs:
        text = open(os.path.join(root, d), encoding="utf-8").read()
        terms = terms_of(text)
        # covered = literal hit, or hit after separator/case normalization (snake_case, kebab, CamelCase)
        unc = [(t, n) for t, n in terms.items()
               if t.lower() not in corpus and (len(norm(t)) < 6 or norm(t) not in corpus_n)]
        unc.sort(key=lambda x: (-x[1], x[0]))
        out.append({"doc": d, "bytes": len(text.encode("utf-8")), "terms": len(terms),
                    "uncovered": len(unc), "top": unc[:top]})
    return out


def main(argv):
    if "--selftest" in argv:
        return selftest()
    top, mx, excl, docs, i = 25, None, [], [], 0
    while i < len(argv):
        a = argv[i]
        if a == "--top":
            top = int(argv[i + 1]); i += 2
        elif a == "--max-uncovered":
            mx = int(argv[i + 1]); i += 2
        elif a == "--exclude":
            excl.append(argv[i + 1]); i += 2
        else:
            docs.append(a); i += 1
    if not docs:
        print(__doc__); return 2
    bad = False
    for r in report(root_dir(), docs, top, excl):
        pct = 100.0 * (r["terms"] - r["uncovered"]) / max(1, r["terms"])
        print(f"{r['doc']}  {r['bytes']}B  terms={r['terms']} uncovered={r['uncovered']} covered={pct:.0f}%")
        print("   " + ", ".join(f"{t}x{n}" for t, n in r["top"]))
        if mx is not None and r["uncovered"] > mx:
            bad = True
    return 1 if bad else 0


def selftest():
    with tempfile.TemporaryDirectory() as td:
        os.makedirs(os.path.join(td, "docs"))
        open(os.path.join(td, "docs", "a.md"), "w", encoding="utf-8").write(
            "# T\nProblem Model uses `knowledge_intake.py` and Epistemic State. P2-F24 Zorbulax.\n")
        open(os.path.join(td, "docs", "b.md"), "w", encoding="utf-8").write(
            "problem model, knowledge_intake.py, p2-f24 live here\n")
        r = report(td, ["docs/a.md"])[0]
        names = {t for t, _ in r["top"]}
        assert "Epistemic State" in names and "Problem Model" not in names, names
        assert "P2-F24" not in names and "knowledge_intake.py" not in names, names
        open(os.path.join(td, "docs", "c.py"), "w", encoding="utf-8").write("epistemic_state = 1\n")
        r3 = report(td, ["docs/a.md"])[0]
        assert "Epistemic State" not in {t for t, _ in r3["top"]}, "normalized (snake_case) match"
        r2 = report(td, ["docs/a.md"], extra_exclude=["docs/b.md", "docs/c.py"])[0]
        assert "Problem Model" in {t for t, _ in r2["top"]}
    print("distill_coverage selftest PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
