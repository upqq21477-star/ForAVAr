#!/usr/bin/env python3
"""Mechanical invariant audit (R3d6): KEEP-ENFORCED principle -> mechanism -> script -> test with asserts.

Replaces the manual "pick one assertion per marker" check. Source table: docs/plans/P2-Invariant-Triage.md §1.
Per principle it reports: scripts/policies/schemas matching each mechanism token, test files that mention the
token, and the assert count of those files. Status: TESTED / SCRIPT_ONLY / NO_MECHANISM_FOUND.
Static name matching only (HYPOTHESIS: aliases and dynamic calls are missed); it does not run the tests.
Usage: python3 tools/invariant_audit.py [--json] [--max-untested N]   |   --selftest
"""
from __future__ import annotations
import json, re, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CC = ROOT / "P1-Central-Control"
TABLE = ROOT / "docs/plans/P2-Invariant-Triage.md"
ASSERT_RE = re.compile(r"\bself\.assert\w+\(|\bassert\s")


def parse_rows(text: str) -> list[dict]:
    rows = []
    for line in text.splitlines():
        c = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(c) == 4 and c[0].isdigit() and c[3] == "KEEP-ENFORCED":
            rows.append({"id": int(c[0]), "principle": c[1], "mechanism": c[2]})
    return rows


def tokens(mech: str) -> list[str]:
    return sorted(set(re.findall(r"[a-z][a-z0-9_*]{3,}|[A-Z][A-Z_]{5,}", mech)))


def audit(cc: Path, rows: list[dict]) -> list[dict]:
    tests = {p: p.read_text(encoding="utf-8", errors="ignore") for p in (cc / "tests").glob("test_*.py")}
    scripts = {p: p.read_text(encoding="utf-8", errors="ignore") for p in (cc / "scripts").glob("*.py")}
    out = []
    for r in rows:
        found_src, found_tests, asserts = [], set(), 0
        for t in tokens(r["mechanism"]):
            g = t if "*" in t else f"*{t}*"
            for sub in ("scripts", "policy", "schemas", "canonical"):
                found_src += [f"{sub}/{p.name}" for p in (cc / sub).glob(g + ".*") if p.is_file()]
            if not found_src:  # fallback: function or constant defined/used inside a script body
                found_src += [f"scripts/{p.name}(body)" for p, txt in scripts.items() if t.replace("*", "") in txt][:2]
            for p, txt in tests.items():
                if t.replace("*", "") in txt or t.replace("*", "") in p.name:
                    found_tests.add(p)
        for p in found_tests:
            asserts += len(ASSERT_RE.findall(tests[p]))
        status = "TESTED" if found_src and asserts else "SCRIPT_ONLY" if found_src else "NO_MECHANISM_FOUND"
        out.append({**r, "status": status, "sources": sorted(set(found_src))[:4],
                    "tests": sorted(p.name for p in found_tests)[:3], "asserts": asserts})
    return out


def selftest() -> int:
    rows = parse_rows("| 2 | x | context_sufficiency、scanner | KEEP-ENFORCED |\n| 3 | y | 無 | MERGE→G1 |")
    assert [r["id"] for r in rows] == [2] and tokens(rows[0]["mechanism"]) == ["context_sufficiency", "scanner"]
    res = audit(CC, rows)
    assert res[0]["status"] in {"TESTED", "SCRIPT_ONLY", "NO_MECHANISM_FOUND"}
    print("invariant_audit selftest PASS")
    return 0


def main(argv: list[str]) -> int:
    if "--selftest" in argv:
        return selftest()
    res = audit(CC, parse_rows(TABLE.read_text(encoding="utf-8")))
    if "--json" in argv:
        print(json.dumps(res, ensure_ascii=False, indent=1))
    else:
        for r in res:
            print(f"{r['id']:>2} {r['status']:<18} asserts={r['asserts']:<4} {r['principle'][:18]:<18} src={r['sources'][:2]} tests={r['tests'][:2]}")
    bad = [r for r in res if r["status"] != "TESTED"]
    print(f"KEEP-ENFORCED={len(res)} TESTED={len(res)-len(bad)} untested={len(bad)}")
    limit = int(argv[argv.index("--max-untested") + 1]) if "--max-untested" in argv else None
    return 1 if limit is not None and len(bad) > limit else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
