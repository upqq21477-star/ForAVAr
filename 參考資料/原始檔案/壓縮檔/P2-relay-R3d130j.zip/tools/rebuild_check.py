#!/usr/bin/env python3
"""P2 rebuild_check (R7-S1-M1): can the system be rebuilt from blueprint + Current + canonical + schemas + scripts?

Copies the REQUIRED/DERIVED build files (a superset of those five groups) into a FRESH directory, regenerates the
derivable Reconstruction Input Set there, compares its per-component integrity hashes with the committed canonical
copy (differences are listed), then runs the Reconstruction Gate on the fresh copy (structural; --behavioral adds tests).
Exit 0 = fresh rebuild passed; --strict also fails on drift. Evidence level: SIMULATED_PASS (no network, stdlib only).
  python3 tools/rebuild_check.py [--strict] [--behavioral] [--out <file>]
"""
from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "P1-Central-Control" / "scripts"))
import reconstruction as rc  # noqa: E402


def diff_integrity(old: dict, new: dict) -> list[dict]:
    a, b = old.get("integrity_hashes", {}), new.get("integrity_hashes", {})
    return [{"component": k, "committed": a.get(k), "regenerated": b.get(k)} for k in sorted(set(a) | set(b)) if a.get(k) != b.get(k)]


def rebuild_check(repo: Path = REPO, *, behavioral: bool = False) -> dict:
    bp = rc.load_blueprint(repo)
    owned, _ = rc.ownership(repo, bp)
    files = rc._build_files(repo, bp, owned)
    with tempfile.TemporaryDirectory() as td:
        fresh, dest = Path(td) / "fresh", Path(td) / "dest"
        for rel in files:
            src = repo / rel
            if src.is_file():
                (fresh / rel).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, fresh / rel)
        committed = json.loads((repo / rc.policy()["input_set_path"]).read_text(encoding="utf-8"))
        regenerated = rc.write_input_set(fresh)  # derivable artifact, regenerated in the fresh tree only
        drift = diff_integrity(committed, regenerated)
        rep = rc.reconstruct(fresh, dest, run_behavioral=behavioral)
    ok = rep["status"] in ("RECONSTRUCTED", "PARTIAL_NOT_ACCEPTED") and rep["stages"].get("CLEAN_BUILD") == "PASS" and rep["stages"].get("STRUCTURAL") == "PASS"
    return {"evidence_level": "SIMULATED_PASS", "files_copied": len(files), "status": rep["status"], "stages": rep["stages"],
            "reasons": rep["reasons"], "drift": drift, "drift_components": len(drift), "ok": ok}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--strict", action="store_true")
    ap.add_argument("--behavioral", action="store_true")
    ap.add_argument("--out")
    a = ap.parse_args()
    r = rebuild_check(behavioral=a.behavioral)
    txt = json.dumps(r, ensure_ascii=False, indent=1)
    print(txt[:1800])
    if a.out:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        Path(a.out).write_text(txt + "\n", encoding="utf-8")
    bad = (not r["ok"]) or (a.strict and r["drift"])
    print("REBUILD_FAIL" if bad else "SIMULATED_PASS rebuild_check")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
