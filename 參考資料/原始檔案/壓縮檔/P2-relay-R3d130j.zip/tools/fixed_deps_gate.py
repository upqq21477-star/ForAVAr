#!/usr/bin/env python3
"""fixed_deps_gate：把「固定依賴驗證債」變成機械棘輪（只用標準庫；R3d11d）。

兩層證據，都存在 P1-Central-Control/evidence/fixed-deps/：
  FALLBACK.json  本環境全測試通過（precheck --run-tests 自動寫；驗證器可為 repo 內後備或真 jsonschema）
  REAL.json      Python 3.11＋jsonschema 4.26 全測試通過（Actions／Codespaces 跑；見 ingest）
  BASELINE.json  「尚未用真依賴驗證」的參考樹；只用來量債成長，不代表已驗證
  HISTORY.json   最近幾份舊樹的檔案雜湊表（陣列），供 ingest 以樹摘要對回當時的樹

規則（precheck 的 fixed_deps，HARD）：
  F1 FALLBACK 必須新鮮：範圍內檔案自上次全測試通過後有變動 → 失敗（先跑 precheck --run-tests）
  F2 真依賴債上限：自 REAL（無則 BASELINE）以來變動的範圍內檔案數 ≤ policy.max_unverified_files
  F3 policy.require_real_before_done 列的批次（預設 R5～R9）要標 DONE，須已有 REAL 證據
  policy.real_testing_mode＝DEFERRED_TO_R9 時 F2、F3 暫停（債仍計量並顯示）；R9 開始時改 ENFORCED
用法：
  python3 tools/fixed_deps_gate.py status | check | baseline | line | ingest "<證據行>" | selftest
  line：在跑完測試的環境印一行證據（Actions 寫進 step summary；使用者貼回對話）
  ingest：驗證證據行（kind=REAL、Python 3.11、真 jsonschema 4.26、exit=0、樹摘要對得上已知樹）後寫入 REAL.json
"""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
POLICY_REL = "P1-Central-Control/policy/fixed_deps.v1.0.json"
EVID_REL = "P1-Central-Control/evidence/fixed-deps"
REGISTRY_REL = "P1-Central-Control/policy/batch_acceptance.v1.0.json"
EXCLUDE_PARTS = {"__pycache__", "evidence"}
EXCLUDE_FILES = {"P1-Central-Control/canonical/reconstruction_input_set.json"}
HISTORY_KEEP = 2


class Gate:
    def __init__(self, root: Path = ROOT):
        self.root = root
        self.evid = root / EVID_REL

    # ---- tree ----
    def scope_files(self) -> list[Path]:
        out: list[Path] = []
        for base, exts in (("tools", {".py", ".json", ".txt"}), ("P1-Central-Control", {".py", ".json"}),
                           (".github/workflows", {".yml"})):
            d = self.root / base
            if d.exists():
                out += [p for p in d.rglob("*") if p.is_file() and p.suffix in exts
                        and not (set(p.relative_to(self.root).parts) & EXCLUDE_PARTS)]
        cur = self.root / "P1-CURRENT.json"
        if cur.exists():
            out.append(cur)
        return sorted(p for p in out if p.relative_to(self.root).as_posix() not in EXCLUDE_FILES)

    def tree_map(self) -> dict[str, str]:
        return {p.relative_to(self.root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest()[:12] for p in self.scope_files()}

    @staticmethod
    def digest(m: dict[str, str]) -> str:
        return hashlib.sha256(json.dumps(sorted(m.items()), ensure_ascii=False).encode()).hexdigest()[:12]

    @staticmethod
    def diff(a: dict[str, str], b: dict[str, str]) -> list[str]:
        return sorted(p for p in set(a) | set(b) if a.get(p) != b.get(p))

    # ---- env ----
    def env_info(self) -> dict:
        sys.path.insert(0, str(self.root / "P1-Central-Control" / "scripts"))
        try:
            import jsonschema  # noqa: WPS433
            fallback = bool(getattr(jsonschema, "FALLBACK", False))
            try:
                from importlib.metadata import version
                ver = None if fallback else version("jsonschema")
            except Exception:  # noqa: BLE001
                ver = None
        except Exception:  # noqa: BLE001
            fallback, ver = None, None
        py = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
        pol = self.policy()
        real_ok = (ver is not None and py.startswith(pol["real"]["python_prefix"])
                   and ver.startswith(pol["real"]["jsonschema_prefix"]))
        return {"python": py, "validator": "none" if fallback is None else ("fallback" if fallback else f"real-{ver}"),
                "jsonschema": ver, "real_ok": real_ok}

    # ---- store ----
    def policy(self) -> dict:
        return json.loads((self.root / POLICY_REL).read_text(encoding="utf-8"))

    def load(self, name: str) -> dict | None:
        p = self.evid / name
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None

    def _save(self, name: str, rec: dict) -> None:
        self.evid.mkdir(parents=True, exist_ok=True)
        (self.evid / name).write_text(json.dumps(rec, ensure_ascii=False, separators=(",", ":")) + "\n", encoding="utf-8")

    def _history(self) -> list[dict]:
        h = self.load("HISTORY.json")
        return h["trees"] if h else []

    def _rotate(self, old: dict | None, new_digest: str) -> None:
        if not old or old["tree_digest"] == new_digest:
            return
        trees = [t for t in self._history() if t["tree_digest"] != old["tree_digest"]] + [old]
        trees = sorted(trees, key=lambda t: t.get("seq", 0))[-HISTORY_KEEP:]
        self._save("HISTORY.json", {"kind": "HISTORY", "trees": trees})

    def _seq(self) -> int:
        return max([(self.load(n) or {}).get("seq", 0) for n in ("FALLBACK.json", "REAL.json", "BASELINE.json")]) + 1

    def known_map(self, digest: str) -> dict | None:
        for n in ("FALLBACK.json", "REAL.json", "BASELINE.json"):
            r = self.load(n)
            if r and r["tree_digest"] == digest:
                return r["map"]
        return next((t["map"] for t in self._history() if t["tree_digest"] == digest), None)

    # ---- commands ----
    def record_auto(self, tests: dict | None = None) -> str:
        """precheck --run-tests 通過後呼叫；真依賴環境同時寫 REAL。"""
        env, m = self.env_info(), self.tree_map()
        d = self.digest(m)
        rec = {"kind": "FALLBACK", "python": env["python"], "validator": env["validator"], "exit_code": 0,
               "tree_digest": d, "files": len(m), "tests": tests or {}, "seq": self._seq(), "map": m}
        self._rotate(self.load("FALLBACK.json"), d)
        self._save("FALLBACK.json", rec)
        if env["real_ok"]:
            self._rotate(self.load("REAL.json"), d)
            self._save("REAL.json", {**rec, "kind": "REAL", "jsonschema": env["jsonschema"], "source": "local-run"})
            return "REAL+FALLBACK"
        return "FALLBACK"

    def line(self) -> str:
        env, m = self.env_info(), self.tree_map()
        kind = "REAL" if env["real_ok"] else "FALLBACK"
        return (f"FIXED-DEPS-EVIDENCE kind={kind} py={env['python']} jsonschema={env['jsonschema'] or 'none'} "
                f"validator={env['validator']} exit=0 tree={self.digest(m)} files={len(m)}")

    def ingest(self, line: str) -> list[str]:
        kv = dict(t.split("=", 1) for t in line.split() if "=" in t)
        pol, errs = self.policy(), []
        if kv.get("kind") != "REAL":
            errs.append("INGEST_KIND_NOT_REAL")
        if not kv.get("py", "").startswith(pol["real"]["python_prefix"]):
            errs.append("INGEST_PYTHON_NOT_3_11")
        if not kv.get("jsonschema", "").startswith(pol["real"]["jsonschema_prefix"]) or not kv.get("validator", "").startswith("real-"):
            errs.append("INGEST_NOT_REAL_JSONSCHEMA_4_26")
        if kv.get("exit") != "0":
            errs.append("INGEST_EXIT_NOT_ZERO")
        m = self.known_map(kv.get("tree", ""))
        if m is None:
            errs.append("INGEST_TREE_UNKNOWN（請在最近一份交接 zip 的內容上跑工作流）")
        if errs:
            return errs
        self._rotate(self.load("REAL.json"), kv["tree"])
        self._save("REAL.json", {"kind": "REAL", "python": kv["py"], "validator": kv["validator"], "jsonschema": kv["jsonschema"],
                                 "exit_code": 0, "tree_digest": kv["tree"], "files": len(m), "seq": self._seq(),
                                 "source": "actions-line", "map": m})
        return []

    def baseline(self) -> None:
        m = self.tree_map()
        self._save("BASELINE.json", {"kind": "BASELINE", "note": "尚未用真依賴驗證；只量債成長", "tree_digest": self.digest(m),
                                     "files": len(m), "seq": self._seq(), "map": m})

    def debt(self) -> tuple[str, list[str]] | None:
        ref = self.load("REAL.json")
        label = "REAL"
        if ref is None:
            ref, label = self.load("BASELINE.json"), "BASELINE"
        return None if ref is None else (label, self.diff(ref["map"], self.tree_map()))

    def check(self) -> list[dict]:
        pol, errs, cur = self.policy(), [], self.tree_map()
        fb = self.load("FALLBACK.json")
        if fb is None:
            errs.append({"error": "F1_FALLBACK_MISSING：先跑 python3 tools/precheck.py --run-tests"})
        else:
            ch = self.diff(fb["map"], cur)
            if ch:
                errs.append({"error": f"F1_FALLBACK_STALE：{len(ch)} 個檔案自上次全測試後變動（{', '.join(ch[:4])}…）；先跑 precheck --run-tests"})
        d = self.debt()
        if d is None:
            errs.append({"error": "F2_BASELINE_MISSING：python3 tools/fixed_deps_gate.py baseline"})
        elif not self.deferred(pol) and len(d[1]) > pol["max_unverified_files"]:
            errs.append({"error": f"F2_REAL_DEBT_OVER_CAP：自 {d[0]} 起 {len(d[1])} 個檔案變動 > {pol['max_unverified_files']}；"
                                  "請使用者在 Actions 跑「P2 Fixed-Deps Tests (manual)」並貼回證據行（ingest）"})
        reg_p = self.root / REGISTRY_REL
        if reg_p.exists() and self.load("REAL.json") is None and not self.deferred(pol):
            reg = json.loads(reg_p.read_text(encoding="utf-8"))
            for b in reg["batches"]:
                if b["batch_id"] in pol["require_real_before_done"]:
                    errs += [{"error": f"F3_REAL_REQUIRED_BEFORE_DONE：{t['task_id']}"} for t in b.get("tasks", []) if t.get("status") == "DONE"]
        return errs

    @staticmethod
    def deferred(pol: dict) -> bool:
        """Real-dependency testing deferred to R9 (user decision 2026-10-14): F2 and F3 are suspended, debt still measured."""
        return pol.get("real_testing_mode") == "DEFERRED_TO_R9"

    def status(self) -> str:
        fb, d, real = self.load("FALLBACK.json"), self.debt(), self.load("REAL.json")
        cur = self.tree_map()
        lines = [f"範圍檔案 {len(cur)}；樹摘要 {self.digest(cur)}"]
        lines.append("FALLBACK：" + ("無" if fb is None else f"{fb['validator']} py{fb['python']}，自此變動 {len(self.diff(fb['map'], cur))} 檔"))
        lines.append("REAL：" + ("無（尚未用 Python 3.11＋jsonschema 4.26 驗證）" if real is None else f"py{real['python']} {real['validator']}，來源 {real.get('source')}"))
        if d:
            pol = self.policy()
            if self.deferred(pol):
                lines.append(f"真依賴債：自 {d[0]} 起 {len(d[1])} 檔（真實測試延後到 R9：只記錄不擋；上限 {pol['max_unverified_files']} 於 R9 起生效）")
            else:
                lines.append(f"真依賴債：自 {d[0]} 起 {len(d[1])} 檔（上限 {pol['max_unverified_files']}）")
        return "\n".join(lines)


def selftest() -> int:
    bad: list[str] = []

    def expect(name: str, cond: bool) -> None:
        if not cond:
            bad.append(name)

    with tempfile.TemporaryDirectory() as t:
        r = Path(t)
        (r / "tools").mkdir()
        (r / "P1-Central-Control/policy").mkdir(parents=True)
        (r / "P1-Central-Control/scripts").mkdir()
        (r / "tools/a.py").write_text("x=1\n")
        for i in range(4):
            (r / f"P1-Central-Control/scripts/m{i}.py").write_text(f"v={i}\n")
        (r / POLICY_REL).write_text(json.dumps({"max_unverified_files": 2, "real": {"python_prefix": "3.11", "jsonschema_prefix": "4.26"},
                                                "require_real_before_done": ["R5"]}))
        (r / REGISTRY_REL).write_text(json.dumps({"batches": [{"batch_id": "R5", "tasks": [{"task_id": "R5-M1", "status": "NOT_STARTED"}]}]}))
        g = Gate(r)
        expect("缺證據要報 F1 與 F2", {e["error"][:2] for e in g.check()} == {"F1", "F2"})
        g.record_auto()
        g.baseline()
        expect("剛記錄後全通過", g.check() == [])
        (r / "tools/a.py").write_text("x=2\n")
        expect("F1：改檔後 FALLBACK 過期", any(e["error"].startswith("F1") for e in g.check()))
        g.record_auto()
        expect("重跑後 F1 消失", not any(e["error"].startswith("F1") for e in g.check()))
        for i in range(3):
            (r / f"P1-Central-Control/scripts/m{i}.py").write_text("changed\n")
        g.record_auto()
        expect("F2：債超過上限", any(e["error"].startswith("F2_REAL_DEBT") for e in g.check()))
        reg = json.loads((r / REGISTRY_REL).read_text())
        reg["batches"][0]["tasks"][0]["status"] = "DONE"
        (r / REGISTRY_REL).write_text(json.dumps(reg))
        g.record_auto()
        expect("F3：無 REAL 證據不得標 R5 DONE", any(e["error"].startswith("F3") for e in g.check()))
        pol_p = r / POLICY_REL
        pol_d = json.loads(pol_p.read_text())
        pol_d["real_testing_mode"] = "DEFERRED_TO_R9"
        pol_p.write_text(json.dumps(pol_d))
        g.record_auto()
        expect("延後到 R9：F2／F3 暫停且 F1 仍通過", g.check() == [])
        (r / "tools/a.py").write_text("x=9\n")
        expect("延後到 R9：F1 仍然生效", any(e["error"].startswith("F1") for e in g.check()))
        g.record_auto()
        pol_d["real_testing_mode"] = "ENFORCED"
        pol_p.write_text(json.dumps(pol_d))
        g.record_auto()
        expect("改回 ENFORCED：F2 與 F3 恢復", {e["error"][:2] for e in g.check()} >= {"F2", "F3"})
        good = f"FIXED-DEPS-EVIDENCE kind=REAL py=3.11.9 jsonschema=4.26.0 validator=real-4.26.0 exit=0 tree={g.digest(g.tree_map())} files=5"
        expect("ingest 合法行通過", g.ingest(good) == [])
        expect("ingest 後 F3 消失、債歸零", not any(e["error"].startswith(("F3", "F2")) for e in g.check()))
        expect("ingest：Python 3.12 被拒", "INGEST_PYTHON_NOT_3_11" in g.ingest(good.replace("py=3.11.9", "py=3.12.3")))
        expect("ingest：後備驗證器被拒", any("NOT_REAL_JSONSCHEMA" in e for e in g.ingest(good.replace("validator=real-4.26.0", "validator=fallback"))))
        expect("ingest：exit≠0 被拒", "INGEST_EXIT_NOT_ZERO" in g.ingest(good.replace("exit=0", "exit=1")))
        expect("ingest：未知樹被拒", any("TREE_UNKNOWN" in e for e in g.ingest(good.replace("tree=" + g.digest(g.tree_map()), "tree=deadbeef0000"))))
        (r / "tools/a.py").write_text("x=3\n")
        g.record_auto()
        expect("歷史輪替保留舊樹且不超過上限", 1 <= len(g._history()) <= HISTORY_KEEP)
        expect("改檔後債按檔數計", g.debt() is not None and len(g.debt()[1]) == 1)
    for b in bad:
        print("FAIL:", b)
    print(f"fixed_deps_gate selftest {'PASS' if not bad else 'FAIL'} (18 cases)")
    return 0 if not bad else 1


def main(argv: list[str]) -> int:
    g = Gate()
    cmd = argv[0] if argv else "status"
    if cmd == "selftest":
        return selftest()
    if cmd == "status":
        print(g.status())
        return 0
    if cmd == "check":
        errs = g.check()
        for e in errs:
            print(e["error"])
        print("fixed_deps", "PASS" if not errs else "FAIL")
        return 1 if errs else 0
    if cmd == "baseline":
        g.baseline()
        print("BASELINE written")
        return 0
    if cmd == "line":
        print(g.line())
        return 0
    if cmd == "ingest" and len(argv) > 1:
        errs = g.ingest(argv[1])
        print("\n".join(errs) if errs else "REAL evidence ingested")
        return 1 if errs else 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
