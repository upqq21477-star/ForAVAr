"""caller_audit -- does a distilled function have a PRODUCTION caller?  (stdlib only, ast only)

Never imports the targets (no side effects); file contents are treated as data.
Exit: 0 = all PRODUCTION and scan COMPLETE; 1 = some dead / scan INCOMPLETE; 2 = tool error.
Classification: PRODUCTION | TEST_ONLY | NONE | UNRESOLVED | CHAINED_DEAD.
Liveness heuristic (HYPOTHESIS): tools/*.py, scripts named in .github/workflows and scripts with a
__main__ guard are live roots; a script module is live if a live file imports it.
Dynamic dispatch (non-literal importlib/__import__) is invisible -> UNRESOLVED when nothing else is live.

  python3 tools/caller_audit.py [--root DIR] [--functions mod:func ...] [--registry] [--out FILE]
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import sys
import tempfile
from pathlib import Path

SCRIPTS, TOOLS, TESTS = "P1-Central-Control/scripts", "tools", "P1-Central-Control/tests"
WORKFLOWS = ".github/workflows"
REGISTRY = "P1-Central-Control/policy/batch_acceptance.v1.0.json"


def _walk(base: Path, kind: str):
    if not base.is_dir():
        return
    for dp, dns, fns in os.walk(base):
        dns[:] = sorted(d for d in dns if d != "__pycache__" and not d.startswith("."))
        for fn in sorted(fns):
            if fn.endswith(".py"):
                yield Path(dp) / fn, kind


def _is_dynamic(n: ast.AST) -> bool:
    if not isinstance(n, ast.Call):
        return False
    fn = n.func
    name = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
    if name not in ("import_module", "__import__"):
        return False
    return not (n.args and isinstance(n.args[0], ast.Constant) and isinstance(n.args[0].value, str))


def _info(tree: ast.AST) -> dict:
    froms, aliases, attrs, dyn, main = set(), {}, set(), False, False
    for n in ast.walk(tree):
        if isinstance(n, ast.ImportFrom) and n.module is not None:
            last = n.module.split(".")[-1]
            for a in n.names:
                froms.add((last, a.name))
                aliases[a.asname or a.name] = a.name  # `from pkg import m [as mm]` binds a module
        elif isinstance(n, ast.Import):
            for a in n.names:
                aliases[a.asname or a.name.split(".")[0]] = a.name.split(".")[-1] if a.asname else a.name.split(".")[0]
        elif isinstance(n, ast.Attribute) and isinstance(n.value, ast.Name):
            attrs.add((n.value.id, n.attr))
        elif _is_dynamic(n):
            dyn = True
        elif isinstance(n, ast.If) and isinstance(n.test, ast.Compare) and isinstance(n.test.left, ast.Name) \
                and n.test.left.id == "__name__":
            main = True
    return {"froms": froms, "aliases": aliases, "attrs": attrs, "dyn": dyn, "main": main}


def _imports_module(info: dict, mod: str) -> bool:
    return any(m == mod for m, _ in info["froms"]) or mod in info["aliases"].values()


def _calls(info: dict, mod: str, func: str) -> bool:
    if (mod, func) in info["froms"] or (mod, "*") in info["froms"]:
        return True
    return any(v == mod and (k, func) in info["attrs"] for k, v in info["aliases"].items())


def audit(root: Path, specs: list[str]) -> dict:
    root = Path(root)
    files, unparsed = {}, []
    for base, kind in ((root / SCRIPTS, "import"), (root / TOOLS, "tool"), (root / TESTS, "test")):
        for p, k in _walk(base, kind):
            rel = p.relative_to(root).as_posix()
            try:
                files[rel] = (k, _info(ast.parse(p.read_text(encoding="utf-8"), filename=rel)))
            except (SyntaxError, UnicodeDecodeError, ValueError, OSError):
                unparsed.append(rel)
    wf = ""
    for p in sorted((root / WORKFLOWS).glob("*.y*ml")) if (root / WORKFLOWS).is_dir() else []:
        try:
            wf += p.read_text(encoding="utf-8")
        except (UnicodeDecodeError, OSError):
            unparsed.append(p.relative_to(root).as_posix())
    scripts = {Path(r).stem: r for r, (k, _) in files.items() if k == "import"}
    live = {m for m, r in scripts.items() if files[r][1]["main"] or f"{m}.py" in wf}
    grew = True
    while grew:  # a script is live if a live file (tool or live script) imports it
        grew = False
        for m, r in scripts.items():
            if m in live:
                continue
            for r2, (k2, i2) in files.items():
                if k2 != "test" and r2 != r and (k2 == "tool" or Path(r2).stem in live) and _imports_module(i2, m):
                    live.add(m)
                    grew = True
                    break
    dyn_prod = any(i["dyn"] for k, i in files.values() if k != "test")
    results = []
    for spec in sorted(set(specs)):
        mod, sep, func = spec.partition(":")
        row = {"module": mod, "function": func, "callers": [], "classification": "NONE"}
        if not sep or not mod or not func:
            row["classification"], row["note"] = "UNRESOLVED", "spec must be module:function"
        elif mod not in scripts:
            row["note"] = "module file missing"
        else:
            for rel in sorted(files):
                k, i = files[rel]
                if rel != scripts[mod] and _calls(i, mod, func):
                    row["callers"].append({"file": rel, "kind": k})
            live_c = [c for c in row["callers"] if c["kind"] == "tool" or (c["kind"] == "import" and Path(c["file"]).stem in live)]
            if live_c:
                row["classification"] = "PRODUCTION"
            elif dyn_prod:
                row["classification"] = "UNRESOLVED"
            elif any(c["kind"] == "import" for c in row["callers"]):
                row["classification"] = "CHAINED_DEAD"
            elif row["callers"]:
                row["classification"] = "TEST_ONLY"
        results.append(row)
    return {"status": "INCOMPLETE" if unparsed else "COMPLETE", "unparsed": sorted(unparsed), "results": results}


def registry_specs(root: Path) -> list[str]:
    reg = json.loads((Path(root) / REGISTRY).read_text(encoding="utf-8"))
    return sorted({t["distilled"]["function"] for b in reg.get("batches", []) for t in b.get("tasks", [])
                   if t.get("status") == "DONE" and t.get("distilled")
                   and t["distilled"].get("kind", "distilled") == "distilled"})


def write_atomic(path, text: str, _fault=None) -> None:
    """Temp file + rename: an interrupted write leaves the old file (or nothing), never a half file."""
    path = Path(path)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
        if _fault:
            _fault()
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def main(argv: list[str]) -> int:
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--root", default=str(Path(__file__).resolve().parents[1]))
    ap.add_argument("--functions", nargs="*", default=[])
    ap.add_argument("--registry", action="store_true", help="audit every DONE distilled function in the registry")
    ap.add_argument("--out")
    ap.add_argument("--json", action="store_true", help="accepted for compatibility; output is always JSON")
    a = ap.parse_args(argv)
    try:
        root = Path(a.root)
        if not root.is_dir():
            print(f"caller_audit: root not found: {root}", file=sys.stderr)
            return 2
        specs = list(a.functions) + (registry_specs(root) if a.registry or not a.functions else [])
        res = audit(root, specs)
        text = json.dumps(res, ensure_ascii=False, indent=2, sort_keys=True)
        if a.out:
            write_atomic(a.out, text + "\n")
        print(text)
    except Exception as e:  # tool error, not a verdict
        print(f"caller_audit: tool error: {type(e).__name__}: {e}", file=sys.stderr)
        return 2
    ok = res["status"] == "COMPLETE" and all(r["classification"] == "PRODUCTION" for r in res["results"])
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
