#!/usr/bin/env python3
"""capability_gate 警告模式：只報告不擋（blocked 恆 False）。maturity 檔缺／損毀／過期／未知 ID＝REFUSE；write_report 原子寫入（中斷不留半檔）。"""
from __future__ import annotations
import argparse, json, os, sys, tempfile
from pathlib import Path
P1 = "P1-Central-Control"
MAT, DECL, ST = (f"{P1}/state/capability_maturity.json", f"{P1}/policy/capability_declarations.v1.0.json", f"{P1}/state/capabilities")
def _r(c, d, why=None):
    return {"capability_id": c, "decision": d, "reason": why, "error_code": "CAP_NOT_WIRED" if d == "REFUSE" else None,
            "enforcement": "WARN_ONLY", "blocked": False, "would_block": d == "REFUSE"}
def _load(p):
    try:
        d = json.loads(Path(p).read_text(encoding="utf-8"))
    except FileNotFoundError:
        return None, "MATURITY_MISSING"
    except (OSError, ValueError):
        return None, "MATURITY_CORRUPT"
    ok = isinstance(d, dict) and isinstance(d.get("capabilities"), dict) and isinstance(d.get("tree_hash"), str)
    return (d, None) if ok else (None, "MATURITY_CORRUPT")
def check(cid, mp, tree_hash=None, fallback_declared=False):
    d, e = _load(mp)
    if e:
        return _r(cid, "REFUSE", e)
    if tree_hash is not None and d["tree_hash"] != tree_hash:
        return _r(cid, "REFUSE", "MATURITY_STALE")
    m = d["capabilities"].get(cid)
    if m is None:
        return _r(cid, "REFUSE", "UNKNOWN_CAPABILITY")
    if m == "WIRED":
        return _r(cid, "ALLOW")
    return _r(cid, "FALLBACK", "UNWIRED_USING_FALLBACK") if fallback_declared else _r(cid, "REFUSE", "UNWIRED")
def report(root, mp=None, tree_hash=None):
    root = Path(root)
    mp = Path(mp) if mp else root / MAT
    rs = [check(p.stem, mp, tree_hash) for p in sorted((root / ST).glob("CAP-*.json"))]
    n = lambda k: sum(r["decision"] == k for r in rs)
    return {"mode": "WARN", "total": len(rs), "allow": n("ALLOW"), "fallback": n("FALLBACK"), "would_refuse": n("REFUSE"), "results": rs}
def write_report(path, rep, _fault=None):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), prefix=".tmp-", suffix=".part")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(json.dumps(rep, ensure_ascii=False, indent=2))
            f.flush()
            os.fsync(f.fileno())
        if _fault:
            _fault()
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
def verify_declarations(root, dec=None):
    """DORMANT 宣告：ADR 存在、狀態檔 mode＝DORMANT、consumers＝0；回不一致清單。"""
    root = Path(root)
    try:
        dec = dec if dec is not None else json.loads((root / DECL).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return ["DECLARATIONS_UNREADABLE"]
    out = []
    for c, v in sorted(dec.get("dormant", {}).items()):
        if v.get("state") != "DORMANT":
            out.append(f"{c}: state 不是 DORMANT")
        elif v.get("consumers") != 0:
            out.append(f"{c}: consumers>0 但仍 DORMANT")
        if not (root / str(v.get("adr", ""))).is_file():
            out.append(f"{c}: ADR 不存在 {v.get('adr')}")
        try:
            if json.loads((root / ST / f"{c}.json").read_text(encoding="utf-8")).get("operating_mode") != "DORMANT":
                out.append(f"{c}: 狀態檔 mode 不是 DORMANT")
        except (OSError, ValueError):
            out.append(f"{c}: 狀態檔缺或損毀")
    return out
def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", default=".")
    ap.add_argument("--maturity")
    ap.add_argument("--tree-hash")
    ap.add_argument("--out")
    a = ap.parse_args(argv)
    rep = report(a.root, a.maturity, a.tree_hash)
    rep["declaration_problems"] = probs = verify_declarations(a.root)
    print(f"capability_gate WARN_ONLY total={rep['total']} allow={rep['allow']} fallback={rep['fallback']} would_refuse={rep['would_refuse']} declaration_problems={len(probs)}")
    for r in rep["results"]:
        if r["would_block"]:
            print(f"  WOULD_REFUSE {r['capability_id']} {r['reason']}")
    for p in probs:
        print(f"  DECLARATION {p}")
    if a.out:
        write_report(a.out, rep)
    return 0
if __name__ == "__main__":
    sys.exit(main())
