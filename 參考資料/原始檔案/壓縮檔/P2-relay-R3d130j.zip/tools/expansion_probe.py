#!/usr/bin/env python3
"""expansion_probe — admissibility check: run each blueprint invariant's test_ref (R1-S3h).

Design: docs/architecture/P2-Expansion-Checks-v0.1.md section 1. Report-only (always exit 0).
Uses the same runner shape as tools/precheck.py run_one_test_file (PYTHONPATH = scripts + tests,
cwd = repo root, `-m unittest P1-Central-Control.tests.<stem>`), because a bare unittest run gave a
false violation (ModuleNotFoundError: jsonschema) in the R1-S3h pilot. stdlib only.
Violation = invariant whose test is missing, fails, or ran 0 tests. Whether a test really covers its
statement is a semantic judgement and is NOT checked here (UNKNOWN).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BP = ROOT / "P1-Central-Control" / "canonical" / "blueprint.json"
TESTS = ROOT / "P1-Central-Control" / "tests"
REG = ROOT / "P1-Central-Control" / "capability_registry.json"


def classify(exists: bool, rc: int, ran: int) -> str:
    if not exists:
        return "MISSING"
    if rc != 0:
        return "FAIL"
    if ran <= 0:
        return "EMPTY"
    return "PASS"


def residual(rows: list[dict]) -> dict:
    n = len(rows)
    bad = sum(1 for r in rows if r["verdict"] != "PASS")
    return {"total": n, "violations": bad, "ratio": (bad / n if n else None)}


def run_test(stem: str, timeout: int = 300) -> tuple[int, int]:
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT / "P1-Central-Control" / "scripts"), str(TESTS)])
    try:
        p = subprocess.run([sys.executable, "-m", "unittest", f"P1-Central-Control.tests.{stem}"],
                           cwd=ROOT, env=env, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return 1, 0
    m = re.search(r"Ran (\d+) test", (p.stderr or "")[-600:])
    return p.returncode, int(m.group(1)) if m else 0


def probe() -> list[dict]:
    invariants = json.loads(BP.read_text(encoding="utf-8"))["invariants"]
    cache: dict[str, tuple[int, int]] = {}
    rows = []
    for inv in invariants:
        ref = inv["test_ref"]
        stem = Path(ref).stem
        exists = (ROOT / ref).is_file()
        if exists and stem not in cache:
            cache[stem] = run_test(stem)
        rc, ran = cache.get(stem, (1, 0))
        rows.append({"id": inv["invariant_id"], "test": stem, "ran": ran, "verdict": classify(exists, rc, ran)})
    return rows


def holdout(ids: list[str], k: int = 0, mod: int = 5) -> list[str]:
    """Deterministic held-out slice: sha256(id) mod `mod` == k (Checks doc section 2)."""
    return sorted(i for i in ids if int(hashlib.sha256(i.encode()).hexdigest(), 16) % mod == k)


def induce(train: list[tuple[str, str]]) -> tuple[dict, set, bool]:
    """Induce a tiny law set from (class, kind) pairs: a lookup, plus an identity law if it holds on train."""
    mapping: dict[str, set] = {}
    for c, kd in train:
        mapping.setdefault(c, set()).add(kd)
    vocab = {kd for _, kd in train}
    return mapping, vocab, all(kd == c for c, kd in train if c in vocab)


def predict(model: tuple[dict, set, bool], cls: str) -> str | None:
    """None = abstain (ambiguous or unseen); an abstention is UNKNOWN, never counted as wrong."""
    mapping, vocab, identity = model
    if cls in mapping:
        return next(iter(mapping[cls])) if len(mapping[cls]) == 1 else None
    return cls if identity and cls in vocab else None


def holdout_report(k: int = 0) -> list[dict]:
    caps = json.loads(REG.read_text(encoding="utf-8"))["capabilities"]
    held = set(holdout([c["capability_id"] for c in caps], k))
    model = induce([(c["class"], c["kind"]) for c in caps if c["capability_id"] not in held])  # frozen first
    rows = []
    for c in caps:  # truth is read only here, after the model is frozen
        if c["capability_id"] in held:
            p = predict(model, c["class"])
            rows.append({"id": c["capability_id"], "class": c["class"], "truth": c["kind"], "pred": p,
                         "verdict": "ABSTAIN" if p is None else ("OK" if p == c["kind"] else "WRONG")})
    return rows


def selftest() -> int:
    assert classify(False, 0, 5) == "MISSING" and classify(True, 1, 5) == "FAIL"
    assert classify(True, 0, 0) == "EMPTY" and classify(True, 0, 3) == "PASS"
    r = residual([{"verdict": "PASS"}, {"verdict": "FAIL"}])
    assert r["violations"] == 1 and r["ratio"] == 0.5
    assert residual([])["ratio"] is None
    ids = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j"]
    assert holdout(ids) == holdout(ids) and 0 < len(holdout(ids, 0)) < len(ids)
    m = induce([("X", "X"), ("Y", "Z"), ("Y", "W")])
    assert predict(m, "X") == "X" and predict(m, "Y") is None and predict(m, "Q") is None
    assert predict(induce([("A", "A"), ("B", "B")]), "A") == "A"
    print("expansion_probe selftest OK (4 groups)")
    return 0


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--selftest", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--holdout", action="store_true", help="generalization mechanism pilot on capability_registry")
    a = ap.parse_args()
    if a.selftest:
        return selftest()
    if a.holdout:
        rows = holdout_report()
        for r in rows:
            print(f"{r['id']:26} class={r['class']:14} truth={r['truth']:14} pred={r['pred']}  {r['verdict']}")
        n = len(rows)
        ok, ab, wr = (sum(1 for r in rows if r["verdict"] == v) for v in ("OK", "ABSTAIN", "WRONG"))
        print(f"held-out {n}: OK {ok}, ABSTAIN {ab}, WRONG {wr}; coverage {ok + wr}/{n}; report-only")
        return 0
    rows = probe()
    res = residual(rows)
    if a.json:
        print(json.dumps({"rows": rows, "residual": res}, ensure_ascii=False))
        return 0
    for r in rows:
        print(f"{r['id']:34} {r['verdict']:8} {r['test']} (ran {r['ran']})")
    pct = "n/a" if res["ratio"] is None else f"{res['ratio']:.1%}"
    print(f"admissibility residual: {res['violations']}/{res['total']} ({pct}); report-only")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
