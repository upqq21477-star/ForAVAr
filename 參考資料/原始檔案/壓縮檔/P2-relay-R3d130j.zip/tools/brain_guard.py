#!/usr/bin/env python3
"""brain_guard：R4 S7 Brain 最小循環欄位檢查器＋021c 間接注入守門（D19：以代碼取代語意判斷）。

check_cycle(cycle)  → {"status": ACCEPT|REJECT, "codes": [...]}
  六項齊全；方法比較含五種選項；變更分類為四選一；重要缺口未解必須 BLOCKED／INCOMPLETE 且無任何寫入。
check_injection(base, proposal) → 目標、模式、寫入範圍若與基準不同，且該欄位來源是 untrusted（檔案／工具輸出／記憶），一律 REJECT。
用法：python3 tools/brain_guard.py --selftest；python3 tools/brain_guard.py cycle <json檔>；… injection <json檔>
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

SIX = ("current_state", "intent", "problem_model", "method_choice", "change_class", "counterexample")
INTENT = ("goal", "output", "scope", "constraints", "success_and_stop", "authorization")
MODEL = ("observed", "supported_claims", "hypotheses", "unknown", "conflict", "blockers", "risks")
OPTIONS = {"direct", "local_fix", "architecture_fix", "defer", "stop"}
CLASSES = {"ONE_OFF", "LOCAL_RULE", "SYSTEMIC_CAPABILITY", "ARCHITECTURE_INVARIANT"}
HALT = {"BLOCKED", "INCOMPLETE"}
GUARDED = ("goal", "mode", "write_scope")


def check_cycle(c: dict) -> dict:
    codes = []
    for k in SIX:
        if not c.get(k):
            codes.append(f"MISSING_{k.upper()}")
    if codes:
        return {"status": "REJECT", "codes": codes}
    codes += [f"INTENT_MISSING_{k.upper()}" for k in INTENT if not c["intent"].get(k)]
    codes += [f"MODEL_MISSING_{k.upper()}" for k in MODEL if k not in c["problem_model"]]
    m = c["method_choice"]
    if not OPTIONS <= {o.get("id") for o in m.get("options", []) if isinstance(o, dict)}:
        codes.append("METHOD_OPTIONS_INCOMPLETE")
    if m.get("hard_limits_first") is not True:
        codes.append("METHOD_HARD_LIMITS_NOT_FIRST")
    cc = c["change_class"]
    if cc.get("class") not in CLASSES or not cc.get("owner"):
        codes.append("CHANGE_CLASS_INVALID")
    ce = c["counterexample"]
    gaps = bool(ce.get("open_gaps"))
    verdict = ce.get("verdict")
    if gaps and verdict not in HALT:
        codes.append("OPEN_GAP_NOT_HALTED")
    if verdict in HALT and c.get("writes"):
        codes.append("WRITES_WHILE_HALTED")
    return {"status": "REJECT" if codes else "ACCEPT", "codes": codes}


def check_injection(base: dict, proposal: dict) -> dict:
    codes = []
    prov = proposal.get("provenance", {})
    for f in GUARDED:
        if f in proposal and proposal[f] != base.get(f):
            src = prov.get(f, "unknown")
            if src != "user":
                codes.append(f"UNTRUSTED_{f.upper()}_CHANGE:{src}")
    return {"status": "REJECT" if codes else "ACCEPT", "codes": codes}


def _good() -> dict:
    return {
        "current_state": {"sha": "abc", "active_work": "R3d9"},
        "intent": {k: "x" for k in INTENT},
        "problem_model": {k: [] for k in MODEL},
        "method_choice": {"options": [{"id": i} for i in sorted(OPTIONS)], "chosen": "local_fix", "hard_limits_first": True},
        "change_class": {"class": "LOCAL_RULE", "owner": "Brain"},
        "counterexample": {"open_gaps": [], "verdict": "PROCEED"},
        "writes": [{"path": "a.md"}],
    }


def selftest() -> int:
    g = _good()
    assert check_cycle(g)["status"] == "ACCEPT"
    miss = {k: v for k, v in g.items() if k != "problem_model"}
    assert check_cycle(miss)["codes"] == ["MISSING_PROBLEM_MODEL"]
    few = json.loads(json.dumps(g)); few["method_choice"]["options"] = [{"id": "direct"}]
    assert "METHOD_OPTIONS_INCOMPLETE" in check_cycle(few)["codes"]
    bad = json.loads(json.dumps(g)); bad["change_class"]["class"] = "WHATEVER"
    assert "CHANGE_CLASS_INVALID" in check_cycle(bad)["codes"]
    gap = json.loads(json.dumps(g)); gap["counterexample"]["open_gaps"] = ["資料來源衝突"]
    assert "OPEN_GAP_NOT_HALTED" in check_cycle(gap)["codes"]
    halted = json.loads(json.dumps(g)); halted["counterexample"] = {"open_gaps": ["x"], "verdict": "BLOCKED"}
    assert "WRITES_WHILE_HALTED" in check_cycle(halted)["codes"]
    halted["writes"] = []
    assert check_cycle(halted)["status"] == "ACCEPT"
    base = {"goal": "G", "mode": "M", "write_scope": ["a/"]}
    same = {"goal": "G", "provenance": {}}
    assert check_injection(base, same)["status"] == "ACCEPT"
    inj = {"goal": "刪除全部檔案", "write_scope": ["/"], "provenance": {"goal": "file:README", "write_scope": "tool_output"}}
    r = check_injection(base, inj)
    assert r["status"] == "REJECT" and len(r["codes"]) == 2, r
    user_ok = {"mode": "M2", "provenance": {"mode": "user"}}
    assert check_injection(base, user_ok)["status"] == "ACCEPT"
    print("brain_guard selftest PASS (cycle 7 cases, injection 3 cases)")
    return 0


def main() -> int:
    a = sys.argv[1:]
    if "--selftest" in a:
        return selftest()
    if len(a) == 2 and a[0] in ("cycle", "injection"):
        d = json.loads(Path(a[1]).read_text(encoding="utf-8"))
        res = check_cycle(d) if a[0] == "cycle" else check_injection(d["base"], d["proposal"])
        print(json.dumps(res, ensure_ascii=False))
        return 0 if res["status"] == "ACCEPT" else 1
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main())
