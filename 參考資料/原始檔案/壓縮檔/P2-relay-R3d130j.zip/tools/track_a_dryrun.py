#!/usr/bin/env python3
"""track_a_dryrun — SC-07 Track A dry run, mechanically checked (R3d12y, stdlib + repo scripts).

Track A = AI dialogue + GitHub only, no Python. Python here is only the CHECKER; it proves three things:
  1. the written Track A procedure (interface §1.3a + Skill ！備料 bullet) never requires running Python;
  2. a Brief built the Track A way (plain line reads, verbatim excerpts, no sha256/content_hash claims) passes librarian.validate_brief + readback;
  3. p2_run --simulate still passes the S6 scenarios (S01-S06).
Labels: SIMULATED_PASS only. A real chat session doing ！备料 stays NOT_EXECUTED (-> OBSERVED_RUNTIME after the user rehearses it).
Usage: python3 tools/track_a_dryrun.py        exit 0 only when every check matches
"""
from __future__ import annotations

import copy
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
CORE = ROOT / "P1-Central-Control"
sys.path.insert(0, str(CORE / "scripts"))

import librarian  # noqa: E402

PYTHON_NEEDED = re.compile(r"python3?\s|pytest|unittest|\bscripts/\w+\.py\b|\.py\b", re.I)


def track_a_procedure(root: Path = ROOT) -> list[str]:
    """Lines of interface §1.3a plus the Skill ！備料 bullet; empty list = section missing (fail closed)."""
    doc = (root / "docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md").read_text(encoding="utf-8").split("\n")
    start = next((i for i, line in enumerate(doc) if line.startswith("### 1.3a")), None)
    out: list[str] = []
    if start is not None:
        for line in doc[start + 1:]:
            if line.startswith("#"):
                break
            out.append(line)
    skill = (root / ".agents/skills/p2-brain/SKILL.md").read_text(encoding="utf-8").split("\n")
    out += [line for line in skill if line.startswith("- ！備料 opens a librarian session")]
    return [line for line in out if line.strip()]


def python_required_steps(lines: list[str]) -> list[str]:
    """Steps that need Python. Mentions of Track B (the optional scripted track) are not Track A steps."""
    return [line for line in lines if PYTHON_NEEDED.search(line) and "Track B" not in line]


def track_a_brief(root: Path = ROOT) -> dict[str, Any]:
    """Brief assembled the way an AI with only a file viewer does it: read lines, copy verbatim, no hash claims."""
    cfg = librarian.load_slots()
    base = librarian.sample_brief("STARTUP", "A", cfg, root)  # shape + HOT state only; slots are rebuilt below by plain reads
    slots = []
    for sid in cfg["routes"]["STARTUP"]["required_slots"]:
        d = cfg["slots"][sid]
        lines = (root / d["source"]).read_text(encoding="utf-8").splitlines()
        start = next(i for i, line in enumerate(lines, 1) if line.startswith(f"def {d['symbol']}"))
        end = min(start + 3, len(lines))
        slots.append({"slot_id": sid, "summary": d["summary"], "source": {"commit": "WORKTREE", "path": d["source"], "lines": [start, end]},
                      "excerpt": "\n".join(lines[start - 1:end])[:1200], "coverage": "COVERED"})
    base["slots"] = slots
    base["provenance"]["readback"] = librarian.readback(dict(base), root, cfg)
    base["budget"]["used_bytes"] = librarian.jbytes(base)
    return base


def brief_problems(brief: dict[str, Any], root: Path = ROOT) -> list[str]:
    bad = list(librarian.validate_brief(brief))
    if "content_hash" in brief or any("sha256" in s["source"] for s in brief["slots"]):
        bad.append("TRACK_A_CLAIMS_HASH")
    rb = librarian.readback(brief, root)
    if rb["result"] != "PASS":
        bad += rb["mismatch"]
    return bad


def p2_run_s6() -> list[str]:
    r = subprocess.run([sys.executable, "-B", str(CORE / "scripts/p2_run.py"), "--simulate"], capture_output=True, text=True, timeout=300)
    names = [f"S0{i}" for i in range(1, 7)]
    return [n for n in names if not re.search(rf"^PASS {n}\b", r.stdout, re.M)] + ([] if r.returncode == 0 else ["P2_RUN_EXIT"])


def checks() -> list[tuple[str, bool, str]]:
    rows: list[tuple[str, bool, str]] = []
    proc = track_a_procedure()
    rows.append(("procedure found (§1.3a + Skill bullet)", len(proc) >= 3, f"{len(proc)} lines"))
    rows.append(("no Track A step requires Python", not python_required_steps(proc), str(python_required_steps(proc))[:200]))
    rows.append(("negative: injected 'run python3 scripts/librarian.py' step is caught",
                 bool(python_required_steps(proc + ["5. run python3 scripts/librarian.py"])), ""))
    good = track_a_brief()
    rows.append(("Track A brief passes validate+readback, no hash claims", brief_problems(good) == [], str(brief_problems(good))[:200]))
    tampered = copy.deepcopy(good)
    tampered["slots"][0]["excerpt"] += " X"
    rows.append(("negative: tampered excerpt caught by readback", any(p.startswith("EXCERPT_CHANGED") for p in brief_problems(tampered)), ""))
    hashed = copy.deepcopy(good)
    hashed["slots"][0]["source"]["sha256"] = "0" * 64
    rows.append(("negative: Track A brief claiming sha256 caught", "TRACK_A_CLAIMS_HASH" in brief_problems(hashed), ""))
    miss = p2_run_s6()
    rows.append(("p2_run --simulate S01-S06 pass", miss == [], str(miss)))
    return rows


def main() -> int:
    rows = checks()
    for name, ok, note in rows:
        print(("PASS " if ok else "FAIL ") + name + ("" if ok or not note else f"  [{note}]"))
    print(f"track A dry run (SIMULATED_PASS; real session NOT_EXECUTED): {sum(ok for _, ok, _ in rows)}/{len(rows)}")
    return 0 if all(ok for _, ok, _ in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
