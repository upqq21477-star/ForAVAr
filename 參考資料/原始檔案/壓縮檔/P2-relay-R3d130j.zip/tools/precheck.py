#!/usr/bin/env python3
"""P2 precheck — fast mechanical gate for every relay batch (stdlib only).

Why this exists: a SyntaxError sat in the 3,290-line core file and nobody noticed,
because no automatic check ran. This script is that check. It costs seconds.

Checks
  HARD  compile   every .py must compile                       (exit 1 on failure)
  HARD  json      every .json / .jsonl must parse               (exit 1 on failure)
  WARN  counts    declared official test counts == source counts
  HARD  hygiene   no media/archives, one handoff, one relay plan, no history logs, handoff view in sync
  HARD  refs      dangling doc references / orphan docs and data files; ratchet: only entries listed in
                  tools/baseline_refs.txt may exist, the list may only shrink (R3d10)
  HARD  pointers  Current / README / blueprint version and path pointers agree (tools/pointer_audit.py)
  HARD  seeds     expansion seeds in canonical/blueprint.json are acyclic, complete, resolvable (tools/seed_audit.py)
  HARD  assurance Outcome vs Process Assurance separation negative cases (tools/assurance_audit.py; 019c)
  HARD  chains    four wiring chains + UNWIRED count ratchet (tools/wiring_chain_audit.py; 020c)
  HARD  batch_gate D19: a DONE task/batch needs executed evidence; tier 3 needs closure + distillation (tools/batch_gate.py)
  HARD  fixed_deps full tests must be fresh; code files changed since the last real-dependency run <= cap; R5+ DONE needs REAL (tools/fixed_deps_gate.py)
  WARN  style     negative-directive wording in plan / handoff / blueprint (constraints live in code gates)
  WARN  wiring    capability derived-maturity report (WIRED / UNWIRED / NO_TOOL; tools/wiring_audit.py)
  HARD  ratchet   (--run-tests) a test file may fail only if it is listed in
                  tools/baseline_failing_tests.txt. New failures => exit 1.
                  Fixed files are reported so the baseline can shrink.

Usage (from repository root)
  python3 tools/precheck.py                  # compile + json + counts   (~3 s)
  python3 tools/precheck.py --run-tests      # + per-file tests + ratchet (~1-2 min)
  python3 tools/precheck.py --run-tests --write-baseline   # shrink-only update

Evidence labels: a passing run on the local machine = PROGRAM_EXECUTED_PASS for exactly
what was run; it is NOT OBSERVED_RUNTIME of the P2 system.
"""
from __future__ import annotations

import argparse
import ast
import json
import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASELINE = ROOT / "tools" / "baseline_failing_tests.txt"
REFS_BASELINE = ROOT / "tools" / "baseline_refs.txt"
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
RUNNER = ROOT / "P1-Central-Control" / "scripts" / "run_p2_validation.py"
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv"}


def iter_files(*suffixes: str):
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            if name.endswith(suffixes):
                yield Path(dirpath) / name


def rel(path: Path) -> str:
    return path.relative_to(ROOT).as_posix()


def check_compile() -> dict:
    errors = []
    total = 0
    for path in iter_files(".py"):
        total += 1
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except (SyntaxError, ValueError, UnicodeDecodeError) as exc:
            errors.append({"file": rel(path), "error": f"{type(exc).__name__}: {exc}"[:200]})
    return {"name": "compile", "level": "HARD", "checked": total, "errors": errors}


def check_json() -> dict:
    errors = []
    total = 0
    for path in iter_files(".json", ".jsonl"):
        total += 1
        try:
            text = path.read_text(encoding="utf-8")
            if path.suffix == ".jsonl":
                for number, line in enumerate(text.splitlines(), 1):
                    if line.strip():
                        json.loads(line)
            else:
                json.loads(text)
        except (ValueError, UnicodeDecodeError) as exc:
            errors.append({"file": rel(path), "error": str(exc)[:200]})
    return {"name": "json", "level": "HARD", "checked": total, "errors": errors}


def count_test_methods(path: Path) -> int:
    tree = ast.parse(path.read_text(encoding="utf-8"))
    count = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            count += sum(
                isinstance(item, ast.FunctionDef) and item.name.startswith("test")
                for item in node.body
            )
    return count


def check_declared_counts() -> dict:
    """Compare EXPECTED_TEST_COUNTS in the official runner with real source counts."""
    drift = []
    try:
        tree = ast.parse(RUNNER.read_text(encoding="utf-8"))
        declared = None
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(
                isinstance(t, ast.Name) and t.id == "EXPECTED_TEST_COUNTS" for t in node.targets
            ):
                declared = ast.literal_eval(node.value)
        if declared is None:
            return {"name": "counts", "level": "WARN", "errors": [{"error": "EXPECTED_TEST_COUNTS not found"}]}
        for ref, expected in declared.items():
            actual = count_test_methods(ROOT / ref)
            if actual != expected:
                drift.append({"file": ref, "declared": expected, "actual": actual})
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        return {"name": "counts", "level": "WARN", "errors": [{"error": f"{type(exc).__name__}: {exc}"[:200]}]}
    return {"name": "counts", "level": "WARN", "errors": drift}


MEDIA_SUFFIX = (".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".pdf", ".zip", ".7z", ".tar", ".gz")
HANDOFF_ALLOWED = {"docs/handoffs/handoff.data.json", "docs/handoffs/HANDOFF.md"}
HISTORY_NAME = re.compile(r"(Execution-Log|Checkpoint-\d+|Issue-Register|Remediation-Status)", re.I)
RUN_LOG_NAME = re.compile(r"-Run-\d+", re.I)
DOC_ROOTS = ("docs/", "參考資料/")
DATA_ROOTS = ("P1-Central-Control/evidence/", "P1-Central-Control/fixtures/", "P1-Central-Control/examples/")
STYLE_FILES = ("docs/plans/P2-Relay-Update-Plan.md", "docs/handoffs/handoff.data.json", "docs/architecture/P2-System-Blueprint-v1.0.md")
NEGATIVE_RE = re.compile(r"禁止|不得|不要|不可|勿|嚴禁|只准|不能|不許")


def all_rel_files() -> list[str]:
    out = []
    for dirpath, dirnames, filenames in os.walk(ROOT):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            r = (Path(dirpath) / name).relative_to(ROOT).as_posix()
            if r == "MANIFEST.sha256" or (r.startswith("P2-relay-") and r.endswith(".zip")):
                continue
            out.append(r)
    return out


def check_hygiene() -> dict:
    """HARD. Mechanical form of the user's rule: no stacked history, no unreferenced media, one handoff, one plan."""
    errors = []
    files = all_rel_files()
    for r in files:
        low = r.lower()
        if low.endswith(MEDIA_SUFFIX):
            errors.append({"rule": "H1_NO_MEDIA_OR_ARCHIVES", "path": r})
        if "handoff" in Path(r).name.lower() and r.startswith(DOC_ROOTS) and r not in HANDOFF_ALLOWED:
            errors.append({"rule": "H2_SINGLE_HANDOFF", "path": r})
        if r.startswith(DOC_ROOTS):
            if HISTORY_NAME.search(r):
                errors.append({"rule": "H4_NO_HISTORY_LOGS", "path": r})
            if RUN_LOG_NAME.search(r):
                errors.append({"rule": "H4_NO_HISTORY_LOGS", "path": r})
    plans = [r for r in files if r.startswith("docs/plans/") and "Relay-Update-Plan" in r]
    if len(plans) != 1:
        errors.append({"rule": "H3_SINGLE_RELAY_PLAN", "found": plans})
    data_path, view_path = ROOT / "docs/handoffs/handoff.data.json", ROOT / "docs/handoffs/HANDOFF.md"
    try:
        sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
        import handoff_render  # noqa: WPS433

        rendered = handoff_render.render(json.loads(data_path.read_text(encoding="utf-8")))
        if not view_path.exists() or view_path.read_text(encoding="utf-8") != rendered:
            errors.append({"rule": "H5_HANDOFF_VIEW_STALE", "fix": "python3 tools/pack_handoff.py --render"})
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        errors.append({"rule": "H5_HANDOFF_DATA_INVALID", "error": f"{type(exc).__name__}: {exc}"[:200]})
    return {"name": "hygiene", "level": "HARD", "checked": len(files), "errors": errors}


REF_RE = re.compile(r"((?:docs|參考資料)/[A-Za-z0-9_\-./\u4e00-\u9fff]+?\.(?:md|json))")


def refs_new_errors(errors: list[dict], baseline: set[str]) -> list[dict]:
    """Ratchet: an entry is tolerated only if its canonical JSON line is in the baseline file."""
    return [e for e in errors if json.dumps(e, sort_keys=True, ensure_ascii=False) not in baseline]


def read_refs_baseline() -> set[str]:
    if not REFS_BASELINE.exists():
        return set()
    return {ln.strip() for ln in REFS_BASELINE.read_text(encoding="utf-8").splitlines() if ln.strip() and not ln.startswith("#")}


def check_refs() -> dict:
    """HARD ratchet. Dangling doc references and orphan docs; only baseline entries may exist (R3d10)."""
    files = all_rel_files()
    existing = set(files)
    scan = [r for r in files if r.endswith((".md", ".json")) and (r.startswith(DOC_ROOTS) or r in ("README.md", "P1-CURRENT.json")
            or r.startswith("P1-Central-Control/progress/"))]
    texts = {}
    for r in scan:
        try:
            texts[r] = (ROOT / r).read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
    errors = []
    for r, text in texts.items():
        for line in text.splitlines():
            if "待建" in line:
                continue
            for target in REF_RE.findall(line):
                if target not in existing:
                    errors.append({"dangling": target, "in": r})
    everything = {}
    for r in files:
        if r.endswith((".md", ".json", ".py", ".yml", ".jsonl")):
            try:
                everything[r] = (ROOT / r).read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError):
                continue
    for r in files:
        if r.startswith(DOC_ROOTS) and r.endswith(".md") and not r.endswith("README.md"):
            name = Path(r).name
            if not any(name in text for key, text in everything.items() if key != r):
                errors.append({"orphan": r})
    for r in files:
        if r.startswith(DATA_ROOTS) and r.endswith((".json", ".jsonl", ".sarif")):
            name = Path(r).name
            if not any(name in text for key, text in everything.items() if key != r):
                errors.append({"orphan_data": r})
    seen, uniq = set(), []
    for e in errors:
        key = json.dumps(e, sort_keys=True, ensure_ascii=False)
        if key not in seen:
            seen.add(key)
            uniq.append(e)
    return {"name": "refs", "level": "HARD", "errors": refs_new_errors(uniq, read_refs_baseline())}



def check_invariants() -> dict:
    """WARN. Every KEEP-ENFORCED principle must map to a mechanism and a test with asserts (tools/invariant_audit.py)."""
    try:
        sys.path.insert(0, str(ROOT / "tools"))
        import invariant_audit  # noqa: WPS433

        rows = invariant_audit.parse_rows((ROOT / "docs/plans/P2-Invariant-Triage.md").read_text(encoding="utf-8"))
        res = invariant_audit.audit(ROOT / "P1-Central-Control", rows)
        errors = [{"principle": r["id"], "status": r["status"]} for r in res if r["status"] != "TESTED"]
        if not rows:
            errors.append({"error": "no KEEP-ENFORCED rows parsed"})
        return {"name": "invariants", "level": "WARN", "errors": errors}
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        return {"name": "invariants", "level": "WARN", "errors": [{"error": f"{type(exc).__name__}: {exc}"[:200]}]}


def check_workflows() -> dict:
    """HARD. Workflows are manual-only and point at no missing or archived path (tools/workflow_audit.py, R3d9 S2-e)."""
    try:
        sys.path.insert(0, str(ROOT / "tools"))
        import workflow_audit  # noqa: WPS433

        res = workflow_audit.audit(ROOT)
        errors = [dict(f) for f in res["findings"]]
        return {"name": "workflows", "level": "HARD", "errors": errors}
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        return {"name": "workflows", "level": "HARD", "errors": [{"error": f"{type(exc).__name__}: {exc}"[:200]}]}


def check_pointers() -> dict:
    """HARD. Current / README / blueprint pointers agree (tools/pointer_audit.py, R3d10 R3e)."""
    try:
        sys.path.insert(0, str(ROOT / "tools"))
        import pointer_audit  # noqa: WPS433

        rc = pointer_audit.selftest()
        errors = [dict(f) for f in pointer_audit.audit(ROOT)["findings"]]
        if rc != 0:
            errors.append({"error": f"selftest rc={rc}"})
        return {"name": "pointers", "level": "HARD", "errors": errors}
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        return {"name": "pointers", "level": "HARD", "errors": [{"error": f"{type(exc).__name__}: {exc}"[:200]}]}


def selftest_refs_ratchet() -> int:
    base = {json.dumps({"dangling": "a.md", "in": "b.md"}, sort_keys=True, ensure_ascii=False)}
    old = {"dangling": "a.md", "in": "b.md"}
    new = {"orphan": "docs/x.md"}
    ok = refs_new_errors([old], base) == [] and refs_new_errors([old, new], base) == [new] and refs_new_errors([new], set()) == [new]
    print("refs ratchet selftest", "PASS" if ok else "FAIL")
    return 0 if ok else 1


def _guard(fn) -> list[dict]:
    """Run one tool check; a crash becomes a finding instead of killing the gate."""
    try:
        sys.path.insert(0, str(ROOT / "tools"))
        return fn()
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        return [{"error": f"{type(exc).__name__}: {exc}"[:200]}]


def _seeds() -> list[dict]:
    import seed_audit

    return ([{"error": "selftest failed"}] if seed_audit.selftest() else []) + seed_audit.audit(ROOT)["findings"]


def _assurance() -> list[dict]:
    import assurance_audit

    return [{"error": "selftest failed"}] if assurance_audit.selftest() else []


def _chains() -> list[dict]:
    import wiring_chain_audit

    return ([{"error": "selftest failed"}] if wiring_chain_audit.selftest() else []) + wiring_chain_audit.audit(ROOT)["findings"]


def _batch_gate() -> list[dict]:
    import batch_gate

    reg = json.loads((ROOT / batch_gate.REGISTRY).read_text(encoding="utf-8"))
    return ([{"error": "selftest failed"}] if batch_gate.selftest() else []) + batch_gate.check(reg, batch_gate.RealFS(ROOT))


def _fixed_deps() -> list[dict]:
    import fixed_deps_gate

    g = fixed_deps_gate.Gate(ROOT)
    return ([{"error": "selftest failed"}] if fixed_deps_gate.selftest() else []) + g.check()


def _adr() -> list[dict]:
    import architecture_decision

    return [{"error": e} for e in architecture_decision.validate(ROOT)] + [{"error": "simulate failed: " + f} for f in architecture_decision.simulate()]


def _startup() -> list[dict]:
    import startup_budget

    return ([{"error": "selftest failed"}] if startup_budget.selftest() else []) + startup_budget.check(ROOT)


def check_brain_guard() -> dict:
    """HARD. The R4 S7 six-item checker and the 021c injection guard keep their negative cases (tools/brain_guard.py)."""
    try:
        sys.path.insert(0, str(ROOT / "tools"))
        import brain_guard  # noqa: WPS433

        rc = brain_guard.selftest()
        return {"name": "brain_guard", "level": "HARD", "errors": [] if rc == 0 else [{"error": f"selftest rc={rc}"}]}
    except Exception as exc:  # noqa: BLE001 - report, never crash the gate
        return {"name": "brain_guard", "level": "HARD", "errors": [{"error": f"{type(exc).__name__}: {exc}"[:200]}]}


def check_style() -> dict:
    """WARN. Counts negative-directive wording in the documents Claude reads first; constraints belong in code gates."""
    errors = []
    for r in STYLE_FILES:
        path = ROOT / r
        if path.exists():
            hits = len(NEGATIVE_RE.findall(path.read_text(encoding="utf-8")))
            if hits:
                errors.append({"file": r, "negative_directives": hits})
    return {"name": "style", "level": "WARN", "errors": errors}


def run_one_test_file(stem: str, timeout: int) -> dict:
    import time as _t
    t0 = _t.perf_counter()
    env = dict(os.environ)
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = os.pathsep.join(
        [str(ROOT / "P1-Central-Control" / "scripts"), str(TESTS_DIR)]
    )
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "unittest", f"P1-Central-Control.tests.{stem}"],
            cwd=ROOT, env=env, capture_output=True, text=True, timeout=timeout,
        )
        tail = (proc.stderr or "")[-600:]
        ran = re.search(r"Ran (\d+) test", tail)
        return {"test": stem, "ok": proc.returncode == 0, "ran": int(ran.group(1)) if ran else 0,
                "secs": round(_t.perf_counter() - t0, 1)}
    except subprocess.TimeoutExpired:
        return {"test": stem, "ok": False, "ran": 0, "timeout": True}


def read_baseline() -> set[str]:
    if not BASELINE.exists():
        return set()
    return {
        line.strip() for line in BASELINE.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.startswith("#")
    }


def check_tests(timeout: int, workers: int) -> dict:
    stems = sorted(p.stem for p in TESTS_DIR.glob("test_*.py"))
    import time as _t
    _w = _t.perf_counter()
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(lambda s: run_one_test_file(s, timeout), stems))
    wall = round(_t.perf_counter() - _w, 1)
    failing = {r["test"] for r in results if not r["ok"]}
    baseline = read_baseline()
    return {
        "name": "ratchet", "level": "HARD",
        "files": len(stems),
        "files_ok": len(stems) - len(failing),
        "files_failing": len(failing),
        "methods_ran": sum(r["ran"] for r in results),
        "new_failures": sorted(failing - baseline),        # => exit 1
        "fixed_since_baseline": sorted(baseline - failing),  # => baseline may shrink
        "_failing": sorted(failing),
        "wall": wall,
        "slowest": [[r.get("secs", 0), r["test"]] for r in sorted(results, key=lambda r: -r.get("secs", 0))[:5]],
    }


def check_wiring() -> dict:
    """WARN. Capability derived-maturity report (tools/wiring_audit.py): WIRED / UNWIRED / NO_TOOL. CANONICAL is an identity constraint, not maturity (D-R2c-D18)."""
    try:
        sys.path.insert(0, str(ROOT / "tools"))
        import wiring_audit
        rep = wiring_audit.audit(ROOT)
    except Exception as exc:  # noqa: BLE001 - a broken audit must not fail the gate while it is WARN
        return {"name": "wiring", "level": "WARN", "errors": [{"error": f"{type(exc).__name__}: {exc}"[:200]}]}
    errors = [{"summary": rep["counts"], "maturity": rep["maturity_counts"], "unwired": len(rep["unwired"])}]
    errors += [{"unwired": c} for c in rep["unwired"]]
    return {"name": "wiring", "level": "WARN", "errors": errors}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--run-tests", action="store_true")
    parser.add_argument("--write-baseline", action="store_true", help="shrink-only baseline update")
    parser.add_argument("--timeout", type=int, default=120)
    parser.add_argument("--workers", type=int, default=4)
    parser.add_argument("--json", action="store_true", help="print full JSON report")
    parser.add_argument("--selftest", action="store_true", help="run the refs-ratchet negative cases")
    args = parser.parse_args()
    if args.selftest:
        return selftest_refs_ratchet()
    import time as _t
    _t0 = _t.perf_counter()

    checks = [check_compile(), check_json(), check_hygiene(), check_declared_counts(), check_refs(), check_pointers(), {"name": "seeds", "level": "HARD", "errors": _guard(_seeds)}, {"name": "assurance", "level": "HARD", "errors": _guard(_assurance)}, {"name": "chains", "level": "HARD", "errors": _guard(_chains)}, {"name": "batch_gate", "level": "HARD", "errors": _guard(_batch_gate)}, {"name": "startup_budget", "level": "HARD", "errors": _guard(_startup)}, {"name": "adr", "level": "HARD", "errors": _guard(_adr)}, check_invariants(), check_workflows(), check_brain_guard(), check_style(), check_wiring()]
    if args.run_tests:
        checks.append(check_tests(args.timeout, args.workers))
        tests = checks[-1]
        if not tests["new_failures"]:
            import fixed_deps_gate

            fixed_deps_gate.Gate(ROOT).record_auto({"files_ok": tests["files_ok"], "files": tests["files"],
                                                    "methods_ran": tests["methods_ran"], "new_failures": 0})
    checks.append({"name": "fixed_deps", "level": "HARD", "errors": _guard(_fixed_deps)})

    failed = False
    for check in checks:
        if check["name"] == "ratchet":
            if check["new_failures"]:
                failed = True
        elif check["level"] == "HARD" and check["errors"]:
            failed = True

    if args.write_baseline:
        ratchet = next((c for c in checks if c["name"] == "ratchet"), None)
        if ratchet is None:
            print("--write-baseline requires --run-tests", file=sys.stderr)
            return 2
        if ratchet["new_failures"] and BASELINE.exists():
            print("refusing to write baseline: new failures exist (baseline may only shrink)", file=sys.stderr)
            return 1
        BASELINE.write_text(
            "# Known-failing test files (ratchet). May only shrink. Owner: relay batch R1.\n"
            + "\n".join(ratchet["_failing"]) + "\n",
            encoding="utf-8",
        )

    for check in checks:
        check.pop("_failing", None)
    report = {"status": "FAIL" if failed else "PASS", "checks": checks,
              "evidence_level": "PROGRAM_EXECUTED_PASS" if not failed else "PROGRAM_EXECUTED_FAIL"}
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2))
    else:
        for check in checks:
            if check["name"] == "ratchet":
                print(f"[ratchet] files ok {check['files_ok']}/{check['files']}, methods ran {check['methods_ran']}, "
                      f"NEW failures {len(check['new_failures'])}, fixed-vs-baseline {len(check['fixed_since_baseline'])}")
                for name in check["new_failures"]:
                    print(f"   NEW FAIL: {name}")
                print(f"[timing] tests wall {check['wall']}s; slowest: " + ", ".join(f"{n} {t}s" for t, n in check["slowest"]))
            else:
                print(f"[{check['name']}] {check['level']} errors={len(check['errors'])}")
                for err in check["errors"][:10]:
                    print("   ", err)
        print(f"[timing] precheck total {_t.perf_counter() - _t0:.1f}s")
        print(f"PRECHECK {report['status']}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
