#!/usr/bin/env python3
"""P2 relay packer — build and verify the handoff bundle (stdlib only).

A relay handoff is exactly two things, and nothing else accumulates:
    1. the updated repository zip   (P2-relay-<BATCH>.zip)
    2. the handoff document         docs/handoffs/handoff.data.json  (the ONE source; native P1 mechanism)
                                    docs/handoffs/HANDOFF.md         (generated view of it, overwritten every batch)
The plan is the other single document: docs/plans/P2-Relay-Update-Plan.md.

Build    : python3 tools/pack_handoff.py --batch R1 --out /path/to/outdir
Verify   : python3 tools/pack_handoff.py --verify P2-relay-R1.zip     (or an unzipped dir)
Render   : python3 tools/pack_handoff.py --render                     (data.json -> HANDOFF.md only)
Skeleton : python3 tools/pack_handoff.py --skeleton R2                (print a fresh data.json to fill in)

Build refuses to produce a zip when the handoff is incomplete (see REQUIRED_TITLES / task table),
when any .py does not compile, or when the hygiene gate (tools/precheck.py) reports an error.
Verify checks MANIFEST.sha256 against the real bytes (missing / altered / extra / mangled names).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", "__pycache__", "node_modules", ".venv"}
SKIP_SUFFIX = (".pyc",)
MANIFEST = "MANIFEST.sha256"

REQUIRED_TITLES = (
    "狀態摘要", "任務表", "證據", "變更檔案", "阻塞與未知", "下一批輸入", "啟動提示詞", "收尾檢核",
)
RULES_TITLE = "接力規則（照做；工具每場自動帶入）"
RULES_BLOCKS = [
    {"p": "只需要本文件與附件 zip；舊企劃、舊交接都不用讀。本章每場自動帶入，固定不改。"},
    {"bullets": [
        "**開工（1 次呼叫）：** 解壓 → `python3 tools/pack_handoff.py --verify <zip> && python3 tools/session_start.py` → 只讀「下一批輸入」；批次卡用 `python3 tools/slice.py docs/plans/P2-Relay-Update-Plan.md --heading \"### R6\"`。大檔一律 slice，不整檔讀。",
        "**預算：** 讀 ≤ 48 KB、寫 ≤ 36 KB、呼叫 ≤ 30 次；任一到 70% 就停止開新任務、進入收尾。",
        "**場次與驗證（使用者 2026-10-16 定）：** ① 題組依複雜度配對（規劃稿 `## 19.`），高搭低、各場總分接近，一場一次跑完，取 §19 的下一個場次組合 ② 驗證只留最低需求，不為「多驗一次」加步驟 ③ 所有測試一律用模擬運行（標 SIMULATED_PASS），R9 之前不跑真實依賴、不要求使用者實測 ④ 全部題組與施工完成後，才做一次整體實測（R9）。",
        "**做法：** 照「下一批輸入」的 MUST 順序做；需裁決就採其中的預設方向、一行記理由，不停下來問；同一問題試 2 次仍失敗＝寫 BLOCKER（假說標 HYPOTHESIS）並換題。",
        "**守則：** 測試期望不改（必改須寫原期望為何錯）；有實跑才說完成；模擬一律標 SIMULATED_PASS；`canonical/`、`schemas/`、`P1-CURRENT.json` 不動（卡片明載除外）。",
        "**既有優先（使用者 2026-10-16 定）：** 新增、修改、規劃、新建系統前，先找出原有流程並比對覆蓋度，決定 REUSE／MODIFY／MERGE／NEW；NEW 須寫明每個既有候選為何不能改；先更新規劃再施工，不得直接堆疊新模組（見規劃 §8）。",
        "**四階段（系統基本能力，不必再提）：** 任何新功能、規劃、新系統一律走 F30 四階段：①藍圖（大綱每節點有重點、待辦排序）②能運行（每功能有入口與退出碼 0）③閉環（被呼叫、結束、退場、蒸餾成程式）④實際運行（無證據標 NOT_EXECUTED）；階段未完成不得說完成。通用化進行中，見規劃 §8。",
        "**證據標記：** PROGRAM_EXECUTED_PASS／SIMULATED_PASS／PATCHED_UNVERIFIED／NOT_EXECUTED／HYPOTHESIS。",
        "**收尾（1 次呼叫，最低需求）：** 先覆寫好 `handoff.data.json`，再 `python3 tools/close_session.py <ID>`。預設只跑 render → precheck → 重封 → 打包；改過 .py 加 `--code`（多跑 run-tests）；動到登記表或要整體驗收才加 `--full`（再加 batch_gate、驗證、解壓副本 rebuild_check）。只交付 `P2-relay-<ID>.zip` 與 `<ID>-HANDOFF.md`。已結案內容一行蒸餾進 `docs/handoffs/LEDGER.md`（≤ 10 KB）。",
        "**交接寫法：** 交接檔只放「下一場要做什麼」；已裁決內容、歷史、未知清單放規劃稿或 LEDGER，用 `slice.py` 按需讀。複製現有 `handoff.data.json`，只改 headline／狀態摘要／任務表／證據／變更檔案／下一批輸入／啟動提示詞；必備章節不變。目標 6～8 KB（上限 12,000 B）。無 Python 時只做 DOC_ONLY。"]},
]


AXIS = ROOT / "docs" / "architecture" / "P2-Axis-v0.1.md"
BLUEPRINT = ROOT / "docs" / "architecture" / "P2-System-Blueprint-v1.0.md"
AXIS_TITLE = "系統主軸（自動帶入；來源 docs/architecture/P2-Axis-v0.1.md）"


def axis_section() -> dict | None:
    """Build the system-axis chapter (one sentence, tree, flow) from the single axis file; None if absent."""
    if not AXIS.exists():
        return None
    text = AXIS.read_text(encoding="utf-8")
    one = re.search(r"^> (.+)$", text, re.M)
    tree = re.search(r"```text\n(.*?)```", text, re.S)
    flow = re.search(r"## 怎麼連[^\n]*\n\n(.+)\n", text)
    if not (one and tree and flow):
        raise ValueError("AXIS_FORMAT_INVALID: need blockquote, text tree and 怎麼連 line")
    return {"title": AXIS_TITLE, "blocks": [
        {"p": one.group(1) + "（索引，非規範；細節以藍圖為準，每場自動帶入，開工不需另讀。）"},
        {"code": tree.group(1).rstrip("\n")},
        {"p": "怎麼連：" + flow.group(1)},
    ]}


def axis_problems() -> list[str]:
    """Gate: the axis file must pass tools/axis_lint.py against the blueprint (stale axis blocks the pack)."""
    if not AXIS.exists():
        return []
    run = subprocess.run([sys.executable, str(ROOT / "tools" / "axis_lint.py"), str(AXIS), str(BLUEPRINT)],
                         capture_output=True, text=True, encoding="utf-8")
    if run.returncode == 0:
        return []
    return ["axis_lint FAIL: " + "; ".join(l for l in run.stdout.splitlines() if l.startswith("[FAIL]"))[:300]]


def ensure_rules() -> None:
    """Inject the fixed rules chapter first and the system-axis chapter second (idempotent)."""
    data = json.loads(DATA.read_text(encoding="utf-8"))
    kept = [x for x in data["sections"] if not x["title"].startswith(("接力規則", "系統主軸"))]
    front = [{"title": RULES_TITLE, "blocks": RULES_BLOCKS}]
    axis = axis_section()
    if axis:
        front.append(axis)
    data["sections"] = front + kept
    DATA.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


VALID_TASK_STATUS = {"DONE", "PARTIAL", "BLOCKED", "SKIPPED", "NOT_STARTED"}
DATA = ROOT / "docs" / "handoffs" / "handoff.data.json"
VIEW = ROOT / "docs" / "handoffs" / "HANDOFF.md"


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def iter_tree(base: Path):
    for dirpath, dirnames, filenames in os.walk(base):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_DIRS)
        for name in sorted(filenames):
            path = Path(dirpath) / name
            rel = path.relative_to(base).as_posix()
            if name.endswith(SKIP_SUFFIX) or rel == MANIFEST:
                continue
            if rel.startswith("P2-relay-") and rel.endswith(".zip"):
                continue
            yield rel, path


def load_renderer():
    sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
    import handoff_render  # noqa: WPS433

    return handoff_render


COUNTER_RE = re.compile(r"登記表 (\d+)/(\d+)(?:、批次 (\d+)/(\d+))?")


def _strings(node):
    if isinstance(node, str):
        yield node
    elif isinstance(node, dict):
        for v in node.values():
            yield from _strings(v)
    elif isinstance(node, list):
        for v in node:
            yield from _strings(v)


def counter_problems(data: dict, counts: dict | None = None) -> list[str]:
    """Hand-written progress counters must equal the registry (OB5-2): regenerate, then compare."""
    if counts is None:
        sys.path.insert(0, str(ROOT / "tools"))
        import session_start  # noqa: WPS433

        counts = session_start.registry_counts(ROOT)
    problems = []
    for text in _strings(data):
        for m in COUNTER_RE.finditer(text):
            said = (int(m.group(1)), int(m.group(2)))
            if said != (counts["done"], counts["total"]):
                problems.append(f"handoff 登記表 {said[0]}/{said[1]} 與登記表實算 {counts['done']}/{counts['total']} 不符")
            if m.group(3) and (int(m.group(3)), int(m.group(4))) != (counts["batches_done"], counts["batches_total"]):
                problems.append(f"handoff 批次 {m.group(3)}/{m.group(4)} 與登記表實算 {counts['batches_done']}/{counts['batches_total']} 不符")
    return problems


def validate_handoff(batch: str) -> list[str]:
    problems: list[str] = []
    try:
        ensure_rules()
        data = json.loads(DATA.read_text(encoding="utf-8"))
        load_renderer().render(data)  # field/section/block validation + size cap
    except Exception as exc:  # noqa: BLE001
        return [f"handoff data invalid: {type(exc).__name__}: {exc}"[:240]]
    titles = [section["title"] for section in data["sections"]]
    for needed in REQUIRED_TITLES:
        if not any(title.startswith(needed) for title in titles):
            problems.append(f"handoff missing section: {needed}")
    if batch not in data["handoff_id"] and batch not in data["store_key"]:
        problems.append("handoff_id/store_key does not mention --batch")
    task_rows = []
    for section in data["sections"]:
        if section["title"].startswith("任務表"):
            for block in section["blocks"]:
                if "table" in block:
                    task_rows = block["table"]["rows"]
    if not task_rows:
        problems.append("任務表 needs a table block (ID | 級別 | 狀態 | 結果)")
    for row in task_rows:
        if len(row) >= 3 and row[2].split()[0] not in VALID_TASK_STATUS:
            problems.append(f"task {row[0]}: status must start with one of {sorted(VALID_TASK_STATUS)}")
    raw = DATA.read_text(encoding="utf-8")
    if "TODO" in raw or "待填" in raw:
        problems.append("handoff still contains TODO / 待填")
    problems += counter_problems(data)
    return problems


def render_view() -> None:
    ensure_rules()
    data = json.loads(DATA.read_text(encoding="utf-8"))
    VIEW.write_text(load_renderer().render(data), encoding="utf-8")


def hygiene_problems() -> list[str]:
    sys.path.insert(0, str(ROOT / "tools"))
    import precheck  # noqa: WPS433

    return [json.dumps(e, ensure_ascii=False) for e in precheck.check_hygiene()["errors"] if e.get("rule") != "H5_HANDOFF_VIEW_STALE"]


def skeleton(batch: str) -> str:
    blocks = {t: [{"p": "..."}] for t in REQUIRED_TITLES}
    blocks["任務表"] = [{"table": {"header": ["ID", "級別", "狀態", "結果"], "rows": [["X-M1", "M", "DONE", "..."]]}}]
    return json.dumps({
        "handoff_id": batch, "date": "YYYY-MM-DD", "store_key": f"{batch}-STATE",
        "headline": "...", "sections": [{"title": RULES_TITLE, "blocks": RULES_BLOCKS}] + [{"title": t, "blocks": b} for t, b in blocks.items()],
    }, ensure_ascii=False, indent=1)


def compile_problems() -> list[str]:
    problems = []
    for rel, path in iter_tree(ROOT):
        if rel.endswith(".py"):
            try:
                compile(path.read_text(encoding="utf-8"), rel, "exec")
            except (SyntaxError, ValueError) as exc:
                problems.append(f"does not compile: {rel}: {exc}"[:200])
    return problems


def build(batch: str, out_dir: Path) -> int:
    problems = validate_handoff(batch) + compile_problems() + hygiene_problems() + axis_problems()
    if not problems:
        render_view()
    if problems:
        print("PACK REFUSED:")
        for problem in problems:
            print("  -", problem)
        return 1
    lines = [f"{sha256_file(path)}  {rel}" for rel, path in iter_tree(ROOT)]
    (ROOT / MANIFEST).write_text("\n".join(lines) + "\n", encoding="utf-8")
    out_dir.mkdir(parents=True, exist_ok=True)
    zip_path = out_dir / f"P2-relay-{batch}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as archive:
        archive.write(ROOT / MANIFEST, MANIFEST)
        for rel, path in iter_tree(ROOT):
            archive.write(path, rel)  # non-ASCII names are stored with the UTF-8 flag
    print(f"PACK OK  {zip_path}")
    print(f"files={len(lines)}  size={zip_path.stat().st_size}  sha256={sha256_file(zip_path)}")
    return 0


def verify(target: Path) -> int:
    temp = None
    base = target
    if target.is_file():
        temp = tempfile.TemporaryDirectory()
        with zipfile.ZipFile(target) as archive:
            archive.extractall(temp.name)
        base = Path(temp.name)
    manifest_path = base / MANIFEST
    if not manifest_path.exists():
        print("VERIFY FAIL: no MANIFEST.sha256")
        return 1
    expected = {}
    for line in manifest_path.read_text(encoding="utf-8").splitlines():
        digest, _, rel = line.partition("  ")
        expected[rel] = digest
    missing = [rel for rel in expected if not (base / rel).exists()]
    altered = [rel for rel in expected if (base / rel).exists() and sha256_file(base / rel) != expected[rel]]
    extra = [rel for rel, _ in iter_tree(base) if rel not in expected]
    badnames = [rel for rel in expected if "#U" in rel]
    ok = not (missing or altered or badnames)
    print(f"VERIFY {'OK' if ok else 'FAIL'}  files={len(expected)} missing={len(missing)} "
          f"altered={len(altered)} extra={len(extra)} mangled_names={len(badnames)}")
    for label, items in (("missing", missing), ("altered", altered), ("extra", extra), ("mangled", badnames)):
        for rel in items[:10]:
            print(f"   {label}: {rel}")
    if temp:
        temp.cleanup()
    return 0 if ok else 1


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--batch", help="batch id, e.g. R1")
    parser.add_argument("--out", type=Path, default=Path("."), help="output directory for the zip")
    parser.add_argument("--verify", type=Path, help="zip or directory to verify against MANIFEST.sha256")
    parser.add_argument("--render", action="store_true", help="regenerate docs/handoffs/HANDOFF.md from handoff.data.json")
    parser.add_argument("--skeleton", metavar="BATCH", help="print a fresh handoff.data.json skeleton")
    args = parser.parse_args()
    if args.skeleton:
        print(skeleton(args.skeleton))
        return 0
    if args.render:
        render_view()
        print("RENDERED", VIEW.relative_to(ROOT))
        return 0
    if args.verify:
        return verify(args.verify)
    if not args.batch:
        parser.error("--batch is required to build")
    return build(args.batch, args.out)


if __name__ == "__main__":
    sys.exit(main())
