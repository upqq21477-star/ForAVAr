#!/usr/bin/env python3
"""Compact failure triage (stdlib only): first error of every baseline-failing test file, in one small table.

  python3 tools/failfirst.py                 # all files in tools/baseline_failing_tests.txt
  python3 tools/failfirst.py test_quality_metrics test_task_admission_gate
Output is capped (~6 KB): file | tests failed/ran | first failing test | first error line. No full tracebacks.
Evidence: a first-error line is an OBSERVED FACT; the cause you infer from it is a HYPOTHESIS until a
distinguishing test separates it from the alternatives.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CC = ROOT / "P1-Central-Control"
BASELINE = ROOT / "tools" / "baseline_failing_tests.txt"


def names() -> list[str]:
    if sys.argv[1:]:
        return [n.removesuffix(".py").split("/")[-1] for n in sys.argv[1:]]
    return [n.removesuffix(".py").split("/")[-1] for n in (l.strip() for l in BASELINE.read_text(encoding="utf-8").splitlines())
            if n and not n.startswith("#")]


def first_failure(stem: str) -> str:
    env = dict(os.environ)  # identical to tools/precheck.py run_one_test_file(): same env, same command, same cwd
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    env["PYTHONPATH"] = os.pathsep.join([str(CC / "scripts"), str(CC / "tests")])
    try:
        proc = subprocess.run([sys.executable, "-m", "unittest", f"P1-Central-Control.tests.{stem}"], cwd=ROOT, env=env,
                              capture_output=True, text=True, timeout=150)
    except subprocess.TimeoutExpired:
        return f"{stem} | TIMEOUT"
    out = proc.stderr
    ran = re.search(r"Ran (\d+) test", out)
    bad = re.search(r"FAILED \((.*?)\)", out)
    count = sum(int(x) for x in re.findall(r"=(\d+)", bad.group(1))) if bad else 0
    head = re.search(r"^(?:FAIL|ERROR): (\w+)", out, re.M)
    err = ""
    if head:
        block = out[head.end():].split("\n\n")[0:6]
        lines = [l.strip() for l in "\n".join(block).splitlines() if re.match(r"\w*(Error|Exception|Failed)\b|AssertionError", l.strip())]
        err = (lines[0] if lines else "")[:150]
    if "ModuleNotFoundError" in out or "ImportError" in out and not head:
        err = (re.findall(r"(?:ModuleNotFound|Import)Error.*", out) or [""])[0][:150]
    return f"{stem} | {count}/{ran.group(1) if ran else '?'} | {head.group(1) if head else '-'} | {err}"


def main() -> int:
    with ThreadPoolExecutor(4) as pool:
        rows = list(pool.map(first_failure, names()))
    print("file | failed/ran | first failing test | first error line")
    print("\n".join(rows))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
