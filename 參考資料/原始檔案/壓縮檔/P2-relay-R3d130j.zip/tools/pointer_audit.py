#!/usr/bin/env python3
"""P2 pointer_audit — Current / README / blueprint pointers must agree (stdlib only; R3d10 R3e).

Rules (code-enforced, replaces "someone reads README and notices drift")
  PT1  P1-CURRENT.json p2_target_blueprint_ref exists and its title carries a version (vN.N).
  PT2  every "藍圖 vN.N" / "blueprint vN.N" statement in README.md that is not marked archived
       (封存 / ARCHIVED / 舊版 / 舊藍圖 / 原藍圖) equals that version.
  PT3  every governance_rule_ref path in P1-CURRENT.json exists (after splitting on non-path text).
  PT4  README names the same blueprint path as Current.
  PT5  README carries no next-step statement of its own ("下一個工作單元"); progress is derived, not restated (R3d12s).
  PT6  README names docs/handoffs/HANDOFF.md as the progress authority (R3d12s).

Usage: python3 tools/pointer_audit.py [--selftest]   exit 0 = PASS
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
VER_RE = re.compile(r"v(\d+\.\d+)")
STMT_RE = re.compile(r"(?:藍圖|blueprint|Blueprint|現行內容)[^。\n]{0,12}?v(\d+\.\d+)")
ARCHIVED_HINT = ("封存", "ARCHIVED", "舊版", "舊藍圖", "原藍圖")
PATH_STRIP = re.compile(r"[\w./\u4e00-\u9fff-]+\.(?:md|json)")
PATH_RE = re.compile(r"[\w./\u4e00-\u9fff-]+\.(?:md|json)")
HANDOFF_PATH = "docs/handoffs/HANDOFF.md"


def audit_texts(current: dict, readme: str, blueprint_title: str, exists) -> list[dict]:
    findings: list[dict] = []
    for n, line in enumerate(readme.splitlines(), 1):
        if "下一個工作單元" in line:
            findings.append({"rule": "PT5", "line": n, "error": "README restates a next step; progress lives in HANDOFF"})
    if HANDOFF_PATH not in readme:
        findings.append({"rule": "PT6", "error": f"README does not name {HANDOFF_PATH} as progress authority"})
    ref = current.get("p2_target_blueprint_ref", "")
    if not ref or not exists(ref):
        findings.append({"rule": "PT1", "error": f"p2_target_blueprint_ref missing or absent: {ref!r}"})
    m = VER_RE.search(blueprint_title)
    if not m:
        findings.append({"rule": "PT1", "error": "blueprint title has no version"})
        return findings
    version = m.group(1)
    for n, line in enumerate(readme.splitlines(), 1):
        for sentence in line.split("。"):
            if any(h in sentence for h in ARCHIVED_HINT):
                continue
            for found in STMT_RE.findall(PATH_STRIP.sub("", sentence)):
                if found != version:
                    findings.append({"rule": "PT2", "line": n, "says": f"v{found}", "blueprint": f"v{version}"})
    if ref and ref not in readme:
        findings.append({"rule": "PT4", "error": "README does not name the Current blueprint path"})
    gov = current.get("p2_blueprint_pointer_policy", {}).get("governance_rule_ref", "")
    for p in PATH_RE.findall(gov):
        if not exists(p):
            findings.append({"rule": "PT3", "missing": p})
    return findings


def audit(root: Path = ROOT) -> dict:
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    readme = (root / "README.md").read_text(encoding="utf-8")
    ref = current.get("p2_target_blueprint_ref", "")
    title = ""
    if ref and (root / ref).exists():
        title = (root / ref).read_text(encoding="utf-8").splitlines()[0]

    def exists(p: str) -> bool:
        return (root / p).exists() or any(root.glob(f"**/{Path(p).name}"))

    return {"findings": audit_texts(current, readme, title, exists)}


def selftest() -> int:
    ok = lambda p: True  # noqa: E731
    cur = {"p2_target_blueprint_ref": "docs/b.md", "p2_blueprint_pointer_policy": {"governance_rule_ref": "see docs/g.md"}}
    good = audit_texts(cur, "唯一藍圖 v4.0 見 docs/b.md\n舊藍圖 v2.7 已封存\n進度見 docs/handoffs/HANDOFF.md", "# X 藍圖 v4.0", ok)
    H = " docs/handoffs/HANDOFF.md"
    stale = audit_texts(cur, "唯一藍圖 v2.7 見 docs/b.md" + H, "# X 藍圖 v4.0", ok)
    nopath = audit_texts(cur, "唯一藍圖 v4.0" + H, "# X 藍圖 v4.0", ok)
    gone = audit_texts(cur, "藍圖 v4.0 docs/b.md" + H, "# X 藍圖 v4.0", lambda p: p != "docs/g.md")
    nextstep = audit_texts(cur, "藍圖 v4.0 docs/b.md" + H + "\n下一個工作單元做 X", "# X 藍圖 v4.0", ok)
    nohandoff = audit_texts(cur, "藍圖 v4.0 docs/b.md", "# X 藍圖 v4.0", ok)
    notitle = audit_texts(cur, "x docs/b.md" + H, "# no version", ok)
    cases = {"good": good == [], "stale": any(f["rule"] == "PT2" for f in stale),
             "nopath": any(f["rule"] == "PT4" for f in nopath), "gone": any(f["rule"] == "PT3" for f in gone),
             "notitle": any(f["rule"] == "PT1" for f in notitle),
             "nextstep": [f["rule"] for f in nextstep] == ["PT5"], "nohandoff": [f["rule"] for f in nohandoff] == ["PT6"]}
    bad = [k for k, v in cases.items() if not v]
    print("pointer_audit selftest", "PASS" if not bad else f"FAIL {bad}", f"({len(cases)} cases)")
    return 0 if not bad else 1


if __name__ == "__main__":
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    res = audit()
    for f in res["findings"]:
        print(f)
    print("pointer_audit", "PASS" if not res["findings"] else "FAIL")
    sys.exit(0 if not res["findings"] else 1)
