#!/usr/bin/env python3
"""Mechanical reference retargeting and delete guard (R3d5).

Replaces the manual "grep referrers -> edit -> hope" flow with code:
  plan   : list every live file that mentions an old path (dry run, exit 0)
  apply  : rewrite old -> new in those files (textual; keeps JSON formatting)
  guard  : exit 1 if any live file still mentions a path (safe-to-delete check)
  delete : guard, then remove the file (refuses when referrers remain)
Live files exclude archive dirs, handoffs, MANIFEST and the given --keep paths
(history prose that may legitimately name a removed file).
Usage:
  python3 tools/ref_retarget.py plan  OLD=NEW [OLD=NEW ...] [--keep PATH ...]
  python3 tools/ref_retarget.py plan  PATH [PATH ...]   (bare paths: list referrers)
  python3 tools/ref_retarget.py apply OLD=NEW ...
  python3 tools/ref_retarget.py guard OLD [OLD ...]
  python3 tools/ref_retarget.py delete OLD [OLD ...]
  python3 tools/ref_retarget.py --selftest
"""
from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {".git", "__pycache__", "archive", "node_modules"}
SKIP_FILES = {"MANIFEST.sha256", "HANDOFF.md", "handoff.data.json"}
TEXT_SUFFIX = (".md", ".json", ".py", ".yml", ".yaml", ".txt", ".jsonl", ".sarif")


def live_files(root: Path, keep: set[str]) -> list[Path]:
    out = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            p = Path(dirpath) / name
            rel = p.relative_to(root).as_posix()
            if name in SKIP_FILES or rel in keep or not name.endswith(TEXT_SUFFIX):
                continue
            out.append(p)
    return out


def referrers(root: Path, targets: list[str], keep: set[str]) -> dict[str, dict[str, int]]:
    hits: dict[str, dict[str, int]] = {}
    for p in live_files(root, keep):
        try:
            text = p.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        rel = p.relative_to(root).as_posix()
        for t in targets:
            if rel == t:
                continue
            n = text.count(t)
            if n:
                hits.setdefault(rel, {})[t] = n
    return hits


def apply_map(root: Path, mapping: dict[str, str], keep: set[str]) -> dict[str, int]:
    changed: dict[str, int] = {}
    for rel in referrers(root, list(mapping), keep):
        p = root / rel
        text = p.read_text(encoding="utf-8")
        new, total = text, 0
        for old, dst in mapping.items():
            total += new.count(old)
            new = new.replace(old, dst)
        if rel.endswith(".json"):
            json.loads(new)  # never write a broken JSON file
        p.write_text(new, encoding="utf-8")
        changed[rel] = total
    return changed


def duplicate_list_items(root: Path, rels: list[str], values: set[str] | None = None) -> list[str]:
    """After retargeting two paths onto one, a JSON string list may hold duplicates."""
    found: list[str] = []

    def walk(node, where, rel):
        if isinstance(node, list):
            strs = [x for x in node if isinstance(x, str)]
            dup = {x for x in strs if strs.count(x) > 1}
            if dup and (values is None or dup & values):
                found.append(f"{rel}:{where}")
            for i, x in enumerate(node):
                walk(x, f"{where}[{i}]", rel)
        elif isinstance(node, dict):
            for k, v in node.items():
                walk(v, f"{where}.{k}", rel)

    for rel in rels:
        if rel.endswith(".json"):
            walk(json.loads((root / rel).read_text(encoding="utf-8")), "$", rel)
    return found


def _parse_map(args: list[str]) -> tuple[dict[str, str], set[str]]:
    keep, pairs, i = set(), [], 0
    while i < len(args):
        if args[i] == "--keep":
            i += 1
            while i < len(args) and not args[i].startswith("--") and "=" not in args[i]:
                keep.add(args[i])
                i += 1
            continue
        pairs.append(args[i])
        i += 1
    return dict(a.split("=", 1) for a in pairs), keep


def _parse_paths(args: list[str]) -> tuple[list[str], set[str]]:
    keep, paths, i = set(), [], 0
    while i < len(args):
        if args[i] == "--keep":
            i += 1
            while i < len(args) and not args[i].startswith("--"):
                keep.add(args[i])
                i += 1
            continue
        paths.append(args[i])
        i += 1
    return paths, keep


def selftest() -> int:
    with tempfile.TemporaryDirectory() as td:
        r = Path(td)
        (r / "docs").mkdir()
        (r / "archive").mkdir()
        (r / "docs/old.md").write_text("old", encoding="utf-8")
        (r / "docs/new.md").write_text("new", encoding="utf-8")
        (r / "a.json").write_text(json.dumps({"x": ["docs/old.md", "docs/new.md"]}), encoding="utf-8")
        (r / "archive/h.md").write_text("docs/old.md", encoding="utf-8")
        (r / "note.md").write_text("see docs/old.md", encoding="utf-8")
        assert set(referrers(r, ["docs/old.md"], set())) == {"a.json", "note.md"}, "plan"
        assert set(referrers(r, ["docs/old.md"], {"note.md"})) == {"a.json"}, "keep"
        changed = apply_map(r, {"docs/old.md": "docs/new.md"}, set())
        assert changed == {"a.json": 1, "note.md": 1}, changed
        assert duplicate_list_items(r, ["a.json"], {"docs/new.md"}) == ["a.json:$.x"], "dup detect"
        assert duplicate_list_items(r, ["a.json"], {"other"}) == [], "dup filter"
        assert not referrers(r, ["docs/old.md"], set()), "guard clean"
    print("ref_retarget selftest PASS")
    return 0


def main(argv: list[str]) -> int:
    if not argv or argv[0] == "--selftest":
        return selftest()
    cmd, rest = argv[0], argv[1:]
    if cmd == "plan" and rest and not any("=" in a for a in rest if not a.startswith("--")):
        paths, keep = _parse_paths(rest)  # bare paths: list referrers only
        print(json.dumps(referrers(ROOT, paths, keep | set(paths)), ensure_ascii=False, indent=1))
        return 0
    if cmd in ("plan", "apply"):
        mapping, keep = _parse_map(rest)
        if cmd == "plan":
            hits = referrers(ROOT, list(mapping), keep)
            print(json.dumps(hits, ensure_ascii=False, indent=1))
            return 0
        changed = apply_map(ROOT, mapping, keep)
        dups = duplicate_list_items(ROOT, [r for r in changed if r.endswith(".json")], set(mapping.values()))
        print(json.dumps({"changed": changed, "duplicate_lists": dups}, ensure_ascii=False, indent=1))
        return 1 if dups else 0
    if cmd in ("guard", "delete"):
        paths, keep = _parse_paths(rest)
        keep |= set(paths)  # files being removed together do not count as referrers
        hits = referrers(ROOT, paths, keep)
        if hits:
            print(json.dumps({"BLOCK": "referrers remain", "hits": hits}, ensure_ascii=False, indent=1))
            return 1
        if cmd == "delete":
            for p in paths:
                (ROOT / p).unlink()
                print("deleted", p)
        else:
            print("GUARD PASS: no live referrers")
        return 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
