#!/usr/bin/env python3
"""workflow_audit：.github/workflows 的機械審計（R3d9 S2-e；取代人工判斷「哪些 workflow 要封存」）。

規則（全部可確定，退出碼 0＝PASS、1＝FAIL）：
  W1 每個 workflow 只能手動觸發（on 區塊含 workflow_dispatch，且無 push／pull_request／schedule／workflow_run）。
  W2 workflow 內提到的 repo 路徑（P1-Central-Control/、tools/ 開頭的 .py／.json）必須存在，或位於 workflow 自己寫出的輸出路徑（--out 類）。
  W3 不得指向 archive/ 內的路徑（指向封存物＝該 workflow 應一併封存）。
用法：python3 tools/workflow_audit.py [root]；python3 tools/workflow_audit.py --selftest
"""
from __future__ import annotations

import json
import re
import sys
import tempfile
from pathlib import Path

PATH_RE = re.compile(r"(?:P1-Central-Control/|tools/)[\w./\-]+\.(?:py|json)")
AUTO = ("push:", "pull_request:", "schedule:", "workflow_run:")


def on_block(text: str) -> str:
    m = re.search(r"^on:\s*\n((?:[ \t]+.*\n|\n)+)", text, re.M)
    if m:
        return m.group(1)
    m = re.search(r"^on:.*$", text, re.M)
    return m.group(0) if m else ""


def audit(root: Path) -> dict:
    findings, files = [], sorted((root / ".github" / "workflows").glob("*.yml"))
    for wf in files:
        text = wf.read_text(encoding="utf-8")
        name = wf.name
        # 只看觸發區塊的鍵（行首縮排後的 key:），不把 inputs 內說明文字當觸發
        keys = {ln.strip() for ln in on_block(text).splitlines() if re.match(r"^\s{0,2}\S", ln)}
        if "workflow_dispatch:" not in keys and "workflow_dispatch" not in on_block(text):
            findings.append({"w": "W1", "file": name, "why": "缺 workflow_dispatch"})
        for a in AUTO:
            if a in keys:
                findings.append({"w": "W1", "file": name, "why": f"含自動觸發 {a}"})
        for p in sorted(set(PATH_RE.findall(text))):
            if "/archive/" in p:
                findings.append({"w": "W3", "file": name, "why": f"指向封存路徑 {p}"})
            elif not (root / p).exists() and "/research/" not in p:
                findings.append({"w": "W2", "file": name, "why": f"路徑不存在 {p}"})
    return {"status": "PASS" if not findings else "FAIL", "workflows": len(files), "findings": findings}


def selftest() -> int:
    with tempfile.TemporaryDirectory() as d:
        r = Path(d)
        (r / ".github/workflows").mkdir(parents=True)
        (r / "tools").mkdir()
        (r / "tools/a.py").write_text("x", encoding="utf-8")
        good = "name: g\non:\n  workflow_dispatch:\njobs: {}\nrun: python3 tools/a.py\n"
        (r / ".github/workflows/g.yml").write_text(good, encoding="utf-8")
        assert audit(r)["status"] == "PASS"
        bad = "name: b\non:\n  workflow_dispatch:\n  push:\njobs: {}\nrun: python3 tools/missing.py P1-Central-Control/archive/x.py\n"
        (r / ".github/workflows/b.yml").write_text(bad, encoding="utf-8")
        res = audit(r)
        kinds = {f["w"] for f in res["findings"]}
        assert res["status"] == "FAIL" and kinds == {"W1", "W2", "W3"}, res
        (r / ".github/workflows/b.yml").write_text("name: b\non:\n  schedule:\n    - cron: '0 0 * * *'\n", encoding="utf-8")
        res = audit(r)
        assert {f["w"] for f in res["findings"]} == {"W1"}, res
    print("workflow_audit selftest PASS")
    return 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    root = Path(next((a for a in sys.argv[1:] if not a.startswith("-")), ".")).resolve()
    res = audit(root)
    print(json.dumps(res, ensure_ascii=False, indent=2))
    return 0 if res["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
