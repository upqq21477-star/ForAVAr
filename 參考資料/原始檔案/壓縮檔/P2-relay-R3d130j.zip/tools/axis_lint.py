#!/usr/bin/env python3
"""axis_lint: 主軸文檔的機械檢查(只用標準函式庫)。

系統主軸: python3 tools/axis_lint.py <axis.md> <blueprint.md>
  位元組預算、樹深度與節點數、節點名稱為藍圖標題原文、§指標存在、
  無規範性用語、引用檔名見於藍圖。
專案主軸: python3 tools/axis_lint.py --project <AXIS.md>
  一句話目標、焦點＝主軸鏈最深一層、有非目標、修改紀錄類型合法且確認者為使用者。
"""
import re
import sys

SYS_MAX_BYTES, SYS_MAX_DEPTH, SYS_MAX_CHILDREN = 4096, 3, 9
PRJ_MAX_BYTES, PRJ_MAX_CHAIN = 3072, 6
BANNED = re.compile(r"必須|不得|不可|禁止|應該|MUST|SHALL")
CHANGE_TYPES = {"收斂", "轉向", "擴張"}


def _report(results):
    ok = all(r[0] for r in results)
    for passed, name, note in results:
        print(f"[{'PASS' if passed else 'FAIL'}] {name} {note}".rstrip())
    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


def lint_system(axis_p, bp_p):
    axis = open(axis_p, encoding="utf-8").read()
    bp = open(bp_p, encoding="utf-8").read()
    heads = [l.lstrip("# ").strip() for l in bp.splitlines() if re.match(r"#{2,4} ", l)]
    sec_nums = {m.group(1) for h in heads if (m := re.match(r"(\d+(?:\.\d+)?)[ .]", h))}
    res = []
    n = len(axis.encode("utf-8"))
    res.append((n <= SYS_MAX_BYTES, "位元組預算", f"{n}/{SYS_MAX_BYTES} B"))
    m = re.search(r"```text\n(.*?)```", axis, re.S)
    tree = m.group(1).splitlines()[1:] if m else []
    depths = [(len(l) - len(l.lstrip("│ "))) // 4 + 1 for l in tree if l.strip()]
    deepest = max(depths) if depths else 0
    res.append((0 < deepest <= SYS_MAX_DEPTH, "樹深度", f"最深 {deepest} 層(上限 {SYS_MAX_DEPTH}+根)"))
    top = sum(1 for d in depths if d == 1)
    res.append((top <= SYS_MAX_CHILDREN, "第一層節點數", f"{top}(上限 {SYS_MAX_CHILDREN})"))
    for l in tree:
        name = re.sub(r"^[│├└─ ]+", "", l).strip()
        if name:
            base = name.split("（")[0].strip()
            res.append((any(base in h for h in heads), "節點為藍圖標題原文", base))
    refs = set(re.findall(r"§(\d+(?:\.\d+)?)", axis))
    miss = sorted(r for r in refs if r not in sec_nums)
    res.append((not miss, "§指標存在於藍圖", f"缺: {miss}" if miss else f"{len(refs)} 個"))
    bad = BANNED.findall(axis)
    res.append((not bad, "無規範性用語", f"命中: {bad}" if bad else ""))
    for f in re.findall(r"`([^`]+\.(?:json|md))`", axis):
        res.append((f in bp, "引用檔名見於藍圖", f))
    return _report(res)


def lint_project(path):
    t = open(path, encoding="utf-8").read()
    res = []
    n = len(t.encode("utf-8"))
    res.append((n <= PRJ_MAX_BYTES, "位元組預算", f"{n}/{PRJ_MAX_BYTES} B"))
    res.append((bool(re.search(r"^> .+", t, re.M)), "一句話目標", ""))
    chain_m = re.search(r"## 主軸鏈\n+```text\n(.*?)```", t, re.S)
    chain = []
    if chain_m:
        chain = [re.sub(r"^[ └─├│]+", "", l).split("←")[0].strip() for l in chain_m.group(1).splitlines() if l.strip()]
    res.append((1 <= len(chain) <= PRJ_MAX_CHAIN, "主軸鏈層數", f"{len(chain)}(上限 {PRJ_MAX_CHAIN})"))
    focus = re.search(r"^焦點：(.+)$", t, re.M)
    res.append((bool(focus) and bool(chain) and focus.group(1).strip() == chain[-1], "焦點＝鏈最深一層",
                f"焦點={focus.group(1).strip() if focus else None} 最深={chain[-1] if chain else None}"))
    ng = re.search(r"## 非目標[^\n]*\n+(.*?)(?=\n## |\Z)", t, re.S)
    res.append((bool(ng) and any(l.strip().startswith("-") for l in ng.group(1).splitlines()), "有非目標", ""))
    log = re.search(r"## 修改紀錄[^\n]*\n+(.*?)(?=\n## |\Z)", t, re.S)
    rows = [l for l in (log.group(1).splitlines() if log else []) if l.strip().startswith("|") and "---" not in l][1:]
    res.append((bool(rows), "有修改紀錄", f"{len(rows)} 行"))
    for r in rows:
        cells = [c.strip() for c in r.strip().strip("|").split("|")]
        ok = len(cells) >= 4 and cells[1] in CHANGE_TYPES and cells[2] == "使用者" and bool(cells[3])
        res.append((ok, "紀錄：類型合法、確認者＝使用者、有原因", r.strip()[:60]))
    return _report(res)


def main(argv):
    if len(argv) == 2 and argv[0] == "--project":
        return lint_project(argv[1])
    if len(argv) == 2 and not argv[0].startswith("--"):
        return lint_system(argv[0], argv[1])
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
