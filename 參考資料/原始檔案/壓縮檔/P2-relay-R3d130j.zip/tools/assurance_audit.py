#!/usr/bin/env python3
"""P2 assurance_audit — Outcome Assurance and Process Assurance stay separate (OPEN-ISSUES 019c; stdlib only; R3d10 R3g).

An acceptance record must carry two independent judgements
  outcome  {producer, verdict, level, evidence_ref}   produced by a Verifier role   (is the result right?)
  process  {producer, verdict, level, evidence_ref}   produced by a Gate / trace check (were the rules followed?)
  claimed_level                                        what the Acceptance Authority states
Rules
  AS1  both judgements present, each with producer, verdict (PASS|FAIL|UNKNOWN), level on the ladder, non-empty evidence_ref.
  AS2  outcome.producer != process.producer (one party cannot grade both questions).
  AS3  claimed_level <= min(outcome.level, process.level) on the ladder (no automatic promotion).
  AS4  claimed verdict PASS only when outcome.verdict == PASS and process.verdict == PASS; any FAIL/UNKNOWN => not PASS.
  AS5  a PASS at PROGRAM_EXECUTED_PASS needs `exit_code == 0` in both evidence records.
Ladder: NOT_EXECUTED < IMPLEMENTED_UNVERIFIED < SIMULATED_PASS < PROGRAM_EXECUTED_PASS
Usage: python3 tools/assurance_audit.py [--selftest] [record.json]      exit 0 = PASS
"""
from __future__ import annotations

import json
import sys

LADDER = ["NOT_EXECUTED", "IMPLEMENTED_UNVERIFIED", "SIMULATED_PASS", "PROGRAM_EXECUTED_PASS"]
VERDICTS = ("PASS", "FAIL", "UNKNOWN")


def check_record(rec: dict) -> list[dict]:
    f: list[dict] = []
    sides = {}
    for name in ("outcome", "process"):
        s = rec.get(name)
        if not isinstance(s, dict):
            f.append({"rule": "AS1", "error": f"{name} judgement missing"})
            continue
        if not s.get("producer") or s.get("verdict") not in VERDICTS or s.get("level") not in LADDER or not s.get("evidence_ref"):
            f.append({"rule": "AS1", "error": f"{name} judgement incomplete"})
            continue
        sides[name] = s
    if len(sides) < 2:
        return f
    o, p = sides["outcome"], sides["process"]
    if o["producer"] == p["producer"]:
        f.append({"rule": "AS2", "error": "same producer for outcome and process"})
    claimed = rec.get("claimed_level")
    if claimed not in LADDER:
        f.append({"rule": "AS3", "error": "claimed_level missing or off the ladder"})
    elif LADDER.index(claimed) > min(LADDER.index(o["level"]), LADDER.index(p["level"])):
        f.append({"rule": "AS3", "error": "claimed_level exceeds the lower of outcome/process level", "claimed": claimed})
    if rec.get("claimed_verdict") == "PASS" and not (o["verdict"] == "PASS" and p["verdict"] == "PASS"):
        f.append({"rule": "AS4", "error": "PASS claimed while a side is not PASS"})
    if rec.get("claimed_verdict") == "PASS" and claimed == "PROGRAM_EXECUTED_PASS":
        for name, s in (("outcome", o), ("process", p)):
            if s.get("exit_code") != 0:
                f.append({"rule": "AS5", "error": f"{name} lacks exit_code 0 for a PROGRAM_EXECUTED_PASS claim"})
    return f


def _good() -> dict:
    return {"outcome": {"producer": "VERIFIER", "verdict": "PASS", "level": "PROGRAM_EXECUTED_PASS", "evidence_ref": "e/o.json", "exit_code": 0},
            "process": {"producer": "GATE", "verdict": "PASS", "level": "PROGRAM_EXECUTED_PASS", "evidence_ref": "e/p.json", "exit_code": 0},
            "claimed_level": "PROGRAM_EXECUTED_PASS", "claimed_verdict": "PASS"}


def selftest() -> int:
    def mut(fn):
        r = _good()
        fn(r)
        return check_record(r)

    cases = {
        "good": check_record(_good()) == [],
        "no_outcome": any(x["rule"] == "AS1" for x in mut(lambda r: r.pop("outcome"))),
        "no_process": any(x["rule"] == "AS1" for x in mut(lambda r: r.pop("process"))),
        "no_evidence": any(x["rule"] == "AS1" for x in mut(lambda r: r["process"].update(evidence_ref=""))),
        "same_producer": any(x["rule"] == "AS2" for x in mut(lambda r: r["process"].update(producer="VERIFIER"))),
        "promotion": any(x["rule"] == "AS3" for x in mut(lambda r: r["process"].update(level="SIMULATED_PASS"))),
        "pass_over_fail": any(x["rule"] == "AS4" for x in mut(lambda r: r["process"].update(verdict="FAIL"))),
        "pass_over_unknown": any(x["rule"] == "AS4" for x in mut(lambda r: r["outcome"].update(verdict="UNKNOWN"))),
        "no_exit_code": any(x["rule"] == "AS5" for x in mut(lambda r: r["outcome"].update(exit_code=1))),
        "off_ladder": any(x["rule"] == "AS3" for x in mut(lambda r: r.update(claimed_level="OBSERVED"))),
    }
    bad = [k for k, v in cases.items() if not v]
    print("assurance_audit selftest", "PASS" if not bad else f"FAIL {bad}", f"({len(cases)} cases)")
    return 0 if not bad else 1


ACCEPTANCE_RECORDS = ("P1-Central-Control/evidence/r5-trace/R5-acceptance.json",)  # batch acceptance records audited by --all (R3d12y)


if __name__ == "__main__":
    if "--all" in sys.argv:
        bad = [x for r in ACCEPTANCE_RECORDS for x in check_record(json.loads(open(r, encoding="utf-8").read()))]
        for x in bad:
            print(x)
        print("assurance_audit --all", "PASS" if not bad else "FAIL", len(ACCEPTANCE_RECORDS), "record(s)")
        sys.exit(0 if not bad else 1)
    if "--selftest" in sys.argv:
        sys.exit(selftest())
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print("usage: assurance_audit.py [--selftest] record.json")
        sys.exit(2)
    found = check_record(json.loads(open(args[0], encoding="utf-8").read()))
    for x in found:
        print(x)
    print("assurance_audit", "PASS" if not found else "FAIL")
    sys.exit(0 if not found else 1)
