#!/usr/bin/env python3
"""P2 startup_budget — deterministic startup read-set size (UTF-8 bytes), two modes (R4L-M1-S1; stdlib only).

Degraded mode (no/STALE Brief): Skill + HOT summary of Current (STARTUP route fields) + read wrappers; target 18 KiB, hard 20 KiB.
Brief mode: Skill + Brief + wrappers; limit 16 KiB, WARN until batch R4L is DONE, then HARD.
  python3 tools/startup_budget.py [--brief <file>] [--selftest]
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
SKILL = ".agents/skills/p2-brain/SKILL.md"
LIMITS = {"degraded_target": 18432, "degraded_hard": 20480, "brief_limit": 16384}


def wrap(label: str) -> int:
    return len(f"\n===== {label} =====\n".encode("utf-8"))


def items_degraded(root: Path = ROOT) -> list[tuple[str, int, str]]:
    import librarian

    cfg = json.loads((root / "P1-Central-Control/brief_slots.json").read_text(encoding="utf-8"))
    cur = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    hot, _ = librarian.hot_summary(cur, cfg["routes"]["STARTUP"]["hot_fields"], cap=10**9)
    skill = (root / SKILL).read_bytes()
    return [("Skill", len(skill), "啟動規則，無法再縮（R1-S3-M2／R4L-S3-M3b 才能改寫）"),
            ("Current HOT 摘要", librarian.jbytes(hot), "STARTUP 路由列出的 Current 欄位"),
            ("讀取包裝", wrap(SKILL) + wrap("P1-CURRENT.json#HOT"), "標頭／分隔文字")]


def items_brief(brief_file: Path, root: Path = ROOT) -> list[tuple[str, int, str]]:
    return [("Skill", len((root / SKILL).read_bytes()), "啟動規則"),
            ("Brief", len(brief_file.read_bytes()), "每任務 Brief，上限 8 KiB"),
            ("讀取包裝", wrap(SKILL) + wrap(str(brief_file)), "標頭／分隔文字")]


def evaluate(mode: str, items: list[tuple[str, int, str]], brief_hard: bool = False) -> dict:
    total = sum(n for _, n, _ in items)
    errors: list[str] = []
    notes: list[str] = []
    if mode == "degraded":
        if total > LIMITS["degraded_hard"]:
            errors.append(f"DEGRADED_OVER_HARD:{total}>{LIMITS['degraded_hard']}")
        if total > LIMITS["degraded_target"]:
            notes += [f"unreducible {name}={n}B ({why})" for name, n, why in items]
    elif total > LIMITS["brief_limit"]:
        (errors if brief_hard else notes).append(f"BRIEF_OVER_LIMIT:{total}>{LIMITS['brief_limit']}")
    return {"mode": mode, "total": total, "items": {k: n for k, n, _ in items}, "errors": errors, "notes": notes}


def r4l_done(root: Path = ROOT) -> bool:
    reg = json.loads((root / "P1-Central-Control/policy/batch_acceptance.v1.0.json").read_text(encoding="utf-8"))
    return any(b["batch_id"] == "R4L" and b["status"] == "DONE" for b in reg["batches"])


def text_errors(root: Path = ROOT) -> list[str]:
    """R4L-S3-M3b: startup text rules (Skill + activation interface + brief_slots.former_startup_list), STATIC_CHECK.
    Skipped when the three files are not all present (isolated fixtures)."""
    import startup_text_check as stc
    f = [root / ".agents/skills/p2-brain/SKILL.md", root / "docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md",
         root / "P1-Central-Control/brief_slots.json"]
    if not all(x.is_file() for x in f):
        return []
    return stc.check(f[0].read_text(encoding="utf-8"), f[1].read_text(encoding="utf-8"),
                     json.loads(f[2].read_text(encoding="utf-8")), root)


def check(root: Path = ROOT) -> list[dict]:
    """precheck HARD: degraded mode must stay <= 20 KiB; Brief mode HARD once R4L is DONE (only when a Brief file exists);
    startup text rules present (M3b)."""
    out = [{"error": e} for e in evaluate("degraded", items_degraded(root))["errors"]]
    out += [{"error": "STARTUP_TEXT:" + e} for e in text_errors(root)]
    briefs = sorted((root / "P1-Central-Control/briefs").glob("*.json")) if (root / "P1-Central-Control/briefs").is_dir() else []
    for b in briefs[-1:]:
        out += [{"error": e} for e in evaluate("brief", items_brief(b, root), r4l_done(root))["errors"]]
    return out


def selftest() -> int:
    bad = 0
    ok_items = [("Skill", 6000, "x"), ("HOT", 6000, "x")]
    if evaluate("degraded", ok_items)["errors"] or evaluate("degraded", ok_items)["notes"]:
        bad += 1
    over_target = [("Skill", 9000, "x"), ("HOT", 10000, "x")]
    r = evaluate("degraded", over_target)
    if r["errors"] or len(r["notes"]) != 2:
        bad += 1
    if not evaluate("degraded", [("Skill", 12000, "x"), ("HOT", 9000, "x")])["errors"]:
        bad += 1
    big = [("Skill", 9000, "x"), ("Brief", 9000, "x")]
    if evaluate("brief", big, brief_hard=False)["errors"] or not evaluate("brief", big, brief_hard=True)["errors"]:
        bad += 1
    if not evaluate("degraded", [("a", 1, "x")], brief_hard=True)["total"] == 1:
        bad += 1
    print("startup_budget selftest:", "PASS" if bad == 0 else f"FAIL({bad})")
    return 1 if bad else 0


def main() -> int:
    if "--selftest" in sys.argv:
        return selftest()
    r = evaluate("degraded", items_degraded())
    print(f"降級模式：{r['total']} B（目標 {LIMITS['degraded_target']}／上限 {LIMITS['degraded_hard']}）", r["items"], r["errors"] or "OK")
    if "--brief" in sys.argv:
        f = Path(sys.argv[sys.argv.index("--brief") + 1])
        b = evaluate("brief", items_brief(f), r4l_done())
        print(f"Brief 模式：{b['total']} B（上限 {LIMITS['brief_limit']}）", b["items"], b["errors"] or b["notes"] or "OK")
    return 1 if r["errors"] else 0


if __name__ == "__main__":
    sys.exit(main())
