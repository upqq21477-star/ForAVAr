# P2｜通用 AI 工程大腦與可重建系統

<!-- P1-CURRENT-PROJECTION:START -->
> ## Current Projection
> **唯一 Current Authority：** P1-CURRENT.json
> **目前 Active Work：** P1-Central-Control/progress/P2-B1-B8.work.json
> **Current Stage：** P2-B1-B8-CODE-FIRST / IN_PROGRESS / active slice P2-B1-B8-CODE-FIRST / next slice None
> **Runtime Truth：** INCOMPLETE
> **最新 Runtime Observation：** run None / attempt None / NOT_EXECUTED / step evidence False
> **Projection Rule：** README 只作 Human Projection；與 P1-CURRENT.json 衝突時，以 Current 為準。
<!-- P1-CURRENT-PROJECTION:END -->
> **接力更新（R0 起）：** 批次接力，每場一個新對話。**企劃（唯一）：** `docs/plans/P2-Relay-Update-Plan.md`（PLANNING_INPUT，R3 納入唯一藍圖前不構成施工準則）；**交接（唯一）：** `docs/handoffs/HANDOFF.md`（由 `handoff.data.json` 生成）；**未結問題（唯一）：** `docs/audit/OPEN-ISSUES.md`。動工前先 `python3 tools/precheck.py`；大檔只用 `python3 tools/slice.py` 讀；失敗基線見 `tools/baseline_failing_tests.txt`（只准縮小）。

## 本專案用途

P2 是 P1 的升級與最終替代者，以 P1-integrated-r48 作為暫時程式相容基線，只吸收對 P2 仍有用的能力。P1 不會成為 P2 的永久架構依賴。本 repo 的 **P2 目標架構**、**目前實作狀態**與**證據層級**必須分開。

## 唯一權威與文件分工

- **目前執行狀態：** `P1-CURRENT.json`。這是繼承的 r48 執行狀態權威；在完成整體命名遷移前，不建立第二份 Current。
- **可重建程式組成：** `P1-Central-Control/canonical/blueprint.json` 與 `reconstruction_input_set.json`。它們只定義程式元件歸屬、建置輸入和完整性，不等於 P2 的目標架構。
- **P2 唯一施工藍圖：** Current 的 `p2_target_blueprint_ref` 唯一指向 `docs/architecture/P2-System-Blueprint-v1.0.md`（現行內容 v4.0；同一路徑原位迭代）。Current 的泛用 `blueprint` 欄位仍只指 P1 程式重建藍圖，不得與 P2 施工指標混用。會議討論、研究、Roadmap 和臨時方案均為規劃素材；可重用規則先蒸餾入唯一藍圖，其他文件只呈現狀態、順序或技術細節。
- **功能實作與證據：** `docs/plans/P2-Feature-Triage.md`。
- **後續工作順序：** `docs/plans/P2-Relay-Update-Plan.md`。
- **最低操作閉環驗收規格：** `docs/plans/P2-Feature-Triage.md`。
- **最低運行模式契約：** `docs/architecture/P2-Run-Mode-Contract-v1.0.md`；BASELINE 是 AI 對話＋GitHub，程式執行／外部整合是可選升級。
- **原企劃符合性對照：** `docs/audit/OPEN-ISSUES.md`。
- **最低運行標記 Run 001：** `docs/audit/OPEN-ISSUES.md`；只證明限定的文件操作閉環，不代表程式測試或 Runtime 已通過。
- **原企劃對照與未結缺陷：** `docs/audit/OPEN-ISSUES.md`、`docs/audit/OPEN-ISSUES.md`；AUDIT-DEFECT-001–019 共 19 項靜態修補均為 `PATCHED_UNVERIFIED`（未執行驗證），`OPEN-ISSUES.md` 是唯一清單。
- **P2 原生思考核心／能力重構規劃：** `docs/plans/P2-Feature-Triage.md`；P2-B0 的設計基線已跨文件對齊；其程式整合仍未驗證。進度與下一步以 `docs/handoffs/HANDOFF.md` 為唯一權威（本條為凍結舊投影，不再更新）。文件更新不代表相應程式已實作或驗收。
- **語意意圖理解與最小化澄清（P2-F24）：** 已列入 P2 唯一目標藍圖 §4.1，主責 Brain／Cognitive Decision；目前為 DESIGN_SPECIFIED_UNVERIFIED，須以功能矩陣和符合性報告為準。互動選項屬可替換呈現層，不能成為最低運行模式前置。
- **原始企劃完整性與呈現方式稽核（2026-10-10）：** `docs/audit/OPEN-ISSUES.md` §8–§11；逐項對照原參考 ZIP 的七份 Markdown、八大核心、跨核心不變量、20 個提示詞標籤、15 項溝通規則、故意失敗測試及 C4／arc42／GDC／Microsoft／MIT 的層疊呈現方法。這是設計完整性稽核，不等於程式驗收。
- **適應式呈現與圖表即程式碼（P2-F27）：** 已納入唯一藍圖 §4.1，並在功能矩陣、符合性檢查、路線圖與測試策略中對齊。複雜架構／流程使用可維護的 Mermaid 源碼；所有視圖必須回溯至權威契約、Current、程式入口或已標示的設計假設，且保留 UNKNOWN／NOT_WIRED／NOT_EXECUTED 狀態。簡單對話仍以文字為預設。呈現選擇器、正式 Schema 欄位、圖表驗證程式與 Runtime 尚未實作／驗證，規劃見 `參考資料/P2-適應式呈現與可執行圖表規劃-v1.0.md`。
- **系統性變更分類與職權路由（P2-F28）：** 已作為唯一藍圖 v4.0 的常設規則，而非本輪一次性調整。Brain 負責分類 ONE_OFF／LOCAL_RULE／SYSTEMIC_CAPABILITY／ARCHITECTURE_INVARIANT；Blueprint Engineering 維護唯一藍圖及受影響視圖；Evolution 蒸餾可重用規則；Governance 管理高影響授權；Central 僅機械交接；Assurance 獨立核對。能力分類為 SYSTEMIC_CAPABILITY；每次變更先分類、同類情境重用已接受規則則是 ARCHITECTURE_INVARIANT。正式 Planner／Capability Card、Schema 與 caller 尚未接線，後續需在目前 B2.2 收口後另立工作單元。詳見 `參考資料/P2-系統性變更分類與職權路由規劃-v1.0.md`。
- **Code-first 執行與蒸餾操作包（P2-B2.2）：** 依唯一藍圖 v4.0 §14 與 `docs/plans/P2-Code-First-Execution-and-Distilled-Operational-Pack-v1.0.md` 推進。F25 Operational Pack Builder 已實作明列來源讀取、Current／Active Work／Active Construction 綁定、來源與 Context 計量、指紋驗證、輸出路徑限制及獨立 Verify；Pack Schema `$id` 與 Builder 輸出已一致升至 `1.1`，舊 `1.0` Pack 必須拒絕；request schema 仍為 `1.0`。F21 Brain 模式控制器已由 Central 的 `COGNITIVE_TRANSITION` 接線，另有 15 項 Controller 測試與 5 項 Runtime Interface 測試原始碼。官方 Runner 現有七套測試，預期數為 11／18／35／3／15／15／5，共 102 個方法；Runner 報告契約為 `2.1`。最新 HEAD 的正式測試仍是 `NOT_EXECUTED`。歷史 commit `3c6e92ebca1501cfdad416391b5a953f706d8a62` 曾執行 82 項，當時 Pack suite 有 3 個斷言失敗；其後修補未在最新 HEAD 重跑，故不可宣稱 PASS。唯一 canonical Active Pack 尚未生成，F25 的正式端到端 caller 仍未接線；F21 的程式接線不等於已驗收。GitHub Actions 執行路徑維持封存；只能在核實免費額度、工作目錄乾淨及 Python 3.11 環境後，使用既有執行路徑進行最終 102 項 Simulation，且只有實際 `SIMULATION_PASS`／exit 0 才能進 Integration。
- **交接入口：** `docs/handoffs/HANDOFF.md`（生成檢視；資料來源 `docs/handoffs/handoff.data.json`）。
- **企劃原始資料：** `參考資料/企劃/`。企劃是設計輸入，不可覆寫程式、Current 或驗收證據。

## 核心責任

`Brain 想 · Role 做 · Runtime 記 · Central 搬`

Brain 不只理解問題和產生計畫；它必須先評估目標、現況、環境和接受條件，選擇最合適的架構、工作方式及運行模式，並在重大變化或失敗時重新評估。Brain 的語意決策與 Central 的機械協調分開；施工者交回結果和證據，由獨立 Assurance／Verifier 按事先定義的條件驗收。思考環境與施工／執行環境分隔，獨立系統以最小充分、契約化交接口交換資料。錯誤先區分事實、根因假說和確認根因，再將可重用的機制修正蒸餾進架構、契約、能力或必要測試；Current 只留現況，不堆積完整除錯歷史。能力以 Capability／Method／Pattern 按需組裝，職責不自動等於永久 Role。


## 資料最小化與 P1 能力吸收

- 長期資料只保留唯一 Current、現行藍圖與必要契約、有效能力、目前資料位置、仍開啟的未知／阻塞，以及支撐目前重要聲明所需的最小證據。
- 不以完整對話、完整 Trace、逐次掃描日誌、路徑搬動歷史、永久全庫呼叫圖或已結案問題歷程作為常駐資料。
- 路徑只記目前有效位置；發生 UNKNOWN、引用失效或當前工作受阻時，才針對相關範圍調查。
- P1 的功能必須經過必要性、功能重疊、維護成本、上下文成本、可替代性與驗收方式判斷後，才納入 P2。既存不等於必須保留。
- 臨時研究／掃描／實驗先蒸餾有用結論；已處理且不再有用的材料移出活動資料。GitHub 版本歷史只按需查閱，不複製成另一套歷史庫。

## 重要狀態限制

- r48 的 M33-CLOSE 是 `VERIFIED / SIMULATION_ONLY`，不代表真實 Brain 或真實角色 session 已運行。
- `OBSERVED_RUNTIME` 尚無可支持 P2 整體功能已運行的證據。
- 模擬、單元測試、乾淨重建、真實 Runtime 是不同證據層級，不可互相替代。
- **最低操作標準是 AI 對話＋GitHub 儲存庫。** 不要求 API、其他外部軟體、命令列、Python 執行環境或 GitHub Actions。AI 對話負責讀取理解、規劃、產出修改與檢查；GitHub 負責保存檔案、版本與可回讀的變更。

## P2 對話指令與 Codex Skill

- **啟動：** 輸入「！P2啟動」；對話應依最新 Current 與工作包初始化，而不是只回覆啟動宣告。
- **指令目錄：** 輸入「！幫助」列出全部正式對話指令；唯一指令定義位於 `docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md`。
- **Codex 相容 Skill：** `.agents/skills/p2-brain/SKILL.md`，遵循標準 SKILL.md 前置資料與 repo-local skill 目錄格式；`.agents/skills/p2-brain/agents/openai.yaml` 提供可選 UI 中繼資料。此 Skill 使用 Markdown 工作流程，現有可執行驗收核心維持 Python，不另建多語言執行框架。
- **能力與證據邊界：** Skill／指令介面讓工作方式可重用，不代表正式 Brain／Central caller 已接通，也不代表程式測試已執行。

## AI 對話＋GitHub 的最低工作方式

1. 讀取 P1-CURRENT.json、最新交接與本工作單元涉及的 GitHub 檔案。
2. 在 AI 對話內界定單一工作單元、輸入／輸出、接受條件、風險與失敗處理。
3. 透過可用的 GitHub 儲存介面提交完整檔案或差異；若無直接寫入能力，產出可直接貼入 GitHub 網頁的檔案內容，不要求 API、CLI 或其他軟體。
4. 從 GitHub 讀回新版本，以 commit SHA、檔案內容、引用一致性及反例檢查確認變更已保存。
5. 更新工作紀錄與交接，記下證據層級、未解風險和下一步；不得只靠對話中的「已完成」宣稱進度。

**證據界線：** AI 推理／靜態檢查不等於程式已執行。沒有實際執行輸出時，必須標記 NOT_EXECUTED_BASELINE_LIMIT 或 IMPLEMENTED_UNVERIFIED，不可聲稱 PROGRAM_EXECUTED_PASS 或 OBSERVED_RUNTIME。
