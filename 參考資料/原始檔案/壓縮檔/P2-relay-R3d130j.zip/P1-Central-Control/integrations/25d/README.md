# P1 ↔ 25D Domain Bridge

P1 owns global planning, routing, reporting and replanning.

25D owns its domain state, local validation and domain execution.

The bridge has only two directions:

P1 TaskPacket → 25D DomainController → P1 ResultPacket

25D → P1 is limited to a compact control projection for planning.

The committed 25D projection is a repository-level state summary. A browser session may expose a live projection through the 25D runtime, but P1 does not depend on browser-local state.

Current skill:
- ID: 25D.DOMAIN_CONTROLLER
- Version: 1.0
- Task contract: P1 TaskPacket 1.0
- Result contract: P1 ResultPacket 1.0
- Projection contract: 25D_CONTROL_PROJECTION/1.0

Domain boundary:
- P1 decides why/what/when.
- 25D decides how to execute and validate inside 25D.
- 25D does not directly call another domain.
- P1 does not directly mutate 25D internal state.

## GitHub Actions 回歸結果交接

外部 GitHub Actions 的 workflow / job 觀測先經由：

`P1-Central-Control/scripts/github_actions_result_adapter.py`

轉為 M7 可消費的 `REGRESSION_EXECUTION_RESULT`。特別規則是：

`job.conclusion=failure + steps=null` → `INCOMPLETE`

這表示 runner / job 啟動層沒有產生測試步驟證據，不能當作程式回歸失敗，更不能直接觸發 ROLLBACK。
