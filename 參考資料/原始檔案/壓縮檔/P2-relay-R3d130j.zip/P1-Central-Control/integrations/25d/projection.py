#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


SKILL_ID = "25D.DOMAIN_CONTROLLER"
SKILL_VERSION = "1.0"
PROJECTION_VERSION = "1.0"


class ProjectionError(ValueError):
    pass


def load_projection(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise ProjectionError(f"{path} 必須是 JSON object")
    return value


def validate_projection(projection: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    required = {
        "system_id",
        "projection_version",
        "controller_version",
        "projection_scope",
        "p1_bridge",
        "capabilities",
        "domain_boundary",
    }
    errors.extend(f"missing:{name}" for name in sorted(required - projection.keys()))

    if projection.get("system_id") != "25D":
        errors.append("invalid:system_id")
    if projection.get("projection_version") != PROJECTION_VERSION:
        errors.append("invalid:projection_version")
    if projection.get("projection_scope") != "DOMAIN":
        errors.append("invalid:projection_scope")

    bridge = projection.get("p1_bridge")
    if not isinstance(bridge, dict):
        errors.append("invalid:p1_bridge")
    else:
        if bridge.get("skill_id") != SKILL_ID:
            errors.append("invalid:p1_bridge.skill_id")
        if bridge.get("skill_version") != SKILL_VERSION:
            errors.append("invalid:p1_bridge.skill_version")

    capabilities = projection.get("capabilities")
    if not isinstance(capabilities, list) or not capabilities:
        errors.append("invalid:capabilities")

    boundary = projection.get("domain_boundary")
    if not isinstance(boundary, dict):
        errors.append("invalid:domain_boundary")
    else:
        if not isinstance(boundary.get("owns"), list):
            errors.append("invalid:domain_boundary.owns")
        if not isinstance(boundary.get("does_not_own"), list):
            errors.append("invalid:domain_boundary.does_not_own")

    return errors


def validate_projection_or_raise(projection: dict[str, Any]) -> None:
    errors = validate_projection(projection)
    if errors:
        raise ProjectionError("25D projection 驗證失敗: " + "; ".join(errors))
