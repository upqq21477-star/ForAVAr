#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import sys
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable

ROOT = Path(__file__).resolve().parents[3]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from external_skill_adapter import invoke_skill, validate_manifest  # noqa: E402
from packet_layer import build_attempt, build_task_packet as build_canonical_task_packet, validate_result_packet, validate_task_packet  # noqa: E402
from projection import load_projection, validate_projection, validate_projection_or_raise  # noqa: E402


SKILL_ID = "25D.DOMAIN_CONTROLLER"
SKILL_VERSION = "1.0"
PROJECTION_VERSION = "1.0"
DEFAULT_WORKFLOW_ID = "p1-25d-control"
DEFAULT_SEGMENT_ID = "25d-domain-control"
SUPPORTED_OBJECTIVES = {
    "REPORT_STATE",
    "GET_CAPABILITIES",
    "VALIDATE_HANDOFF",
}


class AdapterError(ValueError):
    pass


def normalize_objective(value: str) -> str:
    """正規化 objective：只做大小寫／空白／連字號與 `25D` 前綴正規化，然後必須落在白名單內。"""
    text = re.sub(r"[\s\-]+", "_", str(value).strip()).upper()
    text = re.sub(r"^25D_", "", text)
    if text not in SUPPORTED_OBJECTIVES:
        raise AdapterError(f"不支援的 25D objective: {value!r}")
    return text


def load_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        value = json.load(handle)
    if not isinstance(value, dict):
        raise AdapterError(f"{path} 必須是 JSON object")
    return value


def save_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )



def build_task_packet(
    *,
    objective: str,
    workflow_id: str = DEFAULT_WORKFLOW_ID,
    segment_id: str = DEFAULT_SEGMENT_ID,
    attempt_number: int = 1,
    input_refs: list[str] | None = None,
    requested_outputs: list[str] | None = None,
    context_target: int = 600,
    context_ceiling: int = 1200,
) -> dict[str, Any]:
    objective = normalize_objective(objective)
    segment = {
        "workflow_id": workflow_id,
        "segment_id": segment_id,
        "skill_id": SKILL_ID,
        "skill_version": SKILL_VERSION,
        "objective": objective,
        "input_refs": list(input_refs or []),
        "requested_outputs": list(requested_outputs or ["control_result"]),
        "constraints": ["RETURN_PACKET_ONLY"],
        "stop_condition": ["ONE_RESULT"],
        "failure_condition": ["INVALID_PACKET", "DOMAIN_BLOCK"],
        "input_scope": "25D_DOMAIN",
        "completion_contract": {"handoff_allowed": False},
        "acceptance_ref": "25D_ACCEPTANCE:control-bridge.1",
        "context_budget": {
            "target_context_budget": context_target,
            "hard_context_ceiling": context_ceiling,
            "estimated_total_context": context_target,
        },
        "retry_policy": {"max_attempts": 1, "retry_on": ["FAIL", "TIMEOUT"]},
        "timeout_ms": 5000,
        "dependency_refs": [],
    }
    attempt = build_attempt(segment, attempt_number=attempt_number)
    packet = build_canonical_task_packet(segment, attempt)
    validate_task_packet(packet)
    return packet


def to_25d_transport_task(packet: dict[str, Any]) -> dict[str, Any]:
    validate_task_packet(packet)
    result = deepcopy(packet)
    result["input_refs"] = [{"ref": ref} for ref in packet["input_refs"]]
    result["execution_record_ref"] = {"ref": packet["execution_record_ref"]}
    result["dependency_refs"] = [{"ref": ref} for ref in packet["dependency_refs"]]
    return result


def _ref_value(value: Any) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, dict) and isinstance(value.get("ref"), str):
        return value["ref"]
    raise AdapterError(f"無法解析 25D ref: {value!r}")


def normalize_25d_result(value: dict[str, Any]) -> dict[str, Any]:
    allowed = {
        "status",
        "decision_code",
        "output_refs",
        "unresolved",
        "evidence_refs",
        "provenance_refs",
        "observed_usage",
        "usage_observed",
    }
    unknown = sorted(set(value) - allowed - {
        "object_id",
        "kind",
        "schema_version",
        "content_hash",
        "result_id",
        "workflow_id",
        "segment_id",
        "attempt_id",
        "skill_id",
        "skill_version",
        "execution_record_ref",
    })
    if unknown:
        raise AdapterError("25D Result 包含未允許欄位: " + ",".join(unknown))

    result = {key: value[key] for key in allowed if key in value}
    for field in ("output_refs", "evidence_refs", "provenance_refs"):
        refs = result.get(field, [])
        if not isinstance(refs, list):
            raise AdapterError(f"{field} 必須是 array")
        result[field] = [_ref_value(ref) for ref in refs]

    if "unresolved" in result and not isinstance(result["unresolved"], list):
        raise AdapterError("unresolved 必須是 array")
    if "observed_usage" in result and not isinstance(result["observed_usage"], dict):
        raise AdapterError("observed_usage 必須是 object")

    return result


def invoke_25d(
    task_packet: dict[str, Any],
    manifest: dict[str, Any],
    transport_response: dict[str, Any],
    *,
    invocation_id: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    validate_task_packet(task_packet)
    validate_manifest(manifest)

    identity_fields = {
        "workflow_id": task_packet["workflow_id"],
        "segment_id": task_packet["segment_id"],
        "attempt_id": task_packet["attempt_id"],
        "skill_id": task_packet["skill_id"],
        "skill_version": task_packet["skill_version"],
        "execution_record_ref": task_packet["execution_record_ref"],
    }
    for field, expected in identity_fields.items():
        if field in transport_response and transport_response[field] != expected:
            raise AdapterError("25D_RESULT_" + field.upper() + "_MISMATCH")

    if "kind" in transport_response and transport_response["kind"] != "RESULT_PACKET":
        raise AdapterError("25D_RESULT_KIND_MISMATCH")
    if "schema_version" in transport_response and transport_response["schema_version"] != "1.0":
        raise AdapterError("25D_RESULT_SCHEMA_VERSION_MISMATCH")

    normalized = normalize_25d_result(transport_response)
    return invoke_skill(
        task_packet,
        manifest,
        lambda _: normalized,
        invocation_id=invocation_id,
    )


