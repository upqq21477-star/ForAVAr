#!/usr/bin/env python3
"""Deterministic cognitive-mode policy for P2's Central-mediated work loop.

This module is orchestration policy, not an LLM and not execution evidence.
It keeps routine THINKING lightweight, triggers RESEARCH only on declared
uncertainty/risk signals, and blocks construction until a complete plan is approved.
"""
from __future__ import annotations

from typing import Any

MODES = (
    "THINKING",
    "RESEARCH",
    "PLAN_READY",
    "CONSTRUCTION",
    "SIMULATION",
    "FINAL_ACCEPTANCE",
    "CLOSE",
)

MIN_PLAN_EVIDENCE_CHARS = 16

PLAN_GATE_KEYS = (
    "objective",
    "scope",
    "change_set",
    "acceptance_criteria",
    "risk_recovery",
    "cost_authority",
    "stop_conditions",
)

RESEARCH_TRIGGER_REASONS = (
    "NEW_SCENARIO",
    "ROOT_CAUSE_UNKNOWN",
    "PRIOR_FIX_FAILED",
    "RECURRENT_FAILURE",
    "CURRENT_EXTERNAL_FACTS_REQUIRED",
    "HIGH_IMPACT_TRADEOFF",
    "SOURCE_CONFLICT",
    "HYPOTHESIS_FAILED",
)

RETURN_TO_THINKING_EVENTS = {
    "UNEXPECTED_OUTPUT",
    "EXECUTION_ERROR",
    "VALIDATION_FAILED",
    "SCOPE_CHANGED",
    "ENVIRONMENT_CHANGED",
    "SOURCE_CONFLICT",
    "HYPOTHESIS_FAILED",
    "CONSTRUCTION_STALLED",
}

RESEARCH_RECOMMENDED_EVENTS = {
    "UNEXPECTED_OUTPUT",
    "EXECUTION_ERROR",
    "VALIDATION_FAILED",
    "SOURCE_CONFLICT",
    "HYPOTHESIS_FAILED",
    "SIMULATION_FAILED",
    "FINAL_ACCEPTANCE_FAILED",
    "CONSTRUCTION_STALLED",
}

EVENTS = {
    "TASK_STARTED",
    "THINKING_COMPLETE",
    "RESEARCH_COMPLETE",
    "PLAN_APPROVED",
    "UNEXPECTED_OUTPUT",
    "EXECUTION_ERROR",
    "VALIDATION_FAILED",
    "SCOPE_CHANGED",
    "ENVIRONMENT_CHANGED",
    "SOURCE_CONFLICT",
    "HYPOTHESIS_FAILED",
    "CONSTRUCTION_STEP_COMPLETE",
    "SIMULATION_PASSED",
    "SIMULATION_FAILED",
    "FINAL_BATCH_READY",
    "FINAL_ACCEPTANCE_PASSED",
    "FINAL_ACCEPTANCE_FAILED",
    "CONSTRUCTION_STALLED",
}

ROLE_EVENTS = {
    "ROLE:CONTROL_RESEARCH": {
        "TASK_STARTED",
        "THINKING_COMPLETE",
        "RESEARCH_COMPLETE",
        "PLAN_APPROVED",
        "FINAL_BATCH_READY",
        "SCOPE_CHANGED",
        "ENVIRONMENT_CHANGED",
        "SOURCE_CONFLICT",
        "HYPOTHESIS_FAILED",
    },
    "ROLE:EXECUTOR": {
        "UNEXPECTED_OUTPUT",
        "EXECUTION_ERROR",
        "SCOPE_CHANGED",
        "ENVIRONMENT_CHANGED",
        "CONSTRUCTION_STEP_COMPLETE",
        "SIMULATION_PASSED",
        "SIMULATION_FAILED",
    },
    # CONSTRUCTION_STALLED is emitted only by the Central progress watchdog,
    # not accepted as a caller-supplied cognitive transition event.
    # Final verdict transitions are intentionally excluded from the generic
    # transition API. They may occur only through SUBMIT_ROLE_RESULT after the
    # acceptance_ref and head_sha bindings have been checked.
    "ROLE:VERIFIER": {
        "VALIDATION_FAILED",
    },
}


def initial_control_state() -> dict[str, Any]:
    """Return the minimal current state; no mode-transition history is retained."""
    return {
        "mode": "THINKING",
        "plan_approved": False,
        "plan_gates": {key: False for key in PLAN_GATE_KEYS},
        "plan_evidence": {key: "" for key in PLAN_GATE_KEYS},
        "feature_batch_complete": False,
        "simulation_batch_passed": False,
        "integration_batch_passed": False,
        "final_batch_report_ref": None,
        "acceptance_policy": "FINAL_BATCH_ONLY",
        "progress_guard": {
            "last_checkpoint_fingerprint": "",
            "no_progress_repeats": 0,
            "last_classification": "NOT_CHECKED",
            "last_reviewed_fingerprint": "",
            "last_review_status": "NOT_RUN",
        },
        "last_transition": None,
    }



import math
HEALTH_REVIEW_TRIGGERS = ("user_requested", "slowdown", "stalled", "repeated_rework", "recurring_failure", "budget_exceeded", "anomaly_reported")
_REPAIR_SUBJECT_TERMS = ("fix", "repair", "regression", "correct", "rework", "rollback", "hotfix")


def build_construction_health_review(
    *,
    trigger: str,
    samples: list[dict[str, Any]],
    source_input_bytes: int | None = None,
    source_input_budget_bytes: int | None = None,
    construction_units: float | None = None,
    maintenance_units: float | None = None,
    resource_unit: str | None = None,
) -> dict[str, Any]:
    """Summarize a bounded event-triggered retrospective without retaining history."""
    if trigger not in HEALTH_REVIEW_TRIGGERS:
        raise ValueError("REVIEW_TRIGGER_REQUIRED")
    if not isinstance(samples, list) or len(samples) > 3:
        raise ValueError("REVIEW_COMMIT_WINDOW_INVALID")
    normalized, path_commits = [], {}
    lines_per_commit, files_per_commit = [], []
    doc_lines = code_lines = corrective_commits = 0
    truncated = False
    for sample in samples:
        if not isinstance(sample, dict):
            raise ValueError("REVIEW_SAMPLE_INVALID")
        sha, subject, files = sample.get("sha"), sample.get("subject"), sample.get("files")
        if not isinstance(sha, str) or not sha.strip() or not isinstance(subject, str):
            raise ValueError("REVIEW_SAMPLE_IDENTITY_INVALID")
        if not isinstance(files, list) or len(files) > 20:
            raise ValueError("REVIEW_FILE_WINDOW_INVALID")
        truncated = truncated or sample.get("file_rows_truncated") is True
        line_count, clean_files = 0, []
        for item in files:
            if not isinstance(item, dict) or not isinstance(item.get("path"), str):
                raise ValueError("REVIEW_FILE_STAT_INVALID")
            file_path = item["path"]
            if not file_path.strip() or len(file_path) > 300:
                raise ValueError("REVIEW_FILE_PATH_INVALID")
            values = []
            for key in ("additions", "deletions"):
                value = item.get(key)
                if value is not None and (not isinstance(value, int) or isinstance(value, bool) or value < 0):
                    raise ValueError("REVIEW_LINE_COUNT_INVALID")
                values.append(value)
            added, deleted = values
            if added is not None and deleted is not None:
                changed = added + deleted
                line_count += changed
                low = file_path.lower()
                if low.startswith("docs/") or low.endswith((".md", ".rst", ".txt")):
                    doc_lines += changed
                elif low.endswith((".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs")):
                    code_lines += changed
            path_commits.setdefault(file_path, set()).add(sha)
            clean_files.append({"path": file_path, "additions": added, "deletions": deleted})
        lines_per_commit.append(line_count)
        files_per_commit.append(len(clean_files))
        if any(term in subject.lower() for term in _REPAIR_SUBJECT_TERMS):
            corrective_commits += 1
        normalized.append({
            "sha": sha[:12], "date": str(sample.get("date", ""))[:16],
            "subject": subject[:180], "changed_file_count_observed": len(clean_files),
            "changed_lines_observed": line_count, "file_rows_truncated": sample.get("file_rows_truncated") is True,
            "files": clean_files,
        })
    repeated = sorted(
        ({"path": p, "commit_count": len(shas)} for p, shas in path_commits.items() if len(shas) >= 2),
        key=lambda x: (-x["commit_count"], x["path"]),
    )[:8]
    signals: list[dict[str, str]] = []
    if len(normalized) < 2:
        signals.append({"code": "BASELINE_TOO_SMALL", "meaning": "Fewer than two commits; trend comparison is weak."})
    if repeated:
        signals.append({"code": "REPEATED_FILE_TOUCHES", "meaning": "Files changed in multiple commits; inspect planned iteration versus avoidable rework."})
    if corrective_commits >= 2:
        signals.append({"code": "MULTIPLE_CORRECTIVE_COMMITS", "meaning": "At least two subjects indicate repair; check whether requirements/evidence already existed."})
    if len(lines_per_commit) == 3:
        median_lines = sorted(lines_per_commit)[1]
        if max(lines_per_commit) >= 200 and max(lines_per_commit) > max(1, median_lines) * 2:
            signals.append({"code": "HIGH_CHANGE_CHURN_OUTLIER", "meaning": "One commit exceeds twice median changed lines and has at least 200 changed lines."})
    if doc_lines >= 120 and doc_lines > max(1, code_lines) * 2:
        signals.append({"code": "DOC_OR_CONTRACT_EXPANSION_CANDIDATE", "meaning": "Docs/contracts dominate code changes; inspect duplicated authorities and context growth."})
    input_status, input_ratio = "UNMEASURED", None
    if (isinstance(source_input_bytes, int) and not isinstance(source_input_bytes, bool) and source_input_bytes >= 0
        and isinstance(source_input_budget_bytes, int) and not isinstance(source_input_budget_bytes, bool) and source_input_budget_bytes > 0):
        input_ratio = source_input_bytes / source_input_budget_bytes
        input_status = "OVER_BUDGET" if input_ratio > 1 else "NEAR_BUDGET" if input_ratio >= 0.85 else "WITHIN_BUDGET"
        if input_status in {"OVER_BUDGET", "NEAR_BUDGET"}:
            signals.append({"code": "SOURCE_INPUT_BUDGET_PRESSURE", "meaning": "Declared repository input-byte estimate is near/above its configured limit."})
    usage = construction_units is not None or maintenance_units is not None
    resource_status, resource_ratio = "UNMEASURED", None
    if usage:
        valid = (
            isinstance(construction_units, (int, float)) and not isinstance(construction_units, bool)
            and isinstance(maintenance_units, (int, float)) and not isinstance(maintenance_units, bool)
            and math.isfinite(construction_units) and math.isfinite(maintenance_units)
        )
        if not valid or not isinstance(resource_unit, str) or not resource_unit.strip() or construction_units <= 0 or maintenance_units < 0:
            resource_status = "INVALID_OR_INCOMPLETE_TELEMETRY"
        else:
            resource_ratio = maintenance_units / construction_units
            resource_status = "OVER_BUDGET" if resource_ratio > 0.20 else "WITHIN_BUDGET"
    if resource_status == "OVER_BUDGET":
        signals.insert(0, {
            "code": "MAINTENANCE_RESOURCE_BUDGET_EXCEEDED",
            "meaning": "Measured maintenance usage exceeds 20% of construction usage in the declared common unit.",
        })
    classification = "INSUFFICIENT_BASELINE" if len(normalized) < 2 else "REVIEW_RECOMMENDED" if signals else "NO_STRUCTURAL_ANOMALY_OBSERVED"
    recommendations, codes = [], {item["code"] for item in signals}
    if "REPEATED_FILE_TOUCHES" in codes or "MULTIPLE_CORRECTIVE_COMMITS" in codes:
        recommendations.append("Compare original acceptance criteria with failure/fix; classify preventable omission, new evidence, or changed scope.")
    if "HIGH_CHANGE_CHURN_OUTLIER" in codes:
        recommendations.append("Check oversized scope, mixed independent changes, or late plan changes causing rewrites.")
    if "DOC_OR_CONTRACT_EXPANSION_CANDIDATE" in codes:
        recommendations.append("Check duplicate sources of truth, oversized history/context, schema duplication, and missing bounds.")
    if "SOURCE_INPUT_BUDGET_PRESSURE" in codes:
        recommendations.append("Remove irrelevant explicit refs; never load full history or complete diff bodies.")
    if resource_status == "OVER_BUDGET":
        recommendations.append("Inspect actual same-unit usage; reduce redundant reads/tool calls before changing safety/acceptance gates.")
    if not recommendations:
        recommendations.append("This sample establishes no cause and does not prove normal AI reasoning; investigate only if symptoms recur.")
    return {
        "review_kind": "ON_DEMAND_CONSTRUCTION_HEALTH_RETROSPECTIVE",
        "trigger": trigger, "classification": classification,
        "model_reasoning_quality": "NOT_DIRECTLY_OBSERVABLE_FROM_GIT_METADATA",
        "signals": signals[:6],
        "comparison": {"sampled_commits": len(normalized), "changed_files_per_commit": files_per_commit,
            "changed_lines_per_commit": lines_per_commit, "repeated_files": repeated,
            "corrective_commit_subjects": corrective_commits, "file_rows_truncated": truncated,
            "documentation_or_contract_lines": doc_lines, "implementation_lines": code_lines},
        "source_input_budget": {"estimated_bytes": source_input_bytes, "configured_max_bytes": source_input_budget_bytes,
            "ratio": round(input_ratio, 4) if input_ratio is not None else None, "status": input_status},
        "maintenance_resource_budget": {"rule": "maintenance_units / construction_units <= 0.20",
            "ratio": round(resource_ratio, 4) if resource_ratio is not None else None, "resource_unit": resource_unit,
            "status": resource_status, "note": "UNMEASURED unless both values are actual comparable usage telemetry; Git metrics are only proxies."},
        "reviewed_commits": normalized, "recommendations": recommendations[:5],
        "retention": {"max_commits": 3, "max_file_rows_per_commit": 20, "full_diff_loaded": False, "persistent_review_history_written": False},
    }

def plan_gate_gaps(plan_gates: dict[str, Any] | None) -> list[str]:
    gates = plan_gates if isinstance(plan_gates, dict) else {}
    return [key for key in PLAN_GATE_KEYS if gates.get(key) is not True]


def _strings(value: Any, *, minimum: int, maximum: int, limit: int = 1000) -> bool:
    return (
        isinstance(value, list)
        and minimum <= len(value) <= maximum
        and all(isinstance(item, str) and item.strip() and len(item) <= limit for item in value)
    )


def validate_research_record(record: Any) -> tuple[bool, list[str]]:
    """Check a bounded research summary before it can unlock PLAN_READY."""
    if not isinstance(record, dict):
        return False, ["RESEARCH_RECORD_REQUIRED"]

    issues: list[str] = []
    if not _strings(record.get("observations"), minimum=1, maximum=12):
        issues.append("RESEARCH_OBSERVATIONS_INVALID")
    sources = record.get("sources")
    if not isinstance(sources, list) or not 1 <= len(sources) <= 5 or any(
        not isinstance(item, str) or not item.strip() or len(item) > 500
        for item in sources
    ):
        issues.append("RESEARCH_SOURCE_BUDGET_INVALID")

    hypotheses = record.get("hypotheses")
    if not isinstance(hypotheses, list) or not 1 <= len(hypotheses) <= 3:
        issues.append("RESEARCH_HYPOTHESIS_BUDGET_INVALID")
    else:
        for index, hypothesis in enumerate(hypotheses):
            if not isinstance(hypothesis, dict):
                issues.append(f"RESEARCH_HYPOTHESIS_INVALID:{index}")
                continue
            statement = hypothesis.get("statement")
            if not isinstance(statement, str) or not statement.strip():
                issues.append(f"RESEARCH_HYPOTHESIS_STATEMENT_MISSING:{index}")
            elif len(statement) > 1000:
                issues.append(f"RESEARCH_HYPOTHESIS_STATEMENT_TOO_LONG:{index}")
            for key in ("supporting_evidence", "contradicting_evidence"):
                value = hypothesis.get(key)
                if not isinstance(value, list) or not 1 <= len(value) <= 5 or any(
                    not isinstance(item, str) or not item.strip() or len(item) > 500
                    for item in value
                ):
                    issues.append(f"RESEARCH_{key.upper()}_INVALID:{index}")
            discriminating_test = hypothesis.get("discriminating_test")
            if not isinstance(discriminating_test, str) or not discriminating_test.strip():
                issues.append(f"RESEARCH_DISCRIMINATING_TEST_MISSING:{index}")
            elif len(discriminating_test) > 1000:
                issues.append(f"RESEARCH_DISCRIMINATING_TEST_TOO_LONG:{index}")

    if not _strings(record.get("candidate_comparison"), minimum=1, maximum=4, limit=1000):
        issues.append("RESEARCH_CANDIDATE_COMPARISON_INVALID")
    for key in ("selected_solution", "stop_condition"):
        value = record.get(key)
        if not isinstance(value, str) or not value.strip() or len(value) > 1000:
            issues.append(f"RESEARCH_{key.upper()}_MISSING")
    return not issues, issues


def transition_mode(
    *,
    current_mode: str = "THINKING",
    event: str,
    plan_gates: dict[str, Any] | None = None,
    plan_approved: bool = False,
    research_trigger_reasons: list[str] | None = None,
    research_record: dict[str, Any] | None = None,
    feature_batch_complete: bool = False,
    simulation_batch_passed: bool = False,
    integration_batch_passed: bool = False,
) -> dict[str, Any]:
    """Compute exactly one transition; callers persist it through Central authority."""
    if current_mode not in MODES:
        current_mode = "THINKING"
        invalid_mode = True
    else:
        invalid_mode = False
    if event not in EVENTS:
        return _result(
            "BLOCK", current_mode, current_mode, event,
            reason_code="COGNITIVE_EVENT_UNKNOWN",
            construction_paused=True,
            research_recommended=False,
            plan_gates=plan_gates,
            plan_approved=plan_approved,
            feature_batch_complete=feature_batch_complete,
            simulation_batch_passed=simulation_batch_passed,
        integration_batch_passed=integration_batch_passed,
        )
    if invalid_mode:
        return _result(
            "BLOCK", current_mode, "THINKING", event,
            reason_code="COGNITIVE_MODE_INVALID",
            construction_paused=True,
            research_recommended=True,
            plan_gates=plan_gates,
            plan_approved=False,
            feature_batch_complete=feature_batch_complete,
            simulation_batch_passed=simulation_batch_passed,
        integration_batch_passed=integration_batch_passed,
        )

    reasons = research_trigger_reasons or []
    if not isinstance(reasons, list) or any(reason not in RESEARCH_TRIGGER_REASONS for reason in reasons):
        return _result(
            "BLOCK", current_mode, current_mode, event,
            reason_code="RESEARCH_TRIGGER_REASON_INVALID",
            construction_paused=True,
            research_recommended=False,
            plan_gates=plan_gates,
            plan_approved=plan_approved,
            feature_batch_complete=feature_batch_complete,
            simulation_batch_passed=simulation_batch_passed,
        integration_batch_passed=integration_batch_passed,
        )

    next_mode = current_mode
    status = "PASS"
    reason_code = "COGNITIVE_TRANSITION_APPLIED"
    paused = False
    research_recommended = bool(set(reasons) & set(RESEARCH_TRIGGER_REASONS))
    approved = plan_approved
    batch_complete = feature_batch_complete
    batch_simulation_passed = simulation_batch_passed
    batch_integration_passed = integration_batch_passed

    if event == "TASK_STARTED":
        next_mode = "THINKING"
        approved = False
        batch_complete = False
        batch_simulation_passed = False
        batch_integration_passed = False
        reason_code = "DEFAULT_THINKING"
    elif event == "THINKING_COMPLETE":
        if current_mode != "THINKING":
            status, reason_code = "BLOCK", "THINKING_MODE_REQUIRED"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        else:
            if research_recommended:
                next_mode = "RESEARCH"
                reason_code = "RESEARCH_TRIGGERED"
            else:
                gaps = plan_gate_gaps(plan_gates)
                if gaps:
                    status, reason_code = "BLOCK", "PLAN_GATE_INCOMPLETE"
                    next_mode = "THINKING"
                    approved = False
                    batch_complete = False
                    batch_simulation_passed = False
                    batch_integration_passed = False
                    paused = True
                else:
                    next_mode = "PLAN_READY"
                    reason_code = "PLAN_GATES_COMPLETE"
                    approved = False
    elif event == "RESEARCH_COMPLETE":
        if current_mode != "RESEARCH":
            status, reason_code = "BLOCK", "RESEARCH_MODE_REQUIRED"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        else:
            valid_record, issues = validate_research_record(research_record)
            if not valid_record:
                status, reason_code = "BLOCK", "RESEARCH_RECORD_INCOMPLETE"
                next_mode = "THINKING"
                approved = False
                batch_complete = False
                batch_simulation_passed = False
                batch_integration_passed = False
                paused = True
            elif plan_gate_gaps(plan_gates):
                status, reason_code = "BLOCK", "PLAN_GATE_INCOMPLETE"
                next_mode = "THINKING"
                approved = False
                batch_complete = False
                batch_simulation_passed = False
                batch_integration_passed = False
                paused = True
            else:
                next_mode = "PLAN_READY"
                approved = False
                reason_code = "RESEARCH_COMPLETE_PLAN_READY"
    elif event == "PLAN_APPROVED":
        gaps = plan_gate_gaps(plan_gates)
        if current_mode != "PLAN_READY":
            status, reason_code = "BLOCK", "PLAN_READY_STATE_REQUIRED"
            next_mode = current_mode
            approved = False
            paused = True
        elif gaps:
            status, reason_code = "BLOCK", "PLAN_GATE_INCOMPLETE"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        else:
            next_mode = "CONSTRUCTION"
            approved = True
            reason_code = "PLAN_APPROVED_CONSTRUCTION_ALLOWED"
    elif event in RETURN_TO_THINKING_EVENTS:
        next_mode = "THINKING"
        approved = False
        paused = True
        batch_complete = False
        batch_simulation_passed = False
        batch_integration_passed = False
        research_recommended = (
            research_recommended or event in RESEARCH_RECOMMENDED_EVENTS
        )
        reason_code = "PAUSED_RETURN_TO_THINKING"
    elif event == "CONSTRUCTION_STEP_COMPLETE":
        if current_mode != "CONSTRUCTION" or not plan_approved or plan_gate_gaps(plan_gates):
            status, reason_code = "BLOCK", "CONSTRUCTION_NOT_AUTHORIZED"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        else:
            next_mode = "SIMULATION"
            reason_code = "LOCAL_SIMULATION_REQUIRED"
    elif event == "SIMULATION_PASSED":
        if current_mode != "SIMULATION":
            status, reason_code = "BLOCK", "SIMULATION_MODE_REQUIRED"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        elif not plan_approved or plan_gate_gaps(plan_gates):
            status, reason_code = "BLOCK", "SIMULATION_PLAN_NOT_AUTHORIZED"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            research_recommended = True
            paused = True
        elif feature_batch_complete:
            next_mode = "SIMULATION"
            reason_code = "FINAL_BATCH_ELIGIBLE_ONLY_WITH_BATCH_FLAGS"
        else:
            next_mode = "THINKING"
            approved = False
            paused = True
            reason_code = "STEP_SIMULATION_PASSED_RETURN_TO_THINKING"
    elif event == "SIMULATION_FAILED":
        if current_mode != "SIMULATION":
            status, reason_code = "BLOCK", "SIMULATION_MODE_REQUIRED"
            next_mode = "THINKING"
            approved = False
            paused = True
            research_recommended = True
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
        else:
            next_mode = "THINKING"
            approved = False
            paused = True
            research_recommended = True
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            reason_code = "SIMULATION_FAILED_RETURN_TO_THINKING"
    elif event == "FINAL_BATCH_READY":
        if not feature_batch_complete or not simulation_batch_passed or not integration_batch_passed:
            status, reason_code = "BLOCK", "FINAL_BATCH_INTEGRATION_EVIDENCE_MISSING"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        elif current_mode not in {"CONSTRUCTION", "SIMULATION"}:
            status, reason_code = "BLOCK", "FINAL_BATCH_SOURCE_MODE_INVALID"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        elif not plan_approved:
            status, reason_code = "BLOCK", "FINAL_BATCH_PLAN_NOT_APPROVED"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        elif plan_gate_gaps(plan_gates):
            status, reason_code = "BLOCK", "PLAN_GATE_INCOMPLETE"
            next_mode = "THINKING"
            approved = False
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            paused = True
        else:
            next_mode = "FINAL_ACCEPTANCE"
            batch_complete = True
            batch_simulation_passed = True
            batch_integration_passed = True
            reason_code = "FINAL_BATCH_READY_FOR_INDEPENDENT_ACCEPTANCE"
    elif event == "FINAL_ACCEPTANCE_FAILED":
        if (
            current_mode != "FINAL_ACCEPTANCE"
            or not feature_batch_complete
            or not simulation_batch_passed
            or not integration_batch_passed
        ):
            status, reason_code = "BLOCK", "FINAL_ACCEPTANCE_EVIDENCE_GATE_REQUIRED"
            next_mode = current_mode
            paused = True
        else:
            next_mode = "THINKING"
            approved = False
            paused = True
            batch_complete = False
            batch_simulation_passed = False
            batch_integration_passed = False
            research_recommended = True
            reason_code = "FINAL_ACCEPTANCE_FAILED_RETURN_TO_THINKING"
    elif event == "FINAL_ACCEPTANCE_PASSED":
        if (
            current_mode != "FINAL_ACCEPTANCE"
            or not feature_batch_complete
            or not simulation_batch_passed
            or not integration_batch_passed
        ):
            status, reason_code = "BLOCK", "FINAL_ACCEPTANCE_EVIDENCE_GATE_REQUIRED"
            next_mode = current_mode
            paused = True
        else:
            next_mode = "CLOSE"
            reason_code = "FINAL_ACCEPTANCE_PASSED_CLOSE"
    else:
        status, reason_code = "BLOCK", "COGNITIVE_EVENT_UNHANDLED"
        next_mode = current_mode
        paused = True

    effective_plan_gates = plan_gates
    if event == "TASK_STARTED" or (next_mode == "THINKING" and paused):
        effective_plan_gates = {key: False for key in PLAN_GATE_KEYS}

    return _result(
        status,
        current_mode,
        next_mode,
        event,
        reason_code=reason_code,
        construction_paused=paused,
        research_recommended=research_recommended,
        plan_gates=effective_plan_gates,
        plan_approved=approved,
        feature_batch_complete=batch_complete,
        simulation_batch_passed=batch_simulation_passed,
        integration_batch_passed=batch_integration_passed,
    )


def _result(
    status: str,
    from_mode: str,
    to_mode: str,
    event: str,
    *,
    reason_code: str,
    construction_paused: bool,
    research_recommended: bool,
    plan_gates: dict[str, Any] | None,
    plan_approved: bool,
    feature_batch_complete: bool,
    simulation_batch_passed: bool,
    integration_batch_passed: bool,
) -> dict[str, Any]:
    return {
        "status": status,
        "event": event,
        "from_mode": from_mode,
        "mode": to_mode,
        "reason_code": reason_code,
        "construction_paused": construction_paused,
        "research_recommended": research_recommended,
        "missing_plan_gates": plan_gate_gaps(plan_gates),
        "plan_approved": plan_approved,
        "feature_batch_complete": feature_batch_complete,
        "simulation_batch_passed": simulation_batch_passed,
        "integration_batch_passed": integration_batch_passed,
        "acceptance_policy": "FINAL_BATCH_ONLY",
        "execution_evidence": "NOT_PROVIDED_BY_MODE_CONTROLLER",
    }


def build_role_supervision_context(
    *,
    current: dict[str, Any],
    work_packet: dict[str, Any],
    role_id: str,
) -> dict[str, Any]:
    """Small, current-only supervision projection for non-Verifier roles."""
    control = work_packet.get("brain_mode_control")
    if not isinstance(control, dict):
        control = initial_control_state()
    mode = control.get("mode", "THINKING")
    if mode not in MODES:
        mode = "THINKING"
    raw_plan_evidence = control.get("plan_evidence")
    if not isinstance(raw_plan_evidence, dict):
        raw_plan_evidence = {}
    plan_evidence = {
        key: (
            raw_plan_evidence.get(key).strip()
            if isinstance(raw_plan_evidence.get(key), str)
            else ""
        )
        for key in PLAN_GATE_KEYS
    }
    # Role context never trusts persisted booleans without corresponding evidence.
    gates = {
        key: len(plan_evidence[key]) >= MIN_PLAN_EVIDENCE_CHARS
        for key in PLAN_GATE_KEYS
    }
    gaps = plan_gate_gaps(gates)
    plan_approved = (
        control.get("plan_approved") is True
        and not gaps
    )
    feature_batch_complete = control.get("feature_batch_complete") is True
    simulation_batch_passed = control.get("simulation_batch_passed") is True
    integration_batch_passed = control.get("integration_batch_passed") is True
    last_transition = control.get("last_transition")
    if not isinstance(last_transition, dict):
        last_transition = None
    research_recommended = bool(
        last_transition and last_transition.get("research_recommended") is True
    )
    stage = current.get("current_stage", {})
    required_next_step = (
        "PAUSE_CONSTRUCTION_AND_REPLAN"
        if mode == "CONSTRUCTION" and not (
            plan_approved and not gaps
        )
        else "RESEARCH_BEFORE_REPLAN"
        if mode == "THINKING" and research_recommended
        else "BUILD_OR_REFRESH_PLAN_EVIDENCE"
        if mode == "THINKING" and gaps
        else "COMPLETE_LIGHTWEIGHT_THINKING"
        if mode == "THINKING"
        else {
            "RESEARCH": "PRODUCE_BOUNDED_RESEARCH_RECORD",
            "PLAN_READY": "REVIEW_AND_APPROVE_COMPLETE_PLAN",
            "CONSTRUCTION": "CONTINUE_AUTHORIZED_CONSTRUCTION",
            "SIMULATION": "RUN_LOCAL_CASE_SIMULATION_ONLY",
            "FINAL_ACCEPTANCE": "INDEPENDENT_FINAL_BATCH_VERIFICATION",
            "CLOSE": "CLOSE_WORK_UNIT_AND_REFRESH_CURRENT",
        }[mode]
    )
    return {
        "default_mode": "THINKING",
        "current_mode": mode,
        "role_id": role_id,
        "lightweight_monitoring": True,
        "research_recommended": research_recommended,
        "last_transition": last_transition,
        "required_next_step": required_next_step,
        "research_trigger_reasons": list(RESEARCH_TRIGGER_REASONS),
        "pause_on_events": sorted(RETURN_TO_THINKING_EVENTS),
        "research_protocol": {
            "max_hypotheses": 3,
            "max_sources": 5,
            "requires_supporting_and_contradicting_evidence": True,
            "requires_discriminating_test": True,
            "requires_candidate_comparison": True,
            "requires_stop_condition": True,
        },
        "plan_gates": {key: gates[key] for key in PLAN_GATE_KEYS},
        "plan_evidence": plan_evidence,
        "missing_plan_gates": gaps,
        "plan_approved": plan_approved,
        "construction_allowed": (
            mode == "CONSTRUCTION" and plan_approved and not gaps
        ),
        "feature_batch_complete": feature_batch_complete,
        "simulation_batch_passed": simulation_batch_passed,
        "integration_batch_passed": integration_batch_passed,
        "formal_acceptance_eligible": (
            feature_batch_complete
            and simulation_batch_passed
            and integration_batch_passed
            and mode == "FINAL_ACCEPTANCE"
        ),
        "acceptance_policy": {
            "local_case_simulation": "SIMULATION_ONLY",
            "formal_acceptance": "FINAL_BATCH_ONLY",
            "independent_verifier_required": True,
        },
        "current_stage_ref": stage.get("id"),
        "runtime_evidence": "NOT_PROVIDED_BY_MODE_CONTROLLER",
    }
