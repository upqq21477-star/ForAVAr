#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "adoption_rollback.schema.json"
SELECTION_SCHEMA_PATH = SCHEMA_DIR / "regression_selection.schema.json"
REGRESSION_RESULT_SCHEMA_PATH = SCHEMA_DIR / "regression_execution_result.schema.json"
ROUTE_STATE_SCHEMA_PATH = SCHEMA_DIR / "route_state.schema.json"


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def identity(kind: str, object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(value)
    result["object_id"] = f"{kind}:{object_id}"
    result["kind"] = kind
    result["schema_version"] = "1.0"
    result["content_hash"] = content_hash(result)
    return result


def registry() -> Registry:
    reg = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "regression_selection.schema.json",
        "regression_execution_result.schema.json",
        "route_state.schema.json",
        "adoption_rollback.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        reg = reg.with_resource(schema["$id"], Resource.from_contents(schema))
    return reg


def validate(schema_path: Path, value: dict[str, Any]) -> None:
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(schema, registry=registry(), format_checker=FormatChecker()).iter_errors(value),
        key=lambda item: list(item.path),
    )
    if errors:
        raise ValueError(
            f"{schema_path.name} 驗證失敗: " + "; ".join(item.message for item in errors)
        )
    if schema_path.name == "adoption_rollback.schema.json" and value.get("content_hash") != content_hash(value):
        raise ValueError("Adoption Rollback content_hash 不正確")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def decide(
    selection: dict[str, Any],
    regression_result: dict[str, Any],
    route_state: dict[str, Any],
    *,
    decision_id: str | None = None,
) -> dict[str, Any]:
    validate(SELECTION_SCHEMA_PATH, selection)
    validate(REGRESSION_RESULT_SCHEMA_PATH, regression_result)
    validate(ROUTE_STATE_SCHEMA_PATH, route_state)

    if selection.get("kind") != "REGRESSION_SELECTION":
        raise ValueError("M5 只接受 REGRESSION_SELECTION")
    if selection["status"] == "BLOCK":
        raise ValueError("M5 不接受 BLOCK 的 regression selection")
    if regression_result["selection_id"] != selection["selection_id"]:
        raise ValueError("regression result selection_id 不一致")

    result_map = {
        item["regression_set_id"]: item
        for item in regression_result["results"]
    }
    state_map = {
        item["capability_id"]: item
        for item in route_state["routes"]
    }

    decisions = []
    blocked = False
    incomplete = selection["status"] == "INSUFFICIENT_DATA"

    for item in selection["selections"]:
        capability_id = item["capability_id"]
        if capability_id not in state_map:
            blocked = True
            decisions.append({
                "capability_id": capability_id,
                "evaluation_ref": item["evaluation_ref"],
                "from_mode": item["route_mode"],
                "candidate_mode": item["route_mode"],
                "rollback_mode": item["route_mode"],
                "action": "BLOCK",
                "status": "BLOCKED",
                "required_regression_sets": item["regression_sets"],
                "passed_regression_sets": [],
                "failed_regression_sets": [],
                "reason_codes": ["CURRENT_ROUTE_STATE_MISSING"],
            })
            continue

        current = state_map[capability_id]
        required = sorted(set(item["regression_sets"]))
        passed = sorted(
            set(
                regression_id
                for regression_id in required
                if result_map.get(regression_id, {}).get("status") == "PASS"
            )
        )
        failed = sorted(
            set(
                regression_id
                for regression_id in required
                if result_map.get(regression_id, {}).get("status") == "FAIL"
            )
        )
        missing = sorted(set(required) - set(passed) - set(failed))

        if missing:
            incomplete = True
            decisions.append({
                "capability_id": capability_id,
                "evaluation_ref": item["evaluation_ref"],
                "from_mode": current["current_mode"],
                "candidate_mode": item["route_mode"],
                "rollback_mode": current["rollback_mode"],
                "action": "DEFER",
                "status": "DEFERRED",
                "required_regression_sets": required,
                "passed_regression_sets": passed,
                "failed_regression_sets": failed,
                "reason_codes": ["REGRESSION_RESULT_MISSING"],
            })
        elif failed:
            decisions.append({
                "capability_id": capability_id,
                "evaluation_ref": item["evaluation_ref"],
                "from_mode": current["current_mode"],
                "candidate_mode": item["route_mode"],
                "rollback_mode": current["rollback_mode"],
                "action": "ROLLBACK",
                "status": "READY",
                "required_regression_sets": required,
                "passed_regression_sets": passed,
                "failed_regression_sets": failed,
                "reason_codes": ["REGRESSION_FAILED", "ROLLBACK_TO_EXPLICIT_STATE"],
            })
        else:
            decisions.append({
                "capability_id": capability_id,
                "evaluation_ref": item["evaluation_ref"],
                "from_mode": current["current_mode"],
                "candidate_mode": item["route_mode"],
                "rollback_mode": current["rollback_mode"],
                "action": "ADOPT",
                "status": "READY",
                "required_regression_sets": required,
                "passed_regression_sets": passed,
                "failed_regression_sets": failed,
                "reason_codes": ["ALL_REQUIRED_REGRESSIONS_PASS"],
            })

    for item in selection["pending"]:
        incomplete = True

    status = "BLOCK" if blocked else "INSUFFICIENT_DATA" if incomplete else "PASS"

    report = identity(
        "ADOPTION_ROLLBACK",
        decision_id or f"M5-{selection['selection_id'].replace('M4-', '')}",
        {
            "decision_id": decision_id or f"M5-{selection['selection_id'].replace('M4-', '')}",
            "source_selection_id": selection["selection_id"],
            "source_regression_result_id": regression_result["result_id"],
            "status": status,
            "decisions": decisions,
        },
    )
    validate(SCHEMA_PATH, report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 M5 Adoption / Rollback")
    parser.add_argument("selection")
    parser.add_argument("regression_result")
    parser.add_argument("route_state")
    parser.add_argument("output")
    args = parser.parse_args()

    report = decide(
        load_json(Path(args.selection)),
        load_json(Path(args.regression_result)),
        load_json(Path(args.route_state)),
    )
    Path(args.output).write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] in {"PASS", "INSUFFICIENT_DATA"} else 3


if __name__ == "__main__":
    raise SystemExit(main())
