#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
POLICY_PATH = ROOT / "P1-Central-Control/change_scope_policy.json"


def load_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def git_diff(base: str, head: str) -> list[dict[str, Any]]:
    proc = subprocess.run(
        ["git", "-c", "core.quotepath=false", "diff", "--name-status", "-M", base, head],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "git diff failed")
    result: list[dict[str, Any]] = []
    for line in proc.stdout.splitlines():
        if not line.strip():
            continue
        fields = line.split("\t")
        status = fields[0]
        if status.startswith("R") and len(fields) >= 3:
            result.append({"status": "RENAMED", "old_path": fields[1], "path": fields[2]})
        elif status.startswith("C") and len(fields) >= 3:
            result.append({"status": "COPIED", "old_path": fields[1], "path": fields[2]})
        elif len(fields) >= 2:
            result.append({"status": status, "path": fields[1]})
    return result


def diff_lines(base: str, head: str) -> tuple[int, int]:
    proc = subprocess.run(
        ["git", "diff", "--numstat", base, head],
        cwd=ROOT, text=True, capture_output=True, check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "git diff --numstat failed")
    additions = deletions = 0
    for line in proc.stdout.splitlines():
        fields = line.split("\t")
        if len(fields) < 2:
            continue
        additions += int(fields[0]) if fields[0].isdigit() else 0
        deletions += int(fields[1]) if fields[1].isdigit() else 0
    return additions, deletions


def classify_system(path: str) -> str | None:
    if path.startswith("P1-Central-Control/") or path.startswith(".github/"):
        return "P1-CENTRAL-CONTROL"
    return None


def classify_refs(paths: list[str]) -> tuple[list[str], list[str], list[str]]:
    interfaces: set[str] = set()
    canonical: set[str] = set()
    capabilities: set[str] = set()
    for path in paths:
        if "/schemas/" in path or path.endswith("schema.json"):
            interfaces.add(path)
        if "/canonical/" in path or path.endswith("P1-CURRENT.json"):
            canonical.add(path)
    return sorted(interfaces), sorted(canonical), sorted(capabilities)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", required=True)
    ap.add_argument("--head", required=True)
    ap.add_argument("--impact", required=True)
    ap.add_argument("--output", required=True)
    args = ap.parse_args()

    policy = load_json(POLICY_PATH)
    impact = load_json(Path(args.impact))
    impact_scan = impact.get("impact_scan", impact)
    change_event = impact.get("change_event", {})
    changed = git_diff(args.base, args.head)
    additions, deletions = diff_lines(args.base, args.head)

    paths = [x["path"] for x in changed if x.get("path")]
    all_scope_paths = paths + [x["old_path"] for x in changed if x.get("old_path")]
    systems = sorted({s for s in (classify_system(p) for p in all_scope_paths) if s})
    interfaces, canonical, caps_from_paths = classify_refs(paths)
    affected_caps = sorted(set(impact_scan.get("affected_capabilities", [])) | set(caps_from_paths))
    unknown_paths = sorted(set(impact_scan.get("unknown_paths", [])))

    cross_system_write = len(systems) > 1
    reasons: list[str] = []
    scope_risk = "LOW"

    if unknown_paths:
        scope_risk = "BLOCK"
        reasons.append("UNKNOWN_PATH")
    elif cross_system_write:
        scope_risk = "HIGH"
        reasons.append("CROSS_SYSTEM_WRITE")
    elif "P1-CURRENT.json" in paths:
        scope_risk = "HIGH"
        reasons.append("CURRENT_AUTHORITY_CHANGE")
    elif len(paths) >= policy["thresholds"]["red_files"] or additions + deletions >= policy["thresholds"]["red_lines"]:
        scope_risk = "HIGH"
        reasons.append("LARGE_CHANGE")

    context_units = (
        len(paths) * 350
        + (additions + deletions) * 7
        + len(affected_caps) * 180
        + len(interfaces) * 160
        + len(canonical) * 220
        + len(impact_scan.get("required_regression_sets", [])) * 280
    )

    context_status = (
        "OVERSIZED"
        if context_units > policy["thresholds"]["context_target_units"]
        else "SUFFICIENT"
    )
    if context_units > policy["thresholds"]["context_hard_units"]:
        context_status = "OVERSIZED"
        reasons.append("CONTEXT_HARD_CEILING")
    elif context_units > policy["thresholds"]["context_target_units"]:
        reasons.append("CONTEXT_TARGET_EXCEEDED")

    if scope_risk == "BLOCK":
        decision = "BLOCK"
    elif cross_system_write:
        decision = "HANDOFF"
    elif context_status == "OVERSIZED" or scope_risk == "HIGH":
        decision = "SPLIT"
    else:
        decision = "PROCEED"

    green_files = policy["thresholds"]["green_max_files"]
    amber_files = policy["thresholds"]["amber_max_files"]
    green_lines = policy["thresholds"]["green_max_lines"]
    amber_lines = policy["thresholds"]["amber_max_lines"]
    scope_status = "GREEN"
    if len(paths) > green_files or additions + deletions > green_lines or decision in {"HANDOFF", "SPLIT"}:
        scope_status = "AMBER"
    if len(paths) >= policy["thresholds"]["red_files"] or additions + deletions >= policy["thresholds"]["red_lines"] or decision == "BLOCK":
        scope_status = "RED"

    if not change_event:
        scope_status = "UNKNOWN"
        decision = "BLOCK"
        reasons.append("MISSING_CHANGE_EVENT")

    material = {"base": args.base, "head": args.head, "changed": changed, "context_units": context_units, "decision": decision}
    scope_id = "SCOPE:" + hashlib.sha256(json.dumps(material, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()[:16]

    result = {
        "change_scope_id": scope_id,
        "change_id": change_event.get("change_id", "CHANGE:UNKNOWN"),
        "scope_status": scope_status,
        "risk": "BLOCK" if scope_risk == "BLOCK" else "HIGH" if scope_risk == "HIGH" else "MEDIUM" if decision != "PROCEED" else "LOW",
        "changed_file_count": len(paths),
        "changed_line_count": additions + deletions,
        "target_systems": systems,
        "affected_capabilities": affected_caps,
        "affected_interfaces": interfaces,
        "affected_canonical_objects": canonical,
        "required_regression_sets": sorted(set(impact_scan.get("required_regression_sets", []))),
        "unknown_paths": unknown_paths,
        "cross_system_write": cross_system_write,
        "context_units": context_units,
        "context_status": context_status,
        "decision": decision,
        "reason_codes": sorted(set(reasons)),
    }
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if decision == "PROCEED" else 3


if __name__ == "__main__":
    raise SystemExit(main())
