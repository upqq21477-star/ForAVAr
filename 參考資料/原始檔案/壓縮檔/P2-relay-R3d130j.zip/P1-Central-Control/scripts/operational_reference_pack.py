#!/usr/bin/env python3
"""Build and verify one bounded, deterministic Operational Reference Pack.

The builder only reads explicit references from a validated request. It never
walks the repository, follows Current.read_first, or expands claim history.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
REQUEST_SCHEMA = SCHEMA_DIR / "operational_pack_request.schema.json"
PACK_SCHEMA = SCHEMA_DIR / "operational_reference_pack.schema.json"
CONSTRUCTION_SCHEMA = SCHEMA_DIR / "construction_packet.schema.json"
WORK_SCHEMA = SCHEMA_DIR / "operational_work_unit.schema.json"
BUILDER_VERSION = "1.1"
BUILDER_REF = "P1-Central-Control/scripts/operational_reference_pack.py"
MAX_REQUEST_FILE_BYTES = 1_000_000
MAX_EXPLICIT_INPUT_BYTES = 5_000_000
MAX_PACK_FILE_BYTES = 5_000_000
MAX_CONTEXT_CHARS = 100_000
MAX_STEPS = 100
CONTEXT_CHAR_UNIT = "UNICODE_CODE_POINTS"
MODEL_TOKEN_COUNT_STATUS = "NOT_MEASURED"
MEASUREMENT_CONTRACT_VERSION = "P2-RESOURCE-MEASUREMENT-1"


class PackError(ValueError):
    """Stable, machine-readable pack error."""

    def __init__(self, code: str, detail: str = "") -> None:
        self.code = code
        self.detail = detail
        super().__init__(f"{code}:{detail}" if detail else code)


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def sha256(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return sha256(canonical_json(material))


def _context_material(current_projection: dict[str, Any], active_work: dict[str, Any], distilled_rules: list[dict[str, Any]]) -> dict[str, Any]:
    """Return the one canonical context projection used by build and independent verification."""
    return {
        "current_projection": current_projection,
        "active_work": active_work,
        "distilled_rules": distilled_rules,
    }


def _context_character_count(context_material: dict[str, Any]) -> int:
    """Count Unicode code points in canonical JSON; this is not bytes or model tokens."""
    return len(canonical_json(context_material).decode("utf-8"))


def _load_json(path: Path, error_code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackError(error_code, str(path)) from exc
    if not isinstance(value, dict):
        raise PackError(error_code, f"JSON object required: {path}")
    return value


def _validate(value: dict[str, Any], schema_path: Path, error_code: str) -> None:
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    except Exception as exc:
        raise PackError("PACK_SCHEMA_UNAVAILABLE", str(schema_path)) from exc
    if errors:
        detail = "; ".join(f"{'/'.join(str(x) for x in e.path)}: {e.message}" for e in errors[:8])
        raise PackError(error_code, detail)


def _safe_path(root: Path, ref: str) -> Path:
    if not isinstance(ref, str) or not ref.strip():
        raise PackError("PACK_REF_EMPTY")
    candidate = Path(ref)
    if candidate.is_absolute() or any(part == ".." for part in candidate.parts):
        raise PackError("PACK_REF_PATH_FORBIDDEN", ref)
    try:
        resolved_root = root.resolve()
        resolved = (resolved_root / candidate).resolve()
        resolved.relative_to(resolved_root)
    except (OSError, RuntimeError, ValueError) as exc:
        raise PackError("PACK_REF_PATH_FORBIDDEN", ref) from exc
    return resolved


def _read_ref(root: Path, ref: str, *, max_bytes: int, required: bool, purpose: str) -> tuple[bytes | None, dict[str, Any]]:
    path = _safe_path(root, ref)
    if not path.is_file():
        if required:
            raise PackError("PACK_REQUIRED_REF_MISSING", ref)
        return None, {
            "path": ref, "purpose": purpose, "required": False,
            "status": "OPTIONAL_MISSING", "sha256": None, "byte_length": 0,
        }
    try:
        declared_size = path.stat().st_size
    except OSError as exc:
        raise PackError("PACK_REF_UNREADABLE", ref) from exc
    if declared_size > max_bytes:
        raise PackError("PACK_SOURCE_TOO_LARGE", f"{ref}:{declared_size}>{max_bytes}")
    try:
        data = path.read_bytes()
    except OSError as exc:
        raise PackError("PACK_REF_UNREADABLE", ref) from exc
    if len(data) > max_bytes:
        raise PackError("PACK_SOURCE_TOO_LARGE", f"{ref}:{len(data)}>{max_bytes}")
    return data, {
        "path": ref, "purpose": purpose, "required": required,
        "status": "INCLUDED", "sha256": sha256(data), "byte_length": len(data),
    }


def _runtime_observation_projection(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    steps = value.get("steps_executed")
    if steps is None:
        steps = value.get("step_evidence")
    evidence = value.get("evidence")
    return {
        "observed_at": value.get("observed_at") if isinstance(value.get("observed_at"), str) else None,
        "classification": value.get("classification") if isinstance(value.get("classification"), str) else None,
        "head_sha": value.get("head_sha") if isinstance(value.get("head_sha"), str) else None,
        "steps_executed": steps if isinstance(steps, bool) else None,
        "run_id": value.get("run_id") if type(value.get("run_id")) is int else None,
        "run_attempt": value.get("run_attempt") if type(value.get("run_attempt")) is int else None,
        "job_id": value.get("job_id") if type(value.get("job_id")) is int else None,
        "job_conclusion": value.get("job_conclusion") if isinstance(value.get("job_conclusion"), str) else None,
        "evidence": evidence if isinstance(evidence, bool) else None,
    }


def _current_projection(current: dict[str, Any]) -> dict[str, Any]:
    stage = current.get("current_stage")
    implementation = current.get("implementation_control")
    if not isinstance(stage, dict) or not isinstance(implementation, dict):
        raise PackError("PACK_CURRENT_INVALID", "current_stage / implementation_control must be objects")

    stage_id = stage.get("id")
    stage_status = stage.get("status")
    # Match Runner/Central identity resolution for migrated Current documents.
    work_unit_id = stage.get("work_unit_id") or stage.get("slice_id") or stage.get("id")
    next_action = current.get("next_exact_action") or stage.get("next_exact_action")
    active_work_ref = implementation.get("active_work_packet")
    active_construction_ref = implementation.get("active_construction_packet")
    target_blueprint_ref = current.get("p2_target_blueprint_ref")
    if not all(isinstance(x, str) and x.strip() for x in (
        stage_id, stage_status, work_unit_id, next_action,
        active_work_ref, active_construction_ref, target_blueprint_ref
    )):
        raise PackError(
            "PACK_CURRENT_INVALID",
            "Current must name a stage, work unit, next action, P2 blueprint, Active Work and Active Construction Packet",
        )

    truth = implementation.get("runtime_execution_truth") or {}
    if not isinstance(truth, dict):
        raise PackError("PACK_CURRENT_INVALID", "runtime_execution_truth must be an object")
    runtime_projection = {
        "truth_status": truth.get("status") if isinstance(truth.get("status"), str) else None,
        "stage_observation": _runtime_observation_projection(stage.get("latest_runtime_observation")),
        "current_latest_observation": _runtime_observation_projection(current.get("latest_runtime_observation")),
        "execution_truth_latest_observation": _runtime_observation_projection(truth.get("latest_observation")),
    }
    material = {
        "revision": current.get("revision"),
        "state_revision": current.get("state_revision"),
        "stage_id": stage_id,
        "stage_status": stage_status,
        "work_unit_id": work_unit_id,
        "next_slice_id": stage.get("next_slice_id") if isinstance(stage.get("next_slice_id"), str) else None,
        "next_action": next_action,
        "active_work_packet": active_work_ref,
        "active_construction_packet": active_construction_ref,
        "target_blueprint_ref": target_blueprint_ref,
        "runtime_projection": runtime_projection,
    }
    return {
        "revision": material["revision"] if type(material["revision"]) is int else None,
        "state_revision": material["state_revision"] if type(material["state_revision"]) is int else None,
        "stage_id": stage_id,
        "stage_status": stage_status,
        "work_unit_id": work_unit_id,
        "next_slice_id": material["next_slice_id"],
        "next_action": next_action,
        "active_work_packet_ref": active_work_ref,
        "active_construction_packet_ref": active_construction_ref,
        "target_blueprint_ref": target_blueprint_ref,
        "runtime_projection": runtime_projection,
        "fingerprint": sha256(canonical_json(material)),
    }


def _validate_request_links(request: dict[str, Any]) -> None:
    paths = [request["current_ref"], request["blueprint_ref"]]
    paths.extend(item["path"] for item in request["source_refs"])
    if len(paths) != len(set(paths)):
        raise PackError("PACK_DUPLICATE_SOURCE_REF")
    source_by_path = {item["path"]: item for item in request["source_refs"]}
    active_ref = request["active_work_ref"]
    active_spec = source_by_path.get(active_ref)
    if active_spec is None:
        raise PackError("PACK_ACTIVE_WORK_REF_NOT_DECLARED", active_ref)
    if not active_spec["required"]:
        raise PackError("PACK_ACTIVE_WORK_REF_MUST_BE_REQUIRED", active_ref)
    if active_ref in (request["current_ref"], request["blueprint_ref"]):
        raise PackError("PACK_ACTIVE_WORK_REF_INVALID", active_ref)

    allowed_provenance = set(paths)
    for rule in request["distilled_rules"]:
        approval = rule.get("approval") or {}
        if approval.get("status") != "ACCEPTED":
            raise PackError("PACK_RULE_NOT_ACCEPTED", rule.get("rule_id", "UNKNOWN_RULE"))
        if approval.get("approval_ref") not in rule["provenance_refs"]:
            raise PackError("PACK_APPROVAL_REF_NOT_IN_PROVENANCE", rule.get("rule_id", "UNKNOWN_RULE"))
        unknown = sorted(set(rule["provenance_refs"]) - allowed_provenance)
        if unknown:
            raise PackError("PACK_PROVENANCE_REF_NOT_DECLARED", ",".join(unknown))
    rule_ids = [item["rule_id"] for item in request["distilled_rules"]]
    if len(rule_ids) != len(set(rule_ids)):
        raise PackError("PACK_RULE_ID_DUPLICATE")


def _work_input_path_refs(work: dict[str, Any]) -> set[str]:
    """Collect path-like required inputs and step inputs; symbolic names stay symbolic."""
    suffixes = {".json", ".md", ".py", ".txt", ".yaml", ".yml", ".toml", ".csv", ".svg", ".png"}
    values = list(work.get("required_inputs", []))
    for step in work.get("steps", []):
        if isinstance(step, dict):
            values.extend(step.get("inputs", []))
    refs = set()
    for item in values:
        if not isinstance(item, str):
            continue
        if "/" in item or Path(item).suffix.lower() in suffixes:
            refs.add(item)
    return refs


def _load_active_work(
    data: bytes,
    ref: str,
    current_projection: dict[str, Any],
    expected_blueprint_ref: str,
    expected_construction_ref: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    try:
        work_packet = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackError("PACK_ACTIVE_WORK_PACKET_INVALID", ref) from exc
    if not isinstance(work_packet, dict):
        raise PackError("PACK_ACTIVE_WORK_PACKET_INVALID", ref)
    _validate(work_packet, WORK_SCHEMA, "PACK_ACTIVE_WORK_PACKET_INVALID")
    if work_packet["status"] not in {"READY", "IN_PROGRESS", "BUILDING", "CHANGE_OBSERVED", "ACCEPTANCE"}:
        raise PackError("PACK_ACTIVE_WORK_NOT_ACTIVE", f"{ref}:{work_packet['status']}")
    if work_packet["blueprint_ref"] != expected_blueprint_ref:
        raise PackError("PACK_ACTIVE_WORK_BLUEPRINT_MISMATCH", ref)
    if work_packet["construction_packet_ref"] != expected_construction_ref:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_REF_MISMATCH", ref)
    contract = work_packet["operational_contract"]
    if work_packet["work_id"] != current_projection["stage_id"]:
        raise PackError("PACK_ACTIVE_WORK_ID_MISMATCH", ref)
    if work_packet["work_unit"] != current_projection["work_unit_id"] or contract["work_unit_id"] != work_packet["work_unit"]:
        raise PackError("PACK_CURRENT_ACTIVE_WORK_MISMATCH", ref)
    step_ids = [item["step_id"] for item in contract["steps"]]
    if len(step_ids) != len(set(step_ids)):
        raise PackError("PACK_STEP_ID_DUPLICATE")
    return work_packet, contract


def _load_active_construction(
    data: bytes,
    ref: str,
    active_work_packet: dict[str, Any],
    current_projection: dict[str, Any],
) -> dict[str, Any]:
    try:
        packet = json.loads(data.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_PACKET_INVALID", ref) from exc
    if not isinstance(packet, dict):
        raise PackError("PACK_ACTIVE_CONSTRUCTION_PACKET_INVALID", ref)
    _validate(packet, CONSTRUCTION_SCHEMA, "PACK_ACTIVE_CONSTRUCTION_PACKET_INVALID")
    work_unit = active_work_packet["work_unit"]
    if packet.get("packet_id") != f"CONSTRUCTION:{work_unit}":
        raise PackError("PACK_ACTIVE_CONSTRUCTION_ID_MISMATCH", ref)
    if packet.get("work_segment_ref") != work_unit:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_WORK_UNIT_MISMATCH", ref)
    if packet.get("status") not in {"READY", "BUILDING", "CHANGE_OBSERVED", "ACCEPTANCE"}:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_NOT_ACTIVE", f"{ref}:{packet.get('status')}")
    if packet.get("baseline_ref") not in {current_projection.get("target_blueprint_ref"), "P1-CURRENT.json"}:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_BASELINE_INVALID", ref)
    if packet.get("implementation_contract", {}).get("runtime_entrypoint") != BUILDER_REF:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_ENTRYPOINT_MISMATCH", ref)
    return packet


def build_pack(root: Path, request: dict[str, Any], *, request_ref: str) -> dict[str, Any]:
    """Build in memory from one explicit request. No repository discovery or output write occurs here."""
    root = root.resolve()
    _validate(request, REQUEST_SCHEMA, "PACK_REQUEST_INVALID")
    _validate_request_links(request)

    budget = request["resource_budget"]
    max_input = budget["max_explicit_input_bytes"]
    max_pack = budget["max_pack_bytes"]
    max_context = budget["max_context_chars"]
    max_steps = budget["max_steps"]
    requested_limits = {
        "max_explicit_input_bytes": (max_input, MAX_EXPLICIT_INPUT_BYTES),
        "max_pack_bytes": (max_pack, MAX_PACK_FILE_BYTES),
        "max_context_chars": (max_context, MAX_CONTEXT_CHARS),
        "max_steps": (max_steps, MAX_STEPS),
    }
    exceeds = [f"{name}={value}>{ceiling}" for name, (value, ceiling) in requested_limits.items() if value > ceiling]
    if exceeds:
        raise PackError("PACK_BUDGET_CONFIG_EXCEEDS_HARD_LIMIT", ";".join(exceeds))
    request_bytes = len(canonical_json(request))
    if request_bytes > max_input:
        raise PackError("PACK_INPUT_BUDGET_EXCEEDED", f"request:{request_bytes}>{max_input}")

    # In the production CLI the request is a versioned repository input. Check
    # the selected file after hard-budget gates and before reading other sources.
    request_path = _safe_path(root, request_ref)
    try:
        request_size = request_path.stat().st_size
    except OSError as exc:
        raise PackError("PACK_REQUEST_INVALID", request_ref) from exc
    if request_size > MAX_REQUEST_FILE_BYTES:
        raise PackError("PACK_REQUEST_TOO_LARGE", str(request_size))
    referenced_request = _load_json(request_path, "PACK_REQUEST_INVALID")
    _validate(referenced_request, REQUEST_SCHEMA, "PACK_REQUEST_INVALID")
    if referenced_request != request:
        raise PackError("PACK_REQUEST_REF_CONTENT_MISMATCH", request_ref)

    current_bytes, current_entry = _read_ref(
        root, request["current_ref"], max_bytes=max_input - request_bytes,
        required=True, purpose="CURRENT_AUTHORITY"
    )
    if current_bytes is None:
        raise PackError("PACK_REQUIRED_REF_MISSING", request["current_ref"])
    remaining_after_current = max_input - request_bytes - len(current_bytes)
    if remaining_after_current < 0:
        raise PackError("PACK_INPUT_BUDGET_EXCEEDED", request["current_ref"])
    blueprint_bytes, blueprint_entry = _read_ref(
        root, request["blueprint_ref"], max_bytes=remaining_after_current,
        required=True, purpose="BLUEPRINT_CONSTRAINTS"
    )
    if blueprint_bytes is None:
        raise PackError("PACK_REQUIRED_REF_MISSING", request["blueprint_ref"])

    try:
        current = json.loads(current_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackError("PACK_CURRENT_INVALID", request["current_ref"]) from exc
    if not isinstance(current, dict):
        raise PackError("PACK_CURRENT_INVALID", request["current_ref"])

    current_projection = _current_projection(current)
    if request["blueprint_ref"] != current_projection["target_blueprint_ref"]:
        raise PackError("PACK_BLUEPRINT_REF_NOT_CURRENT", request["blueprint_ref"])
    if request["active_work_ref"] != current_projection["active_work_packet_ref"]:
        raise PackError("PACK_ACTIVE_WORK_REF_NOT_CURRENT", request["active_work_ref"])
    active_construction_ref = current_projection["active_construction_packet_ref"]
    request_sources = {item["path"]: item for item in request["source_refs"]}
    construction_spec = request_sources.get(active_construction_ref)
    if not isinstance(construction_spec, dict) or construction_spec.get("required") is not True:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_REF_NOT_DECLARED_REQUIRED", active_construction_ref)
    if request.get("expected_current_fingerprint") and request["expected_current_fingerprint"] != current_projection["fingerprint"]:
        raise PackError("PACK_CURRENT_STALE", request["current_ref"])
    if request.get("expected_blueprint_sha256") and request["expected_blueprint_sha256"] != blueprint_entry["sha256"]:
        raise PackError("PACK_BLUEPRINT_STALE", request["blueprint_ref"])

    entries = [current_entry, blueprint_entry]
    source_data: dict[str, bytes] = {
        request["current_ref"]: current_bytes,
        request["blueprint_ref"]: blueprint_bytes,
    }
    omitted: list[str] = []
    source_bytes = len(current_bytes) + len(blueprint_bytes)
    input_bytes = request_bytes + source_bytes
    if input_bytes > max_input:
        raise PackError("PACK_INPUT_BUDGET_EXCEEDED", f"{input_bytes}>{max_input}")
    for item in request["source_refs"]:
        remaining = max_input - input_bytes
        data, entry = _read_ref(
            root, item["path"], max_bytes=remaining, required=item["required"], purpose=item["purpose"]
        )
        if data is not None:
            source_bytes += len(data)
            input_bytes += len(data)
            source_data[item["path"]] = data
            if input_bytes > max_input:
                raise PackError("PACK_INPUT_BUDGET_EXCEEDED", f"{input_bytes}>{max_input}")
            expected = item.get("expected_sha256")
            if expected and expected != entry["sha256"]:
                raise PackError("PACK_SOURCE_HASH_MISMATCH", item["path"])
        else:
            omitted.append(item["path"])
        entries.append(entry)

    active_ref = request["active_work_ref"]
    active_bytes = source_data.get(active_ref)
    if active_bytes is None:
        raise PackError("PACK_ACTIVE_WORK_REF_NOT_AVAILABLE", active_ref)
    active_packet, active_work = _load_active_work(
        active_bytes, active_ref, current_projection, request["blueprint_ref"], active_construction_ref
    )
    construction_bytes = source_data.get(active_construction_ref)
    if construction_bytes is None:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_REF_NOT_AVAILABLE", active_construction_ref)
    _load_active_construction(construction_bytes, active_construction_ref, active_packet, current_projection)
    step_count = len(active_work["steps"])
    if step_count > max_steps:
        raise PackError("PACK_STEP_BUDGET_EXCEEDED", f"{step_count}>{max_steps}")

    declared_paths = {entry["path"] for entry in entries}
    available_paths = {entry["path"] for entry in entries if entry["status"] == "INCLUDED"}
    required_work_paths = _work_input_path_refs(active_work)
    undeclared_work_paths = sorted(required_work_paths - declared_paths)
    if undeclared_work_paths:
        raise PackError("PACK_REQUIRED_WORK_INPUT_NOT_DECLARED", ",".join(undeclared_work_paths))
    unavailable_work_paths = sorted(required_work_paths - available_paths)
    if unavailable_work_paths:
        raise PackError("PACK_REQUIRED_WORK_INPUT_NOT_AVAILABLE", ",".join(unavailable_work_paths))
    for rule in request["distilled_rules"]:
        unavailable = sorted(set(rule["provenance_refs"]) - available_paths)
        if unavailable:
            raise PackError("PACK_PROVENANCE_NOT_AVAILABLE", ",".join(unavailable))

    entries.sort(key=lambda entry: entry["path"])
    input_material = {
        "request": request,
        "source_manifest": entries,
        "current_fingerprint": current_projection["fingerprint"],
        "measurement_contract_version": MEASUREMENT_CONTRACT_VERSION,
    }
    input_fingerprint = sha256(canonical_json(input_material))
    pack: dict[str, Any] = {
        "schema_version": "1.1",
        "kind": "OPERATIONAL_REFERENCE_PACK",
        "pack_id": request["pack_id"],
        "operation_id": request["operation_id"],
        "status": "READY",
        "builder_version": BUILDER_VERSION,
        "request_ref": request_ref,
        "request_fingerprint": sha256(canonical_json(request)),
        "authority": {
            "current_ref": request["current_ref"],
            "blueprint_ref": request["blueprint_ref"],
            "active_work_ref": active_ref,
            "active_construction_ref": active_construction_ref,
        },
        "current_projection": current_projection,
        "source_manifest": entries,
        "active_work": deepcopy(active_work),
        "distilled_rules": deepcopy(request["distilled_rules"]),
        "resource_usage": {
            "request_bytes": request_bytes,
            "source_bytes": source_bytes,
            "input_bytes": input_bytes,
            "max_explicit_input_bytes": max_input,
            "context_chars": 0,
            "context_char_unit": CONTEXT_CHAR_UNIT,
            "measurement_contract_version": MEASUREMENT_CONTRACT_VERSION,
            "model_token_count": None,
            "model_token_count_status": MODEL_TOKEN_COUNT_STATUS,
            "max_context_chars": max_context,
            "step_count": step_count,
            "max_steps": max_steps,
            "pack_bytes": 0,
            "max_pack_bytes": max_pack,
        },
        "omitted_refs": sorted(omitted),
        "input_fingerprint": input_fingerprint,
        "content_hash": "",
    }
    context_material = _context_material(
        current_projection, pack["active_work"], pack["distilled_rules"]
    )
    context_chars = _context_character_count(context_material)
    if context_chars > max_context:
        raise PackError("PACK_CONTEXT_BUDGET_EXCEEDED", f"{context_chars}>{max_context}")
    pack["resource_usage"]["context_chars"] = context_chars
    # pack_bytes is a self-referential metadata field; iterate to a fixed point.
    for _ in range(4):
        pack["content_hash"] = content_hash(pack)
        _validate(pack, PACK_SCHEMA, "PACK_OUTPUT_INVALID")
        # Include the final newline written to disk; the payload itself is canonical JSON.
        final_bytes = len(canonical_json(pack)) + 1
        if final_bytes > max_pack:
            raise PackError("PACK_OUTPUT_BUDGET_EXCEEDED", f"{final_bytes}>{max_pack}")
        if pack["resource_usage"]["pack_bytes"] == final_bytes:
            return pack
        pack["resource_usage"]["pack_bytes"] = final_bytes
    raise PackError("PACK_SIZE_DID_NOT_STABILIZE")


def verify_pack(root: Path, pack: dict[str, Any]) -> dict[str, Any]:
    """Verify hash, schema, current fingerprint and every explicitly listed source."""
    root = root.resolve()
    _validate(pack, PACK_SCHEMA, "PACK_OUTPUT_INVALID")
    if pack["content_hash"] != content_hash(pack):
        raise PackError("PACK_CONTENT_HASH_MISMATCH")
    request_ref = pack["request_ref"]
    request_path = _safe_path(root, request_ref)
    try:
        request_size = request_path.stat().st_size
    except OSError as exc:
        raise PackError("PACK_STALE_REQUEST", request_ref) from exc
    if request_size > MAX_REQUEST_FILE_BYTES:
        raise PackError("PACK_STALE_REQUEST", f"{request_ref}:request-too-large")
    try:
        current_request = _load_json(request_path, "PACK_STALE_REQUEST")
        _validate(current_request, REQUEST_SCHEMA, "PACK_STALE_REQUEST")
    except PackError as exc:
        raise PackError("PACK_STALE_REQUEST", request_ref) from exc
    current_request_fingerprint = sha256(canonical_json(current_request))
    if current_request_fingerprint != pack["request_fingerprint"]:
        raise PackError("PACK_STALE_REQUEST", request_ref)
    expected_input_fingerprint = sha256(canonical_json({
        "request": current_request,
        "source_manifest": pack["source_manifest"],
        "current_fingerprint": pack["current_projection"]["fingerprint"],
        "measurement_contract_version": MEASUREMENT_CONTRACT_VERSION,
    }))
    if expected_input_fingerprint != pack["input_fingerprint"]:
        raise PackError("PACK_INPUT_FINGERPRINT_MISMATCH")
    serialized_pack_bytes = len(canonical_json(pack)) + 1  # compact JSON plus one final newline
    usage = pack["resource_usage"]
    if serialized_pack_bytes > usage["max_pack_bytes"]:
        raise PackError("PACK_OUTPUT_BUDGET_EXCEEDED", f"{serialized_pack_bytes}>{usage['max_pack_bytes']}")
    manifest = pack["source_manifest"]
    manifest_paths = [entry["path"] for entry in manifest]
    if len(manifest_paths) != len(set(manifest_paths)):
        raise PackError("PACK_DUPLICATE_SOURCE_REF")
    required_authorities = {
        pack["authority"]["current_ref"],
        pack["authority"]["blueprint_ref"],
        pack["authority"]["active_work_ref"],
        pack["authority"]["active_construction_ref"],
    }
    for required_ref in required_authorities:
        if required_ref not in manifest_paths:
            raise PackError("PACK_AUTHORITY_REF_NOT_IN_MANIFEST", required_ref)
        entry = next(item for item in manifest if item["path"] == required_ref)
        if not entry["required"] or entry["status"] != "INCLUDED":
            raise PackError("PACK_AUTHORITY_REF_NOT_INCLUDED", required_ref)
    declared_paths = set(manifest_paths)
    included_paths = {entry["path"] for entry in manifest if entry["status"] == "INCLUDED"}
    required_work_paths = _work_input_path_refs(pack["active_work"])
    if required_work_paths - declared_paths:
        raise PackError("PACK_REQUIRED_WORK_INPUT_NOT_DECLARED", ",".join(sorted(required_work_paths - declared_paths)))
    if required_work_paths - included_paths:
        raise PackError("PACK_REQUIRED_WORK_INPUT_NOT_AVAILABLE", ",".join(sorted(required_work_paths - included_paths)))
    for rule in pack["distilled_rules"]:
        missing_provenance = sorted(set(rule["provenance_refs"]) - included_paths)
        if missing_provenance:
            raise PackError("PACK_PROVENANCE_NOT_AVAILABLE", ",".join(missing_provenance))

    max_input = usage["max_explicit_input_bytes"]
    request_bytes = usage["request_bytes"]
    if request_bytes > max_input:
        raise PackError("PACK_INPUT_BUDGET_EXCEEDED", f"request:{request_bytes}>{max_input}")
    current_ref = pack["authority"]["current_ref"]
    current_path = _safe_path(root, current_ref)
    current_remaining = max_input - request_bytes
    try:
        current_size = current_path.stat().st_size
    except OSError as exc:
        raise PackError("PACK_CURRENT_INVALID", current_ref) from exc
    if current_size > current_remaining:
        raise PackError("PACK_INPUT_BUDGET_EXCEEDED", current_ref)
    try:
        current_bytes = current_path.read_bytes()
        current = json.loads(current_bytes.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PackError("PACK_CURRENT_INVALID", current_ref) from exc
    if not isinstance(current, dict):
        raise PackError("PACK_CURRENT_INVALID", current_ref)
    verified_projection = _current_projection(current)
    if verified_projection["fingerprint"] != pack["current_projection"]["fingerprint"]:
        raise PackError("PACK_STALE_CURRENT", current_ref)
    if pack["authority"]["blueprint_ref"] != verified_projection["target_blueprint_ref"]:
        raise PackError("PACK_BLUEPRINT_REF_NOT_CURRENT", pack["authority"]["blueprint_ref"])
    active_work_ref = pack["authority"]["active_work_ref"]
    if active_work_ref != verified_projection["active_work_packet_ref"]:
        raise PackError("PACK_ACTIVE_WORK_REF_NOT_CURRENT", active_work_ref)
    if pack["current_projection"]["active_work_packet_ref"] != active_work_ref:
        raise PackError("PACK_ACTIVE_WORK_REF_MISMATCH", active_work_ref)
    active_construction_ref = pack["authority"]["active_construction_ref"]
    if active_construction_ref != verified_projection["active_construction_packet_ref"]:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_REF_NOT_CURRENT", active_construction_ref)
    if pack["current_projection"]["active_construction_packet_ref"] != active_construction_ref:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_REF_MISMATCH", active_construction_ref)

    cache: dict[str, bytes] = {current_ref: current_bytes}
    source_bytes = len(current_bytes)
    for entry in manifest:
        ref = entry["path"]
        path = _safe_path(root, ref)
        if not path.is_file():
            if entry["required"]:
                raise PackError("PACK_STALE_REQUIRED_SOURCE", ref)
            if entry["status"] != "OPTIONAL_MISSING":
                raise PackError("PACK_STALE_SOURCE", ref)
            continue
        if ref in cache:
            data = cache[ref]
            # Current bytes were already read to verify the authority fingerprint.
            if ref != current_ref:
                remaining = max_input - request_bytes - source_bytes
                if len(data) > remaining:
                    raise PackError("PACK_INPUT_BUDGET_EXCEEDED", f"{ref}:{len(data)}>{remaining}")
                source_bytes += len(data)
        else:
            remaining = max_input - request_bytes - source_bytes
            try:
                declared_size = path.stat().st_size
            except OSError as exc:
                raise PackError("PACK_SOURCE_UNREADABLE", ref) from exc
            if declared_size > remaining:
                raise PackError("PACK_INPUT_BUDGET_EXCEEDED", f"{ref}:{declared_size}>{remaining}")
            try:
                data = path.read_bytes()
            except OSError as exc:
                raise PackError("PACK_SOURCE_UNREADABLE", ref) from exc
            cache[ref] = data
            source_bytes += len(data)
        if len(data) > max_input:
            raise PackError("PACK_SOURCE_TOO_LARGE", ref)
        if entry["status"] != "INCLUDED" or sha256(data) != entry["sha256"] or len(data) != entry["byte_length"]:
            raise PackError("PACK_STALE_SOURCE", ref)

    active_work_bytes = cache.get(active_work_ref)
    if active_work_bytes is None:
        raise PackError("PACK_ACTIVE_WORK_REF_NOT_AVAILABLE", active_work_ref)
    current_active_packet, current_active_work = _load_active_work(
        active_work_bytes, active_work_ref, verified_projection,
        pack["authority"]["blueprint_ref"], active_construction_ref
    )
    if current_active_work != pack["active_work"]:
        raise PackError("PACK_ACTIVE_WORK_CONTENT_MISMATCH", active_work_ref)
    # Check semantic active-work equality before derived metadata so tampering
    # is reported as a content mismatch rather than being masked by size drift.
    context_material = _context_material(
        pack["current_projection"], pack["active_work"], pack["distilled_rules"]
    )
    context_chars = _context_character_count(context_material)
    if context_chars != usage["context_chars"] or context_chars > usage["max_context_chars"]:
        raise PackError("PACK_CONTEXT_SIZE_MISMATCH")
    construction_bytes = cache.get(active_construction_ref)
    if construction_bytes is None:
        raise PackError("PACK_ACTIVE_CONSTRUCTION_REF_NOT_AVAILABLE", active_construction_ref)
    _load_active_construction(construction_bytes, active_construction_ref, current_active_packet, verified_projection)
    if usage["step_count"] != len(current_active_work["steps"]):
        raise PackError("PACK_STEP_COUNT_MISMATCH")

    request_plus_source = pack["resource_usage"]["request_bytes"] + source_bytes
    if source_bytes != usage["source_bytes"] or request_plus_source != usage["input_bytes"]:
        raise PackError("PACK_INPUT_SIZE_MISMATCH")
    if request_plus_source > max_input:
        raise PackError("PACK_INPUT_BUDGET_EXCEEDED", str(request_plus_source))
    if usage["pack_bytes"] != serialized_pack_bytes:
        raise PackError("PACK_REPORTED_SIZE_MISMATCH")
    return {
        "status": "VERIFIED",
        "pack_id": pack["pack_id"],
        "operation_id": pack["operation_id"],
        "content_hash": pack["content_hash"],
        "source_count": len(manifest),
        "source_bytes": source_bytes,
        "history_loaded": 0,
        "repository_scan_performed": False,
    }


def _validated_pack_output_path(
    root: Path, output_ref: str, *, current_ref: str | None = None
) -> Path:
    """Allow only the canonical Pack or a runner-owned, non-symlink temp target."""
    root = root.resolve()
    candidate = Path(output_ref)
    if not output_ref or candidate.is_absolute() or ".." in candidate.parts:
        raise PackError("PACK_OUTPUT_PATH_FORBIDDEN", output_ref)

    # Check the lexical path before resolving it. _safe_path() intentionally
    # resolves symlinks for containment, but that would hide a symlink whose
    # target happens to be another allowed-looking directory under canonical/.
    cursor = root
    for part in candidate.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise PackError("PACK_OUTPUT_PATH_FORBIDDEN", output_ref)

    output_path = _safe_path(root, output_ref)
    if current_ref is not None and output_path == _safe_path(root, current_ref):
        raise PackError("PACK_CANNOT_OVERWRITE_CURRENT", output_ref)
    canonical_root = _safe_path(root, "P1-Central-Control/canonical")
    canonical_target = canonical_root / "operational_reference_pack.json"
    if output_path == canonical_target:
        return output_path

    parent = output_path.parent
    is_scoped_temporary_target = (
        parent.parent == canonical_root
        and parent.name.startswith(".p2-validation-")
        # Only the runner may supply a temporary destination: it creates the
        # isolated directory before invoking this CLI. Do not create arbitrary
        # .p2-validation-* directories as a side effect of a direct Builder call.
        and parent.is_dir()
        and output_path.name == "operational_reference_pack.json"
    )
    if is_scoped_temporary_target:
        return output_path
    raise PackError("PACK_OUTPUT_PATH_FORBIDDEN", output_ref)


def write_pack(root: Path, output_ref: str, pack: dict[str, Any]) -> dict[str, Any]:
    """Atomically replace the one designated derived pack; same hash is a no-op."""
    root = root.resolve()
    # Validate the in-memory contract, then reject unsupported targets before reading sources.
    _validate(pack, PACK_SCHEMA, "PACK_OUTPUT_INVALID")
    output_path = _validated_pack_output_path(
        root, output_ref, current_ref=pack["authority"]["current_ref"]
    )
    if pack["content_hash"] != content_hash(pack):
        raise PackError("PACK_CONTENT_HASH_MISMATCH")
    verified = verify_pack(root, pack)
    if verified["status"] != "VERIFIED":
        raise PackError("PACK_VERIFY_FAILED")
    current_path = _safe_path(root, pack["authority"]["current_ref"])
    if output_path == current_path:
        raise PackError("PACK_CANNOT_OVERWRITE_CURRENT", output_ref)
    protected_paths = {
        _safe_path(root, pack["authority"]["blueprint_ref"]),
        _safe_path(root, pack["request_ref"]),
    }
    protected_paths.update(_safe_path(root, entry["path"]) for entry in pack["source_manifest"])
    if output_path in protected_paths:
        raise PackError("PACK_CANNOT_OVERWRITE_SOURCE", output_ref)
    if output_path.is_file():
        try:
            existing_size = output_path.stat().st_size
            if existing_size <= min(MAX_PACK_FILE_BYTES, pack["resource_usage"]["max_pack_bytes"]):
                previous = _load_json(output_path, "PACK_EXISTING_INVALID")
                if previous.get("content_hash") == pack["content_hash"] and previous == pack:
                    return {"status": "UNCHANGED", "path": output_ref, "content_hash": pack["content_hash"]}
            # Oversized or invalid derived packs are replaced without loading their contents.
        except (OSError, PackError):
            # Pack is a derived cache, not authority; a corrupt copy can be rebuilt from validated inputs.
            pass
    output_path.parent.mkdir(parents=True, exist_ok=True)
    temp_path: Path | None = None
    payload = canonical_json(pack).decode("utf-8") + "\n"
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", dir=output_path.parent,
            prefix=f".{output_path.name}.", suffix=".tmp", delete=False,
        ) as temp:
            temp.write(payload)
            temp.flush()
            os.fsync(temp.fileno())
            temp_path = Path(temp.name)
        os.replace(temp_path, output_path)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()
    return {"status": "WRITTEN", "path": output_ref, "content_hash": pack["content_hash"]}


def main() -> int:
    parser = argparse.ArgumentParser(description="Build / verify a bounded Operational Reference Pack")
    sub = parser.add_subparsers(dest="command", required=True)
    build_cmd = sub.add_parser("build")
    build_cmd.add_argument("--request", required=True, help="explicit JSON request path relative to repository root")
    build_cmd.add_argument("--output", default="P1-Central-Control/canonical/operational_reference_pack.json")
    build_cmd.add_argument("--check-only", action="store_true")
    verify_cmd = sub.add_parser("verify")
    verify_cmd.add_argument("--pack", default="P1-Central-Control/canonical/operational_reference_pack.json")
    args = parser.parse_args()

    try:
        if args.command == "build":
            request_path = _safe_path(ROOT, args.request)
            try:
                request_size = request_path.stat().st_size
            except OSError as exc:
                raise PackError("PACK_REQUEST_INVALID", args.request) from exc
            if request_size > MAX_REQUEST_FILE_BYTES:
                raise PackError("PACK_REQUEST_TOO_LARGE", str(request_size))
            if request_path.is_file() is False:
                raise PackError("PACK_REQUEST_INVALID", args.request)
            request = _load_json(request_path, "PACK_REQUEST_INVALID")
            pack = build_pack(ROOT, request, request_ref=args.request)
            if args.check_only:
                result = {"status": "READY", "pack_id": pack["pack_id"], "content_hash": pack["content_hash"],
                          "resource_usage": pack["resource_usage"], "write_performed": False}
            else:
                if _safe_path(ROOT, args.output) == request_path:
                    raise PackError("PACK_CANNOT_OVERWRITE_REQUEST")
                result = write_pack(ROOT, args.output, pack)
        else:
            pack_path = _safe_path(ROOT, args.pack)
            try:
                pack_size = pack_path.stat().st_size
            except OSError as exc:
                raise PackError("PACK_OUTPUT_INVALID", args.pack) from exc
            if pack_size > MAX_PACK_FILE_BYTES:
                raise PackError("PACK_OUTPUT_TOO_LARGE", str(pack_size))
            pack = _load_json(pack_path, "PACK_OUTPUT_INVALID")
            result = verify_pack(ROOT, pack)
        print(json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2))
        return 0
    except PackError as exc:
        print(json.dumps({"status": "BLOCKED", "reason_code": exc.code, "detail": exc.detail}, ensure_ascii=False, sort_keys=True))
        return 3
    except (OSError, ValueError) as exc:
        print(json.dumps({"status": "BLOCKED", "reason_code": "PACK_INPUT_INVALID", "detail": str(exc)}, ensure_ascii=False, sort_keys=True))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
