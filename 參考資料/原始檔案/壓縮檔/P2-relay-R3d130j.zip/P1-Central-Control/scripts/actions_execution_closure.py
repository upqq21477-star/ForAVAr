#!/usr/bin/env python3
"""Resolve external Actions evidence and local acceptance into one closure classification."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_closure.schema.json"


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _validate(value: dict[str, Any]) -> None:
    Draft202012Validator(_load(SCHEMA)).validate(value)


def close(
    diagnostic: dict[str, Any],
    acceptance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    external = diagnostic.get("classification", "UNKNOWN")
    local = acceptance.get("status") if acceptance else None
    external_head = diagnostic.get("head_sha")
    local_head = acceptance.get("head_sha") if acceptance else None

    evidence_refs = [diagnostic.get("diagnostic_id", "ACTIONS_DIAGNOSTIC:UNKNOWN")]

    if acceptance:
        evidence_refs.append(
            acceptance.get("acceptance_id", "LOCAL_ACCEPTANCE:UNKNOWN")
        )
        if external_head and local_head and external_head != local_head:
            result = {
                "closure_id": f"ACTIONS_CLOSURE:{diagnostic.get('diagnostic_id', 'UNKNOWN').split(':',1)[-1]}",
                "external_classification": external,
                "local_acceptance_status": local,
                "closure_status": "CONFLICT",
                "program_truth": "EVIDENCE_CONFLICT",
                "head_sha": local_head,
                "evidence_refs": evidence_refs,
                "reason_code": "HEAD_SHA_MISMATCH",
            }
            _validate(result)
            return result

    if external == "PASS" and local == "PASS":
        status, truth, reason = "VERIFIED", "PROGRAM_VERIFIED", "EXTERNAL_AND_LOCAL_PASS"
    elif external == "RUNNER_STARTUP_FAILURE" and local == "PASS":
        status, truth, reason = "INCOMPLETE", "PROGRAM_UNRESOLVED", "LOCAL_PASS_DOES_NOT_VERIFY_EXTERNAL_EXECUTION"
    elif external == "WORKFLOW_EXECUTION_FAILURE" and local == "PASS":
        status, truth, reason = "VERIFIED", "PROGRAM_VERIFIED", "LOCAL_REPLAY_DID_NOT_REPRODUCE_EXTERNAL_FAILURE"
    elif local == "FAIL":
        status, truth, reason = "PROGRAM_REGRESSION_FAIL", "PROGRAM_REGRESSION", "LOCAL_ACCEPTANCE_FAILED"
    elif local == "INCOMPLETE":
        status, truth, reason = "INCOMPLETE", "PROGRAM_UNRESOLVED", "LOCAL_ACCEPTANCE_INCOMPLETE"
    elif local is None:
        status, truth, reason = "INCOMPLETE", "PROGRAM_UNRESOLVED", "LOCAL_ACCEPTANCE_MISSING"
    elif external in {"UNKNOWN", "NOT_DISPATCHED"}:
        status, truth, reason = "BLOCKED", "BLOCKED", "EXTERNAL_EVIDENCE_NOT_CLASSIFIABLE"
    else:
        status, truth, reason = "CONFLICT", "EVIDENCE_CONFLICT", "UNRESOLVED_EVIDENCE_COMBINATION"

    result = {
        "closure_id": f"ACTIONS_CLOSURE:{diagnostic.get('diagnostic_id', 'UNKNOWN').split(':',1)[-1]}",
        "external_classification": external,
        "local_acceptance_status": local,
        "closure_status": status,
        "program_truth": truth,
        "head_sha": local_head or external_head,
        "evidence_refs": evidence_refs,
        "reason_code": reason,
    }
    _validate(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Actions execution closure")
    parser.add_argument("diagnostic")
    parser.add_argument("output")
    parser.add_argument("--acceptance")
    args = parser.parse_args()

    diagnostic = _load(Path(args.diagnostic).resolve())
    acceptance = _load(Path(args.acceptance).resolve()) if args.acceptance else None
    result = close(diagnostic, acceptance)
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["closure_status"] not in {"PROGRAM_REGRESSION_FAIL", "BLOCKED"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
