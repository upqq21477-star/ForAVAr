#!/usr/bin/env python3
"""Convert reverse reconstruction evidence into a conservative partial-system state."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/reverse_reconstruction_result.schema.json"
STATE_SCHEMA = ROOT / "P1-Central-Control/schemas/partial_system_state.schema.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any], schema_path: Path) -> None:
    schema = _load(schema_path)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(value),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def execute(
    reverse_result: dict[str, Any],
    *,
    expected_paths: list[str] | None = None,
) -> dict[str, Any]:
    _validate(reverse_result, RESULT_SCHEMA)

    identity = reverse_result["identity"]
    structure = reverse_result["structure"]
    deps = reverse_result["dependencies"]
    assessment = reverse_result["state_assessment"]
    expected = sorted(set(expected_paths or []))

    inventory_paths = {row["path"] for row in reverse_result["inventory"]}
    missing = sorted(path for path in expected if path not in inventory_paths)

    blocked = reverse_result["status"] == "BLOCK"
    broken = assessment["broken"] or bool(structure["syntax_errors"])
    stub = assessment["stub"] or bool(structure["stub_signals"])
    unresolved = list(deps["unresolved"])

    if blocked:
        classification = "BLOCKED"
    elif broken:
        classification = "BROKEN"
    elif missing:
        classification = "MISSING"
    elif stub and assessment["partial"]:
        classification = "STUB"
    elif assessment["implemented"] and not unresolved:
        classification = "IMPLEMENTED"
    elif assessment["partial"] or unresolved:
        classification = "PARTIAL"
    else:
        classification = "UNKNOWN"

    unknown_items = list(reverse_result["evidence"]["unknown"])
    if not identity.get("source_revision"):
        unknown_items.append("source_revision")

    observed = list(reverse_result["evidence"]["observed"])
    observed.append(f"expected_paths.checked={len(expected)}")
    confirmed = list(reverse_result["evidence"]["confirmed"])
    inferred = list(reverse_result["evidence"]["inferred"])
    conflict = list(reverse_result["evidence"]["conflict"])

    if expected and not missing:
        confirmed.append("expected_paths_present")
    if missing:
        unknown_items.append("missing_paths_are_missing_within_scanned_scope_only")

    next_point = None
    if blocked:
        next_point = "repository-access"
    elif broken:
        next_point = structure["syntax_errors"][0]["path"]
    elif missing:
        next_point = missing[0]
    elif unresolved:
        next_point = unresolved[0]
    elif stub:
        next_point = structure["stub_signals"][0].split(":marker:", 1)[0]
    elif classification == "UNKNOWN":
        next_point = "selected-deep-read"
    else:
        next_point = assessment.get("next_diagnostic_point")

    result = {
        "schema_version": "1.0",
        "source_request_id": reverse_result["request_id"],
        "classification": classification,
        "implemented": classification == "IMPLEMENTED",
        "partial": classification in {"PARTIAL", "STUB", "MISSING", "BROKEN"},
        "stub": stub,
        "missing": missing,
        "broken": broken,
        "blocked": blocked,
        "unknown": classification == "UNKNOWN" or bool(unknown_items),
        "dependencies": {
            "resolved": [
                f"{edge['source']} -> {edge['target']}"
                for edge in deps["edges"]
            ],
            "unresolved": unresolved
        },
        "evidence": {
            "observed": sorted(set(observed)),
            "confirmed": sorted(set(confirmed)),
            "inferred": sorted(set(inferred)),
            "unknown": sorted(set(unknown_items)),
            "conflict": sorted(set(conflict))
        },
        "next_diagnostic_point": next_point
    }
    _validate(result, STATE_SCHEMA)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Build partial-system state from reverse reconstruction")
    parser.add_argument("reverse_result")
    parser.add_argument("--expected-path", action="append", default=[])
    args = parser.parse_args()
    result = execute(_load(Path(args.reverse_result).resolve()), expected_paths=args.expected_path)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
