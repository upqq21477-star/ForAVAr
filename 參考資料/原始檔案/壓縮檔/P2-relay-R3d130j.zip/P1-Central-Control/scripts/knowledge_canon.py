#!/usr/bin/env python3
"""CS-1 B2：Observation → Evidence → Claim 升格鏈與 Memory Integrity Gate（P4／P5／P13／P14／P18）。

stdlib only、決定性。機器只做可確定的事：引文須出現在已讀 Segment、類別規則、Claim→Evidence→Segment→Source
鏈、重複／衝突阻擋、無依據即拒；「Claim 是否真被證據支持」屬語義判斷，由 CONTROL_RESEARCH 以
adjudication（by＋rationale）負責，可被推翻。B2 只有 `promotion`（PROPOSED／CANONICAL／REJECTED）；
四維狀態、Conflict、Temporal／Version 在 `knowledge_versioning.TemporalKnowledgeStore`（B3，繼承本類）。Observation 屬 Research，須經本鏈才進 Canonical（P13）。
"""

from __future__ import annotations

import re
from typing import Any

from event_log import content_hash
from knowledge_intake import ReadingLedger, _sha, validate  # noqa: F401  （_sha 供測試共用）

READABLE = {"READ", "PROCESSED"}
_NOT_PROMOTABLE = {"INFERENCE": "INFERENCE_NOT_FACT", "UNKNOWN": "UNKNOWN_NOT_PROMOTABLE", "CONFLICT": "CONFLICT_NOT_PROMOTABLE"}


def _slug(ref: str) -> str:
    return ref.split(":", 1)[1]


def _norm(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip().casefold()


def _seal(record: dict[str, Any], schema: str) -> dict[str, Any]:
    record.pop("content_hash", None)
    record["content_hash"] = content_hash(record)
    validate(schema, record)
    return record


class KnowledgeStore:
    """記憶體內紀錄庫；texts＝{source_ref: 正規化全文}（由呼叫端提供，hash 不符即拒）。"""

    def __init__(self, ledger: ReadingLedger, texts: dict[str, str]) -> None:
        self.ledger, self.texts = ledger, texts
        self.obs: dict[str, dict[str, Any]] = {}
        self.evid: dict[str, dict[str, Any]] = {}
        self.claims: dict[str, dict[str, Any]] = {}

    def segment(self, ref: str) -> dict[str, Any]:
        if ref not in self.ledger.segments:
            raise ValueError(f"未知 segment: {ref}")
        return self.ledger.segments[ref]

    def segment_text(self, ref: str) -> str:
        seg = self.segment(ref)
        loc = seg["location"]
        text = self.texts[seg["source_ref"]][loc["start"] : loc["end"]]
        if _sha(text.encode("utf-8")) != seg["segment_text_hash"]:
            raise ValueError(f"Segment 文字與 hash 不符（來源已變）: {ref}")
        return text

    # ---- Observation ----
    def add_observation(
        self, cls: str, content: str, segment_ref: str, *, producer: str, captured_at: str,
        quote: str | None = None, basis_refs: list[str] | None = None, conflict_with: list[str] | None = None,
    ) -> dict[str, Any]:
        seg = self.segment(segment_ref)
        if self.ledger.state(segment_ref) not in READABLE:
            raise ValueError("SEGMENT_NOT_READ：未讀（或失敗／封鎖）的 Segment 不得產生 Observation")
        basis, conflict = list(basis_refs or []), list(conflict_with or [])
        if cls == "OBSERVED":
            if not quote or quote not in self.segment_text(segment_ref):
                raise ValueError("OBSERVED 須附出現在該 Segment 的 quote")
            if basis or conflict:
                raise ValueError("OBSERVED 不得帶 basis／conflict")
        elif cls == "INFERENCE":
            if not basis or any(self.obs.get(b, {}).get("observation_class") != "OBSERVED" for b in basis):
                raise ValueError("INFERENCE 須以已存在的 OBSERVED Observation 為 basis")
        elif cls == "CONFLICT":
            if len(set(conflict)) < 2 or any(self.obs.get(c, {}).get("observation_class") != "OBSERVED" for c in conflict):
                raise ValueError("CONFLICT 須指向至少兩筆已存在的 OBSERVED Observation")
        elif cls == "UNKNOWN":
            if basis or conflict:
                raise ValueError("UNKNOWN 不得帶 basis／conflict")
        else:
            raise ValueError(f"未知 observation_class: {cls}")
        record: dict[str, Any] = {
            "object_id": f"OBSERVATION:{_slug(segment_ref)}.O{len(self.obs) + 1:04d}",
            "kind": "OBSERVATION", "schema_version": "1.0", "observation_class": cls, "content": content,
            "segment_ref": segment_ref, "source_ref": seg["source_ref"], "producer": producer,
            "captured_at": captured_at, "basis_refs": basis, "conflict_with": conflict,
        }
        if quote:
            record["quote"] = quote
        self.obs[record["object_id"]] = _seal(record, "observation")
        return record

    # ---- Evidence（只能由 OBSERVED Observation 衍生；source／segment／locator 由鏈帶出，不手填）----
    def add_evidence(
        self, observation_ref: str, claim_ref: str, relation: str, *, producer: str, scope: str,
        captured_at: str, model_id: str | None = None, prompt_revision: str | None = None,
    ) -> dict[str, Any]:
        ob = self.obs.get(observation_ref)
        if not ob or ob["observation_class"] != "OBSERVED":
            raise ValueError("Evidence 只能來自已存在的 OBSERVED Observation")
        start = self.segment(ob["segment_ref"])["location"]["start"] + self.segment_text(ob["segment_ref"]).index(ob["quote"])
        record: dict[str, Any] = {
            "object_id": f"EVIDENCE:{_slug(claim_ref)}.E{len(self.evid) + 1:04d}",
            "kind": "EVIDENCE", "schema_version": "1.0", "source_ref": ob["source_ref"], "claim_ref": claim_ref,
            "relation": relation, "locator": f"chars {start}-{start + len(ob['quote'])}", "captured_at": captured_at,
            "segment_ref": ob["segment_ref"], "observation_ref": observation_ref, "producer": producer, "scope": scope,
        }
        if model_id:
            record["model_id"] = model_id
        if prompt_revision:
            record["prompt_revision"] = prompt_revision
        self.evid[record["object_id"]] = _seal(record, "evidence")
        return record

    # ---- Claim ----
    def propose_claim(self, claim_id: str, claim_kind: str, content: str, observation_refs: list[str],
                      evidence_refs: list[str]) -> dict[str, Any]:
        ref = f"CLAIM:{claim_id}"
        if ref in self.claims:
            raise ValueError(f"Claim 已存在: {ref}")
        if any(o not in self.obs for o in observation_refs):
            raise ValueError("Claim 引用未知 Observation")
        record = {
            "object_id": ref, "kind": "CLAIM", "schema_version": "1.0", "claim_kind": claim_kind, "content": content,
            "observation_refs": list(observation_refs), "evidence_refs": list(evidence_refs),
            "source_refs": sorted({self.obs[o]["source_ref"] for o in observation_refs}),
            "promotion": "PROPOSED", "revision": 1,
        }
        self.claims[ref] = _seal(record, "claim")
        return record

    def chain_errors(self, claim: dict[str, Any]) -> list[str]:
        """Claim→Evidence→Segment→Source 鏈與衝突檢查；回傳 reason code 清單（空＝通過）。"""
        errs: list[str] = []
        obs = [self.obs.get(o) for o in claim["observation_refs"]]
        for ref, ob in zip(claim["observation_refs"], obs):
            if ob is None:
                errs.append(f"OBSERVATION_UNKNOWN:{ref}")
                continue
            if ob["observation_class"] != "OBSERVED":
                errs.append(f"{_NOT_PROMOTABLE[ob['observation_class']]}:{ref}")
            elif self.ledger.state(ob["segment_ref"]) not in READABLE:
                errs.append(f"SEGMENT_NOT_READ:{ob['segment_ref']}")
            elif not any((self.evid.get(e) or {}).get("observation_ref") == ref and self.evid[e]["relation"] == "SUPPORTS"
                         and self.evid[e]["claim_ref"] == claim["object_id"] for e in claim["evidence_refs"]):
                errs.append(f"EVIDENCE_MISSING:{ref}")
        for e in claim["evidence_refs"]:
            ev = self.evid.get(e)
            ob = self.obs.get((ev or {}).get("observation_ref", ""))
            if ev is None or ev["claim_ref"] != claim["object_id"]:
                errs.append(f"EVIDENCE_INVALID:{e}")
            elif ev["relation"] == "CONTRADICTS":
                errs.append(f"CONTRADICTED:{e}")
            elif ob is None or (ev["segment_ref"], ev["source_ref"]) != (ob["segment_ref"], ob["source_ref"]):
                errs.append(f"CHAIN_MISMATCH:{e}")
        if claim["source_refs"] != sorted({o["source_ref"] for o in obs if o}):
            errs.append("SOURCE_REFS_MISMATCH")
        mine = set(claim["observation_refs"])
        errs += [f"CONFLICT_OPEN:{c['object_id']}" for c in self.obs.values()
                 if c["observation_class"] == "CONFLICT" and mine & set(c["conflict_with"])]
        return errs

    def promote(self, claim_ref: str, *, by: str, rationale: str) -> dict[str, Any]:
        """P5：Source／Duplicate／Conflict 檢查通過且附 adjudication 才升 CANONICAL；否則 BLOCK 並列出原因。"""
        claim = self.claims[claim_ref]
        errs = [] if claim["promotion"] == "PROPOSED" else [f"NOT_PROPOSED:{claim['promotion']}"]
        if not by.strip() or not rationale.strip():
            errs.append("ADJUDICATION_REQUIRED")
        errs += self.chain_errors(claim)
        errs += self._promote_errors(claim)
        key = (claim["claim_kind"], _norm(claim["content"]))
        live = ("ACTIVE", "TEMPORARY", "EXPERIMENTAL")  # 已 SUPERSEDED／ARCHIVED 的版本不擋重新主張
        errs += [f"DUPLICATE_CLAIM:{c['object_id']}" for c in self.claims.values()
                 if c["promotion"] == "CANONICAL" and c["object_id"] != claim_ref
                 and c["object_id"] not in claim.get("supersedes", []) and c.get("lifecycle", "ACTIVE") in live
                 and (c["claim_kind"], _norm(c["content"])) == key]
        if errs:
            return {"status": "BLOCK", "reason_codes": errs}
        promoted = dict(claim, promotion="CANONICAL", adjudication={"by": by, "rationale": rationale})
        self.claims[claim_ref] = _seal(promoted, "claim")
        self._after_promote(claim_ref)
        return {"status": "PROMOTED", "reason_codes": []}

    def _promote_errors(self, claim: dict[str, Any]) -> list[str]:  # B3 擴充點
        return []

    def _after_promote(self, claim_ref: str) -> None:  # B3 擴充點
        return None

    def reject(self, claim_ref: str, *, by: str, rationale: str) -> None:
        claim = self.claims[claim_ref]
        if claim["promotion"] != "PROPOSED" or not by.strip() or not rationale.strip():
            raise ValueError("只能以 adjudication 拒絕 PROPOSED Claim")
        self.claims[claim_ref] = _seal(dict(claim, promotion="REJECTED", adjudication={"by": by, "rationale": rationale}), "claim")

    # ---- P14 Memory Integrity Gate ----
    def integrity_gate(self) -> dict[str, Any]:
        errs: list[str] = []
        for entry in self.ledger.entries:
            if entry["status"] == "PROCESSED":
                refs = entry["observation_refs"]
                if not refs or any(self.obs.get(r, {}).get("segment_ref") != entry["segment_ref"] for r in refs):
                    errs.append(f"PROCESSED_WITHOUT_OBSERVATION:{entry['segment_ref']}")
        for ob in self.obs.values():
            if ob["content_hash"] != content_hash(ob):
                errs.append(f"HASH_MISMATCH:{ob['object_id']}")
            if ob["observation_class"] == "OBSERVED":
                try:
                    ok = ob["quote"] in self.segment_text(ob["segment_ref"])
                except ValueError:
                    ok = False
                if not ok:
                    errs.append(f"QUOTE_NOT_IN_SEGMENT:{ob['object_id']}")
        for ref, evidence in self.evid.items():
            if evidence.get("content_hash") != content_hash(evidence):
                errs.append(f"HASH_MISMATCH:{ref}")
            observation = self.obs.get(evidence.get("observation_ref", ""))
            if observation is None:
                errs.append(f"EVIDENCE_OBSERVATION_UNKNOWN:{ref}")
            elif (evidence.get("segment_ref"), evidence.get("source_ref")) != (observation.get("segment_ref"), observation.get("source_ref")):
                errs.append(f"EVIDENCE_CHAIN_MISMATCH:{ref}")
        for claim in self.claims.values():
            if claim["content_hash"] != content_hash(claim):
                errs.append(f"HASH_MISMATCH:{claim['object_id']}")
            if claim["promotion"] == "CANONICAL":
                if not claim.get("adjudication"):
                    errs.append(f"ADJUDICATION_MISSING:{claim['object_id']}")
                errs += [f"{claim['object_id']}:{e}" for e in self.chain_errors(claim)]
        return {"status": "BLOCK" if errs else "PASS", "errors": errs}
