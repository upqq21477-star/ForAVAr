"""evidence_outer -- outer layer around evidence_provenance_guard (CAP-EVIDENCE gaps G-EV1~3, R3d12zy S6 batch 3).  The guard itself is not changed.
G-EV1 classify(call): the guard's single ValueError -> PASS | INCOMPLETE (evidence missing / not ready / guard cannot run) | FAILED (evidence mismatch); verdict uses verify_verdict words
 (PASS|FAIL|INCOMPLETE).  The marker table is an assumption pinned to the guard's messages (MARKERS; a test checks they still exist); schema failure -> FAILED; other exceptions -> INCOMPLETE.
G-EV2 check_research_claims(claims[{id, kind HYPOTHESIS|SYNTHESIS, evidence_refs}], evidence[{object_id, claim_ref, relation}]): ref present, resolvable, bound to the claim, SUPPORTS; else REJECTED.
G-EV3 locator_warnings(evidence, base_dir, resolver): warns only (UNRESOLVED | UNVERIFIABLE for URLs | RESOLVER_ERROR); never changes a verdict; semantic support stays with independent VF.
Pure and stateless: interrupted = rerun.  BaseException (death) is never swallowed.  Ceiling: SIMULATED_PASS."""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Callable

INCOMPLETE_MARKERS = ("缺少 EvidenceRecord", "缺少 ProvenanceRecord", "Provenance 缺少 TaskPacket input_refs", "Provenance 缺少 ResultPacket output_refs",
                      "缺少 object_id", "尚未達 SUCCEEDED", "只驗收 WORK_COMPLETE")
MARKERS = INCOMPLETE_MARKERS + ("驗證失敗",)
KINDS = ("HYPOTHESIS", "SYNTHESIS")


def classify(call: Callable[[], Any]) -> dict[str, Any]:
    try:
        report = call()
    except ValueError as e:
        msg = str(e)
        if "驗證失敗" not in msg and any(m in msg for m in INCOMPLETE_MARKERS):
            return {"status": "INCOMPLETE", "verdict": "INCOMPLETE", "reason": "EVIDENCE_MISSING", "detail": msg}
        return {"status": "FAILED", "verdict": "FAIL", "reason": "EVIDENCE_MISMATCH", "detail": msg}
    except Exception:
        return {"status": "INCOMPLETE", "verdict": "INCOMPLETE", "reason": "GUARD_ERROR"}
    return {"status": "PASS", "verdict": "PASS", "reason": "", "report": report}


def _r(status: str, reason: str = "", bad: Any = None) -> dict[str, Any]:
    return {"status": status, "reason": reason, "bad": bad or []}


def check_research_claims(claims: Any, evidence: Any) -> dict[str, Any]:
    try:
        ids = [e["object_id"] for e in evidence] if isinstance(evidence, list) else None
        if (not isinstance(claims, list) or not claims or ids is None or len(set(ids)) != len(ids) or not all(isinstance(i, str) for i in ids)
                or not all(isinstance(c, dict) and isinstance(c.get("id"), str) and c.get("kind") in KINDS and isinstance(c.get("evidence_refs"), list)
                           and all(isinstance(x, str) for x in c["evidence_refs"]) for c in claims)):
            return _r("INCOMPLETE", "INPUT_UNREADABLE")
        idx, bad = dict(zip(ids, evidence)), []
        for c in claims:
            refs = c["evidence_refs"]
            why = ("NO_EVIDENCE_REF" if not refs else "UNRESOLVED_REF" if any(x not in idx for x in refs)
                   else "NOT_BOUND" if any(idx[x].get("claim_ref") != c["id"] for x in refs)
                   else "NOT_SUPPORTING" if any(idx[x].get("relation") != "SUPPORTS" for x in refs) else "")
            if why:
                bad.append({"claim": c["id"], "reason": why})
    except Exception:
        return _r("INCOMPLETE", "GUARD_ERROR")
    return _r("REJECTED", "BAD_CLAIM", bad) if bad else _r("PASS")


def _file_resolver(base: Path) -> Callable[[str], bool | None]:
    def f(loc: str) -> bool | None:
        if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", loc):
            return None
        root = base.resolve()
        p = (root / loc.split("#", 1)[0]).resolve()
        return p.is_relative_to(root) and p.exists()
    return f


def locator_warnings(evidence: Any, base_dir: Any, resolver: Callable[[str], bool | None] | None = None) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    if not isinstance(evidence, list):
        return out
    try:
        res = resolver or _file_resolver(Path(base_dir))
    except Exception:
        return [{"ref": None, "kind": "RESOLVER_ERROR", "locator": None}]
    for e in evidence:
        loc = e.get("locator") if isinstance(e, dict) else None
        if not isinstance(loc, str) or not loc:
            continue
        try:
            ok = res(loc)
        except Exception:
            ok = "ERR"
        kind = {True: "", False: "LOCATOR_UNRESOLVED", None: "LOCATOR_UNVERIFIABLE", "ERR": "RESOLVER_ERROR"}[ok]
        if kind:
            out.append({"ref": e.get("object_id"), "kind": kind, "locator": loc})
    return out
