#!/usr/bin/env python3
from __future__ import annotations

import argparse
import itertools
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

def main() -> int:
    ap = argparse.ArgumentParser(description="P1 capability usage + co-occurrence aggregator")
    ap.add_argument("records", help="JSON array of capability run records")
    args = ap.parse_args()

    payload = json.loads(Path(args.records).read_text(encoding="utf-8"))
    if isinstance(payload, dict) and isinstance(payload.get("capability_runs"), list):
        rows = payload["capability_runs"]
        source_mode = "CENTRAL_STATE"
    elif isinstance(payload, list):
        rows = payload
        source_mode = "RUN_FIXTURE"
    else:
        raise ValueError("輸入必須是 capability_runs 陣列或含 capability_runs 的 Central State")
    agg = defaultdict(lambda: {
        "execution_count": 0,
        "success_count": 0,
        "verification_failure_count": 0,
        "unresolved_count": 0,
        "segment_count": set(),
    })
    segment_caps: dict[str, set[str]] = defaultdict(set)

    for row in rows:
        cid = row.get("capability_id")
        sid = row.get("segment_id")
        if not cid:
            raise ValueError("缺少 capability_id")
        if not sid:
            raise ValueError("缺少 segment_id")

        a = agg[cid]
        a["execution_count"] += 1
        if row.get("status") in {"PASS", "COMPLETE", "WORK_COMPLETE"}:
            a["success_count"] += 1
        if row.get("status") == "UNRESOLVED":
            a["unresolved_count"] += 1
        if row.get("verification_status") == "FAIL":
            a["verification_failure_count"] += 1
        a["segment_count"].add(sid)
        segment_caps[sid].add(cid)

    capabilities = {}
    for cid, a in agg.items():
        n = a["execution_count"]
        capabilities[cid] = {
            "execution_count": n,
            "segment_count": len(a["segment_count"]),
            "success_count": a["success_count"],
            "success_rate": round(a["success_count"] / n, 4) if n else 0,
            "unresolved_count": a["unresolved_count"],
            "unresolved_rate": round(a["unresolved_count"] / n, 4) if n else 0,
            "verification_failure_count": a["verification_failure_count"],
            "verification_failure_rate": round(a["verification_failure_count"] / n, 4) if n else 0,
        }

    pairs = defaultdict(int)
    for caps in segment_caps.values():
        for a, b in itertools.combinations(sorted(caps), 2):
            pairs[(a, b)] += 1

    pair_rows = []
    for (a, b), count in sorted(pairs.items(), key=lambda x: (-x[1], x[0])):
        a_segments = len(agg[a]["segment_count"])
        b_segments = len(agg[b]["segment_count"])
        union = a_segments + b_segments - count
        jaccard = round(count / union, 4) if union else 0
        pair_rows.append({
            "capability_a": a,
            "capability_b": b,
            "cooccurrence_segments": count,
            "jaccard": jaccard,
        })

    suggestions = [
        p for p in pair_rows
        if p["cooccurrence_segments"] >= 2 and p["jaccard"] >= 0.5
    ]

    print(json.dumps({
        "status": "PASS",
        "source_mode": source_mode,
        "capabilities": capabilities,
        "cooccurrence_pairs": pair_rows,
        "cohort_candidates": suggestions,
        "note": "cohort_candidates 是統計候選，不會自動改寫 System Profile。"
    }, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
