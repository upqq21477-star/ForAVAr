#!/usr/bin/env python3
"""Evidence-bound change classification and routing for P2-F28.

This emits an authorized route proposal. It never writes the blueprint, Current,
permissions, or derived views; writes remain with designated owners.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[2]
SCHEMA_REF="P1-Central-Control/schemas/change_classification.schema.json"
SCOPES={"SINGLE_OUTPUT","SUBSYSTEM","MULTI_DOMAIN","CURRENT_OR_ROLE_OR_AUTHORITY"}
TARGET_KINDS={"content","contract","current_authority","role_permission","contract_precedence","global_policy","acceptance_gate","derived_document"}
EVIDENCE_KINDS={"OBSERVED","CONFIRMED","INFERRED","UNKNOWN","CONFLICT"}
BLUEPRINT="docs/architecture/P2-System-Blueprint-v1.0.md"
ROADMAP="docs/plans/P2-Relay-Update-Plan.md"
MATRIX="docs/plans/P2-Feature-Triage.md"
TEST_STRATEGY="docs/plans/P2-Relay-Update-Plan.md"

class ChangeClassificationError(ValueError): pass

def _text(v:Any,field:str,limit:int=3000)->str:
    if not isinstance(v,str) or not v.strip() or len(v)>limit: raise ChangeClassificationError(f"CHANGE_{field.upper()}_INVALID")
    return v.strip()

def _refs(v:Any,field:str,maximum:int=40)->list[str]:
    if not isinstance(v,list) or len(v)>maximum: raise ChangeClassificationError(f"CHANGE_{field.upper()}_INVALID")
    result=[]
    for item in v:
        if not isinstance(item,str) or not item.strip() or len(item)>500 or item.strip().startswith(("/","\\")) or ".." in Path(item.strip()).parts:
            raise ChangeClassificationError(f"CHANGE_{field.upper()}_REF_INVALID")
        if item.strip() not in result: result.append(item.strip())
    return result

def _route_record(change_id:str,status:str,classification:str|None,rationale:str,route:list[str],
                  targets:list[str],views:list[str],evidence:list[str],*,governance:bool,
                  eligible:bool,reuse:str,warnings:list[str])->dict[str,Any]:
    return {
        "change_id":change_id,"status":status,"classification":classification,
        "classification_rationale":rationale,"authority_owner":route[0],"route":route,
        "authoritative_targets":targets,"derived_views_to_sync":views,"reuse_rule":reuse,
        "acceptance_checks":[
            "Classification agrees with declared intent, impact scope, and authority.",
            "OBSERVED/CONFIRMED/INFERRED/UNKNOWN/CONFLICT remain distinct.",
            "Only the designated owner may modify each authoritative target.",
            "Synchronize only impacted derived views after authoritative approval.",
            "Never elevate a one-off event or unconfirmed hypothesis into a reusable rule."
        ],
        "evidence_refs":evidence,"governance_approval_required":governance,
        "eligible_for_blueprint_update":eligible,"warnings":warnings
    }

def _derived_views(classification:str,target_kinds:list[str],candidates:list[str],governance_approved:bool)->list[str]:
    # Only known, declared derivative views may be proposed; caller hints cannot add arbitrary write targets.
    allowed={BLUEPRINT,ROADMAP,MATRIX,TEST_STRATEGY,"README.md",
             "P1-Central-Control/scripts/run_p2_validation.py",
             "P1-Central-Control/scripts/run_p2_validation_cycle.py"}
    impacted=[]
    if classification in {"LOCAL_RULE","SYSTEMIC_CAPABILITY"} or (classification=="ARCHITECTURE_INVARIANT" and governance_approved):
        impacted.append(BLUEPRINT)
    if classification in {"LOCAL_RULE","SYSTEMIC_CAPABILITY"}:
        # Only caller-declared affected views are selected; absence of a candidate means no blanket sync.
        impacted.extend(p for p in candidates if p in allowed and p not in {BLUEPRINT,"P1-CURRENT.json"})
    if classification=="ARCHITECTURE_INVARIANT" and governance_approved:
        impacted.extend(p for p in candidates if p in allowed and p not in {BLUEPRINT,"P1-CURRENT.json"})
    if "acceptance_gate" in target_kinds:
        for p in ("P1-Central-Control/scripts/run_p2_validation.py","P1-Central-Control/scripts/run_p2_validation_cycle.py"):
            if p in candidates and p not in impacted: impacted.append(p)
    if "current_authority" in target_kinds and "P1-CURRENT.json" in candidates:
        impacted.append("P1-CURRENT.json")
    return list(dict.fromkeys(impacted))

def classify_and_route(request:dict[str,Any])->dict[str,Any]:
    if not isinstance(request,dict): raise ChangeClassificationError("CHANGE_REQUEST_OBJECT_REQUIRED")
    change_id=_text(request.get("change_id"),"ID",120)
    _text(request.get("statement"),"STATEMENT")
    scope=request.get("affected_scope")
    if scope not in SCOPES: raise ChangeClassificationError("CHANGE_SCOPE_INVALID")
    one_off=request.get("explicit_one_off",False)
    confirmed=request.get("confirmed_reusable_mechanism",False)
    governance_approval=request.get("governance_approval",False)
    if not all(isinstance(x,bool) for x in (one_off,confirmed,governance_approval)):
        raise ChangeClassificationError("CHANGE_BOOLEAN_FLAG_INVALID")
    recurrence=request.get("recurrence_count",0)
    if type(recurrence) is not int or recurrence<0 or recurrence>1000000: raise ChangeClassificationError("CHANGE_RECURRENCE_COUNT_INVALID")
    evidence_refs=_refs(request.get("evidence_refs",[]),"EVIDENCE")
    targets=_refs(request.get("authoritative_targets",[]),"TARGETS")
    candidates=_refs(request.get("candidate_derived_views",[]),"DERIVED_VIEWS")
    target_kinds=request.get("target_kinds",[])
    if not isinstance(target_kinds,list) or any(x not in TARGET_KINDS for x in target_kinds): raise ChangeClassificationError("CHANGE_TARGET_KINDS_INVALID")
    evidence=request.get("evidence",[])
    if not isinstance(evidence,list) or len(evidence)>40: raise ChangeClassificationError("CHANGE_EVIDENCE_INVALID")
    for item in evidence:
        if not isinstance(item,dict) or item.get("kind") not in EVIDENCE_KINDS:
            raise ChangeClassificationError("CHANGE_EVIDENCE_KIND_INVALID")
        _text(item.get("statement"),"EVIDENCE_STATEMENT")
    if one_off and scope!="SINGLE_OUTPUT":
        return _route_record(change_id,"BLOCKED_CONFLICT",None,
            "Explicit ONE_OFF intent conflicts with the declared broader impact scope; resolve the scope before routing.",
            ["Brain/Cognitive Decision","Governance"],targets,[],evidence_refs,
            governance=(scope=="CURRENT_OR_ROLE_OR_AUTHORITY" or bool(set(target_kinds)&{"current_authority","role_permission","contract_precedence","global_policy"})),eligible=False,
            reuse="Do not promote a generic rule until the scope conflict is resolved.",
            warnings=["One-off intent conflicts with subsystem, multi-domain, or authority-wide impact."])
    authority_scope=scope=="CURRENT_OR_ROLE_OR_AUTHORITY" or bool(set(target_kinds)&{"current_authority","role_permission","contract_precedence","global_policy"})
    unsupported_evidence=any(x["kind"] in {"INFERRED","UNKNOWN","CONFLICT"} for x in evidence)
    evidence_confirmed=bool(evidence_refs) and confirmed and any(x["kind"] in {"OBSERVED","CONFIRMED"} for x in evidence) and not unsupported_evidence
    if authority_scope:
        status="ROUTED" if governance_approval and evidence_confirmed else "NEEDS_GOVERNANCE_APPROVAL"
        warnings=[]
        if not governance_approval: warnings.append("Governance approval is required before changing the invariant or authority contract.")
        if not evidence_confirmed: warnings.append("Confirmed supporting evidence is required; hypotheses/unknowns/conflicts cannot authorize the update.")
        eligible=governance_approval and evidence_confirmed
        return _route_record(change_id,status,"ARCHITECTURE_INVARIANT",
            "The change touches Current authority, role permission, contract precedence, or global policy; recurrence alone is not decisive.",
            ["Brain/Cognitive Decision","Governance","Blueprint Engineering","Central","Realization/Executor","Assurance/Verifier"],
            targets,_derived_views("ARCHITECTURE_INVARIANT",target_kinds,candidates,governance_approval),evidence_refs,
            governance=True,eligible=eligible,
            reuse="Change the sole invariant only after governance approval and evidence review.",warnings=warnings)
    if one_off:
        return _route_record(change_id,"ROUTED","ONE_OFF",
            "The requester explicitly limits impact to one output and no wider scope is declared.",
            ["Brain/Cognitive Decision","Central","Realization/Executor","Assurance/Verifier"],
            targets,[],evidence_refs,governance=False,eligible=False,
            reuse="Do not promote this exception into a reusable rule without new evidence and authorized reclassification.",warnings=[])
    if scope=="MULTI_DOMAIN":
        if not evidence_confirmed:
            return _route_record(change_id,"NEEDS_EVIDENCE",None,
                "Multi-domain impact is a systemic candidate, but evidence does not yet confirm a reusable mechanism.",
                ["Brain/Cognitive Decision","Evolution","Assurance/Verifier"],targets,[],evidence_refs,
                governance=False,eligible=False,
                reuse="Keep the proposal unclassified until a cross-domain mechanism is confirmed.",
                warnings=["Cross-domain scope alone does not prove a reusable systemic mechanism."])
        return _route_record(change_id,"ROUTED","SYSTEMIC_CAPABILITY",
            "A confirmed reusable mechanism affects multiple domains; update the sole blueprint first, then only impacted derived views.",
            ["Brain/Cognitive Decision","Blueprint Engineering","Evolution","Central","Realization/Executor","Assurance/Verifier"],
            targets,_derived_views("SYSTEMIC_CAPABILITY",target_kinds,candidates,True),evidence_refs,
            governance=False,eligible=True,
            reuse="Reuse for the same confirmed scope; reopen only on new evidence or contrary constraints.",warnings=[])
    if scope=="SUBSYSTEM" or recurrence>=2:
        if not evidence_confirmed:
            return _route_record(change_id,"NEEDS_EVIDENCE",None,
                "Subsystem scope or recurrence alone is insufficient to establish a reusable local rule.",
                ["Brain/Cognitive Decision","Evolution","Assurance/Verifier"],targets,[],evidence_refs,
                governance=False,eligible=False,
                reuse="Keep the current baseline until the local mechanism is confirmed.",
                warnings=["Provide confirming evidence and a discriminating test before rule promotion."])
        return _route_record(change_id,"ROUTED","LOCAL_RULE",
            "A confirmed reusable mechanism applies to a specific subsystem, not all of P2.",
            ["Brain/Cognitive Decision","Blueprint Engineering","Evolution","Realization/Executor","Assurance/Verifier"],
            targets,_derived_views("LOCAL_RULE",target_kinds,candidates,True),evidence_refs,
            governance=False,eligible=True,
            reuse="Apply only within the declared subsystem; do not broaden scope without new evidence.",warnings=[])
    return _route_record(change_id,"NEEDS_EVIDENCE",None,
        "Impact and reuse scope remain unclear; preserve UNKNOWN rather than guessing a class.",
        ["Brain/Cognitive Decision","Assurance/Verifier"],targets,[],evidence_refs,
        governance=False,eligible=False,reuse="Keep the current baseline until scope and reusable mechanism are evidenced.",
        warnings=["No confirmed one-off intent or evidenced reusable mechanism was supplied."])

def validate_record(record:dict[str,Any],root:Path=ROOT)->None:
    path=root/SCHEMA_REF
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
        raise ChangeClassificationError("CHANGE_SCHEMA_PATH_INVALID")
    try:
        from jsonschema import Draft202012Validator
        schema=json.loads(path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema); Draft202012Validator(schema).validate(record)
    except ChangeClassificationError: raise
    except Exception as exc: raise ChangeClassificationError(f"CHANGE_RECORD_SCHEMA_INVALID:{type(exc).__name__}") from exc

def main()->int:
    parser=argparse.ArgumentParser(description="Classify a change and route it to the authorized owner")
    parser.add_argument("--request",required=True); parser.add_argument("--output")
    args=parser.parse_args()
    try:
        record=classify_and_route(json.loads(Path(args.request).read_text(encoding="utf-8")))
        validate_record(record)
        rendered=json.dumps(record,ensure_ascii=False,indent=2)+"\n"
        if args.output: Path(args.output).write_text(rendered,encoding="utf-8")
        print(rendered,end="")
        return 0 if record["status"]=="ROUTED" else 2
    except (OSError,json.JSONDecodeError,ChangeClassificationError) as exc:
        print(json.dumps({"status":"BLOCKED","reason_code":str(exc).split(":",1)[0],"detail":str(exc)},ensure_ascii=False,indent=2)); return 2

if __name__=="__main__": raise SystemExit(main())
