#!/usr/bin/env python3
"""P2 p2_run - Track B thin loop (R5-S1; stdlib + existing modules; no API, no network).

task -> Brief -> Provider proposal -> mode controller -> Gate -> tool -> Verifier -> hash-chained trace -> closure_chain.
Tools: read, search, edit, run_tests (workdir-bound, path/suffix/command allowlist, output cap, edit write protection).
Results are SIMULATED_PASS (toy repo in a temp dir), never real-run evidence.

  python3 P1-Central-Control/scripts/p2_run.py --simulate [--save-trace <file>]
Track A (manual equivalent, no code): propose -> confirm goal -> plan gates -> one edit inside write_scope -> run tests ->
write one line per step with its evidence level; any rejected step is recorded, not retried silently (OD3: retry once).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import brain_mode_controller as bmc  # noqa: E402
import brain_provider as bp  # noqa: E402
import closure_chain as cc  # noqa: E402
import continuation_context_box as ccb  # noqa: E402
import debug_escalation_policy as dep  # noqa: E402
import dialogue_loop as dl  # noqa: E402
import gap_ledger as gl  # noqa: E402
import verify_verdict as vv  # noqa: E402
import event_log as el  # noqa: E402
import librarian as lib  # noqa: E402
import role_command_router as rcr  # noqa: E402
import role_session_gate as rsg  # noqa: E402
import path_distill as pd  # noqa: E402
import provenance_trace as ptr  # noqa: E402
import task_set as ts  # noqa: E402
import run_journal as rj  # noqa: E402
from atomic_write import atomic_write, stale_temps  # noqa: E402
import feature_lifecycle as fl

SUFFIXES = (".py", ".md", ".txt", ".json")
COMMANDS = {"unittest": [sys.executable, "-B", "-m", "unittest", "discover", "-s", "tests", "-q"]}
OUT_CAP = 1500
MAX_DIFF = 40
ZERO = "0" * 64
DEFAULT_FAST = True  # R6: fast paths on by default; path_distill.replay flips it for equivalence replay
TOOLS = ("read", "search", "edit", "run_tests")


def digest(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


class GateReject(Exception):
    def __init__(self, code: str) -> None:
        super().__init__(code)
        self.code = code


class StepError(Exception):
    def __init__(self, code: str, retryable: bool = False) -> None:
        super().__init__(code)
        self.code, self.retryable = code, retryable


class _JournalStop(Exception):
    pass


@dataclass
class ResumeResult:
    status: str  # RESUMED / NOTHING_TO_RESUME / INCOMPLETE / FAILED
    reason: str = ""
    last_seq: int = 0
    warnings: list = field(default_factory=list)
    run: Any = None


def verify_trace(trace: list[dict[str, Any]]) -> list[str]:
    errs, prev = [], ZERO
    for i, e in enumerate(trace):
        body = {k: v for k, v in e.items() if k != "hash"}
        if e.get("seq") != i + 1:
            errs.append(f"SEQ_BROKEN:{i + 1}")
        if e.get("prev") != prev:
            errs.append(f"CHAIN_BROKEN:{i + 1}")
        if e.get("hash") != digest(body):
            errs.append(f"HASH_MISMATCH:{i + 1}")
        prev = e.get("hash", "")
    return errs


class Run:
    def __init__(self, workdir: str | Path, *, write_scope: list[str], protected: list[str] | None = None, budget: int = 12,
                 goal_confirmed: bool = False, brief: dict | None = None, run_id: str = "RUN-1",
                 write_fn: Callable[[Path, str], None] | None = None, use_fast: bool | None = None,
                 journal_path: str | Path | None = None) -> None:
        self.work = Path(workdir).resolve()
        self.write_scope, self.protected = list(write_scope), list(protected or [])
        self.budget, self.goal_confirmed, self.brief, self.run_id = budget, goal_confirmed, brief, run_id
        self.mode, self.trace, self.attempts, self.diffs = "THINKING", [], [], []
        self.role, self.capability = None, None
        self.baseline, self.revision = None, None
        self.write_fn = write_fn or atomic_write
        self.use_fast = DEFAULT_FAST if use_fast is None else use_fast
        self.journal, self._stopped = None, None
        # four-stage lifecycle is a base capability: BUILD work opens a stage-1 checklist by itself
        self.lifecycle = fl.new_checklist(run_id, "BUILD:" + run_id) if (brief or {}).get("route") == "BUILD" else None
        self._params = {"run_id": run_id, "write_scope": list(write_scope), "protected": list(protected or []),
                        "budget0": budget, "goal_confirmed": goal_confirmed}
        if journal_path is not None:  # G2: a new Run never appends to an existing journal (use Run.resume)
            self.journal = rj.Journal(journal_path)
            if self.journal.records:
                self.journal.close()
                raise rj.JournalError("JOURNAL_EXISTS_USE_RESUME")
            self._jr("unit", {"what": "init", **self._params})

    # ---- trace -------------------------------------------------------------------------------------------------
    def _log(self, tool: str, args: Any, verdict: str, code: str) -> None:
        e = {"seq": len(self.trace) + 1, "tool": tool, "args_digest": digest(args), "verdict": verdict, "code": code,
             "mode": self.mode, "brief_use": {"brief_hash": lib.content_hash(self.brief)} if self.brief else None,
             "prev": self.trace[-1]["hash"] if self.trace else ZERO}
        e["hash"] = digest(e)
        self.trace.append(e)
        self._jr("trace", e)

    # ---- mode controller ---------------------------------------------------------------------------------------
    def _jr(self, kind: str, payload: Any) -> None:
        if self.journal is None or self._stopped:
            return
        try:
            self.journal.append(kind, payload)
        except rj.JournalError:
            self._stopped = "journal_write_failed"  # never continue without a log (G2 E4)

    def release(self) -> None:
        if self.journal is not None:
            self.journal.close()

    def to_mode(self, event: str, **kw: Any) -> bool:
        r = bmc.transition_mode(current_mode=self.mode, event=event, **kw)
        if r.get("status") == "BLOCK":
            self._log("MODE", {"event": event}, "REJECT", str(r.get("reason_code")))
            return False
        self.mode = r["mode"]
        self._log("MODE", {"event": event}, "ALLOW", self.mode)
        return True

    # ---- Gate + tools ------------------------------------------------------------------------------------------
    def _path(self, rel: Any) -> Path:
        if not isinstance(rel, str) or not rel or os.path.isabs(rel) or ".." in Path(rel).parts:
            raise GateReject("PATH_ESCAPE")
        p = (self.work / rel).resolve()
        try:
            p.relative_to(self.work)
        except ValueError:
            raise GateReject("PATH_ESCAPE") from None
        if p.suffix not in SUFFIXES:
            raise GateReject("SUFFIX_NOT_ALLOWED")
        return p

    def _fast(self, tool: str, args: dict[str, Any]) -> str | None:
        """R6 fast path (FP2 tool/budget gate, FP1 path gate); None = miss -> original path below."""
        c = pd.fp_tool_gate(tool, self.budget, TOOLS)
        if c is None and (tool == "read" or (tool == "edit" and self.mode == "CONSTRUCTION" and self.goal_confirmed)):
            c = pd.fp_path_gate(args, tool, self.work, SUFFIXES)
        return c

    def _stop_out(self) -> dict[str, Any]:
        return {"ok": False, "code": "INCOMPLETE", "reason": self._stopped}

    def _error(self, tool: str, args: Any, e: Exception) -> dict[str, Any]:
        # G1: classify; unknown exceptions fail closed and only the type name is kept
        if isinstance(e, StepError):
            code, retry = e.code, e.retryable
        elif isinstance(e, UnicodeDecodeError):
            code, retry = "DECODE_ERROR", True
        elif isinstance(e, subprocess.TimeoutExpired):
            code, retry = "TIMEOUT", True
        elif isinstance(e, OSError):
            code, retry = "IO_ERROR", False
        else:
            code, retry = "UNEXPECTED", False
        if tool == "edit":
            retry = False  # may be partially applied: read back and reconcile before any retry
        self.budget -= 1
        self._log(tool, args, "ERROR", code)
        if self._stopped:
            return self._stop_out()
        out = {"ok": False, "code": code, "verdict": "ERROR", "retryable": retry}
        if code == "UNEXPECTED":
            out["error_type"] = type(e).__name__
        return out

    def step(self, tool: str, args: dict[str, Any]) -> dict[str, Any]:
        if self._stopped:
            return self._stop_out()
        fc = self._fast(tool, args) if self.use_fast else None
        if fc:
            self._log(tool, args, "REJECT", fc)
            return {"ok": False, "code": fc}
        try:
            if tool not in TOOLS:
                raise GateReject("TOOL_UNKNOWN")
            if self.budget <= 0:
                raise GateReject("BUDGET_EXHAUSTED")
            out = getattr(self, "_" + tool)(**args)
        except GateReject as g:
            self._log(tool, args, "REJECT", g.code)
            return {"ok": False, "code": g.code}
        except TypeError:
            self._log(tool, args, "REJECT", "BAD_ARGS")
            return {"ok": False, "code": "BAD_ARGS"}
        except _JournalStop:
            return self._stop_out()
        except (KeyboardInterrupt, SystemExit):
            self._log(tool, args, "INTERRUPTED", "INTERRUPTED")
            raise
        except Exception as e:
            return self._error(tool, args, e)
        self.budget -= 1
        self._log(tool, args, "ALLOW", "OK")
        if self._stopped:
            return self._stop_out()
        return {"ok": True, "code": "OK", "out": out}

    def _read(self, path: str) -> str:
        p = self._path(path)
        return p.read_text(encoding="utf-8")[:OUT_CAP] if p.is_file() else ""

    def _search(self, pattern: str) -> list[str]:
        hits: list[str] = []
        for p in sorted(self.work.rglob("*")):
            if p.is_file() and p.suffix in SUFFIXES and "__pycache__" not in p.parts:
                for n, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
                    if pattern in line:
                        hits.append(f"{p.relative_to(self.work).as_posix()}:{n}:{line.strip()[:80]}")
        return hits[:20]

    def _edit(self, path: str, old: str, new: str, preview_lines: int = MAX_DIFF) -> dict[str, Any]:
        if self.mode != "CONSTRUCTION":
            raise GateReject("NOT_AUTHORIZED_TO_BUILD")
        if not self.goal_confirmed:
            raise GateReject("GOAL_NOT_CONFIRMED")
        p = self._path(path)
        rel = p.relative_to(self.work).as_posix()
        if rel not in self.write_scope:
            raise GateReject("OUT_OF_SCOPE")
        if rel in self.protected:
            raise GateReject("PROTECTED_PATH")
        text = p.read_text(encoding="utf-8")
        if text.count(old) != 1:
            raise GateReject("EDIT_NO_MATCH")
        after = text.replace(old, new, 1)
        changed = sum(1 for a, b in zip(text.splitlines(), after.splitlines()) if a != b) + abs(
            len(text.splitlines()) - len(after.splitlines()))
        if changed > min(preview_lines, MAX_DIFF):
            raise GateReject("DIFF_EXCEEDS_PREVIEW")
        self._jr("intent", {"tool": "edit", "path": rel, "before": digest(text), "after": digest(after)})
        if self._stopped:
            raise _JournalStop()
        self.write_fn(p, after)
        if p.read_text(encoding="utf-8") != after:  # post-write diff check
            atomic_write(p, text)
            raise GateReject("POST_DIFF_MISMATCH")
        d = {"path": rel, "before": digest(text), "after": digest(after)}
        self.diffs.append(d)
        self._jr("diff", d)
        return {"path": rel, "changed_lines": changed}

    def _run_tests(self, cmd: str = "unittest") -> dict[str, Any]:
        if self.mode not in ("CONSTRUCTION", "SIMULATION"):
            raise GateReject("NOT_AUTHORIZED_TO_RUN")
        if cmd not in COMMANDS:
            raise GateReject("COMMAND_NOT_ALLOWED")
        env = {"PATH": os.environ.get("PATH", ""), "PYTHONDONTWRITEBYTECODE": "1"}
        try:
            r = subprocess.run(COMMANDS[cmd], cwd=self.work, capture_output=True, text=True, timeout=30, env=env)
        except subprocess.TimeoutExpired:
            self._incomplete("TIMEOUT", True)
        except OSError:
            self._incomplete("LAUNCH_FAILED", False)
        if r.returncode < 0:
            self._incomplete("SIGNALED", False)
        if self.use_fast:
            pd.fp_test_outcome(self.attempts, r.returncode, self.run_id)
        else:
            self.attempts.append({"step": "run_tests", "outcome": "success" if r.returncode == 0 else "failure",
                                  "head_sha": self.run_id, "t": len(self.attempts)})
        self._jr("attempt", self.attempts[-1])
        return {"exit": r.returncode, "out": (r.stdout + r.stderr)[-OUT_CAP:]}

    def _incomplete(self, code: str, retryable: bool) -> None:
        # FP3 error path: same record in the fast and legacy branches; then surface as a typed step error
        self.attempts.append({"step": "run_tests", "outcome": "incomplete", "error_code": code, "head_sha": self.run_id,
                              "t": len(self.attempts)})
        self._jr("attempt", self.attempts[-1])
        raise StepError(code, retryable)

    def _provenance(self) -> dict[str, Any]:
        """CAP-PROVENANCE: the edit -> run_tests chain of this run.  Pure (reads trace + diffs only), so a resumed run gives the same result."""
        diffs, cur, ver, orig, recs, start = iter(self.diffs), {}, {}, set(), [], None
        for e in self.trace:
            if e["verdict"] != "ALLOW":
                continue
            if e["tool"] == "edit":
                d = next(diffs)
                p, n = d["path"], ver.get(d["path"], 0)
                a, b = f"{p}#{n}@{d['before'][:12]}", f"{p}#{n + 1}@{d['after'][:12]}"
                if n == 0:
                    orig.add(a)  # only the first before-state of a file is a declared original; a later mismatch = changed outside the run
                ver[p], cur[p] = n + 1, b
                recs.append({"id": f"e{e['seq']}", "activity": "edit", "input_refs": [a], "output_refs": [b], "started": e["seq"], "ended": e["seq"]})
            elif e["tool"] == "run_tests":
                start = f"tests@{e['seq']}"
                recs.append({"id": f"t{e['seq']}", "activity": "run_tests", "input_refs": sorted(cur.values()), "output_refs": [start], "started": e["seq"], "ended": e["seq"]})
        return {"status": "NOT_APPLICABLE"} if start is None else ptr.trace(recs, start, originals=orig)

    def begin_work_unit(self, change_radius: list[str], revision: Any) -> dict[str, Any]:
        """Baseline write point (FR-06): hash the read-only context files the work depends on; close() checks drift."""
        self.revision = revision
        self.baseline = ccb.make_baseline(self.work, list(change_radius), revision)
        self._log("BASELINE", {"radius": list(change_radius)}, "ALLOW", "BASELINE_WRITTEN")
        self._jr("unit", {"what": "baseline", "baseline": self.baseline, "revision": self.revision})
        return self.baseline

    # ---- role + capability selection (V13) -----------------------------------------------------------------------
    def select_role(self, role_id: str, capability_id: str | None, operation: str, command: str, profile_id: str,
                    mode: str, targets: list[str] | None = None) -> dict[str, Any]:
        """Record the role/capability choice in the trace; role_session_gate (which calls task_set.assert_role_capability)
        blocks mismatches. A blocked choice is traced and returned, never silently dropped."""
        req = {"request_id": f"{self.run_id}:{len(self.trace) + 1}", "role_id": role_id, "operation": operation,
               "activation_command": command, "profile_id": profile_id, "mode": mode,
               "requested_write_targets": list(targets or []), "external_research": False, "history_loaded": 0,
               "transient_context_loaded": False, "targeted_retrieval_only": True}
        if capability_id:
            req["capability_id"] = capability_id
        if role_id == "ROLE:EXECUTOR":
            req["task_packet_ref"] = f"task:{self.run_id}"
        elif role_id == "ROLE:VERIFIER":
            req["verification_target_ref"] = req["verification_target_refs"] = None
            req["verification_target_ref"], req["verification_target_refs"] = f"result:{self.run_id}", [f"result:{self.run_id}"]
        try:
            r = rsg.admission(req)
            status, reasons = r.get("status", "?"), list(r.get("reason_codes") or [])
        except ValueError as e:  # schema rejection
            status, reasons = "BLOCK", ["REQUEST_SCHEMA:" + str(e)[:60]]
        ok = status != "BLOCK"
        self._log("ROLE", {"role": role_id, "cap": capability_id, "op": operation}, "ALLOW" if ok else "REJECT",
                  reasons[0] if reasons else status)
        if ok:
            self.role, self.capability = role_id, capability_id
            self._jr("unit", {"what": "role", "role": role_id, "capability": capability_id})
        return {"ok": ok, "status": status, "reasons": reasons}

    # ---- failure ladder (OD3) ----------------------------------------------------------------------------------
    def ladder(self, step: str, retryable: bool = True) -> dict[str, Any]:
        try:
            last = [a for a in self.attempts if a.get("step") == step][-1:]
            if last and last[0].get("outcome") == "incomplete":  # retryable comes from the error_code table, not the caller
                retryable = dep.RETRYABLE_CODES.get(str(last[0].get("error_code")), False)
            d = dep.retry_decision(self.attempts, step, retryable=retryable)
        except Exception:  # fail closed
            d = {"action": "STOP_WAITING", "level": 0, "reason": "LADDER_ERROR", "escalation": None}
        self._log("LADDER", {"step": step}, d["action"], d["reason"])
        return d

    # ---- closure -----------------------------------------------------------------------------------------------
    @classmethod
    def resume(cls, workdir: str | Path, journal_path: str | Path, *, write_scope: list[str], protected: list[str] | None = None,
               budget: int = 12, goal_confirmed: bool = False, brief: dict | None = None, run_id: str = "RUN-1",
               write_fn: Callable[[Path, str], None] | None = None, use_fast: bool | None = None,
               log_path: str | Path | None = None, conversation_id: str | None = None) -> ResumeResult:
        # G3: rebuild state from the verified journal (not replay); reconcile a pending edit intent by file hash; explicit call only
        want = {"run_id": run_id, "write_scope": list(write_scope), "protected": list(protected or []),
                "budget0": budget, "goal_confirmed": goal_confirmed}
        try:
            j = rj.Journal(journal_path)
        except rj.JournalLocked:
            return ResumeResult("INCOMPLETE", "LOCKED")
        except rj.JournalCorrupt as e:
            return ResumeResult("INCOMPLETE", f"JOURNAL_CORRUPT:{e.line}")
        except rj.JournalError as e:
            return ResumeResult("INCOMPLETE", str(e))

        def out(status: str, reason: str = "") -> ResumeResult:
            j.close()
            return ResumeResult(status, reason, j.last_seq, list(j.warnings))
        recs = j.records
        if not recs or recs[0]["kind"] != "unit" or recs[0]["payload"].get("what") != "init":
            return out("INCOMPLETE", "EMPTY_JOURNAL")
        if j.closed:
            return out("NOTHING_TO_RESUME")
        if {k: recs[0]["payload"].get(k) for k in want} != want:
            return out("FAILED", "PARAMS_MISMATCH")
        trace = [r["payload"] for r in recs if r["kind"] == "trace"]
        if verify_trace(trace):
            return out("INCOMPLETE", "TRACE_CHAIN_BROKEN")
        run = cls(workdir, write_scope=write_scope, protected=protected, budget=budget, goal_confirmed=goal_confirmed,
                  brief=brief, run_id=run_id, write_fn=write_fn, use_fast=use_fast)
        run.trace = trace
        run.attempts = [r["payload"] for r in recs if r["kind"] == "attempt"]
        run.verdicts = [r["payload"] for r in recs if r["kind"] == "verdict"]  # CAP-VERIFY: a journaled verdict is not recomputed
        run.diffs = [{k: r["payload"][k] for k in ("path", "before", "after")} for r in recs if r["kind"] == "diff"]
        run.budget = budget - sum(1 for e in trace if e["tool"] in TOOLS and e["verdict"] in ("ALLOW", "ERROR"))
        run.mode = trace[-1]["mode"] if trace else "THINKING"
        pend = None
        for r in recs:
            w = r["payload"]
            if r["kind"] == "unit" and w.get("what") == "baseline":
                run.baseline, run.revision = w["baseline"], w["revision"]
            elif r["kind"] == "unit" and w.get("what") == "role":
                run.role, run.capability = w["role"], w["capability"]
            elif r["kind"] == "intent":
                pend = None if w.get("void") else w
            elif r["kind"] == "trace" and w.get("tool") == "edit":
                pend = None
        if pend:  # intent without completion: decide by the file's current hash (an edit re-run would give EDIT_NO_MATCH)
            try:
                cur = digest(run._path(pend["path"]).read_text(encoding="utf-8"))
            except (OSError, GateReject, UnicodeDecodeError):
                cur = None
            if cur not in (pend["before"], pend["after"]):
                return out("INCOMPLETE", "INTENT_UNDECIDABLE")
        dlg: list[str] = []
        if brief is not None and log_path is not None and conversation_id:  # CONVERSATION-RECORD: brief must match the log
            try:
                d = dl.resume_from_brief(brief, el.EventLog(log_path).events_for("SEGMENT", run_id), conversation_id)
            except Exception:  # fail closed: a brief that cannot be checked is not trusted
                return out("INCOMPLETE", "DIALOGUE_UNREADABLE")
            if d["status"] == "REJECTED":
                return out("INCOMPLETE", "DIALOGUE_REJECTED:" + ";".join(d["reasons"]))
            run.dialogue_next_turn = d.get("next_turn")
            dlg = ["BRIEF_BEHIND:" + ";".join(d["reasons"])] if d["status"] == "BRIEF_BEHIND" else []
        run.journal = j
        if pend and cur == pend["after"]:
            d = {"path": pend["path"], "before": pend["before"], "after": pend["after"]}
            run.diffs.append(d)
            run._jr("diff", {**d, "recovered": True})
            run.budget -= 1
            run._log("edit", {"path": pend["path"]}, "ALLOW", "RECOVERED")
        elif pend:
            run._jr("intent", {"void": True})
        if run._stopped:
            run.release()
            return ResumeResult("INCOMPLETE", run._stopped, j.last_seq, list(j.warnings))
        warns = list(j.warnings) + ([f"STALE_TEMP:{len(stale_temps(run.work))}"] if stale_temps(run.work) else []) + dlg
        return ResumeResult("RESUMED", "", j.last_seq, warns, run)

    def close(self, log_path: Path, conversation_id: str, occurred_at: str = "2026-10-15T00:00:00Z",
              gap_path: Path | None = None) -> dict[str, Any]:
        passed = [e for e in self.trace if e["tool"] == "run_tests" and e["verdict"] == "ALLOW"]
        ok = any(a["outcome"] == "success" for a in self.attempts[-1:])
        head = self.trace[-1]["hash"] if self.trace else ""
        refs = {"SCOPE": digest(self.write_scope), "IMPACT": digest(self.diffs) if self.diffs else "",
                "ARTIFACTS": ",".join(d["path"] for d in self.diffs), "EVIDENCE": head,
                "REGRESSION": f"run_tests@{passed[-1]['seq']}" if passed and ok else "", "LIFECYCLE": f"workdir:{self.work.name}",
                "CURRENT": f"p2_run:{self.run_id}", "CLOSURE": head}
        rec = {"steps": [{"step": s, "ref": refs[s], "evidence_level": "SIMULATED_PASS"} for s in cc.STEPS]}
        if self.baseline is not None:
            rec["baseline"] = self.baseline
        res = cc.evaluate(rec, root=self.work, current_revision=self.revision) if self.baseline is not None else cc.evaluate(rec)
        last = self.attempts[-1]["outcome"] if self.attempts else None
        res["outcome_class"] = {"success": "PASSED", "failure": "FAILED"}.get(last, "INCOMPLETE")
        try:
            log = el.EventLog(log_path)
            for role, text in (("USER", "task:" + self.run_id), ("ASSISTANT", "closure:" + res["status"])):
                el.record_dialogue_turn(log, workflow_id=self.run_id, conversation_id=conversation_id, role=role, content=text,
                                        occurred_at=occurred_at)
            evs = log.events_for("SEGMENT", self.run_id)
            res["dialogue_turns"] = len(el.read_dialogue(evs, conversation_id))
            v = dl.verify_dialogue(evs, conversation_id)  # CONVERSATION-RECORD: RECORDED / UNVERIFIED (outcome unchanged)
            res["dialogue_status"] = "RECORDED" if v["status"] == "OK" else "UNVERIFIED"
            if v["status"] != "OK":
                res["dialogue_reasons"] = v["reasons"]
        except Exception:  # fail closed: close never raises
            res["outcome_class"], res["close_error"], res["dialogue_status"] = "INCOMPLETE", "CLOSE_WRITE_FAILED", "UNRECORDED"
        try:  # CAP-VERIFY: evidence -> verdict (journaled, reused on resume); CAP-GAP: FAIL/INCOMPLETE -> gap checkpoint
            v = vv.verify(self.run_id, {"attempts": self.attempts, "head": head}, prior=getattr(self, "verdicts", []))
            res["verdict"] = v["verdict"]
            if not v.get("reused"):
                self.verdicts = getattr(self, "verdicts", []) + [v]
                self._jr("verdict", v)
        except Exception:
            res["outcome_class"], res["close_error"] = "INCOMPLETE", "VERIFY_FAILED"
        else:
            if gap_path is not None:
                try:
                    ck = gl.load(gap_path)
                    gl.apply_verdict(ck, v, task=self.run_id)
                    gl.save(gap_path, ck)
                    res["gaps"] = len(ck["gaps"])
                except Exception:  # a gap that cannot be persisted is never dropped silently: close is INCOMPLETE
                    res["outcome_class"], res["close_error"] = "INCOMPLETE", "GAP_WRITE_FAILED"
        try:  # CAP-PROVENANCE: informational like dialogue_status (outcome unchanged); an error or odd input -> INCOMPLETE, death is not swallowed
            pv = self._provenance()
            if pv["status"] == "NOT_APPLICABLE":
                res["provenance"] = "NOT_APPLICABLE"
            else:
                pi = ptr.provenance_input(pv)
                res["provenance"], res["provenance_ok"] = pv["status"], None if pi is None else pi["ok"]
        except Exception:
            res["provenance"] = "INCOMPLETE"
        if self.lifecycle is not None:  # a run with an open lifecycle can never report PASSED
            lb = fl.blockers(self.lifecycle)
            res["lifecycle_stage"], res["lifecycle_blockers"] = self.lifecycle["stage"], lb
            if lb and res["outcome_class"] == "PASSED":
                res["outcome_class"] = "INCOMPLETE"
        if self.journal is not None:
            if not self.journal.closed:
                self._jr("closed", {"outcome_class": res["outcome_class"]})
            self.release()
        return res


# ---- loop_contract (FR-12 / FR-05 / FR-10) ----------------------------------------------------------------------
CAP_FIELDS = ("provider", "consumer", "modes", "success", "failure_feedback")


def loop_contract(rounds: list[dict[str, Any]], capabilities: list[dict[str, Any]] | None = None) -> list[str]:
    codes: list[str] = []
    seen: set[str] = set()
    for i, r in enumerate(rounds):
        if not str(r.get("done_when") or "").strip():
            codes.append(f"NO_COMPLETION_CONDITION:{i + 1}")
        h = str(r.get("state_hash") or "")
        if h in seen:
            codes.append(f"REPEATED_STATE:{i + 1}")
        seen.add(h)
        if i > 0:
            if not (r.get("new_evidence") or r.get("new_question")):
                codes.append(f"NO_NEW_INPUT:{i + 1}")
            prev = set(rounds[i - 1].get("unknowns") or [])
            if prev - set(r.get("unknowns") or []) - set(r.get("resolved") or []):
                codes.append(f"UNKNOWN_DROPPED:{i + 1}")
    for c in capabilities or []:
        codes += [f"CAP_FIELD_MISSING:{c.get('name')}:{f}" for f in CAP_FIELDS if not c.get(f)]
    return codes


# ---- simulation -------------------------------------------------------------------------------------------------
GATES = {k: True for k in bmc.PLAN_GATE_KEYS}


def _toy(tmp: Path) -> Path:
    (tmp / "tests").mkdir(parents=True)
    (tmp / "calc.py").write_text("def add(a, b):\n    return a - b\n", encoding="utf-8")
    (tmp / "other.py").write_text("X = 1\n", encoding="utf-8")
    (tmp / "protected.json").write_text("{}\n", encoding="utf-8")
    (tmp / "tests" / "test_calc.py").write_text(
        "import sys, unittest\nsys.path.insert(0, '.')\nimport calc\n\n\nclass T(unittest.TestCase):\n"
        "    def test_add(self):\n        self.assertEqual(calc.add(2, 3), 5)\n\n\nif __name__ == '__main__':\n    unittest.main()\n",
        encoding="utf-8")
    return tmp


def _build_mode(run: Run) -> bool:
    return (run.to_mode("TASK_STARTED") and run.to_mode("THINKING_COMPLETE", plan_gates=GATES)
            and run.to_mode("PLAN_APPROVED", plan_gates=GATES, plan_approved=True) and run.mode == "CONSTRUCTION")


def simulate(save_trace: str | None = None) -> list[tuple[str, bool, str]]:
    res: list[tuple[str, bool, str]] = []

    def chk(name: str, cond: bool, detail: str = "") -> None:
        res.append((name, bool(cond), detail))

    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        mk = lambda n, **kw: Run(_toy(base / n), write_scope=["calc.py", "protected.json"], protected=["protected.json"],
                                 run_id=n, **kw)  # noqa: E731
        # N1-N11: Gate negatives
        r = mk("n1", goal_confirmed=True); _build_mode(r)
        chk("N01 out-of-bounds write (absolute path)", r.step("edit", {"path": "/etc/x.py", "old": "a", "new": "b"})["code"] == "PATH_ESCAPE")
        chk("N02 path traversal", r.step("read", {"path": "../outside.py"})["code"] == "PATH_ESCAPE")
        chk("N03 dangerous command", r.step("run_tests", {"cmd": "rm -rf /"})["code"] == "COMMAND_NOT_ALLOWED")
        chk("N04 outside write_scope", r.step("edit", {"path": "other.py", "old": "1", "new": "2"})["code"] == "OUT_OF_SCOPE")
        chk("N05 write to protected path", r.step("edit", {"path": "protected.json", "old": "{}", "new": "{1}"})["code"] == "PROTECTED_PATH")
        chk("N06 diff exceeds preview", r.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b", "preview_lines": 0})["code"] == "DIFF_EXCEEDS_PREVIEW")
        b = mk("n7", goal_confirmed=True, budget=1); b.step("read", {"path": "calc.py"})
        chk("N07 budget exhausted", b.step("read", {"path": "calc.py"})["code"] == "BUDGET_EXHAUSTED")
        t = mk("n8"); t.to_mode("TASK_STARTED")
        chk("N08 illegal mode transition", t.to_mode("FINAL_ACCEPTANCE_PASSED") is False and t.mode == "THINKING")
        chk("N09 unauthorized build (THINKING)", t.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"})["code"] == "NOT_AUTHORIZED_TO_BUILD")
        g = mk("n10", goal_confirmed=False); _build_mode(g)
        chk("N10 write before goal confirmed", g.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"})["code"] == "GOAL_NOT_CONFIRMED")
        tr = [dict(e) for e in r.trace]; tr[1]["code"] = "OK"
        chk("N11 tampered trace chain detected", verify_trace(r.trace) == [] and verify_trace(tr) != [])
        tw = mk("n12", goal_confirmed=True, write_fn=lambda p, s: p.write_text(s + "# x\n", encoding="utf-8")); _build_mode(tw)
        chk("N12 post-write diff mismatch rolled back", tw.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"})["code"] == "POST_DIFF_MISMATCH"
            and "a - b" in (tw.work / "calc.py").read_text(encoding="utf-8"))
        # M5 closure: provider -> build -> fix -> verifier -> trace -> closure_chain
        brief = lib.sample_brief("STARTUP", "B")
        c = mk("c1", goal_confirmed=True, brief=brief)
        prop = bp.propose({"request_id": "c1", "signals": {"writes": ["calc.py"]}, "truth_ambiguous": False})
        chk("C01 provider proposal accepted (STANDARD)", prop["status"] == "ACCEPT" and prop["tier"] == "STANDARD", str(prop["codes"]))
        chk("C02 build mode reached via controller", _build_mode(c))
        c.begin_work_unit(["tests/test_calc.py"], "rev-1")
        s1 = c.step("run_tests", {"cmd": "unittest"})
        chk("C03 verifier fails on the toy bug", s1["ok"] and s1["out"]["exit"] != 0)
        c.step("read", {"path": "calc.py"}); c.step("search", {"pattern": "return"})
        chk("C04 edit fixes the bug", c.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"})["ok"])
        s2 = c.step("run_tests", {"cmd": "unittest"})
        chk("C05 verifier passes after fix", s2["ok"] and s2["out"]["exit"] == 0)
        chk("C06 trace verifies and carries brief_use", verify_trace(c.trace) == [] and all(e["brief_use"] for e in c.trace))
        cl = c.close(base / "c1.log", "conv-c1")
        chk("C07 closure_chain COMPLETE + DIALOGUE_TURN written", cl["status"] == "COMPLETE" and cl["dialogue_turns"] == 2, str(cl))
        chk("C07b closure carried a checked baseline", c.baseline is not None and any(e["tool"] == "BASELINE" for e in c.trace))
        dr = mk("c3", goal_confirmed=True); _build_mode(dr); dr.begin_work_unit(["tests/test_calc.py"], "rev-1")
        dr.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"}); dr.step("run_tests", {})
        (dr.work / "tests" / "test_calc.py").write_text((dr.work / "tests" / "test_calc.py").read_text(encoding="utf-8") + "# drift\n", encoding="utf-8")
        chk("C09 context drifted after baseline -> closure STALE", dr.close(base / "c3.log", "conv-c3")["status"] == "STALE")
        fl = mk("c2", goal_confirmed=True); _build_mode(fl); fl.step("run_tests", {})
        chk("C08 failing run -> closure INCOMPLETE", fl.close(base / "c2.log", "conv-c2")["status"] == "INCOMPLETE")
        if save_trace:
            Path(save_trace).write_text(json.dumps({"run_id": "c1", "trace": c.trace, "closure": cl}, indent=1) + "\n", encoding="utf-8")
        # S6: return to THINKING, retry ladder, tiers
        chk("S01 failure returns to THINKING", c.to_mode("VALIDATION_FAILED") and c.mode == "THINKING", c.mode)
        w = mk("w1", goal_confirmed=True); _build_mode(w)
        w.step("run_tests", {}); d1 = w.ladder("run_tests"); w.step("run_tests", {}); d2 = w.ladder("run_tests")
        chk("S02 first failure -> RETRY, second -> STOP_WAITING with reason", d1["action"] == "RETRY" and d2["action"] == "STOP_WAITING" and d2["reason"] == "RETRY_LIMIT_REACHED", f"{d1['action']},{d2['action']}")
        chk("S03 not retryable -> STOP_FAILED", dep.retry_decision(w.attempts, "run_tests", retryable=False)["action"] == "STOP_FAILED")
        chk("S04 LIGHT: no writes, no brief, no build", bp.propose({"request_id": "l", "signals": {}, "truth_ambiguous": False})["tier"] == "LIGHT")
        pd = bp.propose({"request_id": "d", "signals": {"writes": ["protected.json"], "protected_paths": ["protected.json"]}, "truth_ambiguous": False})
        chk("S05 write escalates STANDARD; protected path escalates DEEP", prop["tier"] == "STANDARD" and pd["tier"] == "DEEP")

        class Low(bp.ScriptedProvider):
            def raw(self, tf: dict) -> dict:
                x = super().raw(tf); x["tier"] = "LIGHT"; return x
        lo = bp.propose({"request_id": "x", "signals": {"writes": ["calc.py"]}, "truth_ambiguous": False}, Low())
        chk("S06 below-floor proposal rejected", lo["status"] == "REJECT" and "TIER_BELOW_FLOOR" in lo["codes"])
        # M4b loop_contract
        ok = [{"state_hash": "a", "done_when": "tests pass", "unknowns": ["u1"]},
              {"state_hash": "b", "done_when": "tests pass", "new_evidence": ["t"], "unknowns": ["u1"]}]
        chk("L01 valid loop accepted", loop_contract(ok, [{"name": "c", **{f: "x" for f in CAP_FIELDS}}]) == [])
        chk("L02 no new input", any(x.startswith("NO_NEW_INPUT") for x in loop_contract([ok[0], {**ok[1], "new_evidence": []}])))
        chk("L03 repeated state", any(x.startswith("REPEATED_STATE") for x in loop_contract([ok[0], {**ok[1], "state_hash": "a"}])))
        chk("L04 unknown dropped", any(x.startswith("UNKNOWN_DROPPED") for x in loop_contract([ok[0], {**ok[1], "unknowns": []}])))
        chk("L05 no completion condition", any(x.startswith("NO_COMPLETION") for x in loop_contract([{**ok[0], "done_when": ""}])))
        chk("L06 capability five fields", loop_contract(ok, [{"name": "c", "provider": "p"}]) != [])
        # M3 (V13): role / capability selection through role_session_gate + role_capability_binding
        rr = mk("r1", goal_confirmed=True)
        EX = dict(role_id="ROLE:EXECUTOR", operation="EXECUTE_TASK", command="！施工", profile_id="IP:CONSTRUCTION-EXECUTOR", mode="CONSTRUCTION", targets=["TASK_SCOPE"])
        a = rr.select_role(capability_id="CAP-ITERATE", **EX)
        chk("R01 executor + bound capability accepted and traced", a["ok"] and rr.role == "ROLE:EXECUTOR" and rr.trace[-1]["tool"] == "ROLE", str(a))
        b2 = rr.select_role(capability_id="CAP-VERIFY", **EX)
        chk("R02 capability not bound to role blocked", not b2["ok"] and "CAPABILITY_NOT_BOUND_TO_ROLE" in b2["reasons"], str(b2))
        v = rr.select_role(role_id="ROLE:VERIFIER", capability_id="CAP-RETIRE", operation="VERIFY_TASK", command="！驗收", profile_id="IP:ACCEPTANCE-VERIFIER", mode="ACCEPTANCE", targets=["EVIDENCE"])
        chk("R03 verifier cannot take CAP-RETIRE", not v["ok"] and "CAPABILITY_NOT_BOUND_TO_ROLE" in v["reasons"], str(v))
        w2 = rr.select_role(capability_id=None, **{**EX, "mode": "ACCEPTANCE"})
        chk("R04 role/mode mismatch blocked", not w2["ok"] and "MODE_NOT_ALLOWED" in w2["reasons"], str(w2))
        w3 = rr.select_role(capability_id=None, **{**EX, "command": "！驗收"})
        chk("R05 wrong activation command blocked", not w3["ok"] and "ACTIVATION_COMMAND_NOT_BOUND_TO_ROLE" in w3["reasons"], str(w3))
        w4 = rr.select_role(capability_id=None, **{**EX, "targets": ["P1_CURRENT"]})
        chk("R06 write to Current denied", not w4["ok"], str(w4))
        chk("R07 role choices stay in a verifiable chain", verify_trace(rr.trace) == [] and sum(1 for e in rr.trace if e["tool"] == "ROLE") == 6)
        try:
            rcr.resolve_and_record("!\u65bd\u5de5", event_log_path=base / "cmd.log", workflow_id="W1", conversation_id="C1", occurred_at="2026-10-15T10:00:03+00:00")
            cmd_ok = True
        except Exception as e:  # noqa: BLE001
            cmd_ok = False
        chk("D01 command route leaves a DIALOGUE_TURN record", cmd_ok and len(el.read_dialogue(el.EventLog(base / "cmd.log").events_for("SEGMENT", "W1"), "C1")) == 1)
    return res


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--simulate", action="store_true")
    ap.add_argument("--save-trace")
    a = ap.parse_args()
    if not a.simulate:
        ap.print_help()
        return 2
    rows = simulate(a.save_trace)
    for n, ok, d in rows:
        print(("PASS " if ok else "FAIL ") + n + ("" if ok or not d else "  <- " + d[:200]))
    bad = sum(1 for _, ok, _ in rows if not ok)
    print(f"SIMULATED_PASS {len(rows) - bad}/{len(rows)}" if not bad else f"FAILED {bad}/{len(rows)}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
