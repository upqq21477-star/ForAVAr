#!/usr/bin/env python3
"""Run bounded runtime probes for repository system boundaries.

The probe is deliberately evidence-only: it observes actual runtime imports,
file writes, foreign Current mutations, and cross-system process targets for
the two registered domain systems. It never rewrites P1 Current.
"""

from __future__ import annotations

import argparse
import json
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).resolve().parent))

from runtime_evidence_probe import execute as execute_runtime_probe

SCHEMA_PATH = ROOT / "P1-Central-Control/schemas/dynamic_boundary_runtime_probe.schema.json"

def system_exec_dirs(root: Path) -> dict[str, Path]:
    registry = root / "P1-Central-Control/system_registry.json"
    ids = [x["system_id"] for x in load_json(registry).get("systems", [])] if registry.is_file() else []
    return {sid: root / sid / "執行" for sid in ids if (root / sid / "執行").is_dir()}



def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def validate_result(value: dict[str, Any]) -> None:
    from jsonschema import Draft202012Validator

    schema = load_json(SCHEMA_PATH)
    Draft202012Validator(schema).validate(value)


def _harness(
    source_system: str,
    exec_dirs: dict[str, Path],
    root: Path,
    observation_path: Path,
) -> str:
    exec_dir = exec_dirs[source_system].resolve()
    repo_root = root.resolve()
    system_roots = {sid: str((ROOT / sid).resolve()) for sid in exec_dirs}
    encoded = json.dumps(
        {
            "source_system": source_system,
            "exec_dir": str(exec_dir),
            "repo_root": str(repo_root),
            "system_roots": system_roots,
            "observation_path": str(observation_path.resolve()),
        },
        ensure_ascii=False,
    )

    return f"""
import json
import sys
from pathlib import Path

cfg = json.loads({encoded!r})
source_system = cfg["source_system"]
system_roots = {{k: Path(v).resolve() for k, v in cfg["system_roots"].items()}}
observation_path = Path(cfg["observation_path"]).resolve()
for value in system_roots.values():
    value.mkdir(parents=True, exist_ok=True)

def system_for_path(raw):
    if raw is None:
        return None
    try:
        path = Path(str(raw)).resolve()
    except Exception:
        return None
    for sid, root in system_roots.items():
        try:
            path.relative_to(root)
        except ValueError:
            continue
        return sid
    return None

observed = {{
    "cross_system_imports": [],
    "cross_system_file_writes": [],
    "foreign_current_mutations": [],
    "handoff_process_targets": [],
}}

def audit(event, args):
    if event == "import":
        filename = args[1] if len(args) > 1 else None
        target = system_for_path(filename)
        if target and target != source_system:
            observed["cross_system_imports"].append({{
                "source_system": source_system,
                "target_system": target,
                "filename": str(filename),
                "evidence": "python-audit-import",
            }})
        return

    if event == "open":
        raw = args[0] if args else None
        mode = str(args[1]) if len(args) > 1 else ""
        path = None
        try:
            path = Path(str(raw)).resolve()
        except Exception:
            pass
        target = system_for_path(raw)
        write_mode = any(flag in mode for flag in ("w", "a", "x", "+"))
        if target and target != source_system and write_mode:
            observed["cross_system_file_writes"].append({{
                "source_system": source_system,
                "target_system": target,
                "path": str(path),
                "mode": mode,
                "evidence": "python-audit-open",
            }})
        if write_mode and path and path.name == "P1-CURRENT.json":
            observed["foreign_current_mutations"].append({{
                "source_system": source_system,
                "path": str(path),
                "mode": mode,
                "evidence": "python-audit-open-current",
            }})
        return

    if event in {{"os.rename", "os.replace", "os.remove", "os.unlink"}}:
        for raw in args[:2]:
            target = system_for_path(raw)
            if target and target != source_system:
                observed["cross_system_file_writes"].append({{
                    "source_system": source_system,
                    "target_system": target,
                    "path": str(raw),
                    "event": event,
                    "evidence": "python-audit-filesystem-event",
                }})
        return

    if event == "subprocess.Popen":
        raw_command = args[0] if args else None
        command = raw_command if isinstance(raw_command, (list, tuple)) else [raw_command]
        for raw in command:
            target = system_for_path(raw)
            if target and target != source_system:
                observed["handoff_process_targets"].append({{
                    "source_system": source_system,
                    "target_system": target,
                    "target": str(raw),
                    "evidence": "python-audit-subprocess-target",
                }})

sys.addaudithook(audit)
sys.path.insert(0, cfg["exec_dir"])

if source_system == "A1-S01":
    from core import run
    result = run(
        {{"records": [{{"id": "RUNTIME-PROBE", "text": "boundary probe"}}]}},
        goal="P14 dynamic boundary runtime probe",
        config={{}},
    )
else:
    from core import run
    result = run(
        {{
            "records": [
                {{
                    "id": "RUNTIME-PROBE",
                    "entities": [{{"id": "A"}}, {{"id": "B"}}],
                    "relations": [{{"type": "support", "subject": "A", "object": "B"}}],
                }}
            ]
        }},
        goal="P14 dynamic boundary runtime probe",
        config={{"max_chain_depth": 3}},
    )

if result.get("status") != "COMPLETE":
    raise SystemExit("SYSTEM_RUNTIME_NOT_COMPLETE")

for key in observed:
    observed[key] = sorted(
        observed[key],
        key=lambda item: json.dumps(item, ensure_ascii=False, sort_keys=True),
    )

observation_path.parent.mkdir(parents=True, exist_ok=True)
observation_path.write_text(
    json.dumps(
        {{
            "system_id": source_system,
            "result_status": result.get("status"),
            "observed": observed,
        }},
        ensure_ascii=False,
        indent=2,
    ) + "\\n",
    encoding="utf-8",
)
"""


def classify_observation(observed: dict[str, Any]) -> str:
    violation_keys = (
        "cross_system_imports",
        "cross_system_file_writes",
        "foreign_current_mutations",
        "handoff_process_targets",
    )
    if not isinstance(observed, dict) or any(
        key not in observed or not isinstance(observed[key], list)
        for key in violation_keys
    ):
        return "INCOMPLETE"
    return "FAIL" if any(observed[key] for key in violation_keys) else "PASS"


def run_probe(root: Path = ROOT) -> dict[str, Any]:
    root = root.resolve()
    exec_dirs = system_exec_dirs(root)
    probes = []
    with tempfile.TemporaryDirectory(prefix="p1-dynamic-boundary-") as temp:
        temp_root = Path(temp)
        for system_id in sorted(exec_dirs):
            observation_path = temp_root / f"{system_id}.json"
            request = {
                "schema_version": "1.0",
                "probe_id": f"PROBE:DYNAMIC-BOUNDARY.{str(system_id).replace(':', '.')}",
                "root_path": str(root.resolve()),
                "command": [
                    sys.executable,
                    "-c",
                    _harness(system_id, exec_dirs, root, observation_path),
                ],
                "timeout_seconds": 30,
                "expected_exit_code": 0,
            }
            runtime = execute_runtime_probe(request)
            observation = {
                "cross_system_imports": [],
                "cross_system_file_writes": [],
                "foreign_current_mutations": [],
                "handoff_process_targets": [],
            }
            observation_available = observation_path.is_file()
            if observation_available:
                loaded = load_json(observation_path)
                observation = loaded.get("observed", {}) if isinstance(loaded, dict) else {}
                observation_available = (
                    isinstance(loaded, dict)
                    and loaded.get("result_status") == "COMPLETE"
                    and classify_observation(observation) in {"PASS", "FAIL"}
                )
            probe_status = classify_observation(observation) if observation_available else "INCOMPLETE"
            reason_code = None if observation_available else "RUNTIME_OBSERVATION_MISSING"
            if runtime["status"] == "FAIL":
                probe_status = "FAIL"
            elif runtime["status"] in {"TIMEOUT", "ERROR"}:
                probe_status = "INCOMPLETE"
                reason_code = "RUNTIME_PROBE_" + runtime["status"]

            probes.append({
                "system_id": system_id,
                "probe_id": request["probe_id"],
                "status": probe_status,
                "reason_code": reason_code,
                "runtime_evidence": runtime,
                "observation": observation,
            })

    reason_codes = []
    if not exec_dirs:
        overall = "INCOMPLETE"
        reason_codes.append("NO_REGISTERED_SYSTEMS_OR_EXECUTION_DIRECTORIES")
    elif any(item["status"] == "FAIL" for item in probes):
        overall = "FAIL"
    elif any(item["status"] == "INCOMPLETE" for item in probes):
        overall = "INCOMPLETE"
    elif exec_dirs:
        overall = "PASS"
    else:
        overall = "INCOMPLETE"

    for item in probes:
        if item.get("reason_code"):
            reason_codes.append(f"{item['probe_id']}:{item['reason_code']}")

    result = {
        "schema_version": "1.0",
        "probe_run_id": "DYNAMIC-BOUNDARY:" + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
        "status": overall,
        "evidence_class": "OBSERVED_RUNTIME" if probes and all(item.get("reason_code") is None for item in probes) else "NOT_OBSERVED",
        "reason_codes": reason_codes,
        "coverage": {
            "systems": sorted(exec_dirs),
            "cases": ["core_runtime", "imports", "filesystem_writes", "foreign_current_mutations", "process_targets"],
        },
        "probes": probes,
    }
    validate_result(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 bounded dynamic boundary runtime probe")
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    result = run_probe(Path(args.root).resolve())
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2 if result["status"] == "INCOMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
