"""counterexample_log -- records WHAT was searched for counterexamples (CAP-COUNTEREXAMPLE, R3d12zw S6 batch 1).  The search itself stays with SEARCH / ingested sources.
Input: hypothesis {id, ...}; scope = list of source ids (the searched SET -- PROV-O hadMember vocabulary only, no RDF); searcher(hypothesis, scope) -> [counterexample refs inside scope].
End: FOUND | NONE_IN_SCOPE (writes the scope; never 'does not exist') | SCOPE_LIMITED (search_available=False: only ingested sources were searched)
| INCOMPLETE (searcher raised, or returned refs outside the scope: nothing written, never NONE_IN_SCOPE) | FAILED (bad input: nothing written).
Resume key = hypothesis id + sorted scope; one atomic file per key; a finished key is reused without searching again.  No record = a level>=2 hypothesis cannot be accepted
(fail closed, see hypothesis_guard).  resolve()/lookup() read records; audit() is the deterministic check 'every level>=2 hypothesis has a record with a non-empty scope'.
Evidence ceiling: SIMULATED_PASS.  The level>=2 threshold follows the plan (HYPOTHESIS)."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Callable

from atomic_write import atomic_write

DONE = ("FOUND", "NONE_IN_SCOPE", "SCOPE_LIMITED")


def _dump(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True)


def key(hid: str, scope: list[str]) -> str:
    return hashlib.sha256((hid + "|" + "|".join(sorted(set(scope)))).encode("utf-8")).hexdigest()[:12]


def _scope_ok(scope: Any) -> bool:
    return isinstance(scope, list) and bool(scope) and all(isinstance(s, str) and s for s in scope)


def _check_refs(refs: Any, ids: list[str]) -> bool:
    return isinstance(refs, list) and all(isinstance(r, str) and r in ids for r in refs)


def resolve(ref: Any, log_dir: str | Path) -> dict[str, Any]:
    d = Path(log_dir)
    if not d.is_dir():
        return {"status": "MISSING", "record": None}
    p = d / (str(ref) + ".json")
    if not isinstance(ref, str) or not re.fullmatch(r"[0-9a-f]{12}", ref) or not p.is_file():
        return {"status": "NOT_FOUND", "record": None}
    try:
        rec = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"status": "UNREADABLE", "record": None}
    if not (isinstance(rec, dict) and isinstance(rec.get("hypothesis"), str) and isinstance(rec.get("scope"), list) and rec.get("status") in DONE):
        return {"status": "UNREADABLE", "record": None}
    return {"status": "OK" if rec["scope"] else "EMPTY_SCOPE", "record": rec}


def record(hypothesis: Any, scope: Any, searcher: Callable[..., Any], log_dir: str | Path, search_available: bool = True) -> dict[str, Any]:
    bad = {"status": "FAILED", "ref": None, "scope": [], "counterexamples": [], "reason": "BAD_INPUT"}
    if not (isinstance(hypothesis, dict) and isinstance(hypothesis.get("id"), str) and hypothesis["id"]) or not _scope_ok(scope):
        return bad
    ids = sorted(set(scope))
    ref = key(hypothesis["id"], ids)
    old = resolve(ref, log_dir)
    if old["status"] == "OK":
        return {**old["record"], "ref": ref}
    try:
        found = searcher(hypothesis, ids)
    except Exception:  # search failed: this scope is INCOMPLETE, never 'none found'
        return {**bad, "status": "INCOMPLETE", "reason": "SEARCH_ERROR", "scope": ids}
    if not _check_refs(found, ids):
        return {**bad, "status": "INCOMPLETE", "reason": "BAD_SEARCH_OUTPUT", "scope": ids}
    status = "FOUND" if found else "NONE_IN_SCOPE" if search_available else "SCOPE_LIMITED"
    rec = {"hypothesis": hypothesis["id"], "scope": ids, "status": status, "counterexamples": sorted(set(found)), "reason": ""}
    Path(log_dir).mkdir(parents=True, exist_ok=True)
    atomic_write(Path(log_dir) / (ref + ".json"), _dump(rec))
    return {**rec, "ref": ref}


def _all(log_dir: str | Path) -> tuple[str, list[dict[str, Any]]]:
    d = Path(log_dir)
    if not d.is_dir():
        return "MISSING", []
    recs = []
    for p in sorted(d.glob("*.json")):
        r = resolve(p.stem, d)
        if r["status"] not in ("OK", "EMPTY_SCOPE"):
            return "UNREADABLE", []
        recs.append(r["record"])
    return "OK", recs


def lookup(hid: str, log_dir: str | Path) -> dict[str, Any]:
    st, recs = _all(log_dir)
    return {"status": st, "records": [r for r in recs if r["hypothesis"] == hid]}


def audit(hypotheses: list[dict[str, Any]], log_dir: str | Path) -> dict[str, Any]:
    missing = []
    for h in hypotheses:
        lvl = h.get("level")
        if isinstance(lvl, int) and lvl >= 2:
            lk = lookup(h["id"], log_dir)
            if lk["status"] != "OK" or not any(r["scope"] for r in lk["records"]):
                missing.append(h["id"])
    return {"ok": not missing, "missing": sorted(missing)}


def hit_rate(log_dir: str | Path) -> dict[str, Any]:
    _, recs = _all(log_dir)
    found = sum(1 for r in recs if r["status"] == "FOUND")
    return {"total": len(recs), "found": found, "rate": found / len(recs) if recs else None}
