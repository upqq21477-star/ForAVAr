"""relation_guard -- deterministic guard around model-extracted relations (CAP-RELATION, R3d12zv S5 batch 3).  Extraction stays with the model.
Input: observations [{obs_id, entities[names]}], entities {id: [aliases]}.  Observations that share the same entity group (>= 2 observations) are
sent to model(group{key}, observations, attempt) -> {a, b, type, direction, condition, depends, evidence[{ref, stance support|conflict}]}.
Guard: endpoints normalised by EXACT id/alias match only (no fuzzy); unregistered endpoint -> ask once more -> CANDIDATE ENDPOINT_NOT_REGISTERED;
schema invalid -> re-ask up to 2 -> CANDIDATE INVALID_SCHEMA; evidence refs must resolve to a given obs_id, none -> CANDIDATE NO_EVIDENCE;
only RELATION records reach the graph; conflict and support evidence are both kept; same (pair, type) is kept once (first wins).
End: OK | PARTIAL (candidates + missing_entities) | INCOMPLETE (model error: finished groups kept, missing listed) | FAILED (bad input, nothing written).
Resume key = group key (the type is only known after the call); one atomic file per group.  check_graph() hands directed RELATIONs to graph_check;
strength() gives F17 strength via stats_summary (UNKNOWN when unusable).  Evidence ceiling: SIMULATED_PASS.  Alias table rule is HYPOTHESIS."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

import graph_check
import stats_summary
from atomic_write import atomic_write

DIRECTIONS = ("A→B", "B→A", "undirected", "UNKNOWN")
STANCES = ("support", "conflict")


def _dump(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True)


def _alias_map(entities: dict[str, list[str]]) -> dict[str, str]:
    m = {}
    for eid, aliases in entities.items():
        m[eid] = eid
        for a in aliases:
            m[a] = eid
    return m


def _schema_ok(a: Any) -> bool:
    if not isinstance(a, dict) or a.get("direction") not in DIRECTIONS:
        return False
    if not all(isinstance(a.get(k), str) and a[k] for k in ("a", "b", "type")) or not isinstance(a.get("evidence"), list):
        return False
    return all(isinstance(x, dict) and isinstance(x.get("ref"), str) and x.get("stance") in STANCES for x in a["evidence"])


def _resolvable(refs: list[str], ids: set[str]) -> list[str]:
    return [r for r in refs if r in ids]


def _groups(observations: list[dict[str, Any]], amap: dict[str, str]) -> dict[tuple[str, ...], list[dict[str, Any]]]:
    out: dict[tuple[str, ...], list[dict[str, Any]]] = {}
    for o in observations:
        key = tuple(sorted({amap.get(n, n) for n in o["entities"]}))
        if len(key) >= 2:
            out.setdefault(key, []).append(o)
    return {k: v for k, v in sorted(out.items()) if len(v) >= 2}


def _record(key: tuple[str, ...], status: str, reason: str, pair: list[str], ans: dict[str, Any] | None = None, ids: set[str] | None = None,
            missing: list[str] | None = None) -> dict[str, Any]:
    ev = ans["evidence"] if ans else []
    keep = set(_resolvable([x["ref"] for x in ev], ids or set()))
    d = ans["direction"] if ans else "UNKNOWN"
    ordered = (pair[0], pair[1]) if d == "A→B" else (pair[1], pair[0]) if d == "B→A" else (None, None)
    return {"group": list(key), "pair": sorted(pair), "type": ans["type"] if ans else None, "direction": d, "from": ordered[0] if status == "RELATION" else None,
            "to": ordered[1] if status == "RELATION" else None, "condition": ans.get("condition") if ans else None, "depends": ans.get("depends") if ans else None,
            "supports": [x["ref"] for x in ev if x["ref"] in keep and x["stance"] == "support"],
            "conflicts": [x["ref"] for x in ev if x["ref"] in keep and x["stance"] == "conflict"], "status": status, "reason": reason,
            "missing_entities": missing or []}


def _ask(key: tuple[str, ...], group_obs: list[dict[str, Any]], model: Callable[..., Any], amap: dict[str, str], ids: set[str]) -> dict[str, Any]:
    schema_fail = ep_fail = attempt = 0
    while True:
        ans = model({"key": list(key)}, group_obs, attempt)
        attempt += 1
        if not _schema_ok(ans):
            schema_fail += 1
            if schema_fail > 2:
                return _record(key, "CANDIDATE", "INVALID_SCHEMA", list(key))
            continue
        a, b = amap.get(ans["a"]), amap.get(ans["b"])
        if a is None or b is None:
            ep_fail += 1
            if ep_fail > 1:
                miss = sorted(n for n, i in ((ans["a"], a), (ans["b"], b)) if i is None)
                return _record(key, "CANDIDATE", "ENDPOINT_NOT_REGISTERED", [ans["a"], ans["b"]], ans, ids, miss)
            continue
        ok = _resolvable([x["ref"] for x in ans["evidence"]], ids)
        return _record(key, "RELATION" if ok else "CANDIDATE", "" if ok else "NO_EVIDENCE", [a, b], ans, ids)


def build_relations(observations: Any, entities: Any, model: Callable[..., Any], out_dir: str | Path) -> dict[str, Any]:
    fail = {"status": "FAILED", "records": [], "missing": [], "missing_entities": [], "conflict_count": 0, "candidate_ratio": None}
    if (not isinstance(observations, list) or not isinstance(entities, dict) or not all(isinstance(o, dict) and isinstance(o.get("obs_id"), str)
                                                                                      and isinstance(o.get("entities"), list) for o in observations)):
        return fail
    out, amap, ids = Path(out_dir), _alias_map(entities), {o["obs_id"] for o in observations}
    out.mkdir(parents=True, exist_ok=True)
    groups, recs = _groups(observations, amap), []
    for n, (key, gobs) in enumerate(groups.items()):
        p = out / (hashlib.sha256("|".join(key).encode("utf-8")).hexdigest()[:12] + ".json")
        old = None
        try:
            old = json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
        except (OSError, ValueError):
            old = None
        if isinstance(old, dict) and old.get("group") == list(key) and old.get("status") in ("RELATION", "CANDIDATE"):
            recs.append(old)
            continue
        try:
            rec = _ask(key, gobs, model, amap, ids)
        except Exception:  # model call failed: finished groups stay, the rest is listed
            return {**fail, "status": "INCOMPLETE", "records": _dedupe(recs), "missing": [list(k) for k in list(groups)[n:]]}
        atomic_write(p, _dump(rec))
        recs.append(rec)
    recs = _dedupe(recs)
    cand = [r for r in recs if r["status"] == "CANDIDATE"]
    miss = sorted({m for r in recs for m in r["missing_entities"]})
    conflicts = sum(1 for r in recs if r["conflicts"])
    ratio = len(cand) / len(recs) if recs else 0.0
    atomic_write(out / "_summary.json", _dump({"candidate_ratio": ratio, "conflict_count": conflicts, "total": len(recs)}))
    return {"status": "PARTIAL" if cand else "OK", "records": recs, "missing": [], "missing_entities": miss, "conflict_count": conflicts, "candidate_ratio": ratio}


def _dedupe(recs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen, out = set(), []
    for r in recs:
        k = (tuple(r["pair"]), r["type"])
        if k not in seen:
            seen.add(k)
            out.append(r)
    return out


def graph_edges(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Only RELATION records with a direction and at least one evidence ref become graph edges; CANDIDATEs never do."""
    return [{"from": r["from"], "to": r["to"], "relation": r["type"], "source": (r["supports"] + r["conflicts"])[0]}
            for r in records if r["status"] == "RELATION" and r["from"] and (r["supports"] or r["conflicts"])]


def check_graph(records: list[dict[str, Any]], entities: dict[str, Any]) -> dict[str, Any]:
    return graph_check.check(graph_edges(records), list(entities))


def strength(counts: list[Any], range_mark: str, trust: str = "VERIFIED") -> dict[str, Any]:
    s = stats_summary.summarize("RELATION-STRENGTH", counts, range_mark, trust)
    return {"value": stats_summary.downstream_value(s, "mean"), "summary": s}
