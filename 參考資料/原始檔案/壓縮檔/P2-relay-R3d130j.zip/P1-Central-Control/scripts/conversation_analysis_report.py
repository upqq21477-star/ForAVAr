#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

STAGES = [
    "CREATED",
    "ESSENCE_CAPTURED",
    "STRUCTURED",
    "RELATED",
    "REASONED",
    "SYNTHESIZED",
    "RESPONSE_READY",
]

ALLOWED_RAW_KEYS = {
    "id", "summary", "importance", "source_refs", "title", "essence_refs",
    "unresolved_refs", "from_refs", "to_refs", "relation", "basis_refs",
    "assessment", "premise_refs", "inference", "conclusion", "uncertainty",
    "countercheck_refs", "central_question", "systemic_pattern",
    "higher_level_direction", "implications", "recommendations", "unresolved",
    "key_points", "answer", "support_refs", "detail_note",
    "source_ref", "label", "reason", "event", "timestamp", "refs"
}

def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()

def load(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))

def save(path: str, value: dict[str, Any]) -> None:
    Path(path).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

def trace(report: dict[str, Any], event: str, refs: list[str] | None = None) -> None:
    report["trace"].append({
        "event": event,
        "timestamp": now_iso(),
        "refs": refs or [],
    })
    report["updated_at"] = now_iso()

def ensure_list(value: Any, name: str) -> list[Any]:
    if not isinstance(value, list):
        raise ValueError(f"{name} 必須是陣列")
    return value

def reject_raw_content(value: Any, path: str = "root") -> None:
    if isinstance(value, dict):
        for key, item in value.items():
            lowered = key.lower()
            if lowered in {"raw_content", "raw_source", "source_text", "full_source", "original_text", "complete_history"}:
                raise ValueError(f"Report 禁止保存原始資料內容: {path}.{key}；請改存 source_refs + 摘要")
            reject_raw_content(item, f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            reject_raw_content(item, f"{path}[{index}]")

def validate_refs(report: dict[str, Any]) -> list[str]:
    source_ids = {x.get("source_ref") for x in report["sources"]}
    essence_ids = {x.get("id") for x in report["essence"]}
    structure_ids = {x.get("id") for x in report["structure"]}
    relation_ids = {x.get("id") for x in report["relations"]}
    reasoning_ids = {x.get("id") for x in report["reasoning_summaries"]}
    known = source_ids | essence_ids | structure_ids | relation_ids | reasoning_ids
    errors: list[str] = []

    for row in report["essence"]:
        if not row.get("source_refs"):
            errors.append(f"{row.get('id')}: essence 必須綁 source_refs")
        for ref in row.get("source_refs", []):
            if ref not in source_ids:
                errors.append(f"{row.get('id')}: 未知 source_ref {ref}")

    for row in report["structure"]:
        for ref in row.get("essence_refs", []):
            if ref not in essence_ids:
                errors.append(f"{row.get('id')}: 未知 essence_ref {ref}")
        for ref in row.get("unresolved_refs", []):
            if ref not in known:
                errors.append(f"{row.get('id')}: 未知 unresolved_ref {ref}")

    for row in report["relations"]:
        for ref in row.get("from_refs", []) + row.get("to_refs", []) + row.get("basis_refs", []):
            if ref not in known:
                errors.append(f"{row.get('id')}: 未知 relation ref {ref}")

    for row in report["reasoning_summaries"]:
        for ref in row.get("premise_refs", []) + row.get("countercheck_refs", []):
            if ref not in known:
                errors.append(f"{row.get('id')}: 未知 reasoning ref {ref}")

    return errors

def compute_coverage(report: dict[str, Any]) -> None:
    source_ids = {x.get("source_ref") for x in report["sources"]}
    linked = set()
    for row in report["essence"]:
        linked.update(row.get("source_refs", []))
    report["coverage"] = {
        "source_count": len(source_ids),
        "essence_count": len(report["essence"]),
        "structured_count": len(report["structure"]),
        "relation_count": len(report["relations"]),
        "reasoning_count": len(report["reasoning_summaries"]),
        "linked_source_count": len(linked & source_ids),
    }

def validate(report: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    required = [
        "schema_version", "report_id", "workflow_id", "task_id", "goal",
        "stage", "response_mode", "sources", "essence", "structure",
        "relations", "reasoning_summaries", "synthesis", "response_view",
        "coverage", "unresolved", "trace"
    ]
    errors.extend([f"缺少欄位: {k}" for k in required if k not in report])

    if errors:
        return {"status": "BLOCK", "errors": errors}

    if report["stage"] not in STAGES:
        errors.append("stage 不合法")
    if report["response_mode"] not in {"BRIEF", "STANDARD", "DETAILED"}:
        errors.append("response_mode 不合法")

    errors.extend(validate_refs(report))
    reject_error = None
    try:
        reject_raw_content(report)
    except ValueError as exc:
        reject_error = str(exc)
    if reject_error:
        errors.append(reject_error)

    if report["stage"] in {"SYNTHESIZED", "RESPONSE_READY"}:
        synthesis = report["synthesis"]
        required_synthesis = [
            "central_question", "systemic_pattern", "higher_level_direction",
            "implications", "recommendations", "unresolved"
        ]
        errors.extend([f"synthesis 缺少 {k}" for k in required_synthesis if k not in synthesis])

    if report["stage"] == "RESPONSE_READY":
        response = report["response_view"]
        if not response.get("answer", "").strip():
            errors.append("RESPONSE_READY 必須有 response_view.answer")
        if not response.get("key_points"):
            errors.append("RESPONSE_READY 必須有 key_points")
        if not response.get("support_refs"):
            errors.append("RESPONSE_READY 必須有 support_refs")
        known_response_refs = (
            {x.get("id") for x in report["essence"]}
            | {x.get("id") for x in report["structure"]}
            | {x.get("id") for x in report["relations"]}
            | {x.get("id") for x in report["reasoning_summaries"]}
            | {x.get("source_ref") for x in report["sources"]}
        )
        for ref in response.get("support_refs", []):
            if ref not in known_response_refs:
                errors.append(f"response_view: 未知 support_ref {ref}")

    compute_coverage(report)

    stage_index = STAGES.index(report["stage"])
    if stage_index >= STAGES.index("ESSENCE_CAPTURED") and not report["essence"]:
        errors.append("進入 ESSENCE_CAPTURED 後不得沒有 essence")
    if stage_index >= STAGES.index("STRUCTURED") and not report["structure"]:
        errors.append("進入 STRUCTURED 後不得沒有 structure")
    if stage_index >= STAGES.index("RELATED") and not report["relations"]:
        errors.append("進入 RELATED 後不得沒有 relations")
    if stage_index >= STAGES.index("REASONED") and not report["reasoning_summaries"]:
        errors.append("進入 REASONED 後不得沒有 reasoning_summaries")

    return {
        "status": "BLOCK" if errors else "PASS",
        "stage": report["stage"],
        "coverage": report["coverage"],
        "errors": errors,
    }

def init_report(args: argparse.Namespace) -> dict[str, Any]:
    if not args.source_ref:
        raise ValueError("Conversation Analysis Report 至少需要一個 source_ref")
    report = {
        "schema_version": "1.0",
        "report_id": args.report_id,
        "workflow_id": args.workflow_id,
        "task_id": args.task_id,
        "goal": args.goal,
        "stage": "CREATED",
        "response_mode": args.response_mode,
        "sources": [{"source_ref": ref, "label": None} for ref in args.source_ref],
        "essence": [],
        "structure": [],
        "relations": [],
        "reasoning_summaries": [],
        "synthesis": {
            "central_question": "",
            "systemic_pattern": "",
            "higher_level_direction": "",
            "implications": [],
            "recommendations": [],
            "unresolved": [],
        },
        "response_view": {
            "key_points": [],
            "answer": "",
            "support_refs": [],
            "detail_note": None,
        },
        "coverage": {},
        "unresolved": [],
        "trace": [],
        "created_at": now_iso(),
        "updated_at": now_iso(),
    }
    trace(report, "REPORT_CREATED", [x["source_ref"] for x in report["sources"]])
    compute_coverage(report)
    return report

def append_phase(report: dict[str, Any], phase: str, payload_path: str) -> None:
    if phase not in {"essence", "structure", "relations", "reasoning"}:
        raise ValueError("不支援的 phase")
    payload = json.loads(Path(payload_path).read_text(encoding="utf-8"))
    rows = ensure_list(payload, phase)
    if phase == "essence":
        report["essence"].extend(rows)
        report["stage"] = "ESSENCE_CAPTURED"
    elif phase == "structure":
        report["structure"].extend(rows)
        report["stage"] = "STRUCTURED"
    elif phase == "relations":
        report["relations"].extend(rows)
        report["stage"] = "RELATED"
    else:
        report["reasoning_summaries"].extend(rows)
        report["stage"] = "REASONED"
    trace(report, phase.upper() + "_APPENDED", [r.get("id", "") for r in rows])

def apply_synthesis(report: dict[str, Any], payload_path: str) -> None:
    payload = load(payload_path)
    required = [
        "central_question", "systemic_pattern", "higher_level_direction",
        "implications", "recommendations", "unresolved"
    ]
    missing = [k for k in required if k not in payload]
    if missing:
        raise ValueError("synthesis 缺少: " + ", ".join(missing))
    report["synthesis"] = payload
    report["stage"] = "SYNTHESIZED"
    report["unresolved"] = [
        {"id": f"UNRESOLVED-{i+1}", "reason": reason}
        for i, reason in enumerate(payload.get("unresolved", []))
    ]
    trace(report, "SYNTHESIS_COMMITTED")

def apply_response(report: dict[str, Any], payload_path: str) -> None:
    if report["stage"] != "SYNTHESIZED":
        raise ValueError("只有 SYNTHESIZED 才能建立 RESPONSE_READY")
    payload = load(payload_path)
    for key in ("key_points", "answer", "support_refs"):
        if key not in payload:
            raise ValueError("response_view 缺少: " + key)
    report["response_view"] = payload
    report["stage"] = "RESPONSE_READY"
    trace(report, "RESPONSE_VIEW_COMMITTED", payload.get("support_refs", []))

def render(report: dict[str, Any]) -> str:
    v = validate(report)
    if v["status"] == "BLOCK":
        raise ValueError("Report 尚未通過驗證: " + "；".join(v["errors"]))

    lines = [
        "# P1｜Conversation Analysis Report",
        "",
        f"- 報告：{report['report_id']}",
        f"- 任務：{report['task_id']}",
        f"- 狀態：{report['stage']}",
        f"- 回答模式：{report['response_mode']}",
        f"- 目標：{report['goal']}",
        "",
        "## 1. 資料精華擷取",
    ]
    for item in report["essence"]:
        lines.append(f"- **{item['id']}**：{item['summary']}（{item.get('importance','NORMAL')}）")
    lines.extend(["", "## 2. 結構化重點"])
    for item in report["structure"]:
        lines.append(f"- **{item['id']}｜{item['title']}**：連結 {', '.join(item.get('essence_refs', []))}")
    lines.extend(["", "## 3. 關聯結構"])
    for item in report["relations"]:
        lines.append(
            f"- **{item['id']}**：{', '.join(item['from_refs'])} → {item['relation']} → "
            f"{', '.join(item['to_refs'])}（{item.get('assessment','UNKNOWN')}）"
        )
    lines.extend(["", "## 4. 推理摘要"])
    for item in report["reasoning_summaries"]:
        lines.append(f"- **{item['id']}**：{item['inference']} → {item['conclusion']}；不確定性：{item['uncertainty']}")
    lines.extend([
        "",
        "## 5. 架構級整體統整",
        f"**中心問題**：{report['synthesis']['central_question']}",
        "",
        f"**系統性模式**：{report['synthesis']['systemic_pattern']}",
        "",
        f"**更高層級方向**：{report['synthesis']['higher_level_direction']}",
        "",
        "### 影響",
    ])
    lines.extend([f"- {x}" for x in report["synthesis"].get("implications", [])])
    lines.extend(["", "### 建議"])
    lines.extend([f"- {x}" for x in report["synthesis"].get("recommendations", [])])
    lines.extend(["", "### 未解問題"])
    lines.extend([f"- {x}" for x in report["synthesis"].get("unresolved", [])] or ["- 無"])
    if report["stage"] == "RESPONSE_READY":
        lines.extend([
            "",
            "## 6. 對話回報視圖",
            "",
            "### 重點",
        ])
        lines.extend([f"- {x}" for x in report["response_view"]["key_points"]])
        lines.extend(["", "### 回答", report["response_view"]["answer"]])
    lines.extend([
        "",
        "## 7. Coverage",
        "",
        f"- Source：{report['coverage']['source_count']}",
        f"- Essence：{report['coverage']['essence_count']}",
        f"- Structure：{report['coverage']['structured_count']}",
        f"- Relations：{report['coverage']['relation_count']}",
        f"- Reasoning summaries：{report['coverage']['reasoning_count']}",
        f"- 已連結 Source：{report['coverage']['linked_source_count']}",
        "",
        "> 本文件保存的是可回溯的分析摘要與推理結構，不保存原始資料全文或逐字內在思考。",
    ])
    return "\n".join(lines) + "\n"

def main() -> int:
    ap = argparse.ArgumentParser(description="P1 Conversation Analysis Report controller")
    sub = ap.add_subparsers(dest="command", required=True)

    p = sub.add_parser("init")
    p.add_argument("report_id")
    p.add_argument("workflow_id")
    p.add_argument("task_id")
    p.add_argument("goal")
    p.add_argument("output")
    p.add_argument("--response-mode", choices=["BRIEF", "STANDARD", "DETAILED"], default="STANDARD")
    p.add_argument("--source-ref", action="append", default=[])

    for phase in ("essence", "structure", "relations", "reasoning"):
        p = sub.add_parser("append-" + phase)
        p.add_argument("report")
        p.add_argument("payload")
        p.add_argument("output")

    p = sub.add_parser("synthesize")
    p.add_argument("report")
    p.add_argument("payload")
    p.add_argument("output")

    p = sub.add_parser("response-ready")
    p.add_argument("report")
    p.add_argument("payload")
    p.add_argument("output")

    p = sub.add_parser("validate")
    p.add_argument("report")

    p = sub.add_parser("render")
    p.add_argument("report")
    p.add_argument("output")

    args = ap.parse_args()
    if args.command == "init":
        report = init_report(args)
        result = validate(report)
        if result["status"] == "BLOCK":
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 3
        save(args.output, report)
        print(json.dumps({"status": "PASS", "stage": report["stage"], "report": args.output}, ensure_ascii=False, indent=2))
        return 0

    report = load(args.report)
    try:
        if args.command.startswith("append-"):
            append_phase(report, args.command.replace("append-", ""), args.payload)
            save(args.output, report)
            print(json.dumps({"status": "PASS", "stage": report["stage"], "report": args.output}, ensure_ascii=False, indent=2))
            return 0
        if args.command == "synthesize":
            apply_synthesis(report, args.payload)
            save(args.output, report)
            print(json.dumps({"status": "PASS", "stage": report["stage"], "report": args.output}, ensure_ascii=False, indent=2))
            return 0
        if args.command == "response-ready":
            apply_response(report, args.payload)
            result = validate(report)
            if result["status"] == "BLOCK":
                print(json.dumps(result, ensure_ascii=False, indent=2))
                return 3
            save(args.output, report)
            print(json.dumps({"status": "PASS", "stage": report["stage"], "report": args.output}, ensure_ascii=False, indent=2))
            return 0
        if args.command == "validate":
            result = validate(report)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["status"] == "PASS" else 3
        if args.command == "render":
            Path(args.output).write_text(render(report), encoding="utf-8")
            print(json.dumps({"status": "PASS", "output": args.output}, ensure_ascii=False, indent=2))
            return 0
    except Exception as exc:
        print(json.dumps({"status": "BLOCK", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 3
    return 3

if __name__ == "__main__":
    raise SystemExit(main())
