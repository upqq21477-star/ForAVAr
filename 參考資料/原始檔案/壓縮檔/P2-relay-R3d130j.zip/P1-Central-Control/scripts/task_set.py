#!/usr/bin/env python3
"""U-6：Task Set 契約與生命週期（純函式；寫 Log 由 central_controller 負責）。

Task＝segment（task_id＝segment_id）。Task Set 只存「發行紀錄」（append-only，state.task_sets）；
作廢 segment 記在 state.void_segments（append-only）。ACTIVE／DONE／SUPERSEDED／INVALID 一律由此與
segment 最終結果衍生，不另存狀態（一份資料只有一個正式位置）。作廢 segment 不得排程、不入聚合
（parallel_scheduler.void_ids）。
"""
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from parallel_scheduler import dependency_ids, final_segment_results, void_ids

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = ROOT / "P1-Central-Control" / "schemas" / "control_output.schema.json"
BINDING_PATH = ROOT / "P1-Central-Control" / "policy" / "role_capability_binding.v1.0.json"
VOID_STATE = {"SUPERSEDED": "SUPERSEDED", "ABANDONED": "INVALID"}  # void reason → task state


def validate_control_output(out: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = sorted(Draft202012Validator(schema).iter_errors(out), key=lambda e: list(e.path))
    if errors:
        raise ValueError("Control Output 驗證失敗: " + "; ".join(e.message for e in errors))


def _task_state(state: dict[str, Any], task_id: str, finals: dict[str, Any], void: dict[str, str]) -> str:
    if task_id in void:
        return VOID_STATE[void[task_id]]
    if finals.get(task_id, {}).get("decision_code") == "WORK_COMPLETE":
        return "DONE"
    return "ACTIVE"


def task_set_view(state: dict[str, Any]) -> list[dict[str, Any]]:
    """每個已發行 Task Set 一列：status 與各 task state 皆衍生。"""
    finals = final_segment_results(state)
    void = {i["segment_id"]: i["reason_code"] for i in state.get("void_segments", [])}
    sets = state.get("task_sets", [])
    superseded = {s["supersedes"] for s in sets if s.get("supersedes")}
    rows = []
    for item in sets:
        tasks = [{**t, "state": _task_state(state, t["task_id"], finals, void)} for t in item["task_refs"]]
        states = {t["state"] for t in tasks}
        if item["task_set_id"] in superseded:
            status = "SUPERSEDED"
        elif states == {"DONE"}:
            status = "DONE"
        elif "ACTIVE" not in states:
            status = "INVALID"
        else:
            status = "ACTIVE"
        rows.append({"task_set_id": item["task_set_id"], "revision": item["revision"], "status": status,
                     "supersedes": item.get("supersedes"), "tasks": tasks})
    return rows


def current_task_set(state: dict[str, Any]) -> dict[str, Any] | None:
    """最新（revision 最大）且未被取代的 Task Set；沒有則 None。"""
    live = [r for r in task_set_view(state) if r["status"] != "SUPERSEDED"]
    return max(live, key=lambda r: r["revision"]) if live else None


def stale_task_ids(state: dict[str, Any]) -> list[str]:
    """已作廢（SUPERSEDED／INVALID）的 task，供 Brain 輸入封包標示。"""
    return sorted({t["task_id"] for r in task_set_view(state) for t in r["tasks"] if t["state"] in {"SUPERSEDED", "INVALID"}})


def void(state: dict[str, Any], segment_ids: list[str], reason_code: str, ref: str) -> dict[str, Any]:
    """作廢 segment：移出 queued、記入 void_segments。Active attempt 須先由呼叫端 cancel。"""
    current = deepcopy(state)
    ids = [s for s in segment_ids if s not in void_ids(current)]
    if any(a["segment_id"] in ids for a in current.get("active_segments", [])):
        raise ValueError("VOID_SEGMENT_STILL_ACTIVE")
    current["queued_segments"] = [q for q in current.get("queued_segments", []) if q["segment_id"] not in ids]
    current.setdefault("void_segments", []).extend(
        {"segment_id": s, "reason_code": reason_code, "ref": ref} for s in ids)
    return current


def assert_role_capability(role_id: str, capability_id: str) -> None:
    """U-8：role 只能使用綁定給它的 capability（fail closed；表來自 policy/role_capability_binding）。
    發行時、結果入口、CAP-RETIRE 執行時共用同一個檢查。"""
    roles = json.loads(BINDING_PATH.read_text(encoding="utf-8"))["roles"]
    if capability_id not in roles.get(role_id, []):
        raise ValueError(f"CAPABILITY_NOT_BOUND:{role_id}:{capability_id}")


def _check_capability_binding(task_refs: list[dict[str, Any]]) -> None:
    for task in task_refs:
        try:
            assert_role_capability(task["role"], task["capability_id"])
        except ValueError:
            raise ValueError(f"TASK_CAPABILITY_NOT_BOUND:{task['task_id']}:{task['role']}:{task['capability_id']}") from None


def _check_verifier_independence(task_refs: list[dict[str, Any]], segs: dict[str, dict[str, Any]], view: dict[str, Any]) -> None:
    """D3(a)：Verifier 必須是獨立的驗收 task——`verifies` 指向 Executor task（同集合，或先前集合中已 DONE 者），
    不得指向自己，且其 segment 須依賴被驗收者（先完成才可驗收，不與 Executor 同一 attempt，避免自驗）。"""
    executors = {t["task_id"] for t in task_refs if t["role"] == "ROLE:EXECUTOR"}
    executors |= {t["task_id"] for r in view.values() for t in r["tasks"] if t["role"] == "ROLE:EXECUTOR" and t["state"] == "DONE"}
    for task in task_refs:
        tid, targets = task["task_id"], task.get("verifies")
        if task["role"] != "ROLE:VERIFIER":
            if targets is not None:
                raise ValueError("TASK_VERIFIES_ONLY_FOR_VERIFIER:" + tid)
            continue
        if not targets:
            raise ValueError("TASK_VERIFIER_REQUIRES_VERIFIES:" + tid)
        for target in targets:
            if target == tid:
                raise ValueError("TASK_SELF_VERIFICATION:" + tid)
            if target not in executors:
                raise ValueError("TASK_VERIFIES_TARGET_INVALID:" + target)
            if target not in dependency_ids(segs[tid]):
                raise ValueError("TASK_VERIFIER_MISSING_DEPENDENCY:" + tid)


def plan_issue(state: dict[str, Any], out: dict[str, Any], segment_store: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """驗證 TASK_SET_ISSUED；回 {record, void_ids, active_void_ids, segments}（尚未改 state）。"""
    validate_control_output(out)
    if out["decision_code"] != "TASK_SET_ISSUED":
        raise ValueError("TASK_SET_ISSUE_REQUIRES_TASK_SET_ISSUED")
    sets = state.get("task_sets", [])
    set_id = out["task_set_ref"]
    if any(s["task_set_id"] == set_id for s in sets):
        raise ValueError("TASK_SET_ALREADY_ISSUED:" + set_id)
    if out["revision"] != max((s["revision"] for s in sets), default=0) + 1:
        raise ValueError("TASK_SET_REVISION_CONFLICT")
    view = {r["task_set_id"]: r for r in task_set_view(state)}
    sup = out.get("supersedes")
    live = [r for r in view.values() if r["status"] == "ACTIVE"]
    if sup is None and live:
        raise ValueError("TASK_SET_SUPERSEDES_REQUIRED:" + live[0]["task_set_id"])
    if sup is not None and (sup not in view or view[sup]["status"] != "ACTIVE"):
        raise ValueError("TASK_SET_SUPERSEDES_INVALID:" + sup)

    ids = [t["task_id"] for t in out["task_refs"]]
    if len(set(ids)) != len(ids):
        raise ValueError("TASK_SET_DUPLICATE_TASK")
    used = ({s["segment_id"] for s in state.get("queued_segments", [])} | {s["segment_id"] for s in state.get("active_segments", [])}
            | {s["segment_id"] for s in state.get("completed_segments", [])} | void_ids(state))
    segments = []
    for tid in ids:
        seg = segment_store.get(tid)
        if seg is None or seg.get("workflow_id") != state["workflow_id"]:
            raise ValueError("TASK_SEGMENT_NOT_FOUND:" + tid)
        if tid in used:
            raise ValueError("TASK_SEGMENT_ID_REUSED:" + tid)
        segments.append(deepcopy(seg))

    _check_capability_binding(out["task_refs"])
    _check_verifier_independence(out["task_refs"], {s["segment_id"]: s for s in segments}, view)

    old = view[sup] if sup else None
    stale = [t["task_id"] for t in old["tasks"] if t["state"] == "ACTIVE"] if old else []
    active = {a["segment_id"] for a in state.get("active_segments", [])}
    return {
        "record": {"task_set_id": set_id, "revision": out["revision"], "supersedes": sup,
                   "correlation_id": out["correlation_id"], "task_refs": deepcopy(out["task_refs"])},
        "void_ids": stale, "active_void_ids": sorted(set(stale) & active), "segments": segments,
    }


def apply_record(state: dict[str, Any], record: dict[str, Any]) -> dict[str, Any]:
    current = deepcopy(state)
    current.setdefault("task_sets", []).append(deepcopy(record))
    return current


def rule_segments(
    state: dict[str, Any],
    rulings: list[dict[str, Any]],
    *,
    proposal_id: str,
) -> tuple[dict[str, Any], list[str]]:
    """Brain 逐 segment 裁決（只能針對最後結果為 NEEDS_BRAIN 的 segment，且須全數涵蓋）。

    ACCEPT：以 Brain 裁決記為完成（completed 追加 WORK_COMPLETE，帶 ruling_ref；不是 Verifier 驗收）。
    ABANDON：作廢（reason ABANDONED）；依賴它的 queued segment 由 propagate_dependency_failure 處理。
    REQUEUE：回傳 id 清單，由呼叫端以 requeue_brain_pending(only=…) 重排。
    """
    pending = {sid for sid, r in final_segment_results(state).items() if r["decision_code"] == "NEEDS_BRAIN"}
    ruled = [r["segment_id"] for r in rulings]
    if len(set(ruled)) != len(ruled):
        raise ValueError("PROPOSAL_RULING_DUPLICATE_SEGMENT")
    if set(ruled) - pending:
        raise ValueError("PROPOSAL_RULING_SEGMENT_NOT_PENDING:" + sorted(set(ruled) - pending)[0])
    if pending - set(ruled):
        raise ValueError("PROPOSAL_RULINGS_INCOMPLETE:" + sorted(pending - set(ruled))[0])
    current = deepcopy(state)
    requeue: list[str] = []
    for item in sorted(rulings, key=lambda r: r["segment_id"]):
        sid, ruling = item["segment_id"], item["ruling"]
        ref = f"BRAIN_PROPOSAL:{proposal_id}"
        if ruling == "REQUEUE":
            requeue.append(sid)
        elif ruling == "ACCEPT":
            current.setdefault("completed_segments", []).append({
                "segment_id": sid, "attempt_id": None, "status": "WORK_COMPLETE",
                "decision_code": "WORK_COMPLETE", "result_id": None, "ruling_ref": ref})
        elif ruling == "ABANDON":
            current = void(current, [sid], "ABANDONED", ref)
        else:
            raise ValueError("PROPOSAL_RULING_UNKNOWN:" + str(ruling))
    return current, requeue
