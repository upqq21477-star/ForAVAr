#!/usr/bin/env python3
"""Executable Simulated Amnesia / Resume 2.1 cases 1-10 plus canonical box recovery."""

from __future__ import annotations

import argparse
import json
from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ResumeResult:
    case_id: int
    status: str
    action: str
    loaded_history: int
    hot_checkpoint_refs: int
    selected_revision: str | None = None


def resume(
    *,
    current: dict[str, Any] | None,
    checkpoint: dict[str, Any] | None,
    evidence_refs: list[str],
    available_artifacts: set[str],
    historical_records: list[dict[str, Any]],
    semantic_versions: list[dict[str, Any]],
    rejected_decision_ids: set[str] | None = None,
) -> ResumeResult:
    rejected = rejected_decision_ids or set()

    if current is None:
        return ResumeResult(0, "BLOCK", "RECONCILE_OR_BLOCK", 0, 0)
    if checkpoint is None:
        return ResumeResult(0, "DATA_GAP", "RECONCILE_OR_BLOCK", 0, 0)
    if checkpoint.get("revision") != current.get("revision"):
        return ResumeResult(0, "STALE", "RECONCILE_OR_BLOCK", 0, 0)
    if current.get("required_artifact") and current["required_artifact"] not in available_artifacts:
        return ResumeResult(0, "DATA_GAP", "RECONCILE_OR_BLOCK", 0, 0)
    if current.get("conflict_ref"):
        return ResumeResult(0, "CONFLICT", "RECONCILE_OR_BLOCK", 0, 0)
    if current.get("next_action") in rejected:
        return ResumeResult(0, "REJECTED_CANDIDATE", "RECONCILE_OR_BLOCK", 0, 0)

    relevant = [
        record for record in historical_records
        if record.get("scope") in {None, current.get("scope")}
    ]

    valid_versions = [
        item for item in semantic_versions
        if item.get("valid") is True and item.get("canonical") is True
    ]
    selected = None
    if valid_versions:
        selected = max(valid_versions, key=lambda item: item.get("revision", 0))

    return ResumeResult(
        0,
        "PASS",
        "EXECUTE",
        len(relevant),
        min(len(evidence_refs), 16),
        selected_revision=selected.get("revision") if selected else None,
    )


def reconstruct_task_context(
    *,
    current: dict[str, Any],
    task_packet: dict[str, Any],
    continuation_box: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Rebuild execution context from canonical inputs and an optional bounded box.

    The box is only a resume descriptor. Existing Current, TaskPacket, Execution
    Truth and Event Log remain the owners of actual state and truth.
    """
    if not isinstance(current, dict) or not isinstance(task_packet, dict):
        raise ValueError("AMNESIA_INPUT_OBJECT_REQUIRED")

    implementation = current.get("implementation_control", {})
    active_work = implementation.get("active_work_packet")
    if not active_work:
        raise ValueError("AMNESIA_ACTIVE_WORK_PACKET_MISSING")

    task_object_id = task_packet.get("object_id")
    if not isinstance(task_object_id, str) or not task_object_id.startswith("TASK_PACKET:"):
        raise ValueError("AMNESIA_TASK_PACKET_IDENTITY_MISSING")

    required = (
        "objective",
        "requested_outputs",
        "constraints",
        "stop_condition",
        "failure_condition",
        "acceptance_ref",
        "context_budget",
        "retry_policy",
        "timeout_ms",
    )
    missing = [field for field in required if field not in task_packet]
    if missing:
        raise ValueError("AMNESIA_TASK_PACKET_FIELDS_MISSING:" + ",".join(missing))

    stage = current.get("current_stage", {})
    base = {
        "task_packet_ref": task_object_id,
        "active_work_packet": active_work,
        "current_stage_id": stage.get("id"),
        "current_stage_status": stage.get("status"),
        "objective": task_packet["objective"],
        "requested_outputs": list(task_packet["requested_outputs"]),
        "constraints": list(task_packet["constraints"]),
        "stop_condition": list(task_packet["stop_condition"]),
        "failure_condition": list(task_packet["failure_condition"]),
        "acceptance_ref": task_packet["acceptance_ref"],
        "context_budget": dict(task_packet["context_budget"]),
        "retry_policy": dict(task_packet["retry_policy"]),
        "timeout_ms": task_packet["timeout_ms"],
        "history_loaded": 0,
        "transient_context_loaded": False,
    }

    if continuation_box is None:
        return {
            "mode": "AMNESIA_RECONSTRUCTED",
            "source": "P1-CURRENT.json + TASK_PACKET_ONLY",
            **base,
        }

    from continuation_context_box import reconstruct

    boxed = reconstruct(
        current=current,
        task_packet=task_packet,
        box=continuation_box,
    )
    return {
        "mode": boxed["mode"],
        "source": "P1-CURRENT.json + TASK_PACKET + CONTINUATION_CONTEXT_BOX",
        **base,
        "execution_record_ref": boxed["execution_record_ref"],
        "continuation_box_ref": boxed["continuation_box_ref"],
        "resume_point": boxed["resume_point"],
        "targeted_retrieval_only": boxed["targeted_retrieval_only"],
        "resume_cursor": boxed["resume_cursor"],
    }


def run_cases() -> list[dict[str, Any]]:
    base_current = {
        "revision": 10,
        "scope": "SCOPE:A",
        "next_action": "EXECUTE:11",
        "required_artifact": "ARTIFACT:10",
    }
    base_checkpoint = {"revision": 10}

    raw = [
        ("CASE-01", {}),
        ("CASE-02", {"checkpoint": None}),
        ("CASE-03", {"checkpoint": {"revision": 9}}),
        ("CASE-04", {"current": {"conflict_ref": "CONFLICT:1"}}),
        ("CASE-05", {"current": {"next_action": "DECISION:REJECTED"}}),
        ("CASE-06", {"historical_records": []}),
        ("CASE-07", {"available_artifacts": set()}),
        ("CASE-08", {
            "historical_records": [
                {"id": f"H:{i}", "scope": "SCOPE:A" if i % 200 == 0 else "SCOPE:B"}
                for i in range(10000)
            ]
        }),
        ("CASE-09", {"evidence_refs": [f"E:{i}" for i in range(100000)]}),
        ("CASE-10", {
            "semantic_versions": [
                {"revision": 1, "valid": True, "canonical": False},
                {"revision": 2, "valid": True, "canonical": True},
                {"revision": 3, "valid": False, "canonical": True},
            ]
        }),
    ]

    results: list[dict[str, Any]] = []
    for index, (_, overrides) in enumerate(raw, start=1):
        current = dict(base_current)
        current.update(overrides.get("current", {}))
        checkpoint = overrides.get("checkpoint", base_checkpoint)
        artifacts = overrides.get("available_artifacts", {"ARTIFACT:10"})
        history = overrides.get(
            "historical_records",
            [{"id": "H:1", "scope": "SCOPE:A"}, {"id": "H:2", "scope": "SCOPE:B"}],
        )
        versions = overrides.get(
            "semantic_versions",
            [{"revision": 1, "valid": True, "canonical": True}],
        )
        expected = {
            1: ("PASS", "EXECUTE"),
            2: ("DATA_GAP", "RECONCILE_OR_BLOCK"),
            3: ("STALE", "RECONCILE_OR_BLOCK"),
            4: ("CONFLICT", "RECONCILE_OR_BLOCK"),
            5: ("REJECTED_CANDIDATE", "RECONCILE_OR_BLOCK"),
            6: ("PASS", "EXECUTE"),
            7: ("DATA_GAP", "RECONCILE_OR_BLOCK"),
            8: ("PASS", "EXECUTE"),
            9: ("PASS", "EXECUTE"),
            10: ("PASS", "EXECUTE"),
        }[index]
        result = resume(
            current=current,
            checkpoint=checkpoint,
            evidence_refs=overrides.get("evidence_refs", ["E:1", "E:2"]),
            available_artifacts=artifacts,
            historical_records=history,
            semantic_versions=versions,
            rejected_decision_ids={"DECISION:REJECTED"},
        )
        passed = (result.status, result.action) == expected
        results.append({
            "case_id": index,
            "status": result.status,
            "action": result.action,
            "expected": expected,
            "loaded_history": result.loaded_history,
            "hot_checkpoint_refs": result.hot_checkpoint_refs,
            "selected_revision": result.selected_revision,
            "pass": passed,
        })
    return results


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output")
    args = parser.parse_args()
    report = {
        "model": "p1-simulated-amnesia-resume-v2.1",
        "cases": run_cases(),
        "case_count": 10,
    }
    report["status"] = "PASS" if all(item["pass"] for item in report["cases"]) else "BLOCK"
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    print(rendered)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as handle:
            handle.write(rendered + "\n")
    return 0 if report["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
