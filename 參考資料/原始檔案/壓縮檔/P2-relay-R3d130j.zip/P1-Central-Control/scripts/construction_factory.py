#!/usr/bin/env python3
"""Turn an accepted construction request into a controlled registry change."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from construction_entrypoint import execute as execute_construction
from construction_registration import REGISTRY_PATHS, _load, validate as validate_registration


ROOT = Path(__file__).resolve().parents[2]
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/construction_factory_result.schema.json"


REGISTRY_KEYS = {
    "SYSTEM": ("systems", "system_id"),
    "CAPABILITY": ("capabilities", "capability_id"),
    "FUNCTION": ("functions", "function_id"),
}


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _validate_result(result: dict[str, Any]) -> None:
    schema = _load(RESULT_SCHEMA)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(result),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def _registry_change(
    base: Path,
    registration: dict[str, Any],
) -> tuple[Path, dict[str, Any], str, str]:
    target_type = registration["target_type"]
    if target_type not in REGISTRY_KEYS:
        raise ValueError(f"REGISTRY_APPLY_UNSUPPORTED:{target_type}")

    path = base / REGISTRY_PATHS[target_type]
    document = _load(path)
    rows_key, id_key = REGISTRY_KEYS[target_type]
    rows = document.get(rows_key)
    if not isinstance(rows, list):
        raise ValueError(f"REGISTRY_ROWS_INVALID:{rows_key}")

    candidate = _load(base / registration["artifact_path"])
    target_id = registration["target_id"]
    index = next(
        (i for i, row in enumerate(rows) if isinstance(row, dict) and row.get(id_key) == target_id),
        None,
    )

    if registration["mode"] == "CREATE_NEW":
        if index is not None:
            raise ValueError("TARGET_ALREADY_EXISTS")
        rows.append(candidate)
    elif registration["mode"] == "UPDATE_EXISTING":
        if index is None:
            raise ValueError("TARGET_NOT_FOUND")
        rows[index] = candidate
    else:
        raise ValueError(f"REGISTRATION_MODE_UNSUPPORTED:{registration['mode']}")

    rows.sort(key=lambda row: row.get(id_key, ""))
    document[rows_key] = rows
    return path, document, rows_key, id_key


def _atomic_write(path: Path, value: dict[str, Any]) -> None:
    fd, temp_name = tempfile.mkstemp(
        prefix=f".{path.name}.",
        suffix=".tmp",
        dir=path.parent,
    )
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(value, handle, ensure_ascii=False, indent=2)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_name, path)
    except Exception:
        try:
            os.unlink(temp_name)
        except FileNotFoundError:
            pass
        raise


def execute(
    request: dict[str, Any],
    *,
    base_dir: str | Path | None = None,
    apply: bool = False,
) -> dict[str, Any]:
    base = Path(base_dir or ".").resolve()
    construction = execute_construction(request, base)
    registration = request.get("registration")

    if construction["status"] != "PASS":
        result = {
            "schema_version": "1.0",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "status": "BLOCK",
            "applied": False,
            "registration": registration or {},
            "before_sha256": None,
            "after_sha256": None,
            "reason": "CONSTRUCTION_NOT_FINALIZED",
        }
        _validate_result(result)
        return result

    if registration["target_type"] not in REGISTRY_KEYS:
        result = {
            "schema_version": "1.0",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "status": "BLOCK",
            "applied": False,
            "registration": registration,
            "before_sha256": None,
            "after_sha256": None,
            "reason": f"REGISTRY_APPLY_UNSUPPORTED:{registration['target_type']}",
        }
        _validate_result(result)
        return result

    validation = validate_registration(registration, base_dir=base)
    if validation["status"] != "PASS":
        result = {
            "schema_version": "1.0",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "status": "BLOCK",
            "applied": False,
            "registration": validation,
            "before_sha256": None,
            "after_sha256": None,
            "reason": "REGISTRATION_NOT_READY",
        }
        _validate_result(result)
        return result

    path, updated, _, _ = _registry_change(base, registration)
    before = _sha256(path)

    if apply:
        _atomic_write(path, updated)
        after = _sha256(path)
        result = {
            "schema_version": "1.0",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "status": "PASS",
            "applied": True,
            "registration": validation,
            "before_sha256": before,
            "after_sha256": after,
            "changed_path": str(path.relative_to(base)),
        }
    else:
        result = {
            "schema_version": "1.0",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "status": "PASS",
            "applied": False,
            "registration": validation,
            "before_sha256": before,
            "after_sha256": before,
            "changed_path": str(path.relative_to(base)),
        }

    _validate_result(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("request")
    parser.add_argument("--base-dir", default=".")
    parser.add_argument("--apply", action="store_true")
    args = parser.parse_args()

    request = _load(Path(args.base_dir).resolve() / args.request)
    result = execute(request, base_dir=args.base_dir, apply=args.apply)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
