#!/usr/bin/env python3
"""Minimal trusted continuation runner.

Trusted execution accepts only typed actions routed through fixed handlers.
The legacy next_command field is never executed by this runtime.
"""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable

import command_layer
from command_layer import admit_executable_action

MAX_TIMEOUT_SECONDS = 600
TEST_ROOT = Path("P1-Central-Control/tests")
SENSITIVE_NAMES = {
    ".env",
    ".git",
    ".github",
    ".ssh",
    "credentials",
    "secrets",
    "id_rsa",
    "id_ed25519",
}


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def _as_text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bytes):
        return value.decode("utf-8", errors="replace")
    return str(value)


def _minimal_environment() -> dict[str, str]:
    path = os.environ.get("PATH", "/usr/bin:/bin")
    return {
        "PATH": path,
        "PYTHONUNBUFFERED": "1",
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
    }


def _reject_sensitive_parts(relative_path: Path) -> None:
    lowered = {part.lower() for part in relative_path.parts}
    if lowered & SENSITIVE_NAMES:
        raise ValueError("SENSITIVE_PATH_BLOCKED")


def _resolve_workspace_test(root: Path, value: Any) -> Path:
    if not isinstance(value, str) or not value.strip():
        raise ValueError("TEST_PATH_MISSING")
    raw = Path(value)
    if raw.is_absolute():
        raise ValueError("ABSOLUTE_PATH_BLOCKED")
    if ".." in raw.parts:
        raise ValueError("PATH_TRAVERSAL_BLOCKED")
    _reject_sensitive_parts(raw)
    workspace = root.resolve()
    test_root = (root / TEST_ROOT).resolve()
    raw_candidate = root / raw
    if raw_candidate.is_symlink():
        target = raw_candidate.resolve()
        try:
            target.relative_to(workspace)
        except ValueError as exc:
            raise ValueError("SYMLINK_ESCAPE_BLOCKED") from exc
        try:
            target.relative_to(test_root)
        except ValueError as exc:
            raise ValueError("SYMLINK_OUTSIDE_TEST_SCOPE") from exc
    candidate = raw_candidate.resolve()
    try:
        candidate.relative_to(test_root)
    except ValueError as exc:
        raise ValueError("TEST_PATH_OUTSIDE_ALLOWED_SCOPE") from exc
    if not candidate.is_file():
        raise ValueError("TEST_PATH_NOT_FILE")
    return candidate


def validate_typed_action(root: Path, action: Any) -> dict[str, Any]:
    if not isinstance(action, dict):
        raise ValueError("TYPED_ACTION_REQUIRED")
    if set(action) != {"command_type", "args"}:
        if "argv" in action:
            raise ValueError("ARBITRARY_ARGV_BLOCKED")
        raise ValueError("TYPED_ACTION_SHAPE_INVALID")

    command_type = action.get("command_type")
    args = action.get("args")
    if command_type != "RUN_REPOSITORY_TESTS":
        raise ValueError("UNKNOWN_COMMAND_TYPE")
    if not isinstance(args, dict) or set(args) != {"tests"}:
        raise ValueError("TYPED_ARGS_INVALID")

    tests = args.get("tests")
    if not isinstance(tests, list) or not tests:
        raise ValueError("TYPED_ARGS_INVALID")
    if len(tests) > 50:
        raise ValueError("TOO_MANY_TESTS")

    normalized = []
    for item in tests:
        normalized.append(
            str(_resolve_workspace_test(root, item).relative_to(root))
        )

    return {
        "command_type": command_type,
        "args": {"tests": normalized},
    }


def _run_repository_tests(
    root: Path,
    action: dict[str, Any],
    *,
    timeout_seconds: int,
) -> dict[str, Any]:
    normalized = validate_typed_action(root, action)
    tests = normalized["args"]["tests"]
    if timeout_seconds < 1 or timeout_seconds > MAX_TIMEOUT_SECONDS:
        raise ValueError("timeout_seconds 必須為 1..600")

    command = [
        sys.executable,
        "-m",
        "unittest",
        "-v",
        *tests,
    ]
    try:
        completed = subprocess.run(
            command,
            cwd=root,
            env=_minimal_environment(),
            text=True,
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
            shell=False,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "status": "BLOCK",
            "command_type": normalized["command_type"],
            "returncode": None,
            "timed_out": True,
            "stdout": _as_text(exc.stdout),
            "stderr": _as_text(exc.stderr),
            "command": command,
        }
    except OSError as exc:
        return {
            "status": "BLOCK",
            "command_type": normalized["command_type"],
            "returncode": None,
            "timed_out": False,
            "stdout": "",
            "stderr": str(exc),
            "command": command,
        }

    return {
        "status": "PASS" if completed.returncode == 0 else "BLOCK",
        "command_type": normalized["command_type"],
        "returncode": completed.returncode,
        "timed_out": False,
        "stdout": completed.stdout,
        "stderr": completed.stderr,
        "command": command,
    }


_TRUSTED_ACTION_HANDLERS: dict[str, Callable[..., dict[str, Any]]] = {
    command_type: _run_repository_tests
    for command_type in command_layer.TRUSTED_EXECUTABLE_ACTION_TYPES
}


def execute_typed_action(
    root: Path,
    action: Any,
    *,
    timeout_seconds: int = 300,
) -> dict[str, Any]:
    """Validate and execute one fixed, typed action.

    This is an implementation-level handler map, not a canonical registry.
    Unknown action types and arbitrary argv are rejected before side effects.
    """
    try:
        admitted = admit_executable_action(action)
        command_type = admitted["command_type"]
        handler = _TRUSTED_ACTION_HANDLERS.get(command_type)
        if handler is None:
            raise ValueError("UNKNOWN_COMMAND_TYPE")
        normalized = validate_typed_action(root, admitted)
        return handler(root, normalized, timeout_seconds=timeout_seconds)
    except ValueError as exc:
        return {
            "status": "BLOCK",
            "command_type": action.get("command_type") if isinstance(action, dict) else None,
            "reason": str(exc),
            "returncode": None,
            "timed_out": False,
            "stdout": "",
            "stderr": "",
            "command": None,
        }


def _next_action(packet: dict[str, Any]) -> dict[str, Any] | None:
    action = packet.get("next_action")
    if action is None:
        return None
    if not isinstance(action, dict):
        raise ValueError("next_action 必須為 object")
    return action


def continue_once(
    state: dict[str, Any],
    command: dict[str, Any],
    *,
    event_log_path: str | Path,
) -> dict[str, Any]:
    """Thin continuation: invoke the existing Command Layer and return one observation.

    The runner does not own workflow state, retry policy, persistence, or scheduling.
    Updated state is returned as an observation for the existing caller to commit.
    """
    event_log = command_layer.EventLog(event_log_path)
    updated, result = command_layer.execute_command(
        state,
        command,
        event_log=event_log,
        has_queued_work=bool(state.get("queued_segments")),
    )
    continued = result["status"] in {command_layer.ACCEPTED, command_layer.REPLAY}
    return {
        "status": "PASS" if continued else "BLOCK",
        "continued": continued,
        "observation": {
            "command_id": command["command_id"],
            "result_status": result["status"],
            "reason": result["action"]["reason"],
            "state": updated,
            "result": result,
        },
    }


def run_once(
    root: Path,
    packet: dict[str, Any],
    *,
    timeout_seconds: int = 300,
) -> dict[str, Any]:
    """Consume one typed action only.

    Construction lifecycle and acceptance belong to the construction/CI
    boundary. The trusted runner only admits and executes the fixed typed
    action, then returns its observation.
    """
    if timeout_seconds < 1 or timeout_seconds > MAX_TIMEOUT_SECONDS:
        raise ValueError("timeout_seconds 必須為 1..600")

    try:
        action = _next_action(packet)
    except ValueError as exc:
        return {
            "status": "BLOCK",
            "continued": False,
            "next_action": None,
            "next_action_execution": {
                "status": "BLOCK",
                "reason": str(exc),
            },
        }

    if action is None:
        return {
            "status": "BLOCK",
            "continued": False,
            "next_action": None,
            "next_action_execution": {
                "status": "BLOCK",
                "reason": "TRUSTED_TYPED_ACTION_REQUIRED",
            },
        }

    execution = execute_typed_action(
        root,
        action,
        timeout_seconds=timeout_seconds,
    )
    return {
        "status": execution["status"],
        "continued": execution["status"] == "PASS",
        "next_action": action,
        "next_action_execution": execution,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Consume one P1 typed trusted action or thin continuation"
    )
    parser.add_argument("packet", nargs="?", help="legacy work packet JSON path")
    parser.add_argument("--root", default=".", help="repository root")
    parser.add_argument("--timeout-seconds", type=int, default=300)
    parser.add_argument("--output")
    parser.add_argument("--continue-state", help="workflow state JSON path")
    parser.add_argument("--continue-command", help="command JSON path")
    parser.add_argument("--event-log", help="existing EventLog path")
    args = parser.parse_args()

    if args.continue_state or args.continue_command or args.event_log:
        if not (args.continue_state and args.continue_command and args.event_log):
            parser.error("--continue-state、--continue-command、--event-log 必須一起提供")
        result = continue_once(
            load_json(Path(args.continue_state)),
            load_json(Path(args.continue_command)),
            event_log_path=args.event_log,
        )
    else:
        if not args.packet:
            parser.error("需要提供 packet，或使用 --continue-state/--continue-command/--event-log")
        root = Path(args.root).resolve()
        packet_path = (root / args.packet).resolve()
        result = run_once(
            root,
            load_json(packet_path),
            timeout_seconds=args.timeout_seconds,
        )

    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        output = (Path(args.output)).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if result["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
