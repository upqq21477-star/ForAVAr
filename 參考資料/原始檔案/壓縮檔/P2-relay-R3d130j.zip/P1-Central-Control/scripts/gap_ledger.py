"""gap_ledger -- deterministic gap checkpoint (CAP-GAP).  Gap id = hash of its source evidence (rewrite keeps one entry);
every gap needs an evidence_ref; priority FAIL > INCOMPLETE > UNKNOWN (insertion = dependency order);
the checkpoint {round, prev_ids, gaps} is written with atomic_write and is shared with iterate_control."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from atomic_write import atomic_write

RANK = {"FAIL": 0, "INCOMPLETE": 1}


def gap_id(ref: Any) -> str:
    return hashlib.sha256(str(ref).encode("utf-8")).hexdigest()[:16]


def make_gap(desc: str, priority: str, evidence_ref: Any, task: str = "") -> dict[str, Any]:
    if not evidence_ref:
        raise ValueError("NO_EVIDENCE_REF")
    return {"id": gap_id(evidence_ref), "task": task, "desc": desc, "priority": priority if priority in RANK else "UNKNOWN",
            "evidence_ref": evidence_ref}


def ordered(gaps: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(gaps, key=lambda g: RANK.get(g["priority"], len(RANK)))  # stable sort


def apply_verdict(ck: dict[str, Any], v: dict[str, Any], task: str) -> dict[str, Any]:
    if v["verdict"] == "PASS":
        ck["gaps"] = [g for g in ck["gaps"] if g.get("task") != task]  # the task now passes: its gaps are resolved
    else:
        g = make_gap("; ".join(v.get("failed") or v.get("reasons") or ["no detail"]), v["verdict"], v["key"], task)
        ck["gaps"] = ordered([x for x in ck["gaps"] if x["id"] != g["id"]] + [g])
    return ck


def load(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {"round": 0, "prev_ids": [], "gaps": []}
    try:
        ck = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(ck, dict) or not isinstance(ck.get("gaps"), list):
            raise ValueError("shape")
    except (ValueError, OSError):
        raise ValueError("LEDGER_CORRUPT") from None
    ck.setdefault("round", 0)
    ck.setdefault("prev_ids", [])
    return ck


def save(path: str | Path, ck: dict[str, Any]) -> None:
    atomic_write(path, json.dumps(ck, ensure_ascii=False, sort_keys=True, indent=1))
