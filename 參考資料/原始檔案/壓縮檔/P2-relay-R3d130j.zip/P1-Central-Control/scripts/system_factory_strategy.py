#!/usr/bin/env python3
"""Evidence-gated F20 strategy selection; never mutates a system or registry."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
REQUEST_SCHEMA = "P1-Central-Control/schemas/system_factory_strategy_request.schema.json"
RESULT_SCHEMA = "P1-Central-Control/schemas/system_factory_strategy.schema.json"


class FactoryStrategyError(ValueError):
    pass


def _validate(value: dict[str, Any], schema_ref: str, root: Path) -> None:
    path = root / schema_ref
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
        raise FactoryStrategyError("FACTORY_STRATEGY_SCHEMA_PATH_INVALID")
    try:
        from jsonschema import Draft202012Validator
        schema = json.loads(path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(value)
    except FactoryStrategyError:
        raise
    except Exception as exc:
        raise FactoryStrategyError(f"FACTORY_STRATEGY_SCHEMA_INVALID:{type(exc).__name__}:{exc}") from exc


def validate_request(request: dict[str, Any], root: Path = ROOT) -> None:
    _validate(request, REQUEST_SCHEMA, root)


def validate_result(result: dict[str, Any], root: Path = ROOT) -> None:
    _validate(result, RESULT_SCHEMA, root)


def decide_strategy(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    """Choose BUILD/REPAIR/EXTEND/REBUILD only when required evidence gates are explicit."""
    if not isinstance(request, dict):
        raise FactoryStrategyError("FACTORY_STRATEGY_REQUEST_OBJECT_REQUIRED")
    validate_request(request, root)
    kind = request["request_kind"]
    system_status = request["system_status"]
    inventory = request["inventory_status"]
    root_cause = request["root_cause_status"]
    architecture = request["architecture_status"]
    compatibility = request["compatibility_status"]
    bounded_repair = request["repair_scope_bounded"]
    rebuild_evidence = request["rebuild_evidence_status"]
    scope_ref = request["scope_ref"].strip() if isinstance(request["scope_ref"], str) else None
    evidence_refs = request["evidence_refs"]
    cause_refs = request["root_cause_refs"]
    rebuild_refs = request["rebuild_evidence_refs"]
    explicit_rebuild_auth = request["explicit_rebuild_authorization"]
    governance_approval = request["governance_approval"]
    rollback_ready = request["rollback_ready"]

    checks: list[dict[str, str]] = []

    def check(check_id: str, status: str, detail: str) -> None:
        checks.append({"check_id": check_id, "status": status, "detail": detail})

    def result(
        status: str,
        strategy: str | None,
        rationale: str,
        *,
        confirmation: bool = False,
        governance: bool = False,
        warnings: list[str] | None = None,
        next_action: str,
    ) -> dict[str, Any]:
        value = {
            "request_id": request["request_id"],
            "status": status,
            "system_id": request["system_id"],
            "request_kind": kind,
            "chosen_strategy": strategy,
            "decision_rationale": rationale,
            "evidence_refs": list(dict.fromkeys(evidence_refs + cause_refs + rebuild_refs)),
            "scope_ref": scope_ref,
            "checks": checks,
            "execution_authorized": False,
            "confirmation_required": confirmation,
            "governance_approval_required": governance,
            "must_preserve": [
                "Strategy selection does not authorize execution or registry mutation.",
                "Never classify unscanned paths or unknown architecture as confirmed absent.",
                "A REBUILD strategy requires separate construction admission, independent validation, and recoverable rollback evidence.",
                "The existing Construction Factory remains the only registry mutation path after its lifecycle and registration gates pass.",
            ],
            "warnings": warnings or [],
            "required_next_action": next_action,
        }
        validate_result(value, root)
        return value

    if kind == "UNKNOWN":
        check("INTENT", "UNKNOWN", "The request does not specify build, repair, extend, or replacement intent.")
        return result(
            "BLOCKED_UNKNOWN", None,
            "The factory cannot infer a construction strategy from an unknown request kind.",
            next_action="Clarify the intended outcome and bounded target scope before any factory action.",
            warnings=["No strategy was selected."],
        )

    if system_status == "CONFLICT" or inventory == "CONFLICT":
        check("SYSTEM_AND_INVENTORY_TRUTH", "FAIL", "Conflicting state evidence prevents safe strategy selection.")
        return result(
            "BLOCKED_CONFLICT", None,
            "Conflicting system/inventory evidence must be reconciled before choosing a strategy.",
            next_action="Reconcile the conflicting authoritative sources and rerun strategy selection.",
            warnings=["Conflict is not treated as absence or permission to rebuild."],
        )

    if system_status == "UNKNOWN":
        check("SYSTEM_PRESENCE", "UNKNOWN", "It is not established whether the target system exists.")
        return result(
            "BLOCKED_UNKNOWN", None,
            "System existence is unknown; destructive or replacement decisions are prohibited.",
            next_action="Run a bounded, explicit-path inventory and identify the authoritative system registry entry.",
            warnings=["UNKNOWN is not MISSING."],
        )

    if not scope_ref:
        check("TARGET_SCOPE", "FAIL", "No explicit, bounded target scope was supplied.")
        return result(
            "BLOCKED_SCOPE", None,
            "The factory requires an explicit target scope; it will not infer a repository-wide change.",
            next_action="Supply a declared scope reference and the relevant source/evidence references.",
            warnings=["Scope was not inferred."],
        )

    if kind == "BUILD_NEW":
        check("SYSTEM_ABSENCE", "PASS" if system_status == "NOT_PRESENT" else "FAIL",
              "New build requires the target to be explicitly declared not present.")
        check("INVENTORY_SCOPE", "PASS" if inventory == "NOT_APPLICABLE" else "FAIL",
              "A new target must not be conflated with an unscanned existing system.")
        check("ARCHITECTURE_BASELINE", "PASS" if architecture in {"VALIDATED", "NOT_APPLICABLE"} else "UNKNOWN",
              "A new build still needs an explicit validated architecture baseline or an explicit declaration that it is not applicable.")
        if architecture not in {"VALIDATED", "NOT_APPLICABLE"}:
            return result(
                "NEEDS_EVIDENCE", None,
                "The target is new, but its architecture baseline is not validated or explicitly declared not applicable.",
                next_action="Complete the minimal system design and acceptance contract before generating a construction plan.",
            )
        if system_status != "NOT_PRESENT" or inventory != "NOT_APPLICABLE":
            return result(
                "NEEDS_EVIDENCE", None,
                "BUILD_NEW is eligible only when the target is explicitly not present, not merely unscanned.",
                next_action="Resolve target presence and inventory status; do not create a duplicate system.",
                warnings=["A name collision or incomplete inventory blocks automatic new-build selection."],
            )
        if not evidence_refs:
            check("REQUEST_EVIDENCE", "UNKNOWN", "No scope/request evidence reference was supplied.")
            return result(
                "NEEDS_EVIDENCE", None,
                "The target is new, but the build scope has no evidence/source reference.",
                next_action="Add the approved request/specification reference before generating the construction plan.",
            )
        check("BUILD_SCOPE", "PASS", "Target scope is explicit and source-referenced.")
        return result(
            "STRATEGY_SELECTED", "BUILD",
            "The target is explicitly not present and a bounded source-referenced scope is available.",
            next_action="Pass the strategy decision to the existing Construction Entry Point; validate semantic spec, lifecycle, registration and post-acceptance before writes.",
        )

    if system_status not in {"PRESENT", "PARTIAL"}:
        check("SYSTEM_PRESENCE", "FAIL", "An existing-system operation requires a confirmed present/partial target.")
        return result(
            "NEEDS_EVIDENCE", None,
            "The request describes an operation on an existing system, but its presence is not established.",
            next_action="Identify the authoritative system and its current revision before repair, extension, or replacement.",
            warnings=["Do not choose BUILD as a fallback for an unknown existing-system state."],
        )

    if inventory != "COMPLETE":
        check("INVENTORY_COMPLETENESS", "UNKNOWN", f"Inventory is {inventory}; the required scope is not fully inspected.")
        return result(
            "NEEDS_EVIDENCE", None,
            "The current implementation/inventory scope is incomplete; unscanned targets stay UNKNOWN.",
            next_action="Complete a bounded scan of the explicitly required target paths and local dependencies; leave unrelated paths unscanned.",
            warnings=["Partial or unstarted inventory is not evidence that files/features are missing; unscanned paths stay UNKNOWN."],
        )

    check("INVENTORY_COMPLETENESS", "PASS", "The declared target scope was inventoried within the stated limits.")

    if kind == "FIX_FAILURE":
        check("ROOT_CAUSE", "PASS" if root_cause == "CONFIRMED" and bool(cause_refs) else "UNKNOWN",
              "Repair requires a confirmed, referenced root cause.")
        check("REPAIR_SCOPE", "PASS" if bounded_repair is True else "FAIL",
              "Repair scope must be explicitly bounded.")
        check("ARCHITECTURE_COMPATIBILITY", "PASS" if architecture in {"VALIDATED", "COMPATIBLE"} else "FAIL",
              "Repair must not ignore unresolved architecture conflicts.")
        if root_cause != "CONFIRMED" or not cause_refs:
            return result(
                "NEEDS_EVIDENCE", None,
                "A repair strategy requires a confirmed root cause with explicit evidence references.",
                next_action="Gather supporting/contradicting evidence and run a discriminating test before repair.",
            )
        if architecture == "UNKNOWN":
            return result(
                "NEEDS_EVIDENCE", None,
                "Architecture compatibility remains UNKNOWN; the factory will not assume the proposed repair is safe.",
                next_action="Reconcile the current architecture contract before selecting repair.",
            )
        if bounded_repair is not True or architecture not in {"VALIDATED", "COMPATIBLE"}:
            return result(
                "BLOCKED_SCOPE", None,
                "The repair scope is unbounded or an architectural conflict prevents a safe repair.",
                next_action="Bound the repair blast radius and reconcile architectural conflicts before construction.",
            )
        return result(
            "STRATEGY_SELECTED", "REPAIR",
            "A confirmed failure mechanism exists inside a bounded, architecture-compatible scope.",
            next_action="Create a reversible, scope-limited repair through the existing Construction Entry Point and verify dependent contracts.",
        )

    if kind == "ADD_CAPABILITY":
        check("ARCHITECTURE_COMPATIBILITY", "PASS" if architecture in {"VALIDATED", "COMPATIBLE"} else "FAIL",
              "Extension must preserve the current system's declared contracts.")
        check("CAPABILITY_COMPATIBILITY", "PASS" if compatibility == "COMPATIBLE" else "FAIL",
              "The candidate capability must be contract-compatible with current state.")
        if not evidence_refs:
            check("CAPABILITY_GAP_EVIDENCE", "UNKNOWN", "No declared capability-gap/source evidence was supplied.")
            return result(
                "NEEDS_EVIDENCE", None,
                "Capability extension requires evidence of the gap and target contract.",
                next_action="Reference the current contract and the demonstrated capability gap.",
            )
        if architecture == "UNKNOWN" or compatibility == "UNKNOWN":
            return result(
                "NEEDS_EVIDENCE", None,
                "The existing architecture/capability compatibility is UNKNOWN.",
                next_action="Compare the candidate capability against the current contract and gather explicit compatibility evidence.",
            )
        if architecture not in {"VALIDATED", "COMPATIBLE"} or compatibility != "COMPATIBLE":
            return result(
                "BLOCKED_CONFLICT", None,
                "A capability cannot be extended into an incompatible or conflicted architecture.",
                next_action="Resolve the compatibility conflict or submit a separately authorized architecture change.",
            )
        return result(
            "STRATEGY_SELECTED", "EXTEND",
            "The existing system is inventoried and the proposed capability is contract-compatible.",
            next_action="Implement the capability as an additive, reversible construction unit; preserve existing callers and rollback.",
        )

    if kind == "REPLACE_ARCHITECTURE":
        replacement_necessity = architecture == "CONFLICT" or compatibility == "INCOMPATIBLE"
        check("REPLACEMENT_NECESSITY", "PASS" if replacement_necessity else "UNKNOWN",
              "A replacement request must show an architectural conflict or confirmed incompatibility, not preference alone.")
        if not replacement_necessity:
            return result(
                "NEEDS_EVIDENCE", None,
                "The request asks for replacement, but the current evidence does not establish that repair/extension is insufficient.",
                next_action="Compare repair and extension against explicit requirements and record the confirmed incompatibility that necessitates replacement.",
            )
        check("REPLACEMENT_EVIDENCE", "PASS" if rebuild_evidence == "CONFIRMED" and bool(rebuild_refs) else "UNKNOWN",
              "Replacement requires confirmed evidence that incremental repair/extension is insufficient.")
        check("EXPLICIT_AUTHORIZATION", "PASS" if explicit_rebuild_auth else "FAIL",
              "Rebuild requires explicit user authorization.")
        check("GOVERNANCE_APPROVAL", "PASS" if governance_approval else "FAIL",
              "Architecture replacement requires Governance approval.")
        check("ROLLBACK_RECOVERY", "PASS" if rollback_ready else "FAIL",
              "A recoverable rollback/migration path must be ready before rebuild.")
        if rebuild_evidence != "CONFIRMED" or not rebuild_refs:
            return result(
                "NEEDS_EVIDENCE", None,
                "Rebuild is not eligible without confirmed replacement necessity and supporting evidence.",
                next_action="Compare repair/extend alternatives and record why they cannot satisfy the confirmed requirements.",
            )
        if not explicit_rebuild_auth:
            return result(
                "NEEDS_CONFIRMATION", None,
                "The evidence may support replacement, but explicit user authorization is absent.",
                confirmation=True,
                next_action="Obtain explicit confirmation of target, scope, data preservation and replacement impact.",
            )
        if not governance_approval:
            return result(
                "NEEDS_GOVERNANCE", None,
                "Architecture replacement requires Governance approval.",
                governance=True,
                next_action="Route the evidence, alternatives and rollback plan to Governance; do not modify the system yet.",
            )
        if not rollback_ready:
            return result(
                "BLOCKED_SCOPE", None,
                "Replacement lacks a verified rollback/migration recovery plan.",
                next_action="Build and independently review a recoverable migration/rollback path before any construction.",
            )
        return result(
            "STRATEGY_SELECTED", "REBUILD",
            "Confirmed replacement necessity, explicit user authorization, Governance approval, and rollback readiness are all present.",
            next_action="Open a separate, explicitly authorized construction unit; this strategy decision itself never executes or mutates the registry.",
        )

    check("REQUEST_KIND", "UNKNOWN", "The request kind does not map to a supported safe factory strategy.")
    return result(
        "BLOCKED_UNKNOWN", None,
        "No strategy is selected for an unsupported intent.",
        next_action="Clarify the intended operation using the supported request kinds.",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="Select a safe construction strategy from declared evidence")
    parser.add_argument("--request", required=True)
    parser.add_argument("--output")
    parser.add_argument("--root", default=str(ROOT))
    args = parser.parse_args()
    try:
        root = Path(args.root).resolve()
        request = json.loads(Path(args.request).read_text(encoding="utf-8"))
        decision = decide_strategy(request, root)
        rendered = json.dumps(decision, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            Path(args.output).write_text(rendered, encoding="utf-8")
        print(rendered, end="")
        return 0 if decision["status"] == "STRATEGY_SELECTED" else 2
    except (OSError, json.JSONDecodeError, FactoryStrategyError) as exc:
        print(json.dumps({"status":"BLOCKED","reason_code":str(exc).split(":",1)[0],"detail":str(exc)},ensure_ascii=False,indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
