#!/usr/bin/env python3
"""Evidence-gated F22 root-cause distillation and downstream-evidence invalidation.

This module emits a decision only. It does not edit the blueprint, registry,
Current, capability bindings, or validation reports.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
REQUEST_SCHEMA = "P1-Central-Control/schemas/root_cause_distillation_request.schema.json"
DECISION_SCHEMA = "P1-Central-Control/schemas/root_cause_distillation_decision.schema.json"
VALID_SCOPE = {"SINGLE_OUTPUT", "SINGLE_MODULE", "SUBSYSTEM", "MULTI_DOMAIN", "AUTHORITY_BOUNDARY"}
CONFIRMED_KINDS = {"OBSERVED", "CONFIRMED"}


class RootCauseDistillationError(ValueError):
    pass


def _load_schema(root: Path, ref: str) -> dict[str, Any]:
    path = root / ref
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
        raise RootCauseDistillationError("ROOT_CAUSE_SCHEMA_PATH_INVALID")
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(value, dict):
            raise ValueError("JSON_OBJECT_REQUIRED")
        return value
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise RootCauseDistillationError(f"ROOT_CAUSE_SCHEMA_READ_FAILED:{type(exc).__name__}") from exc


def _validate(value: dict[str, Any], schema_ref: str, root: Path) -> None:
    try:
        from jsonschema import Draft202012Validator
        schema = _load_schema(root, schema_ref)
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(value)
    except RootCauseDistillationError:
        raise
    except Exception as exc:
        raise RootCauseDistillationError(f"ROOT_CAUSE_SCHEMA_INVALID:{type(exc).__name__}:{str(exc)[:250]}") from exc


def _safe_ref(value: str, field: str) -> None:
    candidate = Path(value.strip())
    if (
        not value.strip() or len(value) > 500
        or candidate.is_absolute()
        or ".." in candidate.parts
        or value.strip().startswith(("/", "\\"))
    ):
        raise RootCauseDistillationError(f"ROOT_CAUSE_REFERENCE_INVALID:{field}")


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def distill_root_cause(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    """Confirm a root cause only from evidence + discriminating test, and invalidate stale descendants."""
    if not isinstance(request, dict):
        raise RootCauseDistillationError("ROOT_CAUSE_REQUEST_OBJECT_REQUIRED")
    _validate(request, REQUEST_SCHEMA, root)

    for index, ref in enumerate(request["target_paths"]):
        _safe_ref(ref, f"target_paths[{index}]")
    for field in ("target_scope_ref",):
        _safe_ref(request[field], field)
    for index, ref in enumerate(request["prior_downstream_evidence_refs"]):
        _safe_ref(ref, f"prior_downstream_evidence_refs[{index}]")

    evidence_rows = request["evidence"]
    evidence_by_id: dict[str, dict[str, Any]] = {}
    for item in evidence_rows:
        _safe_ref(item["source_ref"], f"evidence:{item['evidence_id']}")
        if item["evidence_id"] in evidence_by_id:
            raise RootCauseDistillationError("ROOT_CAUSE_EVIDENCE_ID_DUPLICATED")
        evidence_by_id[item["evidence_id"]] = item
    hypotheses = request["hypotheses"]
    if len({item["hypothesis_id"] for item in hypotheses}) != len(hypotheses):
        raise RootCauseDistillationError("ROOT_CAUSE_HYPOTHESIS_ID_DUPLICATED")

    checks: list[dict[str, str]] = []

    def add_check(key: str, status: str, detail: str) -> None:
        checks.append({"check_id": key, "status": status, "detail": detail})

    hypotheses_evaluated: list[dict[str, Any]] = []
    confirmed: list[dict[str, Any]] = []
    rejected: list[dict[str, Any]] = []
    warnings: list[str] = []
    for hypothesis in hypotheses:
        support_ids = hypothesis["supporting_evidence_ids"]
        contradict_ids = hypothesis["contradicting_evidence_ids"]
        missing_ids = sorted((set(support_ids) | set(contradict_ids)) - set(evidence_by_id))
        if missing_ids:
            raise RootCauseDistillationError(
                "ROOT_CAUSE_EVIDENCE_ID_UNKNOWN:" + hypothesis["hypothesis_id"] + ":" + ",".join(missing_ids)
            )
        _safe_ref(hypothesis["discriminating_test_ref"], f"test:{hypothesis['hypothesis_id']}")
        if hypothesis["test_output_ref"] is not None:
            _safe_ref(hypothesis["test_output_ref"], f"test_output:{hypothesis['hypothesis_id']}")

        support = [evidence_by_id[item] for item in support_ids]
        contradict = [evidence_by_id[item] for item in contradict_ids]
        support_confirmed = bool(support) and all(item["kind"] in CONFIRMED_KINDS for item in support)
        has_confirmed_counterevidence = any(item["kind"] in CONFIRMED_KINDS for item in contradict)
        test_complete = (
            hypothesis["test_result"] in {"CONFIRMS", "CONTRADICTS"}
            and isinstance(hypothesis["test_output_ref"], str)
            and bool(hypothesis["test_output_ref"].strip())
        )
        conflict_in_hypothesis = any(
            item["kind"] in {"UNKNOWN", "CONFLICT"} for item in support + contradict
        )
        can_confirm = (
            hypothesis["test_result"] == "CONFIRMS"
            and test_complete
            and support_confirmed
            and has_confirmed_counterevidence
            and not conflict_in_hypothesis
        )
        can_reject = (
            hypothesis["test_result"] == "CONTRADICTS"
            and test_complete
            and support_confirmed
            and has_confirmed_counterevidence
            and not conflict_in_hypothesis
        )
        if can_confirm:
            confirmed.append(hypothesis)
            disposition = "CONFIRMED"
            add_check("HYPOTHESIS:" + hypothesis["hypothesis_id"], "PASS",
                      "Supporting and contradicting evidence are traceable and a discriminating test confirms the hypothesis.")
        elif can_reject:
            rejected.append(hypothesis)
            disposition = "REJECTED"
            add_check("HYPOTHESIS:" + hypothesis["hypothesis_id"], "PASS",
                      "A discriminating test contradicted the hypothesis; it is not promoted as root cause.")
        else:
            disposition = "HYPOTHESIS_ONLY"
            detail = "Missing confirmed evidence/test output, insufficient counterevidence, or UNKNOWN/CONFLICT evidence blocks confirmation."
            add_check("HYPOTHESIS:" + hypothesis["hypothesis_id"], "UNKNOWN", detail)
            warnings.append(f"HYPOTHESIS_NOT_CONFIRMED:{hypothesis['hypothesis_id']}")
        hypotheses_evaluated.append({
            "hypothesis_id": hypothesis["hypothesis_id"],
            "disposition": disposition,
            "test_result": hypothesis["test_result"],
            "supporting_evidence_ids": support_ids,
            "contradicting_evidence_ids": contradict_ids,
        })

    if len(confirmed) > 1:
        status = "CONFLICT"
        root_status = "CONFLICT"
        chosen = None
        classification = None
        supporting_refs: list[str] = []
        contradicting_refs: list[str] = []
        add_check("SINGLE_ROOT_CAUSE", "FAIL", "More than one hypothesis passed its discriminating test; reconcile the competing explanations.")
        warnings.append("MULTIPLE_CONFIRMED_HYPOTHESES_REQUIRE_RECONCILIATION")
        next_action = "Compare the competing confirmed mechanisms and design a discriminating test that separates them; do not distill a reusable rule yet."
    elif len(confirmed) == 1:
        chosen_hypothesis = confirmed[0]
        chosen = chosen_hypothesis["hypothesis_id"]
        status = "CONFIRMED"
        root_status = "CONFIRMED"
        supporting_refs = [evidence_by_id[x]["source_ref"] for x in chosen_hypothesis["supporting_evidence_ids"]]
        contradicting_refs = [evidence_by_id[x]["source_ref"] for x in chosen_hypothesis["contradicting_evidence_ids"]]
        scope = request["affected_scope"]
        recurrence = request["recurrence_count"]
        target_count = len(set(request["target_paths"]))
        classification = None
        if scope == "SINGLE_OUTPUT" and request["explicit_one_off"] and recurrence <= 1:
            classification = "ONE_OFF"
        elif scope in {"SINGLE_MODULE", "SUBSYSTEM"} and (recurrence >= 2 or target_count >= 2):
            classification = "LOCAL_RULE"
        elif scope == "MULTI_DOMAIN" and (recurrence >= 2 or target_count >= 2):
            classification = "SYSTEMIC_CAPABILITY"
        elif scope == "AUTHORITY_BOUNDARY":
            classification = "ARCHITECTURE_INVARIANT"
        add_check("SINGLE_ROOT_CAUSE", "PASS", "Exactly one hypothesis passed the discriminating test and evidence gate.")
        if classification is None:
            warnings.append("REUSE_CLASSIFICATION_NOT_YET_SUPPORTED")
        next_action = (
            "Pass the confirmed evidence and scope classification to the existing F28 change-classification/Governance route; this function does not change the blueprint."
            if classification is not None else
            "Keep the confirmed cause local; obtain recurrence/scope evidence before promoting it to a reusable rule."
        )
    elif len(rejected) == len(hypotheses):
        status = "REJECTED"
        root_status = "REJECTED"
        chosen = None
        classification = None
        supporting_refs = []
        contradicting_refs = []
        add_check("SINGLE_ROOT_CAUSE", "FAIL", "Every supplied hypothesis was contradicted by its discriminating test.")
        next_action = "Return to diagnosis and create a new bounded hypothesis set; do not promote any rejected cause."
    else:
        status = "HYPOTHESIS_ONLY"
        root_status = "HYPOTHESIS"
        chosen = None
        classification = None
        supporting_refs = []
        contradicting_refs = []
        add_check("SINGLE_ROOT_CAUSE", "UNKNOWN", "No unique hypothesis has sufficient supporting/contradicting evidence and a confirming discriminating test.")
        next_action = "Gather supporting and contradicting evidence and execute a discriminating test before marking root cause CONFIRMED."

    scope_payload = {
        "failure_id": request["failure_id"],
        "target_scope_ref": request["target_scope_ref"],
        "affected_scope": request["affected_scope"],
        "target_paths": sorted(set(request["target_paths"])),
        "source_revision": request["source_revision"],
    }
    scope_fingerprint = _digest(scope_payload)
    evidence_fingerprint = _digest(request)
    prior_scope = request["prior_scope_fingerprint"]
    has_prior = bool(request["prior_downstream_evidence_refs"])
    scope_changed = prior_scope is not None and prior_scope != scope_fingerprint
    missing_prior_binding = has_prior and prior_scope is None
    invalidate = scope_changed or missing_prior_binding or request["repair_outcome"] == "FAIL"
    invalidated_refs = list(request["prior_downstream_evidence_refs"]) if invalidate else []
    retest_required = scope_changed or missing_prior_binding or request["repair_outcome"] == "FAIL"
    if scope_changed:
        warnings.append("SCOPE_FINGERPRINT_CHANGED: prior downstream evidence is invalidated.")
    if missing_prior_binding:
        warnings.append("PRIOR_EVIDENCE_UNBOUND: old downstream evidence has no scope fingerprint and is invalidated.")
    if request["repair_outcome"] == "FAIL":
        warnings.append("REPAIR_FAILED: dependent verification evidence is invalidated and a retest is required.")
    governance_required = request["affected_scope"] == "AUTHORITY_BOUNDARY"
    blueprint_eligible = (
        status == "CONFIRMED"
        and classification in {"LOCAL_RULE", "SYSTEMIC_CAPABILITY"}
    ) or (
        status == "CONFIRMED"
        and classification == "ARCHITECTURE_INVARIANT"
        and request["governance_approval"] is True
    )
    if governance_required and not request["governance_approval"]:
        blueprint_eligible = False
        warnings.append("GOVERNANCE_APPROVAL_REQUIRED_FOR_AUTHORITY_INVARIANT")

    result = {
        "request_id": request["request_id"],
        "failure_id": request["failure_id"],
        "status": status,
        "root_cause_status": root_status,
        "chosen_hypothesis_id": chosen,
        "classification_hint": classification,
        "supporting_evidence_refs": supporting_refs,
        "contradicting_evidence_refs": contradicting_refs,
        "scope_fingerprint": scope_fingerprint,
        "evidence_fingerprint": evidence_fingerprint,
        "scope_changed": scope_changed or missing_prior_binding,
        "invalidated_prior_evidence_refs": invalidated_refs,
        "retest_required": retest_required,
        "blueprint_update_eligible": blueprint_eligible,
        "governance_approval_required": governance_required,
        "checks": checks,
        "warnings": warnings,
        "next_action": next_action,
        "execution_authorized": False,
        "persistent_write": False,
    }
    _validate(result, DECISION_SCHEMA, root)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Distill root-cause hypotheses from explicit evidence and discriminating tests")
    parser.add_argument("--request", required=True)
    parser.add_argument("--output")
    parser.add_argument("--root", default=str(ROOT))
    args = parser.parse_args()
    try:
        root = Path(args.root).resolve()
        request = json.loads(Path(args.request).read_text(encoding="utf-8"))
        decision = distill_root_cause(request, root)
        rendered = json.dumps(decision, ensure_ascii=False, indent=2) + "\n"
        if args.output:
            Path(args.output).write_text(rendered, encoding="utf-8")
        print(rendered, end="")
        return 0 if decision["status"] == "CONFIRMED" else 2
    except (OSError, json.JSONDecodeError, RootCauseDistillationError) as exc:
        print(json.dumps({"status":"BLOCKED","reason_code":str(exc).split(":",1)[0],"detail":str(exc)},ensure_ascii=False,indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
