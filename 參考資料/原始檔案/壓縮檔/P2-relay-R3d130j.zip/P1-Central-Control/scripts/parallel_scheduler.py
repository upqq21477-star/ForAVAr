#!/usr/bin/env python3
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timedelta, timezone
from typing import Any

from packet_layer import build_attempt, build_task_packet


DEFAULT_POLICY = {
    "max_concurrency": 4,
    "default_timeout_ms": 300_000,
    "default_max_attempts": 1,
    "default_retry_on": ["FAIL"],
    "late_result_policy": "IGNORE_WITH_RECORD",
    "join_policy": "ALL_DEPENDENCIES_COMPLETE",
    # r16 ADOPTED deterministic policy（非由既有規則推導）：聚合終局結果時的嚴重度，最嚴重在前。
    "failure_precedence": ["FAIL", "TIMEOUT", "BLOCK", "UNRESOLVED"],
}


def load_policy(policy: dict[str, Any] | None = None) -> dict[str, Any]:
    result = deepcopy(DEFAULT_POLICY)
    if policy:
        result.update(deepcopy(policy))
    if not 1 <= int(result["max_concurrency"]) <= 32:
        raise ValueError("max_concurrency 必須為 1..32")
    if int(result["default_timeout_ms"]) < 1:
        raise ValueError("default_timeout_ms 必須 > 0")
    if not 1 <= int(result["default_max_attempts"]) <= 10:
        raise ValueError("default_max_attempts 必須為 1..10")
    allowed = {"FAIL", "TIMEOUT"}
    if not set(result["default_retry_on"]).issubset(allowed):
        raise ValueError("default_retry_on 含未知 decision")
    if result["late_result_policy"] not in {"IGNORE_WITH_RECORD", "REJECT"}:
        raise ValueError("late_result_policy 不合法")
    if result["join_policy"] != "ALL_DEPENDENCIES_COMPLETE":
        raise ValueError("目前只支援 ALL_DEPENDENCIES_COMPLETE")
    if sorted(result["failure_precedence"]) != sorted(["FAIL", "TIMEOUT", "BLOCK", "UNRESOLVED"]):
        raise ValueError("failure_precedence 必須恰為 FAIL/TIMEOUT/BLOCK/UNRESOLVED 的一個排列")
    return result


def _parse_ref(ref: str) -> str:
    if ":" in ref:
        prefix, value = ref.split(":", 1)
        if prefix == "SEGMENT":
            return value
    return ref


def dependency_ids(segment: dict[str, Any]) -> set[str]:
    refs = segment.get("dependency_refs", [])
    refs = list(refs) + list(segment.get("segment_dependencies", []))
    return {_parse_ref(ref) for ref in refs}


def _completed_ids(state: dict[str, Any]) -> set[str]:
    completed: set[str] = set()
    for item in state.get("completed_segments", []):
        if item.get("status") in {"VALID", "COMPLETED", "WORK_COMPLETE"}:
            completed.add(item["segment_id"])
    return completed


FAILED_DECISIONS = {"FAIL", "BLOCK", "UNRESOLVED", "TIMEOUT"}
# 非終態、非失敗：不觸發 retry、不擋依賴；等待 Brain 裁決（見 brain_pending）。
BRAIN_DECISIONS = {"NEEDS_BRAIN"}

def void_ids(state: dict[str, Any]) -> set[str]:
    """U-6：已作廢的 segment（Task Set 被取代／無效、或 Brain 放棄）；不得排程、不入聚合。"""
    return {item["segment_id"] for item in state.get("void_segments", [])}


def final_segment_results(state: dict[str, Any]) -> dict[str, dict[str, Any]]:
    """每個 segment_id 只取最後一筆終局結果（completed_segments 只收終局）；作廢者不計。"""
    void = void_ids(state)
    final: dict[str, dict[str, Any]] = {}
    for item in state.get("completed_segments", []):
        if item["segment_id"] not in void:
            final[item["segment_id"]] = item
    return final


def aggregate_decision(state: dict[str, Any], policy: dict[str, Any] | None = None) -> str | None:
    """全部 segment 皆 WORK_COMPLETE 才回 WORK_COMPLETE；否則回最嚴重的失敗碼。

    只依 completed_segments 的最終狀態計算，與結果到達順序無關（Q5 嚴格規則）。
    """
    precedence = load_policy(policy)["failure_precedence"]
    final = final_segment_results(state)
    if not final:
        return None
    codes = {item["decision_code"] for item in final.values()}
    for code in precedence:
        if code in codes:
            return "FAIL" if code == "TIMEOUT" else code
    if codes & BRAIN_DECISIONS:
        return sorted(codes & BRAIN_DECISIONS)[0]
    return "WORK_COMPLETE"


def brain_pending(state: dict[str, Any]) -> bool:
    """沒有 active、沒有可執行的 queued，且有 segment 停在等待 Brain 的結果。

    此時 workflow 已無法自行前進：queued 只剩依賴未完成者（依賴 NEEDS_BRAIN 的 segment）。
    """
    if state.get("active_segments"):
        return False
    if runnable_segments(state):
        return False
    return any(
        item["decision_code"] in BRAIN_DECISIONS
        for item in final_segment_results(state).values()
    )


def requeue_brain_pending(
    state: dict[str, Any],
    segment_store: dict[str, dict[str, Any]],
    only: set[str] | None = None,
) -> tuple[dict[str, Any], list[str]]:
    """Brain 裁決 REQUEUE：最後結果為 NEEDS_BRAIN 的 segment（only＝限定集合）重新排入，並多給一次 attempt。

    attempt 編號沿用 attempt_counters（attempt_id 不重複）；僅放寬該 segment 的 max_attempts 為「已用次數＋1」。
    Segment 定義取自外部 canonical segment_store（與 retry 相同，不從 bounded projection 重建）。
    """
    current = deepcopy(state)
    queued_ids = {item["segment_id"] for item in current.get("queued_segments", [])}
    requeued: list[str] = []
    for segment_id, item in sorted(final_segment_results(current).items()):
        if item["decision_code"] not in BRAIN_DECISIONS or segment_id in queued_ids:
            continue
        if only is not None and segment_id not in only:
            continue
        if segment_store is None or segment_id not in segment_store:
            raise ValueError("Brain RESUME 需要外部 canonical Segment store：" + segment_id)
        used = int(current.get("attempt_counters", {}).get(segment_id, 0))
        if used + 1 > 10:
            raise ValueError("BRAIN_RESUME_ATTEMPT_LIMIT:" + segment_id)
        segment = deepcopy(segment_store[segment_id])
        segment.setdefault("retry_policy", {})["max_attempts"] = used + 1
        current.setdefault("queued_segments", []).append(segment)
        requeued.append(segment_id)
    return current, requeued


def propagate_dependency_failure(state: dict[str, Any]) -> dict[str, Any]:
    """依賴終局失敗的 queued segment 不可能再執行：移出 queued，記入 blocked_segments。

    重複到不動點，使傳遞性依賴（C→B→A）一併處理。
    """
    current = deepcopy(state)
    while True:
        failed = {
            sid for sid, item in final_segment_results(current).items()
            if item["decision_code"] in FAILED_DECISIONS
        } | void_ids(current)
        blocked_now = [
            seg for seg in current.get("queued_segments", [])
            if dependency_ids(seg) & failed
        ]
        if not blocked_now:
            return current
        blocked_ids = {seg["segment_id"] for seg in blocked_now}
        current["queued_segments"] = [
            seg for seg in current["queued_segments"] if seg["segment_id"] not in blocked_ids
        ]
        record = current.setdefault("blocked_segments", [])
        for seg in blocked_now:
            record.append({
                "segment_id": seg["segment_id"],
                "blocked_by": sorted(dependency_ids(seg) & failed),
                "reason": "BLOCKED_BY_DEPENDENCY",
            })
        # 被擋住的 segment 對其下游而言等同失敗，納入下一輪傳遞。
        for seg in blocked_now:
            current.setdefault("completed_segments", []).append({
                "segment_id": seg["segment_id"],
                "attempt_id": None,
                "status": "BLOCKED_BY_DEPENDENCY",
                "decision_code": "BLOCK",
            })


def _active_ids(state: dict[str, Any]) -> set[str]:
    return {item["segment_id"] for item in state.get("active_segments", [])}


def runnable_segments(state: dict[str, Any]) -> list[dict[str, Any]]:
    completed = _completed_ids(state)
    active = _active_ids(state)
    void = void_ids(state)
    runnable = []
    for segment in state.get("queued_segments", []):
        if segment["segment_id"] in active or segment["segment_id"] in void:
            continue
        if dependency_ids(segment).issubset(completed):
            runnable.append(segment)
    return runnable


def _now(value: str | None) -> datetime:
    if value:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        return parsed
    return datetime.now(timezone.utc)


def _policy_for_segment(segment: dict[str, Any], policy: dict[str, Any]) -> tuple[int, list[str], int]:
    retry = segment.get("retry_policy", {})
    max_attempts = int(retry.get("max_attempts", policy["default_max_attempts"]))
    retry_on = list(retry.get("retry_on", policy["default_retry_on"]))
    timeout_ms = int(segment.get("timeout_ms", policy["default_timeout_ms"]))
    if not 1 <= max_attempts <= 10:
        raise ValueError("segment retry_policy.max_attempts 必須為 1..10")
    if timeout_ms < 1:
        raise ValueError("segment timeout_ms 必須 > 0")
    if not set(retry_on).issubset({"FAIL", "TIMEOUT"}):
        raise ValueError("segment retry_policy.retry_on 不合法")
    return max_attempts, retry_on, timeout_ms


def _next_attempt_number(state: dict[str, Any], segment_id: str) -> int:
    counters = state.setdefault("attempt_counters", {})
    number = int(counters.get(segment_id, 0)) + 1
    counters[segment_id] = number
    return number


def start_available(
    state: dict[str, Any],
    *,
    max_concurrency: int | None = None,
    now: str | None = None,
    policy: dict[str, Any] | None = None,
    include_attempts: bool = False,
) -> tuple:
    policy = load_policy(policy)
    limit = int(max_concurrency or state.get("scheduler_max_concurrency", policy["max_concurrency"]))
    if not 1 <= limit <= 32:
        raise ValueError("scheduler max_concurrency 必須為 1..32")

    current = deepcopy(state)
    current.setdefault("active_segments", [])
    current.setdefault("attempt_counters", {})
    current["scheduler_max_concurrency"] = limit

    available_slots = limit - len(current["active_segments"])
    if available_slots <= 0:
        return current, []

    started_at = _now(now)
    started_packets: list[dict[str, Any]] = []
    started_attempts: list[dict[str, Any]] = []
    queued = list(current.get("queued_segments", []))
    current["queued_segments"] = []

    active_ids = _active_ids(current)
    completed = _completed_ids(current)

    for segment in queued:
        if len(started_packets) >= available_slots:
            current["queued_segments"].append(segment)
            continue

        segment_id = segment["segment_id"]
        if segment_id in active_ids or segment_id in void_ids(current):
            current["queued_segments"].append(segment)
            continue

        if not dependency_ids(segment).issubset(completed):
            current["queued_segments"].append(segment)
            continue

        max_attempts, retry_on, timeout_ms = _policy_for_segment(segment, policy)
        next_number = int(current["attempt_counters"].get(segment_id, 0)) + 1
        if next_number > max_attempts:
            current.setdefault("completed_segments", []).append({
                "segment_id": segment_id,
                "attempt_id": None,
                "attempt_number": next_number,
                "status": "BLOCKED",
                "decision_code": "BLOCK",
                "reason_code": "ATTEMPT_LIMIT_EXCEEDED",
            })
            continue
        attempt_number = _next_attempt_number(current, segment_id)

        attempt = build_attempt(
            segment,
            attempt_number=attempt_number,
            started_at=started_at.isoformat(),
        )
        timeout_at = started_at + timedelta(milliseconds=timeout_ms)
        attempt["timeout_at"] = timeout_at.isoformat()
        attempt["max_attempts"] = max_attempts
        attempt["retry_on"] = retry_on
        packet = build_task_packet(segment, attempt)

        current["active_segments"].append({
            "segment_id": segment_id,
            "attempt_id": attempt["attempt_id"],
            "attempt_number": attempt_number,
            "task_packet_ref": packet["object_id"],
            "skill_id": packet["skill_id"],
            "skill_version": packet["skill_version"],
            "started_at": attempt["started_at"],
            "timeout_at": attempt["timeout_at"],
            "max_attempts": max_attempts,
            "retry_on": retry_on,
            "status": "RUNNING",
        })
        started_packets.append(packet)
        started_attempts.append(attempt)
        active_ids.add(segment_id)

    current["scheduler_max_concurrency"] = limit
    if include_attempts:
        return current, started_packets, started_attempts
    return current, started_packets


def _find_active(state: dict[str, Any], *, segment_id: str | None = None, attempt_id: str | None = None) -> dict[str, Any] | None:
    for item in state.get("active_segments", []):
        if segment_id is not None and item["segment_id"] == segment_id:
            return item
        if attempt_id is not None and item["attempt_id"] == attempt_id:
            return item
    return None


def _remove_active(state: dict[str, Any], attempt_id: str) -> None:
    state["active_segments"] = [
        item for item in state.get("active_segments", [])
        if item["attempt_id"] != attempt_id
    ]


def _find_queued(state: dict[str, Any], segment_id: str) -> dict[str, Any] | None:
    for item in state.get("queued_segments", []):
        if item["segment_id"] == segment_id:
            return item
    return None


def accept_result(
    state: dict[str, Any],
    result: dict[str, Any],
    *,
    segment_store: dict[str, dict[str, Any]] | None = None,
    policy: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], str]:
    policy = load_policy(policy)
    current = deepcopy(state)
    active = _find_active(
        current,
        segment_id=result["segment_id"],
        attempt_id=result["attempt_id"],
    )

    if active is None:
        current["late_result_count"] = int(current.get("late_result_count", 0)) + 1
        if policy["late_result_policy"] == "REJECT":
            raise ValueError("ResultPacket 已晚到或 attempt 已不再 active")
        return current, "LATE_RESULT"

    if active["attempt_id"] != result["attempt_id"]:
        raise ValueError("ResultPacket attempt_id 與 active segment 不匹配")

    decision = result["decision_code"]
    _remove_active(current, active["attempt_id"])

    completed = {
        "segment_id": result["segment_id"],
        "attempt_id": result["attempt_id"],
        "result_id": result["result_id"],
        "skill_id": result["skill_id"],
        "status": result["status"],
        "decision_code": decision,
    }

    if decision == "WORK_COMPLETE":
        current.setdefault("completed_segments", []).append(completed)
        return current, "COMPLETED"

    retry_allowed = (
        decision in active["retry_on"]
        and active["attempt_number"] < active["max_attempts"]
    )

    if retry_allowed:
        if segment_store is None or result["segment_id"] not in segment_store:
            raise ValueError(
                "Retry 需要外部 canonical Segment store；禁止從 bounded active projection 重建完整 Segment"
            )
        segment = deepcopy(segment_store[result["segment_id"]])
        current.setdefault("queued_segments", []).append(segment)
        current["retry_count"] = int(current.get("retry_count", 0)) + 1
        return current, "RETRY_PENDING"

    current.setdefault("completed_segments", []).append(completed)
    if decision in BRAIN_DECISIONS:
        return current, "NEEDS_BRAIN"
    return current, "FAILED" if decision == "FAIL" else "BLOCKED"


def timeout_due(
    state: dict[str, Any],
    *,
    segment_store: dict[str, dict[str, Any]] | None = None,
    now: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    current = deepcopy(state)
    current.setdefault("active_segments", [])
    current.setdefault("queued_segments", [])
    current.setdefault("timeout_count", 0)
    check_time = _now(now)
    timed_out: list[dict[str, Any]] = []

    for active in list(current["active_segments"]):
        deadline = datetime.fromisoformat(active["timeout_at"].replace("Z", "+00:00"))
        if deadline > check_time:
            continue

        _remove_active(current, active["attempt_id"])
        current["timeout_count"] += 1
        timed_out.append(deepcopy(active))

        if active["attempt_number"] < active["max_attempts"] and "TIMEOUT" in active["retry_on"]:
            if segment_store is None or active["segment_id"] not in segment_store:
                raise ValueError(
                    "Timeout retry 需要外部 canonical Segment store"
                )
            current.setdefault("queued_segments", []).append(
                deepcopy(segment_store[active["segment_id"]])
            )
            current["retry_count"] = int(current.get("retry_count", 0)) + 1
        else:
            current.setdefault("completed_segments", []).append({
                "segment_id": active["segment_id"],
                "attempt_id": active["attempt_id"],
                "status": "TIMEOUT",
                "decision_code": "TIMEOUT",
            })

    return current, timed_out


def cancel_segment(
    state: dict[str, Any],
    segment_id: str,
    *,
    reason: str = "CANCELLED_BY_COMMAND",
) -> tuple[dict[str, Any], str]:
    current = deepcopy(state)

    queued = [item for item in current.get("queued_segments", []) if item["segment_id"] != segment_id]
    removed_queued = len(queued) != len(current.get("queued_segments", []))
    current["queued_segments"] = queued

    active = _find_active(current, segment_id=segment_id)
    if active is not None:
        _remove_active(current, active["attempt_id"])

    if removed_queued or active is not None:
        current["cancel_count"] = int(current.get("cancel_count", 0)) + 1
        current["last_cancelled_segment_id"] = segment_id
        current["last_cancel_reason"] = reason
        return current, "CANCELLED"

    return current, "NOT_FOUND"
