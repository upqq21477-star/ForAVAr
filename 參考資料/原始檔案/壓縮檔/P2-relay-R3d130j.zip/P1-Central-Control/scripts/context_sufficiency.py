#!/usr/bin/env python3
"""Determine whether a bounded context is executable, retrievable, oversized, or corrupted."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/context_sufficiency.schema.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any]) -> None:
    schema = _load(SCHEMA)
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def execute(
    *,
    gate_id: str,
    required_refs: list[str],
    available_refs: list[str],
    stale_refs: list[str] | None = None,
    conflict_refs: list[str] | None = None,
    estimated_total_context: int,
    target_context_budget: int,
    hard_context_ceiling: int,
) -> dict[str, Any]:
    required = set(required_refs)
    available = set(available_refs)
    stale = set(stale_refs or [])
    conflicts = set(conflict_refs or [])
    missing = sorted(required - available)
    status = "SUFFICIENT"
    action = "EXECUTE"
    reasons: list[str] = ["ALL_REQUIRED_REFS_AVAILABLE"]

    if target_context_budget >= hard_context_ceiling:
        raise ValueError("target_context_budget must be lower than hard_context_ceiling")

    if conflicts or (stale & required):
        status = "CORRUPTED"
        action = "RECONCILE_OR_BLOCK"
        reasons = ["STALE_OR_CONFLICT_REQUIRED_CONTEXT"]
    elif estimated_total_context > hard_context_ceiling:
        status = "OVERSIZED"
        action = "TRIM_OR_SPLIT"
        reasons = ["HARD_CONTEXT_CEILING_EXCEEDED"]
    elif missing:
        status = "INSUFFICIENT"
        action = "TARGETED_RETRIEVAL"
        reasons = ["REQUIRED_REFS_MISSING"]
    elif estimated_total_context > target_context_budget:
        status = "OVERSIZED"
        action = "TRIM_OR_SPLIT"
        reasons = ["TARGET_CONTEXT_BUDGET_EXCEEDED"]

    result = {
        "schema_version": "1.0",
        "gate_id": gate_id,
        "status": status,
        "action": action,
        "missing_refs": missing,
        "stale_refs": sorted(stale),
        "conflict_refs": sorted(conflicts),
        "required_ref_count": len(required),
        "available_ref_count": len(available),
        "estimated_total_context": estimated_total_context,
        "target_context_budget": target_context_budget,
        "hard_context_ceiling": hard_context_ceiling,
        "reason_codes": reasons,
    }
    _validate(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Evaluate context sufficiency")
    parser.add_argument("request")
    args = parser.parse_args()
    value = _load(Path(args.request).resolve())
    result = execute(**value)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] != "CORRUPTED" else 3


if __name__ == "__main__":
    raise SystemExit(main())
