#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[2]
CONTRACT_PATH = ROOT / "P1-Central-Control/state/state_transition_contract.v1.json"

ACCEPTED = "APPLIED"
REPLAY = "IDEMPOTENT_REPLAY"
REJECTED = "REJECTED"


def load_contract(path: Path = CONTRACT_PATH) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _transition_map(contract: dict[str, Any]) -> dict[tuple[str, str, str], str]:
    result: dict[tuple[str, str, str], str] = {}
    for item in contract["transitions"]:
        key = (
            item["aggregate_type"],
            item["from_status"],
            item["command_type"],
        )
        if key in result:
            raise ValueError(f"duplicate transition: {key}")
        result[key] = item["to_status"]
    return result


def validate_contract(contract: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    states = contract.get("states", {})
    terminal = contract.get("terminal_states", {})

    for aggregate_type, allowed_states in states.items():
        if len(allowed_states) != len(set(allowed_states)):
            errors.append(f"duplicate_state:{aggregate_type}")
        terminal_states = terminal.get(aggregate_type, [])
        unknown_terminal = sorted(set(terminal_states) - set(allowed_states))
        if unknown_terminal:
            errors.append(
                f"terminal_state_not_declared:{aggregate_type}:{','.join(unknown_terminal)}"
            )

    for item in contract.get("transitions", []):
        aggregate_type = item["aggregate_type"]
        from_status = item["from_status"]
        to_status = item["to_status"]
        if aggregate_type not in states:
            errors.append(f"unknown_aggregate_type:{aggregate_type}")
            continue
        if from_status not in states[aggregate_type]:
            errors.append(f"unknown_from_status:{aggregate_type}:{from_status}")
        if to_status not in states[aggregate_type]:
            errors.append(f"unknown_to_status:{aggregate_type}:{to_status}")

    try:
        _transition_map(contract)
    except ValueError as exc:
        errors.append(str(exc))

    return errors


def command_fingerprint(command: dict[str, Any]) -> str:
    semantic = {
        key: value
        for key, value in command.items()
        if key not in {"command_id", "issued_at"}
    }
    canonical = json.dumps(
        semantic,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(canonical).hexdigest()


def _result(
    status: str,
    reason: str,
    before: dict[str, Any],
    after: dict[str, Any],
    command: dict[str, Any],
    *,
    to_status: str | None = None,
) -> dict[str, Any]:
    transition = None
    if to_status is not None:
        transition = {
            "aggregate_type": command["aggregate_type"],
            "from_status": before["status"],
            "command_type": command["command_type"],
            "to_status": to_status,
        }

    return {
        "status": status,
        "reason": reason,
        "command_id": command["command_id"],
        "aggregate_id": command["aggregate_id"],
        "command": copy.deepcopy(command),
        "command_fingerprint": command_fingerprint(command),
        "state_before": before,
        "state_after": after,
        "transition": transition,
    }


def apply_transition(
    state: dict[str, Any],
    command: dict[str, Any],
    contract: dict[str, Any] | None = None,
) -> dict[str, Any]:
    contract = contract or load_contract()

    contract_errors = validate_contract(contract)
    if contract_errors:
        raise ValueError("invalid transition contract: " + "; ".join(contract_errors))

    before = copy.deepcopy(state)
    after = copy.deepcopy(state)

    if state.get("aggregate_type") != command.get("aggregate_type"):
        return _result(
            REJECTED,
            "AGGREGATE_TYPE_MISMATCH",
            before,
            before,
            command,
        )

    if state.get("aggregate_id") != command.get("aggregate_id"):
        return _result(
            REJECTED,
            "AGGREGATE_ID_MISMATCH",
            before,
            before,
            command,
        )

    fingerprint = command_fingerprint(command)

    last_idempotency_key = state.get("last_idempotency_key")
    if last_idempotency_key == command.get("idempotency_key"):
        if state.get("last_command_fingerprint") == fingerprint:
            return _result(
                REPLAY,
                "DUPLICATE_IDEMPOTENCY_KEY",
                before,
                before,
                command,
                to_status=state["status"],
            )
        return _result(
            REJECTED,
            "IDEMPOTENCY_KEY_CONFLICT",
            before,
            before,
            command,
        )

    if state.get("last_command_id") == command["command_id"]:
        if state.get("last_command_fingerprint") == fingerprint:
            return _result(
                REPLAY,
                "DUPLICATE_COMMAND_ID",
                before,
                before,
                command,
                to_status=state["status"],
            )
        return _result(
            REJECTED,
            "COMMAND_ID_CONFLICT",
            before,
            before,
            command,
        )

    expected_revision = command["expected_state_revision"]
    actual_revision = state["state_revision"]
    if expected_revision != actual_revision:
        return _result(
            REJECTED,
            "STATE_REVISION_CONFLICT",
            before,
            before,
            command,
        )

    terminal_states = set(contract["terminal_states"][state["aggregate_type"]])
    if state["status"] in terminal_states:
        return _result(
            REJECTED,
            "TERMINAL_STATE",
            before,
            before,
            command,
        )

    key = (
        command["aggregate_type"],
        state["status"],
        command["command_type"],
    )
    transitions = _transition_map(contract)
    to_status = transitions.get(key)
    if to_status is None:
        return _result(
            REJECTED,
            "INVALID_TRANSITION",
            before,
            before,
            command,
        )

    after["status"] = to_status
    after["state_revision"] = actual_revision + 1
    after["last_command_id"] = command["command_id"]
    after["last_idempotency_key"] = command["idempotency_key"]
    after["last_command_fingerprint"] = fingerprint

    return _result(
        ACCEPTED,
        "TRANSITION_APPLIED",
        before,
        after,
        command,
        to_status=to_status,
    )


def transition_event(result: dict[str, Any]) -> dict[str, Any] | None:
    if result["status"] != ACCEPTED:
        return None

    after = result["state_after"]
    transition = result["transition"]
    return {
        "event_type": "STATE_TRANSITION_APPLIED",
        "aggregate_id": result["aggregate_id"],
        "aggregate_type": transition["aggregate_type"],
        "revision": after["state_revision"],
        "command_id": result["command_id"],
        "from_status": transition["from_status"],
        "to_status": transition["to_status"],
    }


if __name__ == "__main__":
    contract = load_contract()
    errors = validate_contract(contract)
    print(json.dumps({
        "status": "PASS" if not errors else "BLOCK",
        "transition_count": len(contract.get("transitions", [])),
        "contract_errors": errors,
    }, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not errors else 3)
