"""G2 (S2): append-only JSONL run journal with a hash chain (stdlib). Reads are UNTRUSTED and always re-verified.
A damaged LAST line is dropped with a warning (torn write); damage anywhere earlier is JournalCorrupt (never auto-repaired).
read_journal is pure. Only a lock-holding Journal writes (tail repair happens lazily on its first append)."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any

try:
    import fcntl
except ImportError:  # non-POSIX: no single-writer lock (HYPOTHESIS)
    fcntl = None  # type: ignore[assignment]

ZERO = "0" * 64


class JournalError(Exception):
    pass


class JournalLocked(JournalError):
    pass


class JournalWriteError(JournalError):
    pass


class JournalCorrupt(JournalError):
    def __init__(self, line: int, why: str) -> None:
        super().__init__(f"line {line}: {why}")
        self.line, self.why = line, why


def _h(body: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(body, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def read_journal(path: str | Path) -> tuple[list[dict[str, Any]], list[str], int]:
    """-> (records, warnings, good_bytes). Never writes."""
    p = Path(path)
    raw = p.read_bytes() if p.exists() else b""
    complete = raw.endswith(b"\n")
    lines = raw.split(b"\n")
    if lines and lines[-1] == b"":
        lines.pop()
    recs: list[dict[str, Any]] = []
    warns: list[str] = []
    prev, good = ZERO, 0
    for i, ln in enumerate(lines, 1):
        last = i == len(lines)
        try:
            if last and not complete:
                raise ValueError("no newline")
            r = json.loads(ln.decode("utf-8"))
            body = {k: v for k, v in r.items() if k != "hash"}
            if r.get("seq") != i or r.get("prev") != prev or r.get("hash") != _h(body):
                raise ValueError("chain")
        except (ValueError, UnicodeDecodeError, AttributeError) as e:
            if last:
                warns.append(f"TAIL_TRUNCATED:{i}")
                break
            raise JournalCorrupt(i, str(e)) from None
        recs.append(r)
        prev, good = r["hash"], good + len(ln) + 1
    return recs, warns, good


class Journal:
    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)
        self._lock_fd, self._fd, self._closed = None, None, False
        if not os.access(self.path.parent, os.W_OK):
            raise JournalError("JOURNAL_DIR_UNWRITABLE")
        self._lock()
        try:
            self.records, self.warnings, self._good = read_journal(self.path)
        except BaseException:
            self.close()
            raise
        self._dirty = bool(self.warnings)

    def _lock(self) -> None:
        if fcntl is None:
            return
        fd = os.open(str(self.path) + ".lock", os.O_CREAT | os.O_RDWR, 0o644)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            os.close(fd)
            raise JournalLocked("JOURNAL_LOCKED") from None
        self._lock_fd = fd

    @property
    def last_seq(self) -> int:
        return len(self.records)

    @property
    def closed(self) -> bool:
        return any(r["kind"] == "closed" for r in self.records)

    def append(self, kind: str, payload: Any) -> dict[str, Any]:
        if self._closed:
            raise JournalError("JOURNAL_CLOSED")
        body = {"kind": kind, "seq": len(self.records) + 1,
                "payload": json.loads(json.dumps(payload, default=str, ensure_ascii=False)),
                "prev": self.records[-1]["hash"] if self.records else ZERO}
        rec = {**body, "hash": _h(body)}
        data = (json.dumps(rec, sort_keys=True, ensure_ascii=False) + "\n").encode("utf-8")
        try:
            if self._fd is None:
                self._fd = os.open(str(self.path), os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o644)
            if self._dirty:
                os.ftruncate(self._fd, self._good)
                self._dirty = False
            os.write(self._fd, data)
            os.fsync(self._fd)
        except OSError as e:
            self._dirty = True  # a partial or unsynced line may exist; the next append truncates back to the last good byte
            raise JournalWriteError(str(e)) from None
        self.records.append(rec)
        self._good += len(data)
        return rec

    def close(self) -> None:
        self._closed = True
        for name in ("_fd", "_lock_fd"):
            fd = getattr(self, name, None)
            if fd is not None:
                try:
                    os.close(fd)
                except OSError:
                    pass
                setattr(self, name, None)
