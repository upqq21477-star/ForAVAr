#!/usr/bin/env python3
"""Content-addressed head for acceptance: no git, no network.

`code_digest(root)` hashes every file under the code scope (scripts, schemas, policy, tests),
so acceptance binds to the code it actually ran against. State files that a close rewrites
(Current / Work / Construction / acceptance context) are outside the scope on purpose.
"""
from __future__ import annotations

import hashlib
import sys
from pathlib import Path

SCOPE = ("scripts", "schemas", "policy", "tests")
BASE = "NO_BASE"


def code_digest(root: Path) -> str:
    base = Path(root) / "P1-Central-Control"
    lines = []
    for scope in SCOPE:
        for path in sorted((base / scope).rglob("*")):
            if not path.is_file() or "__pycache__" in path.parts or path.suffix == ".pyc":
                continue
            rel = path.relative_to(base).as_posix()
            lines.append(f"{rel}\0{hashlib.sha256(path.read_bytes()).hexdigest()}\n")
    return "code:" + hashlib.sha256("".join(lines).encode("utf-8")).hexdigest()[:40]


if __name__ == "__main__":
    print(code_digest(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parents[2]))
