#!/usr/bin/env python3
"""Conversation Analysis Report CLI (kept out of Central: Central handles refs, not report semantics)."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from conversation_analysis_report import render, validate


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("respond").add_argument("analysis_report")
    render_cmd = sub.add_parser("render-analysis-report")
    render_cmd.add_argument("analysis_report")
    render_cmd.add_argument("output")
    args = parser.parse_args()

    report = json.loads(Path(args.analysis_report).read_text(encoding="utf-8"))
    result = validate(report)
    if args.command == "respond":
        if result["status"] != "PASS" or report.get("stage") != "RESPONSE_READY":
            raise ValueError("Conversation Analysis Report 尚未達 RESPONSE_READY；禁止直接建立使用者回覆")
        view = report["response_view"]
        print(json.dumps({
            "status": "PASS",
            "report_id": report["report_id"],
            "stage": report["stage"],
            "response_mode": report["response_mode"],
            "key_points": view["key_points"],
            "answer": view["answer"],
            "support_refs": view["support_refs"],
        }, ensure_ascii=False, indent=2))
        return 0
    if result["status"] != "PASS":
        raise ValueError("Conversation Analysis Report 驗證失敗: " + "；".join(result["errors"]))
    Path(args.output).write_text(render(report), encoding="utf-8")
    print(json.dumps({"status": "PASS", "output": args.output}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
