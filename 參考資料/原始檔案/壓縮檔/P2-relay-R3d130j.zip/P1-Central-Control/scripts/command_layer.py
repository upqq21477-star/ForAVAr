#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from event_log import EventLog
from state_machine_runtime_gate import initialize_workflow_control, transition_workflow_command
from state_transition import ACCEPTED, REPLAY, REJECTED
from task_set import stale_task_ids


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
COMMAND_SCHEMA_PATH = SCHEMA_DIR / "command.schema.json"
RESULT_SCHEMA_PATH = SCHEMA_DIR / "command_result.schema.json"


# Implementation-level executable allowlist. This is not a canonical registry.
TRUSTED_EXECUTABLE_ACTION_TYPES = frozenset({"RUN_REPOSITORY_TESTS"})


def admit_executable_action(action: dict[str, Any]) -> dict[str, Any]:
    """Admit a typed executable action before any runtime side effect."""
    if not isinstance(action, dict):
        raise ValueError("TYPED_ACTION_REQUIRED")
    if "argv" in action:
        raise ValueError("ARBITRARY_ARGV_BLOCKED")
    if set(action) != {"command_type", "args"}:
        raise ValueError("TYPED_ACTION_SHAPE_INVALID")
    command_type = action.get("command_type")
    if command_type not in TRUSTED_EXECUTABLE_ACTION_TYPES:
        raise ValueError("UNKNOWN_COMMAND_TYPE")
    if not isinstance(action.get("args"), dict):
        raise ValueError("TYPED_ARGS_INVALID")
    return deepcopy(action)


def _schema_registry() -> Registry:
    registry = Registry()
    for path in (
        SCHEMA_DIR / "canonical_identity.schema.json",
        SCHEMA_DIR / "canonical_common.schema.json",
        COMMAND_SCHEMA_PATH,
        RESULT_SCHEMA_PATH,
    ):
        schema = json.loads(path.read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"],
            Resource.from_contents(schema),
        )
    return registry


def _validator(path: Path) -> Draft202012Validator:
    schema = json.loads(path.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(
        schema,
        registry=_schema_registry(),
        format_checker=FormatChecker(),
    )


def validate_command(command: dict[str, Any]) -> None:
    errors = sorted(
        _validator(COMMAND_SCHEMA_PATH).iter_errors(command),
        key=lambda item: list(item.path),
    )
    if errors:
        raise ValueError(
            "Command Schema 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def validate_result(result: dict[str, Any]) -> None:
    errors = sorted(
        _validator(RESULT_SCHEMA_PATH).iter_errors(result),
        key=lambda item: list(item.path),
    )
    if errors:
        raise ValueError(
            "Command Result Schema 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def build_command(
    state: dict[str, Any],
    command_type: str,
    *,
    command_id: str | None = None,
    idempotency_key: str | None = None,
    caused_by: str | None = None,
    actor_id: str = "COMMANDER",
    correlation_id: str | None = None,
    issued_at: str | None = None,
) -> dict[str, Any]:
    workflow_id = state["workflow_id"]
    revision = state["state_revision"]
    deterministic_id = command_id or f"CMD:{workflow_id}:r{revision}:{command_type}"
    command = {
        "command_id": deterministic_id,
        "command_type": command_type,
        "aggregate_type": "WORKFLOW",
        "workflow_id": workflow_id,
        "target_id": workflow_id,
        "expected_state_revision": revision,
        "idempotency_key": idempotency_key or deterministic_id,
        "caused_by": caused_by,
        "issued_at": issued_at or datetime.now(timezone.utc).isoformat(),
        "actor_id": actor_id,
        "correlation_id": correlation_id or f"CORR:{workflow_id}",
    }
    validate_command(command)
    return command


def task_admission_errors(state: dict[str, Any], command: dict[str, Any]) -> list[str]:
    """CH-PLAN-TASK-COMMAND：命令目標是已作廢（SUPERSEDED／INVALID）的 task 時回 TARGET_TASK_STALE（純函式；不改 execute_command）。"""
    return ["TARGET_TASK_STALE"] if command.get("target_id") in set(stale_task_ids(state)) else []


def _next_action(status: str, *, has_queued_work: bool = False) -> str:
    if status in {"COMPLETED", "FAILED", "CANCELLED", "BLOCKED"}:
        return "WORKFLOW_TERMINAL" if status != "BLOCKED" else "REPLAN_REQUIRED"
    if status == "WAITING":
        return "WAIT_FOR_RESULT"
    if status in {"READY", "RUNNING"}:
        return "DISPATCH_READY" if has_queued_work else "NONE"
    return "NONE"


def execute_command(
    state: dict[str, Any],
    command: dict[str, Any],
    *,
    event_log: EventLog,
    has_queued_work: bool = False,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """INPUT → CHECK → ACTION → EVENT → OUTPUT → NEXT。"""
    validate_command(command)

    check_errors: list[str] = []
    if command["aggregate_type"] != "WORKFLOW":
        check_errors.append("UNSUPPORTED_AGGREGATE_TYPE")
    if command["workflow_id"] != state.get("workflow_id"):
        check_errors.append("WORKFLOW_ID_MISMATCH")
    if command["target_id"] != state.get("workflow_id"):
        check_errors.append("TARGET_ID_MISMATCH")

    # Idempotent retry is allowed to reach the authoritative reducer even
    # when its original expected revision is stale. The reducer distinguishes
    # replay from idempotency conflict.
    is_idempotent_retry = (
        command["idempotency_key"] == state.get("last_idempotency_key")
    )
    if (
        command["expected_state_revision"] != state.get("state_revision")
        and not is_idempotent_retry
    ):
        check_errors.append("EXPECTED_REVISION_MISMATCH")

    if check_errors:
        result = {
            "status": REJECTED,
            "command_id": command["command_id"],
            "check": {"status": "BLOCK", "errors": check_errors},
            "action": {"status": "NOT_EXECUTED", "reason": "COMMAND_CHECK_BLOCKED"},
            "event": None,
            "output": {
                "status": state["status"],
                "state_revision": state["state_revision"],
            },
            "next": _next_action(
                state["status"],
                has_queued_work=has_queued_work,
            ),
        }
        validate_result(result)
        return deepcopy(state), result

    updated, transition_result = transition_workflow_command(
        state,
        command,
        event_log=event_log,
    )

    if transition_result["status"] == ACCEPTED:
        status = ACCEPTED
        event = updated.get("last_transition")
    elif transition_result["status"] == REPLAY:
        status = REPLAY
        event = None
    else:
        status = REJECTED
        event = None

    result = {
        "status": status,
        "command_id": command["command_id"],
        "check": {"status": "PASS", "errors": []},
        "action": {
            "status": transition_result["status"],
            "reason": transition_result["reason"],
        },
        "event": event,
        "output": {
            "status": updated["status"],
            "state_revision": updated["state_revision"],
        },
        "next": _next_action(
            updated["status"],
            has_queued_work=has_queued_work,
        ),
    }
    validate_result(result)
    return updated, result


def result_command_types(
    state: dict[str, Any],
    decision_code: str,
    *,
    has_queued_work: bool,
    has_active_work: bool = False,
) -> list[str]:
    if state["status"] not in {"RUNNING", "WAITING"}:
        raise ValueError(
            f"只有執行中的 Workflow 可以接收 ResultPacket；目前為 {state['status']}"
        )

    route = _result_routes().get(decision_code)
    if route is None:
        raise ValueError(f"未知 ResultPacket decision_code: {decision_code}")
    if has_queued_work or has_active_work:
        return list(route["work_remains"])
    return list(route["idle"][state["status"]])


def result_terminal_state(decision_code: str) -> str | None:
    route = _result_routes().get(decision_code)
    if route is None:
        raise ValueError(f"未知 ResultPacket decision_code: {decision_code}")
    return route["terminal_state"]


_RESULT_ROUTES: dict[str, Any] | None = None


def _result_routes() -> dict[str, Any]:
    """路由表資料化：policy/result_routing.v1.0.json（只查表，無語義分支）。"""
    global _RESULT_ROUTES
    if _RESULT_ROUTES is None:
        path = ROOT / "P1-Central-Control" / "policy" / "result_routing.v1.0.json"
        _RESULT_ROUTES = json.loads(path.read_text(encoding="utf-8"))["routes"]
    return _RESULT_ROUTES


def execute_command_sequence(
    state: dict[str, Any],
    command_types: list[str],
    *,
    event_log: EventLog,
    caused_by: str | None = None,
    correlation_id: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    current = deepcopy(state)
    results: list[dict[str, Any]] = []
    for command_type in command_types:
        command = build_command(
            current,
            command_type,
            caused_by=caused_by,
            correlation_id=correlation_id,
        )
        current, result = execute_command(
            current,
            command,
            event_log=event_log,
            has_queued_work=bool(current.get("queued_segments")),
        )
        results.append(result)
        if result["status"] == REJECTED:
            raise ValueError(
                f"Command Sequence 被拒絕: {command_type} / {result['action']['reason']}"
            )
    return current, results


def initialize_command_state(workflow_id: str) -> dict[str, Any]:
    return {
        "workflow_id": workflow_id,
        **initialize_workflow_control(workflow_id),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Command Layer")
    sub = parser.add_subparsers(dest="action", required=True)

    p_execute = sub.add_parser("execute")
    p_execute.add_argument("state")
    p_execute.add_argument("command")
    p_execute.add_argument("output")
    p_execute.add_argument("--event-log", required=True)

    args = parser.parse_args()

    state = json.loads(Path(args.state).read_text(encoding="utf-8"))
    command = json.loads(Path(args.command).read_text(encoding="utf-8"))
    updated, result = execute_command(
        state,
        command,
        event_log=EventLog(args.event_log),
        has_queued_work=bool(state.get("queued_segments")),
    )
    Path(args.output).write_text(
        json.dumps(
            {"state": updated, "result": result},
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {ACCEPTED, REPLAY} else 3


if __name__ == "__main__":
    raise SystemExit(main())
