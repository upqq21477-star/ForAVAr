#!/usr/bin/env python3
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from brain_input import allowed_pairs, is_input_request
from command_layer import build_command, validate_command
from brain_input import validate_packet
from intent_resolution import validate_result as validate_intent_result


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "brain_proposal.schema.json"


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "brain_proposal.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"], Resource.from_contents(schema)
        )
    return registry


def validate_proposal(proposal: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    validator = Draft202012Validator(
        schema,
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(
        validator.iter_errors(proposal),
        key=lambda item: list(item.path),
    )
    if errors:
        raise ValueError(
            "Brain Proposal Schema 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def _expected_revision(state: dict[str, Any], proposal: dict[str, Any]) -> None:
    if proposal["expected_state_revision"] != state["state_revision"]:
        raise ValueError(
            "PROPOSAL_EXPECTED_REVISION_MISMATCH"
        )


def validate_proposal_against_state(
    state: dict[str, Any],
    proposal: dict[str, Any],
    *,
    packet: dict[str, Any] | None = None,
) -> None:
    """提案必須落在 allowed_*：(command_type, decision_code, route_mode) 須在路由表內；
    給定 packet（Brain 實際看到的輸入）時，另須 revision 相符且 decision／route 在其 allowed_* 內。"""
    validate_proposal(proposal)

    if proposal["aggregate_type"] != "WORKFLOW":
        raise ValueError("P9 目前只允許 Brain Proposal 提交 WORKFLOW Command")

    if proposal["workflow_id"] != state.get("workflow_id"):
        raise ValueError("PROPOSAL_WORKFLOW_ID_MISMATCH")

    if proposal["target_id"] != state.get("workflow_id"):
        raise ValueError("PROPOSAL_TARGET_ID_MISMATCH")

    _expected_revision(state, proposal)

    pairs = allowed_pairs(state)
    if proposal["command_type"] not in pairs:
        raise ValueError(
            "PROPOSAL_COMMAND_NOT_ALLOWED_FOR_STATE:" + proposal["command_type"]
        )
    decisions, modes = pairs[proposal["command_type"]]
    if proposal["decision_code"] not in decisions:
        raise ValueError("PROPOSAL_DECISION_NOT_ALLOWED:" + proposal["decision_code"])
    if proposal["route_mode"] not in modes:
        raise ValueError("PROPOSAL_ROUTE_NOT_ALLOWED:" + proposal["route_mode"])

    rulings = proposal.get("segment_rulings")
    if rulings is not None and proposal["command_type"] != "RESUME":
        raise ValueError("PROPOSAL_RULINGS_ONLY_WITH_RESUME")

    if packet is not None:
        if packet["workflow_id"] != proposal["workflow_id"] or packet["state_revision"] != proposal["expected_state_revision"]:
            raise ValueError("PROPOSAL_PACKET_REVISION_MISMATCH")
        if proposal["decision_code"] not in packet["allowed_decisions"]:
            raise ValueError("PROPOSAL_OUTSIDE_PACKET_ALLOWED_DECISIONS:" + proposal["decision_code"])
        if proposal["route_mode"] not in packet["allowed_route_modes"]:
            raise ValueError("PROPOSAL_OUTSIDE_PACKET_ALLOWED_ROUTES:" + proposal["route_mode"])




def validate_intent_handoff(handoff: dict[str, Any]) -> None:
    """Validate the non-persistent F24 handoff against its dedicated schema."""
    schema_path = ROOT / "P1-Central-Control/schemas/intent_handoff.schema.json"
    if schema_path.is_symlink() or not schema_path.is_file() or not schema_path.resolve().is_relative_to(ROOT.resolve()):
        raise ValueError("INTENT_HANDOFF_SCHEMA_PATH_INVALID")
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(handoff)
    except Exception as exc:
        raise ValueError(f"INTENT_HANDOFF_SCHEMA_INVALID:{type(exc).__name__}:{exc}") from exc


def prepare_intent_handoff(
    intent_result: dict[str, Any],
    state: dict[str, Any],
    packet: dict[str, Any],
) -> dict[str, Any]:
    """Bind resolved intent to the current Brain Input Packet without issuing a command.

    This is a handoff gate, not a proposal, authorization, state write, or execution.
    The eventual Brain Proposal must still pass validate_proposal_against_state().
    """
    validate_intent_result(intent_result)
    validate_packet(packet)
    request_id = intent_result.get("request_id")
    workflow_id = state.get("workflow_id")
    state_revision = state.get("state_revision")
    packet_id = packet.get("packet_id")
    base = {
        "request_id": request_id,
        "workflow_id": workflow_id if isinstance(workflow_id, str) else None,
        "state_revision": state_revision if type(state_revision) is int else None,
        "brain_input_packet_id": packet_id if isinstance(packet_id, str) else None,
        "intent_category": intent_result.get("intent_category", "UNKNOWN"),
        "candidate_commands": [],
        "clarification_options": intent_result.get("clarification_options", []),
        "source_refs": list(dict.fromkeys(
            fact["source_ref"] for fact in intent_result.get("source_facts", [])
            if isinstance(fact, dict) and isinstance(fact.get("source_ref"), str)
        )),
        "explicit_scope": intent_result.get("explicit_scope"),
        "constraints": intent_result.get("constraints", []),
        "confirmation_required": intent_result.get("confirmation_required") is True,
        "authorization_status": intent_result.get("authorization_status", "NOT_REQUIRED"),
        "state_written": False,
        "warnings": list(intent_result.get("warnings", [])),
    }
    if (
        not isinstance(workflow_id, str)
        or packet.get("workflow_id") != workflow_id
        or type(state_revision) is not int
        or packet.get("state_revision") != state_revision
    ):
        base.update(
            status="BLOCKED_STATE_DRIFT",
            next_action="Refresh the Brain Input Packet from the current state; discard any stale candidate command.",
        )
        base["warnings"].append("State revision or workflow identity does not match the packet seen by Brain.")
        return validate_intent_handoff_and_return(base)
    intent_status = intent_result.get("status")
    if intent_status in {"NEEDS_CLARIFICATION", "CONFLICT_REQUIRES_CLARIFICATION"} or intent_result.get("intent_category") == "UNKNOWN":
        base.update(
            status="NEEDS_CLARIFICATION",
            next_action="Ask the user to select or correct an interpretation; do not produce a command yet.",
        )
        return validate_intent_handoff_and_return(base)
    if intent_status != "RESOLVED":
        base.update(
            status="BLOCKED_INTENT",
            next_action="Return to Brain/Cognitive Decision and resolve the intent record before proposal creation.",
        )
        return validate_intent_handoff_and_return(base)
    if intent_result.get("authorization_status") == "GOVERNANCE_REVIEW_REQUIRED":
        base.update(
            status="NEEDS_GOVERNANCE",
            next_action="Obtain the required Governance decision; Brain Proposal creation remains blocked.",
        )
        return validate_intent_handoff_and_return(base)
    if intent_result.get("confirmation_required") is True:
        base.update(
            status="NEEDS_CONFIRMATION",
            next_action="Obtain explicit user confirmation within the declared scope; confirmation is not permission to bypass governance.",
        )
        return validate_intent_handoff_and_return(base)
    pairs = allowed_pairs(state)
    packet_decisions = set(packet.get("allowed_decisions", []))
    packet_routes = set(packet.get("allowed_route_modes", []))
    candidates = []
    for command, (decisions, modes) in sorted(pairs.items()):
        narrowed_decisions = sorted(set(decisions) & packet_decisions)
        narrowed_routes = sorted(set(modes) & packet_routes)
        if narrowed_decisions and narrowed_routes:
            candidates.append({
                "command_type": command,
                "decision_codes": narrowed_decisions,
                "route_modes": narrowed_routes,
            })
    if not candidates:
        base.update(
            status="BLOCKED_NO_ALLOWED_COMMAND",
            next_action="The current state contract permits no Brain Proposal command; preserve state and ask Central to refresh or close the workflow.",
        )
        return validate_intent_handoff_and_return(base)
    base.update(
        status="READY_FOR_BRAIN_PROPOSAL",
        candidate_commands=candidates,
        next_action="Brain must select a semantically appropriate candidate and submit a proposal that passes validate_proposal_against_state() for this exact state revision.",
    )
    base["warnings"].append("Intent resolution never authorizes a command; the state contract and proposal validator remain mandatory.")
    return validate_intent_handoff_and_return(base)




def validate_intent_handoff_and_return(handoff: dict[str, Any]) -> dict[str, Any]:
    validate_intent_handoff(handoff)
    return handoff


def materialize_command(
    state: dict[str, Any],
    proposal: dict[str, Any],
    *,
    actor_id: str = "COMMANDER",
    correlation_id: str | None = None,
    issued_at: str | None = None,
    packet: dict[str, Any] | None = None,
) -> dict[str, Any]:
    validate_proposal_against_state(state, proposal, packet=packet)
    if is_input_request(proposal):
        raise ValueError("ASK_INPUT_HAS_NO_COMMAND")

    command = build_command(
        state,
        proposal["command_type"],
        command_id=f"CMD:{proposal['proposal_id']}",
        idempotency_key=proposal["idempotency_key"],
        caused_by=proposal["object_id"],
        actor_id=actor_id,
        correlation_id=correlation_id,
        issued_at=issued_at,
    )
    validate_command(command)

    # Proposal is advisory input. The materialized command is authoritative;
    # no Brain-provided target/state/event payload is copied into execution.
    return command


def accept_proposal(
    state: dict[str, Any],
    proposal: dict[str, Any],
    *,
    packet: dict[str, Any] | None = None,
) -> dict[str, Any]:
    validate_proposal_against_state(state, proposal, packet=packet)
    return {
        "status": "ACCEPTED",
        "proposal_id": proposal["proposal_id"],
        "command_type": proposal["command_type"],
        "target_id": proposal["target_id"],
        "expected_state_revision": proposal["expected_state_revision"],
        "next": "AWAIT_INPUT" if is_input_request(proposal) else "COMMAND_READY",
    }
