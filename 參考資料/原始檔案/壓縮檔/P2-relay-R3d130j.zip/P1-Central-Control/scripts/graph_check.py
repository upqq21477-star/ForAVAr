"""graph_check -- pure stdlib dependency-graph check (CAP-GRAPH, R3d12zv S5 batch 2).  Edge {from, to, relation, source}; nodes = registered ids.
graphlib silently adds unseen predecessors, so endpoints (and edge shape, non-empty source) are checked BEFORE graphlib; any bad edge rejects the whole
batch (REJECTED + bad list, no half graph).  End: OK (acyclic, topo_order) | PARTIAL (one closed witness cycle, first == last; listing all cycles
would need own SCC code) | REJECTED | INCOMPLETE (> max_edges, nothing truncated).  path() = shortest from->to by BFS, deterministic.
No state: an interrupted call is rerun.  Evidence ceiling: SIMULATED_PASS.  max_edges 5000 is HYPOTHESIS."""
from __future__ import annotations

import graphlib
from collections import deque
from typing import Any

MAX_EDGES = 5000


def _edge_errors(edges: list[Any], nodes: set[str] | None) -> list[dict[str, Any]]:
    bad: list[dict[str, Any]] = []
    for i, x in enumerate(edges):
        if not isinstance(x, dict) or not all(isinstance(x.get(k), str) and x[k] for k in ("from", "to", "source")):
            bad.append({"index": i, "reason": "BAD_EDGE"})
            continue
        for k in ("from", "to"):
            if nodes is not None and x[k] not in nodes:
                bad.append({"index": i, "reason": "ENDPOINT_NOT_IN_NODES", "node": x[k]})
                break
    return bad


def _out(status: str, reason: str = "", **kw: Any) -> dict[str, Any]:
    return {"status": status, "reason": reason, "graph": None, "topo_order": None, "cycle": None, "bad": [], **kw}


def check(edges: Any, nodes: Any = None, max_edges: int = MAX_EDGES) -> dict[str, Any]:
    if not isinstance(edges, list):
        return _out("REJECTED", "NOT_A_LIST")
    if len(edges) > max_edges:
        return _out("INCOMPLETE", "TOO_MANY_EDGES")
    node_set = set(nodes) if nodes is not None else None
    bad = _edge_errors(edges, node_set)
    if bad:
        return _out("REJECTED", "BAD_INPUT", bad=bad)
    preds: dict[str, set[str]] = {}
    for x in edges:
        preds.setdefault(x["from"], set())
        preds.setdefault(x["to"], set()).add(x["from"])
    graph = {n: sorted(p) for n, p in sorted(preds.items())}
    ts = graphlib.TopologicalSorter()
    for n, p in graph.items():
        ts.add(n, *p)
    try:
        order = list(ts.static_order())
    except graphlib.CycleError as err:
        return _out("PARTIAL", "CYCLE", graph=graph, cycle=list(err.args[1]))
    return _out("OK", graph=graph, topo_order=order)


def path(edges: list[dict[str, Any]], src: str, dst: str) -> list[str] | None:
    adj: dict[str, list[str]] = {}
    for x in edges:
        adj.setdefault(x["from"], []).append(x["to"])
    seen, q = {src: None}, deque([src])
    while q:
        n = q.popleft()
        if n == dst:
            out = []
            while n is not None:
                out.append(n)
                n = seen[n]
            return out[::-1]
        for m in sorted(adj.get(n, [])):
            if m not in seen:
                seen[m] = n
                q.append(m)
    return None
