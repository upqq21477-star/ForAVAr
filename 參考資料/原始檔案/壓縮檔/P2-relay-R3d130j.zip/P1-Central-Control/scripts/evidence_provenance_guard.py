#!/usr/bin/env python3
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "evidence.schema.json",
        "provenance.schema.json",
        "evidence_guard_result.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"], Resource.from_contents(schema)
        )
    return registry


def _validate(filename: str, value: dict[str, Any]) -> None:
    schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
    validator = Draft202012Validator(
        schema,
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(validator.iter_errors(value), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            f"{filename} 驗證失敗: " + "; ".join(error.message for error in errors)
        )


def validate_evidence(record: dict[str, Any]) -> None:
    _validate("evidence.schema.json", record)


def validate_provenance(record: dict[str, Any]) -> None:
    _validate("provenance.schema.json", record)




def validate_guard_result(report: dict[str, Any]) -> None:
    _validate("evidence_guard_result.schema.json", report)
def _index(records: list[dict[str, Any]], label: str) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for record in records:
        object_id = record.get("object_id")
        if not object_id:
            raise ValueError(f"{label} 缺少 object_id")
        if object_id in result:
            raise ValueError(f"{label} object_id 重複: {object_id}")
        result[object_id] = record
    return result


def guard_success(
    *,
    task_packet: dict[str, Any],
    result_packet: dict[str, Any],
    execution_record: dict[str, Any],
    evidence_records: list[dict[str, Any]],
    provenance_records: list[dict[str, Any]],
) -> dict[str, Any]:
    if result_packet["decision_code"] != "WORK_COMPLETE":
        raise ValueError("Evidence / Provenance Guard 只驗收 WORK_COMPLETE")

    if execution_record["status"] != "SUCCEEDED":
        raise ValueError("ExecutionRecord 尚未達 SUCCEEDED，禁止驗收成功結果")

    evidence = _index(evidence_records, "Evidence")
    provenance = _index(provenance_records, "Provenance")

    missing_evidence = [
        ref for ref in result_packet["evidence_refs"] if ref not in evidence
    ]
    if missing_evidence:
        raise ValueError("缺少 EvidenceRecord: " + ", ".join(missing_evidence))

    missing_provenance = [
        ref for ref in result_packet["provenance_refs"] if ref not in provenance
    ]
    if missing_provenance:
        raise ValueError("缺少 ProvenanceRecord: " + ", ".join(missing_provenance))

    for record in evidence.values():
        validate_evidence(record)
        if record["claim_ref"] != result_packet["object_id"]:
            raise ValueError("Evidence claim_ref 未綁定目前 ResultPacket")
        if record["relation"] != "SUPPORTS":
            raise ValueError("成功結果的 Evidence 必須為 SUPPORTS")
        source_bound = (
            record["source_ref"] in set(task_packet["input_refs"])
            or bool(record.get("locator"))
        )
        if not source_bound:
            raise ValueError(
                "Evidence source_ref 未綁定 TaskPacket input_refs，且沒有 locator"
            )
        captured_at = datetime.fromisoformat(
            record["captured_at"].replace("Z", "+00:00")
        )
        execution_end = datetime.fromisoformat(
            execution_record["end_time"].replace("Z", "+00:00")
        )
        if captured_at > execution_end:
            raise ValueError("Evidence captured_at 晚於 ExecutionRecord end_time")

    expected_agent = (
        f"SKILL:{result_packet['skill_id']}-{result_packet['skill_version']}"
    )
    expected_activity = execution_record["execution_record_ref"]

    for record in provenance.values():
        validate_provenance(record)
        if record["subject_ref"] != result_packet["object_id"]:
            raise ValueError("Provenance subject_ref 未綁定目前 ResultPacket")
        if record["activity_ref"] != expected_activity:
            raise ValueError("Provenance activity_ref 未綁定目前 ExecutionRecord")
        if record["agent_ref"] != expected_agent:
            raise ValueError("Provenance agent_ref 與 Skill identity 不一致")
        if record["relation"] != "WAS_GENERATED_BY":
            raise ValueError("成功結果的 Provenance 必須為 WAS_GENERATED_BY")

        task_inputs = set(task_packet["input_refs"])
        recorded_inputs = set(record["input_refs"])
        if not task_inputs.issubset(recorded_inputs):
            raise ValueError("Provenance 缺少 TaskPacket input_refs")

        result_outputs = set(result_packet["output_refs"])
        recorded_outputs = set(record["output_refs"])
        if not result_outputs.issubset(recorded_outputs):
            raise ValueError("Provenance 缺少 ResultPacket output_refs")

    report = {
        "status": "PASS",
        "result_id": result_packet["result_id"],
        "execution_record_ref": execution_record["execution_record_ref"],
        "evidence_count": len(evidence),
        "provenance_count": len(provenance),
        "checks": {
            "evidence_refs_resolved": True,
            "evidence_claim_binding": True,
            "evidence_supporting": True,
            "evidence_time_bound": True,
            "provenance_refs_resolved": True,
            "provenance_subject_binding": True,
            "provenance_activity_binding": True,
            "provenance_agent_binding": True,
            "provenance_input_binding": True,
            "provenance_output_binding": True,
        },
    }
    validate_guard_result(report)
    return report
