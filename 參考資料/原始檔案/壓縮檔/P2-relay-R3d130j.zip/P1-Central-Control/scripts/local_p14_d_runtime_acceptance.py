#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]


def run(command: list[str], output: Path) -> tuple[int, int]:
    started = time.perf_counter()
    proc = subprocess.run(
        command,
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    duration_ms = int((time.perf_counter() - started) * 1000)
    output.write_text(
        json.dumps(
            {
                "return_code": proc.returncode,
                "duration_ms": duration_ms,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
            },
            ensure_ascii=False,
            indent=2,
        ) + "\n",
        encoding="utf-8",
    )
    return proc.returncode, duration_ms


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def git_sha() -> str:
    proc = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    return proc.stdout.strip() if proc.returncode == 0 else "UNKNOWN"



def source_manifest() -> list[dict[str, str]]:
    paths = [
        "P1-Central-Control/scripts/local_p14_d_runtime_acceptance.py",
        "P1-Central-Control/scripts/external_architecture_evidence_adapter.py",
        "P1-Central-Control/scripts/dynamic_boundary_runtime_probe.py",
        "P1-Central-Control/scripts/p14_d_recovery_entrypoint.py",
        "P1-Central-Control/scripts/actions_execution_closure.py",
        "P1-Central-Control/scripts/actions_execution_truth_adapter.py",
        "P1-Central-Control/scripts/current_truth_reconciliation.py",
        "P1-Central-Control/schemas/local_p14_d_runtime_acceptance.schema.json",
        "P1-Central-Control/schemas/actions_execution_diagnostic.schema.json",
    ]
    manifest: list[dict[str, str]] = []
    for relative in paths:
        path = ROOT / relative
        if not path.is_file():
            raise SystemExit(f"PROVENANCE_SOURCE_MISSING:{relative}")
        manifest.append({"path": relative, "sha256": sha256(path)})
    return manifest


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain JSON object")
    return value


def validate_bundle(value: dict[str, Any]) -> None:
    schema = json.loads(
        (ROOT / "P1-Central-Control/schemas/local_p14_d_runtime_acceptance.schema.json")
        .read_text(encoding="utf-8")
    )
    Draft202012Validator(schema).validate(value)


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 local P14-D runtime acceptance")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    output_dir = Path(args.output).resolve().parent
    output_dir.mkdir(parents=True, exist_ok=True)

    started_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    head_sha = git_sha()
    if not head_sha or head_sha == "UNKNOWN":
        raise SystemExit("GIT_HEAD_SHA_UNAVAILABLE")
    scratch = output_dir / ".p14-local"
    scratch.mkdir(parents=True, exist_ok=True)

    stages: list[dict[str, Any]] = []

    external = scratch / "external.json"
    code, duration = run(
        [
            sys.executable,
            "P1-Central-Control/scripts/external_architecture_evidence_adapter.py",
            "--input",
            "P1-Central-Control/fixtures/p14-external-architecture-sample.sarif",
            "--source-type",
            "OTHER",
            "--source-uri",
            "fixture://p14-external-architecture-sample.sarif",
            "--source-revision",
            head_sha,
            "--output",
            str(external),
        ],
        scratch / "external-run.json",
    )
    external_value = load(external) if external.is_file() else {}
    external_pass = (
        code == 0
        and external_value.get("truth_boundary") == "EXTERNAL_EVIDENCE_ONLY"
        and external_value.get("summary", {}).get("finding_count") == 1
    )
    stages.append(
        {
            "stage_id": "EXTERNAL_ARCHITECTURE_EVIDENCE_ADAPTER",
            "status": "PASS" if external_pass else "FAIL",
            "return_code": code,
            "duration_ms": duration,
            "evidence_ref": str(external.relative_to(ROOT)),
        }
    )

    dynamic = scratch / "dynamic-boundary.json"
    code, duration = run(
        [
            sys.executable,
            "P1-Central-Control/scripts/dynamic_boundary_runtime_probe.py",
            "--root",
            str(ROOT),
            "--output",
            str(dynamic),
        ],
        scratch / "dynamic-run.json",
    )
    dynamic_value = load(dynamic) if dynamic.is_file() else {}
    dynamic_status = dynamic_value.get("status")
    stages.append(
        {
            "stage_id": "DYNAMIC_BOUNDARY_RUNTIME_PROBE",
            "status": (
                "PASS"
                if code == 0 and dynamic_status == "PASS"
                else "INCOMPLETE"
                if dynamic_status == "INCOMPLETE" or code == 2
                else "FAIL"
            ),
            "return_code": code,
            "duration_ms": duration,
            "evidence_ref": str(dynamic.relative_to(ROOT)),
        }
    )

    test_output = scratch / "p14-tests.json"
    test_code, test_duration = run(
        [
            sys.executable,
            "-m",
            "unittest",
            "-v",
            "P1-Central-Control/tests/test_external_architecture_evidence_adapter.py",
            "P1-Central-Control/tests/test_dynamic_boundary_runtime_probe.py",
            "P1-Central-Control/tests/test_m23_p14_control_gate_integration.py",
            "P1-Central-Control/tests/test_runtime_evidence_probe.py",
            "P1-Central-Control/tests/test_p14_d_recovery_entrypoint.py",
            "P1-Central-Control/tests/test_p14_d_recovery_e2e.py",
        ],
        test_output,
    )
    stages.append(
        {
            "stage_id": "P14-D_UNIT_ACCEPTANCE",
            "status": "PASS" if test_code == 0 else "FAIL",
            "return_code": test_code,
            "duration_ms": test_duration,
            "evidence_ref": str(test_output.relative_to(ROOT)),
        }
    )

    overall = "PASS"
    if any(stage["status"] == "FAIL" for stage in stages):
        overall = "FAIL"
    elif any(stage["status"] == "INCOMPLETE" for stage in stages):
        overall = "INCOMPLETE"

    bundle = {
        "schema_version": "1.0",
        "evidence_id": "LOCAL_P14_D:" + head_sha,
        "status": overall,
        "evidence_class": "OBSERVED_LOCAL_RUNTIME",
        "started_at": started_at,
        "completed_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "head_sha": head_sha,
        "runtime": {
            "python": platform.python_version(),
            "platform": platform.platform(),
        },
        "source_manifest": source_manifest(),
        "stages": stages,
        "truth_boundary": "LOCAL_RUNTIME_ONLY_NOT_GITHUB_ACTIONS",
    }

    final = Path(args.output).resolve()
    validate_bundle(bundle)
    final.write_text(
        json.dumps(bundle, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(bundle, ensure_ascii=False, indent=2))
    return 0 if overall == "PASS" else 2 if overall == "INCOMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
