#!/usr/bin/env python3
"""Build and validate a bounded recovery box from canonical execution references.

The box is a recovery descriptor, not a second state/truth store. It contains only
the identifiers, hashes and resume cursor required to reconstruct the task from
existing canonical owners after context loss or process restart.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import tempfile
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/continuation_context_box.schema.json"


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def current_fingerprint(current: dict[str, Any]) -> str:
    """Fingerprint the current authority fields that affect a resume decision."""
    stage = current.get("current_stage") or {}
    implementation = current.get("implementation_control") or {}
    material = {
        "revision": current.get("revision"),
        "state_revision": current.get("state_revision"),
        "current_stage": stage,
        "active_work_packet": implementation.get("active_work_packet"),
        "latest_runtime_observation": current.get("latest_runtime_observation") or stage.get("latest_runtime_observation"),
        "next_exact_action": current.get("next_exact_action"),
    }
    return content_hash(material)


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError("CONTINUATION_BOX_OBJECT_REQUIRED")
    return value


def validate(box: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(box)
    expected = content_hash(box)
    if box["content_hash"] != expected:
        raise ValueError("CONTINUATION_BOX_CONTENT_HASH_MISMATCH")


def build(
    *,
    current: dict[str, Any],
    task_packet: dict[str, Any],
    execution_record_ref: str,
    event_log_ref: str | None = None,
    construction_ref: str | None = None,
    resume_point: str = "WAITING_EXTERNAL_RESULT",
    baseline: dict[str, Any] | None = None,
) -> dict[str, Any]:
    from packet_layer import validate_task_packet

    validate_task_packet(task_packet)
    if not execution_record_ref:
        raise ValueError("CONTINUATION_BOX_EXECUTION_REF_REQUIRED")

    stage = current.get("current_stage") or {}
    box = {
        "schema_version": "1.0",
        "box_id": (
            "CONTINUATION_BOX:"
            f"{task_packet['workflow_id']}:{task_packet['segment_id']}:{task_packet['attempt_id']}"
        ),
        "kind": "CONTINUATION_CONTEXT_BOX",
        "status": "READY",
        "workflow_id": task_packet["workflow_id"],
        "segment_id": task_packet["segment_id"],
        "attempt_id": task_packet["attempt_id"],
        "resume_point": resume_point,
        "canonical_inputs": {
            "current_ref": "AUTHORITY:P1-CURRENT",
            "current_revision": current.get("revision"),
            "current_fingerprint": current_fingerprint(current),
            "task_packet_ref": task_packet["object_id"],
            "task_packet_hash": task_packet["content_hash"],
            "execution_record_ref": execution_record_ref,
            "event_log_ref": event_log_ref,
            "construction_ref": construction_ref,
        },
        "resume_cursor": {
            "state_revision": int(current.get("state_revision", 0)),
            "stage_id": stage.get("id"),
            "stage_status": stage.get("status"),
            "next_action": current.get("next_exact_action"),
        },
        "context_policy": {
            "history_loaded": 0,
            "transient_context_loaded": False,
            "targeted_retrieval_only": True,
        },
        "content_hash": "",
    }
    if baseline is not None:
        box["baseline"] = deepcopy(baseline)
    box["content_hash"] = content_hash(box)
    validate(box)
    return box


def _checkpoint_root(root: Path) -> Path:
    return (root.resolve() / "P1-Central-Control" / "checkpoints").resolve()


def _is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.relative_to(parent)
        return True
    except ValueError:
        return False


def _index_path(root: Path) -> Path:
    return _checkpoint_root(root) / "continuation_box_index.json"


def _read_index(root: Path, *, allow_missing: bool = False) -> dict[str, Any]:
    path = _index_path(root)
    if not path.is_file():
        if allow_missing:
            return {"schema_version": "1.0", "entries": {}}
        raise ValueError("CONTINUATION_BOX_INDEX_NOT_FOUND")
    try:
        value = load(path)
    except (OSError, UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
        raise ValueError("CONTINUATION_BOX_INDEX_INVALID") from exc
    if value.get("schema_version") != "1.0" or not isinstance(value.get("entries"), dict):
        raise ValueError("CONTINUATION_BOX_INDEX_INVALID")
    if any(not isinstance(k, str) or not k or not isinstance(v, str) or not v for k, v in value["entries"].items()):
        raise ValueError("CONTINUATION_BOX_INDEX_INVALID")
    return value


def _write_index(root: Path, index: dict[str, Any]) -> None:
    path = _index_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(index, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            newline="\n",
            dir=path.parent,
            prefix=".continuation_box_index.",
            suffix=".tmp",
            delete=False,
        ) as temp:
            temp.write(payload)
            temp.flush()
            os.fsync(temp.fileno())
            temp_path = Path(temp.name)
        os.replace(temp_path, path)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def register_checkpoint(root: Path, path: Path, box: dict[str, Any]) -> None:
    """Register one already-persisted box; normal lookup never scans for missing entries."""
    validate(box)
    root_path = root.resolve()
    checkpoint_root = _checkpoint_root(root_path)
    target = path.resolve()
    if not _is_relative_to(target, checkpoint_root):
        raise ValueError("CONTINUATION_BOX_PATH_OUTSIDE_CHECKPOINT_ROOT")
    if not target.is_file():
        raise ValueError("CONTINUATION_BOX_TARGET_NOT_FOUND")
    persisted = load(target)
    validate(persisted)
    if persisted.get("box_id") != box.get("box_id") or persisted != box:
        raise ValueError("CONTINUATION_BOX_TARGET_MISMATCH")

    relative_path = target.relative_to(root_path).as_posix()
    index = _read_index(root_path, allow_missing=True)
    existing = index["entries"].get(box["box_id"])
    if existing is not None and existing != relative_path:
        raise ValueError("CONTINUATION_BOX_ID_CONFLICT")
    index["entries"][box["box_id"]] = relative_path
    _write_index(root_path, index)


def locate(root: Path, box_id: str) -> tuple[Path, dict[str, Any]]:
    """O(1)-style indexed lookup by canonical box_id; never searches checkpoint history."""
    if not isinstance(box_id, str) or not box_id:
        raise ValueError("CONTINUATION_BOX_ID_REQUIRED")
    root_path = root.resolve()
    checkpoint_root = _checkpoint_root(root_path)
    index = _read_index(root_path)
    relative_path = index["entries"].get(box_id)
    if relative_path is None:
        raise ValueError("CONTINUATION_BOX_NOT_FOUND")
    target = (root_path / relative_path).resolve()
    if not _is_relative_to(target, checkpoint_root):
        raise ValueError("CONTINUATION_BOX_INDEX_PATH_INVALID")
    if not target.is_file():
        raise ValueError("CONTINUATION_BOX_INDEX_TARGET_MISSING")
    try:
        candidate = load(target)
        validate(candidate)
    except Exception as exc:
        raise ValueError("CONTINUATION_BOX_INDEX_TARGET_INVALID") from exc
    if candidate.get("kind") != "CONTINUATION_CONTEXT_BOX" or candidate.get("box_id") != box_id:
        raise ValueError("CONTINUATION_BOX_INDEX_ENTRY_MISMATCH")
    return target, candidate


def mark_used(box: dict[str, Any]) -> dict[str, Any]:
    validate(box)
    updated = deepcopy(box)
    updated["status"] = "USED"
    updated["content_hash"] = ""
    updated["content_hash"] = content_hash(updated)
    validate(updated)
    return updated


def reconstruct(
    *,
    current: dict[str, Any],
    task_packet: dict[str, Any],
    box: dict[str, Any],
    root: Path | None = None,
    require_baseline: bool = False,
) -> dict[str, Any]:
    from packet_layer import validate_task_packet

    validate_task_packet(task_packet)
    validate(box)

    expected_task_ref = task_packet["object_id"]
    expected_exec_ref = task_packet["execution_record_ref"]
    canonical = box["canonical_inputs"]
    stage = current.get("current_stage") or {}

    if box.get("status") != "READY":
        raise ValueError("CONTINUATION_BOX_NOT_READY")
    if box["workflow_id"] != task_packet["workflow_id"]:
        raise ValueError("CONTINUATION_BOX_WORKFLOW_MISMATCH")
    if box["segment_id"] != task_packet["segment_id"]:
        raise ValueError("CONTINUATION_BOX_SEGMENT_MISMATCH")
    if box["attempt_id"] != task_packet["attempt_id"]:
        raise ValueError("CONTINUATION_BOX_ATTEMPT_MISMATCH")
    if canonical["task_packet_ref"] != expected_task_ref:
        raise ValueError("CONTINUATION_BOX_TASK_REF_MISMATCH")
    if canonical["task_packet_hash"] != task_packet["content_hash"]:
        raise ValueError("CONTINUATION_BOX_TASK_HASH_MISMATCH")
    if canonical["execution_record_ref"] != expected_exec_ref:
        raise ValueError("CONTINUATION_BOX_EXECUTION_REF_MISMATCH")

    if canonical["current_revision"] is not None and current.get("revision") != canonical["current_revision"]:
        raise ValueError("CONTINUATION_BOX_CURRENT_REVISION_STALE")
    if stage.get("id") != box["resume_cursor"]["stage_id"]:
        raise ValueError("CONTINUATION_BOX_STAGE_ID_STALE")
    if stage.get("status") != box["resume_cursor"]["stage_status"]:
        raise ValueError("CONTINUATION_BOX_STAGE_STATUS_STALE")
    if "state_revision" in current and int(current["state_revision"]) != box["resume_cursor"]["state_revision"]:
        raise ValueError("CONTINUATION_BOX_STATE_REVISION_STALE")
    if current.get("next_exact_action") != box["resume_cursor"].get("next_action"):
        raise ValueError("CONTINUATION_BOX_NEXT_ACTION_STALE")
    if not canonical.get("current_fingerprint"):
        raise ValueError("CONTINUATION_BOX_CURRENT_FINGERPRINT_MISSING")
    if current_fingerprint(current) != canonical["current_fingerprint"]:
        raise ValueError("CONTINUATION_BOX_CURRENT_FINGERPRINT_STALE")
    if box.get("baseline") is None:
        if require_baseline:
            raise ValueError("CONTINUATION_BOX_BASELINE_MISSING")
    elif root is not None or require_baseline:
        if root is None:
            raise ValueError("CONTINUATION_BOX_BASELINE_ROOT_REQUIRED")
        checked = check_baseline(box["baseline"], root, current_revision=current.get("revision"))
        if checked["status"] != "OK":
            raise ValueError("CONTINUATION_BOX_BASELINE_" + checked["status"] + ":" + ",".join(checked["reasons"]))

    return {
        "mode": "AMNESIA_RECONSTRUCTED_WITH_BOX",
        "task_packet_ref": expected_task_ref,
        "execution_record_ref": expected_exec_ref,
        "continuation_box_ref": box["box_id"],
        "resume_point": box["resume_point"],
        "history_loaded": 0,
        "transient_context_loaded": False,
        "targeted_retrieval_only": True,
        "resume_cursor": deepcopy(box["resume_cursor"]),
    }


BASELINE_KEYS = ("baseline_revision", "semantic_baseline_hash", "change_radius")
BASELINE_MAX_RADIUS = 50


def _radius_files(root: Path, entry: str) -> list[tuple[str, Path | None]]:
    p = Path(entry)
    if not entry.strip() or p.is_absolute() or ".." in p.parts:
        raise ValueError(f"BASELINE_RADIUS_PATH_INVALID:{entry}")
    target = root / p
    if target.is_file():
        return [(p.as_posix(), target)]
    if target.is_dir():
        found: list[tuple[str, Path | None]] = []
        for dirpath, dirnames, filenames in os.walk(target):
            dirnames[:] = sorted(d for d in dirnames if d != "__pycache__")
            for name in sorted(filenames):
                fp = Path(dirpath) / name
                found.append((fp.relative_to(root).as_posix(), fp))
        return found
    return [(p.as_posix(), None)]


def semantic_baseline_hash(root: Path, change_radius: list[str]) -> str:
    """FR-06: hash of the bytes of every file inside the change radius (a missing path hashes as MISSING)."""
    items = []
    for entry in sorted(set(change_radius)):
        for rel, fp in _radius_files(root, entry):
            items.append([rel, hashlib.sha256(fp.read_bytes()).hexdigest() if fp else "MISSING"])
    items.sort()
    return "sha256:" + hashlib.sha256(json.dumps(items, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()


def make_baseline(root: Path, change_radius: list[str], baseline_revision: Any) -> dict[str, Any]:
    radius = sorted(set(change_radius))
    if not radius or len(radius) > BASELINE_MAX_RADIUS:
        raise ValueError("BASELINE_RADIUS_SIZE")
    return {"baseline_revision": baseline_revision, "semantic_baseline_hash": semantic_baseline_hash(root, radius),
            "change_radius": radius}


def check_baseline(baseline: Any, root: Path, *, current_revision: Any = None) -> dict[str, Any]:
    """OK | STALE (revision or content drifted) | MISSING (no baseline) | REJECTED (bad radius path)."""
    if not isinstance(baseline, dict) or any(k not in baseline for k in BASELINE_KEYS):
        return {"status": "MISSING", "reasons": ["BASELINE_MISSING"]}
    reasons: list[str] = []
    if current_revision is not None and str(baseline["baseline_revision"]) != str(current_revision):
        reasons.append("BASELINE_REVISION_STALE")
    try:
        now = semantic_baseline_hash(root, list(baseline["change_radius"]))
    except ValueError as exc:
        return {"status": "REJECTED", "reasons": [str(exc)]}
    if now != baseline["semantic_baseline_hash"]:
        reasons.append("SEMANTIC_BASELINE_STALE")
    return {"status": "STALE" if reasons else "OK", "reasons": reasons}


def resume_check(*, current: dict[str, Any], task_packet: dict[str, Any], box: dict[str, Any],
                 root: Path | None = None, require_baseline: bool = False) -> dict[str, Any]:
    """Admission for a resumed segment: status OK | STALE | REJECTED (reason = the reconstruct error code)."""
    try:
        result = reconstruct(current=current, task_packet=task_packet, box=box, root=root, require_baseline=require_baseline)
    except ValueError as exc:
        code = str(exc)
        return {"status": "STALE" if "STALE" in code else "REJECTED", "reason": code}
    return {"status": "OK", "result": result}


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Continuation Context Box")
    sub = parser.add_subparsers(dest="command", required=True)

    create = sub.add_parser("create")
    create.add_argument("--current", required=True)
    create.add_argument("--task-packet", required=True)
    create.add_argument("--execution-record-ref", required=True)
    create.add_argument("--event-log-ref")
    create.add_argument("--construction-ref")
    create.add_argument("--resume-point", default="WAITING_EXTERNAL_RESULT")
    create.add_argument("--output", required=True)

    inspect = sub.add_parser("reconstruct")
    inspect.add_argument("--current", required=True)
    inspect.add_argument("--task-packet", required=True)
    inspect.add_argument("--box", required=True)

    args = parser.parse_args()
    current = load(Path(args.current))
    task_packet = load(Path(args.task_packet))

    if args.command == "create":
        result = build(
            current=current,
            task_packet=task_packet,
            execution_record_ref=args.execution_record_ref,
            event_log_ref=args.event_log_ref,
            construction_ref=args.construction_ref,
            resume_point=args.resume_point,
        )
        output_path = Path(args.output).resolve()
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(
            json.dumps(result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        if _is_relative_to(output_path, _checkpoint_root(ROOT)):
            register_checkpoint(ROOT, output_path, result)
        print(json.dumps({"status": "PASS", "box_id": result["box_id"]}, ensure_ascii=False))
        return 0

    box = load(Path(args.box))
    print(json.dumps(
        reconstruct(current=current, task_packet=task_packet, box=box),
        ensure_ascii=False,
        indent=2,
    ))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
