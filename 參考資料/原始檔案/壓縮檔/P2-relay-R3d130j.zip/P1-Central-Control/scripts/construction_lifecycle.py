#!/usr/bin/env python3
"""Execute the canonical semantic-design to code-acceptance lifecycle."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any, Dict, List


EXPECTED_STAGES = [
    "SEMANTIC_SPEC",
    "SEMANTIC_SIMULATION",
    "DISTILL",
    "DISTILLED_VALIDATION",
    "CODE_COMPILE",
    "CODE_ACCEPTANCE",
    "FINALIZE",
]


def _load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate_contract(contract: Dict[str, Any]) -> None:
    from jsonschema import Draft202012Validator

    schema_path = Path(__file__).resolve().parents[1] / "schemas" / "construction_lifecycle_contract.schema.json"
    schema = _load_json(schema_path)
    errors = sorted(Draft202012Validator(schema).iter_errors(contract), key=lambda e: list(e.path))
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def _hash_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _resolve(base: Path, raw: str) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else base / path


def _check_files(base: Path, paths: List[str]) -> List[Dict[str, Any]]:
    results = []
    for raw in paths:
        path = _resolve(base, raw)
        if not path.is_file():
            raise FileNotFoundError(f"FILE_MISSING:{raw}")
        size = path.stat().st_size
        if size <= 0:
            raise ValueError(f"FILE_EMPTY:{raw}")
        results.append({
            "path": raw,
            "bytes": size,
            "sha256": _hash_file(path),
        })
    return results


def _validate_semantic_spec(base: Path, inputs: List[str]) -> List[Dict[str, Any]]:
    files = _check_files(base, inputs)
    payload = _load_json(_resolve(base, inputs[0]))
    if payload.get("status") != "PASS":
        raise ValueError("SEMANTIC_SPEC_NOT_PASS")
    if payload.get("architecture_validated") is not True:
        raise ValueError("SEMANTIC_ARCHITECTURE_NOT_VALIDATED")
    if not isinstance(payload.get("invariants"), list) or not payload["invariants"]:
        raise ValueError("SEMANTIC_INVARIANTS_MISSING")
    return files


def _run_command(base: Path, stage: Dict[str, Any]) -> Dict[str, Any]:
    inputs = _check_files(base, stage.get("inputs", []))
    command = stage.get("command")
    if not command:
        raise ValueError(f"COMMAND_MISSING:{stage['stage_id']}")
    timeout = stage.get("timeout_seconds", 30)
    try:
        completed = subprocess.run(
            command,
            cwd=str(base),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(f"COMMAND_TIMEOUT:{stage['stage_id']}") from exc
    if completed.returncode != 0:
        raise RuntimeError(
            f"COMMAND_FAILED:{stage['stage_id']}:returncode={completed.returncode}"
        )
    outputs = _check_files(base, stage.get("outputs", []))
    return {
        "command": command,
        "returncode": completed.returncode,
        "stdout_bytes": len(completed.stdout.encode("utf-8")),
        "stderr_bytes": len(completed.stderr.encode("utf-8")),
        "stdout_sha256": hashlib.sha256(completed.stdout.encode("utf-8")).hexdigest(),
        "stderr_sha256": hashlib.sha256(completed.stderr.encode("utf-8")).hexdigest(),
        "inputs": inputs,
        "outputs": outputs,
    }


def execute(contract: Dict[str, Any], base_dir: str | Path | None = None) -> Dict[str, Any]:
    _validate_contract(contract)
    if contract["stage_order"] != EXPECTED_STAGES:
        raise ValueError("STAGE_ORDER_INVALID")

    base = Path(base_dir or ".").resolve()
    stage_map = {stage["stage_id"]: stage for stage in contract["stages"]}
    if list(stage_map) != EXPECTED_STAGES:
        raise ValueError("STAGE_DEFINITION_ORDER_INVALID")

    results: List[Dict[str, Any]] = []
    for stage_id in EXPECTED_STAGES:
        stage = stage_map[stage_id]
        result: Dict[str, Any] = {
            "stage_id": stage_id,
            "op": stage["op"],
            "status": "PASS",
        }
        try:
            if stage["op"] == "VALIDATE_SEMANTIC_SPEC":
                result["files"] = _validate_semantic_spec(base, stage["inputs"])
            elif stage["op"] == "RUN_COMMAND":
                result.update(_run_command(base, stage))
            elif stage["op"] == "FINALIZE":
                if any(item["status"] != "PASS" for item in results):
                    raise RuntimeError("PRIOR_STAGE_NOT_PASS")
                result["finalized"] = True
            else:
                raise ValueError(f"UNSUPPORTED_OPERATION:{stage['op']}")
        except Exception as exc:
            result["status"] = "FAIL"
            result["error"] = str(exc)
            results.append(result)
            return {
                "status": "BLOCK",
                "lifecycle_id": contract["lifecycle_id"],
                "applies_to": contract["applies_to"],
                "completed_stage": stage_id,
                "finalized": False,
                "stage_results": results,
            }
        results.append(result)

    return {
        "status": "PASS",
        "lifecycle_id": contract["lifecycle_id"],
        "applies_to": contract["applies_to"],
        "completed_stage": "FINALIZE",
        "finalized": True,
        "stage_results": results,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("contract", help="Path to a construction lifecycle contract JSON file")
    parser.add_argument("--base-dir", default=".", help="Working directory for relative artifact paths")
    args = parser.parse_args()

    result = execute(_load_json(Path(args.contract)), args.base_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
