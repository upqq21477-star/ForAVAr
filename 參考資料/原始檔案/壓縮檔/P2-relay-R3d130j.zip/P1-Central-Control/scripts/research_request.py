"""research_request -- request ledger + degradation for a search the caller supplies (CAP-SEARCH, R3d12zz S6 batch 4).  Contract only: no search of its own, no network.
request(gap_id, queries[<=2], search(query)->[{url, retrieved_at, ...}] | None, ledger_dir, enough=1).  queries[0] = first ask, queries[1] = one narrowed retry; a third -> REJECTED ROUND_LIMIT.
Candidates: http(s) url + ISO retrieved_at required, else dropped into `rejected`; only url/retrieved_at/title kept; trust is always set here to UNTRUSTED_CANDIDATE (never taken from the search
output); search-result text is data and is never executed.  End: COMPLETE (>= enough candidates) | PARTIAL (2 rounds used, still short; gaps=[gap_id]) | NOT_EXECUTED (search is None; action
ASK_USER_FOR_SOURCE; not FAILED) | INCOMPLETE (2 failed attempts: tool error, non-list reply, or death mid-request; action ASK_USER_FOR_SOURCE) | REJECTED (bad fields, round limit).
Ledger: request_id = hash(gap, query, round); PENDING is written before the call, DONE/INCOMPLETE after; DONE is reused (never resent); PENDING/INCOMPLETE count as attempts, so a crash loop
cannot resend forever.  BaseException (death) is never swallowed.  2 rounds / 2 failures follow §12 (HYPOTHESIS).  Evidence ceiling: SIMULATED_PASS."""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from atomic_write import atomic_write

MAX_ROUNDS = MAX_FAILS = 2
TRUST = "UNTRUSTED_CANDIDATE"
ASK = "ASK_USER_FOR_SOURCE"


def _dump(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True, default=str)


def request_id(gap_id: str, query: str, rnd: int) -> str:
    return hashlib.sha256(_dump([gap_id, query, rnd]).encode("utf-8")).hexdigest()[:16]


def _load(p: Path) -> Any:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _cand(c: Any, rid: str) -> dict[str, Any] | None:
    try:
        u, t = c.get("url"), c.get("retrieved_at")
        if not (isinstance(u, str) and re.match(r"^https?://[^\s/]+", u) and isinstance(t, str) and t):
            return None
        datetime.fromisoformat(t.replace("Z", "+00:00"))
    except (AttributeError, ValueError, TypeError):
        return None
    ti = c.get("title")
    return {"url": u, "retrieved_at": t, "title": ti[:200] if isinstance(ti, str) else "", "trust": TRUST, "request_id": rid}


def _res(status: str, reason: str = "", gap: str = "", cands: Any = (), rej: Any = (), rounds: int = 0, action: str = "") -> dict[str, Any]:
    return {"status": status, "reason": reason, "gaps": [gap] if status == "PARTIAL" else [], "candidates": list(cands), "rejected": list(rej), "rounds": rounds, "action": action}


def _run(gap_id: Any, queries: Any, search: Callable[[str], Any] | None, ledger_dir: Any, enough: Any) -> dict[str, Any]:
    if isinstance(queries, list) and len(queries) > MAX_ROUNDS:
        return _res("REJECTED", "ROUND_LIMIT")
    if not (isinstance(gap_id, str) and gap_id and isinstance(queries, list) and queries and all(isinstance(q, str) and q.strip() for q in queries)
            and isinstance(enough, int) and enough >= 1):
        return _res("REJECTED", "FIELDS")
    if search is None:
        return _res("NOT_EXECUTED", "NO_SEARCH", action=ASK)
    sd, cands, rejected, fails = Path(ledger_dir), [], [], 0
    for rnd, q in enumerate(queries, 1):
        rid = request_id(gap_id, q, rnd)
        p = sd / f"{rid}.json"
        e = _load(p)
        base = {"request_id": rid, "gap_id": gap_id, "query": q, "round": rnd}
        if isinstance(e, dict) and e.get("status") == "DONE" and isinstance(e.get("candidates"), list):
            new, rej = e["candidates"], e.get("rejected", [])
        else:
            prev = e.get("attempts", 1) if isinstance(e, dict) and isinstance(e.get("attempts", 1), int) else 0
            fails += prev
            if fails >= MAX_FAILS:
                return _res("INCOMPLETE", "TOO_MANY_FAILURES", cands=cands, rej=rejected, rounds=rnd, action=ASK)
            sd.mkdir(parents=True, exist_ok=True)
            atomic_write(p, _dump({**base, "status": "PENDING", "attempts": prev + 1}))
            try:
                raw = search(q)
            except Exception:  # tool error: this round is INCOMPLETE, not a verdict
                raw = None
            if not isinstance(raw, list):
                atomic_write(p, _dump({**base, "status": "INCOMPLETE", "attempts": prev + 1}))
                fails += 1
                if fails >= MAX_FAILS:
                    return _res("INCOMPLETE", "TOO_MANY_FAILURES", cands=cands, rej=rejected, rounds=rnd, action=ASK)
                continue
            new, rej = [], []
            for i, c in enumerate(raw):
                x = _cand(c, rid)
                (new.append(x) if x else rej.append({"round": rnd, "index": i}))
            atomic_write(p, _dump({**base, "status": "DONE", "attempts": prev + 1, "candidates": new, "rejected": rej}))
        seen = {c["url"] for c in cands}
        for c in new:
            if c["url"] not in seen:
                seen.add(c["url"])
                cands.append(c)
        rejected += rej
        if len(cands) >= enough:
            return _res("COMPLETE", cands=cands, rej=rejected, rounds=rnd)
    return _res("PARTIAL", "ROUNDS_EXHAUSTED", gap_id, cands, rejected, len(queries))


def request(gap_id: Any, queries: Any, search: Callable[[str], Any] | None, ledger_dir: Any, enough: Any = 1) -> dict[str, Any]:
    try:
        return _run(gap_id, queries, search, ledger_dir, enough)
    except Exception:  # ledger/disk failure: not a verdict on the gap
        return _res("INCOMPLETE", "GUARD_ERROR", action=ASK)
