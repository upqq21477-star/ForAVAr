#!/usr/bin/env python3
"""R4R-S1 (FR-02) ADR validator + Brief decision selector + closure scenario. Standard library only.
Validates the records under docs/adr (start record docs/adr/0000-adr-format.md; P2-defined format, modelled on MADR 4 frontmatter plus hve-core style single-parent
supersession). It only validates and selects; it never edits ADRs and never owns Current.
Evidence level of --simulate is SIMULATED_PASS (temp mini repo, real validator + real selector)."""
from __future__ import annotations

import json
import re
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ADR_DIR = "docs/adr"
SLOTS = "P1-Central-Control/brief_slots.json"
STATUSES = ("proposed", "accepted", "deprecated", "superseded")
TRANSITIONS = {"proposed": {"accepted"}, "accepted": {"deprecated", "superseded"}, "deprecated": set(), "superseded": set()}
REQUIRED = ("id", "title", "status", "date", "decision-makers", "scope", "supersedes", "superseded-by",
            "reversal-condition", "links", "basis")
RESERVED_SCOPES = {"ALL", "NONE"}
NAME_RE = re.compile(r"^(\d{4})-[a-z0-9][a-z0-9-]*\.md$")
ID_RE = re.compile(r"^\d{4}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ADR_LINK_RE = re.compile(r"^ADR-(\d{4})$")


def _value(v: str):
    if v in ("null", "~"):
        return None
    if v.startswith("[") and v.endswith("]"):
        return [x.strip().strip("\"'") for x in v[1:-1].split(",") if x.strip()]
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    return v


def parse_frontmatter(text: str) -> tuple[dict | None, str]:
    lines = text.replace("\r\n", "\n").split("\n")
    if not lines or lines[0].strip() != "---":
        return None, text
    end = next((i for i in range(1, len(lines)) if lines[i].strip() == "---"), None)
    if end is None:
        return None, text
    fm: dict = {}
    for ln in lines[1:end]:
        if not ln.strip() or ln.lstrip().startswith("#"):
            continue
        if ":" not in ln:
            raise ValueError(ln.strip()[:40])
        k, _, v = ln.partition(":")
        fm[k.strip()] = _value(v.strip())
    return fm, "\n".join(lines[end + 1:])


def render(fm: dict, body: str = "") -> str:
    def f(v):
        return "null" if v is None else ("[" + ", ".join(v) + "]" if isinstance(v, list) else str(v))
    return "---\n" + "\n".join(f"{k}: {f(fm[k])}" for k in REQUIRED) + "\n---\n" + body


def transition_error(old: str, new: str) -> str | None:
    if old not in STATUSES or new not in STATUSES:
        return f"ADR_BAD_STATUS:{old}->{new}"
    return None if new in TRANSITIONS[old] else f"ADR_BAD_TRANSITION:{old}->{new}"


def load_adrs(root: Path = ROOT) -> tuple[dict, list[str]]:
    adrs: dict = {}
    errs: list[str] = []
    d = root / ADR_DIR
    for p in sorted(d.glob("*.md")) if d.is_dir() else []:
        m = NAME_RE.match(p.name)
        if not m:
            errs.append(f"ADR_BAD_FILENAME:{p.name}")
            continue
        try:
            fm, body = parse_frontmatter(p.read_text(encoding="utf-8"))
        except ValueError as e:
            errs.append(f"ADR_BAD_FRONTMATTER_LINE:{p.name}:{e}")
            continue
        if fm is None:
            errs.append(f"ADR_NO_FRONTMATTER:{p.name}")
            continue
        if fm.get("id") != m.group(1):
            errs.append(f"ADR_ID_FILENAME_MISMATCH:{p.name}")
        if str(fm.get("id")) in adrs:
            errs.append(f"ADR_DUPLICATE_ID:{p.name}")
            continue
        adrs[str(fm.get("id"))] = {"name": p.name, "fm": fm}
    return adrs, errs


def _routes(root: Path) -> set[str] | None:
    p = root / SLOTS
    return set(json.loads(p.read_text(encoding="utf-8")).get("routes", {})) if p.is_file() else None


def validate(root: Path = ROOT) -> list[str]:
    adrs, errs = load_adrs(root)
    routes = _routes(root)
    if "0000" not in adrs:
        errs.append("ADR_NO_START:0000")
    for i, a in adrs.items():
        fm, n = a["fm"], a["name"]
        for k in REQUIRED:
            if k not in fm:
                errs.append(f"ADR_MISSING_FIELD:{n}:{k}")
        if any(k not in fm for k in REQUIRED):
            continue
        if fm["status"] not in STATUSES:
            errs.append(f"ADR_BAD_STATUS:{n}:{fm['status']}")
        if not DATE_RE.match(str(fm["date"])):
            errs.append(f"ADR_BAD_DATE:{n}")
        dm = fm["decision-makers"]
        if not isinstance(dm, list) or not dm:
            errs.append(f"ADR_NO_DECISION_MAKERS:{n}")
        if not isinstance(fm["reversal-condition"], str) or len(fm["reversal-condition"].strip()) < 10:
            errs.append(f"ADR_EMPTY_REVERSAL:{n}")
        sc = fm["scope"]
        if not isinstance(sc, list) or not sc:
            errs.append(f"ADR_NO_SCOPE:{n}")
        elif routes is not None:
            errs += [f"ADR_SCOPE_UNKNOWN:{n}:{s}" for s in sc if s not in RESERVED_SCOPES and s not in routes]
        for link in fm["links"] if isinstance(fm["links"], list) else []:
            m = ADR_LINK_RE.match(link)
            if m and m.group(1) not in adrs:
                errs.append(f"ADR_LINK_DANGLING:{n}:{link}")
            elif not m and not link.startswith("http") and not (root / link.split("#")[0]).exists():
                errs.append(f"ADR_LINK_DANGLING:{n}:{link}")
        sup, by, st = fm["supersedes"], fm["superseded-by"], fm["status"]
        if st == "superseded" and by is None:
            errs.append(f"ADR_SUPERSEDED_NO_SUCCESSOR:{n}")
        if by is not None and st != "superseded":
            errs.append(f"ADR_SUPERSEDED_BY_STATUS_MISMATCH:{n}")
        if sup is not None:
            if sup == i:
                errs.append(f"ADR_SELF_SUPERSEDE:{n}")
            elif sup not in adrs:
                errs.append(f"ADR_SUPERSEDES_DANGLING:{n}:{sup}")
            elif st != "proposed":
                t = adrs[sup]["fm"]
                if t.get("status") != "superseded" or t.get("superseded-by") != i:
                    errs.append(f"ADR_SUPERSEDES_NOT_RECIPROCAL:{n}->{adrs[sup]['name']}")
        if by is not None:
            if by not in adrs:
                errs.append(f"ADR_SUPERSEDED_BY_DANGLING:{n}:{by}")
            else:
                s = adrs[by]["fm"]
                if s.get("supersedes") != i:
                    errs.append(f"ADR_SUPERSEDED_BY_NOT_RECIPROCAL:{n}")
                if s.get("status") == "proposed":
                    errs.append(f"ADR_SUCCESSOR_NOT_ACCEPTED:{n}")
    targets = [a["fm"].get("supersedes") for a in adrs.values() if a["fm"].get("supersedes")]
    errs += [f"ADR_MULTIPLE_SUPERSEDERS:{t}" for t in sorted({t for t in targets if targets.count(t) > 1})]
    for i, a in adrs.items():
        seen, cur = {i}, a["fm"].get("supersedes")
        while cur in adrs:
            if cur in seen:
                errs.append(f"ADR_SUPERSEDES_CYCLE:{i}")
                break
            seen.add(cur)
            cur = adrs[cur]["fm"].get("supersedes")
    return errs


def brief_decisions(root: Path = ROOT, route: str = "", limit: int = 5) -> list[str]:
    """Brief decisions[]: only accepted ADRs whose scope has the route (or ALL); superseded/deprecated = history."""
    adrs, _ = load_adrs(root)
    rows = []
    for i, a in adrs.items():
        fm = a["fm"]
        sc = fm.get("scope") if isinstance(fm.get("scope"), list) else []
        if fm.get("status") == "accepted" and ("ALL" in sc or route in sc):
            rows.append((i, f"ADR-{i} {fm.get('title', '')} | reversal: {fm.get('reversal-condition', '')}"[:160]))
    return [r for _, r in sorted(rows, reverse=True)[:limit]]


def _fm(i, status, title, sup=None, by=None, scope=("ALL",)):
    return {"id": i, "title": title, "status": status, "date": "2026-10-15", "decision-makers": ["sim"],
            "scope": list(scope), "supersedes": sup, "superseded-by": by,
            "reversal-condition": "reverse when the simulated premise no longer holds", "links": [], "basis": "simulation"}


def simulate() -> list[str]:
    """Closure scenario producer -> consumer -> verifier -> feedback. Returns failures ([] = SIMULATED_PASS)."""
    fails: list[str] = []
    mini = Path(tempfile.mkdtemp(prefix="adr-sim-"))
    try:
        d = mini / ADR_DIR
        d.mkdir(parents=True)
        def put(i, name, **kw):
            (d / f"{i}-{name}.md").write_text(render(_fm(i, **kw), "body\n"), encoding="utf-8")

        def step(label, cond):
            if not cond:
                fails.append(label)
        put("0001", "first", status="accepted", title="first decision")                                   # producer
        put("0000", "start", status="accepted", title="start", scope=("NONE",))
        step("producer_valid", validate(mini) == [])                                                       # verifier
        step("consumer_sees_first", any(x.startswith("ADR-0001") for x in brief_decisions(mini, "BUILD")))  # consumer
        put("0002", "second", status="accepted", title="second decision", sup="0001")                       # producer: forgot to retire 0001
        step("verifier_catches_missing_retire", any(e.startswith("ADR_SUPERSEDES_NOT_RECIPROCAL") for e in validate(mini)))
        step("transition_rule_blocks_reuse", transition_error("superseded", "accepted") is not None)
        step("transition_rule_allows_retire", transition_error("accepted", "superseded") is None)
        put("0001", "first", status="superseded", title="first decision", by="0002")                        # feedback: fix the old one
        step("verifier_ok_after_fix", validate(mini) == [])
        ids = [x[:8] for x in brief_decisions(mini, "BUILD")]
        step("consumer_drops_superseded", ids == ["ADR-0002"])                                              # feedback reaches the Brief
        step("route_filter", brief_decisions(mini, "BUILD") == brief_decisions(mini, "DISCUSS"))
    finally:
        shutil.rmtree(mini, ignore_errors=True)
    return fails


def main(argv: list[str]) -> int:
    if "--simulate" in argv:
        f = simulate()
        print("SIMULATED_PASS" if not f else f"FAIL {f}")
        return 1 if f else 0
    if "--transition" in argv:
        i = argv.index("--transition")
        e = transition_error(argv[i + 1], argv[i + 2])
        print(e or "OK")
        return 1 if e else 0
    errs = validate()
    print("\n".join(errs) if errs else f"adr OK ({len(load_adrs()[0])} records)")
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
