#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from capability_router import route as resolve_capability_route
from command_layer import (
    execute_command,
    execute_command_sequence,
    initialize_command_state,
    result_command_types,
    result_terminal_state,
    validate_result,
)
from event_log import EventLog
from event_reducer import log_segment_change
from packet_layer import validate_result_packet, validate_task_packet
from execution_truth import (
    bind_attempt_result,
    build_execution_record,
    cancel_execution,
    classify_late_result,
    finalize_execution,
    timeout_execution,
)
from parallel_scheduler import (
    accept_result,
    aggregate_decision,
    brain_pending,
    cancel_segment,
    propagate_dependency_failure,
    requeue_brain_pending,
    start_available,
    timeout_due,
)
from result_distillation import distill_result
from brain_input import build_brain_input_packet, is_input_request
from brain_proposal import materialize_command, prepare_intent_handoff, validate_proposal_against_state
from state_transition import ACCEPTED
import task_set as task_set_mod
from state_machine_runtime_gate import require_non_terminal


STATUSES = {
    "CREATED", "READY", "DISPATCHED", "RUNNING",
    "WAITING_RESULT", "RESULT_RECEIVED", "ROUTING_NEXT",
    "COMPLETE", "BLOCK", "UNRESOLVED"
}
RESULT_STATUSES = {"WORK_COMPLETE", "UNRESOLVED", "BLOCK", "FAIL"}


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def load(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path: str, value: dict[str, Any]) -> None:
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def require_work_segment(segment: dict[str, Any]) -> None:
    required = (
        "segment_id", "workflow_id", "system_id", "skill_id", "skill_version", "objective",
        "input_scope", "input_refs", "requested_outputs",
        "constraints", "stop_condition", "failure_condition",
        "dependency_refs", "completion_contract", "execution_record_ref", "context_cohort_id",
        "context_budget", "retry_policy", "timeout_ms"
    )
    missing = [key for key in required if key not in segment]
    if missing:
        raise ValueError("Work Segment 缺少必要欄位: " + ", ".join(missing))
    if not segment["requested_outputs"]:
        raise ValueError("Work Segment 必須有 requested_outputs")
    if not segment["completion_contract"].get("handoff_allowed", False):
        raise ValueError("Work Segment completion_contract 必須允許完成後交接")
    budget = segment["context_budget"]
    required_budget_keys = ("estimated_total_context", "target_context_budget", "hard_context_ceiling", "risk")
    missing_budget = [key for key in required_budget_keys if key not in budget]
    if missing_budget:
        raise ValueError("context_budget 缺少必要欄位: " + ", ".join(missing_budget))
    if budget["target_context_budget"] >= budget["hard_context_ceiling"]:
        raise ValueError("target_context_budget 必須小於 hard_context_ceiling")
    if budget["estimated_total_context"] > budget["hard_context_ceiling"] or budget["risk"] == "BLOCK":
        raise ValueError("Work Segment 超過 Context hard ceiling 或已被標記 BLOCK")
    retry_policy = segment["retry_policy"]
    if not 1 <= int(retry_policy["max_attempts"]) <= 10:
        raise ValueError("retry_policy.max_attempts 必須為 1..10")
    if not set(retry_policy["retry_on"]).issubset({"FAIL", "TIMEOUT"}):
        raise ValueError("retry_policy.retry_on 不合法")
    if int(segment["timeout_ms"]) < 1:
        raise ValueError("timeout_ms 必須 > 0")


def init_state(workflow_id: str, task_id: str, conversation_analysis_report_ref: str | None = None) -> dict[str, Any]:
    state = {
        "workflow_id": workflow_id,
        "task_id": task_id,
        "active_segments": [],
        "queued_segments": [],
        "attempt_counters": {},
        "scheduler_max_concurrency": 4,
        "retry_count": 0,
        "timeout_count": 0,
        "late_result_count": 0,
        "cancel_count": 0,
        "completed_segments": [],
        "result_refs": [],
        "recent_distillation_refs": [],
        "conversation_analysis_report_ref": conversation_analysis_report_ref,
        "evidence_refs": [],
        "provenance_refs": [],
        "gaps": [],
        "unresolved": [],
        "handoff_history": [],
        "created_at": now_iso(),
    }
    state.update(initialize_command_state(workflow_id))
    return state



def prepare_brain_intent_handoff(
    state: dict[str, Any],
    intent_result: dict[str, Any],
) -> dict[str, Any]:
    """Build the input packet from the supplied canonical workflow state and bind intent to it.

    This operation is read-only. Any later Brain Proposal must still be checked against the
    same state revision by validate_proposal_against_state and then committed through Central.
    """
    packet = build_brain_input_packet(state, trigger="EXTERNAL_INPUT")
    return prepare_intent_handoff(intent_result, state, packet)


def commit_brain_proposal(
    state: dict[str, Any],
    proposal: dict[str, Any],
    *,
    event_log: EventLog | None = None,
    segment_store: dict[str, dict[str, Any]] | None = None,
    packet: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Brain 提案 → 驗證（allowed_*）→ Command → 執行。

    - ASK_INPUT：不改狀態、不寫 Event Log，回 INPUT_REQUESTED（等外部輸入後由新封包再提案）。
    - RESUME 且有 segment 停在 NEEDS_BRAIN：RESUME 成功後把這些 segment 重新排入（需 segment_store），
      再由 dispatch 起跑；RESUME 被拒時不動 queue。
    """
    require_non_terminal(state)
    if event_log is None:
        raise ValueError("P9 Brain Proposal 提交要求外部 Event Log")

    validate_proposal_against_state(state, proposal, packet=packet)
    if is_input_request(proposal):
        return deepcopy(state), {
            "status": "INPUT_REQUESTED",
            "proposal_id": proposal["proposal_id"],
            "next": "WAIT_FOR_INPUT",
        }
    command = materialize_command(state, proposal, actor_id="COMMANDER", packet=packet)
    resume_brain = command["command_type"] == "RESUME" and brain_pending(state)
    rulings = proposal.get("segment_rulings")
    if resume_brain and rulings is None:
        raise ValueError("BRAIN_RESUME_REQUIRES_RULINGS")
    if not resume_brain and rulings is not None:
        raise ValueError("PROPOSAL_RULINGS_NOT_APPLICABLE")
    if resume_brain and segment_store is None and any(r["ruling"] == "REQUEUE" for r in rulings):
        raise ValueError("BRAIN_RESUME_REQUIRES_SEGMENT_STORE")
    if resume_brain:  # 先驗證裁決完整性（RESUME 前；不合法則狀態不變）
        task_set_mod.rule_segments(state, rulings, proposal_id=proposal["proposal_id"])
    updated, result = execute_command(
        state,
        command,
        event_log=event_log,
        has_queued_work=bool(state.get("queued_segments")),
    )
    if resume_brain and result["status"] == ACCEPTED:
        cause = f"BRAIN_PROPOSAL:{proposal['proposal_id']}"
        ruled, requeue_ids = task_set_mod.rule_segments(updated, rulings, proposal_id=proposal["proposal_id"])
        _log_segments(event_log, updated, ruled, "SEGMENT_RULED", cause)
        after_rulings = ruled
        if requeue_ids:
            after_rulings, _ = requeue_brain_pending(ruled, segment_store or {}, only=set(requeue_ids))
            _log_segments(event_log, ruled, after_rulings, "SEGMENT_QUEUED", cause)
        before = after_rulings
        updated = propagate_dependency_failure(after_rulings)
        _log_segments(event_log, before, updated, "SEGMENT_DEPENDENCY_BLOCKED", cause)
        if updated.get("queued_segments"):
            result["next"] = "DISPATCH_READY"
        else:  # 無工作可派：以聚合結果走既有結果路由表（不新增分支）
            decision = aggregate_decision(updated) or "BLOCK"  # 全數放棄且無任何結果＝無法完成
            commands = result_command_types(updated, decision, has_queued_work=False)
            if commands:
                updated, _ = execute_command_sequence(updated, commands, event_log=event_log, caused_by=cause,
                                                      correlation_id=f"CORR:{updated['workflow_id']}")
                terminal = result_terminal_state(decision)
                if terminal is not None:
                    updated["terminal_state"] = terminal
            result["next"] = "WORKFLOW_TERMINAL" if updated.get("terminal_state") else "NONE"
        validate_result(result)
    return updated, result


def issue_task_set(
    state: dict[str, Any],
    control_output: dict[str, Any],
    *,
    segment_store: dict[str, dict[str, Any]],
    event_log: EventLog,
    execution_store: dict[str, dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """U-6：TASK_SET_ISSUED → 登錄 Task Set、作廢被取代的舊任務（active 者經既有 cancel）、排入新任務。

    Workflow 狀態不變；之後由 Brain 以 START／RESUME 推進（allowed_* 內）。
    """
    require_non_terminal(state)
    plan = task_set_mod.plan_issue(state, control_output, segment_store)
    if plan["active_void_ids"] and execution_store is None:
        raise ValueError("TASK_SET_SUPERSEDE_ACTIVE_REQUIRES_EXECUTION_STORE")
    cause = f"TASK_SET:{plan['record']['task_set_id']}"
    for sid in plan["active_void_ids"]:
        state, _ = cancel(state, sid, reason="SUPERSEDED_BY_TASK_SET", execution_store=execution_store, event_log=event_log)
    before = state
    state = task_set_mod.void(state, plan["void_ids"], "SUPERSEDED", cause)
    state = task_set_mod.apply_record(state, plan["record"])
    _log_segments(event_log, before, state, "SEGMENT_TASK_SET_ISSUED", cause)
    for segment in plan["segments"]:
        state = queue_segment(state, segment, event_log=event_log)
    return state


def apply_control_output(
    state: dict[str, Any],
    control_output: dict[str, Any],
    *,
    segment_store: dict[str, dict[str, Any]],
    event_log: EventLog,
    execution_store: dict[str, dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Control 輸出的唯一入口：只有 TASK_SET_ISSUED 改 State；其餘回報，不推進（交 Brain／人）。"""
    task_set_mod.validate_control_output(control_output)
    code = control_output["decision_code"]
    if code == "TASK_SET_ISSUED":
        updated = issue_task_set(state, control_output, segment_store=segment_store,
                                 event_log=event_log, execution_store=execution_store)
        return updated, {"status": "TASK_SET_ISSUED", "task_set_ref": control_output["task_set_ref"]}
    return deepcopy(state), {"status": code}


def queue_segment(
    state: dict[str, Any],
    segment: dict[str, Any],
    *,
    event_log: EventLog | None = None,
) -> dict[str, Any]:
    require_work_segment(segment)
    if segment["workflow_id"] != state["workflow_id"]:
        raise ValueError("segment workflow_id 與 Central State 不一致")
    require_non_terminal(state)
    if any(x.get("segment_id") == segment["segment_id"] for x in state["queued_segments"]):
        raise ValueError("segment_id 已在 queue")
    if any(
        item.get("segment_id") == segment["segment_id"]
        for item in state.get("active_segments", [])
    ):
        raise ValueError("segment 已經是 active segment")

    before = state
    state = deepcopy(state)
    state["queued_segments"].append(deepcopy(segment))
    if event_log is not None:
        _log_segments(event_log, before, state, "SEGMENT_QUEUED", f"SEGMENT:{segment['segment_id']}")
    return state


def _log_segments(
    event_log: EventLog,
    before: dict[str, Any],
    after: dict[str, Any],
    event_type: str,
    causation_id: str,
    *,
    now: str | None = None,
) -> None:
    """D11：Segment 狀態變更一律寫入 Event Log（Execution Store 可丟棄，狀態可由 Log 重建）。"""
    log_segment_change(
        event_log,
        before,
        after,
        event_type=event_type,
        causation_id=causation_id,
        occurred_at=now or now_iso(),
    )


def _register_executions(
    task_packets: list[dict[str, Any]],
    attempts: list[dict[str, Any]],
    execution_store: dict[str, dict[str, Any]],
) -> None:
    for packet, attempt in zip(task_packets, attempts):
        execution = build_execution_record(
            packet,
            started_at=attempt["started_at"],
        )
        execution_store[execution["execution_record_ref"]] = {
            "execution_record": execution,
            "attempt": attempt,
            "task_packet": packet,
        }


def dispatch(
    state: dict[str, Any],
    *,
    event_log: EventLog | None = None,
    max_concurrency: int | None = None,
    execution_store: dict[str, dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    require_non_terminal(state)
    if event_log is None:
        raise ValueError("P5 Parallel Scheduler 要求 dispatch 提供外部 Event Log")
    if execution_store is None:
        raise ValueError("P6 Execution Truth 要求 dispatch 提供外部 Execution Store")

    if state["status"] not in {"READY", "RUNNING"}:
        raise ValueError(
            f"目前 Workflow 狀態 {state['status']} 不允許 scheduler dispatch"
        )
    if not state.get("queued_segments") and not state.get("active_segments"):
        raise ValueError("沒有可排程的 Work Segment")

    before_segments = state
    state, task_packets, attempts = start_available(
        state,
        max_concurrency=max_concurrency,
        include_attempts=True,
    )
    if task_packets:
        _log_segments(event_log, before_segments, state, "SEGMENT_STARTED", "SCHEDULER:START")
    if not task_packets:
        if state.get("active_segments"):
            return state, []
        if state != before_segments and any(
            item.get("reason_code") == "ATTEMPT_LIMIT_EXCEEDED"
            for item in state.get("completed_segments", [])
        ):
            _log_segments(
                event_log, before_segments, state,
                "SEGMENT_ATTEMPT_LIMIT_BLOCKED", "SCHEDULER:START"
            )
            return state, []
        raise ValueError(
            "目前沒有 dependency satisfied 且可用 concurrency slot 的 Work Segment"
        )

    for packet, attempt in zip(task_packets, attempts):
        execution = build_execution_record(
            packet,
            started_at=attempt["started_at"],
        )
        execution_store[execution["execution_record_ref"]] = {
            "execution_record": execution,
            "attempt": attempt,
            "task_packet": packet,
        }

    if state["status"] == "READY":
        state, command_results = execute_command_sequence(
            state,
            ["START"],
            event_log=event_log,
            caused_by="SCHEDULER:START",
            correlation_id=f"CORR:{state['workflow_id']}",
        )

    return state, task_packets


def receive_result_and_schedule(
    state: dict[str, Any],
    result: dict[str, Any],
    *,
    event_log: EventLog | None = None,
    segment_store: dict[str, dict[str, Any]] | None = None,
    execution_store: dict[str, dict[str, Any]] | None = None,
    distillation_store: dict[str, dict[str, Any]] | None = None,
    semantic_input: dict[str, Any] | None = None,
    evidence_records: list[dict[str, Any]] | None = None,
    provenance_records: list[dict[str, Any]] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    validate_result_packet(result)
    if execution_store is None:
        raise ValueError("P6 Execution Truth 要求 receive 提供外部 Execution Store")
    if distillation_store is None:
        raise ValueError("P8 Result Distillation 要求 receive 提供外部 Distillation Store")
    if event_log is None:
        raise ValueError("P5 Parallel Scheduler 要求 receive 提供外部 Event Log")
    # Stage all externally supplied stores. If scheduler validation, event append,
    # or subsequent planning fails, caller-owned stores remain unchanged.
    staged_execution_store = deepcopy(execution_store)
    staged_distillation_store = deepcopy(distillation_store)

    def commit_stores() -> None:
        execution_store.clear()
        execution_store.update(staged_execution_store)
        distillation_store.clear()
        distillation_store.update(staged_distillation_store)

    envelope = staged_execution_store.get(result["execution_record_ref"])
    if envelope is None:
        raise ValueError("找不到 ResultPacket 對應的 ExecutionRecord")
    result_cause = f"RESULT_PACKET:{result['result_id']}"
    if result["decision_code"] == "WORK_COMPLETE":
        if evidence_records is None or provenance_records is None:
            raise ValueError(
                "WORK_COMPLETE 必須提供結構化 Evidence / Provenance Records"
            )
    execution = envelope["execution_record"]
    task_packet = envelope["task_packet"]
    attempt = envelope["attempt"]

    # A result for an already-finished execution must be routed through the
    # existing Scheduler late-result path before Execution Truth finalization.
    # This prevents duplicate/late results from being treated as a second
    # execution while preserving the single canonical runtime owners.
    if execution["status"] == "RUNNING":
        # 首次 finalization 會修改 workflow；terminal 後仍禁止。
        require_non_terminal(state)
    if execution["status"] != "RUNNING":
        # 已完成 execution 的重複/晚到結果只走 late-result 記錄路徑，
        # 允許在 terminal workflow 上進行（不 finalize、不改 workflow status）。
        # 但必須先與既有 Execution Truth 對照：重複 / 結束後無結果的晚到結果可記錄；
        # 與 truth 衝突者在任何 store 被寫入前即拒絕，避免 distillation / Current
        # 與 Execution Truth 分歧。這裡只讀 truth，不建立第二套 late-result 狀態機。
        classify_late_result(execution, attempt, task_packet, result)
        active_match = any(
            item.get("segment_id") == result["segment_id"]
            and item.get("attempt_id") == result["attempt_id"]
            for item in state.get("active_segments", [])
        )
        if active_match:
            raise ValueError(
                "ExecutionRecord 非 RUNNING 但 Attempt 仍為 active；"
                "Execution/Scheduler truth 發生衝突"
            )

        distillation = distill_result(
            result,
            semantic_input=semantic_input,
        )
        existing_distillation = staged_distillation_store.get(distillation["object_id"])
        if (
            existing_distillation is not None
            and existing_distillation["content_hash"] != distillation["content_hash"]
        ):
            raise ValueError("相同 DistillationRecord object_id 內容不同")

        before_segments = state
        state, scheduler_outcome = accept_result(
            state,
            result,
            segment_store=segment_store,
        )
        if scheduler_outcome != "LATE_RESULT":
            raise ValueError(
                "已結束 Execution 的結果必須走 LATE_RESULT；"
                f"Scheduler 回報 {scheduler_outcome}，Execution/Scheduler truth 發生衝突"
            )
        _log_segments(event_log, before_segments, state, "SEGMENT_RESULT_ACCEPTED", result_cause)
        # 所有拒絕條件都已通過；此時才寫入 store。
        if existing_distillation is None:
            staged_distillation_store[distillation["object_id"]] = distillation
        state = deepcopy(state)
        recent = [
            ref for ref in state.get("recent_distillation_refs", [])
            if ref != distillation["object_id"]
        ]
        state["recent_distillation_refs"] = (
            recent + [distillation["object_id"]]
        )[-16:]
        commit_stores()
        return state, []

    finalized_execution = finalize_execution(
        execution,
        task_packet,
        result,
        evidence_records=evidence_records,
        provenance_records=provenance_records,
    )
    staged_execution_store[result["execution_record_ref"]]["execution_record"] = finalized_execution
    staged_execution_store[result["execution_record_ref"]]["attempt"] = bind_attempt_result(
        attempt,
        result,
        finalized_execution,
    )

    distillation = distill_result(
        result,
        semantic_input=semantic_input,
    )
    existing_distillation = staged_distillation_store.get(distillation["object_id"])
    if existing_distillation is not None:
        if existing_distillation["content_hash"] != distillation["content_hash"]:
            raise ValueError("相同 DistillationRecord object_id 內容不同")
    else:
        staged_distillation_store[distillation["object_id"]] = distillation

    before_segments = state
    state, scheduler_outcome = accept_result(
        state,
        result,
        segment_store=segment_store,
    )
    _log_segments(event_log, before_segments, state, "SEGMENT_RESULT_ACCEPTED", result_cause)

    if scheduler_outcome == "LATE_RESULT":
        state = deepcopy(state)
        recent = [
            ref for ref in state.get("recent_distillation_refs", [])
            if ref != distillation["object_id"]
        ]
        state["recent_distillation_refs"] = (recent + [distillation["object_id"]])[-16:]
        commit_stores()
        return state, []

    state = deepcopy(state)
    state["result_refs"].append(result["result_id"])
    recent = [
        ref for ref in state.get("recent_distillation_refs", [])
        if ref != distillation["object_id"]
    ]
    state["recent_distillation_refs"] = (recent + [distillation["object_id"]])[-16:]
    state["evidence_refs"] = sorted(
        set(state["evidence_refs"]) | set(result["evidence_refs"])
    )
    state["provenance_refs"] = sorted(
        set(state["provenance_refs"]) | set(result["provenance_refs"])
    )
    state["unresolved"] = deepcopy(result["unresolved"])

    # completed_segments 的唯一寫入者是 parallel_scheduler.accept_result / timeout_due（D2）。
    # 依賴終局失敗的 queued segment 在此移出佇列，避免 workflow 永遠 RUNNING（D10）。
    before_segments = state
    state = propagate_dependency_failure(state)
    _log_segments(event_log, before_segments, state, "SEGMENT_DEPENDENCY_BLOCKED", result_cause)

    # Every completed/failed attempt frees a concurrency slot.
    # Refill from the canonical queued segments; retry uses the same path.
    before_segments = state
    state, next_task_packets, next_attempts = start_available(
        state,
        max_concurrency=state.get("scheduler_max_concurrency", 4),
        include_attempts=True,
    )
    if next_task_packets:
        _log_segments(event_log, before_segments, state, "SEGMENT_STARTED", result_cause)
        _register_executions(next_task_packets, next_attempts, staged_execution_store)

    has_active_work = bool(state.get("active_segments"))
    # 「無剩餘工作」＝無 active 且（無 queued 或停在等 Brain）；終態只在此時成立，
    # 依全部 segment 的最終結果聚合（D1）。
    idle = not has_active_work and (not state.get("queued_segments") or brain_pending(state))
    effective_decision = result["decision_code"]
    if idle:
        effective_decision = aggregate_decision(state) or effective_decision
    command_types = result_command_types(
        state,
        effective_decision,
        has_queued_work=bool(state.get("queued_segments")) and not idle,
        has_active_work=has_active_work,
    )
    if command_types:
        state, _ = execute_command_sequence(
            state,
            command_types,
            event_log=event_log,
            caused_by=f"RESULT_PACKET:{result['result_id']}",
            correlation_id=f"CORR:{state['workflow_id']}",
        )

    if idle:
        terminal = result_terminal_state(effective_decision)
        if terminal is not None:
            state["terminal_state"] = terminal

    commit_stores()
    return state, next_task_packets


def receive_result(
    state: dict[str, Any],
    result: dict[str, Any],
    *,
    event_log: EventLog | None = None,
    segment_store: dict[str, dict[str, Any]] | None = None,
    execution_store: dict[str, dict[str, Any]] | None = None,
    distillation_store: dict[str, dict[str, Any]] | None = None,
    semantic_input: dict[str, Any] | None = None,
    evidence_records: list[dict[str, Any]] | None = None,
    provenance_records: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    state, _ = receive_result_and_schedule(
        state,
        result,
        event_log=event_log,
        segment_store=segment_store,
        execution_store=execution_store,
        distillation_store=distillation_store,
        semantic_input=semantic_input,
        evidence_records=evidence_records,
        provenance_records=provenance_records,
    )
    return state


def check_timeouts(
    state: dict[str, Any],
    *,
    now: str | None = None,
    segment_store: dict[str, dict[str, Any]] | None = None,
    execution_store: dict[str, dict[str, Any]] | None = None,
    event_log: EventLog | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if execution_store is None:
        raise ValueError("P6 Execution Truth 要求 timeout 提供外部 Execution Store")
    before_segments = state
    state, timed_out = timeout_due(
        state,
        segment_store=segment_store,
        now=now,
    )
    for active in timed_out:
        ref = f"EXECUTION:exec-{active['attempt_id']}"
        envelope = execution_store.get(ref)
        if envelope is None:
            raise ValueError("Timeout 缺少對應 ExecutionRecord")
        envelope["execution_record"] = timeout_execution(envelope["execution_record"], ended_at=now)
        envelope["attempt"]["status"] = "TIMEOUT"
        envelope["attempt"]["ended_at"] = envelope["execution_record"]["end_time"]

    if timed_out:
        if event_log is not None:
            _log_segments(event_log, before_segments, state, "SEGMENT_TIMED_OUT",
                          f"ATTEMPT:{timed_out[0]['attempt_id']}", now=now)
        before_segments = state
        state, task_packets, attempts = start_available(
            state,
            max_concurrency=state.get("scheduler_max_concurrency", 4),
            now=now,
            include_attempts=True,
        )
        if task_packets and event_log is not None:
            _log_segments(event_log, before_segments, state, "SEGMENT_STARTED",
                          f"ATTEMPT:{timed_out[0]['attempt_id']}", now=now)
        _register_executions(task_packets, attempts, execution_store)
    return state, timed_out


def cancel(
    state: dict[str, Any],
    segment_id: str,
    *,
    reason: str = "CANCELLED_BY_COMMAND",
    execution_store: dict[str, dict[str, Any]] | None = None,
    event_log: EventLog | None = None,
) -> tuple[dict[str, Any], str]:
    if execution_store is None:
        raise ValueError("P6 Execution Truth 要求 cancel 提供外部 Execution Store")
    before_segments = state
    active = next(
        (item for item in state.get("active_segments", [])
         if item.get("segment_id") == segment_id),
        None,
    )
    state, outcome = cancel_segment(state, segment_id, reason=reason)
    if outcome == "CANCELLED" and event_log is not None:
        _log_segments(event_log, before_segments, state, "SEGMENT_CANCELLED", f"SEGMENT:{segment_id}")
    if active is not None:
        ref = f"EXECUTION:exec-{active['attempt_id']}"
        envelope = execution_store.get(ref)
        if envelope is None:
            raise ValueError("Cancel 缺少對應 ExecutionRecord")
        envelope["execution_record"] = cancel_execution(envelope["execution_record"])
        envelope["attempt"]["status"] = "CANCELLED"
        envelope["attempt"]["ended_at"] = envelope["execution_record"]["end_time"]
        envelope["attempt"]["cancel_reason"] = reason
    return state, outcome


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Central Controller")
    sub = parser.add_subparsers(dest="command", required=True)

    p_route = sub.add_parser("route-plan")
    p_route.add_argument("task")
    p_route.add_argument("function_registry")
    p_route.add_argument("cohort_registry")
    p_route.add_argument("output")
    p_route.add_argument("--system-profile", action="append", dest="system_profiles", default=[])

    p_init = sub.add_parser("init")
    p_init.add_argument("workflow_id")
    p_init.add_argument("task_id")
    p_init.add_argument("output")
    p_init.add_argument("--conversation-analysis-report")

    p_intent_handoff = sub.add_parser("intent-handoff")
    p_intent_handoff.add_argument("state")
    p_intent_handoff.add_argument("intent_resolution")
    p_intent_handoff.add_argument("output")


    p_queue = sub.add_parser("queue")
    p_queue.add_argument("state")
    p_queue.add_argument("segment")
    p_queue.add_argument("output")
    p_queue.add_argument("--event-log", help="提供時，queue 事件同時寫入 Event Log（D11）")

    p_dispatch = sub.add_parser("dispatch")
    p_dispatch.add_argument("state")
    p_dispatch.add_argument("output")
    p_dispatch.add_argument("task_packet_output")
    p_dispatch.add_argument("--event-log", required=True)
    p_dispatch.add_argument("--max-concurrency", type=int)
    p_dispatch.add_argument("--execution-envelope-output", required=True)

    p_receive = sub.add_parser("receive")
    p_receive.add_argument("state")
    p_receive.add_argument("result_packet")
    p_receive.add_argument("output")
    p_receive.add_argument("--event-log", required=True)
    p_receive.add_argument("--execution-envelope", required=True)
    p_receive.add_argument("--evidence-records", required=True)
    p_receive.add_argument("--provenance-records", required=True)
    p_receive.add_argument("--distillation-envelope-output", required=True)
    p_receive.add_argument("--distillation-input")
    p_receive.add_argument("--task-packet-output")
    p_receive.add_argument("--execution-envelope-output")

    args = parser.parse_args()

    if args.command == "route-plan":
        task = load(args.task)
        function_registry = load(args.function_registry)
        cohort_registry = load(args.cohort_registry)
        system_profiles = [load(path) for path in args.system_profiles]
        result = resolve_capability_route(task, function_registry, cohort_registry, system_profiles)
        save(args.output, result)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("status") == "PASS" else 3

    if args.command == "init":
        state = init_state(args.workflow_id, args.task_id, args.conversation_analysis_report)
        save(args.output, state)
        print(json.dumps({"status": "PASS", "state": args.output}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "intent-handoff":
        state = load(args.state)
        intent_result = load(args.intent_resolution)
        handoff = prepare_brain_intent_handoff(state, intent_result)
        save(args.output, handoff)
        print(json.dumps(handoff, ensure_ascii=False, indent=2))
        return 0 if handoff.get("status") == "READY_FOR_BRAIN_PROPOSAL" else 2

    state = load(args.state)

    if args.command == "queue":
        state = queue_segment(
            state,
            load(args.segment),
            event_log=EventLog(args.event_log) if args.event_log else None,
        )
        save(args.output, state)
        print(json.dumps({"status": "PASS", "queued": len(state["queued_segments"])}, ensure_ascii=False, indent=2))
        return 0

    if args.command == "dispatch":
        before_dispatch_state = deepcopy(state)
        execution_store: dict[str, dict[str, Any]] = {}
        state, task_packets = dispatch(
            state,
            event_log=EventLog(args.event_log),
            max_concurrency=args.max_concurrency,
            execution_store=execution_store,
        )
        save(args.output, state)
        Path(args.execution_envelope_output).write_text(
            json.dumps(
                list(execution_store.values()),
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
        Path(args.task_packet_output).write_text(
            json.dumps(task_packets, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        old_blocked = {
            (item.get("segment_id"), item.get("reason_code"))
            for item in before_dispatch_state.get("completed_segments", [])
            if item.get("reason_code")
        }
        new_blocked = [
            item for item in state.get("completed_segments", [])
            if item.get("reason_code") and (item.get("segment_id"), item.get("reason_code")) not in old_blocked
        ]
        dispatch_status = "BLOCK" if not task_packets and new_blocked else "PASS"
        print(
            json.dumps(
                {
                    "status": dispatch_status,
                    "task_packet_count": len(task_packets),
                    "active_segment_count": len(state.get("active_segments", [])),
                    "task_packet_ids": [packet["packet_id"] for packet in task_packets],
                    "newly_blocked_segments": [
                        {"segment_id": item.get("segment_id"), "reason_code": item.get("reason_code")}
                        for item in new_blocked
                    ],
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        return 3 if dispatch_status == "BLOCK" else 0

    if args.command == "receive":
        envelopes = load(args.execution_envelope)
        execution_store = {
            item["execution_record"]["execution_record_ref"]: item
            for item in envelopes
        }
        evidence_records = load(args.evidence_records)["records"]
        provenance_records = load(args.provenance_records)["records"]
        distillation_store: dict[str, dict[str, Any]] = {}
        semantic_input = (
            load(args.distillation_input)
            if args.distillation_input
            else None
        )
        state, next_task_packets = receive_result_and_schedule(
            state,
            load(args.result_packet),
            event_log=EventLog(args.event_log),
            execution_store=execution_store,
            distillation_store=distillation_store,
            semantic_input=semantic_input,
            evidence_records=evidence_records,
            provenance_records=provenance_records,
        )
        save(args.output, state)
        Path(args.distillation_envelope_output).write_text(
            json.dumps(
                list(distillation_store.values()),
                ensure_ascii=False,
                indent=2,
            ) + "\n",
            encoding="utf-8",
        )
        if args.task_packet_output:
            Path(args.task_packet_output).write_text(
                json.dumps(next_task_packets, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        if args.execution_envelope_output:
            Path(args.execution_envelope_output).write_text(
                json.dumps(list(execution_store.values()), ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        print(json.dumps({
            "status": "PASS",
            "central_status": state["status"],
            "terminal_state": state["terminal_state"],
            "next_task_packet_count": len(next_task_packets),
        }, ensure_ascii=False, indent=2))
        return 0

    return 3


if __name__ == "__main__":
    raise SystemExit(main())