#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
import os
from copy import deepcopy
from pathlib import Path
from typing import Any, Iterable

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
EVENT_SCHEMA_PATH = SCHEMA_DIR / "event.schema.json"
COMMON_SCHEMA_PATH = SCHEMA_DIR / "canonical_common.schema.json"
IDENTITY_SCHEMA_PATH = SCHEMA_DIR / "canonical_identity.schema.json"


def _schema_registry() -> Registry:
    registry = Registry()
    for path in (IDENTITY_SCHEMA_PATH, COMMON_SCHEMA_PATH, EVENT_SCHEMA_PATH):
        schema = json.loads(path.read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"],
            Resource.from_contents(schema),
        )
    return registry


def validate_event(event: dict[str, Any]) -> None:
    Draft202012Validator.check_schema(
        json.loads(EVENT_SCHEMA_PATH.read_text(encoding="utf-8"))
    )
    validator = Draft202012Validator(
        json.loads(EVENT_SCHEMA_PATH.read_text(encoding="utf-8")),
        registry=_schema_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(validator.iter_errors(event), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            "Event Schema 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def _event_key_digest(
    *,
    aggregate_type: str,
    aggregate_id: str,
    revision: int,
    event_type: str,
    command_id: str | None,
    correlation_id: str,
) -> str:
    key = {
        "aggregate_type": aggregate_type,
        "aggregate_id": aggregate_id,
        "revision": revision,
        "event_type": event_type,
        "command_id": command_id,
        "correlation_id": correlation_id,
    }
    return hashlib.sha256(canonical_json(key)).hexdigest()[:24]


def make_transition_event(
    result: dict[str, Any],
    *,
    correlation_id: str,
    actor_id: str = "COMMANDER",
    causation_id: str | None = None,
    occurred_at: str,
) -> dict[str, Any]:
    if result.get("status") != "APPLIED":
        raise ValueError("只有 APPLIED transition 才能建立 canonical Event")

    after = result["state_after"]
    transition = result["transition"]
    digest = _event_key_digest(
        aggregate_type=transition["aggregate_type"],
        aggregate_id=result["aggregate_id"],
        revision=after["state_revision"],
        event_type="STATE_TRANSITION_APPLIED",
        command_id=result["command_id"],
        correlation_id=correlation_id,
    )

    event = {
        "object_id": f"EVENT:evt-{digest}",
        "kind": "EVENT",
        "schema_version": "1.0",
        "content_hash": "",
        "event_id": f"evt-{digest}",
        "event_type": "STATE_TRANSITION_APPLIED",
        "aggregate_id": result["aggregate_id"],
        "aggregate_type": transition["aggregate_type"],
        "revision": after["state_revision"],
        "causation_id": causation_id or result["command_id"],
        "correlation_id": correlation_id,
        "actor_id": actor_id,
        "occurred_at": occurred_at,
        "payload_ref": f"PAYLOAD:transition-{digest}",
        "command_id": result["command_id"],
        "command_type": result["command"]["command_type"],
        "idempotency_key": result["command"].get("idempotency_key"),
        "command_fingerprint": result.get("command_fingerprint"),
        "from_status": transition["from_status"],
        "to_status": transition["to_status"],
    }
    event["content_hash"] = content_hash(event)
    validate_event(event)
    return event


SEGMENT_EVENT_TYPES = (
    "SEGMENT_QUEUED",
    "SEGMENT_STARTED",
    "SEGMENT_RESULT_ACCEPTED",
    "SEGMENT_TIMED_OUT",
    "SEGMENT_CANCELLED",
    "SEGMENT_DEPENDENCY_BLOCKED",
    "SEGMENT_ATTEMPT_LIMIT_BLOCKED",
    "SEGMENT_TASK_SET_ISSUED",
    "SEGMENT_RULED",
    "BRIEF_DELIVERED",
    "BRIEF_SLOTS_CITED",
    "INFORMATION_GAP_PROPOSED",
    "DIALOGUE_TURN",
)


def make_segment_event(
    *,
    workflow_id: str,
    event_type: str,
    revision: int,
    delta: dict[str, Any],
    segment_ids: list[str],
    correlation_id: str,
    causation_id: str,
    actor_id: str = "SCHEDULER",
    occurred_at: str,
) -> dict[str, Any]:
    """D11：Segment 狀態變更事件。aggregate=該 workflow 的 SEGMENT 表，鍵為 workflow_id／segment_ids／correlation_id。"""
    if event_type not in SEGMENT_EVENT_TYPES:
        raise ValueError(f"不合法 Segment 事件類型: {event_type}")
    digest = _event_key_digest(
        aggregate_type="SEGMENT",
        aggregate_id=workflow_id,
        revision=revision,
        event_type=event_type,
        command_id=causation_id,
        correlation_id=correlation_id,
    )
    event = {
        "object_id": f"EVENT:evt-{digest}",
        "kind": "EVENT",
        "schema_version": "1.0",
        "content_hash": "",
        "event_id": f"evt-{digest}",
        "event_type": event_type,
        "aggregate_id": workflow_id,
        "aggregate_type": "SEGMENT",
        "revision": revision,
        "causation_id": causation_id,
        "correlation_id": correlation_id,
        "actor_id": actor_id,
        "occurred_at": occurred_at,
        "payload_ref": f"PAYLOAD:segdelta-{digest}",
        "segment_ids": sorted(set(segment_ids)),
        "segment_delta": deepcopy(delta),
    }
    event["content_hash"] = content_hash(event)
    validate_event(event)
    return event


def make_brief_delivered_event(
    *,
    workflow_id: str,
    revision: int,
    brief_session_id: str,
    route: str,
    track: str,
    slot_ids: list[str],
    grade: str,
    content_hash: str | None,
    occurred_at: str,
) -> dict[str, Any]:
    """R4L-M2：Brief 送出事件（SEGMENT aggregate；不新增 aggregate_type）。事後補查次數由此事件之後的事件重算。"""
    delta: dict[str, Any] = {
        "brief_session_id": brief_session_id,
        "route": route,
        "track": track,
        "slot_ids": sorted(slot_ids),
        "grade": grade,
    }
    if content_hash:
        delta["content_hash"] = content_hash
    return make_segment_event(
        workflow_id=workflow_id,
        event_type="BRIEF_DELIVERED",
        revision=revision,
        delta=delta,
        segment_ids=[brief_session_id],
        correlation_id=brief_session_id,
        causation_id=brief_session_id,
        actor_id="LIBRARIAN",
        occurred_at=occurred_at,
    )


class EventLog:
    """Append-only JSONL Event Log. It owns persistence, not Workflow State."""

    def __init__(self, path: str | Path):
        self.path = Path(path)

    def _read_raw(self) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        events: list[dict[str, Any]] = []
        for line_number, line in enumerate(
            self.path.read_text(encoding="utf-8").splitlines(),
            start=1,
        ):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(
                    f"Event Log 第 {line_number} 行 JSON 無效: {exc}"
                ) from exc
            validate_event(event)
            events.append(event)
        return events

    def read_all(self, aggregate_type: str | None = None) -> list[dict[str, Any]]:
        """讀全部事件（完整驗證）；可只取某 aggregate_type（WORKFLOW／SEGMENT）。"""
        events = self._read_raw()
        self._validate_history(events)
        if aggregate_type is not None:
            events = [e for e in events if e["aggregate_type"] == aggregate_type]
        return deepcopy(events)

    def read_recoverable(self) -> tuple[list[dict[str, Any]], dict[str, Any]]:
        """Read complete events and classify an incomplete final JSONL line.

        Complete events remain canonical inputs to the reducer. A malformed final
        non-empty line is never silently discarded as valid state; it is exposed
        as an UNKNOWN recovery condition so callers can reconcile before retrying.
        """
        if not self.path.exists():
            return [], {
                "status": "CLEAN",
                "complete_event_count": 0,
                "tail_line_present": False,
            }

        raw_lines = self.path.read_text(encoding="utf-8").splitlines()
        events: list[dict[str, Any]] = []
        tail_status = "CLEAN"

        for index, line in enumerate(raw_lines):
            if not line.strip():
                continue
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                if index == len(raw_lines) - 1:
                    tail_status = "PARTIAL_OR_CORRUPT_FINAL_LINE"
                    break
                raise ValueError(
                    f"Event Log 第 {index + 1} 行 JSON 無效，且不是最後一行: {exc}"
                ) from exc

            validate_event(event)
            events.append(event)

        self._validate_history(events)
        return deepcopy(events), {
            "status": tail_status,
            "complete_event_count": len(events),
            "tail_line_present": tail_status != "CLEAN",
        }

    @staticmethod
    def _validate_history(events: Iterable[dict[str, Any]]) -> None:
        last_revision: dict[tuple[str, str], int] = {}
        seen_ids: set[str] = set()
        for event in events:
            event_id = event["event_id"]
            if event_id in seen_ids:
                raise ValueError(f"Event Log 重複 event_id: {event_id}")
            seen_ids.add(event_id)

            aggregate = (event["aggregate_type"], event["aggregate_id"])
            previous = last_revision.get(aggregate)
            revision = event["revision"]

            if previous is None:
                if revision != 1:
                    raise ValueError(
                        f"Event Log 第一個 transition revision 必須為 1: "
                        f"{aggregate}={revision}"
                    )
            elif revision != previous + 1:
                raise ValueError(
                    f"Event Log revision 不連續: {aggregate} "
                    f"{previous} -> {revision}"
                )

            if event["event_type"] == "STATE_TRANSITION_APPLIED":
                required = (
                    "command_id",
                    "command_type",
                    "idempotency_key",
                    "command_fingerprint",
                    "from_status",
                    "to_status",
                )
                missing = [key for key in required if event.get(key) is None]
                if missing:
                    raise ValueError(
                        "STATE_TRANSITION_APPLIED 缺少 replay control data: "
                        + ", ".join(missing)
                    )

            expected_hash = content_hash(event)
            if event["content_hash"] != expected_hash:
                raise ValueError(f"Event content_hash 不正確: {event_id}")

            last_revision[aggregate] = revision

    def _last_event_for(self, aggregate_type: str, aggregate_id: str) -> dict[str, Any] | None:
        """同一 aggregate 的最後一筆事件（revision 以 aggregate 為單位連續）。"""
        if not self.path.exists():
            return None
        last: dict[str, Any] | None = None
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if not line.strip():
                    continue
                try:
                    event = json.loads(line)
                except json.JSONDecodeError as exc:
                    raise ValueError(f"Event Log 含無效 JSON 行: {exc}") from exc
                if (
                    event.get("aggregate_type") == aggregate_type
                    and event.get("aggregate_id") == aggregate_id
                ):
                    last = event
        return last

    def _require_same_workflow(self, event: dict[str, Any]) -> None:
        """單一 Event Log 只屬於一個 workflow：所有 aggregate_id 必須相同。"""
        if not self.path.exists():
            return
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    first = json.loads(line)
                    if first["aggregate_id"] != event["aggregate_id"]:
                        raise ValueError(
                            "單一 Event Log 只能保存單一 workflow："
                            f"existing={first['aggregate_id']} new={event['aggregate_id']}"
                        )
                    return

    def append(self, event: dict[str, Any]) -> str:
        """append 前只檢查同 aggregate 的最後 revision；完整 history 驗證由 read_all/replay 負責。

        D11：同一 Log 可保存 WORKFLOW 與 SEGMENT 兩種 aggregate，各自 revision 連續。
        """
        validate_event(event)
        expected_hash = content_hash(event)
        if event["content_hash"] != expected_hash:
            raise ValueError("Event content_hash 不正確")

        self._require_same_workflow(event)
        last = self._last_event_for(event["aggregate_type"], event["aggregate_id"])
        if last is not None:
            if last["event_id"] == event["event_id"]:
                if last["content_hash"] == event["content_hash"]:
                    return "IDEMPOTENT_REPLAY"
                raise ValueError(
                    f"event_id 已存在但內容不同: {event['event_id']}"
                )
            expected_revision = last["revision"] + 1
        else:
            expected_revision = 1

        if event["revision"] != expected_revision:
            raise ValueError(
                f"Event revision 不符合 append 順序: expected={expected_revision} "
                f"actual={event['revision']}"
            )

        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = json.dumps(
            event,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ) + "\n"

        fd = os.open(
            self.path,
            os.O_WRONLY | os.O_CREAT | os.O_APPEND,
            0o640,
        )
        try:
            with os.fdopen(fd, "a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()
                os.fsync(handle.fileno())
        except Exception:
            try:
                os.close(fd)
            except OSError:
                pass
            raise

        return "APPENDED"

    def events_for(self, aggregate_type: str, aggregate_id: str) -> list[dict[str, Any]]:
        return [
            event
            for event in self.read_all()
            if event["aggregate_type"] == aggregate_type
            and event["aggregate_id"] == aggregate_id
        ]


def make_brief_use_event(
    *,
    workflow_id: str,
    revision: int,
    event_type: str,
    brief_session_id: str,
    slot_ids: list[str] | None = None,
    ref: str | None = None,
    occurred_at: str,
    seq: int = 0,
) -> dict[str, Any]:
    """R4L-S4：任務使用 Brief 的事實事件（SEGMENT aggregate）。
    BRIEF_SLOTS_CITED＝任務引用了哪些槽；INFORMATION_GAP_PROPOSED＝任務提出 INFORMATION_GAP 提案（含缺的 ref）。
    brief_use 統計只由這些事件與 BRIEF_DELIVERED 重算，不在任何檔案維護計數欄位。"""
    if event_type not in ("BRIEF_SLOTS_CITED", "INFORMATION_GAP_PROPOSED"):
        raise ValueError(f"不合法 brief_use 事件類型: {event_type}")
    delta: dict[str, Any] = {"brief_session_id": brief_session_id}
    if event_type == "BRIEF_SLOTS_CITED":
        if not slot_ids:
            raise ValueError("BRIEF_SLOTS_CITED 需要 slot_ids")
        delta["slot_ids"] = sorted(set(slot_ids))
    else:
        if not ref:
            raise ValueError("INFORMATION_GAP_PROPOSED 需要缺少的 ref")
        delta["problem_class"] = "INFORMATION_GAP"
        delta["ref"] = ref
    return make_segment_event(
        workflow_id=workflow_id,
        event_type=event_type,
        revision=revision,
        delta=delta,
        segment_ids=[brief_session_id],
        correlation_id=f"{brief_session_id}:{event_type}:{seq}",
        causation_id=f"{brief_session_id}:{event_type}:{seq}",
        actor_id="BRAIN",
        occurred_at=occurred_at,
    )


# ---------------------------------------------------------------------------
# R4R-S4 (FR-10): DIALOGUE_TURN — conversation turns and `!` command routes as hash-only facts.
# Same extension point as BRIEF_DELIVERED: SEGMENT aggregate keyed by the work id (one Event Log = one workflow), so
# revisions stay contiguous; the conversation id lives in the event content.  Field names follow OpenTelemetry GenAI
# `gen_ai.conversation.id` as a NAMING reference only.  The full text is NEVER stored (no consumer yet): only its hash.
# ---------------------------------------------------------------------------
DIALOGUE_ROLES = ("USER", "ASSISTANT", "COMMAND")
MAX_DIALOGUE_RECENT = 10
_HEX64 = frozenset("0123456789abcdef")


def dialogue_content_hash(text: str) -> str:
    """sha256 hex of the UTF-8 text; the only trace of a turn's content that the log keeps."""
    if not isinstance(text, str):
        raise ValueError("DIALOGUE_CONTENT_NOT_TEXT")
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def make_dialogue_turn_event(
    *,
    workflow_id: str,
    revision: int,
    conversation_id: str,
    turn: int,
    role: str,
    content_hash: str,
    ref: str | None = None,
    occurred_at: str,
) -> dict[str, Any]:
    """One DIALOGUE_TURN (SEGMENT aggregate).  Stores conversation_id, turn, role, content hash and an optional ref only."""
    if not isinstance(conversation_id, str) or not conversation_id.strip():
        raise ValueError("DIALOGUE_CONVERSATION_ID_REQUIRED")
    if isinstance(turn, bool) or not isinstance(turn, int) or turn < 1:
        raise ValueError("DIALOGUE_TURN_MUST_BE_POSITIVE_INT")
    if role not in DIALOGUE_ROLES:
        raise ValueError(f"DIALOGUE_ROLE_INVALID:{role}")
    if not (isinstance(content_hash, str) and len(content_hash) == 64 and set(content_hash) <= _HEX64):
        raise ValueError("DIALOGUE_HASH_INVALID")
    delta: dict[str, Any] = {
        "conversation_id": conversation_id,
        "turn": turn,
        "role": role,
        "content_hash": content_hash,
    }
    if ref:
        delta["ref"] = str(ref)
    key = f"{conversation_id}:{turn}"
    return make_segment_event(
        workflow_id=workflow_id,
        event_type="DIALOGUE_TURN",
        revision=revision,
        delta=delta,
        segment_ids=[conversation_id],
        correlation_id=key,
        causation_id=key,
        actor_id="DIALOGUE",
        occurred_at=occurred_at,
    )


def read_dialogue(events: Iterable[dict[str, Any]], conversation_id: str) -> list[dict[str, Any]]:
    """Turns of one conversation, ordered by turn.  Fail-closed: a gap or a duplicate turn number raises ValueError."""
    rows = [
        deepcopy(e["segment_delta"])
        for e in events
        if e.get("event_type") == "DIALOGUE_TURN" and e["segment_delta"].get("conversation_id") == conversation_id
    ]
    rows.sort(key=lambda r: r["turn"])
    for index, row in enumerate(rows, start=1):
        if row["turn"] == index:
            continue
        raise ValueError(
            f"DIALOGUE_DUPLICATE_TURN:{row['turn']}" if index > 1 and row["turn"] == rows[index - 2]["turn"]
            else f"DIALOGUE_TURN_GAP:expected={index} actual={row['turn']}"
        )
    return rows


def record_dialogue_turn(
    log: "EventLog",
    *,
    workflow_id: str,
    conversation_id: str,
    role: str,
    content: str,
    ref: str | None = None,
    occurred_at: str,
) -> dict[str, Any]:
    """Producer: hash the content, take the next turn number and the next SEGMENT revision, append.  Text is dropped."""
    prior = log.events_for("SEGMENT", workflow_id)
    turn = len(read_dialogue(prior, conversation_id)) + 1
    event = make_dialogue_turn_event(
        workflow_id=workflow_id,
        revision=(prior[-1]["revision"] if prior else 0) + 1,
        conversation_id=conversation_id,
        turn=turn,
        role=role,
        content_hash=dialogue_content_hash(content),
        ref=ref,
        occurred_at=occurred_at,
    )
    log.append(event)
    return event


def dialogue_recent_refs(
    events: Iterable[dict[str, Any]], conversation_id: str, limit: int = MAX_DIALOGUE_RECENT
) -> list[str]:
    """Brief.recent projection: the last `limit` turns as short string refs, oldest first (a disposable derivative)."""
    turns = read_dialogue(events, conversation_id)[-max(1, int(limit)):]
    out = []
    for t in turns:
        item = f"DIALOGUE:{conversation_id}#{t['turn']} {t['role']} sha256:{t['content_hash'][:12]}"
        if t.get("ref"):
            item += f" ref={t['ref']}"
        out.append(item)
    return out
