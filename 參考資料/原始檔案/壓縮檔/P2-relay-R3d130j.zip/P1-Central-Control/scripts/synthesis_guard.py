"""synthesis_guard -- deterministic guard around a model-written synthesis (CAP-SYNTHESIS, R3d12zx S6 batch 2).  Writing stays with the model; references and states only, not faithfulness.
inputs {claims[{id, verdict (verify_verdict result)}], hypotheses[{id, state (hypothesis_guard status)}], gaps (gap_ledger gaps), provenance {ok} (provenance_trace result)};
draft {text, claim_refs, hypothesis_main, hypothesis_pending, status COMPLETE|PARTIAL, gaps[ids]}.
Rules: every claim_ref exists and is VERIFIED (verdict PASS); main-text hypotheses ACCEPTABLE (PROVISIONAL only in pending); provenance not ok -> REJECTED;
open gaps -> draft must be PARTIAL and list every gap id; COMPLETE needs every input claim VERIFIED.
End: COMPLETE | PARTIAL | REJECTED (fail closed) | INCOMPLETE (inputs unreadable incl. missing provenance result, no saved draft, guard error; never REJECTED/FAILED).
submit(): key = input_set_hash; the draft is written first and draft=None re-runs the guard on it; only COMPLETE/PARTIAL are journaled (done file, reused as cached);
a changed input set is a new key and the old one stays.  Claim granularity UNKNOWN; F39 and F47 share one guard (HYPOTHESIS).  Evidence ceiling: SIMULATED_PASS."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from atomic_write import atomic_write


def _dump(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True, default=str)


def _v(status: str, reason: str, inputs: Any = None) -> dict[str, Any]:
    return {"status": status, "reason": reason, "gaps": sorted(g["id"] for g in inputs["gaps"]) if inputs else []}


def input_set_hash(inputs: Any) -> str:
    return hashlib.sha256(_dump(inputs).encode("utf-8")).hexdigest()[:16]


def _claim_verified(c: dict[str, Any]) -> bool:
    return isinstance(c.get("verdict"), dict) and c["verdict"].get("verdict") == "PASS"


def _ids(xs: Any, *need: str) -> bool:
    return isinstance(xs, list) and all(isinstance(x, dict) and isinstance(x.get("id"), str) and all(x.get(k) for k in need) for x in xs)


def _readable(i: Any) -> bool:
    return (isinstance(i, dict) and _ids(i.get("claims")) and _ids(i.get("hypotheses")) and _ids(i.get("gaps"), "evidence_ref")
            and isinstance(i.get("provenance"), dict) and isinstance(i["provenance"].get("ok"), bool))


def _draft_ok(d: Any) -> bool:
    return (isinstance(d, dict) and isinstance(d.get("text"), str) and bool(d["text"].strip()) and d.get("status") in ("COMPLETE", "PARTIAL")
            and all(isinstance(d.get(k), list) and all(isinstance(x, str) for x in d[k]) for k in ("claim_refs", "hypothesis_main", "hypothesis_pending", "gaps")))


def _judge(inputs: dict[str, Any], d: dict[str, Any]) -> tuple[str, str]:
    claims, hyps = {c["id"]: c for c in inputs["claims"]}, {h["id"]: h for h in inputs["hypotheses"]}
    if not d["claim_refs"]:
        return "REJECTED", "NO_CLAIM_REF"
    for r in d["claim_refs"]:
        if r not in claims:
            return "REJECTED", "UNKNOWN_CLAIM"
        if not _claim_verified(claims[r]):
            return "REJECTED", "UNVERIFIED_CLAIM"
    if any(hyps.get(h, {}).get("state") != "ACCEPTABLE" for h in d["hypothesis_main"]):
        return "REJECTED", "HYPOTHESIS_NOT_ACCEPTABLE"
    if any(h not in hyps or hyps[h].get("state") in ("REJECTED", "INCOMPLETE") for h in d["hypothesis_pending"]):
        return "REJECTED", "HYPOTHESIS_UNUSABLE"
    if not inputs["provenance"]["ok"]:
        return "REJECTED", "PROVENANCE_BREAK"
    open_ids = {g["id"] for g in inputs["gaps"]}
    if open_ids and (d["status"] != "PARTIAL" or not open_ids <= set(d["gaps"])):
        return "REJECTED", "GAP_IGNORED"
    if d["status"] == "COMPLETE" and not all(_claim_verified(c) for c in claims.values()):
        return "REJECTED", "REQUIRED_CLAIM_UNVERIFIED"
    return d["status"], ""


def check(inputs: Any, d: Any) -> dict[str, Any]:
    try:
        if not _readable(inputs):
            return _v("INCOMPLETE", "INPUT_UNREADABLE")
        if not _draft_ok(d):
            return _v("REJECTED", "FIELDS", inputs)
        s, r = _judge(inputs, d)
    except Exception:  # guard failed: not a verdict on the draft
        return _v("INCOMPLETE", "GUARD_ERROR")
    return _v(s, r, inputs)


def _load(p: Path) -> Any:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def submit(inputs: Any, d: Any, store_dir: str | Path) -> dict[str, Any]:
    if not _readable(inputs):
        return {**check(inputs, d), "cached": False}
    ih, sd = input_set_hash(inputs), Path(store_dir)
    old = _load(sd / f"{ih}.done.json")
    if isinstance(old, dict) and isinstance(old.get("verdict"), dict):
        return {**old["verdict"], "cached": True}
    if d is None:
        d = _load(sd / f"{ih}.draft.json")
        if d is None:
            return {**_v("INCOMPLETE", "NO_DRAFT"), "cached": False}
    else:
        sd.mkdir(parents=True, exist_ok=True)
        atomic_write(sd / f"{ih}.draft.json", _dump(d))
    v = check(inputs, d)
    if v["status"] in ("COMPLETE", "PARTIAL"):
        atomic_write(sd / f"{ih}.done.json", _dump({"verdict": v, "draft": d}))
    return {**v, "cached": False}
