#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "attempt.schema.json",
        "task_packet.schema.json",
        "result_packet.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"], Resource.from_contents(schema)
        )
    return registry


def _validate(filename: str, value: dict[str, Any]) -> None:
    schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(
        schema,
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(validator.iter_errors(value), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            f"{filename} 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )
    expected_hash = content_hash(value)
    if value.get("content_hash") != expected_hash:
        raise ValueError(
            f"{filename} content_hash 不正確: "
            f"expected={expected_hash} actual={value.get('content_hash')}"
        )


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def _identity(kind: str, object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    value["object_id"] = f"{kind}:{object_id}"
    value["kind"] = kind
    value["schema_version"] = "1.0"
    value["content_hash"] = ""
    value["content_hash"] = content_hash(value)
    return value


def validate_attempt(attempt: dict[str, Any]) -> None:
    _validate("attempt.schema.json", attempt)


def validate_task_packet(packet: dict[str, Any]) -> None:
    _validate("task_packet.schema.json", packet)


def validate_result_packet(packet: dict[str, Any]) -> None:
    _validate("result_packet.schema.json", packet)


def build_attempt(
    segment: dict[str, Any],
    *,
    attempt_number: int = 1,
    started_at: str | None = None,
    timeout_ms: int | None = None,
) -> dict[str, Any]:
    if attempt_number < 1:
        raise ValueError("attempt_number 必須 >= 1")
    workflow_id = segment["workflow_id"]
    segment_id = segment["segment_id"]
    attempt_id = f"att-{segment_id}-{attempt_number}"
    start_value = started_at or datetime.now(timezone.utc).isoformat()
    retry_policy = deepcopy(
        segment.get(
            "retry_policy",
            {"max_attempts": 1, "retry_on": []},
        )
    )
    effective_timeout = int(
        timeout_ms if timeout_ms is not None else segment.get("timeout_ms", 300000)
    )
    timeout_at = (
        datetime.fromisoformat(start_value.replace("Z", "+00:00"))
        + timedelta(milliseconds=effective_timeout)
    ).isoformat()
    attempt = {
        "attempt_id": attempt_id,
        "segment_id": segment_id,
        "workflow_id": workflow_id,
        "attempt_number": attempt_number,
        "status": "RUNNING",
        "idempotency_key": f"{segment_id}:{attempt_number}",
        "started_at": start_value,
        "ended_at": None,
        "task_packet_ref": f"TASK_PACKET:pkt-{segment_id}-{attempt_number}",
        "result_packet_ref": None,
        "execution_record_ref": f"EXECUTION:exec-{attempt_id}",
        "input_hash": None,
        "output_hash": None,
        "timeout_at": timeout_at,
        "max_attempts": int(retry_policy["max_attempts"]),
        "retry_on": list(retry_policy["retry_on"]),
        "cancel_reason": None,
    }
    attempt = _identity("ATTEMPT", attempt_id, attempt)
    validate_attempt(attempt)
    return attempt


def build_task_packet(
    segment: dict[str, Any],
    attempt: dict[str, Any],
) -> dict[str, Any]:
    if attempt["segment_id"] != segment["segment_id"]:
        raise ValueError("Attempt 與 Segment 不一致")
    if attempt["workflow_id"] != segment["workflow_id"]:
        raise ValueError("Attempt 與 Workflow 不一致")

    budget = segment["context_budget"]
    packet_id = f"pkt-{segment['segment_id']}-{attempt['attempt_number']}"
    packet = {
        "packet_id": packet_id,
        "workflow_id": segment["workflow_id"],
        "segment_id": segment["segment_id"],
        "attempt_id": attempt["attempt_id"],
        "skill_id": segment["skill_id"],
        "skill_version": segment["skill_version"],
        "objective": segment["objective"],
        "input_refs": list(segment["input_refs"]),
        "requested_outputs": list(segment["requested_outputs"]),
        "constraints": list(segment.get("constraints", [])),
        "stop_condition": list(segment.get("stop_condition", [])),
        "failure_condition": list(segment.get("failure_condition", [])),
        "scope": {
            "input_scope": segment["input_scope"],
            "handoff_allowed": bool(
                segment["completion_contract"].get("handoff_allowed", False)
            ),
        },
        "acceptance_ref": segment.get(
            "acceptance_ref",
            f"SEGMENT:{segment['segment_id']}",
        ),
        "context_budget": {
            "target": budget["target_context_budget"],
            "hard_ceiling": budget["hard_context_ceiling"],
            "estimated": budget["estimated_total_context"],
        },
        "execution_record_ref": attempt["execution_record_ref"],
        "retry_policy": deepcopy(
            segment.get(
                "retry_policy",
                {"max_attempts": 1, "retry_on": []},
            )
        ),
        "timeout_ms": int(segment.get("timeout_ms", 300000)),
        "dependency_refs": list(segment.get("dependency_refs", [])),
    }
    continuation_box_ref = segment.get("continuation_box_ref")
    if continuation_box_ref:
        packet["continuation_box_ref"] = continuation_box_ref
    packet = _identity("TASK_PACKET", packet_id, packet)
    validate_task_packet(packet)

    expected_attempt_ref = f"TASK_PACKET:{packet_id}"
    if attempt["task_packet_ref"] != expected_attempt_ref:
        raise ValueError("Attempt.task_packet_ref 與 TaskPacket 不一致")

    return packet


DECISION_TO_STATUS = {
    "WORK_COMPLETE": "VALID",
    "UNRESOLVED": "UNRESOLVED",
    "FAIL": "INVALID",
    "BLOCK": "INVALID",
    "NEEDS_BRAIN": "UNRESOLVED",
}


def build_result_packet(
    task_packet: dict[str, Any],
    skill_result: dict[str, Any],
    *,
    result_id: str | None = None,
) -> dict[str, Any]:
    validate_task_packet(task_packet)
    decision_code = skill_result.get("decision_code", skill_result.get("status"))
    if decision_code not in DECISION_TO_STATUS:
        raise ValueError(
            "Skill Result 必須提供 decision_code: WORK_COMPLETE / UNRESOLVED / FAIL / BLOCK / NEEDS_BRAIN"
        )

    status = skill_result.get("status", DECISION_TO_STATUS[decision_code])
    if status != DECISION_TO_STATUS[decision_code]:
        raise ValueError("ResultPacket status 與 decision_code 不一致")

    if result_id is None:
        result_id = f"res-{task_packet['segment_id']}-{task_packet['attempt_id']}"

    usage = skill_result.get("observed_usage", {})
    packet = {
        "result_id": result_id,
        "workflow_id": task_packet["workflow_id"],
        "segment_id": task_packet["segment_id"],
        "attempt_id": task_packet["attempt_id"],
        "skill_id": task_packet["skill_id"],
        "skill_version": task_packet["skill_version"],
        "status": status,
        "decision_code": decision_code,
        "output_refs": list(skill_result.get("output_refs", [])),
        "unresolved": list(skill_result.get("unresolved", [])),
        "evidence_refs": list(skill_result.get("evidence_refs", [])),
        "provenance_refs": list(skill_result.get("provenance_refs", [])),
        "observed_usage": {
            "model_calls": int(usage.get("model_calls", 0)),
            "tool_calls": int(usage.get("tool_calls", 0)),
            "wall_time_ms": int(usage.get("wall_time_ms", 0)),
        },
        "usage_observed": bool(skill_result.get("usage_observed", False)),
        "execution_record_ref": task_packet["execution_record_ref"],
    }
    packet = _identity("RESULT_PACKET", result_id, packet)
    validate_result_packet(packet)
    return packet
