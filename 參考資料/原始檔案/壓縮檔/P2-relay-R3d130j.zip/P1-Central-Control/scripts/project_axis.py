#!/usr/bin/env python3
"""R4-S6 專案主軸（藍圖 §3B.12）：AXIS.md 建立／收斂／偏離判斷。只用標準庫。

入口：python3 P1-Central-Control/scripts/project_axis.py --simulate [--mutate]
  SC-09 主軸逐層收斂、SC-10 偏離處置；格式檢查由 tools/axis_lint.py --project 實際執行。
  --mutate：把「確認者必須是使用者」換成永遠放行，模擬必須轉 FAILED（證明檢查不是空轉）。
語意判斷（距離三級、子類關係）由 Brain 提供標籤；本檔只做可由代碼檢驗的部分：
  確認者＝使用者、原因非空、非目標命中、確認前不生成、位元組預算、轉向保留舊鏈。
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAX_BYTES = 3072
MAX_CHAIN = 6
KINDS = ("收斂", "轉向", "擴張")
ASK_DRIFT = "這是新支線還是換主軸？"
ASK_TURN = "這是換主軸嗎？"
_ALLOW_ANY_CONFIRMER = False  # 只給 --mutate 用


class AxisError(Exception):
    pass


def new_axis(goal: str, root: str, non_goals: list[str]) -> dict:
    if not goal.strip() or not root.strip() or not non_goals:
        raise AxisError("AXIS_NEEDS_GOAL_ROOT_NONGOALS")
    return {"goal": goal.strip(), "chain": [root.strip()], "branches": [], "non_goals": list(non_goals),
            "log": [["v1", "收斂", "使用者", f"建立主軸：{root.strip()}"]]}


def focus(st: dict) -> str:
    return st["chain"][-1]


def render(st: dict) -> str:
    tree = []
    for i, node in enumerate(st["chain"]):
        tree.append(node if i == 0 else "   " * (i - 1) + "└─ " + node)
    lines = [f"> {st['goal']}", "", f"焦點：{focus(st)}", "", "## 主軸鏈", "", "```text", *tree, "```", "", "## 支線", ""]
    lines += [f"- {b[0]}（服務焦點：{b[1]}）" for b in st["branches"]] or ["- （無）"]
    lines += ["", "## 非目標", ""] + [f"- {x}" for x in st["non_goals"]]
    lines += ["", "## 修改紀錄", "", "| 版本 | 類型 | 確認者 | 原因 |", "|---|---|---|---|"]
    lines += ["| " + " | ".join(r) + " |" for r in st["log"]]
    text = "\n".join(lines) + "\n"
    if len(text.encode("utf-8")) > MAX_BYTES:
        raise AxisError(f"AXIS_TOO_LARGE:{len(text.encode('utf-8'))}>{MAX_BYTES}")
    return text


def propose(st: dict, kind: str, node: str) -> dict:
    """AI 只能提議；提議本身不改鏈。"""
    if kind not in KINDS:
        raise AxisError("AXIS_KIND_INVALID")
    ask = ASK_TURN if kind == "轉向" else None
    return {"kind": kind, "node": node, "status": "PROPOSED", "ask": ask}


def confirm(st: dict, prop: dict, confirmer: str, reason: str) -> dict:
    """使用者確認才生效；回傳新狀態，失敗時原狀態不動。"""
    if confirmer != "使用者" and not _ALLOW_ANY_CONFIRMER:
        raise AxisError("AXIS_CONFIRMER_MUST_BE_USER")
    if not reason.strip():
        raise AxisError("AXIS_REASON_REQUIRED")
    new = json.loads(json.dumps(st, ensure_ascii=False))
    old_chain = " ⊃ ".join(st["chain"])
    if prop["kind"] == "收斂":
        if len(new["chain"]) >= MAX_CHAIN:
            raise AxisError("AXIS_CHAIN_TOO_DEEP")
        new["chain"].append(prop["node"])
    elif prop["kind"] == "轉向":
        new["chain"] = [prop["node"]]
        reason = f"{reason}（舊鏈：{old_chain}）"
    else:  # 擴張：往上放寬一層
        if len(new["chain"]) < 2:
            raise AxisError("AXIS_ALREADY_AT_ROOT")
        new["chain"].pop()
    new["log"].append([f"v{len(new['log']) + 1}", prop["kind"], confirmer, reason.strip()])
    render(new)  # 預算檢查
    return new


def add_branch(st: dict, name: str, serves: str, confirmer: str) -> dict:
    if not serves.strip():
        raise AxisError("BRANCH_MUST_SERVE_FOCUS")
    new = json.loads(json.dumps(st, ensure_ascii=False))
    new["branches"].append([name, serves.strip()])
    new["log"].append([f"v{len(new['log']) + 1}", "擴張", confirmer, f"新增支線：{name}"])
    render(new)
    return new


def drift_check(st: dict, request: str, distance: str, kind: str = "generate", confirmed: bool = False) -> dict:
    """distance 由 Brain 標：in_focus／in_upper／outside。非目標命中一律當 outside。"""
    if any(n and n in request for n in st["non_goals"]):
        distance = "outside"
    if distance == "in_focus":
        return {"verdict": "PASS", "generate_allowed": True, "ask": None}
    if distance == "in_upper":
        return {"verdict": "NOTE", "generate_allowed": True, "ask": None}
    if kind == "chat":  # 使用者自己岔題：只提醒，不阻擋
        return {"verdict": "REMIND", "generate_allowed": True, "ask": None}
    return {"verdict": "DRIFT", "generate_allowed": bool(confirmed), "ask": None if confirmed else ASK_DRIFT}


def anchor_line(st: dict) -> str:
    return f"主軸：{' ⊃ '.join(st['chain'])}｜焦點：{focus(st)}｜非目標：{'、'.join(st['non_goals'])}"


def lint(path: Path) -> tuple[bool, str]:
    r = subprocess.run([sys.executable, str(ROOT / "tools" / "axis_lint.py"), "--project", str(path)],
                       capture_output=True, text=True, encoding="utf-8")
    return r.returncode == 0, r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-120:]


def _raises(fn, code: str) -> bool:
    try:
        fn()
    except AxisError as e:
        return code in str(e)
    return False


def _sc09(tmp: Path) -> list[tuple[str, bool]]:
    out = []
    st = new_axis("寫一篇情詩", "愛情", ["戰爭題材"])
    for node, why in (("青春的愛情", "使用者說要青春的"), ("學生時代的暗戀", "使用者說是學生時代的暗戀")):
        p = propose(st, "收斂", node)
        out.append((f"提議不改鏈：{node}", st["chain"][-1] != node and p["status"] == "PROPOSED"))
        st = confirm(st, p, "使用者", why)
    out.append(("鏈＝愛情⊃青春的愛情⊃學生時代的暗戀、焦點最深", st["chain"] == ["愛情", "青春的愛情", "學生時代的暗戀"] and focus(st) == st["chain"][-1]))
    f = tmp / "AXIS.md"
    f.write_text(render(st), encoding="utf-8")
    ok, note = lint(f)
    out.append((f"axis_lint --project PASS（{note}）", ok))
    out.append(("每次收斂都有一行原因且確認者為使用者", all(r[2] == "使用者" and r[3] for r in st["log"]) and len(st["log"]) == 3))
    # 負例
    p = propose(st, "收斂", "初戀的告白")
    before = json.dumps(st, ensure_ascii=False)
    out.append(("負例：AI 自行確認被拒、鏈不變", _raises(lambda: confirm(st, p, "AI", "自己收斂"), "CONFIRMER") and json.dumps(st, ensure_ascii=False) == before))
    out.append(("負例：沒有原因被拒", _raises(lambda: confirm(st, p, "使用者", "  "), "REASON")))
    bad = json.loads(before)
    bad["log"].append(["v4", "收斂", "AI", "悄悄收斂"])
    bad["chain"].append("初戀的告白")
    g = tmp / "BAD-AXIS.md"
    g.write_text(render(bad), encoding="utf-8")
    out.append(("負例：竄改成未經確認的節點，lint 轉 FAIL", not lint(g)[0]))
    t = confirm(st, propose(st, "轉向", "戰亂中的離別"), "使用者", "使用者換主軸")
    out.append(("轉向：新鏈單層且舊鏈留在紀錄", t["chain"] == ["戰亂中的離別"] and "舊鏈：愛情 ⊃ 青春的愛情 ⊃ 學生時代的暗戀" in t["log"][-1][3]))
    e = confirm(st, propose(st, "擴張", "青春的愛情"), "使用者", "使用者要放寬")
    out.append(("擴張：往上一層，確認者為使用者", e["chain"][-1] == "青春的愛情" and e["log"][-1][2] == "使用者"))
    return out


def _sc10(tmp: Path) -> list[tuple[str, bool]]:
    out = []
    st = new_axis("寫一篇情詩", "愛情", ["戰爭題材"])
    for n in ("青春的愛情", "學生時代的暗戀"):
        st = confirm(st, propose(st, "收斂", n), "使用者", f"使用者要{n}")
    d = drift_check(st, "寫失落的情詩", "outside")
    out.append(("界外請求標 DRIFT、先問新支線或換主軸、確認前不生成", d["verdict"] == "DRIFT" and d["ask"] == ASK_DRIFT and not d["generate_allowed"]))
    d2 = drift_check(st, "寫一首戰爭題材的情詩", "in_focus")
    out.append(("負例：命中非目標即使 Brain 誤標焦點內仍是 DRIFT", d2["verdict"] == "DRIFT" and not d2["generate_allowed"]))
    out.append(("確認後才放行", drift_check(st, "寫失落的情詩", "outside", confirmed=True)["generate_allowed"]))
    out.append(("焦點內放行；上層標註後放行", drift_check(st, "x", "in_focus")["verdict"] == "PASS" and drift_check(st, "x", "in_upper")["verdict"] == "NOTE"))
    out.append(("使用者自己岔題（聊天）只提醒、不阻擋", drift_check(st, "x", "outside", kind="chat") == {"verdict": "REMIND", "generate_allowed": True, "ask": None}))
    b = add_branch(st, "失落的情詩", "同樣寫學生時代，只是結局不同", "使用者")
    out.append(("新支線須說明如何服務焦點", len(b["branches"]) == 1 and _raises(lambda: add_branch(st, "x", " ", "使用者"), "SERVE")))
    f = tmp / "AXIS2.md"
    f.write_text(render(b), encoding="utf-8")
    out.append(("加支線後 axis_lint --project 仍 PASS", lint(f)[0]))
    def _fill():
        cur = st
        for i in range(40):
            cur = add_branch(cur, f"支線{i}" + "名" * 30, "服務" * 30, "使用者")

    out.append(("位元組預算：累加到超過 3,072 B 被拒", _raises(_fill, "TOO_LARGE")))
    out.append(("貼近生成處的錨定行 ≤ 2 行且含焦點與非目標", anchor_line(st).count("\n") == 0 and "學生時代的暗戀" in anchor_line(st) and "戰爭題材" in anchor_line(st)))
    return out


def run_simulation(mutate: bool = False) -> dict:
    global _ALLOW_ANY_CONFIRMER
    _ALLOW_ANY_CONFIRMER = mutate
    try:
        with tempfile.TemporaryDirectory() as d:
            groups = {"SC-09": _sc09(Path(d)), "SC-10": _sc10(Path(d))}
    finally:
        _ALLOW_ANY_CONFIRMER = False
    ok = all(p for g in groups.values() for _, p in g)
    return {"evidence": "SIMULATED_PASS" if ok else "FAILED", "ok": ok,
            "groups": {k: f"{sum(p for _, p in v)}/{len(v)}" for k, v in groups.items()},
            "failed": [n for g in groups.values() for n, p in g if not p]}


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--simulate", action="store_true")
    ap.add_argument("--mutate", action="store_true")
    a = ap.parse_args()
    if not a.simulate:
        ap.print_help()
        return 2
    r = run_simulation(a.mutate)
    print(json.dumps(r["groups"], ensure_ascii=False), r["evidence"])
    for n in r["failed"]:
        print("FAILED:", n)
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
