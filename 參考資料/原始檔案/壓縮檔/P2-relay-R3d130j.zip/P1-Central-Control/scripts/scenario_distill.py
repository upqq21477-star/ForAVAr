#!/usr/bin/env python3
"""P2 scenario_distill (R7) - four simulated scenarios distilled into re-runnable functions (SIMULATED_PASS, stdlib, no network).

  FP4 fp_amnesia_resume       interrupted run resumed only from a trace snapshot == uninterrupted run (M2)
  FP5 fp_knowledge_lifecycle  observation -> claim -> new version -> conflict -> archive, queries asserted per state (M3)
  FP6 fp_archive_isolation    archived claims never reach a Brain input packet (M4, V14)
  FP7 fp_candidate_promotion  UNTRUSTED_CANDIDATE -> VERIFIED -> ACCEPTED/REJECTED/EXPIRED, no entry before VERIFIED (M6)
Each returns {"name","ok","assertions":[[name,bool]...],"state":{...},"digest"}; the digest is path-free, so replay can compare runs.
  python3 scripts/scenario_distill.py amnesia|knowledge|archive|promotion|replay
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
EVID = HERE.parent / "evidence" / "r7"
TS = "2026-10-08T00:00:00Z"
T1, T2, T3, MID, NOW = "2026-01-01T00:00:00Z", "2026-06-01T00:00:00Z", "2026-09-01T00:00:00Z", "2026-03-01T00:00:00Z", "2026-10-01T00:00:00Z"
J = ("CONTROL_RESEARCH", "引文直接支持")
PARAS = ["系統 A 使用 SQLite 儲存。", "系統 A 不使用網路。", "系統 B 使用 JSON 檔。"]


def dig(obj: Any) -> str:
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()


def _out(name: str, asserts: list[list[Any]], state: dict[str, Any]) -> dict[str, Any]:
    a = [[n, bool(c)] for n, c in asserts]
    return {"name": name, "ok": all(c for _, c in a), "assertions": a, "state": state, "digest": dig([a, state])}


# ---- FP4 amnesia resume ---------------------------------------------------------------------------------------
def _final(r: Any, p2: Any) -> dict[str, Any]:
    return {"calc": dig((r.work / "calc.py").read_text(encoding="utf-8")), "trace": [[e["tool"], e["verdict"], e["code"], e["args_digest"], e["hash"]] for e in r.trace],
            "attempts": [a["outcome"] for a in r.attempts], "mode": r.mode, "chain_ok": p2.verify_trace(r.trace) == []}


def fp_amnesia_resume() -> dict[str, Any]:
    import p2_run as p2
    mk = lambda base, **kw: p2.Run(p2._toy(base), write_scope=["calc.py", "protected.json"], protected=["protected.json"], goal_confirmed=True, run_id="AM", **kw)  # noqa: E731
    pre = lambda r: (p2._build_mode(r), r.begin_work_unit(["tests/test_calc.py"], "rev-1"), r.step("run_tests", {"cmd": "unittest"}), r.step("read", {"path": "calc.py"}))  # noqa: E731
    post = lambda r: (r.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"}), r.step("run_tests", {"cmd": "unittest"}))  # noqa: E731
    with tempfile.TemporaryDirectory() as td:
        base = Path(td)
        u = mk(base / "u"); pre(u); post(u); uf = _final(u, p2)
        i = mk(base / "i"); pre(i)
        snap = json.loads(json.dumps({k: getattr(i, k) for k in ("trace", "attempts", "diffs", "mode", "baseline", "revision", "budget")}))
        work = i.work
        del i  # amnesia: only the persisted workdir files and the snapshot survive

        def resume(s: dict[str, Any]) -> Any:
            if p2.verify_trace(s["trace"]):
                raise ValueError("TRACE_CHAIN_BROKEN")
            r = p2.Run(work, write_scope=["calc.py", "protected.json"], protected=["protected.json"], goal_confirmed=True, run_id="AM")
            r.__dict__.update(json.loads(json.dumps(s)))  # private copy: the snapshot itself must stay untouched
            return r
        r = resume(snap); post(r); rf = _final(r, p2)
        bad = json.loads(json.dumps(snap)); bad["trace"][1]["code"] = "TAMPERED"
        try:
            resume(bad); refused = False
        except ValueError as e:
            refused = str(e) == "TRACE_CHAIN_BROKEN"
    return _out("S_AMNESIA", [["resumed_final_state_equals_uninterrupted", rf == uf], ["trace_chain_ok_after_resume", rf["chain_ok"]],
                              ["fix_applied_and_tests_pass", rf["attempts"] == ["failure", "success"]], ["tampered_snapshot_refused", refused],
                              ["snapshot_has_pre_interrupt_steps", 0 < len(snap["trace"]) < len(rf["trace"]) and snap["trace"][-1]["tool"] == "read"]], {"steps": len(rf["trace"]), "attempts": rf["attempts"], "final": rf["calc"]})


# ---- shared knowledge store ---------------------------------------------------------------------------------
def _kb(tmp: Path) -> tuple[Any, dict[str, str]]:
    import knowledge_intake as ki
    import knowledge_versioning as kv
    data = "\n\n".join(PARAS).encode("utf-8")
    _, segs = ki.build_source("d", data, location="mem://d", version="v1", max_chars=20)
    refs = [x["object_id"] for x in segs]
    led = ki.ReadingLedger(tmp / "ledger.jsonl", segs)
    for ref in refs[:3]:
        led.append(ref, "READ", reader="R1", timestamp=TS)
    store = kv.TemporalKnowledgeStore(led, {"SOURCE:d": ki.normalize(data)})
    store.segs = refs  # type: ignore[attr-defined]
    return store, {}


def _mk(s: Any, cid: str, seg: int, quote: str, content: str, **kw: Any) -> str:
    o = s.add_observation("OBSERVED", "obs", s.segs[seg], producer="R1", captured_at=TS, quote=quote)["object_id"]
    e = s.add_evidence(o, f"CLAIM:{cid}", "SUPPORTS", producer="R1", scope="TASK:t", captured_at=TS)["object_id"]
    ref = s.propose_claim(cid, "FACT", content, [o], [e], **kw)["object_id"]
    s.promote(ref, by=J[0], rationale=J[1])
    return ref


# ---- FP5 knowledge lifecycle ----------------------------------------------------------------------------------
def fp_knowledge_lifecycle() -> dict[str, Any]:
    with tempfile.TemporaryDirectory() as td:
        s, _ = _kb(Path(td)); a: list[list[Any]] = []; st: dict[str, Any] = {}
        s.add_observation("OBSERVED", "obs", s.segs[0], producer="R1", captured_at=TS, quote="SQLite")
        a.append(["observation_alone_is_not_knowledge", s.valid_at(NOW) == {"valid": [], "disputed": []}])
        c1 = _mk(s, "c1", 0, "SQLite", "系統 A 使用 SQLite 儲存", valid_from=T1)
        a += [["claim_valid_after_promotion", s.valid_at(MID)["valid"] == [c1]], ["claim_confirmed_active", (s.state_vector(c1)["adjudication"], s.state_vector(c1)["lifecycle"]) == ("CONFIRMED", "ACTIVE")]]
        c2 = _mk(s, "c2", 2, "JSON", "系統 B 使用 JSON 檔", supersedes=[c1], valid_from=T2)
        a += [["old_version_answers_old_time", s.valid_at(MID)["valid"] == [c1]], ["new_version_answers_now", s.valid_at(NOW)["valid"] == [c2]],
              ["old_version_superseded", s.state_vector(c1)["lifecycle"] == "SUPERSEDED"]]
        c3, c4 = _mk(s, "c3", 1, "不使用網路", "系統 A 不使用網路", valid_from=T1), _mk(s, "c4", 1, "不使用網路", "系統 A 使用網路", valid_from=T1)
        s.open_conflict("k1", c3, c4, "A 是否用網路", by=J[0], opened_at=TS)
        v = s.valid_at(NOW)
        a += [["conflict_sides_disputed_not_hidden", sorted(v["disputed"]) == sorted([c3, c4]) and v["valid"] == [c2]], ["conflict_state_disputed", s.state_vector(c3)["adjudication"] == "DISPUTED"]]
        s.set_lifecycle(c1, "ARCHIVED", by=J[0], rationale="已被取代")
        try:
            s.set_lifecycle(c1, "ACTIVE", by=J[0], rationale="x"); revived = True
        except ValueError:
            revived = False
        a += [["archived_leaves_valid_at_any_time", s.valid_at(MID)["valid"] == [] and s.state_vector(c1)["lifecycle"] == "ARCHIVED"], ["archived_is_terminal", not revived],
              ["integrity_gate_ok", bool(s.integrity_gate())]]
        st = {"claims": sorted(s.claims), "valid_now": s.valid_at(NOW), "c1_lifecycle": s.state_vector(c1)["lifecycle"]}
    return _out("S_KNOWLEDGE_LIFECYCLE", a, st)


# ---- FP6 archive isolation ------------------------------------------------------------------------------------
def fp_archive_isolation() -> dict[str, Any]:
    import archive_governance as ag
    import brain_input
    import central_controller
    import knowledge_retrieval as kr
    with tempfile.TemporaryDirectory() as td:
        s, _ = _kb(Path(td))
        c1 = _mk(s, "c1", 0, "SQLite", "系統 A 使用 SQLite 儲存", valid_from=T1)
        c2 = _mk(s, "c2", 2, "JSON", "系統 B 使用 JSON 檔", valid_from=T2)
        ret = kr.Retriever(s)
        pre = brain_input.semantic_refs_from(ret, "SQLite")
        s.set_lifecycle(c1, "ARCHIVED", by=J[0], rationale="封存")
        arc, act = brain_input.semantic_refs_from(ret, "SQLite"), brain_input.semantic_refs_from(ret, "JSON")
        pkt = brain_input.build_brain_input_packet(central_controller.init_state("WF-ARC", "TASK-ARC"), semantic_refs=arc + act)
        txt = json.dumps(pkt, ensure_ascii=False)
        codes = []
        for fn in (lambda: ag.scoped_search([{"scope": "ARCHIVE"}], lambda i: True, "ARCHIVE"), lambda: ag.check_scope("ARCHIVE")):
            try:
                fn(); codes.append("NO_ERROR")
            except Exception as e:  # noqa: BLE001 - the governance error code is the evidence
                codes.append(str(e)[:40])
    return _out("S_ARCHIVE_ISOLATION", [["active_before_archive_reaches_brain", pre == [c1]], ["archived_claim_not_in_semantic_refs", arc == []], ["archived_ref_and_text_absent_from_packet", c1 not in txt and "SQLite" not in txt],
                                        ["active_claim_still_reaches_brain", act == [c2] and c2 in pkt["semantic_refs"]], ["archive_only_via_protocol", codes[0] != "NO_ERROR" and codes[1] != "NO_ERROR"]],
                {"refs_in_packet": pkt["semantic_refs"], "archive_errors": codes})


# ---- FP7 candidate promotion ----------------------------------------------------------------------------------
TRANSITIONS = {"UNTRUSTED_CANDIDATE": {"VERIFIED", "EXPIRED"}, "VERIFIED": {"ACCEPTED", "REJECTED", "EXPIRED"}, "ACCEPTED": set(), "REJECTED": set(), "EXPIRED": set()}
ROLE_FOR = {"VERIFIED": "CONTROL_RESEARCH", "ACCEPTED": "CONTROL_RESEARCH", "REJECTED": "CONTROL_RESEARCH", "EXPIRED": "MACHINE:TTL"}


class Candidate:
    def __init__(self, cid: str, content: str) -> None:
        self.cid, self.content, self.state, self.log = cid, content, "UNTRUSTED_CANDIDATE", []

    def to(self, new: str, *, by: str, evidence_ref: str | None) -> None:
        if new not in TRANSITIONS[self.state]:
            raise ValueError(f"TRANSITION_INVALID:{self.state}->{new}")
        if by != ROLE_FOR[new]:
            raise ValueError("ROLE_NOT_RESPONSIBLE")
        if not evidence_ref:
            raise ValueError("EVIDENCE_REF_REQUIRED")
        self.log.append({"from": self.state, "to": new, "by": by, "evidence_ref": evidence_ref})
        self.state = new


def admit(store: Any, cand: Candidate, seg: int, quote: str) -> str:
    """The only door into Knowledge: refuses anything not ACCEPTED."""
    if cand.state != "ACCEPTED":
        raise ValueError("CANDIDATE_NOT_ACCEPTED")
    return _mk(store, cand.cid, seg, quote, cand.content, valid_from=T3)


def _err(fn: Any) -> str:
    try:
        fn(); return "NO_ERROR"
    except ValueError as e:
        return str(e)


def fp_candidate_promotion() -> dict[str, Any]:
    import knowledge_retrieval as kr
    with tempfile.TemporaryDirectory() as td:
        s, _ = _kb(Path(td)); ret = kr.Retriever(s)
        ca, cb, cc, cd = (Candidate(i, t) for i, t in (("ca", "外部：系統 B 另提供 YAML 匯出"), ("cb", "外部：系統 B 完全免費"), ("cc", "外部：系統 B 支援雲端"), ("cd", "外部：系統 B 已停產")))
        before_admit = _err(lambda: admit(s, ca, 2, "JSON"))
        direct = _err(lambda: ca.to("ACCEPTED", by="CONTROL_RESEARCH", evidence_ref="EV:1"))
        ca.to("VERIFIED", by="CONTROL_RESEARCH", evidence_ref="EV:a1"); ca.to("ACCEPTED", by="CONTROL_RESEARCH", evidence_ref="EV:a2")
        ref = admit(s, ca, 2, "JSON")
        cb.to("VERIFIED", by="CONTROL_RESEARCH", evidence_ref="EV:b1"); cb.to("REJECTED", by="CONTROL_RESEARCH", evidence_ref="EV:b2")
        cc.to("EXPIRED", by="MACHINE:TTL", evidence_ref="TTL:cc")
        wrong_role = _err(lambda: cd.to("VERIFIED", by="MACHINE:TTL", evidence_ref="EV:d"))
        no_ev = _err(lambda: cd.to("VERIFIED", by="CONTROL_RESEARCH", evidence_ref=""))
        rejected_admit, expired_admit = _err(lambda: admit(s, cb, 2, "JSON")), _err(lambda: admit(s, cc, 2, "JSON"))
        undead = _err(lambda: cb.to("ACCEPTED", by="CONTROL_RESEARCH", evidence_ref="EV:b3"))
        found = lambda needle: [h["claim_ref"] for h in ret.text(needle)["results"]]  # noqa: E731
        a = [["unverified_cannot_enter_knowledge", before_admit == "CANDIDATE_NOT_ACCEPTED"], ["cannot_skip_verified", direct.startswith("TRANSITION_INVALID")],
             ["accepted_candidate_found_in_knowledge", found("YAML") == [ref]], ["rejected_not_in_knowledge", found("免費") == [] and rejected_admit == "CANDIDATE_NOT_ACCEPTED"],
             ["expired_not_in_knowledge", found("雲端") == [] and expired_admit == "CANDIDATE_NOT_ACCEPTED"], ["wrong_role_refused", wrong_role == "ROLE_NOT_RESPONSIBLE"],
             ["evidence_ref_required", no_ev == "EVIDENCE_REF_REQUIRED"], ["terminal_states_stay_terminal", undead.startswith("TRANSITION_INVALID")],
             ["every_transition_has_role_and_evidence", all(e["by"] and e["evidence_ref"] for c in (ca, cb, cc) for e in c.log)]]
        st = {"states": {c.cid: c.state for c in (ca, cb, cc, cd)}, "logs": {c.cid: c.log for c in (ca, cb, cc)}, "integration": "HYPOTHESIS: knowledge_intake/research_source_normalization hook not yet checked"}
    return _out("S_CANDIDATE_PROMOTION", a, st)


SCENARIOS = {"amnesia": ("FP4", fp_amnesia_resume), "knowledge": ("FP5", fp_knowledge_lifecycle), "archive": ("FP6", fp_archive_isolation), "promotion": ("FP7", fp_candidate_promotion)}


def replay(n: int = 3, evid: Path = EVID) -> dict[str, Any]:
    per, total, same = {}, 0, 0
    for key, (fp, fn) in SCENARIOS.items():
        runs = [fn() for _ in range(n)]
        ok = all(r["ok"] for r in runs) and len({r["digest"] for r in runs}) == 1
        per[fp] = {"scenario": runs[0]["name"], "runs": n, "ok": ok, "digest": runs[0]["digest"], "assertions": len(runs[0]["assertions"])}
        total, same = total + 1, same + int(ok)
    rep = {"evidence_level": "SIMULATED_PASS", "equivalence_rate": same / total, "per_fast_path": per, "ok": same == total}
    evid.mkdir(parents=True, exist_ok=True)
    (evid / "replay.json").write_text(json.dumps(rep, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    return rep


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=[*SCENARIOS, "replay"])
    a = ap.parse_args()
    r = replay() if a.cmd == "replay" else SCENARIOS[a.cmd][1]()
    print(json.dumps({k: v for k, v in r.items() if k != "state"}, ensure_ascii=False)[:900])
    print(("SIMULATED_PASS " if r["ok"] else "FAILED ") + a.cmd)
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
