#!/usr/bin/env python3
"""Maintain one reusable Executor construction record without creating a second truth store."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/construction_session_record.schema.json"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save(path: str | Path, value: dict[str, Any]) -> None:
    Path(path).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def validate(record: dict[str, Any]) -> None:
    errors = sorted(
        Draft202012Validator(
            load(SCHEMA),
            format_checker=FormatChecker(),
        ).iter_errors(record),
        key=lambda e: list(e.path),
    )
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def count_repairs(record: dict[str, Any], error_id: str) -> int:
    return sum(
        1
        for event in record.get("events", [])
        if event.get("event_type") == "REPAIR_ATTEMPT"
        and event.get("error_id") == error_id
    )


def create(record_id: str, work_unit_ref: str, task_ref: str | None) -> dict[str, Any]:
    timestamp = now()
    record = {
        "schema_version": "1.0",
        "record_id": record_id,
        "authority": "OPERATIONAL_TRACE_ONLY",
        "role_id": "ROLE:EXECUTOR",
        "work_unit_ref": work_unit_ref,
        "status": "ACTIVE",
        "current_task_ref": task_ref,
        "canonical_truth_refs": [],
        "repair_policy": {
            "max_attempts_per_error": 1,
            "enforced_by": "construction_session_record.py",
        },
        "events": [{
            "event_id": f"EV:{record_id}:001",
            "event_type": "SESSION_STARTED",
            "task_ref": task_ref,
            "error_id": None,
            "repair_attempt": 0,
            "summary": "Construction session record created/reused.",
            "result_ref": None,
            "evidence_refs": [],
            "timestamp": timestamp,
        }],
        "created_at": timestamp,
        "updated_at": timestamp,
    }
    validate(record)
    return record


def append(
    record: dict[str, Any],
    *,
    event_type: str,
    summary: str,
    task_ref: str | None = None,
    error_id: str | None = None,
    result_ref: str | None = None,
    evidence_refs: list[str] | None = None,
) -> dict[str, Any]:
    if record["authority"] != "OPERATIONAL_TRACE_ONLY":
        raise ValueError("NOT_OPERATIONAL_RECORD")
    if event_type == "REPAIR_ATTEMPT":
        if not error_id:
            raise ValueError("REPAIR_ATTEMPT_REQUIRES_ERROR_ID")
        if count_repairs(record, error_id) >= 1:
            raise ValueError(f"REPAIR_ATTEMPT_LIMIT_REACHED:{error_id}")

    out = dict(record)
    out["events"] = list(record["events"])
    event_id = f"EV:{record['record_id']}:{len(out['events']) + 1:03d}"
    out["events"].append({
        "event_id": event_id,
        "event_type": event_type,
        "task_ref": task_ref or record.get("current_task_ref"),
        "error_id": error_id,
        "repair_attempt": 1 if event_type == "REPAIR_ATTEMPT" else 0,
        "summary": summary,
        "result_ref": result_ref,
        "evidence_refs": sorted(set(evidence_refs or [])),
        "timestamp": now(),
    })
    if task_ref is not None:
        out["current_task_ref"] = task_ref
    if event_type == "REPORT_REQUIRED":
        out["status"] = "REPORT_REQUIRED"
    elif event_type in {"SIMULATION_CLOSE", "RESULT_RETURNED"}:
        out["status"] = "COMPLETE"
    out["updated_at"] = now()
    validate(out)
    return out


def main() -> int:
    parser = argparse.ArgumentParser()
    sub = parser.add_subparsers(dest="command", required=True)

    p = sub.add_parser("create")
    p.add_argument("--record-id", required=True)
    p.add_argument("--work-unit-ref", required=True)
    p.add_argument("--task-ref")
    p.add_argument("--output", required=True)

    p = sub.add_parser("append")
    p.add_argument("--record", required=True)
    p.add_argument("--event-type", required=True)
    p.add_argument("--summary", required=True)
    p.add_argument("--task-ref")
    p.add_argument("--error-id")
    p.add_argument("--result-ref")
    p.add_argument("--evidence-ref", action="append", default=[])
    p.add_argument("--output", required=True)

    args = parser.parse_args()
    try:
        if args.command == "create":
            out = create(args.record_id, args.work_unit_ref, args.task_ref)
        else:
            out = append(
                load(args.record),
                event_type=args.event_type,
                summary=args.summary,
                task_ref=args.task_ref,
                error_id=args.error_id,
                result_ref=args.result_ref,
                evidence_refs=args.evidence_ref,
            )
        save(args.output, out)
        print(json.dumps({
            "status":"PASS",
            "record_id":out["record_id"],
            "record_status":out["status"],
            "event_count":len(out["events"]),
        }, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"status":"BLOCK","error":str(exc)}, ensure_ascii=False, indent=2))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
