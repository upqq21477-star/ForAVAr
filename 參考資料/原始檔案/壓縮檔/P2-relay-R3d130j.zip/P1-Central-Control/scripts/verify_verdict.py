"""verify_verdict -- evidence -> verdict, deterministic (CAP-VERIFY).  PASS | FAIL (names the failing evidence item) | INCOMPLETE.
Only tool-produced evidence (attempt outcomes, exit codes) is read; executor self-report is not an input.
Idempotency key = (task, evidence hash): a journaled verdict with the same key is reused, never recomputed.
A verify error is INCOMPLETE + error_code, never FAIL."""
from __future__ import annotations

import hashlib
import json
from typing import Any


def evidence_hash(ev: Any) -> str:
    return hashlib.sha256(json.dumps(ev, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")).hexdigest()


def _decide(ev: Any) -> tuple[str, list[str], list[str]]:
    atts = ev.get("attempts") if isinstance(ev, dict) else None
    if not atts:
        return "INCOMPLETE", [], ["EVIDENCE_MISSING"]
    i, last = len(atts) - 1, atts[-1]
    out = last.get("outcome")
    if out == "failure":
        return "FAIL", [f"attempt:{i}:outcome=failure"], []
    if out == "success":
        ec = last.get("exit_code")
        if ec not in (None, 0):  # the tool's exit code contradicts the recorded outcome
            return "FAIL", [f"attempt:{i}:exit_code={ec}"], []
        return "PASS", [], []
    return "INCOMPLETE", [], [f"ATTEMPT_{i}_OUTCOME_{out}"] + ([str(last["error_code"])] if last.get("error_code") else [])


def verify(task: str, ev: Any, prior: list[dict[str, Any]] | None = None) -> dict[str, Any]:
    try:
        key = f"{task}:{evidence_hash(ev)[:16]}"
        for p in prior or []:
            if p.get("key") == key:
                return {**p, "reused": True}
        verdict, failed, reasons = _decide(ev)
        return {"task": task, "key": key, "verdict": verdict, "failed": failed, "reasons": reasons}
    except Exception as e:  # verify's own failure is missing evidence, not a failed task
        return {"task": task, "key": f"{task}:", "verdict": "INCOMPLETE", "failed": [], "reasons": ["VERIFY_ERROR"],
                "error_code": "VERIFY_ERROR:" + type(e).__name__}
