#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import change_impact_scan as v1
import repository_architecture_evidence as evidence_adapter

ROOT = Path(__file__).resolve().parents[2]


def _registered_systems(root: Path) -> list[str]:
    path = root / "P1-Central-Control/system_registry.json"
    if not path.exists():
        return []
    data = json.loads(path.read_text(encoding="utf-8"))
    return [x["system_id"] for x in data.get("systems", [])]


def _sha(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:16]


def git_change_entries(root: Path, base_ref: str, head_ref: str) -> list[dict[str, str]]:
    proc = subprocess.run(
        ["git", "-c", "core.quotepath=false", "diff", "--name-status", "-M", "--find-copies", base_ref, head_ref],
        cwd=root,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr.strip() or "git diff --name-status failed")
    rows: list[dict[str, str]] = []
    for line in proc.stdout.splitlines():
        fields = line.split("\t")
        if not fields:
            continue
        status = fields[0]
        if status.startswith("R") and len(fields) >= 3:
            rows.append({"status": "RENAMED", "old_path": fields[1], "path": fields[2]})
        elif status.startswith("C") and len(fields) >= 3:
            rows.append({"status": "COPIED", "old_path": fields[1], "path": fields[2]})
        elif len(fields) >= 2:
            rows.append({"status": status, "path": fields[1]})
    return rows


def _reverse_graph(edges: list[dict[str, str]]) -> dict[str, set[str]]:
    graph: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        graph[edge["target"]].add(edge["source"])
    return graph


def transitive_dependents(edges: list[dict[str, str]], seeds: set[str]) -> tuple[list[str], list[str]]:
    reverse = _reverse_graph(edges)
    queue = deque(sorted(seeds))
    seen = set(seeds)
    while queue:
        node = queue.popleft()
        for parent in sorted(reverse.get(node, set())):
            if parent not in seen:
                seen.add(parent)
                queue.append(parent)
    direct = sorted(set().union(*(reverse.get(seed, set()) for seed in seeds))) if seeds else []
    transitive = sorted(seen - seeds - set(direct))
    return direct, transitive


def run_v2(
    *,
    paths: list[str],
    base_ref: str,
    head_ref: str,
    root_path: str | Path = ROOT,
    semantic: bool = True,
) -> dict[str, Any]:
    root = Path(root_path).resolve()
    base = v1.run(paths=paths, base_ref=base_ref, head_ref=head_ref)
    change_event = dict(base["change_event"])
    impact = dict(base["impact_scan"])

    semantic_info: dict[str, Any] = {
        "enabled": semantic,
        "change_entries": [],
        "change_kinds": {},
        "dependency_edges": [],
        "direct_dependents": [],
        "transitive_dependents": [],
        "unknown_dependencies": [],
        "affected_systems": [],
        "semantic_unknowns": [],
    }

    if semantic:
        try:
            entries = git_change_entries(root, base_ref, head_ref)
        except RuntimeError:
            entries = []
            semantic_info["semantic_unknowns"].append("GIT_CHANGE_METADATA_UNAVAILABLE")
        semantic_info["change_entries"] = entries
        semantic_info["change_kinds"] = {
            row.get("path", row.get("old_path", "")): row["status"] for row in entries
        }

        repository_evidence = evidence_adapter.collect(
            root,
            _registered_systems(root),
        )
        edges = repository_evidence["dependency"]["edges"]
        unresolved = repository_evidence["dependency"]["unresolved"]
        semantic_info["dependency_edges"] = edges
        semantic_info["unknown_dependencies"] = unresolved

        current_paths = set(row["path"] for row in entries if row.get("path"))
        current_paths.update(paths)
        direct, transitive = transitive_dependents(edges, current_paths)
        semantic_info["direct_dependents"] = direct
        semantic_info["transitive_dependents"] = transitive

        systems = set()
        for path in current_paths | set(direct) | set(transitive):
            system = evidence_adapter.system_for_path(path)
            if system:
                systems.add(system)
        semantic_info["affected_systems"] = sorted(systems)

        if unresolved:
            semantic_info["semantic_unknowns"].append("UNRESOLVED_LOCAL_DEPENDENCY")

        rename_or_move = [
            row for row in entries
            if row["status"] in {"RENAMED", "COPIED"}
        ]
        if rename_or_move:
            semantic_info["semantic_unknowns"].append("RENAME_OR_COPY_REQUIRES_BASE_SIDE_RESOLUTION")

        if direct or transitive:
            impact["reason_codes"] = sorted(set(
                list(impact.get("reason_codes", [])) + ["DEPENDENCY_AFFECTED_SCOPE"]
            ))

    semantic_hash = _sha(semantic_info)
    impact["scan_id"] = "IMPACT:" + _sha({
        "change_id": change_event["change_id"],
        "semantic": semantic_hash,
    })
    impact["semantic_impact"] = semantic_info
    impact["dependency_aware"] = True

    if semantic_info["semantic_unknowns"] and impact["status"] == "PASS":
        impact["status"] = "BLOCK"
        impact["decision"] = "BLOCK"
        impact["reason_codes"] = sorted(set(
            list(impact.get("reason_codes", [])) + ["SEMANTIC_IMPACT_UNRESOLVED"]
        ))

    return {
        "schema_version": "2.0",
        "change_event": change_event,
        "impact_scan": impact,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "detector": "P1_CHANGE_IMPACT_V2",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 semantic dependency-aware Change Impact v2")
    parser.add_argument("--base", required=True)
    parser.add_argument("--head", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()

    paths = v1.changed_paths_from_git(args.base, args.head)
    result = run_v2(paths=paths, base_ref=args.base, head_ref=args.head)
    encoded = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    if args.output:
        Path(args.output).write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0 if result["impact_scan"]["decision"] == "PROCEED" else 3


if __name__ == "__main__":
    raise SystemExit(main())
