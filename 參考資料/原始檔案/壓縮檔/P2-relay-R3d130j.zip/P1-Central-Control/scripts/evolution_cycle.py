#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

import capability_reevaluation
import routing_reevaluation
import regression_selection
import adoption_rollback
import evolution_cycle_execution


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "evolution_cycle.schema.json"
CAPABILITY_REGISTRY_PATH = ROOT / "P1-Central-Control" / "capability_registry.json"
REGRESSION_SELECTION_REGISTRY_PATH = ROOT / "P1-Central-Control" / "regression_selection_registry.json"
IMPACT_SCHEMA_PATH = SCHEMA_DIR / "impact_scan.schema.json"


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def identity(object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(value)
    result["object_id"] = f"EVOLUTION_CYCLE:{object_id}"
    result["kind"] = "EVOLUTION_CYCLE"
    result["schema_version"] = "1.0"
    result["content_hash"] = content_hash(result)
    return result


def reg() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "evolution_cycle.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    return registry


def validate(report: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(schema, registry=reg(), format_checker=FormatChecker()).iter_errors(report),
        key=lambda item: list(item.path),
    )
    if errors:
        raise ValueError("evolution_cycle.schema.json 驗證失敗: " + "; ".join(item.message for item in errors))
    if report.get("content_hash") != content_hash(report):
        raise ValueError("Evolution Cycle content_hash 不正確")


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def impact_from(value: dict[str, Any]) -> dict[str, Any]:
    impact = value.get("impact_scan", value)
    if not isinstance(impact, dict):
        raise ValueError("M6 缺少 impact_scan")
    return impact


def cycle(
    impact_document: dict[str, Any],
    *,
    measurements: dict[str, Any] | None = None,
    regression_result: dict[str, Any] | None = None,
    route_state: dict[str, Any] | None = None,
    capability_registry: dict[str, Any] | None = None,
    execute_regressions: bool = False,
    cycle_id: str = "AUTO",
) -> dict[str, Any]:
    impact = impact_from(impact_document)
    impact_schema = json.loads(IMPACT_SCHEMA_PATH.read_text(encoding="utf-8"))
    Draft202012Validator(impact_schema, format_checker=FormatChecker()).validate(impact)

    stages=[]
    if impact["status"] != "PASS" or impact["decision"] != "PROCEED":
        stages.append({
            "stage_id":"IMPACT_SCAN",
            "status":"BLOCK",
            "object_ref":impact.get("scan_id"),
            "reason_code":"IMPACT_BLOCKED"
        })
        report=identity(cycle_id, {
            "cycle_id":cycle_id,
            "source_change_id":impact.get("change_id","UNKNOWN"),
            "stages":stages,
            "status":"BLOCK"
        })
        validate(report)
        return report

    stages.append({
        "stage_id":"IMPACT_SCAN",
        "status":"PASS",
        "object_ref":impact["scan_id"],
        "reason_code":None
    })

    registry = capability_registry or load(CAPABILITY_REGISTRY_PATH)
    m2 = capability_reevaluation.reevaluate(impact, capability_registry=registry, measurements=measurements)
    stages.append({
        "stage_id":"CAPABILITY_REEVALUATION",
        "status":m2["status"],
        "object_ref":m2["object_id"],
        "reason_code":None if m2["status"]=="PASS" else "MISSING_MEASUREMENT"
    })
    if m2["status"] == "BLOCK":
        final="BLOCK"
        report=identity(cycle_id, {"cycle_id":cycle_id,"source_change_id":impact["change_id"],"stages":stages,"status":final})
        validate(report)
        return report

    m3 = routing_reevaluation.reevaluate(m2)
    stages.append({
        "stage_id":"ROUTING_REEVALUATION",
        "status":m3["status"],
        "object_ref":m3["object_id"],
        "reason_code":None if m3["status"]=="PASS" else "ROUTE_NOT_READY"
    })
    if m3["status"] == "BLOCK":
        final="BLOCK"
        report=identity(cycle_id, {"cycle_id":cycle_id,"source_change_id":impact["change_id"],"stages":stages,"status":final})
        validate(report)
        return report

    m4 = regression_selection.select(
        m3,
        impact,
        registry=regression_selection.load_set_registry(REGRESSION_SELECTION_REGISTRY_PATH),
    )
    stages.append({
        "stage_id":"REGRESSION_SELECTION",
        "status":m4["status"],
        "object_ref":m4["object_id"],
        "reason_code":None if m4["status"]=="PASS" else "REGRESSION_NOT_READY"
    })

    if m4["status"] == "BLOCK":
        final="BLOCK"
        report=identity(cycle_id, {"cycle_id":cycle_id,"source_change_id":impact["change_id"],"stages":stages,"status":final})
        validate(report)
        return report

    regression_result, execution_stage = evolution_cycle_execution.prepare_regression_stage(
        m4,
        regression_result=regression_result,
        execute_regressions=execute_regressions,
    )
    if execution_stage is not None:
        stages.append(execution_stage)

    if regression_result is None or route_state is None or m4["status"] != "PASS":
        stages.append({
            "stage_id":"ADOPTION_ROLLBACK",
            "status":"INSUFFICIENT_DATA",
            "object_ref":None,
            "reason_code":"ACTUAL_REGRESSION_RESULT_OR_ROUTE_STATE_MISSING"
        })
        final="INSUFFICIENT_DATA"
    else:
        m5 = adoption_rollback.decide(m4, regression_result, route_state)
        stages.append({
            "stage_id":"ADOPTION_ROLLBACK",
            "status":m5["status"],
            "object_ref":m5["object_id"],
            "reason_code":None if m5["status"]=="PASS" else "ADOPTION_BLOCKED_OR_DEFERRED"
        })
        final=m5["status"]

    report=identity(
        cycle_id,
        {
            "cycle_id":cycle_id,
            "source_change_id":impact["change_id"],
            "stages":stages,
            "status":final
        },
    )
    validate(report)
    return report


def main() -> int:
    parser=argparse.ArgumentParser(description="P1 Evolution Cycle M1→M7")
    parser.add_argument("impact_scan")
    parser.add_argument("output")
    parser.add_argument("--measurements")
    parser.add_argument("--regression-result")
    parser.add_argument("--route-state")
    parser.add_argument("--execute-regressions", action="store_true")
    args=parser.parse_args()

    report=cycle(
        load(Path(args.impact_scan)),
        measurements=load(Path(args.measurements)) if args.measurements else None,
        regression_result=load(Path(args.regression_result)) if args.regression_result else None,
        route_state=load(Path(args.route_state)) if args.route_state else None,
        execute_regressions=args.execute_regressions,
    )
    Path(args.output).write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n",encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] in {"PASS","INSUFFICIENT_DATA"} else 3


if __name__=="__main__":
    raise SystemExit(main())
