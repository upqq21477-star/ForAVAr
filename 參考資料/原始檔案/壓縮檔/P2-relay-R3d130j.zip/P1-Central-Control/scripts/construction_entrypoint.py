#!/usr/bin/env python3
"""Canonical admission point for building or changing P1 capabilities."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from construction_lifecycle import execute as execute_lifecycle
from construction_registration import validate as validate_registration


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_PATH = ROOT / "P1-Central-Control" / "schemas" / "construction_request.schema.json"
RESULT_SCHEMA_PATH = ROOT / "P1-Central-Control" / "schemas" / "construction_result.schema.json"


def _load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _resolve(base: Path, raw: str) -> Path:
    path = Path(raw)
    return path if path.is_absolute() else base / path


def _validate_request(request: dict[str, Any]) -> None:
    schema = _load_json(SCHEMA_PATH)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(request),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def _hash(value: Any) -> str:
    material = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(material).hexdigest()


def validate_result(result: dict[str, Any]) -> bool:
    schema = _load_json(RESULT_SCHEMA_PATH)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(result),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))
    return True


def _run_post_acceptance(base: Path, checks: list[dict[str, Any]]) -> list[dict[str, Any]]:
    results = []
    for check in checks:
        command = check["command"]
        timeout = check["timeout_seconds"]
        inputs = [_resolve(base, item) for item in check.get("inputs", [])]
        outputs = [_resolve(base, item) for item in check.get("outputs", [])]
        for path in inputs:
            if not path.is_file():
                raise FileNotFoundError(f"POST_CHECK_INPUT_MISSING:{path}")
        completed = subprocess.run(
            command,
            cwd=str(base),
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        if completed.returncode != 0:
            raise RuntimeError(
                "POST_CHECK_FAILED:"
                + " ".join(command)
                + f":returncode={completed.returncode}"
            )
        for path in outputs:
            if not path.is_file() or path.stat().st_size == 0:
                raise RuntimeError(f"POST_CHECK_OUTPUT_MISSING:{path}")
        results.append({
            "command": command,
            "returncode": completed.returncode,
            "stdout_sha256": hashlib.sha256(
                completed.stdout.encode("utf-8")
            ).hexdigest(),
            "stderr_sha256": hashlib.sha256(
                completed.stderr.encode("utf-8")
            ).hexdigest(),
        })
    return results


def execute(request: dict[str, Any], base_dir: str | Path | None = None) -> dict[str, Any]:
    _validate_request(request)

    base = Path(base_dir or ".").resolve()
    contract_path = _resolve(base, request["lifecycle_contract"])
    if not contract_path.is_file():
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "reason": "LIFECYCLE_CONTRACT_MISSING",
        }

    contract = _load_json(contract_path)
    if contract.get("applies_to") != request["target_type"]:
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "reason": "LIFECYCLE_TARGET_TYPE_MISMATCH",
        }

    registration_request = request["registration"]
    if (
        registration_request.get("target_type") != request["target_type"]
        or registration_request.get("target_id") != request["target_id"]
    ):
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "phase": "REGISTRATION",
            "reason": "REGISTRATION_TARGET_MISMATCH",
            "finalized": False,
        }

    spec_path = _resolve(base, request["semantic_spec"])
    if not spec_path.is_file():
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "reason": "SEMANTIC_SPEC_MISSING",
        }

    stages = contract.get("stages", [])
    if not stages or stages[0].get("stage_id") != "SEMANTIC_SPEC":
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "reason": "SEMANTIC_STAGE_MISSING",
        }
    lifecycle_semantic_inputs = stages[0].get("inputs", [])
    if lifecycle_semantic_inputs != [request["semantic_spec"]]:
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "reason": "SEMANTIC_SPEC_REF_MISMATCH",
        }

    lifecycle = execute_lifecycle(contract, base)
    if lifecycle["status"] != "PASS":
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "phase": "CONSTRUCTION_LIFECYCLE",
            "lifecycle": lifecycle,
            "finalized": False,
        }

    try:
        registration = validate_registration(
            request["registration"],
            base_dir=base,
            canonical_registry_root=request.get("canonical_registry_root"),
        )
    except Exception as exc:
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "phase": "REGISTRATION",
            "error": str(exc),
            "lifecycle": lifecycle,
            "finalized": False,
        }
    if registration["status"] != "PASS":
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "phase": "REGISTRATION",
            "registration": registration,
            "lifecycle": lifecycle,
            "finalized": False,
        }

    try:
        post_checks = _run_post_acceptance(
            base, request.get("post_acceptance_commands", [])
        )
    except Exception as exc:
        return {
            "status": "BLOCK",
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "phase": "POST_ACCEPTANCE",
            "error": str(exc),
            "lifecycle": lifecycle,
            "finalized": False,
        }

    result = {
        "schema_version": "1.0",
        "status": "PASS",
        "request_id": request["request_id"],
        "target_type": request["target_type"],
        "target_id": request["target_id"],
        "phase": "FINALIZE",
        "finalized": True,
        "lifecycle": lifecycle,
        "registration": registration,
        "post_acceptance": post_checks,
        "construction_fingerprint": _hash({
            "request_id": request["request_id"],
            "target_type": request["target_type"],
            "target_id": request["target_id"],
            "lifecycle": lifecycle.get("lifecycle_id"),
            "post_acceptance": post_checks,
        }),
    }
    validate_result(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("request")
    parser.add_argument("--base-dir", default=".")
    args = parser.parse_args()

    request = _load_json(_resolve(Path(args.base_dir).resolve(), args.request))
    result = execute(request, args.base_dir)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
