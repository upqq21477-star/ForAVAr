#!/usr/bin/env python3
"""Run declared positive/negative/recovery scenarios against a target."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from runtime_evidence_probe import execute as run_probe
from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/scenario_oracle.schema.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any]) -> None:
    schema = _load(SCHEMA)
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def execute(request: dict[str, Any]) -> dict[str, Any]:
    _validate(request)
    classes = set(request.get("minimum_classes", []))
    observed_classes = {s["class"] for s in request["scenarios"]}
    missing_classes = sorted(classes - observed_classes)
    if missing_classes:
        return {
            "oracle_id": request["oracle_id"],
            "status": "BLOCK",
            "missing_classes": missing_classes,
            "results": []
        }

    results = []
    for index, scenario in enumerate(request["scenarios"]):
        probe = run_probe({
            "schema_version": "1.0",
            "probe_id": f"PROBE:{str(request['oracle_id']).replace(':', '.')}.{index}",
            "root_path": request["root_path"],
            "command": scenario["command"],
            "timeout_seconds": scenario.get("timeout_seconds", 120),
            "expected_exit_code": scenario["expected_exit_code"],
        })
        results.append({
            "scenario_id": scenario["scenario_id"],
            "class": scenario["class"],
            "status": probe["status"],
            "return_code": probe["return_code"],
            "duration_ms": probe["duration_ms"],
            "stdout_sha256": probe["stdout_sha256"],
            "stderr_sha256": probe["stderr_sha256"]
        })

    status = "PASS" if all(item["status"] == "PASS" for item in results) else "FAIL"
    return {
        "oracle_id": request["oracle_id"],
        "status": status,
        "missing_classes": [],
        "results": results
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Run scenario oracle")
    parser.add_argument("request")
    args = parser.parse_args()
    result = execute(_load(Path(args.request).resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
