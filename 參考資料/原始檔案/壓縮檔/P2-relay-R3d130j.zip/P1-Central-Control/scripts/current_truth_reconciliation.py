#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PASS = "PASS"
BLOCK = "RECONCILIATION_REQUIRED"
INCOMPLETE = "INCOMPLETE"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def classify_repository_result(
    current: dict[str, Any],
    repository_result: dict[str, Any] | None,
) -> tuple[str | None, dict[str, Any] | None]:
    """Classify persisted ResultPacket without making it a second truth owner."""
    if repository_result is None:
        return None, None

    try:
        import sys
        scripts = Path(__file__).resolve().parent
        if str(scripts) not in sys.path:
            sys.path.insert(0, str(scripts))
        from packet_layer import validate_result_packet
        validate_result_packet(repository_result)
    except Exception as exc:
        return None, {
            "status": BLOCK,
            "reason_code": "REPOSITORY_RESULT_INVALID",
            "error": str(exc),
        }

    result_id = repository_result.get("result_id")
    execution_ref = repository_result.get("execution_record_ref")
    if not result_id or not execution_ref:
        return None, {
            "status": BLOCK,
            "reason_code": "REPOSITORY_RESULT_IDENTITY_INCOMPLETE",
        }

    current_results = set(current.get("result_refs") or [])
    status = "INGESTED" if result_id in current_results else "PERSISTED_PENDING_CENTRAL"
    return status, {
        "status": PASS if status == "INGESTED" else INCOMPLETE,
        "reason_code": None if status == "INGESTED" else "REPOSITORY_RESULT_PENDING_CENTRAL_INGESTION",
        "result_id": result_id,
        "execution_record_ref": execution_ref,
    }


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _observation_fields(observation: dict[str, Any]) -> dict[str, Any]:
    run = observation.get("workflow_run") or observation.get("run") or {}
    job = observation.get("job") or {}
    evidence = observation.get("evidence") or {}
    steps = observation.get("steps")
    if steps is None:
        steps = job.get("steps", [])
    step_count = evidence.get("step_count")
    if step_count is None:
        step_count = len(steps) if isinstance(steps, list) else 0
    step_observed = evidence.get("step_execution_observed")
    if step_observed is None:
        step_observed = step_count > 0
    logs_available = evidence.get("logs_available")
    if logs_available is None:
        logs_available = bool(job.get("logs_url"))
    return {
        "observed_at": observation.get("observed_at"),
        "workflow_identity": observation.get("workflow_identity")
        or observation.get("workflow")
        or run.get("name"),
        "workflow_id": observation.get("workflow_id")
        or observation.get("workflow_run_id"),
        "run_id": observation.get("run_id") or run.get("id"),
        "run_attempt": observation.get("run_attempt") or run.get("run_attempt"),
        "attempt_id": observation.get("attempt_id")
        or observation.get("job_id")
        or job.get("id"),
        "head_sha": observation.get("head_sha") or run.get("head_sha"),
        "evidence_rank": (
            int(bool(step_observed)),
            int(step_count),
            int(bool(logs_available)),
        ),
    }


def compare_observations(existing: dict[str, Any], candidate: dict[str, Any]) -> str:
    """Compare observations without inventing a second truth store.

    Returns NEWER, OLDER, EQUAL, CONFLICT, or INCOMPLETE.
    """
    left = _observation_fields(existing)
    right = _observation_fields(candidate)

    if not left["observed_at"] or not right["observed_at"]:
        return INCOMPLETE

    try:
        left_time = datetime.fromisoformat(str(left["observed_at"]).replace("Z", "+00:00"))
        right_time = datetime.fromisoformat(str(right["observed_at"]).replace("Z", "+00:00"))
    except ValueError:
        return INCOMPLETE

    if left_time != right_time:
        return "NEWER" if right_time > left_time else "OLDER"

    if (
        left["workflow_identity"]
        and right["workflow_identity"]
        and left["workflow_identity"] != right["workflow_identity"]
    ):
        return "CONFLICT"

    if left["run_id"] != right["run_id"]:
        return "NEWER" if (
            isinstance(right["run_id"], int)
            and isinstance(left["run_id"], int)
            and right["run_id"] > left["run_id"]
        ) else "CONFLICT"

    if left["run_attempt"] != right["run_attempt"]:
        if left["run_attempt"] is None or right["run_attempt"] is None:
            return INCOMPLETE
        return "NEWER" if right["run_attempt"] > left["run_attempt"] else "OLDER"

    if left["attempt_id"] != right["attempt_id"]:
        return "CONFLICT"

    if left["head_sha"] != right["head_sha"]:
        return "CONFLICT"

    if left["evidence_rank"] != right["evidence_rank"]:
        return "NEWER" if right["evidence_rank"] > left["evidence_rank"] else "OLDER"

    return "EQUAL"


def check(condition: bool, check_id: str, reason_code: str, refs: list[str]) -> dict[str, Any]:
    return {
        "check_id": check_id,
        "status": PASS if condition else BLOCK,
        "reason_code": None if condition else reason_code,
        "refs": refs,
    }


def incomplete_check(condition: bool, check_id: str, reason_code: str, refs: list[str]) -> dict[str, Any]:
    return {
        "check_id": check_id,
        "status": PASS if condition else INCOMPLETE,
        "reason_code": None if condition else reason_code,
        "refs": refs,
    }


def reconcile(
    *,
    current: dict[str, Any],
    work_packet: dict[str, Any],
    truth_record: dict[str, Any],
    runtime_fixture: dict[str, Any],
    repository_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    stage = current.get("current_stage", {})
    implementation = current.get("implementation_control", {})
    latest = current.get("latest_runtime_observation") or stage.get("latest_runtime_observation") or {}
    checks: list[dict[str, Any]] = []
    repository_result_status, repository_result_check = classify_repository_result(
        current,
        repository_result,
    )
    if repository_result_check is not None:
        reason_code = repository_result_check.get(
            "reason_code",
            "REPOSITORY_RESULT_RECONCILIATION_FAILED",
        )
        if reason_code == "REPOSITORY_RESULT_PENDING_CENTRAL_INGESTION":
            checks.append(
                incomplete_check(
                    False,
                    "REPOSITORY_RESULT_CANONICAL_BOUNDARY",
                    reason_code,
                    ["repository_result", "P1-CURRENT.json#result_refs"],
                )
            )
        else:
            checks.append(
                check(
                    repository_result_check["status"] == PASS,
                    "REPOSITORY_RESULT_CANONICAL_BOUNDARY",
                    reason_code,
                    ["repository_result", "P1-CURRENT.json#result_refs"],
                )
            )

    checks.append(check(
        work_packet.get("work_id") == stage.get("id"),
        "CURRENT_STAGE_MATCHES_WORK_PACKET",
        "CURRENT_STAGE_WORK_PACKET_MISMATCH",
        ["P1-CURRENT.json", implementation.get("active_work_packet", "")],
    ))

    merged_sha = stage.get("merged_commit_sha")
    truth_head = truth_record.get("head_sha")
    checks.append(incomplete_check(
        truth_head == merged_sha,
        "TRUTH_RECORD_HEAD_IS_CURRENT_STAGE_HEAD",
        "TRUTH_RECORD_HEAD_NOT_CURRENT_STAGE_HEAD",
        ["P1-CURRENT.json#current_stage.merged_commit_sha", "truth_record#head_sha"],
    ))

    previous_observation = latest if latest else {}
    observation_order = (
        compare_observations(previous_observation, runtime_fixture)
        if previous_observation and runtime_fixture
        else INCOMPLETE
    )
    checks.append(check(
        observation_order in {"NEWER", "EQUAL"}
        or (not previous_observation.get("observed_at") and observation_order == INCOMPLETE),
        "RUNTIME_OBSERVATION_ORDER",
        "STALE_OR_CONFLICTING_RUNTIME_OBSERVATION",
        ["P1-CURRENT.json#latest_runtime_observation", "runtime_fixture"],
    ))

    fixture_run_id = runtime_fixture.get("run", {}).get("id") or runtime_fixture.get("workflow_run_id")
    expected_run_id = latest.get("run_id")
    checks.append(check(
        fixture_run_id == expected_run_id or expected_run_id is None,
        "RUNTIME_FIXTURE_MATCHES_CURRENT",
        "RUNTIME_FIXTURE_MISMATCH",
        ["P1-CURRENT.json#latest_runtime_observation", "runtime_fixture#run.id"],
    ))

    runtime_classification = runtime_fixture.get("classification")
    record_status = truth_record.get("status")
    program_truth = truth_record.get("program_truth")
    expected_status = {
        "PROGRAM_VERIFIED": PASS,
        "PROGRAM_REGRESSION": "FAIL",
        "PROGRAM_UNRESOLVED": INCOMPLETE,
        "EVIDENCE_CONFLICT": INCOMPLETE,
        "BLOCKED": INCOMPLETE,
    }
    if program_truth in expected_status:
        checks.append(check(
            record_status == expected_status[program_truth],
            "CLOSURE_PROGRAM_TRUTH_ALIGNS_STATUS",
            "CLOSURE_PROGRAM_TRUTH_STATUS_MISMATCH",
            ["truth_record#program_truth", "truth_record#status"],
        ))

    failure_classifications = {"RUNNER_STARTUP_FAILURE", "WORKFLOW_EXECUTION_FAILURE"}
    checks.append(check(
        runtime_classification not in failure_classifications
        or record_status == INCOMPLETE
        or program_truth == "PROGRAM_VERIFIED",
        "RUNTIME_FAILURE_CLASSIFICATION_PRESERVED",
        "RUNTIME_FAILURE_MISCLASSIFIED",
        ["runtime_fixture#classification", "truth_record#status", "truth_record#program_truth"],
    ))

    stage_status = stage.get("status")
    checks.append(check(
        not (stage_status in {"VERIFIED", "COMPLETED", "PASS"} and record_status != "PASS"),
        "VERIFIED_STAGE_HAS_PASS_EVIDENCE",
        "VERIFIED_WITHOUT_PASS_EVIDENCE",
        ["P1-CURRENT.json#current_stage.status", "truth_record#status"],
    ))

    checks.append(check(
        not (
            record_status == PASS
            and runtime_classification in {"RUNNER_STARTUP_FAILURE", "WORKFLOW_EXECUTION_FAILURE"}
            and program_truth != "PROGRAM_VERIFIED"
        ),
        "PASS_REQUIRES_CLOSURE_FOR_EXTERNAL_FAILURE",
        "PASS_CONTRADICTS_EXTERNAL_FAILURE_WITHOUT_PROGRAM_TRUTH",
        ["truth_record#status", "truth_record#program_truth", "runtime_fixture#classification"],
    ))

    runtime_head = runtime_fixture.get("run", {}).get("head_sha")
    checks.append(check(
        runtime_head == truth_head,
        "TRUTH_RECORD_HEAD_MATCHES_RUNTIME_FIXTURE",
        "TRUTH_RECORD_RUNTIME_HEAD_MISMATCH",
        ["truth_record#head_sha", "runtime_fixture#run.head_sha"],
    ))

    blocking = [c for c in checks if c["status"] == BLOCK]
    incomplete = [c for c in checks if c["status"] == INCOMPLETE]

    if blocking:
        overall = BLOCK
    elif incomplete:
        overall = INCOMPLETE
    elif stage_status in {"VERIFIED", "COMPLETED", "PASS"} and record_status == "PASS":
        overall = PASS
    else:
        overall = INCOMPLETE

    return {
        "reconciliation_id": f"CURRENT_TRUTH_RECONCILIATION:{uuid.uuid4().hex[:16]}",
        "generated_at": now_iso(),
        "status": overall,
        "current_stage_id": stage.get("id"),
        "current_stage_status": stage_status,
        "truth_record_status": record_status,
        "program_truth": program_truth,
        "closure_status": truth_record.get("closure_status"),
        "current_merged_commit_sha": merged_sha,
        "truth_record_head_sha": truth_head,
        "runtime_run_id": fixture_run_id,
        "runtime_head_sha": runtime_head,
        "runtime_classification": runtime_classification,
        "repository_result_status": repository_result_status,
        "checks": checks,
        "blocking_conflicts": [c["reason_code"] for c in blocking],
        "incomplete_reasons": [c["reason_code"] for c in incomplete],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Current / Projection / Runtime Truth Reconciliation")
    parser.add_argument("--current", required=True)
    parser.add_argument("--work-packet", required=True)
    parser.add_argument("--truth-record", required=True)
    parser.add_argument("--runtime-fixture", required=True)
    parser.add_argument("--repository-result")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    result = reconcile(
        current=load_json(Path(args.current)),
        work_packet=load_json(Path(args.work_packet)),
        truth_record=load_json(Path(args.truth_record)),
        runtime_fixture=load_json(Path(args.runtime_fixture)),
        repository_result=(
            load_json(Path(args.repository_result))
            if args.repository_result
            else None
        ),
    )
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    return {PASS: 0, BLOCK: 2, INCOMPLETE: 3}[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
