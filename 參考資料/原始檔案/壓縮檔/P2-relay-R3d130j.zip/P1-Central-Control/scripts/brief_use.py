#!/usr/bin/env python3
"""R4L-S4 brief_use statistics (offline, stdlib only; evidence level SIMULATED_PASS).

Per delivered Brief: slots sent / slots cited / follow-up lookups.  Everything is recomputed from events
(BRIEF_DELIVERED, BRIEF_SLOTS_CITED, INFORMATION_GAP_PROPOSED); no counter field is stored anywhere.
Follow-up lookups = INFORMATION_GAP proposals recorded after that Brief's BRIEF_DELIVERED (same work, higher revision,
same brief_session_id).  Misses (D5 failure-driven): the ref of every follow-up is appended to brief_slots.json
as a slot ("<repo-root-relative file>::<symbol>"), validated by librarian.validate_slots; never removes, never duplicates.
"""
from __future__ import annotations

import argparse
import copy
import json
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import event_log as el  # noqa: E402
import librarian as lib  # noqa: E402


def record_use(log_path: Path, work_id: str, brief_session_id: str, *, cited: list[str] | None = None,
               gap_ref: str | None = None, occurred_at: str = "2026-10-14T00:00:00Z") -> dict:
    """Append one use-event for a task (revision = last revision of the work's SEGMENT table + 1)."""
    log = el.EventLog(log_path)
    prior = log.events_for("SEGMENT", work_id)
    rev = (prior[-1]["revision"] if prior else 0) + 1
    ev = el.make_brief_use_event(
        workflow_id=work_id, revision=rev, brief_session_id=brief_session_id,
        event_type="BRIEF_SLOTS_CITED" if cited else "INFORMATION_GAP_PROPOSED",
        slot_ids=cited, ref=gap_ref, occurred_at=occurred_at, seq=rev)
    log.append(ev)
    return ev


def compute_use(events: list[dict]) -> list[dict]:
    """Deterministic: input order ignored; result ordered by (work, delivery revision)."""
    ev = sorted((e for e in events if e["aggregate_type"] == "SEGMENT"),
                key=lambda e: (e["aggregate_id"], e["revision"]))
    out = []
    for d in (e for e in ev if e["event_type"] == "BRIEF_DELIVERED"):
        bid = d["segment_delta"]["brief_session_id"]
        sent = list(d["segment_delta"]["slot_ids"])
        mine = [e for e in ev if e["aggregate_id"] == d["aggregate_id"] and e["revision"] > d["revision"]
                and e["segment_delta"].get("brief_session_id") == bid]
        cited_all = sorted({s for e in mine if e["event_type"] == "BRIEF_SLOTS_CITED" for s in e["segment_delta"]["slot_ids"]})
        gaps = sorted({e["segment_delta"]["ref"] for e in mine if e["event_type"] == "INFORMATION_GAP_PROPOSED"})
        n_gap_events = sum(1 for e in mine if e["event_type"] == "INFORMATION_GAP_PROPOSED")
        out.append({"work_id": d["aggregate_id"], "brief_session_id": bid, "route": d["segment_delta"].get("route"),
                    "slots_sent": len(sent), "slots_cited": len([s for s in cited_all if s in sent]),
                    "cited_outside_sent": [s for s in cited_all if s not in sent],
                    "followup_lookups": n_gap_events, "missed_refs": gaps})
    return out


def slot_id_for(ref: str) -> str:
    return "S_GAP_" + "".join(c if c.isalnum() else "_" for c in ref.split("::", 1)[1]).upper()


def patch_slots(cfg: dict, uses: list[dict], root: Path = lib.ROOT) -> tuple[dict, list[str], list[str]]:
    """Append missed refs as slots on the route of the Brief that missed them.  Returns (new_cfg, added, rejected)."""
    new, added, rejected = copy.deepcopy(cfg), [], []
    for u in uses:
        for ref in u["missed_refs"]:
            if "::" not in ref or not u.get("route") or u["route"] not in new["routes"]:
                rejected.append(f"BAD_REF:{ref}")
                continue
            path, symbol = ref.split("::", 1)
            sid = slot_id_for(ref)
            if sid in new["slots"]:
                if sid not in new["routes"][u["route"]]["required_slots"]:
                    new["routes"][u["route"]]["required_slots"].append(sid)
                    added.append(f"{u['route']}:{sid}")
                continue
            trial = copy.deepcopy(new)
            trial["slots"][sid] = {"source": path, "symbol": symbol, "summary": "補查補入（D5 失敗驅動）"}
            trial["routes"][u["route"]]["required_slots"].append(sid)
            if lib.validate_slots(trial, root):
                rejected.append(f"INVALID_REF:{ref}")
                continue
            new = trial
            added.append(f"{u['route']}:{sid}")
    return new, added, rejected


def write_slots(cfg: dict, path: Path = lib.SLOTS_PATH, replace=os.replace) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    try:
        replace(tmp, path)
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def simulate() -> list[tuple[str, bool, str]]:
    res: list[tuple[str, bool, str]] = []
    cfg = lib.load_slots()
    route = "STARTUP"
    sample = lib.sample_brief(route, "B", cfg)

    def fresh():
        td = Path(tempfile.mkdtemp())
        log = td / "events.jsonl"
        lib.deliver(sample, log)
        return td, log

    def uses(log):
        return compute_use(el.EventLog(log).events_for("SEGMENT", sample["work_id"]))

    def case(name, fn):
        try:
            ok, note = fn()
        except Exception as e:  # noqa: BLE001
            ok, note = False, f"EXC {type(e).__name__}: {e}"
        res.append((name, ok, note))

    sent = [s["slot_id"] for s in sample["slots"]]
    ref_ok = "P1-Central-Control/scripts/librarian.py::validate_slots"

    def c1():
        td, log = fresh()
        record_use(log, sample["work_id"], sample["brief_session_id"], cited=sent[:1])
        u = uses(log)[0]
        return (u["slots_sent"] == len(sent) and u["slots_cited"] == 1 and u["followup_lookups"] == 0, str(u))
    case("sent/cited counted, no follow-up", c1)

    def c2():
        td, log = fresh()
        record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref=ref_ok)
        record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref="P1-Central-Control/scripts/event_log.py::make_segment_event")
        u = uses(log)[0]
        return (u["followup_lookups"] == 2 and len(u["missed_refs"]) == 2, str(u))
    case("INFORMATION_GAP after delivery counted", c2)

    def c3():
        td = Path(tempfile.mkdtemp()); log = td / "e.jsonl"
        record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref=ref_ok)  # before delivery
        lib.deliver(sample, log)
        u = uses(log)[0]
        return (u["followup_lookups"] == 0, str(u))
    case("gap BEFORE delivery not counted (mutation: ignoring revision order would count it)", c3)

    def c4():
        td, log = fresh()
        record_use(log, sample["work_id"], "other-brief", gap_ref=ref_ok)
        return (uses(log)[0]["followup_lookups"] == 0, "other brief_session_id excluded")
    case("gap of another Brief not counted", c4)

    def c5():
        td, log = fresh()
        record_use(log, sample["work_id"], sample["brief_session_id"], cited=["S_NOT_SENT", sent[0]])
        u = uses(log)[0]
        return (u["slots_cited"] == 1 and u["cited_outside_sent"] == ["S_NOT_SENT"], str(u))
    case("cited slot not sent is flagged, not counted", c5)

    def c6():
        td, log = fresh()
        record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref=ref_ok)
        record_use(log, sample["work_id"], sample["brief_session_id"], cited=sent[:1])
        evs = el.EventLog(log).events_for("SEGMENT", sample["work_id"])
        a, b = compute_use(evs), compute_use(list(reversed(evs)))
        return (a == b and json.dumps(a, sort_keys=True) == json.dumps(b, sort_keys=True), "same events, any order -> same result")
    case("deterministic recompute", c6)

    def c7():
        td, log = fresh()
        record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref=ref_ok)
        u = uses(log)
        new, added, rej = patch_slots(cfg, u)
        again, added2, _ = patch_slots(new, u)
        sid = slot_id_for(ref_ok)
        ok = (not rej and added == [f"{route}:{sid}"] and sid in new["routes"][route]["required_slots"]
              and not lib.validate_slots(new) and not added2 and again == new and sid not in cfg["slots"])
        return ok, f"added={added} second_pass={added2}"
    case("miss patched into slots; idempotent; original untouched", c7)

    def c8():
        td, log = fresh()
        for bad in ("P1-Central-Control/scripts/nope.py::x", "P1-Central-Control/scripts/librarian.py::no_such_symbol", "no-separator"):
            record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref=bad)
        new, added, rej = patch_slots(cfg, uses(log))
        return (not added and len(rej) == 3 and new == cfg, f"rejected={rej}")
    case("invalid refs rejected, slots unchanged", c8)

    def c9():
        td, log = fresh()
        record_use(log, sample["work_id"], sample["brief_session_id"], gap_ref=ref_ok)
        new, _, _ = patch_slots(cfg, uses(log))
        p = td / "brief_slots.json"
        write_slots(cfg, p)
        before = p.read_bytes()

        def boom(a, b):
            raise OSError("disk")
        try:
            write_slots(new, p, replace=boom)
            return False, "no error raised"
        except OSError:
            pass
        return (p.read_bytes() == before and not p.with_suffix(".tmp").exists(), "old file kept, no temp left")
    case("atomic write: failure keeps old file", c9)

    def c10():
        td, log = fresh()
        b2 = copy.deepcopy(sample); b2["brief_session_id"] = "brief-second-task"
        lib.deliver(b2, log)
        record_use(log, sample["work_id"], b2["brief_session_id"], gap_ref=ref_ok)
        u = {x["brief_session_id"]: x for x in uses(log)}
        return (u[sample["brief_session_id"]]["followup_lookups"] == 0 and u["brief-second-task"]["followup_lookups"] == 1, "per-brief split")
    case("two Briefs on one work counted separately", c10)
    return res


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--simulate", action="store_true")
    ap.add_argument("--report", action="store_true")
    ap.add_argument("--apply-gaps", action="store_true", help="append missed refs to brief_slots.json (with --report)")
    ap.add_argument("--event-log")
    ap.add_argument("--work-id")
    a = ap.parse_args()
    if a.simulate:
        rs = simulate()
        for n, ok, note in rs:
            print(("PASS " if ok else "FAIL ") + n + ("" if ok else f" -- {note}"))
        bad = [n for n, ok, _ in rs if not ok]
        print(f"brief_use --simulate: {len(rs) - len(bad)}/{len(rs)} SIMULATED_PASS")
        return 1 if bad else 0
    if a.report:
        if not (a.event_log and a.work_id):
            print("--report needs --event-log and --work-id")
            return 2
        u = compute_use(el.EventLog(Path(a.event_log)).events_for("SEGMENT", a.work_id))
        print(json.dumps(u, ensure_ascii=False, indent=2))
        if a.apply_gaps:
            new, added, rej = patch_slots(lib.load_slots(), u)
            if added:
                write_slots(new)
            print(json.dumps({"added": added, "rejected": rej}, ensure_ascii=False))
        return 0
    ap.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
