#!/usr/bin/env python3
"""Normalize external architecture-analysis SARIF into P1 evidence projection.

This adapter does not decide architecture truth. It preserves source identity,
claim identity and locations so downstream P1 gates can consume evidence without
creating a second Current or dependency graph.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _id(prefix: str, value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return f"{prefix}:{hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16]}"


def _level(result: dict[str, Any]) -> str:
    level = str(result.get("level", "warning")).lower()
    return level if level in {"error", "warning", "note", "none"} else "warning"


def _locations(result: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for item in result.get("locations", []):
        physical = item.get("physicalLocation", {})
        artifact = physical.get("artifactLocation", {})
        region = physical.get("region", {})
        rows.append({
            "uri": artifact.get("uri"),
            "start_line": region.get("startLine"),
            "start_column": region.get("startColumn"),
            "end_line": region.get("endLine"),
            "end_column": region.get("endColumn"),
        })
    return rows


def normalize(
    sarif: dict[str, Any],
    *,
    source_type: str,
    source_uri: str,
    source_revision: str | None,
    captured_at: str | None = None,
) -> dict[str, Any]:
    captured = captured_at or datetime.now(timezone.utc).isoformat()
    runs = sarif.get("runs", [])
    findings: list[dict[str, Any]] = []

    for run_index, run in enumerate(runs):
        tool = run.get("tool", {}).get("driver", {})
        tool_name = str(tool.get("name", source_type))
        tool_version = tool.get("version")
        rules = {
            str(rule.get("id")): rule
            for rule in tool.get("rules", [])
            if rule.get("id") is not None
        }

        for result_index, result in enumerate(run.get("results", [])):
            rule_id = str(result.get("ruleId", "UNKNOWN"))
            rule = rules.get(rule_id, {})
            locations = _locations(result)
            claim_material = {
                "source_type": source_type,
                "source_uri": source_uri,
                "source_revision": source_revision,
                "run_index": run_index,
                "result_index": result_index,
                "rule_id": rule_id,
                "locations": locations,
                "message": result.get("message", {}).get("text", ""),
            }
            finding_id = _id("EXTFINDING", claim_material)
            findings.append({
                "finding_id": finding_id,
                "claim_ref": f"CLAIM:{hashlib.sha256(finding_id.encode('utf-8')).hexdigest()[:16]}",
                "source_ref": _id("SOURCE", {
                    "source_type": source_type,
                    "source_uri": source_uri,
                    "source_revision": source_revision,
                }),
                "tool": {
                    "name": tool_name,
                    "version": tool_version,
                    "rule_id": rule_id,
                    "rule_name": rule.get("name"),
                    "help_uri": rule.get("helpUri"),
                },
                "level": _level(result),
                "message": result.get("message", {}).get("text", ""),
                "locations": locations,
                "captured_at": captured,
                "provenance": {
                    "activity_ref": _id("ACTIVITY", {
                        "source_uri": source_uri,
                        "run_index": run_index,
                    }),
                    "agent_ref": f"EXTERNAL_ANALYZER:{source_type}",
                    "relation": "WAS_GENERATED_BY",
                },
            })

    result = {
        "schema_version": "1.0",
        "adapter_id": _id("EXTADAPTER", {
            "source_type": source_type,
            "source_uri": source_uri,
            "source_revision": source_revision,
            "captured_at": captured,
        }),
        "source": {
            "source_type": source_type,
            "source_uri": source_uri,
            "source_revision": source_revision,
            "captured_at": captured,
        },
        "findings": findings,
        "summary": {
            "finding_count": len(findings),
            "error_count": sum(x["level"] == "error" for x in findings),
            "warning_count": sum(x["level"] == "warning" for x in findings),
            "note_count": sum(x["level"] == "note" for x in findings),
        },
        "truth_boundary": "EXTERNAL_EVIDENCE_ONLY",
        "promotion_policy": "EXTERNAL_FINDINGS_MUST_NOT_BECOME_CURRENT_WITHOUT_P1_GATE_AND_PROVENANCE",
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True)
    parser.add_argument("--source-type", required=True, choices=["CODEQL", "SEMGREP", "OTHER"])
    parser.add_argument("--source-uri", required=True)
    parser.add_argument("--source-revision")
    parser.add_argument("--captured-at")
    parser.add_argument("--output")
    args = parser.parse_args()

    sarif = json.loads(Path(args.input).read_text(encoding="utf-8"))
    result = normalize(
        sarif,
        source_type=args.source_type,
        source_uri=args.source_uri,
        source_revision=args.source_revision,
        captured_at=args.captured_at,
    )
    text = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
    print(text, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
