#!/usr/bin/env python3
"""Minimal failure-escalation policy for the canonical debug/recovery path.

The policy is stateless: the failure level is derived from observed workflow
runs and the current diagnostic. No second state store is introduced.
"""

from __future__ import annotations

from typing import Any

FAILURE_CLASSES = {
    "WORKFLOW_EXECUTION_FAILURE",
    "RUNNER_STARTUP_FAILURE",
    "NOT_DISPATCHED",
    "INCOMPLETE",
}


def failure_signature(diagnostic: dict[str, Any]) -> tuple[str, str, str, str]:
    return (
        str(diagnostic.get("head_sha") or ""),
        str(diagnostic.get("workflow") or "M32-CLOSE acceptance"),
        str(diagnostic.get("classification") or "UNKNOWN"),
        str(diagnostic.get("reason_code") or diagnostic.get("run_conclusion") or ""),
    )


def _run_failure_signature(run: dict[str, Any]) -> tuple[str, str, str]:
    return (
        str(run.get("head_sha") or ""),
        str(run.get("name") or "M32-CLOSE acceptance"),
        str(run.get("conclusion") or run.get("status") or ""),
    )


def consecutive_failures(
    current: dict[str, Any],
    runs: list[dict[str, Any]],
    diagnostic: dict[str, Any],
) -> int:
    classification = diagnostic.get("classification")
    if classification not in FAILURE_CLASSES:
        return 0

    target_head, target_workflow, _, _ = failure_signature(diagnostic)
    count = 0

    ordered = sorted(
        runs,
        key=lambda item: str(item.get("created_at") or item.get("updated_at") or ""),
        reverse=True,
    )
    for run in ordered:
        run_head, run_workflow, conclusion = _run_failure_signature(run)
        if target_head and run_head and run_head != target_head:
            continue
        if run_workflow != target_workflow:
            continue
        if conclusion in {"failure", "cancelled", "timed_out"}:
            count += 1
        elif conclusion in {"success", "neutral", "skipped"} or run.get("status") == "completed":
            break

    if count == 0:
        previous = current.get("latest_runtime_observation", {})
        if (
            previous.get("classification") == classification
            and previous.get("head_sha") == target_head
            and previous.get("program_regression_status") == "INCOMPLETE"
        ):
            return 1
        return 1

    return count


def decide(
    *,
    current: dict[str, Any],
    runs: list[dict[str, Any]],
    diagnostic: dict[str, Any],
) -> dict[str, Any]:
    level = consecutive_failures(current, runs, diagnostic)
    if level <= 0:
        return {
            "level": 0,
            "mode": "NORMAL",
            "next_action": "NORMAL_FLOW",
            "auto_recovery_allowed": True,
            "reason": "NO_REPEATED_FAILURE",
        }
    if level == 1:
        return {
            "level": 1,
            "mode": "MINIMAL_REPAIR",
            "next_action": "USE_EXISTING_RECOVERY_PATH",
            "auto_recovery_allowed": True,
            "reason": "FIRST_FAILURE",
        }
    if level == 2:
        return {
            "level": 2,
            "mode": "ONE_STEP_ESCALATION",
            "next_action": "ALLOW_ONE_MINIMAL_ADDITIONAL_CAPABILITY",
            "auto_recovery_allowed": True,
            "reason": "SECOND_CONSECUTIVE_FAILURE",
        }
    return {
        "level": level,
        "mode": "DEEP_RESEARCH",
        "next_action": "REQUIRE_EXTERNAL_COMPARISON_BEFORE_FURTHER_REPAIR",
        "auto_recovery_allowed": False,
        "reason": "THIRD_OR_LATER_CONSECUTIVE_FAILURE",
    }


RETRYABLE_CODES = {"TIMEOUT": True, "LAUNCH_FAILED": False, "SIGNALED": False, "UNEXPECTED": False}  # S2 (HYPOTHESIS defaults)
RETRY_MAX = 1  # OD3: a retryable step is retried automatically at most once after its first failure


def attempts_to_runs(attempts: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Segment attempt events {step, outcome, head_sha, t} -> the run shape decide() accepts."""
    return [
        {"head_sha": str(a.get("head_sha") or ""), "name": str(a.get("step") or ""),
         "conclusion": "success" if a.get("outcome") == "success" else "failure",
         "created_at": str(a.get("t") if a.get("t") is not None else i).zfill(8)}
        for i, a in enumerate(attempts) if a.get("outcome") != "incomplete"  # incomplete is not a test failure (S2)
    ]


def retry_decision(attempts: list[dict[str, Any]], step: str, *, retryable: bool = True) -> dict[str, Any]:
    """OD3 adapter (R5-S1-M5): RETRY once, then STOP_WAITING with the reason; never loops; not retryable -> STOP_FAILED.
    Level logic is decide(); nothing is copied here."""
    own = [a for a in attempts if a.get("step") == step]
    if own and own[-1].get("outcome") == "incomplete":  # S2: infrastructure incompleteness is counted apart from failures
        n = 0
        for a in reversed(own):
            if a.get("outcome") != "incomplete":
                break
            n += 1
        action, reason = (("STOP_FAILED", "NOT_RETRYABLE") if not retryable else
                          ("RETRY", "INCOMPLETE_AUTO_RETRY") if n <= RETRY_MAX else ("STOP_WAITING", "INCOMPLETE_LIMIT_REACHED"))
        return {"action": action, "level": n, "reason": reason, "escalation": None}
    runs = [r for r in attempts_to_runs(attempts) if r["name"] == step]
    if not runs or runs[-1]["conclusion"] == "success":
        return {"action": "PROCEED", "level": 0, "reason": "NO_FAILURE", "escalation": None}
    diag = {"head_sha": runs[-1]["head_sha"], "workflow": step,
            "classification": "WORKFLOW_EXECUTION_FAILURE", "reason_code": "STEP_FAILED"}
    esc = decide(current={}, runs=runs, diagnostic=diag)
    if not retryable:
        action, reason = "STOP_FAILED", "NOT_RETRYABLE"
    elif esc["level"] <= RETRY_MAX:
        action, reason = "RETRY", "FIRST_FAILURE_AUTO_RETRY"
    else:
        action, reason = "STOP_WAITING", "RETRY_LIMIT_REACHED"
    return {"action": action, "level": esc["level"], "reason": reason, "escalation": esc}
