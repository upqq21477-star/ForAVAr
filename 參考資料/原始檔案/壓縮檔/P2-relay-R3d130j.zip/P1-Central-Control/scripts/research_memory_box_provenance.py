#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PASS = "PASS"
BLOCK = "BLOCK"

BASELINE_COLLECTIONS = ("facts", "constraints", "capabilities")


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def _source_refs(item: dict[str, Any]) -> list[str]:
    refs = item.get("source_refs")
    if not isinstance(refs, list) or not refs or any(not isinstance(ref, str) or not ref for ref in refs):
        return []
    return list(dict.fromkeys(refs))


def _claim_id(item: dict[str, Any]) -> str | None:
    value = item.get("claim_id")
    return value if isinstance(value, str) and value else None


def validate(box: dict[str, Any]) -> dict[str, Any]:
    errors: list[dict[str, Any]] = []
    provenance: list[dict[str, Any]] = []
    seen_claim_ids: set[str] = set()
    known_source_refs: set[str] = set()
    known_evidence_ids: set[str] = set()

    def add_claim(
        *,
        claim_id: str | None,
        claim_kind: str,
        source_refs: list[str],
        path: str,
    ) -> None:
        if not claim_id:
            errors.append({
                "code": "CLAIM_ID_MISSING",
                "path": path,
            })
            return
        if claim_id in seen_claim_ids:
            errors.append({
                "code": "CLAIM_ID_DUPLICATE",
                "claim_id": claim_id,
                "path": path,
            })
            return
        seen_claim_ids.add(claim_id)

        if not source_refs:
            errors.append({
                "code": "SOURCE_REFS_MISSING",
                "claim_id": claim_id,
                "path": path,
            })
            return

        provenance.append({
            "provenance_id": f"PROV:{uuid.uuid4().hex[:16]}",
            "claim_id": claim_id,
            "claim_kind": claim_kind,
            "source_refs": source_refs,
            "relation": "DIRECT",
        })

    baseline = box.get("objective_baseline", {})
    for collection_name in BASELINE_COLLECTIONS:
        collection = baseline.get(collection_name, [])
        if not isinstance(collection, list):
            errors.append({
                "code": "COLLECTION_INVALID",
                "path": f"objective_baseline.{collection_name}",
            })
            continue
        for index, item in enumerate(collection):
            if not isinstance(item, dict):
                errors.append({
                    "code": "CLAIM_INVALID",
                    "path": f"objective_baseline.{collection_name}[{index}]",
                })
                continue
            refs = _source_refs(item)
            known_source_refs.update(refs)
            add_claim(
                claim_id=_claim_id(item),
                claim_kind=f"OBJECTIVE_{collection_name.upper()}",
                source_refs=refs,
                path=f"objective_baseline.{collection_name}[{index}]",
            )

    external = box.get("external_evidence", [])
    if not isinstance(external, list):
        errors.append({"code": "EXTERNAL_EVIDENCE_INVALID", "path": "external_evidence"})
        external = []
    for index, item in enumerate(external):
        if not isinstance(item, dict):
            errors.append({
                "code": "EVIDENCE_INVALID",
                "path": f"external_evidence[{index}]",
            })
            continue
        evidence_id = item.get("evidence_id")
        refs = _source_refs(item)
        known_source_refs.update(refs)
        if not isinstance(evidence_id, str) or not evidence_id:
            errors.append({
                "code": "EVIDENCE_ID_MISSING",
                "path": f"external_evidence[{index}]",
            })
        else:
            known_evidence_ids.add(evidence_id)
            add_claim(
                claim_id=evidence_id,
                claim_kind="EXTERNAL_EVIDENCE",
                source_refs=refs,
                path=f"external_evidence[{index}]",
            )

    alternatives = box.get("alternatives", [])
    alternative_ids: set[str] = set()
    if not isinstance(alternatives, list):
        errors.append({"code": "ALTERNATIVES_INVALID", "path": "alternatives"})
        alternatives = []
    for index, item in enumerate(alternatives):
        if not isinstance(item, dict):
            errors.append({
                "code": "ALTERNATIVE_INVALID",
                "path": f"alternatives[{index}]",
            })
            continue
        option_id = item.get("option_id")
        if isinstance(option_id, str) and option_id:
            alternative_ids.add(option_id)
        else:
            errors.append({
                "code": "OPTION_ID_MISSING",
                "path": f"alternatives[{index}]",
            })
        refs = _source_refs(item)
        known_source_refs.update(refs)
        add_claim(
            claim_id=option_id if isinstance(option_id, str) else None,
            claim_kind="ALTERNATIVE",
            source_refs=refs,
            path=f"alternatives[{index}]",
        )

    decision = box.get("decision")
    if decision is not None:
        if not isinstance(decision, dict):
            errors.append({"code": "DECISION_INVALID", "path": "decision"})
        else:
            decision_id = decision.get("decision_id")
            evidence_refs = decision.get("evidence_refs")
            alternative_refs = decision.get("alternative_refs")
            if not isinstance(evidence_refs, list) or not evidence_refs:
                errors.append({"code": "DECISION_EVIDENCE_REFS_MISSING", "path": "decision.evidence_refs"})
                evidence_refs = []
            if not isinstance(alternative_refs, list) or not alternative_refs:
                errors.append({"code": "DECISION_ALTERNATIVE_REFS_MISSING", "path": "decision.alternative_refs"})
                alternative_refs = []

            unknown_alternatives = [ref for ref in alternative_refs if ref not in alternative_ids]
            if unknown_alternatives:
                errors.append({
                    "code": "DECISION_ALTERNATIVE_REF_UNKNOWN",
                    "refs": unknown_alternatives,
                })

            unknown_evidence = [
                ref for ref in evidence_refs
                if ref not in known_source_refs and ref not in known_evidence_ids
            ]
            if unknown_evidence:
                errors.append({
                    "code": "DECISION_EVIDENCE_REF_UNKNOWN",
                    "refs": unknown_evidence,
                })

            if not isinstance(decision_id, str) or not decision_id:
                errors.append({"code": "DECISION_ID_MISSING", "path": "decision.decision_id"})
            else:
                add_claim(
                    claim_id=decision_id,
                    claim_kind="DECISION",
                    source_refs=[ref for ref in evidence_refs if isinstance(ref, str) and ref],
                    path="decision",
                )

    status = PASS if not errors else BLOCK
    return {
        "provenance_report_id": f"PROVENANCE:{uuid.uuid4().hex[:16]}",
        "generated_at": now_iso(),
        "status": status,
        "box_id": box.get("box_id"),
        "claim_count": len(provenance),
        "provenance": provenance,
        "errors": errors,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate and materialize per-claim provenance for a Research Memory Box")
    parser.add_argument("--box", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    result = validate(load_json(Path(args.box)))
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0 if result["status"] == PASS else 2


if __name__ == "__main__":
    raise SystemExit(main())
