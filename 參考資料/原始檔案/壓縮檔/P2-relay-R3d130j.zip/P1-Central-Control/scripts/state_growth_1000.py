#!/usr/bin/env python3
from __future__ import annotations

import json
import math

ITERATIONS = 1000
BASE_SOURCE_FILES = 200
RECENT_RESULTS_LIMIT = 16
HOT_EVENTS_LIMIT = 128
ACTIVE_SEGMENT_LIMIT = 32
SNAPSHOT_INTERVAL = 300


def current_state_counts(n: int) -> dict[str, int]:
    return {
        "completed_segments": n,
        "result_refs": n,
        "capability_runs": n * 2,
        "evidence_refs": n * 3,
        "provenance_refs": n * 2,
        "handoff_history": n * 2,
        "validation_records": n,
    }


def compact_projection_counts(n: int) -> dict[str, int]:
    events = n * 3
    return {
        "active_segments": 0,
        "recent_result_refs": min(n, RECENT_RESULTS_LIMIT),
        "recent_event_refs": min(events, HOT_EVENTS_LIMIT),
        "canonical_artifacts": 1,
        "snapshots": math.ceil(events / SNAPSHOT_INTERVAL),
        "persistent_raw_results_in_projection": 0,
    }


def bad_repository_growth(n: int) -> int:
    files = BASE_SOURCE_FILES
    for _ in range(n):
        files += 4
    return files


def clean_repository_growth(n: int) -> int:
    return BASE_SOURCE_FILES


def run() -> dict:
    current = current_state_counts(ITERATIONS)
    compact = compact_projection_counts(ITERATIONS)
    current_items = sum(current.values())
    compact_items = sum(compact.values())

    current_repo = bad_repository_growth(ITERATIONS)
    clean_repo = clean_repository_growth(ITERATIONS)

    report = {
        "iterations": ITERATIONS,
        "current_model": {
            "state_retained_items": current_items,
            "detail": current,
            "growth": "O(n)"
        },
        "v2_1_model": {
            "hot_projection_items": compact_items,
            "detail": compact,
            "growth": "O(1) hot state + external history"
        },
        "repository": {
            "bad_generation_model_files": current_repo,
            "v2_1_active_source_files": clean_repo,
            "active_tree_growth": clean_repo - BASE_SOURCE_FILES,
            "generated_runtime_data_in_source_tree": 0
        },
        "checks": {
            "hot_state_bounded": compact["recent_event_refs"] <= HOT_EVENTS_LIMIT,
            "recent_results_bounded": compact["recent_result_refs"] <= RECENT_RESULTS_LIMIT,
            "active_segments_bounded": compact["active_segments"] <= ACTIVE_SEGMENT_LIMIT,
            "source_tree_constant": clean_repo == BASE_SOURCE_FILES,
            "raw_result_not_in_projection": compact["persistent_raw_results_in_projection"] == 0
        }
    }
    return report


if __name__ == "__main__":
    report = run()
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if all(report["checks"].values()) else 3)
