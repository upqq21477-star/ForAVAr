"""session_driver -- production host of Run.resume / Run.close (S3a, CONVERSATION-RECORD).
Start = Run(journal_path); interrupted = the journal stays open and the next drive() resumes it (params come from the
journal's init record); error in work = closed as INCOMPLETE; close always records the dialogue and verifies it.
  python3 session_driver.py recover --workdir W --journal J --log L --cid C   (resume an interrupted run, then close it)
Exit: 0 closed / 1 not resumable or nothing to recover / 2 no journal."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any, Callable

sys.path.insert(0, str(Path(__file__).resolve().parent))
import gap_ledger as gl  # noqa: E402
import iterate_control as ic  # noqa: E402
import p2_run  # noqa: E402
import run_journal as rj  # noqa: E402


def _init(journal_path: str | Path) -> dict[str, Any] | None:
    p = Path(journal_path)
    if not p.exists() or p.stat().st_size == 0:
        return None
    try:
        j = rj.Journal(p)
    except rj.JournalError:
        return {}  # locked or corrupt: Run.resume reports the reason
    try:
        return dict(j.records[0]["payload"]) if j.records else {}
    finally:
        j.close()


def drive(workdir: str | Path, journal_path: str | Path, log_path: str | Path, cid: str, work: Callable[[Any], Any], *,
          write_scope: list[str], protected: list[str] | None = None, budget: int = 12, goal_confirmed: bool = False,
          run_id: str = "RUN-1", brief: dict | None = None, gap_path: str | Path | None = None) -> dict[str, Any]:
    init = _init(journal_path)
    if init is None:
        run = p2_run.Run(workdir, write_scope=write_scope, protected=protected, budget=budget, goal_confirmed=goal_confirmed,
                         run_id=run_id, brief=brief, journal_path=journal_path)
    else:
        r = p2_run.Run.resume(workdir, journal_path, write_scope=init.get("write_scope", write_scope),
                              protected=init.get("protected", protected or []), budget=init.get("budget0", budget),
                              goal_confirmed=init.get("goal_confirmed", goal_confirmed), run_id=init.get("run_id", run_id),
                              brief=brief, log_path=log_path, conversation_id=cid)
        if r.status != "RESUMED":
            return {"status": r.status, "resumed": False, "reason": r.reason}
        run = r.run
    out: dict[str, Any] = {"resumed": init is not None}
    try:
        work(run)
    except Exception as e:  # error mid-run: still close (INCOMPLETE), never leave the lock or an open journal
        out["error"] = type(e).__name__
    except BaseException:  # interrupted: keep the journal open so the next drive() resumes it
        run.release()
        raise
    out["close"] = p2_run.Run.close(run, Path(log_path), cid, gap_path=gap_path)
    out["status"] = "ERROR" if "error" in out else "CLOSED"
    return out


def iterate(workdir: str | Path, journal_dir: str | Path, log_path: str | Path, cid: str, work: Callable[[Any], Any], *,
            limit: int = ic.DEFAULT_LIMIT, write_scope: list[str], protected: list[str] | None = None, budget: int = 12,
            goal_confirmed: bool = False, run_id: str = "RUN-1", brief: dict | None = None) -> dict[str, Any]:
    """Round loop after Run.close (CAP-ITERATE): one journal per round; the gap checkpoint carries the round count, so an
    interrupted round is resumed (same number) and a restart never resets it.  Stops on DONE / LIMIT / STALLED."""
    jd = Path(journal_dir)
    gp, last = jd / "gaps.json", None
    while True:
        try:
            ck = gl.load(gp)
        except ValueError as e:
            return {"status": "INCOMPLETE", "reason": str(e), "round": 0, "unresolved": [], "last": last}
        d = ic.decide(ck, limit)
        if ck["round"] and d["decision"] != "CONTINUE":
            return {"status": d["decision"], "round": ck["round"], "unresolved": d["unresolved"], "last": last}
        last = drive(workdir, jd / f"round-{ck['round'] + 1}.jsonl", log_path, cid, work, write_scope=write_scope,
                     protected=protected, budget=budget, goal_confirmed=goal_confirmed, run_id=run_id, brief=brief, gap_path=gp)
        if last["status"] not in ("CLOSED", "ERROR", "NOTHING_TO_RESUME"):  # the round never ran: not counted, rerun retries it
            return {"status": "INCOMPLETE", "reason": last.get("reason", last["status"]), "round": ck["round"],
                    "unresolved": d["unresolved"], "last": last}
        try:
            ck = gl.load(gp)
            gl.save(gp, ic.finish_round(ck, d["unresolved"]))  # d = the gap set at round start
        except (ValueError, OSError):
            return {"status": "INCOMPLETE", "reason": "LEDGER_WRITE_FAILED", "round": ck["round"], "unresolved": [], "last": last}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="recover an interrupted P2 run (resume, then close)")
    ap.add_argument("cmd", choices=["recover"])
    for k in ("workdir", "journal", "log", "cid"):
        ap.add_argument("--" + k, required=True)
    a = ap.parse_args(argv)
    if not Path(a.journal).exists():
        print("NO_JOURNAL", file=sys.stderr)
        return 2
    out = drive(a.workdir, a.journal, a.log, a.cid, lambda r: None, write_scope=[])
    c = out.get("close", {})
    print(json.dumps({"status": out["status"], "reason": out.get("reason", ""), "outcome_class": c.get("outcome_class"),
                      "dialogue_status": c.get("dialogue_status")}, ensure_ascii=False))
    return 0 if out["status"] == "CLOSED" else 1


if __name__ == "__main__":
    raise SystemExit(main())
