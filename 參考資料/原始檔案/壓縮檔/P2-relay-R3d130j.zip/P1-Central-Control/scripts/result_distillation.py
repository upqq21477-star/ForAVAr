#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
INPUT_SCHEMA = SCHEMA_DIR / "distillation_input.schema.json"
RECORD_SCHEMA = SCHEMA_DIR / "distillation_record.schema.json"


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def _registry() -> Registry:
    registry = Registry()
    for path in (
        SCHEMA_DIR / "canonical_identity.schema.json",
        SCHEMA_DIR / "canonical_common.schema.json",
        INPUT_SCHEMA,
        RECORD_SCHEMA,
    ):
        schema = json.loads(path.read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"],
            Resource.from_contents(schema),
        )
    return registry


def _validate(path: Path, value: dict[str, Any]) -> None:
    schema = json.loads(path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(
        schema,
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(validator.iter_errors(value), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            f"{path.name} 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def validate_distillation_input(value: dict[str, Any]) -> None:
    _validate(INPUT_SCHEMA, value)


def validate_distillation_record(value: dict[str, Any]) -> None:
    _validate(RECORD_SCHEMA, value)


def _refs(values: list[str]) -> list[str]:
    return sorted(set(values))


def _base_input() -> dict[str, Any]:
    return {
        "confirmed_refs": [],
        "inference_refs": [],
        "conflict_refs": [],
        "state_change_candidate_refs": [],
        "next_action_candidate_refs": [],
    }


def distill_result(
    result_packet: dict[str, Any],
    *,
    semantic_input: dict[str, Any] | None = None,
) -> dict[str, Any]:
    source = _base_input()
    if semantic_input is not None:
        validate_distillation_input(semantic_input)
        source.update(deepcopy(semantic_input))

    # Only a validated successful output becomes a confirmed fact.
    # Other semantic categories must be supplied explicitly by a structured
    # producer; the distiller never invents inference/conflict/state change.
    confirmed = list(source["confirmed_refs"])
    if (
        result_packet["status"] == "VALID"
        and result_packet["decision_code"] == "WORK_COMPLETE"
    ):
        confirmed.extend(result_packet["output_refs"])

    record = {
        "distillation_id": f"dist-{result_packet['result_id']}",
        "workflow_id": result_packet["workflow_id"],
        "segment_id": result_packet["segment_id"],
        "attempt_id": result_packet["attempt_id"],
        "result_id": result_packet["result_id"],
        "execution_record_ref": result_packet["execution_record_ref"],
        "result_status": result_packet["status"],
        "decision_code": result_packet["decision_code"],
        "confirmed_refs": _refs(confirmed),
        "inference_refs": _refs(source["inference_refs"]),
        "unknown": list(result_packet.get("unresolved", [])),
        "conflict_refs": _refs(source["conflict_refs"]),
        "evidence_refs": _refs(result_packet.get("evidence_refs", [])),
        "state_change_candidate_refs": _refs(
            source["state_change_candidate_refs"]
        ),
        "next_action_candidate_refs": _refs(
            source["next_action_candidate_refs"]
        ),
        "object_id": f"DISTILLATION:dist-{result_packet['result_id']}",
        "kind": "DISTILLATION_RECORD",
        "schema_version": "1.0",
        "content_hash": "",
    }
    record["content_hash"] = content_hash(record)
    validate_distillation_record(record)
    return record
