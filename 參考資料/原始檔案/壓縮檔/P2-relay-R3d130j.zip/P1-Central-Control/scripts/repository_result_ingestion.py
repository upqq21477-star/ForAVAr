#!/usr/bin/env python3
"""Ingest a persisted canonical ResultPacket back into the existing Central path.

This adapter owns no state, retry, result taxonomy, or truth. It only:
1. validates a persisted ResultPacket and its identity,
2. loads existing canonical runtime inputs,
3. invokes central_controller.receive_result_and_schedule(),
4. persists the returned canonical projections for the caller.

The Central controller remains the sole execution/result routing owner.
"""

from __future__ import annotations

import argparse
import json
import re
from copy import deepcopy
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_object(path: Path) -> dict[str, Any]:
    value = load_json(path)
    if not isinstance(value, dict):
        raise ValueError(f"OBJECT_REQUIRED:{path}")
    return value


def load_record_list(path: Path | None) -> list[dict[str, Any]]:
    if path is None or not path.exists():
        return []
    value = load_json(path)
    if isinstance(value, list):
        return value
    if isinstance(value, dict) and isinstance(value.get("records"), list):
        return list(value["records"])
    if isinstance(value, dict) and isinstance(value.get("envelopes"), list):
        return list(value["envelopes"])
    raise ValueError(f"RECORD_LIST_REQUIRED:{path}")


def save_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def _safe_ref(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9._:-]+", "_", value).strip("_")
    if not token:
        raise ValueError("EMPTY_REFERENCE")
    return token


def _execution_envelope_map(
    envelopes: list[dict[str, Any]],
) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for envelope in envelopes:
        execution = envelope.get("execution_record") or {}
        ref = execution.get("execution_record_ref")
        if ref:
            result[ref] = envelope
    return result


def ingest(
    *,
    result_packet: dict[str, Any],
    task_packet: dict[str, Any],
    current_state: dict[str, Any],
    execution_envelopes: list[dict[str, Any]],
    event_log_path: Path,
    segment_store: dict[str, dict[str, Any]] | None = None,
    distillation_envelopes: list[dict[str, Any]] | None = None,
    evidence_records: list[dict[str, Any]] | None = None,
    provenance_records: list[dict[str, Any]] | None = None,
    continuation_box: dict[str, Any] | None = None,
    current_authority: dict[str, Any] | None = None,
) -> dict[str, Any]:
    import sys

    sys.path.insert(0, str(SCRIPTS))
    import central_controller
    from event_log import EventLog
    from packet_layer import validate_result_packet, validate_task_packet
    from simulated_amnesia_resume import reconstruct_task_context

    validate_task_packet(task_packet)
    validate_result_packet(result_packet)

    identity_pairs = (
        "workflow_id",
        "segment_id",
        "attempt_id",
        "skill_id",
        "skill_version",
    )
    for field in identity_pairs:
        if result_packet[field] != task_packet[field]:
            raise ValueError(f"RESULT_TASK_IDENTITY_MISMATCH:{field}")
    if result_packet["execution_record_ref"] != task_packet["execution_record_ref"]:
        raise ValueError("RESULT_TASK_EXECUTION_REF_MISMATCH")

    expected_box_ref = task_packet.get("continuation_box_ref")
    if expected_box_ref:
        if continuation_box is None:
            raise ValueError("CONTINUATION_BOX_REQUIRED")
        if current_authority is None:
            raise ValueError("CURRENT_AUTHORITY_REQUIRED_FOR_CONTINUATION_BOX")
        if continuation_box.get("box_id") != expected_box_ref:
            raise ValueError("CONTINUATION_BOX_REF_MISMATCH")
        reconstruct_task_context(
            current=current_authority,
            task_packet=task_packet,
            continuation_box=continuation_box,
        )

    execution_ref = task_packet["execution_record_ref"]
    execution_map = _execution_envelope_map(execution_envelopes)
    envelope = execution_map.get(execution_ref)
    if envelope is None:
        raise ValueError("EXECUTION_RECORD_NOT_FOUND")

    execution = envelope.get("execution_record")
    attempt = envelope.get("attempt")
    envelope_task = envelope.get("task_packet")
    if not isinstance(execution, dict) or not isinstance(attempt, dict):
        raise ValueError("EXECUTION_ENVELOPE_INVALID")
    if not isinstance(envelope_task, dict):
        envelope["task_packet"] = deepcopy(task_packet)
    elif envelope_task.get("content_hash") != task_packet.get("content_hash"):
        raise ValueError("EXECUTION_ENVELOPE_TASK_HASH_MISMATCH")

    distillation_store = {
        item["distillation_record"]["object_id"]: item["distillation_record"]
        for item in (distillation_envelopes or [])
        if isinstance(item, dict) and isinstance(item.get("distillation_record"), dict)
    }
    # Existing minimal_closed_loop_runner writes a JSON array of DistillationRecord
    # envelopes. Accept plain records too, without creating a new store.
    for item in (distillation_envelopes or []):
        if isinstance(item, dict) and item.get("object_id"):
            distillation_store[item["object_id"]] = item

    execution_store = {execution_ref: envelope}
    result = deepcopy(result_packet)

    state, next_task_packets = central_controller.receive_result_and_schedule(
        deepcopy(current_state),
        result,
        event_log=EventLog(event_log_path),
        execution_store=execution_store,
        distillation_store=distillation_store,
        segment_store=segment_store,
        evidence_records=evidence_records,
        provenance_records=provenance_records,
    )

    updated_envelopes = list(execution_store.values())
    updated_distillation = list(distillation_store.values())

    return {
        "status": "PASS",
        "result_id": result_packet["result_id"],
        "execution_record_ref": execution_ref,
        "central_state": state,
        "next_task_packets": next_task_packets,
        "execution_envelopes": updated_envelopes,
        "distillation_records": updated_distillation,
        "ingestion": {
            "boundary": "REPOSITORY_RESULT -> CENTRAL_RECEIVE_RESULT_AND_SCHEDULE",
            "result_owner": "EXISTING_RESULT_PACKET",
            "state_owner": "EXISTING_CENTRAL_CONTROLLER",
            "retry_owner": "EXISTING_PARALLEL_SCHEDULER",
            "truth_owner": "EXISTING_EXECUTION_TRUTH",
        },
    }


ISSUE_STATUSES = {"FAIL", "BLOCK", "INCOMPLETE", "UNRESOLVED", "BLOCKED"}


def ingest_role_result(*, role_result: dict[str, Any], task_packet: dict[str, Any],
                       record_root: Path | None = None, **kwargs: Any) -> dict[str, Any]:
    """角色結果的正式入口：role_result →（映射表）→ ResultPacket → ingest()。

    Verifier 判決另存為 VerifierVerdict（outcome["verifier_verdicts"]，由呼叫端持久化）。
    """
    import sys

    sys.path.insert(0, str(SCRIPTS))
    from role_result import to_result_packet

    packet, verdict = to_result_packet(task_packet, role_result)
    outcome = ingest(result_packet=packet, task_packet=task_packet, **kwargs)
    outcome["result_packet"] = packet
    outcome["verifier_verdicts"] = [verdict] if verdict else []
    outcome["ingestion"]["role_mapping"] = "policy/role_result_mapping.v1.0.json"
    signature = role_result.get("issue_signature")
    if signature and record_root is not None and role_result["result_status"] in ISSUE_STATUSES:
        import lifecycle_sweep

        entry = lifecycle_sweep.record_failure(
            record_root, signature, f"{role_result['role_id']} {role_result['result_status']} ({role_result['reason_code']})",
            "待 CONTROL_RESEARCH 依證據判斷：暫時或機制（classify_issue）")
        outcome["issue_recorded"] = entry["issue_id"]
    return outcome


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Repository Result Ingestion Adapter")
    source = parser.add_mutually_exclusive_group(required=True)
    source.add_argument("--result-packet")
    source.add_argument("--role-result")
    parser.add_argument("--verdict-output")
    parser.add_argument("--task-packet", required=True)
    parser.add_argument("--state", required=True)
    parser.add_argument("--execution-envelope", required=True)
    parser.add_argument("--event-log", required=True)
    parser.add_argument("--segment", action="append", default=[])
    parser.add_argument("--distillation-envelope")
    parser.add_argument("--evidence-records")
    parser.add_argument("--provenance-records")
    parser.add_argument("--continuation-box")
    parser.add_argument("--current-authority")
    parser.add_argument("--state-output", required=True)
    parser.add_argument("--execution-envelope-output", required=True)
    parser.add_argument("--distillation-envelope-output", required=True)
    parser.add_argument("--task-packet-output", required=True)
    args = parser.parse_args()

    segment_store = {}
    for path in args.segment:
        segment = load_object(Path(path))
        segment_id = segment.get("segment_id")
        if not segment_id:
            raise ValueError(f"SEGMENT_ID_REQUIRED:{path}")
        segment_store[segment_id] = segment

    common = dict(
        task_packet=load_object(Path(args.task_packet)),
        current_state=load_object(Path(args.state)),
        execution_envelopes=load_record_list(Path(args.execution_envelope)),
        event_log_path=Path(args.event_log),
        segment_store=segment_store or None,
        distillation_envelopes=(
            load_record_list(Path(args.distillation_envelope))
            if args.distillation_envelope else []
        ),
        evidence_records=(
            load_record_list(Path(args.evidence_records))
            if args.evidence_records else []
        ),
        provenance_records=(
            load_record_list(Path(args.provenance_records))
            if args.provenance_records else []
        ),
        continuation_box=(
            load_object(Path(args.continuation_box))
            if args.continuation_box else None
        ),
        current_authority=(
            load_object(Path(args.current_authority))
            if args.current_authority else None
        ),
    )
    if args.role_result:
        result = ingest_role_result(role_result=load_object(Path(args.role_result)), **common)
        if result["verifier_verdicts"]:
            if not args.verdict_output:
                raise ValueError("VERDICT_OUTPUT_REQUIRED")
            save_json(Path(args.verdict_output), result["verifier_verdicts"])
    else:
        result = ingest(result_packet=load_object(Path(args.result_packet)), **common)

    save_json(Path(args.state_output), result["central_state"])
    save_json(Path(args.execution_envelope_output), result["execution_envelopes"])
    save_json(Path(args.distillation_envelope_output), result["distillation_records"])
    save_json(Path(args.task_packet_output), result["next_task_packets"])
    print(json.dumps({
        "status": result["status"],
        "result_id": result["result_id"],
        "execution_record_ref": result["execution_record_ref"],
        "next_task_packet_count": len(result["next_task_packets"]),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
