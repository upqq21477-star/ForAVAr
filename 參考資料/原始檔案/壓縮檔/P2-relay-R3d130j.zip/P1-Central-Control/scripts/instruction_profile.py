#!/usr/bin/env python3
"""Resolve user shortcuts to compact, model-ready instruction profiles."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/instruction_profile.schema.json"
PROFILE_DIR = ROOT / "P1-Central-Control/canonical/instruction_profiles"
SHORTCUTS = ROOT / "P1-Central-Control/canonical/command_shortcuts.json"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_profile(profile: dict[str, Any]) -> None:
    Draft202012Validator(load_json(SCHEMA)).validate(profile)


def resolve_shortcut(shortcut: str) -> dict[str, Any]:
    registry = load_json(SHORTCUTS)
    for item in registry["shortcuts"]:
        if item.get("shortcut") == shortcut:
            return item
    raise ValueError(f"未知 shortcut: {shortcut}")


def load_profile(profile_id: str) -> dict[str, Any]:
    if not profile_id.startswith("IP:"):
        raise ValueError("profile_id 必須以 IP: 開頭")
    path = PROFILE_DIR / (profile_id[3:] + ".json")
    if not path.exists():
        matches = [
            p for p in PROFILE_DIR.glob("*.json")
            if p.stem.upper() == profile_id[3:].upper()
        ]
        if len(matches) != 1:
            raise FileNotFoundError(f"找不到 profile: {profile_id}")
        path = matches[0]

    profile = load_json(path)
    validate_profile(profile)

    if profile["profile_id"] != profile_id:
        raise ValueError("profile_id 與檔案內容不一致")
    if profile["status"] != "ACTIVE":
        raise ValueError("只有 ACTIVE profile 可以啟用")

    return profile


def compile_prompt(profile: dict[str, Any]) -> str:
    validate_profile(profile)
    priorities = sorted(
        profile["semantic_priorities"],
        key=lambda item: (-item["weight"], item["tag"]),
    )
    lines = [
        "【語義指令配置】",
        f"模式：{profile['name']}",
        "優先行為：",
    ]

    for item in priorities:
        lines.append(f"- {item['directive']}")

    lines.append("硬邊界：")
    for item in profile["hard_boundaries"]:
        lines.append(f"- {item['directive']}")

    return "\n".join(lines)


def activate(shortcut: str) -> dict[str, Any]:
    route = resolve_shortcut(shortcut)

    if route["command"] != "instruction.activate":
        raise ValueError("shortcut 不是 instruction.activate")

    profile = load_profile(route["profile_id"])
    ordered = sorted(
        profile["semantic_priorities"],
        key=lambda item: (-item["weight"], item["tag"]),
    )

    return {
        "shortcut": shortcut,
        "profile_id": profile["profile_id"],
        "semantic_tags": [item["tag"] for item in ordered],
        "compiled_prompt": compile_prompt(profile),
        "model_controls": profile["model_controls"],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Instruction Profile Router")
    sub = parser.add_subparsers(dest="command", required=True)

    resolve_cmd = sub.add_parser("resolve")
    resolve_cmd.add_argument("shortcut")

    compile_cmd = sub.add_parser("compile")
    compile_cmd.add_argument("profile_id")

    activate_cmd = sub.add_parser("activate")
    activate_cmd.add_argument("shortcut")

    args = parser.parse_args()

    if args.command == "resolve":
        result = resolve_shortcut(args.shortcut)
    elif args.command == "compile":
        profile = load_profile(args.profile_id)
        result = {
            "profile_id": args.profile_id,
            "compiled_prompt": compile_prompt(profile),
        }
    else:
        result = activate(args.shortcut)

    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
