#!/usr/bin/env python3
"""Deterministic phase gate for the single P2 B1-B8 feature batch.

The orchestrator extends the existing Brain/Central workflow. It is not a
second Current, a general shell runner, or a replacement for the final Verifier.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from brain_mode_controller import MIN_PLAN_EVIDENCE_CHARS, PLAN_GATE_KEYS


ROOT = Path(__file__).resolve().parents[2]
CURRENT_REF = "P1-CURRENT.json"
WORK_SCHEMA_REF = "P1-Central-Control/schemas/operational_work_unit.schema.json"
MANIFEST_SCHEMA_REF = "P1-Central-Control/schemas/feature_batch_manifest.schema.json"
CASE_SCHEMA_REF = "P1-Central-Control/schemas/local_case_sim_evidence.schema.json"
CLOSURE_SCHEMA_REF = "P1-Central-Control/schemas/feature_batch_closure_evidence.schema.json"
EXPECTED_BATCH_ID = "P2-B1-B8-CODE-FIRST"
FEATURE_IDS = tuple(f"P2-F{i:02d}" for i in range(1, 31))
CLOSURE_CHECKS = (
    "all_features_implemented",
    "all_local_case_sims_pass",
    "all_declared_outputs_present",
    "all_call_paths_and_interfaces_closed",
    "state_and_error_propagation_closed",
    "authorization_boundaries_checked",
    "recovery_paths_checked",
)
REQUIRED_LOCAL_CASE_KINDS = {"NORMAL", "NEGATIVE", "BOUNDARY"}
RECEIPT_DIR = "P1-Central-Control/progress/local-case-sim"


class BatchGateError(RuntimeError):
    def __init__(self, code: str, detail: str = "") -> None:
        self.code = code
        self.detail = detail
        super().__init__(f"{code}:{detail}" if detail else code)


def _safe_path(root: Path, ref: str, *, must_exist: bool = True) -> Path:
    if not isinstance(ref, str) or not ref:
        raise BatchGateError("BATCH_PATH_REQUIRED")
    candidate = Path(ref)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise BatchGateError("BATCH_PATH_FORBIDDEN", str(ref))
    base = root.resolve()
    cursor = base
    for part in candidate.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise BatchGateError("BATCH_PATH_SYMLINK", str(ref))
    path = base / candidate
    try:
        path.resolve().relative_to(base)
    except (OSError, ValueError) as exc:
        raise BatchGateError("BATCH_PATH_OUTSIDE_ROOT", str(ref)) from exc
    if must_exist and not path.is_file():
        raise BatchGateError("BATCH_FILE_MISSING", str(ref))
    if must_exist and not path.resolve().is_file():
        raise BatchGateError("BATCH_FILE_INVALID", str(ref))
    return path


def _read_json(root: Path, ref: str, code: str) -> dict[str, Any]:
    path = _safe_path(root, ref)
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise BatchGateError(code, str(ref)) from exc
    if not isinstance(value, dict):
        raise BatchGateError(code, f"JSON object required: {ref}")
    return value


def _validate_schema(root: Path, value: dict[str, Any], schema_ref: str, code: str) -> None:
    schema = _read_json(root, schema_ref, code + "_SCHEMA_UNAVAILABLE")
    try:
        from jsonschema import Draft202012Validator
    except ImportError as exc:
        raise BatchGateError(code + "_SCHEMA_VALIDATOR_UNAVAILABLE", "jsonschema is not installed") from exc
    try:
        Draft202012Validator.check_schema(schema)
        errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    except Exception as exc:
        raise BatchGateError(code + "_SCHEMA_INVALID", f"{schema_ref}:{type(exc).__name__}:{exc}") from exc
    if errors:
        first = errors[0]
        location = ".".join(str(item) for item in first.path)
        raise BatchGateError(code + "_SCHEMA_INVALID", f"{schema_ref}:{location}:{first.message}")


def _atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
    temp: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=path.parent, prefix=f".{path.name}.", suffix=".tmp", delete=False) as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
            temp = Path(stream.name)
        os.replace(temp, path)
    finally:
        if temp is not None and temp.exists():
            temp.unlink()


def _current_and_work(root: Path) -> tuple[dict[str, Any], dict[str, Any], str]:
    current = _read_json(root, CURRENT_REF, "BATCH_CURRENT_INVALID")
    control = current.get("implementation_control")
    stage = current.get("current_stage")
    if not isinstance(control, dict) or not isinstance(stage, dict):
        raise BatchGateError("BATCH_CURRENT_POINTERS_MISSING")
    work_ref = control.get("active_work_packet")
    if not isinstance(work_ref, str) or not work_ref:
        raise BatchGateError("BATCH_ACTIVE_WORK_REF_MISSING")
    work = _read_json(root, work_ref, "BATCH_ACTIVE_WORK_INVALID")
    contract = work.get("operational_contract")
    if not isinstance(contract, dict):
        raise BatchGateError("BATCH_ACTIVE_WORK_CONTRACT_MISSING")
    selected_id = stage.get("work_unit_id") or stage.get("slice_id") or stage.get("id")
    if not isinstance(selected_id, str) or not selected_id.strip():
        raise BatchGateError("BATCH_CURRENT_WORK_ID_INVALID")
    if work.get("work_id") != stage.get("id") or work.get("work_unit") != selected_id or contract.get("work_unit_id") != work.get("work_unit"):
        raise BatchGateError("BATCH_ACTIVE_WORK_ID_MISMATCH")
    _validate_schema(root, work, WORK_SCHEMA_REF, "BATCH_ACTIVE_WORK")
    return current, work, work_ref


def _manifest_ref_for_work(work: dict[str, Any]) -> str | None:
    contract = work.get("operational_contract")
    if not isinstance(contract, dict):
        return None
    ref = contract.get("feature_batch_manifest_ref")
    if ref is None:
        return None
    if not isinstance(ref, str) or not ref.strip():
        raise BatchGateError("FEATURE_BATCH_MANIFEST_REF_INVALID")
    return ref


def _batch_scope_fingerprint(manifest: dict[str, Any]) -> str:
    """Fingerprint the frozen intent/feature allocation, excluding mutable implementation evidence."""
    try:
        batch_id = manifest["batch_id"]
        workstreams = manifest["workstreams"]
        features = manifest["features"]
        if not isinstance(batch_id, str) or not isinstance(workstreams, list) or not isinstance(features, list):
            raise TypeError("invalid scope fields")
        lines = [batch_id]
        for item in sorted(workstreams, key=lambda row: row["section_id"]):
            section_id = item["section_id"]
            feature_ids = item["feature_ids"]
            if not isinstance(section_id, str) or not isinstance(feature_ids, list) or any(not isinstance(x, str) for x in feature_ids):
                raise TypeError("invalid workstream scope")
            lines.append(f"W|{section_id}|{','.join(sorted(feature_ids))}")
        for item in sorted(features, key=lambda row: row["feature_id"]):
            feature_id = item["feature_id"]
            name = item["name"]
            sections = item["roadmap_sections"]
            dependencies = item["depends_on"]
            if (
                not isinstance(feature_id, str) or not isinstance(name, str)
                or not isinstance(sections, list) or any(not isinstance(x, str) for x in sections)
                or not isinstance(dependencies, list) or any(not isinstance(x, str) for x in dependencies)
            ):
                raise TypeError("invalid feature scope")
            lines.append(
                f"F|{feature_id}|{name}|{','.join(sorted(sections))}|{','.join(sorted(dependencies))}"
            )
        canonical = "\n".join(lines) + "\n"
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()
    except (KeyError, TypeError, ValueError) as exc:
        raise BatchGateError("FEATURE_BATCH_SCOPE_INVALID", str(exc)) from exc


def _validate_scope_change_history(manifest: dict[str, Any]) -> None:
    """Reject stale or incomplete scope-change audit entries before phase admission."""
    history = manifest.get("scope_change_history", [])
    if not isinstance(history, list):
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_HISTORY_INVALID")
    if not history:
        return
    row = history[-1]
    required = ("change_id", "approval_ref", "previous_scope_fingerprint", "new_scope_fingerprint", "affected_feature_ids")
    if not isinstance(row, dict) or row.get("status") != "APPROVED" or any(not row.get(key) for key in required):
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_NOT_APPROVED")
    if row.get("new_scope_fingerprint") != manifest.get("scope_fingerprint"):
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_FINGERPRINT_MISMATCH")
    known_features = {feature.get("feature_id") for feature in manifest.get("features", []) if isinstance(feature, dict)}
    affected_features = set(row.get("affected_feature_ids", []))
    if not affected_features or not affected_features.issubset(known_features):
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_FEATURE_BINDING_INVALID")
    flags = ("dependency_graph_recomputed", "downstream_evidence_invalidated", "reopened_to_planning", "refrozen_after_review")
    if any(row.get(flag) is not True for flag in flags):
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_GOVERNANCE_INCOMPLETE")
    phase = row.get("phase_transition")
    allowed_phases = {"PLANNING", "REALIZATION", "CLOSURE", "FINAL_TEST"}
    if not isinstance(phase, list) or len(phase) != 3 or phase[0] not in allowed_phases or phase[1] != "PLANNING" or phase[2] != "REALIZATION":
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_PHASE_TRACE_INVALID")
    invalidated = {"LOCAL_CASE_RECEIPTS", "CLOSURE_EVIDENCE", "OFFICIAL_TEST_ROSTER", "FINAL_TEST_ADMISSION"}
    if not invalidated.issubset(set(row.get("evidence_invalidated", []))):
        raise BatchGateError("FEATURE_BATCH_SCOPE_CHANGE_EVIDENCE_INVALIDATION_INCOMPLETE")


def _load_manifest(root: Path, work: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    ref = _manifest_ref_for_work(work)
    if ref is None:
        raise BatchGateError("FEATURE_BATCH_MANIFEST_NOT_BOUND_TO_ACTIVE_WORK")
    manifest = _read_json(root, ref, "FEATURE_BATCH_MANIFEST_INVALID")
    _validate_schema(root, manifest, MANIFEST_SCHEMA_REF, "FEATURE_BATCH_MANIFEST")
    if manifest.get("batch_id") != EXPECTED_BATCH_ID:
        raise BatchGateError("FEATURE_BATCH_ID_MISMATCH")
    if manifest.get("scope_frozen") is not True:
        raise BatchGateError("FEATURE_BATCH_SCOPE_NOT_FROZEN")
    expected_scope_fingerprint = manifest.get("scope_fingerprint")
    if (
        not isinstance(expected_scope_fingerprint, str)
        or re.fullmatch(r"sha256:[0-9a-f]{64}", expected_scope_fingerprint) is None
        or _batch_scope_fingerprint(manifest) != expected_scope_fingerprint
    ):
        raise BatchGateError("FEATURE_BATCH_SCOPE_FINGERPRINT_MISMATCH")
    _validate_scope_change_history(manifest)
    features = manifest.get("features")
    if not isinstance(features, list):
        raise BatchGateError("FEATURE_BATCH_FEATURES_INVALID")
    ids = [item.get("feature_id") for item in features if isinstance(item, dict)]
    if len(features) != 30 or len(set(ids)) != 30 or set(ids) != set(FEATURE_IDS):
        raise BatchGateError("FEATURE_BATCH_ROSTER_MISMATCH")
    known_ids = set(ids)
    for feature in features:
        deps = feature.get("depends_on")
        if not isinstance(deps, list) or any(dep not in known_ids or dep == feature.get("feature_id") for dep in deps):
            raise BatchGateError("FEATURE_BATCH_DEPENDENCY_INVALID", str(feature.get("feature_id")))
        plans = feature.get("local_case_plan")
        if not isinstance(plans, list) or len(plans) != 3 or {p.get("kind") for p in plans if isinstance(p, dict)} != REQUIRED_LOCAL_CASE_KINDS:
            raise BatchGateError("FEATURE_LOCAL_CASE_PLAN_INVALID", str(feature.get("feature_id")))
    return ref, manifest


def _git_head(root: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=root, capture_output=True,
            text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    value = result.stdout.strip()
    return value if result.returncode == 0 and re.fullmatch(r"[0-9a-f]{40}", value) else None


def feature_implementation_fingerprint(root: Path, feature: dict[str, Any]) -> str:
    refs: list[str] = []
    for key in ("implementation_refs", "test_refs"):
        values = feature.get(key)
        if not isinstance(values, list):
            raise BatchGateError("FEATURE_REFERENCE_LIST_INVALID", f"{feature.get('feature_id')}:{key}")
        for ref in values:
            if not isinstance(ref, str) or not ref:
                raise BatchGateError("FEATURE_REFERENCE_INVALID", str(feature.get("feature_id")))
            # Manifest status/evidence updates must not invalidate the source-code receipt.
            if ref == "P1-Central-Control/progress/P2-B1-B8.feature-batch.json":
                continue
            if ref.startswith(RECEIPT_DIR + "/"):
                continue
            if ref not in refs:
                refs.append(ref)
    if not refs:
        raise BatchGateError("FEATURE_FINGERPRINT_INPUTS_EMPTY", str(feature.get("feature_id")))
    digest = hashlib.sha256()
    for ref in sorted(refs):
        path = _safe_path(root, ref)
        data = path.read_bytes()
        digest.update(ref.encode("utf-8"))
        digest.update(b"\0")
        digest.update(str(len(data)).encode("ascii"))
        digest.update(b"\0")
        digest.update(hashlib.sha256(data).digest())
    return "sha256:" + digest.hexdigest()


def _feature_file_blockers(root: Path, feature: dict[str, Any]) -> list[str]:
    feature_id = str(feature.get("feature_id", "UNKNOWN"))
    blockers: list[str] = []
    refs: list[str] = []
    for key in ("implementation_refs", "test_refs"):
        values = feature.get(key, [])
        if not isinstance(values, list):
            blockers.append(f"{feature_id}:{key}:INVALID")
            continue
        refs.extend(value for value in values if isinstance(value, str))
    for ref in sorted(set(refs)):
        try:
            _safe_path(root, ref)
        except BatchGateError as exc:
            blockers.append(f"{feature_id}:{exc.code}:{ref}")
    return blockers


def _validate_receipt(root: Path, manifest: dict[str, Any], feature: dict[str, Any], receipt_ref: str, current_fingerprint: str) -> list[str]:
    blockers: list[str] = []
    feature_id = feature.get("feature_id")
    try:
        receipt = _read_json(root, receipt_ref, "LOCAL_CASE_SIM_RECEIPT_INVALID")
        _validate_schema(root, receipt, CASE_SCHEMA_REF, "LOCAL_CASE_SIM_RECEIPT")
    except BatchGateError as exc:
        return [f"{feature_id}:{exc.code}:{exc.detail}"]
    if receipt.get("batch_id") != manifest.get("batch_id") or receipt.get("feature_id") != feature_id:
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_RECEIPT_ID_MISMATCH")
    if receipt.get("batch_scope_fingerprint") != manifest.get("scope_fingerprint"):
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_SCOPE_FINGERPRINT_MISMATCH")
    if receipt.get("status") != "LOCAL_CASE_SIM_PASS" or receipt.get("exit_code") != 0:
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_NOT_PASS")
    if receipt.get("implementation_fingerprint") != current_fingerprint:
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_SOURCE_DRIFT")
    cases = receipt.get("cases", [])
    if len(cases) != 3 or {case.get("kind") for case in cases if isinstance(case, dict)} != REQUIRED_LOCAL_CASE_KINDS:
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_CASE_SET_INVALID")
    elif any(case.get("outcome") != "PASS" or not case.get("actual") for case in cases):
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_CASE_FAILED_OR_EMPTY")
    if not isinstance(receipt.get("tested_head"), str) or not re.fullmatch(r"[0-9a-f]{40}", receipt["tested_head"]):
        blockers.append(f"{feature_id}:LOCAL_CASE_SIM_HEAD_MISSING")
    return blockers


def evaluate_realization(root: Path, manifest: dict[str, Any]) -> dict[str, Any]:
    per_feature: list[dict[str, Any]] = []
    blockers: list[str] = []
    implemented_count = 0
    sim_pass_count = 0
    refs_present_count = 0
    for feature in manifest["features"]:
        feature_id = feature["feature_id"]
        local: list[str] = []
        if feature.get("implementation_status") != "IMPLEMENTED":
            local.append(f"{feature_id}:FEATURE_NOT_IMPLEMENTED")
        else:
            implemented_count += 1
        file_blockers = _feature_file_blockers(root, feature)
        if not file_blockers:
            refs_present_count += 1
        local.extend(file_blockers)
        plans = feature.get("local_case_plan", [])
        methods: list[tuple[str, str]] = []
        for plan in plans:
            test_ref, method = plan.get("test_ref"), plan.get("test_method")
            if not isinstance(test_ref, str) or test_ref not in feature.get("test_refs", []):
                local.append(f"{feature_id}:LOCAL_CASE_TEST_REF_UNASSIGNED:{plan.get('case_id')}")
                continue
            if not isinstance(method, str) or re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*\.test_[A-Za-z0-9_]+", method) is None:
                local.append(f"{feature_id}:LOCAL_CASE_TEST_METHOD_UNASSIGNED:{plan.get('case_id')}")
                continue
            if (test_ref, method) in methods:
                local.append(f"{feature_id}:LOCAL_CASE_TEST_METHOD_DUPLICATED:{method}")
            methods.append((test_ref, method))
            try:
                test_path = _safe_path(root, test_ref)
                if not test_ref.startswith("P1-Central-Control/tests/test_") or test_path.suffix != ".py":
                    local.append(f"{feature_id}:LOCAL_CASE_TEST_NOT_RUNNABLE:{test_ref}")
                elif f"def {method.split('.', 1)[1]}(" not in test_path.read_text(encoding="utf-8"):
                    local.append(f"{feature_id}:LOCAL_CASE_TEST_METHOD_MISSING:{test_ref}:{method}")
            except (BatchGateError, OSError, UnicodeDecodeError) as exc:
                local.append(f"{feature_id}:LOCAL_CASE_TEST_SOURCE_UNAVAILABLE:{type(exc).__name__}")
        if feature.get("local_case_sim_status") != "PASS":
            local.append(f"{feature_id}:LOCAL_CASE_SIM_NOT_PASS")
        else:
            receipt_refs = feature.get("local_case_sim_evidence_refs", [])
            if not isinstance(receipt_refs, list) or len(receipt_refs) != 1 or not isinstance(receipt_refs[0], str):
                local.append(f"{feature_id}:LOCAL_CASE_SIM_RECEIPT_REF_MISSING")
            else:
                try:
                    fingerprint = feature_implementation_fingerprint(root, feature)
                    receipt_blockers = _validate_receipt(root, manifest, feature, receipt_refs[0], fingerprint)
                    local.extend(receipt_blockers)
                except BatchGateError as exc:
                    local.append(f"{feature_id}:{exc.code}:{exc.detail}")
            if not local:
                sim_pass_count += 1
        blockers.extend(local)
        per_feature.append({
            "feature_id": feature_id,
            "implementation_status": feature.get("implementation_status"),
            "local_case_sim_status": feature.get("local_case_sim_status"),
            "blockers": local,
        })
    return {
        "feature_count": len(manifest["features"]),
        "implemented_count": implemented_count,
        "local_case_sim_pass_count": sim_pass_count,
        "features_with_all_declared_refs_present": refs_present_count,
        "blocker_count": len(blockers),
        "blockers": blockers[:200],
        "features": per_feature,
        "ready_for_closure": not blockers and implemented_count == 30 and sim_pass_count == 30 and refs_present_count == 30,
    }


def _load_closure_evidence(root: Path, manifest: dict[str, Any]) -> tuple[dict[str, Any] | None, list[str]]:
    ref = manifest.get("closure_evidence_ref")
    if not isinstance(ref, str) or not ref:
        return None, ["CLOSURE_EVIDENCE_REF_MISSING"]
    try:
        evidence = _read_json(root, ref, "CLOSURE_EVIDENCE_INVALID")
        _validate_schema(root, evidence, CLOSURE_SCHEMA_REF, "CLOSURE_EVIDENCE")
    except BatchGateError as exc:
        return None, [f"{exc.code}:{exc.detail}"]
    blockers: list[str] = []
    if evidence.get("status") != "CLOSURE_PASS" or evidence.get("batch_id") != manifest.get("batch_id"):
        blockers.append("CLOSURE_EVIDENCE_NOT_PASS")
    if evidence.get("scope_fingerprint") != manifest.get("scope_fingerprint"):
        blockers.append("CLOSURE_EVIDENCE_SCOPE_FINGERPRINT_MISMATCH")
    reviews = evidence.get("feature_reviews", [])
    reviews_by_id = {item.get("feature_id"): item for item in reviews if isinstance(item, dict)}
    if set(reviews_by_id) != set(FEATURE_IDS) or len(reviews) != 30:
        blockers.append("CLOSURE_EVIDENCE_FEATURE_ROSTER_MISMATCH")
    for feature in manifest.get("features", []):
        feature_id = feature.get("feature_id")
        review = reviews_by_id.get(feature_id)
        if review is None:
            continue
        try:
            fingerprint = feature_implementation_fingerprint(root, feature)
        except BatchGateError as exc:
            blockers.append(f"{feature_id}:{exc.code}")
            continue
        if review.get("implementation_fingerprint") != fingerprint:
            blockers.append(f"{feature_id}:CLOSURE_EVIDENCE_SOURCE_DRIFT")
        refs = feature.get("local_case_sim_evidence_refs", [])
        if refs and review.get("local_case_evidence_ref") != refs[0]:
            blockers.append(f"{feature_id}:CLOSURE_EVIDENCE_CASE_REF_MISMATCH")
    return evidence, blockers


def _validate_official_roster(root: Path, manifest: dict[str, Any]) -> tuple[list[dict[str, Any]], int, list[str]]:
    roster = manifest.get("official_test_roster")
    if not isinstance(roster, list) or not roster:
        return [], 0, ["OFFICIAL_TEST_ROSTER_EMPTY"]
    seen: set[str] = set()
    total = 0
    blockers: list[str] = []
    normalized: list[dict[str, Any]] = []
    for item in roster:
        test_ref = item.get("test_ref") if isinstance(item, dict) else None
        if not isinstance(test_ref, str) or not test_ref.startswith("P1-Central-Control/tests/test_") or not test_ref.endswith(".py"):
            blockers.append("OFFICIAL_TEST_REF_INVALID")
            continue
        if test_ref in seen:
            blockers.append(f"OFFICIAL_TEST_REF_DUPLICATED:{test_ref}")
            continue
        seen.add(test_ref)
        try:
            path = _safe_path(root, test_ref)
            source = path.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=test_ref)
        except (BatchGateError, OSError, UnicodeDecodeError, SyntaxError) as exc:
            blockers.append(f"OFFICIAL_TEST_SOURCE_INVALID:{test_ref}:{type(exc).__name__}")
            continue
        method_names = sorted({
            node.name for node in ast.walk(tree)
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith("test_")
        })
        declared_names = item.get("method_names")
        declared_count = item.get("expected_method_count")
        if not isinstance(declared_names, list) or sorted(set(declared_names)) != method_names:
            blockers.append(f"OFFICIAL_TEST_METHOD_SET_MISMATCH:{test_ref}")
        if declared_count != len(method_names) or not method_names:
            blockers.append(f"OFFICIAL_TEST_METHOD_COUNT_MISMATCH:{test_ref}")
        feature_ids = item.get("feature_ids")
        if not isinstance(feature_ids, list) or not feature_ids or any(feature_id not in FEATURE_IDS for feature_id in feature_ids):
            blockers.append(f"OFFICIAL_TEST_FEATURE_BINDING_INVALID:{test_ref}")
        total += len(method_names)
        normalized.append({
            "test_ref": test_ref,
            "expected_method_count": len(method_names),
            "method_names": method_names,
            "feature_ids": sorted(set(feature_ids or [])),
        })
    if not normalized:
        blockers.append("OFFICIAL_TEST_ROSTER_NO_RUNNABLE_TESTS")
    return normalized, total, blockers


def validate_final_test_gate(root: Path = ROOT) -> dict[str, Any]:
    """Reject official regression/integration before the Current-selected batch reaches FINAL_TEST."""
    try:
        _, work, _ = _current_and_work(root)
        manifest_ref = _manifest_ref_for_work(work)
        if manifest_ref is None:
            # Compatibility for isolated legacy unit-test fixtures with no batch manifest.
            return {"status": "NOT_REQUIRED", "required": False, "test_roster": [], "expected_test_method_count": None}
        _, manifest = _load_manifest(root, work)
        blockers: list[str] = []
        if manifest.get("batch_phase") != "FINAL_TEST":
            blockers.append("FEATURE_BATCH_NOT_IN_FINAL_TEST")
        if manifest.get("official_test_scope_status") != "READY_FOR_BATCH":
            blockers.append("FEATURE_BATCH_TEST_ROSTER_NOT_READY")
        checks = manifest.get("closure_checks", {})
        for key in CLOSURE_CHECKS:
            if checks.get(key) is not True:
                blockers.append(f"FEATURE_BATCH_CLOSURE_CHECK_NOT_PASS:{key}")
        if checks.get("official_test_roster_complete") is not True:
            blockers.append("FEATURE_BATCH_OFFICIAL_ROSTER_NOT_COMPLETE")
        readiness = evaluate_realization(root, manifest)
        blockers.extend(readiness["blockers"])
        _, closure_blockers = _load_closure_evidence(root, manifest)
        blockers.extend(closure_blockers)
        roster, count, roster_blockers = _validate_official_roster(root, manifest)
        blockers.extend(roster_blockers)
        if blockers:
            raise BatchGateError("FEATURE_BATCH_CLOSURE_GATE_REQUIRED", ";".join(blockers[:40]))
        return {
            "status": "PASS",
            "required": True,
            "batch_id": manifest["batch_id"],
            "batch_phase": manifest["batch_phase"],
            "manifest_ref": manifest_ref,
            "manifest_fingerprint": "sha256:" + hashlib.sha256(_safe_path(root, manifest_ref).read_bytes()).hexdigest(),
            "scope_fingerprint": manifest["scope_fingerprint"],
            "feature_count": 30,
            "expected_test_method_count": count,
            "test_roster": roster,
        }
    except BatchGateError:
        raise


def _persist_manifest(root: Path, manifest_ref: str, manifest: dict[str, Any]) -> None:
    _validate_schema(root, manifest, MANIFEST_SCHEMA_REF, "FEATURE_BATCH_MANIFEST")
    _atomic_write_json(_safe_path(root, manifest_ref), manifest)


def _case_receipt_path(feature_id: str) -> str:
    return f"{RECEIPT_DIR}/{feature_id}.local-case-sim.json"


def _run_one_case(root: Path, plan: dict[str, Any], timeout: int) -> dict[str, Any]:
    test_ref = plan["test_ref"]
    method = plan["test_method"]
    test_path = _safe_path(root, test_ref)
    if not test_ref.startswith("P1-Central-Control/tests/test_") or test_path.suffix != ".py":
        raise BatchGateError("LOCAL_CASE_TEST_NOT_RUNNABLE", test_ref)
    if re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*\.test_[A-Za-z0-9_]+", method) is None:
        raise BatchGateError("LOCAL_CASE_TEST_METHOD_INVALID", method)
    class_name, method_name = method.split(".", 1)
    source = test_path.read_text(encoding="utf-8")
    if f"def {method_name}(" not in source:
        raise BatchGateError("LOCAL_CASE_TEST_METHOD_MISSING", f"{test_ref}:{method}")
    if sys.version_info[:2] != (3, 11):
        raise BatchGateError("LOCAL_CASE_PYTHON_VERSION_MISMATCH", sys.version.split()[0])
    env = dict(os.environ)
    scripts = str(root / "P1-Central-Control/scripts")
    tests = str(root / "P1-Central-Control/tests")
    env["PYTHONPATH"] = os.pathsep.join(item for item in (scripts, tests, env.get("PYTHONPATH","")) if item)
    command = [sys.executable, str(test_path), f"{class_name}.{method_name}"]
    try:
        result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout.decode("utf-8",errors="replace") if isinstance(exc.stdout,bytes) else (exc.stdout or "")
        err = exc.stderr.decode("utf-8",errors="replace") if isinstance(exc.stderr,bytes) else (exc.stderr or "")
        return {
            "case_id":plan["case_id"],"kind":plan["kind"],"input":plan["scenario"],
            "expected":plan["expected_behavior"],"actual":"LOCAL_CASE_TIMEOUT",
            "outcome":"BLOCKED","return_code":None,"stdout":out[-20000:],"stderr":err[-20000:],
            "command":" ".join(command),
        }
    output = (result.stdout or "") + "\n" + (result.stderr or "")
    match = re.findall(r"Ran\s+(\d+)\s+tests?\s+in\s+", output)
    one_method = bool(match) and int(match[-1]) == 1
    passed = result.returncode == 0 and one_method and re.search(r"\bOK\b", output) is not None
    return {
        "case_id":plan["case_id"],"kind":plan["kind"],"input":plan["scenario"],
        "expected":plan["expected_behavior"],
        "actual":f"exit={result.returncode}; " + (output[-4000:] or "NO_TEST_OUTPUT"),
        "outcome":"PASS" if passed else "FAIL",
        "return_code":result.returncode,"stdout":(result.stdout or "")[-20000:],
        "stderr":(result.stderr or "")[-20000:],"command":" ".join(command),
    }


def run_local_case_sim(root: Path, feature_id: str, timeout: int = 180) -> dict[str, Any]:
    if feature_id not in FEATURE_IDS:
        raise BatchGateError("FEATURE_ID_UNKNOWN", feature_id)
    current, work, active_work_ref = _current_and_work(root)
    manifest_ref, manifest = _load_manifest(root, work)
    feature = next(item for item in manifest["features"] if item["feature_id"] == feature_id)
    if manifest.get("batch_phase") != "REALIZATION":
        raise BatchGateError("LOCAL_CASE_SIM_ONLY_DURING_REALIZATION", manifest.get("batch_phase","UNKNOWN"))
    if feature.get("implementation_status") != "IMPLEMENTED":
        raise BatchGateError("FEATURE_NOT_MARKED_IMPLEMENTED", feature_id)

    # The local-case runner is an executable mutation path: it writes receipts and
    # updates the frozen manifest. Require the approved Brain lifecycle here as well
    # as at the Central caller so direct CLI invocation cannot bypass the mode gate.
    current_stage = current.get("current_stage", {})
    open_statuses = {"READY", "BUILDING", "CHANGE_OBSERVED", "IN_PROGRESS"}
    if work.get("status") not in open_statuses or current_stage.get("status") not in open_statuses:
        raise BatchGateError(
            "LOCAL_CASE_WORK_UNIT_NOT_OPEN",
            f"work={work.get('status')};stage={current_stage.get('status')}",
        )
    control = work.get("brain_mode_control")
    if not isinstance(control, dict):
        raise BatchGateError("LOCAL_CASE_BRAIN_MODE_NOT_AUTHORIZED")
    evidence = control.get("plan_evidence")
    if not isinstance(evidence, dict):
        evidence = {}
    plan_complete = all(
        isinstance(evidence.get(key), str)
        and len(evidence[key].strip()) >= MIN_PLAN_EVIDENCE_CHARS
        for key in PLAN_GATE_KEYS
    )
    if (
        control.get("mode") != "SIMULATION"
        or control.get("plan_approved") is not True
        or not plan_complete
    ):
        raise BatchGateError(
            "LOCAL_CASE_BRAIN_MODE_NOT_AUTHORIZED",
            "A complete approved plan and successful construction-step transition to SIMULATION are required.",
        )
    if sys.version_info[:2] != (3, 11):
        raise BatchGateError("LOCAL_CASE_PYTHON_VERSION_MISMATCH", sys.version.split()[0])
    if os.environ.get("P2_NO_CHARGE_QUOTA_CONFIRMED") != "1":
        raise BatchGateError("LOCAL_CASE_NO_CHARGE_GATE_UNCONFIRMED", "Set P2_NO_CHARGE_QUOTA_CONFIRMED=1 only after verifying the existing environment is approved and has no-charge quota; do not create/resume a metered environment.")
    file_blockers = _feature_file_blockers(root, feature)
    if file_blockers:
        raise BatchGateError("FEATURE_OUTPUTS_MISSING", ";".join(file_blockers[:20]))
    plans = feature["local_case_plan"]
    if any(not isinstance(plan.get("test_method"), str) or not isinstance(plan.get("test_ref"), str) for plan in plans):
        raise BatchGateError("LOCAL_CASE_TEST_METHODS_UNASSIGNED", feature_id)
    head = _git_head(root)
    if head is None:
        raise BatchGateError("LOCAL_CASE_GIT_HEAD_UNAVAILABLE")

    # Capture the exact authority files after all cheap gates but before running
    # the cases. If another process changes Current, Active Work or the manifest
    # during the run, do not write a receipt against stale authority and never
    # overwrite the other process's newer manifest.
    authority_refs = {
        CURRENT_REF: current,
        active_work_ref: work,
        manifest_ref: manifest,
    }
    authority_paths: dict[str, Path] = {}
    authority_bytes: dict[str, bytes] = {}
    for ref, expected_value in authority_refs.items():
        path = _safe_path(root, ref)
        try:
            raw = path.read_bytes()
            observed_value = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise BatchGateError("LOCAL_CASE_AUTHORITY_UNAVAILABLE", ref) from exc
        if observed_value != expected_value:
            raise BatchGateError("LOCAL_CASE_AUTHORITY_CHANGED_BEFORE_RUN", ref)
        authority_paths[ref] = path
        authority_bytes[ref] = raw

    before = feature_implementation_fingerprint(root, feature)
    results: list[dict[str, Any]] = []
    blocker: str | None = None
    for plan in plans:
        try:
            results.append(_run_one_case(root, plan, timeout))
        except BatchGateError as exc:
            blocker = f"{exc.code}:{exc.detail}"
            results.append({
                "case_id":plan.get("case_id","UNKNOWN"),"kind":plan.get("kind","BOUNDARY"),
                "input":plan.get("scenario",""),"expected":plan.get("expected_behavior",""),
                "actual":blocker,"outcome":"BLOCKED","return_code":None,"stdout":"","stderr":"",
                "command":"NOT_LAUNCHED",
            })
            break
    for ref, path in authority_paths.items():
        try:
            current_raw = path.read_bytes()
        except OSError as exc:
            raise BatchGateError("LOCAL_CASE_AUTHORITY_CHANGED_DURING_RUN", ref) from exc
        if current_raw != authority_bytes[ref]:
            raise BatchGateError("LOCAL_CASE_AUTHORITY_CHANGED_DURING_RUN", ref)
    current_head = _git_head(root)
    if current_head != head:
        raise BatchGateError(
            "LOCAL_CASE_HEAD_CHANGED_DURING_RUN",
            f"before={head};after={current_head}",
        )

    after = feature_implementation_fingerprint(root, feature)
    if after != before:
        blocker = "LOCAL_CASE_SOURCE_CHANGED_DURING_RUN"
    all_pass = len(results) == 3 and all(item["outcome"] == "PASS" for item in results) and blocker is None and after == before
    status = "LOCAL_CASE_SIM_PASS" if all_pass else ("LOCAL_CASE_SIM_BLOCKED" if blocker else "LOCAL_CASE_SIM_FAIL")
    receipt = {
        "schema_version":"1.0",
        "batch_id":manifest["batch_id"],
        "batch_scope_fingerprint":manifest["scope_fingerprint"],
        "feature_id":feature_id,
        "status":status,
        "command":"feature_batch_orchestrator.py run-local-sim " + feature_id,
        "executed_at":datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00","Z"),
        "tested_head":head,
        "implementation_fingerprint":before,
        "exit_code":0 if all_pass else 2,
        "cases":[{key:item[key] for key in ("case_id","kind","input","expected","actual","outcome")} for item in results],
        "stdout":"\n".join(item.get("stdout","") for item in results)[-50000:],
        "stderr":"\n".join(item.get("stderr","") for item in results)[-50000:],
        "stdout_ref":None,
        "stderr_ref":None,
    }
    _validate_schema(root, receipt, CASE_SCHEMA_REF, "LOCAL_CASE_SIM_RECEIPT")
    receipt_ref = _case_receipt_path(feature_id)
    _atomic_write_json(_safe_path(root, receipt_ref, must_exist=False), receipt)
    feature["local_case_sim_status"] = "PASS" if all_pass else ("BLOCKED" if status == "LOCAL_CASE_SIM_BLOCKED" else "FAIL")
    feature["local_case_sim_evidence_refs"] = [receipt_ref]
    _persist_manifest(root, manifest_ref, manifest)
    return {"status":status,"feature_id":feature_id,"receipt_ref":receipt_ref,"tested_head":head,"implementation_fingerprint":before,"case_results":receipt["cases"],"blocker":blocker}


def mark_feature_implemented(root: Path, feature_id: str) -> dict[str, Any]:
    if feature_id not in FEATURE_IDS:
        raise BatchGateError("FEATURE_ID_UNKNOWN", feature_id)
    current, work, _ = _current_and_work(root)
    stage = current.get("current_stage", {})
    open_statuses = {"READY", "BUILDING", "CHANGE_OBSERVED", "IN_PROGRESS"}
    if work.get("status") not in open_statuses or stage.get("status") not in open_statuses:
        raise BatchGateError(
            "WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION",
            f"work={work.get('status')};stage={stage.get('status')}",
        )
    control = work.get("brain_mode_control")
    if not isinstance(control, dict):
        raise BatchGateError("BRAIN_NOT_IN_AUTHORIZED_CONSTRUCTION_MODE")
    evidence = control.get("plan_evidence")
    if not isinstance(evidence, dict):
        evidence = {}
    gates_satisfied = all(
        isinstance(evidence.get(key), str)
        and len(evidence[key].strip()) >= MIN_PLAN_EVIDENCE_CHARS
        for key in PLAN_GATE_KEYS
    )
    if (
        control.get("mode") != "CONSTRUCTION"
        or control.get("plan_approved") is not True
        or not gates_satisfied
    ):
        raise BatchGateError(
            "BRAIN_NOT_IN_AUTHORIZED_CONSTRUCTION_MODE",
            "A complete plan and explicit PLAN_APPROVED transition are required.",
        )
    manifest_ref, manifest = _load_manifest(root, work)
    if manifest.get("batch_phase") != "REALIZATION":
        raise BatchGateError("FEATURE_IMPLEMENTATION_ONLY_DURING_REALIZATION")
    feature = next(item for item in manifest["features"] if item["feature_id"] == feature_id)
    blockers = _feature_file_blockers(root, feature)
    for plan in feature["local_case_plan"]:
        test_ref, method = plan.get("test_ref"), plan.get("test_method")
        if not isinstance(test_ref, str) or not isinstance(method, str):
            blockers.append(f"{feature_id}:LOCAL_CASE_METHOD_PLAN_INCOMPLETE:{plan.get('case_id')}")
            continue
        if test_ref not in feature.get("test_refs", []):
            blockers.append(f"{feature_id}:LOCAL_CASE_METHOD_TEST_REF_NOT_DECLARED:{test_ref}")
            continue
        try:
            test_path = _safe_path(root, test_ref)
            class_name, method_name = method.split(".", 1)
            tree = ast.parse(test_path.read_text(encoding="utf-8"), filename=test_ref)
            methods = {
                (node.name, child.name)
                for node in ast.walk(tree) if isinstance(node, ast.ClassDef)
                for child in node.body
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef))
            }
            if (class_name, method_name) not in methods:
                blockers.append(f"{feature_id}:LOCAL_CASE_METHOD_NOT_DECLARED:{method}")
        except (BatchGateError, OSError, UnicodeDecodeError, SyntaxError, ValueError) as exc:
            blockers.append(f"{feature_id}:LOCAL_CASE_METHOD_SOURCE_INVALID:{type(exc).__name__}")
    if blockers:
        raise BatchGateError("FEATURE_IMPLEMENTATION_OUTPUTS_INCOMPLETE", ";".join(blockers[:40]))
    feature["implementation_status"] = "IMPLEMENTED"
    feature["local_case_sim_status"] = "NOT_RUN"
    feature["local_case_sim_evidence_refs"] = []
    _persist_manifest(root, manifest_ref, manifest)
    return {"status":"IMPLEMENTED_PENDING_LOCAL_CASE_SIM","feature_id":feature_id,"batch_id":manifest["batch_id"]}


def _validate_closure_readiness(root: Path, manifest: dict[str, Any]) -> list[str]:
    blockers: list[str] = []
    readiness = evaluate_realization(root, manifest)
    blockers.extend(readiness["blockers"])
    checks = manifest.get("closure_checks", {})
    for key in CLOSURE_CHECKS:
        if checks.get(key) is not True:
            blockers.append(f"CLOSURE_CHECK_NOT_PASS:{key}")
    _, evidence_blockers = _load_closure_evidence(root, manifest)
    blockers.extend(evidence_blockers)
    return blockers


def advance_phase(root: Path, target: str) -> dict[str, Any]:
    if target not in {"CLOSURE","FINAL_TEST"}:
        raise BatchGateError("FEATURE_BATCH_PHASE_TRANSITION_FORBIDDEN", target)
    _, work, _ = _current_and_work(root)
    manifest_ref, manifest = _load_manifest(root, work)
    current_phase = manifest.get("batch_phase")
    if target == "CLOSURE":
        if current_phase != "REALIZATION":
            raise BatchGateError("FEATURE_BATCH_PHASE_ORDER_INVALID", f"{current_phase}->CLOSURE")
        blockers = _validate_closure_readiness(root, manifest)
        if blockers:
            raise BatchGateError("FEATURE_BATCH_CLOSURE_GATE_BLOCKED", ";".join(blockers[:60]))
        manifest["batch_phase"] = "CLOSURE"
        _persist_manifest(root, manifest_ref, manifest)
        return {"status":"CLOSURE_OPENED","batch_id":manifest["batch_id"],"phase":"CLOSURE"}
    if current_phase != "CLOSURE":
        raise BatchGateError("FEATURE_BATCH_PHASE_ORDER_INVALID", f"{current_phase}->FINAL_TEST")
    blockers = _validate_closure_readiness(root, manifest)
    if blockers:
        raise BatchGateError("FEATURE_BATCH_CLOSURE_EVIDENCE_STALE", ";".join(blockers[:60]))
    if manifest.get("closure_checks", {}).get("official_test_roster_complete") is not True:
        raise BatchGateError("OFFICIAL_TEST_ROSTER_NOT_COMPLETE")
    roster, count, roster_blockers = _validate_official_roster(root, manifest)
    if roster_blockers:
        raise BatchGateError("OFFICIAL_TEST_ROSTER_INVALID", ";".join(roster_blockers[:60]))
    manifest["official_test_roster"] = roster
    manifest["official_test_scope_status"] = "READY_FOR_BATCH"
    manifest["batch_phase"] = "FINAL_TEST"
    _persist_manifest(root, manifest_ref, manifest)
    return {"status":"FINAL_TEST_READY","batch_id":manifest["batch_id"],"phase":"FINAL_TEST","feature_count":30,"expected_test_method_count":count,"test_roster":roster}


def prepare_official_test_roster(root: Path) -> dict[str, Any]:
    _, work, _ = _current_and_work(root)
    manifest_ref, manifest = _load_manifest(root, work)
    if manifest.get("batch_phase") != "CLOSURE":
        raise BatchGateError("OFFICIAL_ROSTER_CAN_ONLY_BE_PREPARED_AFTER_CLOSURE")
    blockers = _validate_closure_readiness(root, manifest)
    if blockers:
        raise BatchGateError("OFFICIAL_ROSTER_CLOSURE_EVIDENCE_STALE", ";".join(blockers[:60]))
    files: dict[str, set[str]] = {}
    for feature in manifest["features"]:
        for ref in feature.get("test_refs", []):
            if isinstance(ref,str) and ref.startswith("P1-Central-Control/tests/test_") and ref.endswith(".py"):
                files.setdefault(ref,set()).add(feature["feature_id"])
    roster: list[dict[str, Any]] = []
    for ref, owners in sorted(files.items()):
        path = _safe_path(root,ref)
        tree = ast.parse(path.read_text(encoding="utf-8"),filename=ref)
        names = sorted({node.name for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name.startswith("test_")})
        if names:
            roster.append({"test_ref":ref,"expected_method_count":len(names),"method_names":names,"feature_ids":sorted(owners)})
    if not roster:
        raise BatchGateError("OFFICIAL_TEST_ROSTER_EMPTY")
    manifest["official_test_roster"] = roster
    manifest["closure_checks"]["official_test_roster_complete"] = True
    _persist_manifest(root,manifest_ref,manifest)
    return {"status":"OFFICIAL_ROSTER_PREPARED","test_file_count":len(roster),"expected_test_method_count":sum(item["expected_method_count"] for item in roster),"roster":roster}


def inspect_batch(root: Path = ROOT) -> dict[str, Any]:
    _, work, _ = _current_and_work(root)
    manifest_ref, manifest = _load_manifest(root, work)
    readiness = evaluate_realization(root, manifest)
    closure_evidence, closure_evidence_blockers = _load_closure_evidence(root,manifest)
    checks = manifest.get("closure_checks",{})
    return {
        "status":"REALIZATION_INCOMPLETE" if not readiness["ready_for_closure"] else ("CLOSURE_EVIDENCE_PENDING" if _validate_closure_readiness(root,manifest) else "CLOSURE_READY"),
        "batch_id":manifest["batch_id"],
        "batch_phase":manifest["batch_phase"],
        "scope_frozen":manifest["scope_frozen"],
        "feature_count":readiness["feature_count"],
        "implemented_count":readiness["implemented_count"],
        "local_case_sim_pass_count":readiness["local_case_sim_pass_count"],
        "features_with_all_declared_refs_present":readiness["features_with_all_declared_refs_present"],
        "closure_checks":checks,
        "realization_blocker_count":readiness["blocker_count"],
        "realization_blockers":readiness["blockers"][:100],
        "closure_evidence_present":closure_evidence is not None,
        "closure_evidence_blockers":closure_evidence_blockers,
        "official_test_scope_status":manifest.get("official_test_scope_status"),
        "official_test_roster_files":len(manifest.get("official_test_roster",[])),
        "formal_test_policy":manifest.get("formal_test_policy"),
        "manifest_ref":manifest_ref,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P2 B1-B8 feature batch phase gate")
    parser.add_argument("--root", default=str(ROOT), help="existing P2 checkout root")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("status", help="inspect the current batch without changing state")
    mark = sub.add_parser("mark-implemented", help="mark one feature implemented after all declared code/tests exist")
    mark.add_argument("--feature-id", required=True)
    sim = sub.add_parser("run-local-sim", help="run the three declared unittest methods for one implemented feature")
    sim.add_argument("--feature-id", required=True)
    sim.add_argument("--timeout", type=int, default=180)
    prep = sub.add_parser("prepare-official-roster", help="build the exact test roster after CLOSURE only")
    phase = sub.add_parser("advance-phase", help="advance only when the preceding batch gate passes")
    phase.add_argument("--to", choices=["CLOSURE","FINAL_TEST"], required=True)
    args = parser.parse_args()
    root = Path(args.root).resolve()
    try:
        if args.command == "status":
            result = inspect_batch(root)
        elif args.command == "mark-implemented":
            result = mark_feature_implemented(root,args.feature_id)
        elif args.command == "run-local-sim":
            result = run_local_case_sim(root,args.feature_id,args.timeout)
        elif args.command == "prepare-official-roster":
            result = prepare_official_test_roster(root)
        else:
            result = advance_phase(root,args.to)
        print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True))
        return 0
    except BatchGateError as exc:
        print(json.dumps({"status":"BLOCKED","reason_code":exc.code,"detail":exc.detail},ensure_ascii=False,indent=2,sort_keys=True))
        return 2
    except Exception as exc:
        print(json.dumps({"status":"FAIL_UNCLASSIFIED","reason_code":type(exc).__name__,"detail":str(exc)[:1000]},ensure_ascii=False,indent=2,sort_keys=True))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
