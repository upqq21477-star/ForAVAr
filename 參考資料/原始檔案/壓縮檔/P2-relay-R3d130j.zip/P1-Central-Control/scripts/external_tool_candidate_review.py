#!/usr/bin/env python3
"""Enrich top External Tool Radar candidates with objective repository metadata."""

from __future__ import annotations
import argparse
import datetime as dt
import json
import os
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[2]
RADAR_SCHEMA=ROOT/"P1-Central-Control/schemas/external_tool_radar_result.schema.json"
SCHEMA=ROOT/"P1-Central-Control/schemas/external_tool_candidate_review.schema.json"
API_DEFAULT="https://api.github.com"

def load(path: Path)->dict[str,Any]:
    value=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value,dict):
        raise ValueError(f"{path} must be an object")
    return value

def parse_time(value: str)->dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z","+00:00"))

def get_json(api_url:str,path:str,token:str|None)->dict[str,Any]:
    url=api_url.rstrip("/")+path
    headers={"Accept":"application/vnd.github+json","X-GitHub-Api-Version":"2026-03-10","User-Agent":"P1-External-Tool-Candidate-Review/1.0"}
    if token:
        headers["Authorization"]=f"Bearer {token}"
    request=urllib.request.Request(url,headers=headers,method="GET")
    try:
        with urllib.request.urlopen(request,timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as exc:
        if exc.code==404:
            return {}
        raise RuntimeError(f"GITHUB_METADATA_FAILED:{exc.code}") from exc

def enrich(candidate:dict[str,Any],api_url:str,token:str|None)->dict[str,Any]:
    repository=candidate["repository"]
    metadata=get_json(api_url,"/repos/"+urllib.parse.quote(repository,safe="/"),token)
    release=get_json(api_url,"/repos/"+urllib.parse.quote(repository,safe="/")+"/releases/latest",token)
    reasons=[]
    archived=bool(metadata.get("archived",candidate.get("archived",False)))
    license_obj=metadata.get("license") or {}
    license_id=license_obj.get("spdx_id") if isinstance(license_obj,dict) else None
    default_branch=metadata.get("default_branch")
    if not default_branch:
        reasons.append("DEFAULT_BRANCH_MISSING")
    if not metadata.get("description"):
        reasons.append("DESCRIPTION_MISSING")
    if archived:
        reasons.append("REPOSITORY_ARCHIVED")
    release_tag=release.get("tag_name") if release else None
    release_created=release.get("created_at") if release else None
    release_published=release.get("published_at") if release else None
    if not license_id:
        reasons.append("LICENSE_UNDECLARED")
    if not release_tag:
        reasons.append("LATEST_RELEASE_UNAVAILABLE")
    status="BLOCKED" if archived else ("REVIEW_READY" if default_branch else "INSUFFICIENT_METADATA")
    return {
        "repository":repository,
        "url":candidate["url"],
        "radar_classification":candidate["classification"],
        "stars":candidate["stars"],
        "forks":candidate["forks"],
        "archived":archived,
        "default_branch":default_branch or "",
        "license_spdx_id":license_id,
        "latest_release_tag":release_tag,
        "latest_release_created_at":release_created,
        "latest_release_published_at":release_published,
        "review_status":status,
        "review_reasons":sorted(set(reasons)),
        "matched_scopes":candidate.get("matched_scopes",[]),
    }

def review(radar:dict[str,Any],api_url:str,token:str|None,max_candidates:int)->dict[str,Any]:
    Draft202012Validator(json.loads(RADAR_SCHEMA.read_text(encoding="utf-8"))).validate(radar)
    selected=[x for x in radar["candidates"] if x["classification"] in {"ADOPT_CANDIDATE","WATCH"}][:max_candidates]
    candidates=[enrich(x,api_url,token) for x in selected]
    return {
        "schema_version":"1.0",
        "run_id":"REVIEW-"+radar["observed_date"].replace("-",""),
        "observed_date":radar["observed_date"],
        "source":"GITHUB_REPOSITORY_METADATA",
        "input_run_id":radar["run_id"],
        "summary":{
            "input_count":len(radar["candidates"]),
            "reviewed_count":len(candidates),
            "review_ready_count":sum(x["review_status"]=="REVIEW_READY" for x in candidates),
            "blocked_count":sum(x["review_status"]=="BLOCKED" for x in candidates),
        },
        "candidates":candidates,
    }

def main()->int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--input",required=True)
    parser.add_argument("--output",required=True)
    parser.add_argument("--api-url",default=os.environ.get("GITHUB_API_URL",API_DEFAULT))
    parser.add_argument("--max-candidates",type=int,default=10)
    args=parser.parse_args()
    radar=load(Path(args.input))
    result=review(radar,args.api_url,os.environ.get("GITHUB_TOKEN"),args.max_candidates)
    Draft202012Validator(json.loads(SCHEMA.read_text(encoding="utf-8"))).validate(result)
    out=Path(args.output)
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result["summary"],ensure_ascii=False))
    return 0

if __name__=="__main__":
    raise SystemExit(main())
