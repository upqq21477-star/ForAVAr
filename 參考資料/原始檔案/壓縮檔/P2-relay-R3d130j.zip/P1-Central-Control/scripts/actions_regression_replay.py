#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

import github_actions_result_adapter as adapter

ROOT = Path(__file__).resolve().parents[2]
REGISTRY = ROOT / "P1-Central-Control/regression_selection_registry.json"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(
        description="P1 replay GitHub Actions observation through M9 -> M7 -> M13"
    )
    parser.add_argument("selection")
    parser.add_argument("observation")
    parser.add_argument("--output", required=True)
    parser.add_argument("--acceptance-output", required=True)
    parser.add_argument(
        "--expected-head-sha",
        help="只用於驗證 observation；不會覆蓋本機 local acceptance 的 Git HEAD",
    )
    parser.add_argument(
        "--local-head-sha",
        help="可選：明確指定本機 repository 內存在的 Git ref/SHA",
    )
    parser.add_argument("--base")
    parser.add_argument("--skip-unit-tests", action="store_true")
    parser.add_argument("--external-output")
    args = parser.parse_args()

    selection = load_json(Path(args.selection))
    observation = load_json(Path(args.observation))
    registry_doc = load_json(REGISTRY)
    registry = {
        item["regression_set_id"]: item
        for item in registry_doc.get("sets", [])
        if isinstance(item, dict) and item.get("regression_set_id")
    }

    expected_head_sha = args.expected_head_sha or observation["workflow_run"]["head_sha"]
    external_result = adapter.build_external_result(
        selection,
        observation,
        registry,
        expected_head_sha=expected_head_sha,
    )

    if args.external_output:
        Path(args.external_output).write_text(
            json.dumps(external_result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

    with tempfile.TemporaryDirectory(prefix="p1-actions-replay-") as temp:
        external_path = Path(temp) / "external-regression-result.json"
        external_path.write_text(
            json.dumps(external_result, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )

        command = [
            sys.executable,
            "P1-Central-Control/scripts/local_acceptance.py",
            "--output",
            args.output,
            "--acceptance-output",
            args.acceptance_output,
            "--external-result",
            str(external_path),
        ]
        if args.base:
            command.extend(["--base", args.base])
        if args.local_head_sha:
            command.extend(["--head", args.local_head_sha])
        if args.skip_unit_tests:
            command.append("--skip-unit-tests")

        return subprocess.run(command, cwd=ROOT, check=False).returncode


if __name__ == "__main__":
    raise SystemExit(main())
