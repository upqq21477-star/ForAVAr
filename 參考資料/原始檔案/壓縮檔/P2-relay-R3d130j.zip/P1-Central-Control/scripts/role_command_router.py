#!/usr/bin/env python3
"""Resolve !施工 / !驗收 / !討論 / !指導 into a locked role session manifest.

R4R-S4 (FR-10): resolve_and_record() also logs each routing attempt as a hash-only DIALOGUE_TURN (role COMMAND) in the
Event Log; the route outcome is the ref.  Dialogue loop entry: scripts/dialogue_loop.py --simulate-dialogue.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SHORTCUTS = ROOT / "P1-Central-Control/canonical/command_shortcuts.json"
ROLES = ROOT / "P1-Central-Control/canonical/role_contract_registry.json"
ROLE_SCHEMA = ROOT / "P1-Central-Control/schemas/role_contract.schema.json"
PROFILE_SCHEMA = ROOT / "P1-Central-Control/schemas/instruction_profile.schema.json"
PROFILE_DIR = ROOT / "P1-Central-Control/canonical/instruction_profiles"


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def validate(value: dict[str, Any], schema_path: Path) -> None:
    errors = sorted(
        Draft202012Validator(load(schema_path)).iter_errors(value),
        key=lambda e: list(e.path),
    )
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def normalize_command(command: str) -> str:
    """Single mapping point: a leading ASCII '!' is the same command as full-width '！' (router layer only)."""
    return "\uff01" + command[1:] if command.startswith("!") else command


def resolve(command: str) -> dict[str, Any]:
    command = normalize_command(command)
    shortcuts = load(SHORTCUTS)["shortcuts"]
    routes = [x for x in shortcuts if x.get("shortcut") == command]
    if len(routes) != 1 or routes[0].get("command") != "role.activate":
        raise ValueError(f"UNKNOWN_ROLE_COMMAND:{command}")
    route = routes[0]

    roles = load(ROLES)["roles"]
    matches = [x for x in roles if x["role_id"] == route["role_id"]]
    if len(matches) != 1:
        raise ValueError(f"ROLE_ROUTE_MISMATCH:{route['role_id']}")
    role = matches[0]
    validate(role, ROLE_SCHEMA)

    if route["profile_id"] not in role["instruction_profile_ids"]:
        raise ValueError("PROFILE_NOT_BOUND_TO_ROLE")

    profile_path = PROFILE_DIR / f"{route['profile_id'][3:].lower()}.json"
    if not profile_path.is_file():
        raise FileNotFoundError(f"PROFILE_MISSING:{route['profile_id']}")
    profile = load(profile_path)
    validate(profile, PROFILE_SCHEMA)
    if profile["profile_id"] != route["profile_id"]:
        raise ValueError("PROFILE_ID_MISMATCH")
    if profile["status"] != "ACTIVE":
        raise ValueError("PROFILE_NOT_ACTIVE")

    priorities = sorted(
        profile["semantic_priorities"],
        key=lambda item: (-item["weight"], item["tag"]),
    )
    prompt_lines = [
        "【P1 身份啟動】",
        f"身份：{role['role_id']}",
        f"模式：{route['mode']}",
        "狀態：LOCKED",
        "身份鎖定：本 Session 不得切換身份；切換必須建立新 Session 並重新使用啟動指令。",
        "",
        "【核心任務】",
        role["primary_objective"],
        "",
        "【優先行為】",
    ]
    prompt_lines.extend(f"- {x['directive']}" for x in priorities)
    prompt_lines.extend(["", "【硬限制】"])
    prompt_lines.extend(f"- {x['directive']}" for x in profile["hard_boundaries"])
    if profile.get("built_in_commands"):
        prompt_lines.extend(["", "【內建操作路徑】"])
        prompt_lines.extend(f"- {x}" for x in profile["built_in_commands"])

    return {
        "status": "PASS",
        "activation_command": command,
        "role_id": route["role_id"],
        "profile_id": route["profile_id"],
        "mode": route["mode"],
        "lock_policy": role["lock_policy"],
        "session_state": "LOCKED",
        "context_mode": role["context_mode"],
        "amnesia_required": role["amnesia_required"],
        "allowed_operations": role["allowed_operations"],
        "denied_operations": role["denied_operations"],
        "allowed_write_targets": role["allowed_write_targets"],
        "denied_write_targets": role["denied_write_targets"],
        "compiled_prompt": "\n".join(prompt_lines),
        "operational_defaults": profile.get("operational_defaults", {}),
    }


def resolve_and_record(
    command: str,
    *,
    event_log_path: str | Path,
    workflow_id: str,
    conversation_id: str,
    occurred_at: str,
) -> dict[str, Any]:
    """Route a command and record the attempt as DIALOGUE_TURN(role=COMMAND).  The record is written BEFORE a failure is
    re-raised, so blocked routes leave a trace too.  Only the normalized command's hash and the route ref are stored."""
    import sys

    sys.path.insert(0, str(Path(__file__).resolve().parent))
    import event_log as el

    normalized = normalize_command(command)
    log = el.EventLog(event_log_path)
    try:
        result = resolve(command)
    except (ValueError, FileNotFoundError) as exc:
        # a registered shortcut that is not a role command (e.g. conversation.record.create) has no executor here:
        # say so instead of calling it unknown
        other = [x.get("command") for x in load(SHORTCUTS)["shortcuts"] if x.get("shortcut") == normalized]
        ref = f"ROUTE_UNHANDLED:{other[0]}" if other and other[0] != "role.activate" else \
            f"ROLE_ROUTE_BLOCKED:{str(exc).split(':', 1)[0]}"
        el.record_dialogue_turn(log, workflow_id=workflow_id, conversation_id=conversation_id, role="COMMAND",
                                content=normalized, ref=ref, occurred_at=occurred_at)
        raise
    el.record_dialogue_turn(log, workflow_id=workflow_id, conversation_id=conversation_id, role="COMMAND",
                            content=normalized, ref=f"ROLE_ROUTE:{result['role_id']}/{result['profile_id']}",
                            occurred_at=occurred_at)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command")
    parser.add_argument("--event-log", default=None, help="also record the routing attempt as DIALOGUE_TURN here")
    parser.add_argument("--workflow", default=None, help="work id (aggregate) for --event-log")
    parser.add_argument("--conversation", default=None, help="conversation id for --event-log")
    args = parser.parse_args()
    try:
        if args.event_log:
            if not (args.workflow and args.conversation):
                raise ValueError("EVENT_LOG_NEEDS_WORKFLOW_AND_CONVERSATION")
            from datetime import datetime, timezone

            result = resolve_and_record(args.command, event_log_path=args.event_log, workflow_id=args.workflow,
                                        conversation_id=args.conversation,
                                        occurred_at=datetime.now(timezone.utc).isoformat(timespec="seconds"))
        else:
            result = resolve(args.command)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except Exception as exc:
        print(json.dumps({"status": "BLOCK", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
