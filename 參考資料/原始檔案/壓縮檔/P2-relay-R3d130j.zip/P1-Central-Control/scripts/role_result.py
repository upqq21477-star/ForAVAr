#!/usr/bin/env python3
"""D4 映射點：角色 result_status → ResultPacket（只查 policy/role_result_mapping.v1.0.json）。

Verifier 的 PASS/FAIL 是判決：另產生 VerifierVerdict 紀錄（以 result_id 指向 ResultPacket；
不放進 output_refs，因 Provenance guard 要求覆蓋全部 output_refs），
FAIL 映射為 NEEDS_BRAIN 而非 FAIL，故 scheduler retry 永遠看不到 Verifier 判決。
本模組不持有狀態、不做路由。
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

from packet_layer import build_result_packet
from task_set import assert_role_capability

ROOT = Path(__file__).resolve().parents[2]
MAPPING_PATH = ROOT / "P1-Central-Control" / "policy" / "role_result_mapping.v1.0.json"


def _validate(filename: str, value: dict[str, Any]) -> None:
    schema = json.loads((ROOT / "P1-Central-Control" / "schemas" / filename).read_text(encoding="utf-8"))
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        raise ValueError(f"{filename} 驗證失敗: " + "; ".join(e.message for e in errors))


def load_mapping() -> dict[str, Any]:
    return json.loads(MAPPING_PATH.read_text(encoding="utf-8"))


def validate_role_result(role_result: dict[str, Any]) -> None:
    _validate("role_result.schema.json", role_result)


def validate_verdict(verdict: dict[str, Any]) -> None:
    _validate("verifier_verdict.schema.json", verdict)


def decision_for(role_id: str, result_status: str) -> str:
    decision = load_mapping()["mapping"].get(role_id, {}).get(result_status)
    if decision is None:
        raise ValueError(f"ROLE_RESULT_STATUS_NOT_ALLOWED:{role_id}:{result_status}")
    return decision


def to_result_packet(
    task_packet: dict[str, Any], role_result: dict[str, Any]
) -> tuple[dict[str, Any], dict[str, Any] | None]:
    """回傳 (ResultPacket, VerifierVerdict | None)；身分欄位一律取自 task_packet。"""
    validate_role_result(role_result)
    role_id = role_result["role_id"]
    assert_role_capability(role_id, role_result["capability_id"])  # U-8 執行期（結果入口）
    status = role_result["result_status"]
    decision = decision_for(role_id, status)

    verdict = None
    if status in load_mapping()["verdict_statuses"].get(role_id, []):
        token = re.sub(r"[^A-Za-z0-9._-]+", "_", role_result["result_id"]).strip("_")
        verdict = {
            "verdict_id": f"VERDICT:{token}",
            "workflow_id": task_packet["workflow_id"],
            "segment_id": task_packet["segment_id"],
            "attempt_id": task_packet["attempt_id"],
            "result_id": role_result["result_id"],
            "verdict": status,
            "reason_code": role_result["reason_code"],
            "acceptance_ref": role_result["acceptance_ref"],
            "head_sha": role_result["head_sha"],
            "decision_code": decision,
        }
        validate_verdict(verdict)

    unresolved = list(role_result["unresolved"])
    code = role_result["reason_code"]
    if decision != "WORK_COMPLETE" and code and code not in unresolved:
        unresolved.append(code)

    packet = build_result_packet(
        task_packet,
        {
            "decision_code": decision,
            "output_refs": list(role_result["output_refs"]),
            "unresolved": unresolved,
            "evidence_refs": role_result["evidence_refs"],
            "provenance_refs": role_result["provenance_refs"],
            "observed_usage": role_result["observed_usage"],
            "usage_observed": role_result["usage_observed"],
        },
        result_id=role_result["result_id"],
    )
    return packet, verdict
