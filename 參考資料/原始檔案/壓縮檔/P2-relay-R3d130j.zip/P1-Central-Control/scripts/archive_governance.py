#!/usr/bin/env python3
"""CS-1 B4：Archive scope、存取協定、蒸餾與處置（G1／H2／H3／K12；Master §12、§17–18、§26–27、§32、§34–36；03）。

stdlib only、決定性（不讀時鐘，時間由呼叫端傳入）。Archive 實體在 repo 外（D-A）；repo 內只有
`canonical/archive_manifest.json`（索引＋hash＋purpose）。政策表 `policy/archive_scope.v1.0.json`。
機器只做可確定的事：scope／purpose 檢查、capability＋scope＋resource 授權、蒸餾與 Blueprint 引用是否齊備、hash 與鏈、
TTL 算術；「資料該 KEEP／ARCHIVE／DISPOSE、蒸餾內容是否正確」屬語義判斷，由 CONTROL_RESEARCH 附 by＋rationale，可被推翻。
Archive 取回結果一律是 UNTRUSTED_CANDIDATE 資料（非指令、非 Truth）；要進知識只能經 `result_as_source`→B1 Intake→B2 升格鏈。
錯誤皆為 ValueError("<REASON_CODE>[:detail]")。
"""

from __future__ import annotations

import json
import os
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Any, Callable, Iterable

from event_log import canonical_json, content_hash
from knowledge_intake import _sha, validate
from task_set import assert_role_capability

ROOT = Path(__file__).resolve().parents[2]
POLICY_PATH = ROOT / "P1-Central-Control" / "policy" / "archive_scope.v1.0.json"
MANIFEST_PATH = ROOT / "P1-Central-Control" / "canonical" / "archive_manifest.json"
INDEX_NAME = "ARCHIVE-INDEX.json"


def policy() -> dict[str, Any]:
    return json.loads(POLICY_PATH.read_text(encoding="utf-8"))


def _fail(code: str, detail: str = "") -> None:
    raise ValueError(f"{code}:{detail}" if detail else code)


def _blank(*vals: Any) -> bool:
    return any(not isinstance(v, str) or not v.strip() for v in vals)


def _t(value: str) -> datetime:
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError(f"時間須含時區: {value}")
    return dt


def _seal(record: dict[str, Any], schema: str) -> dict[str, Any]:
    record.pop("content_hash", None)
    record["content_hash"] = content_hash(record)
    validate(schema, record)
    return record


# ---- Scope（K12）：正常只讀 ACTIVE＋WARM；COLD 須 reason；ARCHIVE 須 purpose 且只走協定；ALL 一律禁止 ----

def check_scope(scope: str, *, purpose: str | None = None, reason: str | None = None) -> str:
    p = policy()
    if not isinstance(scope, str) or not scope.strip():
        _fail("SCOPE_REQUIRED")
    if scope.upper() in p["forbidden_scopes"]:
        _fail("SCOPE_ALL_FORBIDDEN")
    if scope not in p["scopes"]:
        _fail("SCOPE_UNKNOWN", scope)
    if scope == "EXTERNAL":
        _fail("EXTERNAL_NOT_SERVED")
    if scope == "COLD" and _blank(reason):
        _fail("COLD_REASON_REQUIRED")
    if scope == "ARCHIVE":
        if not purpose:
            _fail("ARCHIVE_PURPOSE_REQUIRED")
        if purpose not in p["purposes"]:
            _fail("PURPOSE_UNKNOWN", purpose)
    return scope


def scoped_search(items: Iterable[dict[str, Any]], match: Callable[[dict[str, Any]], bool],
                  scope: str | Iterable[str] = ("ACTIVE", "WARM"), *, reason: str | None = None) -> list[dict[str, Any]]:
    """一般搜尋（Layer 5）。ARCHIVE 永遠不可由此回傳；未標 scope 的項目 fail closed（不回傳）。"""
    scopes = [scope] if isinstance(scope, str) else list(scope)
    for s in scopes:
        if s == "ARCHIVE":
            _fail("ARCHIVE_VIA_PROTOCOL_ONLY")
        check_scope(s, reason=reason)
    return [i for i in items if i.get("scope") in scopes and match(i)]


# ---- 處置判斷（Active Gate：沒有這份資料，下次重建是否仍能正確建立？）----

def decide(asset_class: str, *, reconstruction_required: bool, impact: str, disposition: str, by: str, rationale: str,
           distilled: str | None = None, blueprint_ref: str | None = None) -> dict[str, Any]:
    p = policy()
    classes = p["asset_classes"]
    if _blank(by, rationale):
        _fail("ADJUDICATION_REQUIRED")
    if asset_class not in classes["temporary_default"] + classes["other"]:
        _fail("ASSET_CLASS_UNKNOWN", asset_class)
    if disposition not in p["dispositions"] or impact not in ("NONE", "SYSTEM"):
        _fail("DISPOSITION_INVALID")
    if reconstruction_required and disposition != "KEEP":
        _fail("RECONSTRUCTION_INPUT_MUST_BE_KEPT")
    if disposition == "KEEP":
        if not reconstruction_required:
            _fail("KEEP_REQUIRES_RECONSTRUCTION_NEED")
        if asset_class in classes["temporary_default"]:
            _fail("TEMPORARY_CLASS_NOT_KEEPABLE")
    elif impact == "SYSTEM" and _blank(blueprint_ref):
        _fail("BLUEPRINT_REF_REQUIRED")
    if disposition == "ARCHIVE" and _blank(distilled):
        _fail("DISTILLED_REQUIRED")
    out = {"asset_class": asset_class, "disposition": disposition, "impact": impact, "by": by, "rationale": rationale}
    return {**out, **{k: v for k, v in (("distilled", distilled), ("blueprint_ref", blueprint_ref)) if v}}


# ---- Manifest ----

def make_record(data: bytes, decision: dict[str, Any], *, archive_ref: str, origin_path: str, allowed_purposes: list[str],
                reason: str, archived_at: str, review_after: str) -> dict[str, Any]:
    if decision.get("disposition") != "ARCHIVE":
        _fail("NOT_ARCHIVE_DISPOSITION")
    if _blank(archive_ref, origin_path, reason):
        _fail("RECORD_FIELD_BLANK")
    if _t(review_after) <= _t(archived_at):
        _fail("REVIEW_AFTER_NOT_LATER")
    asset_hash = _sha(data)
    slug = content_hash({"o": origin_path, "h": asset_hash})[7:23]
    rec: dict[str, Any] = {
        "object_id": f"ARCHIVE_RECORD:{slug}", "kind": "ARCHIVE_RECORD", "schema_version": "1.0",
        "archive_ref": archive_ref, "member_path": origin_path, "origin_path": origin_path,
        "asset_class": decision["asset_class"], "asset_hash": asset_hash, "byte_size": len(data), "scope": "ARCHIVE",
        "impact": decision["impact"], "allowed_purposes": sorted(set(allowed_purposes)), "distilled": decision["distilled"],
        "reason": reason, "archived_at": archived_at, "archived_by": decision["by"], "lifecycle": "RETAIN",
        "review_after": review_after, "lifecycle_log": [],
    }
    if decision.get("blueprint_ref"):
        rec["blueprint_ref"] = decision["blueprint_ref"]
    if not set(rec["allowed_purposes"]) <= set(policy()["purposes"]):
        _fail("PURPOSE_UNKNOWN")
    return _seal(rec, "archive_record")


class ArchiveManifest:
    def __init__(self, records: list[dict[str, Any]] | None = None) -> None:
        self.records: dict[str, dict[str, Any]] = {}
        for r in records or []:
            self.add(r)

    @classmethod
    def load(cls, path: Path = MANIFEST_PATH) -> "ArchiveManifest":
        return cls(json.loads(Path(path).read_text(encoding="utf-8"))["records"])

    def save(self, path: Path = MANIFEST_PATH) -> None:
        body = {"version": "1.0", "location_policy": "Archive 實體放 repo 外（D-A）；此檔只存索引＋hash＋purpose",
                "records": [self.records[k] for k in sorted(self.records)]}
        target = Path(path)
        target.parent.mkdir(parents=True, exist_ok=True)
        temporary = target.with_name(target.name + ".tmp")
        payload = (json.dumps(body, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
        try:
            with temporary.open("wb") as fh:
                fh.write(payload)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(temporary, target)
        except OSError:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
            raise

    def add(self, record: dict[str, Any]) -> None:
        validate("archive_record", record)
        if record["content_hash"] != content_hash({k: v for k, v in record.items() if k != "content_hash"}):
            _fail("RECORD_HASH_MISMATCH", record["object_id"])
        if record["object_id"] in self.records:
            _fail("RECORD_DUPLICATE", record["object_id"])
        self.records[record["object_id"]] = record

    def set_lifecycle(self, ref: str, to: str, *, by: str, rationale: str, at: str, review_after: str | None = None) -> dict[str, Any]:
        rec = self.records.get(ref)
        if rec is None:
            _fail("RECORD_UNKNOWN", ref)
        if _blank(by, rationale):
            _fail("ADJUDICATION_REQUIRED")
        if to not in policy()["archive_lifecycle"][rec["lifecycle"]]:
            _fail("LIFECYCLE_TRANSITION_INVALID", f"{rec['lifecycle']}->{to}")
        if to == "RETAIN" and (not review_after or _t(review_after) <= _t(at)):
            _fail("REVIEW_AFTER_REQUIRED_LATER")
        new = {**rec, "lifecycle": to, "review_after": review_after or rec["review_after"],
               "lifecycle_log": [*rec["lifecycle_log"], {"from": rec["lifecycle"], "to": to, "by": by, "rationale": rationale, "at": at}]}
        self.records[ref] = _seal(new, "archive_record")
        return self.records[ref]

    def mark_due(self, now: str) -> list[str]:
        """TTL 算術：RETAIN 且 review_after 已到 → REVIEW（by MACHINE:TTL）。是否保留／壓縮／刪除由 CONTROL_RESEARCH 裁決。"""
        due = sorted(r for r, rec in self.records.items() if rec["lifecycle"] == "RETAIN" and _t(rec["review_after"]) <= _t(now))
        for ref in due:
            self.set_lifecycle(ref, "REVIEW", by="MACHINE:TTL", rationale="review_after 已到", at=now)
        return due

    def verify(self) -> list[str]:
        errs = []
        for ref, r in self.records.items():
            if r["content_hash"] != content_hash({k: v for k, v in r.items() if k != "content_hash"}):
                errs.append(f"RECORD_HASH_MISMATCH:{ref}")
            if r["impact"] == "SYSTEM" and not r.get("blueprint_ref"):
                errs.append(f"BLUEPRINT_REF_MISSING:{ref}")
            if r["lifecycle_log"] and r["lifecycle_log"][-1]["to"] != r["lifecycle"]:
                errs.append(f"LIFECYCLE_LOG_MISMATCH:{ref}")
            if r["lifecycle"] == "DELETE" and not r["lifecycle_log"]:
                errs.append(f"DELETE_WITHOUT_ADJUDICATION:{ref}")
        return errs


# ---- 實體 bundle（repo 外；決定性 zip＋索引）----

def archive_assets(root: Path, plans: list[dict[str, Any]], out_zip: Path, *, archive_ref: str, now: str) -> list[dict[str, Any]]:
    """plan＝{path, decision(decide 的輸出，須 ARCHIVE), reason, allowed_purposes, review_after}。只複製、不刪 repo 檔
    （刪除走 lifecycle_sweep／CAP-RETIRE）。"""
    root = Path(root).resolve()
    records, members = [], {}
    for plan in sorted(plans, key=lambda x: x["path"]):
        src = (root / plan["path"]).resolve()
        if root not in src.parents or not src.is_file():
            _fail("PATH_OUTSIDE_ROOT_OR_MISSING", plan["path"])
        data = src.read_bytes()
        records.append(make_record(data, plan["decision"], archive_ref=archive_ref, origin_path=plan["path"],
                                   allowed_purposes=plan["allowed_purposes"], reason=plan["reason"], archived_at=now,
                                   review_after=plan["review_after"]))
        members[plan["path"]] = data
    members[INDEX_NAME] = canonical_json({"archive_ref": archive_ref, "records": records})
    with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
        for name in sorted(members):
            z.writestr(zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0)), members[name])
    return records


def verify_bundle(zip_path: Path, records: Iterable[dict[str, Any]], archive_ref: str) -> list[str]:
    errs = []
    with zipfile.ZipFile(zip_path) as z:
        names = set(z.namelist())
        for r in records:
            if r["archive_ref"] != archive_ref:
                continue
            if r["member_path"] not in names:
                errs.append(f"MEMBER_MISSING:{r['object_id']}")
            elif _sha(z.read(r["member_path"])) != r["asset_hash"]:
                errs.append(f"MEMBER_HASH_MISMATCH:{r['object_id']}")
    return errs


# ---- 存取紀錄（含拒絕；append-only＋prev_hash 鏈）----

class AccessLog:
    def __init__(self, path: Path | None = None) -> None:
        self.path = Path(path) if path else None
        self.entries: list[dict[str, Any]] = []
        if self.path and self.path.exists():
            self.entries = [json.loads(x) for x in self.path.read_text(encoding="utf-8").splitlines()]
            if err := self.verify():
                _fail("ACCESS_LOG_BROKEN", err[0])

    def head(self) -> str | None:
        return self.entries[-1]["content_hash"] if self.entries else None

    def verify(self) -> list[str]:
        errs, prev = [], None
        for i, e in enumerate(self.entries, 1):
            if e["seq"] != i or e["prev_hash"] != prev:
                errs.append(f"CHAIN_BROKEN:{i}")
            if e["content_hash"] != content_hash({k: v for k, v in e.items() if k != "content_hash"}):
                errs.append(f"HASH_MISMATCH:{i}")
            prev = e["content_hash"]
        return errs

    def append(self, requester: dict[str, Any], purpose: str, scope: str, target: dict[str, Any], decision: str,
               reason_code: str | None, returned: list[str], at: str) -> dict[str, Any]:
        n = len(self.entries) + 1
        entry = {
            "object_id": f"ARCHIVE_ACCESS_RECORD:A{n:05d}", "kind": "ARCHIVE_ACCESS_RECORD", "schema_version": "1.0", "seq": n,
            "agent_id": str(requester.get("agent_id") or ""), "role": str(requester.get("role") or ""),
            "capability_id": str(requester.get("capability_id") or ""), "purpose": str(purpose or ""),
            "requested_scope": str(scope or ""), "target": target, "decision": decision, "reason_code": reason_code,
            "returned_refs": returned, "timestamp": at, "prev_hash": self.head(),
        }
        _seal(entry, "archive_access_record")
        if self.path:
            file_existed = self.path.exists()
            original_size = self.path.stat().st_size if file_existed else 0
            try:
                with self.path.open("ab") as fh:
                    fh.write(canonical_json(entry) + b"\n")
                    fh.flush()
                    os.fsync(fh.fileno())
            except OSError:
                try:
                    if file_existed and self.path.exists():
                        with self.path.open("r+b") as fh:
                            fh.truncate(original_size)
                            fh.flush()
                            os.fsync(fh.fileno())
                    elif not file_existed and self.path.exists():
                        self.path.unlink()
                except OSError as rollback_error:
                    _fail("ACCESS_LOG_APPEND_ROLLBACK_INCOMPLETE", type(rollback_error).__name__)
                raise
        # Memory advances only after durable persistence succeeds.
        self.entries.append(entry)
        return entry


# ---- 存取協定：REQUEST→PURPOSE→SCOPE→AUTHORIZE→TARGET→最小取回→EVIDENCE→蒸餾結果→紀錄→CLOSE ----

TARGET_KEYS = ("object_id", "origin_path", "asset_class")  # 只允許精確比對；空 target＝SEARCH_ALL，拒絕


class ArchiveAccess:
    def __init__(self, manifest: ArchiveManifest, log: AccessLog) -> None:
        self.manifest, self.log = manifest, log

    def retrieve(self, requester: dict[str, Any], purpose: str, requested_scope: str, target: dict[str, Any], *,
                 now: str, max_records: int | None = None) -> dict[str, Any]:
        try:
            result = self._run(requester, purpose, requested_scope, target, max_records)
        except ValueError as exc:
            self.log.append(requester, purpose, requested_scope, target, "DENIED", str(exc), [], now)
            raise
        entry = self.log.append(requester, purpose, requested_scope, target, "GRANTED", None, result["source_refs"], now)
        return {**result, "access_record": entry["object_id"]}

    def _run(self, requester: dict[str, Any], purpose: str, scope: str, target: dict[str, Any], max_records: int | None) -> dict[str, Any]:
        p = policy()
        check_scope(scope, purpose=purpose)
        if scope != "ARCHIVE":
            _fail("NOT_ARCHIVE_SCOPE", scope)
        role, cap = requester.get("role") or "", requester.get("capability_id") or ""
        if _blank(requester.get("agent_id") or "", cap):
            _fail("AGENT_AND_CAPABILITY_REQUIRED")
        try:
            assert_role_capability(role, cap)
        except ValueError:
            _fail("CAPABILITY_NOT_BOUND", f"{role}:{cap}")
        if cap != p["archive_capability"]:
            _fail("CAPABILITY_NOT_ARCHIVE_QUERY", cap)
        if scope not in p["role_scope_grants"].get(role, []):
            _fail("SCOPE_NOT_GRANTED", f"{role}:{scope}")
        crit = {k: v for k, v in target.items() if k in TARGET_KEYS and isinstance(v, str) and v}
        if not crit or set(target) - set(TARGET_KEYS):
            _fail("TARGET_REQUIRED")
        cap_n = min(max_records or p["max_records_per_request"]["default"], p["max_records_per_request"]["hard"])
        hits = [r for r in self.manifest.records.values() if all(r[k] == v for k, v in crit.items())]
        hits = sorted((r for r in hits if r["lifecycle"] != "DELETE" and purpose in r["allowed_purposes"]), key=lambda r: r["object_id"])
        if not hits:
            _fail("NO_ELIGIBLE_RECORD")
        if len(hits) > cap_n:
            _fail("TARGET_TOO_BROAD", f"{len(hits)}>{cap_n}")
        return {
            "purpose": purpose, "requested_scope": scope, "truth_status": "UNTRUSTED_CANDIDATE", "instruction_content": False,
            "source_refs": [r["object_id"] for r in hits],
            "evidence_refs": [f"{r['archive_ref']}#{r['member_path']}@{r['asset_hash']}" for r in hits],
            "distilled_result": [{"ref": r["object_id"], "asset_class": r["asset_class"], "distilled": r["distilled"]} for r in hits],
        }


def result_as_source(result: dict[str, Any]) -> tuple[str, bytes]:
    """Archive→Evidence→Observation 的入口：把取回結果轉成可交給 knowledge_intake.build_source 的 (source_id, raw)。
    取回結果本身不是 Truth；之後須走 Ledger 讀取→Observation→promote。"""
    if result.get("truth_status") != "UNTRUSTED_CANDIDATE":
        _fail("NOT_AN_ARCHIVE_RESULT")
    body = "\n\n".join(f"{d['ref']}\n{d['distilled']}" for d in result["distilled_result"])
    return f"archive-{result['access_record'].split(':', 1)[1]}", body.encode("utf-8")


# ---- 量測定義（Q1；基準值於 B8）----

def retrieval_precision(returned: list[str], relevant: set[str]) -> float:
    return len([r for r in returned if r in relevant]) / len(returned) if returned else 1.0


def access_stats(log: AccessLog) -> dict[str, Any]:
    denied: dict[str, int] = {}
    for e in log.entries:
        if e["decision"] == "DENIED":
            code = e["reason_code"].split(":", 1)[0]
            denied[code] = denied.get(code, 0) + 1
    return {"granted": sum(e["decision"] == "GRANTED" for e in log.entries), "denied": denied}
