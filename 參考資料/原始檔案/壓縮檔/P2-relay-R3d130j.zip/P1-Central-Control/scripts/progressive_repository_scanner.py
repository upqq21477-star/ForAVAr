#!/usr/bin/env python3
"""Executable L0-L6 progressive repository scanner."""

from __future__ import annotations

import argparse
import ast
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

SCRIPT_ROOT = Path(__file__).resolve().parent
ROOT = SCRIPT_ROOT.parents[1]
REQUEST_SCHEMA = ROOT / "P1-Central-Control/schemas/progressive_repository_scanner.schema.json"
REVERSE_RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/reverse_reconstruction_result.schema.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/progressive_repository_scanner_result.schema.json"

sys.path.insert(0, str(SCRIPT_ROOT))
from context_sufficiency import execute as context_sufficiency
from reverse_context_selection import execute as select_context
from runtime_evidence_probe import execute as runtime_probe
from scenario_oracle import execute as run_oracle
from partial_system_state import execute as derive_partial_system_state
from reconstruction_artifact_lifecycle import execute as artifact_lifecycle

DEFAULT_EXCLUDES = {
    ".git", ".hg", ".svn", "__pycache__", ".pytest_cache",
    "node_modules", "vendor", "dist", "build", ".venv", "venv",
}
EXT_LANG = {
    ".py": "python", ".js": "javascript", ".ts": "typescript",
    ".tsx": "typescript", ".jsx": "javascript", ".go": "go",
    ".rs": "rust", ".java": "java", ".rb": "ruby", ".php": "php",
    ".c": "c", ".cc": "cpp", ".cpp": "cpp", ".h": "c", ".hpp": "cpp",
    ".cs": "csharp", ".sh": "shell", ".ps1": "powershell",
    ".json": "json", ".yaml": "yaml", ".yml": "yaml", ".toml": "toml",
    ".md": "markdown",
}
ENTRYPOINT_NAMES = {
    "main.py", "app.py", "server.py", "cli.py", "run.py",
    "index.js", "index.ts", "main.go", "main.rs", "Program.cs",
}
STUB_RE = re.compile(
    r"\b(?:TODO|FIXME|XXX|STUB|PLACEHOLDER|NOT_IMPLEMENTED|IMPLEMENT_ME)\b",
    re.IGNORECASE,
)


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any], schema_path: Path) -> None:
    schema = _load(schema_path)
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _language(path: Path) -> str:
    return EXT_LANG.get(path.suffix.lower(), "unknown")


def _kind(path: Path) -> str:
    if path.name.startswith("test_") or any(p.lower() in {"test", "tests", "__tests__"} for p in path.parts):
        return "TEST"
    if path.suffix.lower() in {".md", ".rst", ".txt"}:
        return "DOC"
    if path.suffix.lower() in {".json", ".yaml", ".yml", ".toml", ".ini", ".env"}:
        return "CONFIG"
    return "SOURCE" if _language(path) != "unknown" else "OTHER"


def _inventory(
    root: Path,
    excludes: set[str],
    max_files: int,
    max_bytes: int,
    *,
    focus_paths: list[str] | None = None,
    mode: str = "TARGETED",
) -> tuple[list[dict[str, Any]], int, bool, list[dict[str, Any]]]:
    """Inventory only explicit paths and their resolvable local imports by default.

    Full-tree enumeration is available only as an explicit bounded reconstruction mode.
    Unvisited paths are never inferred to be MISSING.
    """
    if mode == "BOUNDED_RECONSTRUCTION":
        return _inventory_bounded_reconstruction(root, excludes, max_files, max_bytes)
    if mode != "TARGETED":
        return [], 0, False, [{"code": "INVENTORY_MODE_INVALID", "mode": str(mode)}]
    if not isinstance(focus_paths, list) or not focus_paths:
        return [], 0, False, [{"code": "FOCUS_PATHS_REQUIRED_FOR_TARGETED_SCAN"}]

    base = root.resolve()
    rows: list[dict[str, Any]] = []
    consumed = 0
    complete = True
    issues: list[dict[str, Any]] = []
    queue: list[str] = []
    seen: set[str] = set()

    def enqueue(ref: str, reason: str) -> None:
        if ref not in seen and ref not in queue:
            queue.append(ref)

    def resolve_import(source_rel: str, target: str, level: int = 0) -> str | None:
        source = Path(source_rel)
        candidates: list[Path] = []
        if level > 0:
            parent = source.parent
            for _ in range(max(0, level - 1)):
                parent = parent.parent
            if target:
                module_path = Path(target.replace(".", "/"))
                candidates.extend([
                    parent / module_path.with_suffix(".py"),
                    parent / module_path / "__init__.py",
                ])
            else:
                candidates.append(parent / "__init__.py")
        else:
            dotted = target.replace(".", "/")
            candidates.extend([
                Path(dotted + ".py"),
                Path(dotted) / "__init__.py",
                source.parent / Path(dotted + ".py"),
                source.parent / Path(dotted) / "__init__.py",
            ])
        for candidate in candidates:
            if candidate.is_absolute() or ".." in candidate.parts:
                continue
            absolute = base / candidate
            cursor = base
            symlink = False
            for part in candidate.parts:
                cursor = cursor / part
                if cursor.is_symlink():
                    symlink = True
                    break
            if symlink:
                issues.append({
                    "code": "DEPENDENCY_SYMLINK_NOT_FOLLOWED",
                    "path": candidate.as_posix(),
                    "source": source_rel,
                })
                continue
            try:
                absolute.resolve().relative_to(base)
            except (OSError, ValueError):
                continue
            if absolute.is_file():
                return candidate.as_posix()
        return None

    for raw in focus_paths:
        if not isinstance(raw, str) or not raw.strip():
            complete = False
            issues.append({"code": "FOCUS_PATH_INVALID", "path": str(raw)})
            continue
        candidate = Path(raw.strip())
        if candidate.is_absolute() or ".." in candidate.parts or candidate == Path("."):
            complete = False
            issues.append({"code": "TARGET_PATH_FORBIDDEN", "path": str(raw)})
            continue
        if any(part in excludes for part in candidate.parts):
            complete = False
            issues.append({"code": "TARGET_PATH_EXCLUDED", "path": candidate.as_posix()})
            continue
        queue.append(candidate.as_posix())

    while queue:
        rel = queue.pop(0)
        if rel in seen:
            continue
        seen.add(rel)
        relative = Path(rel)
        if len(rows) >= max_files:
            complete = False
            issues.append({"code": "FILE_LIMIT_REACHED", "path": rel})
            break
        candidate = base / relative
        cursor = base
        symlink = False
        for part in relative.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                symlink = True
                break
        if symlink:
            complete = False
            issues.append({"code": "TARGET_SYMLINK_NOT_FOLLOWED", "path": rel})
            continue
        try:
            candidate.resolve().relative_to(base)
        except (OSError, ValueError):
            complete = False
            issues.append({"code": "TARGET_PATH_OUTSIDE_ROOT", "path": rel})
            continue
        if any(part in excludes for part in relative.parts):
            complete = False
            issues.append({"code": "TARGET_PATH_EXCLUDED", "path": rel})
            continue
        if not candidate.exists():
            complete = False
            issues.append({"code": "TARGET_PATH_NOT_FOUND", "path": rel, "scope": "exact-path-only"})
            continue
        if candidate.is_dir():
            complete = False
            issues.append({"code": "DIRECTORY_NOT_ENUMERATED", "path": rel})
            continue
        if not candidate.is_file():
            complete = False
            issues.append({"code": "TARGET_NOT_REGULAR_FILE", "path": rel})
            continue
        try:
            size = candidate.stat().st_size
        except OSError as exc:
            complete = False
            issues.append({"code": "FILE_STAT_ERROR", "path": rel, "detail": type(exc).__name__})
            continue
        if consumed + size > max_bytes:
            complete = False
            issues.append({
                "code": "BYTE_LIMIT_REACHED",
                "path": rel,
                "file_bytes": size,
                "remaining_bytes": max(0, max_bytes - consumed),
                "exists": True,
                "contents_read": False,
            })
            # Preserve explicit existence while stopping all further reads.
            break
        try:
            data = candidate.read_bytes()
        except OSError as exc:
            complete = False
            issues.append({"code": "FILE_READ_ERROR", "path": rel, "detail": type(exc).__name__})
            continue
        text_value = data.decode("utf-8", errors="replace")
        rows.append({
            "path": relative.as_posix(),
            "kind": _kind(candidate),
            "language": _language(candidate),
            "bytes": len(data),
            "lines": len(text_value.splitlines()),
            "sha256": _sha(data),
        })
        consumed += len(data)
        if _language(candidate) == "python":
            try:
                tree = ast.parse(text_value, filename=rel)
            except (SyntaxError, UnicodeError):
                # Structure phase will record the syntax error from the same declared file.
                continue
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for item in node.names:
                        local = resolve_import(rel, item.name)
                        if local:
                            enqueue(local, "python-import")
                elif isinstance(node, ast.ImportFrom):
                    local = resolve_import(rel, node.module or "", node.level)
                    if local:
                        enqueue(local, "python-from-import")

    if not rows and focus_paths:
        # Unavailable/forbidden scope is UNKNOWN/INCOMPLETE, not a claim that the
        # repository contains no implementation.
        complete = False
    return rows, consumed, complete, issues


def _inventory_bounded_reconstruction(root: Path, excludes: set[str], max_files: int, max_bytes: int) -> tuple[list[dict[str, Any]], int, bool, list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    consumed = 0
    complete = True
    issues: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if any(part in excludes for part in rel.parts):
            continue
        if len(rows) >= max_files:
            complete = False
            issues.append({"code": "FILE_LIMIT_REACHED", "path": rel.as_posix()})
            break
        try:
            data = path.read_bytes()
        except OSError as exc:
            complete = False
            issues.append({"code": "FILE_READ_ERROR", "path": rel.as_posix(), "detail": type(exc).__name__})
            continue
        if consumed + len(data) > max_bytes:
            complete = False
            issues.append({"code": "BYTE_LIMIT_REACHED", "path": rel.as_posix(), "file_bytes": len(data), "remaining_bytes": max(0, max_bytes - consumed)})
            break
        text = data.decode("utf-8", errors="replace")
        rows.append({
            "path": rel.as_posix(),
            "kind": _kind(path),
            "language": _language(path),
            "bytes": len(data),
            "lines": len(text.splitlines()),
            "sha256": _sha(data),
        })
        consumed += len(data)
    return rows, consumed, complete, issues


def _structure(root: Path, inventory: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[str], list[dict[str, str]], list[str], list[dict[str, str]]]:
    symbols: list[dict[str, Any]] = []
    modules: list[str] = []
    errors: list[dict[str, str]] = []
    stubs: list[str] = []
    imports: list[dict[str, str]] = []

    for row in inventory:
        if row["kind"] != "SOURCE":
            continue
        path = root / row["path"]
        text = path.read_text(encoding="utf-8", errors="replace")
        symbols.append({"path": row["path"], "kind": "MODULE", "name": row["path"]})
        modules.append(row["path"])
        stubs.extend(f"{row['path']}:marker:{m.group(0).upper()}" for m in STUB_RE.finditer(text))
        if row["language"] == "python":
            try:
                tree = ast.parse(text, filename=row["path"])
            except (OSError, SyntaxError, UnicodeError) as exc:
                errors.append({"path": row["path"], "error": str(exc)})
                continue
            for node in ast.walk(tree):
                if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    symbols.append({"path": row["path"], "kind": "FUNCTION", "name": node.name})
                elif isinstance(node, ast.ClassDef):
                    symbols.append({"path": row["path"], "kind": "CLASS", "name": node.name})
                elif isinstance(node, ast.Import):
                    for item in node.names:
                        imports.append({"source": row["path"], "target": item.name, "evidence": f"python-import:{item.name}"})
                elif isinstance(node, ast.ImportFrom) and node.module:
                    imports.append({"source": row["path"], "target": node.module, "evidence": f"python-from:{node.module}"})
        else:
            for match in re.finditer(
                r"^\s*(?:export\s+)?(?:async\s+)?(?:function|class|interface|struct|enum|type)\s+([A-Za-z_][A-Za-z0-9_]*)",
                text,
                re.MULTILINE,
            ):
                symbols.append({"path": row["path"], "kind": "GENERIC_DECLARATION", "name": match.group(1)})
    return symbols, modules, errors, sorted(set(stubs)), imports


def _resolve_local(root: Path, source_rel: str, target: str) -> str | None:
    source = Path(source_rel)
    candidates: list[Path] = []
    if target.startswith("."):
        candidates.append((source.parent / target).with_suffix(".py"))
    dotted = target.replace(".", "/")
    candidates.extend([
        Path(dotted + ".py"),
        Path(dotted) / "__init__.py",
        source.parent / Path(dotted + ".py"),
        source.parent / Path(dotted) / "__init__.py",
    ])
    for candidate in candidates:
        if (root / candidate).is_file():
            return candidate.as_posix()
    return None


def _dependencies(root: Path, imports: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[str]]:
    edges: list[dict[str, str]] = []
    unresolved: list[str] = []
    for dep in imports:
        target = _resolve_local(root, dep["source"], dep["target"])
        if target:
            edge = {"source": dep["source"], "target": target, "evidence": dep["evidence"]}
            if edge not in edges:
                edges.append(edge)
        elif dep["target"].startswith(".") or "." in dep["target"]:
            unresolved.append(f"{dep['source']} -> {dep['target']}")
    return sorted(edges, key=lambda x: (x["source"], x["target"])), sorted(set(unresolved))


def _entrypoints(inventory: list[dict[str, Any]], symbols: list[dict[str, Any]]) -> list[str]:
    candidates = {row["path"] for row in inventory if Path(row["path"]).name in ENTRYPOINT_NAMES}
    candidates.update(row["path"] for row in symbols if row["kind"] == "FUNCTION" and row["name"] == "main")
    return sorted(candidates)


def _state(inventory: list[dict[str, Any]], errors: list[dict[str, str]], stubs: list[str], unresolved: list[str], entrypoints: list[str]) -> dict[str, Any]:
    source_count = sum(x["kind"] == "SOURCE" for x in inventory)
    if not source_count:
        classification = "UNKNOWN"
    elif errors:
        classification = "BROKEN"
    elif stubs:
        classification = "STUB"
    elif unresolved or not entrypoints:
        classification = "PARTIAL"
    else:
        classification = "IMPLEMENTED"
    next_point = (
        errors[0]["path"] if errors else
        stubs[0].split(":marker:", 1)[0] if stubs else
        unresolved[0] if unresolved else
        None
    )
    return {
        "classification": classification,
        "implemented": classification == "IMPLEMENTED",
        "partial": classification in {"PARTIAL", "BROKEN", "STUB"},
        "stub": bool(stubs),
        "broken": bool(errors),
        "unknown": classification == "UNKNOWN",
        "next_diagnostic_point": next_point,
    }


def _coverage(level: str, status: str, reason: str, evidence_ref: str | None = None) -> dict[str, Any]:
    return {
        "level": level,
        "status": status,
        "reason": reason,
        "evidence_ref": evidence_ref,
    }



def _request_suffix(request_id: str) -> str:
    return request_id.split(":", 1)[1]


def _reverse_coverage(coverage: list[dict[str, Any]]) -> list[dict[str, Any]]:
    mapping = [
        ("L0", "IDENTITY"),
        ("L1", "SOURCE_INVENTORY"),
        ("L2", "STRUCTURE"),
        ("L3", "DEPENDENCY"),
        ("L4", "DEEP_READ"),
        ("L5", "RUNTIME"),
        ("L6", "SCENARIO"),
    ]
    by_level = {row["level"]: row for row in coverage}
    allowed = {"SCANNED", "DEFERRED", "EXCLUDED", "UNAVAILABLE", "UNKNOWN", "CONFLICT", "VERIFIED"}
    normalized = []
    for level, scope in mapping:
        if level not in by_level:
            continue
        source_status = by_level[level]["status"]
        status = source_status
        if source_status == "PASS":
            status = "VERIFIED"
        elif source_status in {"FAIL", "BLOCK"}:
            status = "CONFLICT"
        elif source_status == "OBSERVED":
            status = "UNKNOWN"
        if status not in allowed:
            status = "UNKNOWN"
        normalized.append({
            "scope": scope,
            "status": status,
            "reason": by_level[level]["reason"],
            "evidence_ref": by_level[level].get("evidence_ref"),
        })
    return normalized


def _build_reverse_projection(
    request_id: str,
    root: Path,
    source_revision: str | None,
    inventory: list[dict[str, Any]],
    modules: list[str],
    symbols: list[dict[str, Any]],
    entrypoints: list[str],
    stubs: list[str],
    syntax_errors: list[dict[str, str]],
    edges: list[dict[str, str]],
    unresolved: list[str],
    assessment: dict[str, Any],
    coverage: list[dict[str, Any]],
    *,
    status: str = "PASS",
    reason: str | None = None,
) -> dict[str, Any]:
    result = {
        "schema_version": "1.0",
        "request_id": "REVERSE:" + _request_suffix(request_id),
        "status": status,
        "identity": {
            "root_path": str(root),
            "root_name": root.name,
            "file_count": len(inventory),
            "source_revision": source_revision,
        },
        "coverage_ledger": _reverse_coverage(coverage),
        "inventory": inventory,
        "structure": {
            "modules": sorted(set(modules)),
            "symbols": symbols,
            "entrypoint_candidates": entrypoints,
            "stub_signals": stubs,
            "syntax_errors": syntax_errors,
        },
        "dependencies": {
            "edges": edges,
            "unresolved": unresolved,
        },
        "state_assessment": assessment,
        "evidence": {
            "observed": [
                f"inventory.files={len(inventory)}",
                f"structure.symbols={len(symbols)}",
                f"dependencies.local_edges={len(edges)}",
                f"syntax_errors={len(syntax_errors)}",
                f"stub_signals={len(stubs)}",
            ],
            "confirmed": ["root_path_exists", "file_sha256_recorded"] if status == "PASS" else [],
            "inferred": [f"entrypoint_candidate:{path}" for path in entrypoints],
            "unknown": ["business_semantics", "external_dependency_health"],
            "conflict": [],
        },
    }
    if reason:
        result["reason"] = reason
    return result


def execute(request: dict[str, Any]) -> dict[str, Any]:
    _validate(request, REQUEST_SCHEMA)
    root = Path(request["root_path"]).resolve()
    levels: list[dict[str, Any]] = []
    coverage: list[dict[str, Any]] = []

    # L0 Identity
    if not root.is_dir():
        assessment = {
            "classification": "UNKNOWN",
            "implemented": False,
            "partial": False,
            "stub": False,
            "broken": False,
            "unknown": True,
            "next_diagnostic_point": "root-path",
        }
        reverse_projection = _build_reverse_projection(
            request["request_id"], root, None, [], [], [], [], [], [], [], [], assessment,
            [_coverage("L0", "UNAVAILABLE", "root path not found")],
            status="BLOCK",
            reason="ROOT_PATH_UNAVAILABLE",
        )
        _validate(reverse_projection, REVERSE_RESULT_SCHEMA)
        partial_state = derive_partial_system_state(
            reverse_projection, expected_paths=request.get("focus_paths", [])
        )
        lifecycle = artifact_lifecycle(
            artifact_id="RECONART:" + _request_suffix(request["request_id"]),
            artifact_type="KNOWLEDGE_RECOVERY",
            source_request_id=reverse_projection["request_id"],
            current_status="ABSENT",
            action="CREATE",
        )
        return {
            "schema_version": "1.0",
            "request_id": request["request_id"],
            "status": "BLOCK",
            "identity": {"root_path": str(root), "root_name": root.name, "source_revision": None},
            "levels": [{"level": "L0", "status": "UNAVAILABLE"}],
            "coverage_ledger": [_coverage("L0", "UNAVAILABLE", "root path not found")],
            "inventory": {"files": 0, "bytes": 0, "complete_under_limits": False},
            "structure": {"modules": 0, "symbols": 0, "syntax_errors": [], "stub_signals": [], "entrypoint_candidates": []},
            "dependencies": {"local_edges": 0, "unresolved": []},
            "selected_context": {"selected_paths": [], "deferred_paths": [], "budget": {}, "deep_reads": [], "context_gate": {}},
            "runtime_evidence": [],
            "oracle": None,
            "state_assessment": assessment,
            "reverse_reconstruction": reverse_projection,
            "partial_system_state": partial_state,
            "artifact_lifecycle": lifecycle,
        }

    head = root / ".git" / "HEAD"
    source_revision = None
    if head.exists():
        raw = head.read_text(encoding="utf-8", errors="replace").strip()
        if raw.startswith("ref:"):
            ref = root / ".git" / raw[5:].strip()
            source_revision = ref.read_text(encoding="utf-8", errors="replace").strip() if ref.exists() else raw
        else:
            source_revision = raw
    levels.append({"level": "L0", "status": "VERIFIED", "facts": {
        "root_name": root.name, "source_revision": source_revision
    }})
    coverage.append(_coverage("L0", "VERIFIED", "repository identity established"))

    # L1 Inventory
    excludes = DEFAULT_EXCLUDES | set(request.get("exclude_dirs", []))
    inventory_mode = request.get("inventory_mode", "TARGETED")
    inventory, inventory_bytes, inventory_complete, inventory_issues = _inventory(
        root,
        excludes,
        request.get("max_inventory_files", 10000),
        request.get("max_inventory_bytes", 20_000_000),
        focus_paths=request.get("focus_paths", []),
        mode=inventory_mode,
    )
    levels.append({"level": "L1", "status": "SCANNED" if inventory_complete else "DEFERRED", "facts": {
        "files": len(inventory), "bytes": inventory_bytes, "complete_under_limits": inventory_complete,
        "scope_mode": inventory_mode, "explicit_focus_paths": request.get("focus_paths", []),
        "issues": inventory_issues,
    }})
    coverage.append(_coverage("L1", "SCANNED" if inventory_complete else "DEFERRED",
                              ("explicit focus paths and resolvable local imports" if inventory_mode == "TARGETED" else "explicitly requested bounded reconstruction inventory") if inventory_complete else "inventory incomplete; unscanned scope remains UNKNOWN", "inventory"))

    # L2 Structure
    symbols, modules, syntax_errors, stubs, imports = _structure(root, inventory)
    entrypoints = _entrypoints(inventory, symbols)
    levels.append({"level": "L2", "status": "SCANNED", "facts": {
        "modules": len(modules), "symbols": len(symbols), "syntax_errors": len(syntax_errors),
        "stub_signals": len(stubs), "entrypoints": entrypoints
    }})
    coverage.append(_coverage("L2", "SCANNED", "AST/structural extraction completed", "structure"))

    # L3 Dependencies
    edges, unresolved = _dependencies(root, imports)
    levels.append({"level": "L3", "status": "SCANNED", "facts": {
        "local_edges": len(edges), "unresolved": len(unresolved)
    }})
    coverage.append(_coverage("L3", "SCANNED", "local dependency resolution completed", "dependencies"))

    assessment = _state(inventory, syntax_errors, stubs, unresolved, entrypoints)
    reverse_result = _build_reverse_projection(
        request["request_id"], root, source_revision, inventory, modules, symbols,
        entrypoints, stubs, syntax_errors, edges, unresolved, assessment, coverage,
    )
    _validate(reverse_result, REVERSE_RESULT_SCHEMA)

    # L4 Selected deep read + context gate
    selection = select_context(
        reverse_result,
        focus_paths=request.get("focus_paths", []),
        max_files=request.get("max_deep_read_files", 8),
        max_bytes=request.get("max_deep_read_bytes", 20000),
    )
    selected_paths = [row["path"] for row in selection["selected_paths"]]
    required_refs = sorted(set(request.get("focus_paths", [])) & set(row["path"] for row in inventory))
    available_refs = selected_paths
    sufficient = context_sufficiency(
        gate_id="CTXGATE:" + request["request_id"].replace(":", "-"),
        required_refs=required_refs,
        available_refs=available_refs,
        estimated_total_context=selection["budget"]["selected_bytes"],
        target_context_budget=request.get("target_context_budget", 12000),
        hard_context_ceiling=request.get("hard_context_ceiling", 20000),
    )
    deep_reads: list[dict[str, Any]] = []
    remaining = request.get("max_deep_read_bytes", 20000)
    for selected in selection["selected_paths"]:
        if remaining <= 0:
            break
        path = root / selected["path"]
        data = path.read_bytes()
        take = min(len(data), remaining, 4096)
        deep_reads.append({
            "path": selected["path"],
            "bytes_read": take,
            "sha256": _sha(data),
            "excerpt_utf8": data[:take].decode("utf-8", errors="replace"),
        })
        remaining -= take
    l4_status = "SCANNED" if sufficient["action"] == "EXECUTE" else "DEFERRED"
    levels.append({"level": "L4", "status": l4_status, "facts": {
        "selected_files": len(selected_paths),
        "selected_bytes": selection["budget"]["selected_bytes"],
        "context_gate": sufficient["status"],
        "context_action": sufficient["action"],
        "deep_reads": len(deep_reads),
    }})
    coverage.append(_coverage("L4", l4_status, "dependency-aware bounded deep read", "selected-context"))

    # L5 Runtime / test / config evidence
    runtime_results = []
    for probe in request.get("runtime_probes", []):
        runtime_results.append(runtime_probe({
            "schema_version": "1.0",
            "probe_id": probe["probe_id"],
            "root_path": str(root),
            "command": probe["command"],
            "timeout_seconds": probe.get("timeout_seconds", 120),
            "expected_exit_code": probe.get("expected_exit_code", 0),
            "environment_keys": probe.get("environment_keys", []),
        }))
    if not runtime_results:
        l5_status = "UNKNOWN"
    elif all(item["status"] == "PASS" for item in runtime_results):
        l5_status = "VERIFIED"
    else:
        l5_status = "FAIL"
    levels.append({"level": "L5", "status": l5_status, "facts": {
        "probes": len(runtime_results),
        "passes": sum(x["status"] == "PASS" for x in runtime_results),
    }})
    coverage.append(_coverage("L5", l5_status,
                              "explicit runtime probes only; no implicit execution",
                              "runtime-evidence" if runtime_results else None))

    # L6 Targeted hypothesis verification
    oracle_result = None
    if request.get("oracle"):
        oracle_request = dict(request["oracle"])
        oracle_request["schema_version"] = "1.0"
        oracle_request["root_path"] = str(root)
        oracle_result = run_oracle(oracle_request)
        l6_status = oracle_result["status"]
    else:
        l6_status = "UNKNOWN"
    levels.append({"level": "L6", "status": l6_status, "facts": {
        "oracle": bool(oracle_result),
        "scenario_results": len(oracle_result["results"]) if oracle_result else 0,
    }})
    # coverage_ledger 的 status enum 沒有 PASS；與 L5 一致，PASS 在 ledger 記為 VERIFIED。
    # levels[].status 維持 oracle 原值（schema 為任意 string，既有測試依賴 PASS）。
    l6_ledger_status = "VERIFIED" if l6_status == "PASS" else l6_status
    coverage.append(_coverage("L6", l6_ledger_status,
                              "targeted scenario/oracle verification",
                              "scenario-oracle" if oracle_result else None))

    final_assessment = _state(
        inventory, syntax_errors, stubs, unresolved, entrypoints
    )
    reverse_result = _build_reverse_projection(
        request["request_id"], root, source_revision, inventory, modules, symbols,
        entrypoints, stubs, syntax_errors, edges, unresolved, final_assessment, coverage,
        status="BLOCK" if sufficient["action"] == "RECONCILE_OR_BLOCK" else "PASS",
    )
    _validate(reverse_result, REVERSE_RESULT_SCHEMA)

    partial_system_state = derive_partial_system_state(
        reverse_result,
        expected_paths=request.get("focus_paths", []),
    )

    artifact = artifact_lifecycle(
        artifact_id="RECONART:" + _request_suffix(request["request_id"]),
        artifact_type="KNOWLEDGE_RECOVERY",
        source_request_id=reverse_result["request_id"],
        current_status="ABSENT",
        action="CREATE",
    )
    artifact = artifact_lifecycle(
        artifact_id=artifact["artifact_id"],
        artifact_type=artifact["artifact_type"],
        source_request_id=artifact["source_request_id"],
        current_status=artifact["status"],
        action="USE",
    )
    verification_refs = []
    if runtime_results and all(item["status"] == "PASS" for item in runtime_results):
        verification_refs.append("runtime-evidence")
    if oracle_result and oracle_result["status"] == "PASS":
        verification_refs.append("scenario-oracle")
    if verification_refs:
        artifact = artifact_lifecycle(
            artifact_id=artifact["artifact_id"],
            artifact_type=artifact["artifact_type"],
            source_request_id=artifact["source_request_id"],
            current_status=artifact["status"],
            action="VERIFY",
            evidence_refs=verification_refs,
        )

    overall = "PASS"
    if sufficient["action"] == "RECONCILE_OR_BLOCK":
        overall = "BLOCK"
    elif l5_status == "FAIL" or l6_status == "FAIL":
        overall = "FAIL"
    elif not inventory_complete:
        overall = "INCOMPLETE"

    result = {
        "schema_version": "1.0",
        "request_id": request["request_id"],
        "status": overall,
        "identity": {"root_path": str(root), "root_name": root.name, "source_revision": source_revision},
        "levels": levels,
        "coverage_ledger": coverage,
        "inventory": {"files": len(inventory), "bytes": inventory_bytes, "complete_under_limits": inventory_complete},
        "structure": {"modules": len(modules), "symbols": len(symbols), "syntax_errors": syntax_errors, "stub_signals": stubs, "entrypoint_candidates": entrypoints},
        "dependencies": {"local_edges": len(edges), "unresolved": unresolved},
        "selected_context": {
            "selected_paths": selected_paths,
            "deferred_paths": selection["deferred_paths"],
            "budget": selection["budget"],
            "deep_reads": deep_reads,
            "context_gate": sufficient,
        },
        "runtime_evidence": runtime_results,
        "oracle": oracle_result,
        "state_assessment": final_assessment,
        "reverse_reconstruction": reverse_result,
        "partial_system_state": partial_system_state,
        "artifact_lifecycle": artifact,
    }
    _validate(result, RESULT_SCHEMA)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run P1 progressive L0-L6 repository scan")
    parser.add_argument("request")
    args = parser.parse_args()
    result = execute(_load(Path(args.request).resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return {"PASS": 0, "FAIL": 1, "BLOCK": 2, "INCOMPLETE": 3}[result["status"]]


if __name__ == "__main__":
    raise SystemExit(main())
