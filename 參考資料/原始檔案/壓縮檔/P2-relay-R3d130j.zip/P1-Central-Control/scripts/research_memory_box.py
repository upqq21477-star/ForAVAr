#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ALLOWED_BASELINE_KINDS = {"OBSERVED", "CONFIRMED"}
EVIDENCE_KINDS = {"EVIDENCE", "ALTERNATIVE", "COUNTEREXAMPLE", "CONSTRAINT", "COMPATIBILITY"}
DECISION_OUTCOMES = {
    "NO_CHANGE", "REUSE", "ADAPTER", "REDUCE", "DEFER",
    "REPAIR", "REFACTOR", "MERGE", "SPLIT", "NEW_SYSTEM"
}


def now() -> datetime:
    return datetime.now(timezone.utc).replace(microsecond=0)


def iso(value: datetime) -> str:
    return value.isoformat().replace("+00:00", "Z")


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def validate_baseline(baseline: dict[str, Any]) -> None:
    if baseline.get("working_context"):
        raise ValueError("Research Memory Box 不接受既有 working_context")
    if baseline.get("prior_conclusions"):
        raise ValueError("上一輪 conclusion 不得直接進入 Objective Baseline")
    if baseline.get("recommendations"):
        raise ValueError("上一輪 recommendation 不得直接進入 Objective Baseline")

    for collection_name in ("facts", "constraints", "capabilities"):
        collection = baseline.get(collection_name, [])
        if not isinstance(collection, list):
            raise ValueError(f"{collection_name} 必須是 array")
        for item in collection:
            if not isinstance(item, dict):
                raise ValueError(f"{collection_name} item 必須是 object")
            if item.get("kind") not in ALLOWED_BASELINE_KINDS:
                raise ValueError(f"{collection_name} 只接受 OBSERVED / CONFIRMED")

    for name in ("unknowns", "conflicts", "source_refs"):
        value = baseline.get(name, [])
        if not isinstance(value, list):
            raise ValueError(f"{name} 必須是 array")


def create_box(baseline: dict[str, Any], ttl_minutes: int = 60) -> dict[str, Any]:
    validate_baseline(baseline)
    created = now()
    return {
        "box_id": f"RESEARCH_BOX:{uuid.uuid4().hex[:16]}",
        "kind": "FRESH_DECISION_WORKSPACE",
        "status": "OPEN",
        "risk_level": baseline.get("risk_level", "L2"),
        "created_at": iso(created),
        "expires_at": iso(created + timedelta(minutes=ttl_minutes)),
        "baseline_revision": baseline.get("baseline_revision", "UNKNOWN"),
        "baseline_source_refs": list(baseline.get("source_refs", [])),
        "objective_baseline": {
            "goal": baseline.get("goal"),
            "change_request": baseline.get("change_request"),
            "facts": list(baseline.get("facts", [])),
            "constraints": list(baseline.get("constraints", [])),
            "capabilities": list(baseline.get("capabilities", [])),
            "unknowns": list(baseline.get("unknowns", [])),
            "conflicts": list(baseline.get("conflicts", [])),
        },
        "working_context": [],
        "external_evidence": [],
        "alternatives": [],
        "decision": None,
    }


def add_external(box: dict[str, Any], item: dict[str, Any]) -> dict[str, Any]:
    if box.get("status") != "OPEN":
        raise ValueError("Box 已關閉")
    if item.get("kind") not in EVIDENCE_KINDS:
        raise ValueError("未知 external evidence kind")
    if not item.get("source_refs"):
        raise ValueError("external evidence 必須有 source_refs")
    box.setdefault("external_evidence", []).append(item)
    return box


def add_alternative(box: dict[str, Any], option: dict[str, Any]) -> dict[str, Any]:
    if box.get("status") != "OPEN":
        raise ValueError("Box 已關閉")
    required = ("option_id", "name", "tradeoffs")
    if any(not option.get(field) for field in required):
        raise ValueError("alternative 缺少必要欄位")
    box.setdefault("alternatives", []).append(option)
    return box


def close_box(box: dict[str, Any], decision: dict[str, Any]) -> dict[str, Any]:
    if box.get("status") != "OPEN":
        raise ValueError("Box 不是 OPEN")

    expires_at = datetime.fromisoformat(box["expires_at"].replace("Z", "+00:00"))
    if now() > expires_at:
        raise ValueError("Research Box 已過期")

    outcome = decision.get("outcome")
    if outcome not in DECISION_OUTCOMES:
        raise ValueError("非法 Decision outcome")

    if not decision.get("evidence_refs"):
        raise ValueError("Decision 必須有 evidence_refs")
    if not decision.get("alternative_refs"):
        raise ValueError("Decision 必須有 alternative_refs，至少包含候選或 NO_CHANGE")

    decision["decision_id"] = decision.get("decision_id") or f"DECISION:{uuid.uuid4().hex[:16]}"

    # CLOSED is the durable decision boundary. Enforce per-claim provenance here
    # so a box cannot become CLOSED while provenance validation would still BLOCK.
    from research_memory_box_provenance import validate as validate_provenance

    provenance_box = dict(box)
    provenance_box["decision"] = dict(decision)
    provenance = validate_provenance(provenance_box)
    if provenance["status"] != "PASS":
        raise ValueError(
            "Research Memory Box provenance gate BLOCK: "
            + json.dumps(provenance["errors"], ensure_ascii=False)
        )

    decision["baseline_revision"] = box["baseline_revision"]
    decision["box_id"] = box["box_id"]
    box["decision"] = decision
    box["status"] = "CLOSED"
    box["closed_at"] = iso(now())
    return box


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Research Memory Box")
    sub = parser.add_subparsers(dest="command", required=True)

    create = sub.add_parser("create")
    create.add_argument("--baseline", required=True)
    create.add_argument("--output", required=True)
    create.add_argument("--ttl-minutes", type=int, default=60)

    external = sub.add_parser("add-external")
    external.add_argument("--box", required=True)
    external.add_argument("--item", required=True)
    external.add_argument("--output", required=True)

    alternative = sub.add_parser("add-alternative")
    alternative.add_argument("--box", required=True)
    alternative.add_argument("--item", required=True)
    alternative.add_argument("--output", required=True)

    close = sub.add_parser("close")
    close.add_argument("--box", required=True)
    close.add_argument("--decision", required=True)
    close.add_argument("--output", required=True)

    args = parser.parse_args()

    if args.command == "create":
        result = create_box(load(Path(args.baseline)), args.ttl_minutes)
    elif args.command == "add-external":
        result = add_external(load(Path(args.box)), load(Path(args.item)))
    elif args.command == "add-alternative":
        result = add_alternative(load(Path(args.box)), load(Path(args.item)))
    else:
        result = close_box(load(Path(args.box)), load(Path(args.decision)))

    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
