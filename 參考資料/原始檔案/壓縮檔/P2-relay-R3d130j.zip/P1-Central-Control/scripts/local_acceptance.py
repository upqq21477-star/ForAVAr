#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
CAPTURABLE_GATE_CODES = {0, 1, 2}

from progress_execution_contract import require_work_unit_close_ready


def require_central_acceptance_context(root: Path = ROOT) -> dict:
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    stage = current.get("current_stage", {})
    ref = stage.get("acceptance_ref")
    if not ref:
        raise ValueError("CENTRAL_ACCEPTANCE_CONTEXT_REQUIRED")
    path = root / ref if not Path(ref).is_absolute() else Path(ref)
    if not path.is_file():
        raise ValueError("CENTRAL_ACCEPTANCE_CONTEXT_NOT_FOUND")
    context = json.loads(path.read_text(encoding="utf-8"))
    if context.get("kind") != "ACCEPTANCE_CONTEXT":
        raise ValueError("CENTRAL_ACCEPTANCE_CONTEXT_KIND_INVALID")
    if context.get("authority") != "P1-CURRENT" or context.get("lifecycle_owner") != "CENTRAL":
        raise ValueError("CENTRAL_ACCEPTANCE_CONTEXT_AUTHORITY_INVALID")
    if context.get("mode") != "SIMULATION_ONLY":
        raise ValueError("CENTRAL_ACCEPTANCE_CONTEXT_MODE_INVALID")
    if context.get("work_unit_ref") != (stage.get("work_unit_id") or stage.get("id")):
        raise ValueError("CENTRAL_ACCEPTANCE_CONTEXT_WORK_UNIT_MISMATCH")
    return context


def regression_targets(root: Path, work_unit: str) -> dict[str, str]:
    """stage_id -> test file that must pass for this Work Unit's close.

    M32-CLOSE keeps its single vertical-slice regression. Every other Work Unit is driven by
    its acceptance context: each `required_checks` entry names `tests/test_<check>.py`.
    """
    if work_unit == "M32-CLOSE":
        return {"M32_CLOSE_VERTICAL_SLICE": "P1-Central-Control/tests/test_m32_close_vertical_slice.py"}
    context = require_central_acceptance_context(root)
    return {
        check.upper(): f"P1-Central-Control/tests/test_{check}.py"
        for check in context["required_checks"]
    }


def close_locally(report_path: Path, record_path: Path, root: Path = ROOT) -> dict:
    """Apply a PASS simulation acceptance to canonical state, entirely on this machine.

    Needs no network, no CI and no hosted runner: the acceptance result, the close and the
    state write all happen here. Hosted CI is an optional second observer, not a dependency.
    """
    from local_acceptance_capture import close_simulation, load

    report = load(report_path)
    record = load(record_path)
    current_path = root / "P1-CURRENT.json"
    current = load(current_path)
    work_path = root / current["implementation_control"]["active_work_packet"]
    construction_path = root / load(work_path)["construction_packet_ref"]
    return close_simulation(
        report,
        record,
        current_path=current_path,
        work_packet_path=work_path,
        construction_packet_path=construction_path,
        execution_source="LOCAL",
        execution_id=record["execution_id"],
        head_sha=report["head_sha"],
    )


def bind_context(head_sha: str, root: Path = ROOT) -> None:
    """Point the OPEN acceptance context at this code digest (content-addressed, no git)."""
    from acceptance_context import dump, load, sha256_payload

    stage = load(root / "P1-CURRENT.json")["current_stage"]
    path = root / stage["acceptance_ref"]
    context = load(path)
    if context.get("status") != "OPEN":
        raise ValueError("ACCEPTANCE_CONTEXT_NOT_OPEN")
    context["head_sha"] = head_sha
    context.pop("content_sha256", None)
    context["content_sha256"] = sha256_payload(context)
    path.write_text(dump(context), encoding="utf-8")


def reopen_active(root: Path = ROOT) -> None:
    """Reopen the active Work Unit's stage/work/construction so the same unit can be re-accepted.

    One-step re-verification after any code change (the acceptance binds a code digest).
    """
    pending = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE"

    def edit(path: Path, fn) -> None:
        data = json.loads(path.read_text(encoding="utf-8"))
        fn(data)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    current_path = root / "P1-CURRENT.json"
    current = json.loads(current_path.read_text(encoding="utf-8"))
    control = current["implementation_control"]

    def reopen_stage(data: dict) -> None:
        stage = data["current_stage"]
        stage.update(status=pending, implementation_step="CLOSE_ACCEPTANCE",
                     validated_control_gate_run=None, validated_head_sha=None)
        stage.pop("simulation_acceptance", None)

    def reopen_work(data: dict) -> None:
        data.update(status=pending, implementation_step="CLOSE_ACCEPTANCE")
        completion = data.get("completion")
        if isinstance(completion, dict):
            completion["verified_at"] = None
            completion.pop("acceptance_result", None)

    def reopen_construction(data: dict) -> None:
        data.update(status=pending, implementation_step="CLOSE_ACCEPTANCE")
        data.pop("acceptance_result", None)

    edit(current_path, reopen_stage)
    edit(root / control["active_work_packet"], reopen_work)
    edit(root / control["active_construction_packet"], reopen_construction)


def gate_result_is_capturable(returncode: int, report: Path) -> bool:
    return returncode in CAPTURABLE_GATE_CODES and report.is_file()


def observation_is_not_real_evidence(observation: object) -> bool:
    """RUNTIME_TRUTH_BOUNDARY：最近一次運行觀察不得被當成真實驗收證據。

    以型別欄位判斷（不比對原文子字串、不依賴舊 evidence 旗標）：
    classification 屬 SIMULATION_*，或 program_regression_status 不是 PASS，即成立。
    缺觀察或型別錯誤一律不成立（fail closed）。
    """
    if not isinstance(observation, dict):
        return False
    classification = observation.get("classification")
    status = observation.get("program_regression_status")
    if not isinstance(classification, str) or not isinstance(status, str):
        return False
    return classification.startswith("SIMULATION_") or status != "PASS"


def simulated_report(head_sha: str, base_sha: str) -> dict:
    """Run one static construction acceptance for the active Work Unit."""
    def file_text(relative: str) -> str:
        path = ROOT / relative
        return path.read_text(encoding="utf-8") if path.is_file() else ""

    def exists(relative: str) -> bool:
        return (ROOT / relative).is_file()

    current_path = ROOT / "P1-CURRENT.json"
    current = json.loads(current_path.read_text(encoding="utf-8"))
    stage = current["current_stage"]
    work_unit = stage.get("work_unit_id") or stage["id"]

    m32_checks = {
        "M32_C01_A": (
            exists("P1-Central-Control/scripts/command_layer.py")
            and "TRUSTED_EXECUTABLE_ACTION_TYPES" in file_text("P1-Central-Control/scripts/command_layer.py")
            and "ARBITRARY_ARGV_BLOCKED" in file_text("P1-Central-Control/scripts/command_layer.py")
        ),
        "M32_C01_B": (
            "def continue_once(" in file_text("P1-Central-Control/scripts/minimal_closed_loop_runner.py")
            and "command_layer.execute_command" in file_text("P1-Central-Control/scripts/minimal_closed_loop_runner.py")
            and exists("P1-Central-Control/tests/test_thin_continuation.py")
        ),
        "M32_C01_C": (
            "LATE_RESULT" in file_text("P1-Central-Control/scripts/parallel_scheduler.py")
            and 'execution["status"] != "RUNNING"' in file_text("P1-Central-Control/scripts/central_controller.py")
            and exists("P1-Central-Control/tests/test_execution_truth.py")
        ),
        "M32_C01_D": (
            "def read_recoverable(" in file_text("P1-Central-Control/scripts/event_log.py")
            and "def recover_workflow(" in file_text("P1-Central-Control/scripts/event_reducer.py")
            and "PARTIAL_OR_CORRUPT_FINAL_LINE" in file_text("P1-Central-Control/scripts/event_log.py")
        ),
        "M32_C01_E": (
            "def compare_observations(" in file_text("P1-Central-Control/scripts/current_truth_reconciliation.py")
            and "STALE_OR_CONFLICTING_RUNTIME_OBSERVATION" in file_text("P1-Central-Control/scripts/current_truth_reconciliation.py")
            and exists("P1-Central-Control/tests/test_current_truth_reconciliation.py")
        ),
        "M32_C01_F": (
            exists(".github/workflows/p1-control-gate.yml")
            and all(
                re.search(r"uses:\s*[^\s@]+@(?:[0-9a-f]{40})(?:\s|#|$)", line)
                for workflow in (ROOT / ".github/workflows").glob("*.yml")
                for line in workflow.read_text(encoding="utf-8").splitlines()
                if "uses:" in line and not "uses: ./" in line
            )
            and "contents: read" in file_text(".github/workflows/p1-control-gate.yml")
        ),
    }

    checks = m32_checks if work_unit == "M32-CLOSE" else {}
    if work_unit == "M32-CLOSE":
        close_source = file_text("P1-Central-Control/tests/test_m32_close_vertical_slice.py")
        required_markers = (
            "central_controller.commit_brain_proposal",
            "RETRY_PENDING",
            '"TIMEOUT"',
            "IDEMPOTENT_REPLAY",
            'unknown["execution_status"]',
            "RECONCILIATION_REQUIRED",
            "RUNNER_STARTUP_FAILURE",
            "STALE_OR_CONFLICTING_RUNTIME_OBSERVATION",
            "runner.admit_executable_action",
            "SIMULATION_ONLY",
        )
        checks["M32_CLOSE_VERTICAL_SLICE"] = (
            exists("P1-Central-Control/tests/test_m32_close_vertical_slice.py")
            and all(marker in close_source for marker in required_markers)
        )

    if work_unit != "M32-CLOSE":
        for stage_id, test_path in regression_targets(ROOT, work_unit).items():
            checks[stage_id] = exists(test_path)

    checks["SIMULATION_BOUNDARY"] = (
        current["current_stage"].get("validated_control_gate_run") is None
        and current["current_stage"].get("validated_head_sha") is None
        and "SIMULATION" in str(current["current_stage"].get("acceptance", "")).upper()
    )
    checks["RUNTIME_TRUTH_BOUNDARY"] = observation_is_not_real_evidence(
        current.get("latest_runtime_observation")
    )

    stages = [
        {
            "stage_id": stage_id,
            "status": "PASS" if passed else "FAIL",
            "object_ref": f"SIM:{stage_id}",
            "reason_code": "SIMULATED_STATIC_ACCEPTANCE" if passed else "SIMULATED_STATIC_CHECK_FAILED",
        }
        for stage_id, passed in checks.items()
    ]
    status = "PASS" if all(checks.values()) else "FAIL"
    return {
        "report_id": f"SIMULATED_CONTROL_GATE:{head_sha}",
        "base_sha": base_sha,
        "head_sha": head_sha,
        "status": status,
        "mode": "SIMULATION_ONLY",
        "simulated": True,
        "work_unit": work_unit,
        "stages": stages,
    }

def main() -> int:
    parser = argparse.ArgumentParser(description="P1 local acceptance entrypoint")
    parser.add_argument("--output", required=True)
    parser.add_argument("--acceptance-output", required=True)
    parser.add_argument("--base")
    parser.add_argument("--head")
    parser.add_argument("--skip-unit-tests", action="store_true")
    parser.add_argument("--external-result")
    parser.add_argument("--live", action="store_true", help="opt into real control-gate execution")
    parser.add_argument(
        "--bind-context",
        action="store_true",
        help="rebind the OPEN acceptance context to the current code digest before accepting",
    )
    parser.add_argument(
        "--close",
        action="store_true",
        help="after a PASS simulation acceptance, close the Work Unit in canonical state locally",
    )
    parser.add_argument(
        "--reverify",
        action="store_true",
        help="one step after a code change: reopen stage/work/construction, then bind-context and close",
    )
    args = parser.parse_args()
    if args.reverify:
        if args.live:
            parser.error("--reverify applies to the SIMULATION_ONLY acceptance, not --live")
        reopen_active(ROOT)
        args.bind_context = args.close = True
    if args.close and args.live:
        parser.error("--close applies to the SIMULATION_ONLY acceptance, not --live")

    try:
        close_ready = require_work_unit_close_ready(ROOT)
        require_central_acceptance_context(ROOT)
    except ValueError as exc:
        print(f"WORK_UNIT_CLOSE_ACCEPTANCE_BLOCKED:{exc}", file=sys.stderr)
        return 4

    if not args.live:
        from code_digest import BASE, code_digest
        head_sha = args.head or code_digest(ROOT)
        base_sha = args.base or BASE
        if args.bind_context:
            bind_context(head_sha)
        report = simulated_report(head_sha, base_sha)

        targets = regression_targets(ROOT, report["work_unit"])
        for stage_id, test_path in targets.items():
            regression = subprocess.run(
                [sys.executable, "-m", "unittest", "-v", test_path],
                cwd=ROOT,
                check=False,
                capture_output=True,
                text=True,
            )
            stage = next(item for item in report["stages"] if item["stage_id"] == stage_id)
            ok = regression.returncode == 0
            stage["status"] = "PASS" if ok else "FAIL"
            stage["reason_code"] = "EXECUTABLE_REGRESSION_PASS" if ok else "EXECUTABLE_REGRESSION_FAILED"
        report["status"] = (
            "PASS" if all(stage["status"] == "PASS" for stage in report["stages"]) else "FAIL"
        )

        report_path = Path(args.output)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        capture = subprocess.run(
            [sys.executable, "P1-Central-Control/scripts/local_acceptance_capture.py", str(report_path), args.acceptance_output],
            cwd=ROOT,
            check=False,
        )
        if args.close and capture.returncode == 0:
            print(json.dumps(close_locally(report_path, Path(args.acceptance_output)), ensure_ascii=False, indent=2))
            import lifecycle_sweep

            pending = lifecycle_sweep.records_for_control_research(ROOT)
            if pending:  # 結案時交 CONTROL_RESEARCH 判斷（過期／再發待升級／無效）
                print(json.dumps({"records_for_control_research": pending}, ensure_ascii=False))
        return capture.returncode

    with tempfile.TemporaryDirectory(prefix="p1-local-acceptance-") as temp:
        report = Path(temp) / "control-gate-report.json"
        command = [sys.executable, "P1-Central-Control/scripts/local_control_gate.py", "--output", str(report)]
        if args.base:
            command.extend(["--base", args.base])
        if args.head:
            command.extend(["--head", args.head])
        if args.skip_unit_tests:
            command.append("--skip-unit-tests")
        if args.external_result:
            command.extend(["--external-result", args.external_result])
        gate = subprocess.run(command, cwd=ROOT, check=False)
        if not gate_result_is_capturable(gate.returncode, report):
            return gate.returncode
        capture = subprocess.run(
            [sys.executable, "P1-Central-Control/scripts/local_acceptance_capture.py", str(report), args.acceptance_output],
            cwd=ROOT,
            check=False,
        )
        if capture.returncode != 0:
            return capture.returncode
        Path(args.output).write_text(report.read_text(encoding="utf-8"), encoding="utf-8")
        return 0 if gate.returncode == 0 else 2 if gate.returncode == 2 else 1


if __name__ == "__main__":
    raise SystemExit(main())
