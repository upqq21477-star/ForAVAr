#!/usr/bin/env python3
"""CS-1 B6：Planner 可見的 Card 投影、Method／Pattern 表、Pattern→Task Set（Dynamic Team）、升格規則、決策簡報。
Card＝capability_registry／policy/planner_library 的白名單投影（不建第二個 registry）；Team＝一份 Task Set，不新增 Role。
語義判斷（升格的邊界／IO／驗證／失效模式是否成立）歸 CONTROL_RESEARCH 並附 rationale；機器只做結構、白名單、算術。
錯誤皆 ValueError("<CODE>[:detail]")。SIMULATION_ONLY；無非測試呼叫者。"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).resolve().parent))
import task_set  # noqa: E402

POLICY = ROOT / "P1-Central-Control/policy/planner_library.v1.0.json"
REGISTRY = ROOT / "P1-Central-Control/capability_registry.json"
ROLES = ("ROLE:CONTROL_RESEARCH", "ROLE:EXECUTOR", "ROLE:VERIFIER")
ID_RE = re.compile(r"^[A-Za-z][A-Za-z0-9_.:-]{1,63}$")
VER_RE = re.compile(r"^[0-9A-Za-z][0-9A-Za-z._-]{0,31}$")
TEXT_KEYS = ("purpose", "trigger")


def _fail(code: str, detail: str = "") -> None:
    raise ValueError(code + (":" + detail if detail else ""))


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _text(value: Any, limit: int) -> None:
    if not isinstance(value, str) or not value or len(value) > limit or any(ord(c) < 32 for c in value):
        _fail("CARD_TEXT_INVALID")


def _walk_ids(value: Any) -> None:
    if isinstance(value, str):
        if not ID_RE.match(value):
            _fail("CARD_FIELD_NOT_ID", value[:40])
    elif isinstance(value, list):
        for v in value:
            _walk_ids(v)
    elif isinstance(value, dict):
        for v in value.values():
            _walk_ids(v)
    elif value is not None and not isinstance(value, (int, bool)):
        _fail("CARD_FIELD_TYPE")


def check_card(card: dict[str, Any], kind: str, pol: dict[str, Any] | None = None) -> dict[str, Any]:
    """Planner 可見性白名單（Data≠Instruction）：欄位須恰為該類清單；自由文字只限 purpose／trigger（單行、有長度上限），其餘一律 id／enum。"""
    pol = pol or _load(POLICY)
    fields = pol["card_fields"].get(kind)
    if fields is None:
        _fail("CARD_KIND_UNKNOWN", kind)
    if set(card) != set(fields):
        _fail("CARD_FIELDS_NOT_WHITELIST", ",".join(sorted(set(card) ^ set(fields))))
    for key, value in card.items():
        if key in TEXT_KEYS:
            _text(value, pol["text_limit"])
        elif key == "skill_version":
            if not isinstance(value, str) or not VER_RE.match(value):
                _fail("CARD_FIELD_NOT_ID", key)
        else:
            _walk_ids(value)
    return card


def _bound_roles(capability_id: str) -> list[str]:
    roles = _load(task_set.BINDING_PATH)["roles"]
    return sorted(r for r, caps in roles.items() if capability_id in caps)


def _caps() -> dict[str, dict[str, Any]]:
    return {c["capability_id"]: c for c in _load(REGISTRY)["capabilities"]}


def capability_card(capability_id: str, pol: dict[str, Any] | None = None) -> dict[str, Any]:
    pol = pol or _load(POLICY)
    row = _caps().get(capability_id)
    if row is None or row["retirement_state"] != "ACTIVE":
        _fail("CAPABILITY_NOT_ACTIVE", capability_id)
    card = {"capability_id": capability_id, "purpose": row.get("purpose", ""), "kind": row["kind"], "cost": row["context_tier"],
            "risk": pol["capability_risk"].get(capability_id, "LOW"), "roles": _bound_roles(capability_id)}
    return check_card(card, "CAPABILITY", pol)


def method_card(m: dict[str, Any], pol: dict[str, Any]) -> dict[str, Any]:
    return check_card({k: m[k] for k in pol["card_fields"]["METHOD"]}, "METHOD", pol)


def pattern_card(p: dict[str, Any], pol: dict[str, Any]) -> dict[str, Any]:
    slots = [{"slot": s["slot"], "role": s["role"], "capability_id": s["capability_id"], "after": list(s["after"]),
              "verifies": list(s.get("verifies", []))} for s in p["slots"]]
    return check_card({"pattern_id": p["pattern_id"], "purpose": p["purpose"], "trigger": p["trigger"],
                       "problem_classes": list(p["problem_classes"]), "slots": slots, "cost": p["cost"], "risk": p["risk"]}, "PATTERN", pol)


def skill_card(manifest: dict[str, Any], pol: dict[str, Any] | None = None) -> dict[str, Any]:
    """Skill→Planner 可見 Card：只取 skill_id／版本／capability id；描述、input_scope、其他欄位一概丟棄（DescGuard 式最小介面）。"""
    pol = pol or _load(POLICY)
    ids = []
    for ref in manifest.get("capabilities") or []:
        cid = str(ref).split(":", 1)[-1]
        if cid not in _caps() or _caps()[cid]["retirement_state"] != "ACTIVE":
            _fail("SKILL_CAPABILITY_NOT_ACTIVE", cid)
        ids.append(cid)
    if not ids:
        _fail("SKILL_CAPABILITIES_REQUIRED")
    return check_card({"skill_id": manifest.get("skill_id"), "skill_version": manifest.get("skill_version"), "capability_ids": ids}, "SKILL", pol)


def load_library() -> dict[str, Any]:
    """載入並驗證政策表：引用存在、role 綁定、Task Set 形狀（verifier 獨立）、route 覆蓋全部 problem class 且三條路徑相異。"""
    pol = _load(POLICY)
    classes, caps = set(pol["problem_classes"]), _caps()
    methods = {m["method_id"]: m for m in pol["methods"]}
    patterns = {p["pattern_id"]: p for p in pol["patterns"]}
    if len(methods) != len(pol["methods"]) or len(patterns) != len(pol["patterns"]):
        _fail("LIBRARY_DUPLICATE_ID")
    for m in methods.values():
        if not set(m["problem_classes"]) <= classes:
            _fail("METHOD_PROBLEM_CLASS_UNKNOWN", m["method_id"])
        for c in m["capability_ids"]:
            capability_card(c, pol)
        method_card(m, pol)
    for p in patterns.values():
        if not set(p["problem_classes"]) <= classes:
            _fail("PATTERN_PROBLEM_CLASS_UNKNOWN", p["pattern_id"])
        seen: dict[str, str] = {}
        for s in p["slots"]:
            sid = s["slot"]
            if sid in seen or s["role"] not in ROLES or not set(s["after"]) <= set(seen):
                _fail("PATTERN_SLOT_INVALID", f"{p['pattern_id']}:{sid}")
            if s.get("method_id") is not None and s["method_id"] not in methods:
                _fail("PATTERN_METHOD_UNKNOWN", f"{p['pattern_id']}:{s['method_id']}")
            try:
                task_set.assert_role_capability(s["role"], s["capability_id"])
            except ValueError:
                _fail("PATTERN_CAPABILITY_NOT_BOUND", f"{p['pattern_id']}:{sid}")
            targets = s.get("verifies")
            if s["role"] == "ROLE:VERIFIER":
                if not targets or any(seen.get(t) != "ROLE:EXECUTOR" or t not in s["after"] for t in targets):
                    _fail("PATTERN_VERIFIER_INVALID", f"{p['pattern_id']}:{sid}")
            elif targets is not None:
                _fail("PATTERN_VERIFIES_ONLY_FOR_VERIFIER", f"{p['pattern_id']}:{sid}")
            seen[sid] = s["role"]
        if "ROLE:VERIFIER" not in seen.values():
            _fail("PATTERN_NEEDS_VERIFIER", p["pattern_id"])
        pattern_card(p, pol)
    if set(pol["routes"]) != classes:
        _fail("ROUTES_MUST_COVER_ALL_PROBLEM_CLASSES")
    for cls, route in pol["routes"].items():
        chain = [route["preferred"], route["alternative"], route["fallback"]]
        if len(set(chain)) != 3 or not set(chain) <= set(patterns):
            _fail("ROUTE_INVALID", cls)
        if cls not in patterns[route["preferred"]]["problem_classes"]:
            _fail("ROUTE_PREFERRED_CLASS_MISMATCH", cls)
    return {"policy": pol, "methods": methods, "patterns": patterns}


def planner_index(problem_class: str | None = None) -> dict[str, list[dict[str, Any]]]:
    """Planner 預設可見的全部資訊：Capability／Method／Pattern Card（可依 problem class 過濾 Method／Pattern）。"""
    lib = load_library()
    pol = lib["policy"]
    if problem_class is not None and problem_class not in pol["problem_classes"]:
        _fail("PROBLEM_CLASS_UNKNOWN", problem_class)
    bound = {c for caps in _load(task_set.BINDING_PATH)["roles"].values() for c in caps}
    keep = lambda x: problem_class is None or problem_class in x["problem_classes"]  # noqa: E731
    return {"capabilities": [capability_card(c, pol) for c in sorted(_caps()) if c in bound and _caps()[c]["retirement_state"] == "ACTIVE"],
            "methods": [method_card(m, pol) for m in lib["methods"].values() if keep(m)],
            "patterns": [pattern_card(p, pol) for p in lib["patterns"].values() if keep(p)]}


def select_patterns(problem_class: str) -> list[str]:
    """Preferred／Alternative／Fallback 順序（Brain 不依賴單一路徑）。"""
    route = load_library()["policy"]["routes"].get(problem_class)
    if route is None:
        _fail("PROBLEM_CLASS_UNKNOWN", problem_class)
    return [route["preferred"], route["alternative"], route["fallback"]]


def validate_problem_model(model: dict[str, Any]) -> None:
    pol = _load(POLICY)
    if set(model) != {"problem_class", "epistemic_state"}:
        _fail("PROBLEM_MODEL_FIELDS")
    if model["problem_class"] not in pol["problem_classes"]:
        _fail("PROBLEM_CLASS_UNKNOWN", str(model["problem_class"])[:40])
    if model["epistemic_state"] not in pol["epistemic_states"]:
        _fail("EPISTEMIC_STATE_UNKNOWN", str(model["epistemic_state"])[:40])


def assemble_team(pattern_id: str, *, task_set_ref: str, revision: int, correlation_id: str, diagnosis_ref: str, input_ref: str,
                  prefix: str, evidence_refs: list[str] | None = None, supersedes: str | None = None) -> dict[str, Any]:
    """Pattern→可發行的 TASK_SET_ISSUED（只用既有 3 role）。回 {control_output, dependencies{task_id:[task_id]}}；
    dependencies 供建立 segment 的 dependency_refs。Team 不留存：無任何 Team 物件，解散＝該 Task Set 被取代或完成。"""
    pat = load_library()["patterns"].get(pattern_id)
    if pat is None:
        _fail("PATTERN_UNKNOWN", pattern_id)
    tid = lambda slot: f"{prefix}-{slot}"  # noqa: E731
    refs, deps = [], {}
    for s in pat["slots"]:
        ref = {"task_id": tid(s["slot"]), "role": s["role"], "capability_id": s["capability_id"], "input_ref": input_ref,
               "output_contract_id": f"OC-{s['slot']}"}
        if s.get("verifies"):
            ref["verifies"] = [tid(t) for t in s["verifies"]]
        refs.append(ref)
        deps[ref["task_id"]] = [tid(a) for a in s["after"]]
    out = {"decision_code": "TASK_SET_ISSUED", "diagnosis_ref": diagnosis_ref, "evidence_refs": list(evidence_refs or []),
           "changed_plan_refs": [], "task_set_ref": task_set_ref, "revision": revision, "correlation_id": correlation_id,
           "supersedes": supersedes, "task_refs": refs}
    task_set.validate_control_output(out)
    return {"control_output": out, "dependencies": deps}



def _tier_rank(tier: str) -> int:
    rank = {"C1": 1, "C2": 2, "C3": 3}
    if tier not in rank:
        _fail("CAPABILITY_CONTEXT_TIER_INVALID", str(tier))
    return rank[tier]


def _validate_evidence_refs(values: Any, field: str, maximum: int = 20) -> None:
    if not isinstance(values, list) or len(values) > maximum:
        _fail("CAPABILITY_EVIDENCE_REFS_INVALID", field)
    for ref in values:
        if (
            not isinstance(ref, str) or not ref.strip() or len(ref) > 500
            or ref.strip().startswith(("/", "\\"))
            or ".." in Path(ref.strip()).parts
        ):
            _fail("CAPABILITY_EVIDENCE_REF_INVALID", field)


def _capability_usage(capability_id: str, pol: dict[str, Any], caps: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Read-only cross-reference check against the current registry, role bindings and Planner policy."""
    bindings = _load(task_set.BINDING_PATH)["roles"]
    bound_roles = sorted(role for role, ids in bindings.items() if capability_id in ids)
    methods = sorted(m["method_id"] for m in pol["methods"] if capability_id in m.get("capability_ids", []))
    patterns = sorted(
        p["pattern_id"] for p in pol["patterns"]
        if any(slot.get("capability_id") == capability_id for slot in p.get("slots", []))
    )
    dependents = sorted(cid for cid, row in caps.items() if capability_id in row.get("dependencies", []))
    return {"bound_roles": bound_roles, "methods": methods, "patterns": patterns, "dependents": dependents}


def _cap_lifecycle_result(
    request: dict[str, Any],
    *,
    status: str,
    decision: str,
    selected_ids: list[str] | None = None,
    selected_cards: list[dict[str, Any]] | None = None,
    checks: list[dict[str, str]] | None = None,
    blockers: list[str] | None = None,
    warnings: list[str] | None = None,
    scope_ref: str | None = None,
    next_action: str,
) -> dict[str, Any]:
    result = {
        "request_id": request["request_id"],
        "action": request["action"],
        "status": status,
        "decision": decision,
        "selected_capability_ids": selected_ids or [],
        "selected_cards": selected_cards or [],
        "checks": checks or [],
        "blockers": blockers or [],
        "warnings": warnings or [],
        "scope_ref": scope_ref,
        "execution_authorized": False,
        "registry_written": False,
        "next_action": next_action,
    }
    schema_path = ROOT / "P1-Central-Control/schemas/capability_lifecycle_decision.schema.json"
    try:
        from jsonschema import Draft202012Validator
        schema = _load(schema_path)
        Draft202012Validator.check_schema(schema)
        Draft202012Validator(schema).validate(result)
    except Exception as exc:
        _fail("CAPABILITY_LIFECYCLE_RESULT_INVALID", type(exc).__name__ + ":" + str(exc)[:300])
    return result


def review_capability_lifecycle(request: dict[str, Any]) -> dict[str, Any]:
    """F18: select an active bound capability set, review admission, or prepare a safe retirement review.

    This function is advisory and read-only. New capabilities still require the existing
    Construction Factory's accepted registration path; retirement requires separate approval
    and the existing lifecycle/rollback owners. It never edits the registry or role bindings.
    """
    if not isinstance(request, dict):
        _fail("CAPABILITY_LIFECYCLE_REQUEST_INVALID")
    request_schema_path = ROOT / "P1-Central-Control/schemas/capability_lifecycle_request.schema.json"
    try:
        from jsonschema import Draft202012Validator
        request_schema = _load(request_schema_path)
        Draft202012Validator.check_schema(request_schema)
        Draft202012Validator(request_schema).validate(request)
    except Exception as exc:
        _fail("CAPABILITY_LIFECYCLE_REQUEST_INVALID", type(exc).__name__ + ":" + str(exc)[:300])

    pol = _load(POLICY)
    caps = _caps()
    action = request["action"]
    scope_ref = request.get("scope_ref") if isinstance(request.get("scope_ref"), str) else None
    checks: list[dict[str, str]] = []
    warnings: list[str] = []

    def check(key: str, status: str, detail: str) -> None:
        checks.append({"check_id": key, "status": status, "detail": detail})

    if action == "SELECT_FOR_NEED":
        role = request["role_id"]
        problem = request["problem_class"]
        if problem not in pol["problem_classes"]:
            return _cap_lifecycle_result(
                request, status="BLOCKED_UNKNOWN", decision="Unknown problem class; no capability set selected.",
                checks=[{"check_id":"PROBLEM_CLASS","status":"FAIL","detail":str(problem)}],
                blockers=["PROBLEM_CLASS_UNKNOWN"], next_action="Map the request to a declared Planner problem class.",
            )
        required = request["required_capability_ids"]
        optional = request.get("optional_capability_ids", [])
        if len(required) != len(set(required)) or len(optional) != len(set(optional)) or set(required) & set(optional):
            _fail("CAPABILITY_SET_DUPLICATED")
        candidates = list(required) + (list(optional) if request.get("include_optional", False) else [])
        if len(candidates) > 12:
            _fail("CAPABILITY_SELECTION_OVER_LIMIT")
        chosen: list[dict[str, Any]] = []
        blockers: list[str] = []
        for cid in candidates:
            row = caps.get(cid)
            is_required = cid in required
            if row is None:
                code = f"CAPABILITY_UNKNOWN:{cid}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Capability is absent from the current registry.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            if row.get("retirement_state") != "ACTIVE":
                code = f"CAPABILITY_NOT_ACTIVE:{cid}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Retired or non-active capability cannot be selected.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            bound_roles = _bound_roles(cid)
            if role not in bound_roles:
                code = f"CAPABILITY_ROLE_NOT_BOUND:{cid}:{role}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Current role binding does not authorize this capability.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            budget = request["context_budget"]
            if _tier_rank(row.get("context_tier")) > _tier_rank(budget):
                code = f"CAPABILITY_CONTEXT_BUDGET_EXCEEDED:{cid}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Capability context tier exceeds the caller's explicit budget.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            missing_deps = [dep for dep in row.get("dependencies", []) if dep not in caps or caps[dep].get("retirement_state") != "ACTIVE"]
            if missing_deps:
                code = f"CAPABILITY_DEPENDENCY_UNAVAILABLE:{cid}:{','.join(missing_deps)}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Capability dependency is missing or inactive.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            # A destructive capability (for example CAP-RETIRE) is never selected by a
            # generic planner request; it must use its separate authority/lifecycle flow.
            if row.get("risk") == "DESTRUCTIVE":
                code = f"DESTRUCTIVE_CAPABILITY_REQUIRES_SEPARATE_AUTHORIZATION:{cid}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Destructive capabilities are not admitted through generic selection.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            supported_classes = set()
            for method in pol["methods"]:
                if cid in method.get("capability_ids", []):
                    supported_classes.update(method.get("problem_classes", []))
            for pattern in pol["patterns"]:
                if any(slot.get("capability_id") == cid for slot in pattern.get("slots", [])):
                    supported_classes.update(pattern.get("problem_classes", []))
            if problem not in supported_classes:
                code = f"CAPABILITY_PROBLEM_CLASS_MISMATCH:{cid}:{problem}"
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Current Planner policy does not map this capability to the requested problem class.")
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                continue
            try:
                card = capability_card(cid, pol)
            except ValueError as exc:
                code = f"CAPABILITY_CARD_INVALID:{cid}:{str(exc).split(':',1)[0]}"
                if is_required:
                    blockers.append(code)
                else:
                    warnings.append(code)
                check(f"CAPABILITY:{cid}", "FAIL" if is_required else "UNKNOWN", "Capability card failed the policy whitelist.")
                continue
            chosen.append(card)
            check(f"CAPABILITY:{cid}", "PASS", "Active, role-bound, dependency-valid and within explicit context budget.")
        if blockers:
            return _cap_lifecycle_result(
                request, status=(
                    "BLOCKED_ROLE" if any("ROLE_NOT_BOUND" in x for x in blockers)
                    else "BLOCKED_BUDGET" if any("BUDGET_EXCEEDED" in x for x in blockers)
                    else "BLOCKED_AUTHORITY" if any("DESTRUCTIVE_CAPABILITY_REQUIRES_SEPARATE_AUTHORIZATION" in x for x in blockers)
                    else "BLOCKED_UNKNOWN" if any("CAPABILITY_UNKNOWN" in x or "PROBLEM_CLASS_MISMATCH" in x for x in blockers)
                    else "BLOCKED_DEPENDENCY"
                ),
                decision="One or more required capabilities did not pass the current registry, role, dependency and budget gates.",
                selected_ids=[x["capability_id"] for x in chosen], selected_cards=chosen,
                checks=checks, blockers=blockers, warnings=warnings, scope_ref=scope_ref,
                next_action="Reconcile required capability bindings/dependencies or adjust the explicit context budget; do not auto-add a capability.",
            )
        return _cap_lifecycle_result(
            request, status="SELECTED",
            decision="The selected capabilities are active, explicitly bound to the requesting role, dependency-valid and within the declared context budget.",
            selected_ids=[x["capability_id"] for x in chosen], selected_cards=chosen,
            checks=checks, warnings=warnings, scope_ref=scope_ref,
            next_action="Pass the bounded Card set to the existing Brain/Planner; any new role binding or registry change requires a separate accepted Construction Factory request.",
        )

    if action == "ADMIT_CANDIDATE":
        cid = request["capability_id"]
        if cid in caps:
            row = caps[cid]
            status = "BLOCKED_DUPLICATE" if row.get("retirement_state") == "ACTIVE" else "NEEDS_EVIDENCE"
            check("CAPABILITY_ID_UNIQUE", "FAIL" if status == "BLOCKED_DUPLICATE" else "UNKNOWN", "The ID already exists in the authoritative registry.")
            return _cap_lifecycle_result(
                request, status=status,
                decision="Do not create a duplicate capability ID; evaluate/reevaluate the existing authoritative row instead.",
                checks=checks, blockers=[f"CAPABILITY_ID_ALREADY_EXISTS:{cid}"] if status == "BLOCKED_DUPLICATE" else [],
                warnings=["Existing P1 registry rows are not automatically promoted to validated P2 capabilities."],
                next_action="Use the existing row only within its current status/bindings, or propose a separately justified registry amendment.",
            )
        problem_classes = set(pol["problem_classes"])
        invalid_classes = sorted(set(request["target_problem_classes"]) - problem_classes)
        if invalid_classes:
            check("TARGET_PROBLEM_CLASSES", "FAIL", "Candidate references problem classes not in current Planner policy.")
            return _cap_lifecycle_result(
                request, status="BLOCKED_UNKNOWN", decision="Candidate problem-class scope is not recognized.",
                checks=checks, blockers=["PROBLEM_CLASS_UNKNOWN:"+",".join(invalid_classes)],
                next_action="Map the candidate to the current policy problem classes before registration.",
            )
        source_refs = request["source_refs"]
        for field in ("source_refs", "acceptance_criteria_refs", "failure_mode_refs", "validation_evidence_refs"):
            _validate_evidence_refs(request[field], field)
        _validate_evidence_refs(request["alternatives_considered"], "alternatives_considered")
        _validate_evidence_refs(request["overlap_capability_ids"], "overlap_capability_ids")
        if request.get("scope_ref") is not None:
            _validate_evidence_refs([request["scope_ref"]], "scope_ref", 1)
        required_ref_fields = {
            "ACCEPTANCE_CRITERIA": request["acceptance_criteria_refs"],
            "FAILURE_MODES": request["failure_mode_refs"],
            "VALIDATION_EVIDENCE": request["validation_evidence_refs"],
            "ALTERNATIVES": request["alternatives_considered"],
        }
        missing = [key for key, values in required_ref_fields.items() if not values]
        check("SOURCE_AUTHORITY", "PASS" if request["source_authority"] == "AUTHORIZED" else "FAIL", "Candidate source/owner must be authorized.")
        check("SOURCE_EVIDENCE", "PASS" if source_refs else "FAIL", "At least one source reference is required.")
        check("TARGET_SCOPE", "PASS" if request["target_problem_classes"] else "FAIL", "Candidate must declare target problem classes.")
        check("ROLE_SCOPE", "PASS" if request["intended_roles"] else "FAIL", "Candidate must declare its intended role scope.")
        check("CONTEXT_BUDGET", "PASS" if _tier_rank(request["context_tier"]) <= _tier_rank(request["budget_context_tier"]) else "FAIL", "Candidate context tier must fit the explicit budget.")
        check("CONTRACT_COMPATIBILITY", "PASS" if request["compatibility_status"] == "COMPATIBLE" else "FAIL", "Candidate must be compatible with the current P2 contract.")
        check("MAINTENANCE_BURDEN", "PASS" if request["maintenance_burden"] != "HIGH" or len(request["alternatives_considered"]) >= 2 else "UNKNOWN", "High-maintenance candidates require at least two compared alternatives.")
        check("DISTINCT_VALUE", "PASS" if request["distinct_value_explanation"].strip() else "FAIL", "Candidate must explain why active overlapping capabilities do not already satisfy the need.")
        check("REQUIRED_EVIDENCE_SET", "PASS" if not missing else "FAIL", "Acceptance criteria, failure modes, validation evidence and alternatives are explicit.")
        active_overlaps = sorted(cid2 for cid2 in request["overlap_capability_ids"] if cid2 in caps and caps[cid2].get("retirement_state") == "ACTIVE")
        unknown_overlaps = sorted(cid2 for cid2 in request["overlap_capability_ids"] if cid2 not in caps)
        if request["source_authority"] != "AUTHORIZED":
            return _cap_lifecycle_result(request,status="BLOCKED_AUTHORITY",decision="Candidate source authority is unverified or conflicting.",checks=checks,blockers=["CAPABILITY_SOURCE_AUTHORITY_NOT_CONFIRMED"],scope_ref=scope_ref,next_action="Confirm source and owner authority before admission.")
        if not source_refs or not request["target_problem_classes"] or not request["intended_roles"] or missing:
            return _cap_lifecycle_result(request,status="NEEDS_EVIDENCE",decision="Candidate admission evidence is incomplete.",checks=checks,blockers=["CAPABILITY_ADMISSION_EVIDENCE_INCOMPLETE"],scope_ref=scope_ref,next_action="Supply source, scope, acceptance, failure-mode, validation and alternative evidence.")
        if request["compatibility_status"] == "UNKNOWN":
            return _cap_lifecycle_result(request,status="NEEDS_EVIDENCE",decision="Compatibility remains unknown; candidate is not admissible yet.",checks=checks,blockers=["CAPABILITY_COMPATIBILITY_UNKNOWN"],scope_ref=scope_ref,next_action="Produce compatibility evidence against existing contracts.")
        if request["compatibility_status"] != "COMPATIBLE":
            return _cap_lifecycle_result(request,status="BLOCKED_CONFLICT",decision="Candidate conflicts with the current contract.",checks=checks,blockers=["CAPABILITY_COMPATIBILITY_CONFLICT"],scope_ref=scope_ref,next_action="Resolve or redesign the conflict before registration.")
        if _tier_rank(request["context_tier"]) > _tier_rank(request["budget_context_tier"]):
            return _cap_lifecycle_result(request,status="BLOCKED_BUDGET",decision="Candidate exceeds the explicit context budget.",checks=checks,blockers=["CAPABILITY_CONTEXT_BUDGET_EXCEEDED"],scope_ref=scope_ref,next_action="Reduce context cost or obtain a separately approved budget change.")
        if unknown_overlaps:
            return _cap_lifecycle_result(request,status="NEEDS_EVIDENCE",decision="Possible overlap references include unknown registry IDs.",checks=checks,blockers=["CAPABILITY_OVERLAP_REFERENCES_UNKNOWN:"+",".join(unknown_overlaps)],scope_ref=scope_ref,next_action="Resolve each overlap reference against the authoritative registry.")
        if active_overlaps and len(request["distinct_value_explanation"].strip()) < 32:
            return _cap_lifecycle_result(request,status="BLOCKED_DUPLICATE",decision="Active capability overlap is declared, but the distinct-value justification is insufficient.",checks=checks,blockers=["CAPABILITY_DUPLICATE_OR_UNJUSTIFIED_OVERLAP"],scope_ref=scope_ref,next_action="Reuse/evaluate the active capability or provide a concrete differentiated contract and measured rationale.")
        if request["maintenance_burden"] == "HIGH" and len(request["alternatives_considered"]) < 2:
            return _cap_lifecycle_result(request,status="NEEDS_EVIDENCE",decision="High-maintenance candidate lacks a sufficient alternative comparison.",checks=checks,blockers=["CAPABILITY_MAINTENANCE_COST_UNJUSTIFIED"],scope_ref=scope_ref,next_action="Compare at least two alternatives and document lifecycle/retirement cost.")
        if not request["rollback_ref"].strip():
            return _cap_lifecycle_result(request,status="NEEDS_EVIDENCE",decision="Candidate has no explicit rollback/removal path.",checks=checks,blockers=["CAPABILITY_ROLLBACK_MISSING"],scope_ref=scope_ref,next_action="Declare a rollback/removal plan before registration.")
        return _cap_lifecycle_result(
            request, status="READY_FOR_CONSTRUCTION_REVIEW",
            decision="Candidate passed the evidence, authority, scope, context-budget, compatibility, duplication and lifecycle checks; this is still a proposal, not an admission or registry write.",
            checks=checks, scope_ref=scope_ref,
            warnings=["A separate authorized Construction Factory registration and subsequent validation are still required."],
            next_action="Route this bounded proposal to the existing Construction Factory; do not edit the registry directly.",
        )

    # RETIRE_CANDIDATE: review only, never delete or alter registry here.
    cid = request["capability_id"]
    row = caps.get(cid)
    if row is None:
        return _cap_lifecycle_result(
            request,status="BLOCKED_UNKNOWN",decision="Capability ID is absent from the authoritative registry.",
            checks=[{"check_id":"CAPABILITY_EXISTS","status":"FAIL","detail":cid}],
            blockers=["CAPABILITY_UNKNOWN:"+cid],scope_ref=scope_ref,
            next_action="Confirm the exact capability identity; do not treat an unscanned artifact as present or absent.",
        )
    if row.get("retirement_state") != "ACTIVE":
        return _cap_lifecycle_result(
            request,status="NEEDS_EVIDENCE",decision="Capability is already non-active; do not retire it a second time.",
            checks=[{"check_id":"CAPABILITY_ACTIVE","status":"UNKNOWN","detail":str(row.get("retirement_state"))}],
            blockers=["CAPABILITY_NOT_ACTIVE:"+cid],scope_ref=scope_ref,
            next_action="Use the current lifecycle status and reevaluation history instead of replaying retirement.",
        )
    for field in ("retirement_impact_scan_ref", "migration_plan_ref", "rollback_ref"):
        _validate_evidence_refs([request[field]], field, 1)
    if request.get("scope_ref") is not None:
        _validate_evidence_refs([request["scope_ref"]], "scope_ref", 1)
    usage = _capability_usage(cid, pol, caps)
    refs_exist = bool(usage["bound_roles"] or usage["methods"] or usage["patterns"] or usage["dependents"])
    replacement_id = request.get("replacement_capability_id")
    replacement = caps.get(replacement_id) if isinstance(replacement_id, str) else None
    replacement_is_active = isinstance(replacement, dict) and replacement.get("retirement_state") == "ACTIVE" and replacement_id != cid
    if replacement_is_active:
        replacement_roles = set(_bound_roles(replacement_id))
        if not set(usage["bound_roles"]) <= replacement_roles:
            warnings.append("Replacement capability does not preserve every current role binding.")
            replacement_is_active = False
    check("RETIREMENT_IMPACT_SCAN", "PASS" if request["retirement_impact_scan_status"] == "COMPLETE" and request["retirement_impact_scan_ref"].strip() else "FAIL", "A complete impact scan with a source reference is required.")
    check("MIGRATION", "PASS" if request["migration_plan_ref"].strip() else "FAIL", "A migration plan must preserve callers and role/pattern coverage.")
    check("ROLLBACK", "PASS" if request["rollback_ref"].strip() else "FAIL", "A recoverable rollback reference is mandatory.")
    check("USER_CONFIRMATION", "PASS" if request["user_confirmation"] else "FAIL", "Capability retirement requires explicit confirmation.")
    check("GOVERNANCE", "PASS" if request["governance_approval"] else "FAIL", "Capability retirement requires Governance review.")
    check("REFERENCES", "PASS" if not refs_exist else ("PASS" if replacement_is_active else "FAIL"),
          "Current role bindings, methods, patterns and reverse dependencies must be migrated to an active replacement before retirement.")
    if request["retirement_impact_scan_status"] != "COMPLETE" or not request["retirement_impact_scan_ref"].strip():
        return _cap_lifecycle_result(request,status="NEEDS_EVIDENCE",decision="Retirement impact scan is incomplete.",checks=checks,blockers=["CAPABILITY_RETIREMENT_SCAN_INCOMPLETE"],scope_ref=scope_ref,next_action="Run and review the targeted impact scan before considering retirement.")
    if refs_exist and not (request.get("replacement_capability_id") in caps and caps[request["replacement_capability_id"]].get("retirement_state") == "ACTIVE"):
        return _cap_lifecycle_result(request,status="BLOCKED_RETIREMENT",decision="Capability is still bound or referenced; no active replacement is established.",checks=checks,blockers=["CAPABILITY_STILL_REFERENCED"],warnings=[f"bound_roles={usage['bound_roles']}",f"methods={usage['methods']}",f"patterns={usage['patterns']}",f"dependents={usage['dependents']}"],scope_ref=scope_ref,next_action="Map all active references to a compatible active replacement and migrate them through authorized contracts.")
    if not request["migration_plan_ref"].strip() or not request["rollback_ref"].strip() or not request["user_confirmation"] or not request["governance_approval"]:
        return _cap_lifecycle_result(request,status="BLOCKED_RETIREMENT",decision="Retirement lacks one or more mandatory migration/rollback/authority approvals.",checks=checks,blockers=["CAPABILITY_RETIREMENT_GATES_INCOMPLETE"],scope_ref=scope_ref,next_action="Complete the migration and rollback plans, then obtain user confirmation and Governance approval.")
    return _cap_lifecycle_result(
        request,status="READY_FOR_RETIREMENT_REVIEW",
        decision="The capability's current references were inspected and required approval/recovery evidence is present; retirement is only ready for independent review, not execution.",
        checks=checks,scope_ref=scope_ref,
        warnings=[f"bound_roles={usage['bound_roles']}",f"methods={usage['methods']}",f"patterns={usage['patterns']}",f"dependents={usage['dependents']}"],
        next_action="Route to the designated capability lifecycle owner and independent Verifier; make any registry/lifecycle change only through the existing authorized path.",
    )


def evaluate_promotion(record: dict[str, Any]) -> dict[str, Any]:
    """L4 升格：HOLD／PROMOTE＋reason codes。次數為算術；四項準則須由 adjudication（by＋rationale＋各項 true）提供——判斷歸 CONTROL_RESEARCH。"""
    rule = _load(POLICY)["promotion"]
    frm, to, n = record.get("from_level"), record.get("to_level"), record.get("repeat_count")
    if not isinstance(n, int) or isinstance(n, bool) or n < 0 or frm not in rule["transitions"]:
        _fail("PROMOTION_RECORD_INVALID")
    reasons: list[str] = []
    step = rule["transitions"][frm]
    if to not in step["to"]:
        reasons.append("TRANSITION_NOT_ALLOWED")
    if n < step["min_repeat"]:
        reasons.append("REPEAT_BELOW_MIN")
    adj = record.get("adjudication")
    if not isinstance(adj, dict) or not adj.get("by") or not adj.get("rationale"):
        reasons.append("ADJUDICATION_REQUIRED")
    else:
        reasons += [f"CRITERION_NOT_MET:{c}" for c in rule["adjudicated"] if adj.get(c) is not True]
    return {"decision": "HOLD" if reasons else "PROMOTE", "reasons": reasons}


def validate_decision_brief(brief: dict[str, Any]) -> None:
    """E2：Discussion／Decision Method 的輸出契約（固定段落；EVIDENCE 只收 ref；RECOMMENDATION 須指向 OPTIONS 之一）。"""
    sections = _load(POLICY)["decision_brief_sections"]
    if set(brief) != set(sections):
        _fail("BRIEF_SECTIONS", ",".join(sorted(set(brief) ^ set(sections))))
    lists = ("OPTIONS", "ASSUMPTIONS", "EVIDENCE", "TRADEOFFS", "UNRESOLVED")
    for key in lists:
        if not isinstance(brief[key], list) or not all(isinstance(x, str) and x for x in brief[key]):
            _fail("BRIEF_LIST_INVALID", key)
    if not isinstance(brief["ISSUE"], str) or not brief["ISSUE"] or not isinstance(brief["DECISION_BOUNDARY"], str) or not brief["DECISION_BOUNDARY"]:
        _fail("BRIEF_TEXT_REQUIRED")
    if len(brief["OPTIONS"]) < 2:
        _fail("BRIEF_OPTIONS_MIN_2")
    if not all(re.match(r"^[A-Z][A-Z0-9_]{2,63}:[A-Za-z0-9._-]+$", r) for r in brief["EVIDENCE"]):
        _fail("BRIEF_EVIDENCE_NOT_REF")
    rec = brief["RECOMMENDATION"]
    if not isinstance(rec, dict) or set(rec) != {"option", "rationale"} or not rec["rationale"] or type(rec["option"]) is not int or rec["option"] not in range(len(brief["OPTIONS"])):
        _fail("BRIEF_RECOMMENDATION_INVALID")


# --- R4L-S4 / FR-13: capability cards loaded by Brief slot (no whole-library read) -----------------------------
FUNCTION_REGISTRY = ROOT / "P1-Central-Control/function_capability_registry.json"
SLOTS_PATH = ROOT / "P1-Central-Control/brief_slots.json"
MAX_SLOT_CARDS = 20


def cards_for_slots(slot_ids: list[str], slots_cfg: dict[str, Any] | None = None,
                    functions: dict[str, dict[str, Any]] | None = None, pol: dict[str, Any] | None = None) -> dict[str, Any]:
    """Slot -> function_id -> canonical capability -> Card.  Order = slot order, one card per capability.
    Unknown slot / unmapped function / non-ACTIVE capability fail closed; slots without a capability are listed in `skipped`."""
    cfg = slots_cfg if slots_cfg is not None else _load(SLOTS_PATH)
    fx = functions if functions is not None else {r["function_id"]: r for r in _load(FUNCTION_REGISTRY)["functions"]}
    pol = pol or _load(POLICY)
    cards: list[dict[str, Any]] = []
    seen: set[str] = set()
    skipped: list[str] = []
    for sid in slot_ids:
        slot = cfg["slots"].get(sid)
        if slot is None:
            _fail("SLOT_UNDEFINED", sid)
        fid = slot.get("function_id")
        if not fid:
            skipped.append(sid)
            continue
        row = fx.get(fid)
        if row is None:
            _fail("FUNCTION_UNMAPPED", f"{sid}:{fid}")
        cap = row.get("canonical_capability")
        if not cap:
            skipped.append(sid)
            continue
        if cap in seen:
            continue
        seen.add(cap)
        cards.append(capability_card(cap, pol))
        if len(cards) > MAX_SLOT_CARDS:
            _fail("SLOT_CARDS_OVER_LIMIT", str(len(cards)))
    return {"cards": cards, "skipped": skipped}


def cards_for_route(route: str, slots_cfg: dict[str, Any] | None = None, **kw: Any) -> dict[str, Any]:
    cfg = slots_cfg if slots_cfg is not None else _load(SLOTS_PATH)
    if route not in cfg["routes"]:
        _fail("ROUTE_UNDEFINED", route)
    return cards_for_slots(cfg["routes"][route]["required_slots"], cfg, **kw)


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--cards":
        print(json.dumps(cards_for_route(sys.argv[2]), ensure_ascii=False, indent=1))
    else:
        print("usage: planner_library.py --cards <ROUTE>   (cards loaded by Brief slot, FR-13)")

