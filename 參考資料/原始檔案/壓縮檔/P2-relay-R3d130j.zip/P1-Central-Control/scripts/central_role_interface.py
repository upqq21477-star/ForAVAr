#!/usr/bin/env python3
"""Minimal Central-mediated interface for locked P1 roles.

This module is an adapter over existing canonical owners. It does not own
Current, State, Result, Retry, Acceptance, or Session truth.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, ValidationError

from acceptance_context import create_acceptance_context
from change_classification_router import ChangeClassificationError, classify_and_route, validate_record
from intent_resolution import IntentResolutionError, resolve_intent, validate_result
from system_factory_strategy import FactoryStrategyError, decide_strategy, validate_result as validate_factory_strategy_result
from planner_library import review_capability_lifecycle
from root_cause_distillation import RootCauseDistillationError, distill_root_cause
from blueprint_update_transaction import (BlueprintUpdateError, assess_update, validate_request as validate_blueprint_update_request, validate_result as validate_blueprint_update_result)
from construction_efficiency_review import generate_review as generate_construction_health_review
from feature_batch_orchestrator import (
    BatchGateError, advance_phase, inspect_batch, mark_feature_implemented,
    prepare_official_test_roster, validate_final_test_gate,
)
from brain_mode_controller import (
    MIN_PLAN_EVIDENCE_CHARS,
    ROLE_EVENTS,
    build_role_supervision_context,
    initial_control_state,
    transition_mode,
)

ROOT = Path(__file__).resolve().parents[2]
REQUEST_SCHEMA = ROOT / "P1-Central-Control/schemas/central_role_interface.schema.json"
SHORTCUT_TO_ROLE = {
    "！施工": ("ROLE:EXECUTOR", "IP:CONSTRUCTION-EXECUTOR", "CONSTRUCTION"),
    "！驗收": ("ROLE:VERIFIER", "IP:ACCEPTANCE-VERIFIER", "ACCEPTANCE"),
    "！討論": ("ROLE:CONTROL_RESEARCH", "IP:CONTROL-DISCUSSION", "DISCUSSION"),
    "！指導": ("ROLE:CONTROL_RESEARCH", "IP:GUIDANCE-REVIEW", "GUIDANCE"),
}

# Which result_status each role may submit to Central. PASS/FAIL are verdicts and
# belong to the Verifier only; WORK_COMPLETE is a construction claim and belongs to
# the Executor only. Control can never emit a verdict (it cannot produce VERIFIED).
ALLOWED_RESULT_STATUS = {
    "ROLE:EXECUTOR": {None, "WORK_COMPLETE", "INCOMPLETE", "BLOCK", "UNRESOLVED"},
    "ROLE:VERIFIER": {None, "PASS", "FAIL", "BLOCK", "INCOMPLETE"},
    "ROLE:CONTROL_RESEARCH": {None, "TASK_SET_ISSUED", "NEEDS_INPUT", "NO_ACTION_REQUIRED", "BLOCKED", "UNRESOLVED"},
}

EXECUTOR_READY_STATUSES = {"READY", "BUILDING", "CHANGE_OBSERVED", "IN_PROGRESS"}
VERIFIER_STAGE_STATUSES = {
    "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
    "READY_FOR_CLOSE_ACCEPTANCE",
}
PENDING_STAGE_STATUSES = VERIFIER_STAGE_STATUSES


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def validate_request(request: dict[str, Any]) -> None:
    schema = load(REQUEST_SCHEMA)
    Draft202012Validator(schema).validate(request)


def _validate_document_schema(
    root: Path,
    document: dict[str, Any],
    schema_ref: str,
    error_code: str,
) -> None:
    """Fail before persistence if a lifecycle update would violate its authoritative schema."""
    schema_path = root.resolve() / schema_ref
    try:
        schema = load(schema_path)
        Draft202012Validator.check_schema(schema)
    except Exception as exc:
        raise ValueError(f"{error_code}_SCHEMA_UNAVAILABLE:{type(exc).__name__}") from exc
    try:
        Draft202012Validator(schema).validate(document)
    except ValidationError as exc:
        message = str(exc.message).replace("\n", " ")[:500]
        raise ValueError(f"{error_code}_SCHEMA_INVALID:{message}") from exc


def _set_construction_lifecycle_note(construction: dict[str, Any], message: str) -> None:
    """Store lifecycle guidance only in schema-owned Construction handoff fields."""
    handoff = construction.get("handoff")
    if not isinstance(handoff, dict):
        raise ValueError("CONSTRUCTION_HANDOFF_OBJECT_REQUIRED")
    notes = handoff.get("notes", [])
    if not isinstance(notes, list) or any(not isinstance(item, str) for item in notes):
        raise ValueError("CONSTRUCTION_HANDOFF_NOTES_INVALID")
    prefix = "B2.2 lifecycle:"
    handoff["notes"] = [item for item in notes if not item.startswith(prefix)]
    handoff["notes"].append(f"{prefix} {message}")


def _validate_operational_lifecycle_payloads(
    root: Path,
    *,
    current: dict[str, Any],
    work: dict[str, Any],
    construction: dict[str, Any],
    context: dict[str, Any],
) -> None:
    _validate_document_schema(
        root, current, "P1-Central-Control/schemas/p1_current.schema.json",
        "OPERATIONAL_LIFECYCLE_CURRENT",
    )
    _validate_document_schema(
        root, work, "P1-Central-Control/schemas/operational_work_unit.schema.json",
        "OPERATIONAL_LIFECYCLE_WORK",
    )
    _validate_document_schema(
        root, construction, "P1-Central-Control/schemas/construction_packet.schema.json",
        "OPERATIONAL_LIFECYCLE_CONSTRUCTION",
    )
    _validate_document_schema(
        root, context, "P1-Central-Control/schemas/operational_acceptance_context.schema.json",
        "OPERATIONAL_LIFECYCLE_CONTEXT",
    )


def _stage_work_unit_id(stage: dict[str, Any]) -> str | None:
    """Resolve one stage identity with the Pack Builder's precedence and fail closed."""
    candidate = stage.get("work_unit_id") or stage.get("slice_id") or stage.get("id")
    return candidate if isinstance(candidate, str) and candidate.strip() else None


def load_current(root: Path = ROOT) -> dict[str, Any]:
    return load(root / "P1-CURRENT.json")


def compute_next_stage_admission(
    *,
    current: dict[str, Any],
) -> dict[str, Any]:
    """Compute admission from existing Current truth; never persist unlock state."""
    stage = current.get("current_stage", {})
    if stage.get("status") != "VERIFIED":
        return {
            "status": "BLOCK",
            "admitted": False,
            "reason_codes": ["ACCEPTANCE_NOT_VERIFIED"],
        }

    next_slice_id = stage.get("next_slice_id")
    if not next_slice_id:
        return {
            "status": "BLOCK",
            "admitted": False,
            "reason_codes": ["NEXT_WORK_UNIT_NOT_DEFINED"],
            "next_action": "RETURN_TO_CONTROL_RESEARCH_FOR_NEXT_TASK",
        }

    return {
        "status": "PASS",
        "admitted": True,
        "next_work_unit_ref": next_slice_id,
        "admission_basis": "P1-CURRENT",
        "admission_mode": "DERIVED_NO_UNLOCK_STATE",
    }


def _role_request(
    request: dict[str, Any],
    *,
    activation_command: str,
    profile_id: str,
    mode: str,
    operation: str,
    requested_write_targets: list[str] | None = None,
    root: Path = ROOT,
) -> dict[str, Any]:
    from role_session_gate import admission

    role_id = request["role_id"]
    current = load_current(root)
    stage = current.get("current_stage", {})
    implementation = current.get("implementation_control", {})
    active_work = implementation.get("active_work_packet")
    active_task_ref = request.get("work_unit_ref")
    if role_id == "ROLE:EXECUTOR" and active_work:
        active_work_path = root / active_work if not Path(active_work).is_absolute() else Path(active_work)
        if active_work_path.is_file():
            active_work_doc = load(active_work_path)
            active_task_ref = active_work_doc.get("task_packet_ref") or active_task_ref
    if not active_task_ref:
        active_task_ref = _stage_work_unit_id(stage)

    gate_request = {
        "request_id": request["request_id"],
        "role_id": role_id,
        "operation": operation,
        "activation_command": activation_command,
        "profile_id": profile_id,
        "mode": mode,
        "task_packet_ref": (
            active_task_ref
            if role_id == "ROLE:EXECUTOR"
            else None
        ),
        "verification_target_ref": (
            request.get("work_unit_ref")
            if role_id == "ROLE:VERIFIER"
            else None
        ),
        "verification_target_refs": (
            [request["work_unit_ref"]]
            if role_id == "ROLE:VERIFIER" and request.get("work_unit_ref")
            else []
        ),
        "construction_record_ref": None,
        "acceptance_mode": (
            "CONTRACT_ONLY_SIMULATION_FIRST"
            if role_id == "ROLE:VERIFIER"
            else "NONE"
        ),
        "requested_write_targets": (
            list(requested_write_targets) if requested_write_targets is not None else []
        ),
        "external_research": False,
        "history_loaded": 0,
        "transient_context_loaded": False,
        "targeted_retrieval_only": role_id != "ROLE:CONTROL_RESEARCH",
        **({"capability_id": request["capability_id"]} if request.get("capability_id") else {}),
    }

    result = admission(gate_request)
    if result["status"] != "PASS":
        return result

    if role_id == "ROLE:EXECUTOR":
        if not active_work:
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACTIVE_WORK_PACKET_MISSING"],
            }
        work_path = root / active_work if not Path(active_work).is_absolute() else Path(active_work)
        if not work_path.is_file():
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACTIVE_WORK_PACKET_NOT_FOUND"],
            }
        work = load(work_path)
        # Final-batch acceptance is an explicitly gated handoff after construction
        # is complete. Permit only this exact claim while BOTH Current and Work are
        # in pending-acceptance states; all other writes still require an open unit.
        final_acceptance_handoff = (
            operation == "WRITE_RESULT"
            and request.get("result_status") == "WORK_COMPLETE"
            and request.get("final_batch_acceptance") is True
            and stage.get("status") in PENDING_STAGE_STATUSES
            and work.get("status") in PENDING_STAGE_STATUSES
        )
        if (
            work.get("status") not in EXECUTOR_READY_STATUSES
            and not final_acceptance_handoff
        ):
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION"],
                "work_status": work.get("status"),
            }

    if role_id == "ROLE:VERIFIER":
        if stage.get("status") not in VERIFIER_STAGE_STATUSES:
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["WORK_UNIT_NOT_READY_FOR_ACCEPTANCE"],
                "stage_status": stage.get("status"),
            }

    return {
        "status": "PASS",
        "admitted": True,
        "request_id": request["request_id"],
        "role_id": role_id,
        "profile_id": profile_id,
        "mode": mode,
        "central_authority": "P1-CURRENT",
        "lifecycle_authority": "CENTRAL_ROLE_INTERFACE",
    }


def _active_work_location(root: Path, current: dict[str, Any]) -> tuple[Path, str]:
    """Resolve only the Current-selected active work packet; reject traversal/symlinks."""
    reference = current.get("implementation_control", {}).get("active_work_packet")
    if not isinstance(reference, str) or not reference:
        raise ValueError("ACTIVE_WORK_PACKET_MISSING")
    relative = Path(reference)
    if relative.is_absolute() or ".." in relative.parts:
        raise ValueError("ACTIVE_WORK_PATH_FORBIDDEN")

    root_resolved = root.resolve()
    candidate = root_resolved / relative
    cursor = root_resolved
    for part in relative.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("ACTIVE_WORK_PATH_SYMLINK")
    if not candidate.is_file():
        raise ValueError("ACTIVE_WORK_PACKET_NOT_FOUND")
    if not candidate.resolve().is_relative_to(root_resolved):
        raise ValueError("ACTIVE_WORK_PATH_FORBIDDEN")
    return candidate, reference


def _normalize_brain_mode_control(work: dict[str, Any]) -> dict[str, Any]:
    """Normalize current mode and derive plan gates from recorded plan evidence."""
    control = work.get("brain_mode_control")
    if not isinstance(control, dict):
        control = initial_control_state()
    else:
        defaults = initial_control_state()
        for key, value in defaults.items():
            if key not in control:
                control[key] = value

    defaults = initial_control_state()
    gate_keys = tuple(defaults["plan_gates"])
    raw_evidence = control.get("plan_evidence")
    if not isinstance(raw_evidence, dict):
        raw_evidence = {}
    evidence: dict[str, str] = {}
    for key in gate_keys:
        value = raw_evidence.get(key)
        evidence[key] = value.strip() if isinstance(value, str) else ""
    control["plan_evidence"] = evidence
    # Booleans are derived from non-empty, current plan evidence rather than trusted
    # from a caller-supplied or stale flag.
    control["plan_gates"] = {
        key: len(evidence[key]) >= MIN_PLAN_EVIDENCE_CHARS
        for key in gate_keys
    }
    if not all(control["plan_gates"].values()):
        control["plan_approved"] = False
    else:
        control["plan_approved"] = control.get("plan_approved") is True

    work["brain_mode_control"] = control
    return control

def _load_active_work_snapshot(
    root: Path, current: dict[str, Any]
) -> dict[str, Any]:
    """Read Current and its active Work Packet, retaining optimistic write preconditions."""
    current_path = root / "P1-CURRENT.json"
    if current_path.is_symlink():
        raise ValueError("CURRENT_PATH_SYMLINK")
    current_raw = current_path.read_bytes()
    current_on_disk = json.loads(current_raw.decode("utf-8"))
    if current_on_disk != current:
        raise ValueError("COGNITIVE_CURRENT_CHANGED")
    work_path, work_ref = _active_work_location(root, current)
    raw = work_path.read_bytes()
    work = json.loads(raw.decode("utf-8"))
    if not isinstance(work, dict):
        raise ValueError("ACTIVE_WORK_PACKET_NOT_OBJECT")
    stage = current.get("current_stage", {})
    return {
        "current_raw_sha256": hashlib.sha256(current_raw).hexdigest(),
        "work_path": work_path,
        "work_ref": work_ref,
        "work": work,
        "raw_sha256": hashlib.sha256(raw).hexdigest(),
        "stage_id": stage.get("id"),
        "work_unit_id": _stage_work_unit_id(stage),
    }




def _atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    """Replace the selected work packet atomically; never write Current here."""
    payload = json.dumps(value, ensure_ascii=False, indent=2) + "\n"
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _persist_cognitive_transition(
    *,
    root: Path,
    snapshot: dict[str, Any],
    role_id: str,
    transition: dict[str, Any],
) -> None:
    """Persist only if Current and the active Work Packet still match the read snapshot."""
    work_path = snapshot["work_path"]
    work = snapshot["work"]
    current_path_on_disk = root / "P1-CURRENT.json"
    if current_path_on_disk.is_symlink():
        raise ValueError("CURRENT_PATH_SYMLINK")
    current_raw = current_path_on_disk.read_bytes()
    if _sha256_bytes(current_raw) != snapshot["current_raw_sha256"]:
        raise ValueError("COGNITIVE_CURRENT_CONCURRENT_MODIFICATION")
    current = json.loads(current_raw.decode("utf-8"))
    current_path, current_ref = _active_work_location(root, current)
    stage = current.get("current_stage", {})
    if (
        current_ref != snapshot["work_ref"]
        or current_path != work_path
        or stage.get("id") != snapshot["stage_id"]
        or (_stage_work_unit_id(stage)) != snapshot["work_unit_id"]
    ):
        raise ValueError("COGNITIVE_STATE_AUTHORITY_CHANGED")
    raw = work_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != snapshot["raw_sha256"]:
        raise ValueError("COGNITIVE_WORK_PACKET_CONCURRENT_MODIFICATION")
    if work_path.is_symlink() or not work_path.resolve().is_relative_to(root.resolve()):
        raise ValueError("ACTIVE_WORK_PATH_FORBIDDEN")

    control = _normalize_brain_mode_control(work)
    control.update(
        mode=transition["mode"],
        plan_approved=transition["plan_approved"],
        feature_batch_complete=transition["feature_batch_complete"],
        simulation_batch_passed=transition["simulation_batch_passed"],
        integration_batch_passed=transition["integration_batch_passed"],
        acceptance_policy="FINAL_BATCH_ONLY",
        last_transition={
            "event": transition["event"],
            "from_mode": transition["from_mode"],
            "to_mode": transition["mode"],
            "status": transition["status"],
            "reason_code": transition["reason_code"],
            "research_recommended": transition["research_recommended"],
            "role_id": role_id,
            "transitioned_at": datetime.now(timezone.utc).isoformat(),
        },
    )
    if transition["integration_batch_passed"] is False:
        control["final_batch_report_ref"] = None
    # Only an explicit successful PLAN_APPROVED event may re-arm a watchdog
    # latch after a stalled transition has paused work in THINKING. A generic
    # construction-step event must not be sufficient to bypass the pause.
    if (
        transition["status"] == "PASS"
        and transition["event"] == "PLAN_APPROVED"
        and transition["mode"] == "CONSTRUCTION"
    ):
        control["progress_guard"] = initial_control_state()["progress_guard"]
    reset_plan = (
        transition["event"] == "TASK_STARTED"
        or (
            transition["mode"] == "THINKING"
            and transition["construction_paused"] is True
        )
    )
    if reset_plan:
        control["plan_evidence"] = {key: "" for key in control["plan_gates"]}
        control["plan_gates"] = {key: False for key in control["plan_gates"]}
        control["plan_approved"] = False
    if (
        isinstance(work.get("operational_contract"), dict)
        and isinstance(work.get("work_id"), str)
        and isinstance(work.get("brain_mode_control"), dict)
    ):
        _validate_document_schema(
            root, work, "P1-Central-Control/schemas/operational_work_unit.schema.json",
            "COGNITIVE_WORK_PACKET",
        )
    _atomic_write_json(work_path, work)


def _stable_payload_sha256(value: dict[str, Any]) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _active_work_contract_sha256(work: dict[str, Any]) -> str:
    projection = json.loads(json.dumps(work, ensure_ascii=False))
    for key in ("status", "implementation_step", "current_result", "next_action", "brain_mode_control"):
        projection.pop(key, None)
    handoff = projection.get("handoff")
    if isinstance(handoff, dict):
        handoff.pop("next_step", None)
    return _stable_payload_sha256(projection)


def _active_construction_contract_sha256(construction: dict[str, Any]) -> str:
    projection = json.loads(json.dumps(construction, ensure_ascii=False))
    projection.pop("status", None)
    handoff = projection.get("handoff")
    if isinstance(handoff, dict):
        notes = handoff.get("notes", [])
        if isinstance(notes, list):
            handoff["notes"] = [
                note for note in notes
                if not (isinstance(note, str) and note.startswith("B2.2 lifecycle:"))
            ]
    return _stable_payload_sha256(projection)


FINAL_BATCH_SUITE_COUNTS = {
    "P1-Central-Control/tests/test_continuation_context_box.py": 11,
    "P1-Central-Control/tests/test_knowledge_retrieval.py": 18,
    "P1-Central-Control/tests/test_operational_reference_pack.py": 35,
    "P1-Central-Control/tests/test_current_projection_sync.py": 3,
    "P1-Central-Control/tests/test_run_p2_validation.py": 15,
    "P1-Central-Control/tests/test_brain_mode_controller.py": 15,
    "P1-Central-Control/tests/test_brain_mode_runtime_interface.py": 5,
}


def _validate_final_batch_report(root: Path, report_ref: Any) -> dict[str, Any]:
    """Validate the actual final integration report and bind it to the checked-out HEAD."""
    try:
        feature_batch_gate = validate_final_test_gate(root)
    except BatchGateError as exc:
        raise ValueError(f"FEATURE_BATCH_CLOSURE_GATE_REQUIRED:{exc.code}:{exc.detail}") from exc
    batch_required = feature_batch_gate.get("required") is True
    expected_method_count = feature_batch_gate.get("expected_test_method_count") if batch_required else 102
    if type(expected_method_count) is not int or expected_method_count < 1:
        raise ValueError("FINAL_BATCH_TEST_COUNT_INVALID")
    suite_counts = ({item["test_ref"]: item["expected_method_count"] for item in feature_batch_gate.get("test_roster", [])} if batch_required else FINAL_BATCH_SUITE_COUNTS)
    if not suite_counts or sum(suite_counts.values()) != expected_method_count:
        raise ValueError("FINAL_BATCH_TEST_ROSTER_INVALID")
    if not isinstance(report_ref, str) or not report_ref.strip():
        raise ValueError("FINAL_BATCH_REPORT_REF_REQUIRED")
    relative = Path(report_ref)
    expected_parent = Path("P1-Central-Control/acceptance/reports")
    if relative.is_absolute() or ".." in relative.parts or not report_ref.endswith(".json"):
        raise ValueError("FINAL_BATCH_REPORT_PATH_FORBIDDEN")
    if relative.parts[:len(expected_parent.parts)] != expected_parent.parts:
        raise ValueError("FINAL_BATCH_REPORT_PATH_FORBIDDEN")

    root_resolved = root.resolve()
    cursor = root_resolved
    for part in relative.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("FINAL_BATCH_REPORT_PATH_SYMLINK")
    path = root_resolved / relative
    if not path.is_file() or not path.resolve().is_relative_to(root_resolved):
        raise ValueError("FINAL_BATCH_REPORT_NOT_FOUND")

    try:
        head = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=root_resolved,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise ValueError("FINAL_BATCH_HEAD_UNAVAILABLE") from exc
    if head.returncode != 0 or not head.stdout.strip():
        raise ValueError("FINAL_BATCH_HEAD_UNAVAILABLE")
    expected_head = head.stdout.strip()

    report_raw = path.read_bytes()
    report = json.loads(report_raw.decode("utf-8"))
    if not isinstance(report, dict):
        raise ValueError("FINAL_BATCH_REPORT_NOT_OBJECT")
    report_sha256 = "sha256:" + hashlib.sha256(report_raw).hexdigest()
    if report.get("report_schema_version") != "2.1":
        raise ValueError("FINAL_BATCH_REPORT_SCHEMA_MISMATCH")
    if report.get("mode") != "integration" or report.get("status") != "PACK_INTEGRATION_PASS":
        raise ValueError("FINAL_BATCH_REPORT_NOT_INTEGRATION_PASS")
    if report.get("repository_worktree_clean_at_start") is not True:
        raise ValueError("FINAL_BATCH_WORKTREE_NOT_CLEAN_AT_START")
    cycle_gate = report.get("cycle_gate_evidence")
    if not isinstance(cycle_gate, dict):
        raise ValueError("FINAL_BATCH_CYCLE_GATE_EVIDENCE_MISSING")
    if (
        cycle_gate.get("status") != "P2_PACK_CYCLE_PASS"
        or cycle_gate.get("simulation_status") != "SIMULATION_PASS"
        or type(cycle_gate.get("simulation_exit_code")) is not int
        or cycle_gate.get("simulation_exit_code") != 0
        or type(cycle_gate.get("simulation_expected_test_method_count")) is not int
        or cycle_gate.get("simulation_expected_test_method_count") != expected_method_count
        or type(cycle_gate.get("simulation_actual_test_method_count")) is not int
        or cycle_gate.get("simulation_actual_test_method_count") != expected_method_count
        or cycle_gate.get("simulation_repository_commit") != expected_head
        or cycle_gate.get("integration_status") != "PACK_INTEGRATION_PASS"
        or type(cycle_gate.get("integration_exit_code")) is not int
        or cycle_gate.get("integration_exit_code") != 0
        or cycle_gate.get("integration_repository_commit") != expected_head
        or cycle_gate.get("same_head") is not True
        or cycle_gate.get("final_worktree_clean") is not True
    ):
        raise ValueError("FINAL_BATCH_CYCLE_GATE_EVIDENCE_INVALID")
    if report.get("repository_commit") != expected_head:
        raise ValueError("FINAL_BATCH_REPORT_HEAD_MISMATCH")
    if batch_required:
        report_gate = report.get("feature_batch_gate")
        if (
            not isinstance(report_gate, dict)
            or report_gate.get("required") is not True
            or report_gate.get("batch_id") != feature_batch_gate.get("batch_id")
            or report_gate.get("manifest_ref") != feature_batch_gate.get("manifest_ref")
            or report_gate.get("manifest_fingerprint") != feature_batch_gate.get("manifest_fingerprint")
            or report_gate.get("scope_fingerprint") != feature_batch_gate.get("scope_fingerprint")
            or report_gate.get("expected_test_method_count") != expected_method_count
            or report_gate.get("batch_phase") != "FINAL_TEST"
        ):
            raise ValueError("FINAL_BATCH_FEATURE_GATE_BINDING_MISMATCH")

    # The report's preflight identity must still match Current. Lifecycle status
    # may change during acceptance; authority pointers and Work Unit identity may not.
    preflight = report.get("preflight")
    if not isinstance(preflight, dict) or preflight.get("status") != "PREFLIGHT_PASS":
        raise ValueError("FINAL_BATCH_PREFLIGHT_EVIDENCE_MISSING")
    current_path = root_resolved / "P1-CURRENT.json"
    if current_path.is_symlink() or not current_path.is_file():
        raise ValueError("FINAL_BATCH_CURRENT_PATH_INVALID")
    try:
        state = load(current_path)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise ValueError("FINAL_BATCH_CURRENT_STATE_INVALID") from exc
    current_stage = state.get("current_stage", {})
    implementation = state.get("implementation_control", {})
    if not isinstance(current_stage, dict) or not isinstance(implementation, dict):
        raise ValueError("FINAL_BATCH_CURRENT_AUTHORITY_INVALID")
    active_work_ref = implementation.get("active_work_packet")
    active_construction_ref = implementation.get("active_construction_packet")
    active_work_unit = _stage_work_unit_id(current_stage)
    if (
        preflight.get("current_stage_id") != current_stage.get("id")
        or preflight.get("current_stage_acceptance") != current_stage.get("acceptance")
        or preflight.get("current_stage_regression_tests") != current_stage.get("regression_tests")
        or preflight.get("current_blueprint_ref") != state.get("p2_target_blueprint_ref")
        or preflight.get("active_work_ref") != active_work_ref
        or preflight.get("active_construction_ref") != active_construction_ref
        or preflight.get("active_work_unit") != active_work_unit
        or preflight.get("active_construction_packet_id") != f"CONSTRUCTION:{active_work_unit}"
    ):
        raise ValueError("FINAL_BATCH_CURRENT_AUTHORITY_DRIFT")
    for ref, expected_parent, expected_suffix, code in (
        (active_work_ref, "P1-Central-Control/progress", ".work.json", "FINAL_BATCH_ACTIVE_WORK_PATH_INVALID"),
        (active_construction_ref, "P1-Central-Control/progress/construction", ".construction.json", "FINAL_BATCH_ACTIVE_CONSTRUCTION_PATH_INVALID"),
    ):
        if not isinstance(ref, str):
            raise ValueError(code)
        candidate = Path(ref)
        if (
            candidate.is_absolute()
            or ".." in candidate.parts
            or candidate.parent.as_posix() != expected_parent
            or not candidate.name.endswith(expected_suffix)
        ):
            raise ValueError(code)
        cursor = root_resolved
        for part in candidate.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                raise ValueError(code)
        if not (root_resolved / candidate).resolve().is_relative_to(root_resolved):
            raise ValueError(code)

    try:
        try:
            active_work_document = load(root_resolved / active_work_ref)
            active_construction_document = load(root_resolved / active_construction_ref)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            raise ValueError("FINAL_BATCH_ACTIVE_PACKET_READ_FAILED") from exc
        expected_work_contract = preflight.get("active_work_contract_sha256")
        expected_construction_contract = preflight.get("active_construction_contract_sha256")
        if (
            not isinstance(expected_work_contract, str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}", expected_work_contract) is None
            or _active_work_contract_sha256(active_work_document) != expected_work_contract
        ):
            raise ValueError("FINAL_BATCH_ACTIVE_WORK_CONTRACT_DRIFT")
        if (
            not isinstance(expected_construction_contract, str)
            or re.fullmatch(r"sha256:[0-9a-f]{64}", expected_construction_contract) is None
            or _active_construction_contract_sha256(active_construction_document) != expected_construction_contract
        ):
            raise ValueError("FINAL_BATCH_ACTIVE_CONSTRUCTION_CONTRACT_DRIFT")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        if isinstance(exc, ValueError) and str(exc).startswith("FINAL_BATCH_"):
            raise
        raise ValueError("FINAL_BATCH_ACTIVE_PACKET_EVIDENCE_INVALID") from exc

    try:
        worktree = subprocess.run(
            ["git", "status", "--porcelain", "--untracked-files=all"],
            cwd=root_resolved,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise ValueError("FINAL_BATCH_WORKTREE_STATUS_UNAVAILABLE") from exc
    if worktree.returncode != 0:
        raise ValueError("FINAL_BATCH_WORKTREE_STATUS_UNAVAILABLE")

    # Central legitimately updates these state packets after the report is sealed.
    # Allow only the Current-selected state files and the tightly named operational
    # acceptance context; any changed source, schema, test, doc or unknown file blocks.
    allowed_runtime_paths = {
        "P1-CURRENT.json",
        active_work_ref,
        active_construction_ref,
    }
    context_ref = current_stage.get("acceptance_ref") if isinstance(current_stage, dict) else None
    if isinstance(context_ref, str):
        candidate = Path(context_ref)
        if (
            not candidate.is_absolute()
            and ".." not in candidate.parts
            and candidate.parent.as_posix() == "P1-Central-Control/acceptance"
            and re.fullmatch(
                r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\.operational-acceptance\.json",
                candidate.name,
            )
        ):
            allowed_runtime_paths.add(candidate.as_posix())

    changed_paths: list[str] = []
    for entry in worktree.stdout.splitlines():
        if len(entry) < 4:
            changed_paths.append(entry)
            continue
        status_code, reported_path = entry[:2], entry[3:]
        if " -> " in reported_path or reported_path.startswith('"'):
            changed_paths.append(reported_path)
            continue
        if reported_path not in allowed_runtime_paths:
            changed_paths.append(reported_path)
    if changed_paths:
        raise ValueError("FINAL_BATCH_SOURCE_TREE_CHANGED:" + ",".join(changed_paths[:20]))
    if report.get("expected_test_method_count") != expected_method_count or report.get("actual_test_method_count") != expected_method_count:
        raise ValueError("FINAL_BATCH_TEST_COUNT_MISMATCH")
    if report.get("pinned_dependencies", {}).get("status") != "MATCH":
        raise ValueError("FINAL_BATCH_DEPENDENCIES_UNVERIFIED")

    steps = report.get("steps")
    if not isinstance(steps, list):
        raise ValueError("FINAL_BATCH_STEPS_MISSING")
    by_name = {step.get("name"): step for step in steps if isinstance(step, dict)}
    for test_ref, expected_count in suite_counts.items():
        step = by_name.get(test_ref)
        if not isinstance(step, dict):
            raise ValueError("FINAL_BATCH_TEST_SUITE_MISSING:" + test_ref)
        if (
            step.get("status") != "PASS"
            or step.get("expected_test_count") != expected_count
            or step.get("actual_test_count") != expected_count
        ):
            raise ValueError("FINAL_BATCH_TEST_SUITE_NOT_PASS:" + test_ref)
    check_only = report.get("check_only_result")
    if not isinstance(check_only, dict) or check_only.get("status") != "READY" or check_only.get("write_performed") is not False:
        raise ValueError("FINAL_BATCH_CHECK_ONLY_NOT_PASS")
    if report.get("canonical_pack_write_outcome") not in {"WRITTEN", "UNCHANGED"}:
        raise ValueError("FINAL_BATCH_CANONICAL_PACK_WRITE_UNVERIFIED")
    expected_written = report.get("canonical_pack_write_outcome") == "WRITTEN"
    if report.get("canonical_pack_write_occurred") is not expected_written:
        raise ValueError("FINAL_BATCH_CANONICAL_PACK_WRITE_CONTRADICTION")
    canonical_verify = report.get("canonical_verify_result")
    canonical_repeat = report.get("canonical_idempotency_result")
    if (
        not isinstance(canonical_verify, dict)
        or canonical_verify.get("status") != "VERIFIED"
        or not isinstance(canonical_repeat, dict)
        or canonical_repeat.get("status") != "UNCHANGED"
    ):
        raise ValueError("FINAL_BATCH_CANONICAL_PACK_NOT_VERIFIED")
    canonical_pack = root_resolved / "P1-Central-Control/canonical/operational_reference_pack.json"
    if not canonical_pack.is_file() or canonical_pack.is_symlink():
        raise ValueError("FINAL_BATCH_CANONICAL_PACK_MISSING")
    expected_pack_sha256 = report.get("canonical_pack_sha256")
    if not isinstance(expected_pack_sha256, str) or re.fullmatch(r"sha256:[0-9a-f]{64}", expected_pack_sha256) is None:
        raise ValueError("FINAL_BATCH_CANONICAL_PACK_HASH_MISSING")
    actual_pack_sha256 = "sha256:" + hashlib.sha256(canonical_pack.read_bytes()).hexdigest()
    if actual_pack_sha256 != expected_pack_sha256:
        raise ValueError("FINAL_BATCH_CANONICAL_PACK_HASH_MISMATCH")
    return {
        "status": "PASS",
        "repository_commit": expected_head,
        "report_ref": relative.as_posix(),
        "report_sha256": report_sha256,
        "expected_test_method_count": expected_method_count,
        "actual_test_method_count": expected_method_count,
        "feature_batch_gate": feature_batch_gate,
        "canonical_pack_write_outcome": report["canonical_pack_write_outcome"],
    }


def _missing_batch_outputs(root: Path, work: dict[str, Any]) -> list[str]:
    outputs = work.get("outputs")
    if not isinstance(outputs, list) or not outputs:
        return ["ACTIVE_WORK_OUTPUTS_MISSING"]
    missing: list[str] = []
    root_resolved = root.resolve()
    for item in outputs:
        reference = item.get("path") if isinstance(item, dict) else None
        if not isinstance(reference, str) or not reference:
            missing.append("INVALID_OUTPUT_REF")
            continue
        relative = Path(reference)
        if relative.is_absolute() or ".." in relative.parts:
            missing.append("OUTPUT_PATH_FORBIDDEN:" + reference)
            continue
        candidate = root_resolved / relative
        cursor = root_resolved
        for part in relative.parts:
            cursor = cursor / part
            if cursor.is_symlink():
                missing.append("OUTPUT_PATH_SYMLINK:" + reference)
                break
        else:
            if not candidate.is_file() or not candidate.resolve().is_relative_to(root_resolved):
                missing.append("OUTPUT_NOT_FOUND:" + reference)
    return missing


def _atomic_write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=False, exist_ok=True)
    fd, temporary_name = tempfile.mkstemp(
        prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent)
    )
    temporary = Path(temporary_name)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
    finally:
        try:
            temporary.unlink(missing_ok=True)
        except OSError:
            pass


def _sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def _finalize_operational_batch(
    *,
    root: Path,
    current: dict[str, Any],
    snapshot: dict[str, Any],
    decision: dict[str, Any],
    report_evidence: dict[str, Any],
    role_id: str,
) -> dict[str, Any]:
    """Create an Operational Acceptance Context and update Current last as commit point."""
    root_resolved = root.resolve()
    current_path = root_resolved / "P1-CURRENT.json"
    work_path: Path = snapshot["work_path"]
    stage = current.get("current_stage", {})
    implementation = current.get("implementation_control", {})
    work_ref = snapshot["work_ref"]
    work_unit = _stage_work_unit_id(stage)
    construction_ref = implementation.get("active_construction_packet")
    if not isinstance(construction_ref, str) or not construction_ref:
        raise ValueError("ACTIVE_CONSTRUCTION_PACKET_MISSING")
    construction_relative = Path(construction_ref)
    if construction_relative.is_absolute() or ".." in construction_relative.parts:
        raise ValueError("ACTIVE_CONSTRUCTION_PATH_FORBIDDEN")
    construction_path = root_resolved / construction_relative
    cursor = root_resolved
    for part in construction_relative.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("ACTIVE_CONSTRUCTION_PATH_SYMLINK")
    if not construction_path.is_file() or not construction_path.resolve().is_relative_to(root_resolved):
        raise ValueError("ACTIVE_CONSTRUCTION_PACKET_NOT_FOUND")

    current_before = current_path.read_bytes()
    if _sha256_bytes(current_before) != snapshot["current_raw_sha256"]:
        raise ValueError("COGNITIVE_CURRENT_CONCURRENT_MODIFICATION")
    work_before = work_path.read_bytes()
    if _sha256_bytes(work_before) != snapshot["raw_sha256"]:
        raise ValueError("COGNITIVE_WORK_PACKET_CONCURRENT_MODIFICATION")
    construction_before = construction_path.read_bytes()
    construction = json.loads(construction_before.decode("utf-8"))
    if not isinstance(construction, dict):
        raise ValueError("ACTIVE_CONSTRUCTION_PACKET_NOT_OBJECT")
    work = snapshot["work"]
    if work.get("work_unit") != work_unit or construction.get("work_segment_ref") != work_unit:
        raise ValueError("ACCEPTANCE_WORK_UNIT_MISMATCH")
    if work.get("construction_packet_ref") != construction_ref:
        raise ValueError("ACTIVE_CONSTRUCTION_REFERENCE_MISMATCH")
    if stage.get("acceptance_ref"):
        raise ValueError("ACCEPTANCE_CONTEXT_ALREADY_BOUND")
    if stage.get("status") not in {"IN_PROGRESS", "BUILDING", "CHANGE_OBSERVED"}:
        raise ValueError("WORK_UNIT_NOT_ACTIVE_FOR_FINAL_BATCH")
    if work.get("status") not in {"IN_PROGRESS", "BUILDING", "CHANGE_OBSERVED", "READY"}:
        raise ValueError("WORK_PACKET_NOT_ACTIVE_FOR_FINAL_BATCH")
    if construction.get("status") not in {"BUILDING", "CHANGE_OBSERVED", "READY"}:
        raise ValueError("CONSTRUCTION_PACKET_NOT_ACTIVE_FOR_FINAL_BATCH")

    if (
        not isinstance(work_unit, str)
        or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", work_unit) is None
    ):
        raise ValueError("ACCEPTANCE_WORK_UNIT_ID_UNSAFE")
    context_relative = Path("P1-Central-Control/acceptance") / f"{work_unit}.operational-acceptance.json"
    context_ref = context_relative.as_posix()
    context_path = root_resolved / context_relative
    context_cursor = root_resolved
    for part in context_relative.parts:
        context_cursor = context_cursor / part
        if context_cursor.is_symlink():
            raise ValueError("OPERATIONAL_ACCEPTANCE_CONTEXT_PATH_SYMLINK")
    if not context_path.resolve().is_relative_to(root_resolved):
        raise ValueError("OPERATIONAL_ACCEPTANCE_CONTEXT_PATH_FORBIDDEN")
    if context_path.exists():
        raise ValueError("OPERATIONAL_ACCEPTANCE_CONTEXT_PATH_EXISTS")
    schema_path = root_resolved / "P1-Central-Control/schemas/operational_acceptance_context.schema.json"
    schema = load(schema_path)
    context_base = {
        "context_id": f"OPERATIONAL_ACCEPTANCE_CONTEXT:{work_unit}",
        "kind": "OPERATIONAL_ACCEPTANCE_CONTEXT",
        "status": "OPEN",
        "authority": "P1-CURRENT",
        "lifecycle_owner": "CENTRAL",
        "mode": "SIMULATION_ONLY",
        "head_sha": report_evidence["repository_commit"],
        "work_unit_ref": work_unit,
        "work_id": work["work_id"],
        "construction_packet_ref": construction_ref,
        "final_batch_report_ref": report_evidence["report_ref"],
        "report_sha256": report_evidence["report_sha256"],
        "expected_test_method_count": report_evidence["expected_test_method_count"],
        "required_checks": [
            "OFFICIAL_INTEGRATION_REPORT_PACK_INTEGRATION_PASS",
            "REPORT_HEAD_MATCHES_CURRENT_GIT_HEAD",
            f"OFFICIAL_TEST_ROSTER_PASS_WITH_EXACT_COUNTS_TOTAL_{report_evidence['expected_test_method_count']}",
            "PINNED_DEPENDENCIES_MATCH",
            "CHECK_ONLY_READY_WITHOUT_WRITE",
            "CANONICAL_PACK_VERIFIED",
            "CANONICAL_PACK_IDEMPOTENCY_UNCHANGED",
            "CANONICAL_PACK_SHA256_MATCHES_REPORT_AT_VERIFIER_TIME",
            "INDEPENDENT_VERIFIER_MUST_SUBMIT_ACCEPTANCE_REF_AND_HEAD_SHA",
        ],
        "source_refs": [
            "P1-CURRENT.json",
            work_ref,
            construction_ref,
            report_evidence["report_ref"],
            "P1-Central-Control/schemas/operational_acceptance_context.schema.json",
            "P1-Central-Control/scripts/central_role_interface.py",
        ],
    }
    content_digest = "sha256:" + hashlib.sha256(
        json.dumps(context_base, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    context = dict(context_base)
    context["content_sha256"] = content_digest
    Draft202012Validator.check_schema(schema)
    Draft202012Validator(schema).validate(context)
    context_bytes = (json.dumps(context, ensure_ascii=False, indent=2) + "\n").encode("utf-8")

    new_work = json.loads(json.dumps(work, ensure_ascii=False))
    new_work["status"] = "READY_FOR_CLOSE_ACCEPTANCE"
    new_work["implementation_step"] = "READY_FOR_CLOSE_ACCEPTANCE"
    new_work["next_action"] = (
        "Await independent Verifier on the report-bound Operational Acceptance Context."
    )
    if isinstance(new_work.get("handoff"), dict):
        new_work["handoff"]["next_step"] = new_work["next_action"]
    if isinstance(new_work.get("current_result"), dict):
        new_work["current_result"].update(
            code_status="PROGRAM_EXECUTED_PASS",
            python_tests=f"PASS_{report_evidence['expected_test_method_count']}_OF_{report_evidence['expected_test_method_count']}",
            formal_caller="WIRED",
            active_pack="CANONICAL_PACK_VERIFIED_IDEMPOTENT",
            runtime_truth="INCOMPLETE",
            known_execution_blocker="Independent Verifier result is still required to close the Work Unit.",
        )
    new_construction = json.loads(json.dumps(construction, ensure_ascii=False))
    new_construction["status"] = "READY_FOR_CLOSE_ACCEPTANCE"
    _set_construction_lifecycle_note(
        new_construction,
        f"Official {report_evidence['expected_test_method_count']}-method Simulation/Integration evidence is report-bound; await the independent Verifier.",
    )
    current_updated = json.loads(current_before.decode("utf-8"))
    stage_updated = current_updated["current_stage"]
    observed_at = datetime.now(timezone.utc).isoformat()
    stage_updated["status"] = "READY_FOR_CLOSE_ACCEPTANCE"
    stage_updated["acceptance_ref"] = context_ref
    stage_updated["acceptance_mode"] = "SIMULATION_ONLY"
    stage_updated["validated_head_sha"] = report_evidence["repository_commit"]
    stage_updated["next_exact_action"] = (
        "Independent Verifier must inspect the report-bound Operational Acceptance Context "
        "and submit SUBMIT_ROLE_RESULT with the exact acceptance_ref and head_sha."
    )
    stage_updated["operational_result"] = (
        f"Official Integration PACK_INTEGRATION_PASS at {report_evidence['repository_commit']}; "
        f"{report_evidence['expected_test_method_count']} declared test methods and canonical Pack verify/idempotency evidence validated. "
        "The work unit is awaiting independent Verifier acceptance; this is not final closure."
    )
    stage_updated["latest_runtime_observation"] = {
        "observed_at": observed_at,
        "source": "CODESPACES_P2_VALIDATION_CYCLE_REPORT",
        "run_id": None,
        "classification": "PACK_INTEGRATION_PASS",
        "evidence": True,
        "run_attempt": None,
        "job_id": None,
        "head_sha": report_evidence["repository_commit"],
        "step_evidence": True,
        "evidence_policy": (
            f"Validated persisted Integration report: same Git HEAD, {report_evidence['expected_test_method_count']} methods, "
            "pinned dependencies MATCH, check-only READY/no write, canonical verification and idempotency."
        ),
    }
    current_updated["current_stage"] = stage_updated
    runtime_truth = current_updated.get("implementation_control", {}).get("runtime_execution_truth", {})
    runtime_truth["latest_observation"] = {
        "observed_at": observed_at,
        "workflow": "CODESPACES_P2_VALIDATION_CYCLE_REPORT",
        "run_id": None,
        "run_attempt": None,
        "job_id": None,
        "head_sha": report_evidence["repository_commit"],
        "job_conclusion": "not_applicable",
        "step_evidence": True,
        "classification": "PACK_INTEGRATION_PASS",
        "program_regression_status": f"PASS_{report_evidence['expected_test_method_count']}_OF_{report_evidence['expected_test_method_count']}",
        "evidence_policy": (
            "Validated persisted Integration report tied to current Git HEAD. "
            "This proves the Pack Integration layer only; independent Work Unit acceptance remains open."
        ),
    }
    current_updated["implementation_control"]["runtime_execution_truth"] = runtime_truth

    _validate_operational_lifecycle_payloads(
        root_resolved,
        current=current_updated,
        work=new_work,
        construction=new_construction,
        context=context,
    )

    context_created = False
    construction_written = False
    work_written = False
    current_written = False
    construction_payload = (json.dumps(new_construction, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    try:
        _atomic_write_json(context_path, context)
        context_created = True
        if _sha256_bytes(construction_path.read_bytes()) != _sha256_bytes(construction_before):
            raise ValueError("COGNITIVE_CONSTRUCTION_CONCURRENT_MODIFICATION")
        _atomic_write_json(construction_path, new_construction)
        construction_written = True
        snapshot["work"].clear()
        snapshot["work"].update(new_work)
        snapshot["work"]["brain_mode_control"]["final_batch_report_ref"] = report_evidence["report_ref"]
        _persist_cognitive_transition(
            root=root,
            snapshot=snapshot,
            role_id=role_id,
            transition=decision,
        )
        work_written = True
        if _sha256_bytes(current_path.read_bytes()) != snapshot["current_raw_sha256"]:
            raise ValueError("COGNITIVE_CURRENT_CONCURRENT_MODIFICATION")
        _atomic_write_json(current_path, current_updated)
        current_written = True
    except Exception:
        # Best-effort rollback only when the affected file still equals our write.
        try:
            if current_written and _sha256_bytes(current_path.read_bytes()) == _sha256_bytes(
                (json.dumps(current_updated, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
            ):
                _atomic_write_bytes(current_path, current_before)
        except OSError:
            pass
        try:
            if work_written:
                current_work = work_path.read_bytes()
                expected_work_payload = (
                    json.dumps(snapshot["work"], ensure_ascii=False, indent=2) + "\n"
                ).encode("utf-8")
                if _sha256_bytes(current_work) == _sha256_bytes(expected_work_payload):
                    _atomic_write_bytes(work_path, work_before)
        except OSError:
            pass
        try:
            if construction_written:
                current_construction = construction_path.read_bytes()
                if _sha256_bytes(current_construction) == _sha256_bytes(construction_payload):
                    _atomic_write_bytes(construction_path, construction_before)
        except OSError:
            pass
        try:
            if context_created and context_path.is_file() and _sha256_bytes(context_path.read_bytes()) == _sha256_bytes(context_bytes):
                context_path.unlink()
        except OSError:
            pass
        raise

    return {
        "status": "PASS",
        "acceptance_ref": context_ref,
        "head_sha": report_evidence["repository_commit"],
        "report_ref": report_evidence["report_ref"],
        "next_action": "INDEPENDENT_VERIFIER_REQUIRED",
    }


def _persist_operational_verifier_outcome(
    *,
    root: Path,
    current: dict[str, Any],
    snapshot: dict[str, Any],
    context_ref: str,
    transition: dict[str, Any],
    verifier_passed: bool,
) -> dict[str, Any]:
    """Commit the independent Verifier outcome across Current, Work, Construction and Context."""
    root_resolved = root.resolve()
    current_path = root_resolved / "P1-CURRENT.json"
    work_path: Path = snapshot["work_path"]
    current_before = current_path.read_bytes()
    if _sha256_bytes(current_before) != snapshot["current_raw_sha256"]:
        raise ValueError("VERIFIER_CURRENT_CONCURRENT_MODIFICATION")
    work_before = work_path.read_bytes()
    if _sha256_bytes(work_before) != snapshot["raw_sha256"]:
        raise ValueError("VERIFIER_WORK_CONCURRENT_MODIFICATION")

    context_relative = Path(context_ref)
    if context_relative.is_absolute() or ".." in context_relative.parts:
        raise ValueError("VERIFIER_CONTEXT_PATH_FORBIDDEN")
    context_path = root_resolved / context_relative
    context_cursor = root_resolved
    for part in context_relative.parts:
        context_cursor = context_cursor / part
        if context_cursor.is_symlink():
            raise ValueError("VERIFIER_CONTEXT_PATH_INVALID")
    if not context_path.is_file() or not context_path.resolve().is_relative_to(root_resolved):
        raise ValueError("VERIFIER_CONTEXT_PATH_INVALID")
    context_before = context_path.read_bytes()
    context = json.loads(context_before.decode("utf-8"))

    stage = current.get("current_stage", {})
    implementation = current.get("implementation_control", {})
    construction_ref = implementation.get("active_construction_packet")
    if not isinstance(construction_ref, str) or not construction_ref:
        raise ValueError("ACTIVE_CONSTRUCTION_PACKET_MISSING")
    construction_relative = Path(construction_ref)
    if construction_relative.is_absolute() or ".." in construction_relative.parts:
        raise ValueError("ACTIVE_CONSTRUCTION_PATH_FORBIDDEN")
    construction_path = root_resolved / construction_relative
    cursor = root_resolved
    for part in construction_relative.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("ACTIVE_CONSTRUCTION_PATH_SYMLINK")
    if not construction_path.is_file() or not construction_path.resolve().is_relative_to(root_resolved):
        raise ValueError("ACTIVE_CONSTRUCTION_PACKET_NOT_FOUND")
    construction_before = construction_path.read_bytes()
    construction = json.loads(construction_before.decode("utf-8"))
    work = snapshot["work"]

    if (
        stage.get("acceptance_ref") != context_ref
        or stage.get("status") not in PENDING_STAGE_STATUSES
        or context.get("work_id") != work.get("work_id")
        or context.get("work_unit_ref") != (_stage_work_unit_id(stage))
        or context.get("construction_packet_ref") != construction_ref
        or work.get("construction_packet_ref") != construction_ref
    ):
        raise ValueError("VERIFIER_ACCEPTANCE_AUTHORITY_MISMATCH")
    if (
        work.get("status") not in PENDING_STAGE_STATUSES
        or construction.get("status") not in PENDING_STAGE_STATUSES
    ):
        raise ValueError("VERIFIER_ACCEPTANCE_STATUS_MISMATCH")

    new_work = json.loads(json.dumps(work, ensure_ascii=False))
    new_construction = json.loads(json.dumps(construction, ensure_ascii=False))
    new_current = json.loads(current_before.decode("utf-8"))
    new_context = json.loads(context_before.decode("utf-8"))
    new_stage = new_current["current_stage"]
    control = _normalize_brain_mode_control(new_work)
    role_id = "ROLE:VERIFIER"
    control.update(
        mode=transition["mode"],
        plan_approved=transition["plan_approved"],
        feature_batch_complete=transition["feature_batch_complete"],
        simulation_batch_passed=transition["simulation_batch_passed"],
        integration_batch_passed=transition["integration_batch_passed"],
        acceptance_policy="FINAL_BATCH_ONLY",
        last_transition={
            "event": transition["event"],
            "from_mode": transition["from_mode"],
            "to_mode": transition["mode"],
            "status": transition["status"],
            "reason_code": transition["reason_code"],
            "research_recommended": transition["research_recommended"],
            "role_id": role_id,
            "transitioned_at": datetime.now(timezone.utc).isoformat(),
        },
    )
    observed_at = datetime.now(timezone.utc).isoformat()
    if verifier_passed:
        new_work["status"] = "VERIFIED"
        new_work["implementation_step"] = "CLOSED"
        if isinstance(new_work.get("current_result"), dict):
            new_work["current_result"].update(
                code_status="VERIFIED",
                python_tests=f"PASS_{context.get('expected_test_method_count', 102)}_OF_{context.get('expected_test_method_count', 102)}",
                formal_caller="WIRED",
                active_pack="CANONICAL_PACK_VERIFIED_IDEMPOTENT",
                # This batch verifies its declared 102-method suites and the Pack
                # integration only. It must not promote the full B1→B7 Runtime truth.
                runtime_truth="INCOMPLETE",
                known_execution_blocker="",
            )
        new_construction["status"] = "VERIFIED"
        _set_construction_lifecycle_note(
            new_construction,
            f"Independent Verifier accepted {context.get('work_unit_ref', 'the active batch')} at declared batch scope; global Runtime remains INCOMPLETE.",
        )
        new_work["next_action"] = (
            "Work Unit verified; derive next admission from Current or return to Control Research."
        )
        if isinstance(new_work.get("handoff"), dict):
            new_work["handoff"]["next_step"] = new_work["next_action"]
        new_stage["status"] = "VERIFIED"
        new_stage["operational_result"] = (
            f"Independent Verifier PASS for {context.get('head_sha')} after validating the "
            f"report-bound Operational Acceptance Context, exact {context.get('expected_test_method_count', 102)}-method regression evidence "
            f"and canonical Pack digest. {context.get('work_unit_ref', 'The batch')} is closed at its declared scope; "
            "full B1→B7 Runtime truth remains INCOMPLETE and is not inferred from this Pack-level acceptance."
        )
        new_stage["next_exact_action"] = (
            "Central may derive next Work Unit admission from P1-CURRENT; if no next_slice_id exists, "
            "Control Research must define the next slice."
        )
        new_context["status"] = "ACCEPTED"
        context_base = {key: value for key, value in new_context.items() if key != "content_sha256"}
        new_context["content_sha256"] = "sha256:" + hashlib.sha256(
            json.dumps(context_base, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()
    else:
        new_work["status"] = "IN_PROGRESS"
        new_work["implementation_step"] = "RETURN_TO_THINKING"
        if isinstance(new_work.get("current_result"), dict):
            new_work["current_result"].update(
                code_status="PATCHED_UNVERIFIED",
                formal_caller="WIRED",
                runtime_truth="BLOCKED",
                known_execution_blocker="Verifier findings require THINKING and a revised plan before another construction slice.",
            )
        new_construction["status"] = "BUILDING"
        _set_construction_lifecycle_note(
            new_construction,
            "Independent Verifier rejected the batch; pause construction and return to THINKING for evidence-backed replanning.",
        )
        new_stage["status"] = "IN_PROGRESS"
        new_stage.pop("acceptance_ref", None)
        new_stage.pop("acceptance_mode", None)
        new_stage["validated_head_sha"] = None
        new_stage["operational_result"] = (
            "Independent Verifier did not accept the current batch. Construction is paused; "
            "Brain must return to THINKING, reassess the finding and invalidate prior final-batch readiness."
        )
        new_stage["next_exact_action"] = (
            "Return to THINKING, examine verifier findings and decide whether bounded research or a revised plan is required."
        )
        control["final_batch_report_ref"] = None
        control["plan_evidence"] = {key: "" for key in control["plan_gates"]}
        control["plan_gates"] = {key: False for key in control["plan_gates"]}
        control["plan_approved"] = False
        new_work["next_action"] = new_stage["next_exact_action"]
        if isinstance(new_work.get("handoff"), dict):
            new_work["handoff"]["next_step"] = new_work["next_action"]
        new_context["status"] = "REJECTED"
        context_base = {key: value for key, value in new_context.items() if key != "content_sha256"}
        new_context["content_sha256"] = "sha256:" + hashlib.sha256(
            json.dumps(context_base, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
        ).hexdigest()

    new_stage["latest_runtime_observation"] = current.get("current_stage", {}).get("latest_runtime_observation", {})
    new_current["current_stage"] = new_stage
    _validate_operational_lifecycle_payloads(
        root_resolved,
        current=new_current,
        work=new_work,
        construction=new_construction,
        context=new_context,
    )
    context_written = False
    construction_written = False
    work_written = False
    current_written = False
    context_payload = (json.dumps(new_context, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    construction_payload = (json.dumps(new_construction, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    work_payload = (json.dumps(new_work, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    current_payload = (json.dumps(new_current, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    try:
        if _sha256_bytes(context_path.read_bytes()) != _sha256_bytes(context_before):
            raise ValueError("VERIFIER_CONTEXT_CONCURRENT_MODIFICATION")
        if _sha256_bytes(construction_path.read_bytes()) != _sha256_bytes(construction_before):
            raise ValueError("VERIFIER_CONSTRUCTION_CONCURRENT_MODIFICATION")
        _atomic_write_json(construction_path, new_construction)
        construction_written = True
        if _sha256_bytes(work_path.read_bytes()) != snapshot["raw_sha256"]:
            raise ValueError("VERIFIER_WORK_CONCURRENT_MODIFICATION")
        _atomic_write_json(work_path, new_work)
        work_written = True
        if _sha256_bytes(current_path.read_bytes()) != snapshot["current_raw_sha256"]:
            raise ValueError("VERIFIER_CURRENT_CONCURRENT_MODIFICATION")
        if verifier_passed:
            _atomic_write_json(context_path, new_context)
            context_written = True
        _atomic_write_json(current_path, new_current)
        current_written = True
    except Exception:
        try:
            if current_written and _sha256_bytes(current_path.read_bytes()) == _sha256_bytes(current_payload):
                _atomic_write_bytes(current_path, current_before)
        except OSError:
            pass
        try:
            if work_written and _sha256_bytes(work_path.read_bytes()) == _sha256_bytes(work_payload):
                _atomic_write_bytes(work_path, work_before)
        except OSError:
            pass
        try:
            if construction_written and _sha256_bytes(construction_path.read_bytes()) == _sha256_bytes(construction_payload):
                _atomic_write_bytes(construction_path, construction_before)
        except OSError:
            pass
        try:
            if context_written and _sha256_bytes(context_path.read_bytes()) == _sha256_bytes(context_payload):
                _atomic_write_bytes(context_path, context_before)
        except OSError:
            pass
        raise

    if not verifier_passed:
        try:
            if (
                context_path.is_file()
                and not context_path.is_symlink()
                and _sha256_bytes(context_path.read_bytes()) == _sha256_bytes(context_before)
            ):
                context_path.unlink()
        except OSError:
            pass
    admission = compute_next_stage_admission(current=new_current) if verifier_passed else {
        "status": "BLOCK",
        "admitted": False,
        "reason_codes": ["VERIFIER_DID_NOT_ACCEPT"],
        "next_action": "RETURN_TO_CONTROL_RESEARCH",
    }
    return {
        "status": "PASS",
        "work_unit_closed": verifier_passed,
        "acceptance_ref": context_ref if verifier_passed else None,
        "next_stage_admission": admission,
        "next_action": (
            "CENTRAL_NEXT_STAGE_ADMITTED"
            if verifier_passed and admission.get("status") == "PASS"
            else "RETURN_TO_CONTROL_RESEARCH"
        ),
    }


def transition_cognition(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    """Central-authorized, role-bounded cognitive transition with current-work persistence."""
    validate_request(request)
    if request["operation"] != "COGNITIVE_TRANSITION":
        raise ValueError("COGNITIVE_TRANSITION_REQUIRED")

    role_id = request["role_id"]
    event = request.get("cognitive_event")
    if event not in ROLE_EVENTS.get(role_id, set()):
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": ["COGNITIVE_EVENT_NOT_ALLOWED_FOR_ROLE"],
            "cognitive_event": event,
        }

    if role_id == "ROLE:CONTROL_RESEARCH":
        if event == "TASK_STARTED":
            operation, write_targets = "CREATE_TASK", ["TASK_ARTIFACTS"]
        elif event == "FINAL_BATCH_READY":
            operation, write_targets = "MODIFY_CONSTRUCTION", ["CONSTRUCTION_ARTIFACTS"]
        else:
            operation, write_targets = "MODIFY_PLAN", ["PLANNING_ARTIFACTS"]
        activation_command, profile_id, mode = (
            "！討論", "IP:CONTROL-DISCUSSION", "DISCUSSION"
        )
    elif role_id == "ROLE:EXECUTOR":
        operation, write_targets = "WRITE_CHECKPOINT", ["CHECKPOINT"]
        activation_command, profile_id, mode = (
            "！施工", "IP:CONSTRUCTION-EXECUTOR", "CONSTRUCTION"
        )
    else:
        operation, write_targets = "WRITE_VERIFICATION_RESULT", ["VERIFICATION_RESULT"]
        activation_command, profile_id, mode = (
            "！驗收", "IP:ACCEPTANCE-VERIFIER", "ACCEPTANCE"
        )

    current = load_current(root)
    stage = current.get("current_stage", {})
    gate_request = dict(request)
    if not gate_request.get("work_unit_ref"):
        gate_request["work_unit_ref"] = _stage_work_unit_id(stage)
    admission = _role_request(
        gate_request,
        activation_command=activation_command,
        profile_id=profile_id,
        mode=mode,
        operation=operation,
        requested_write_targets=write_targets,
        root=root,
    )
    if admission.get("status") != "PASS":
        return admission

    try:
        snapshot = _load_active_work_snapshot(root, current)
        work_path = snapshot["work_path"]
        work = snapshot["work"]
    except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": [str(exc).split(":", 1)[0]],
        }

    control = _normalize_brain_mode_control(work)
    if "plan_evidence" in request:
        if role_id != "ROLE:CONTROL_RESEARCH" or event not in {"THINKING_COMPLETE", "RESEARCH_COMPLETE"}:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": ["PLAN_EVIDENCE_SUBMISSION_NOT_ALLOWED_FOR_ROLE_OR_EVENT"],
            }
        supplied_evidence = request["plan_evidence"]
        if not isinstance(supplied_evidence, dict):
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": ["PLAN_EVIDENCE_OBJECT_REQUIRED"],
            }
        normalized_evidence = {}
        for key in control["plan_gates"]:
            value = supplied_evidence.get(key, "")
            normalized_evidence[key] = value.strip() if isinstance(value, str) else ""
        insufficient_evidence = [
            key for key, value in normalized_evidence.items()
            if len(value) < MIN_PLAN_EVIDENCE_CHARS
        ]
        control["plan_evidence"] = normalized_evidence
        control["plan_gates"] = {
            key: len(normalized_evidence[key]) >= MIN_PLAN_EVIDENCE_CHARS
            for key in normalized_evidence
        }
        if insufficient_evidence:
            control["plan_approved"] = False
    report_evidence = None
    feature_batch_complete = control.get("feature_batch_complete") is True
    simulation_batch_passed = control.get("simulation_batch_passed") is True
    integration_batch_passed = control.get("integration_batch_passed") is True
    if event == "FINAL_BATCH_READY":
        if (
            not isinstance(work.get("operational_contract"), dict)
            or not isinstance(work.get("work_id"), str)
            or work.get("task_packet_ref")
        ):
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": ["OPERATIONAL_WORK_UNIT_REQUIRED_FOR_FINAL_BATCH"],
            }
        if request.get("feature_batch_complete") is not True:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": ["FEATURE_BATCH_COMPLETION_NOT_CONFIRMED"],
            }
        try:
            feature_batch_gate = validate_final_test_gate(root)
            if feature_batch_gate.get("required") is True:
                work_contract = work.get("operational_contract", {})
                if (
                    work_contract.get("feature_batch_id") != feature_batch_gate.get("batch_id")
                    or work_contract.get("feature_batch_manifest_ref") != feature_batch_gate.get("manifest_ref")
                ):
                    raise ValueError("FEATURE_BATCH_ACTIVE_WORK_BINDING_MISMATCH")
            report_evidence = _validate_final_batch_report(
                root, request.get("simulation_report_ref")
            )
        except (OSError, ValueError, BatchGateError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": [str(exc).split(":", 1)[0]],
                "detail": str(exc),
            }
        missing_outputs = _missing_batch_outputs(root, work)
        if missing_outputs:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": ["FEATURE_BATCH_OUTPUTS_MISSING"],
                "missing_outputs": missing_outputs[:25],
            }
        feature_batch_complete = True
        simulation_batch_passed = True
        integration_batch_passed = True
        control["final_batch_report_ref"] = report_evidence["report_ref"]

    research_reasons = list(request.get("research_trigger_reasons", []))
    last_transition = control.get("last_transition")
    if (
        event == "THINKING_COMPLETE"
        and not research_reasons
        and isinstance(last_transition, dict)
        and last_transition.get("research_recommended") is True
    ):
        # Carry the one current failure signal forward, without retaining a trace history.
        research_reasons = ["ROOT_CAUSE_UNKNOWN"]

    decision = transition_mode(
        current_mode=control.get("mode", "THINKING"),
        event=event,
        plan_gates=control.get("plan_gates"),
        plan_approved=(True if event == "PLAN_APPROVED" else control.get("plan_approved") is True),
        research_trigger_reasons=research_reasons,
        research_record=request.get("research_record"),
        feature_batch_complete=feature_batch_complete,
        simulation_batch_passed=simulation_batch_passed,
        integration_batch_passed=integration_batch_passed,
    )
    if decision["status"] != "PASS":
        recovery_persisted = False
        if decision["mode"] == "THINKING" and decision["construction_paused"]:
            try:
                _persist_cognitive_transition(
                    root=root,
                    snapshot=snapshot,
                    role_id=role_id,
                    transition=decision,
                )
                recovery_persisted = True
            except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "reason_codes": ["COGNITIVE_RECOVERY_PERSIST_FAILED", str(exc).split(":", 1)[0]],
                    "transition": decision,
                }
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": [decision["reason_code"]],
            "transition": decision,
            "recovery_state_persisted": recovery_persisted,
        }

    if (
        event == "VALIDATION_FAILED"
        and role_id == "ROLE:VERIFIER"
        and control.get("mode") == "FINAL_ACCEPTANCE"
        and current.get("current_stage", {}).get("acceptance_ref")
    ):
        context_ref = current["current_stage"]["acceptance_ref"]
        try:
            context_relative = Path(context_ref)
            if context_relative.is_absolute() or ".." in context_relative.parts:
                raise ValueError("ACCEPTANCE_CONTEXT_PATH_FORBIDDEN")
            context_path = root / context_relative
            if context_path.is_symlink() or not context_path.resolve().is_relative_to(root.resolve()):
                raise ValueError("ACCEPTANCE_CONTEXT_PATH_FORBIDDEN")
            context = load(context_path)
            if context.get("kind") == "OPERATIONAL_ACCEPTANCE_CONTEXT":
                outcome = _persist_operational_verifier_outcome(
                    root=root,
                    current=current,
                    snapshot=snapshot,
                    context_ref=context_ref,
                    transition=decision,
                    verifier_passed=False,
                )
                return {
                    "status": "PASS",
                    "accepted": True,
                    "request_id": request["request_id"],
                    "role_id": role_id,
                    "transition": decision,
                    "work_unit_reopened": True,
                    "next_action": outcome["next_action"],
                }
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["OPERATIONAL_ACCEPTANCE_REOPEN_FAILED", str(exc).split(":", 1)[0]],
            }

    if event == "FINAL_BATCH_READY":
        try:
            finalized = _finalize_operational_batch(
                root=root,
                current=current,
                snapshot=snapshot,
                decision=decision,
                report_evidence=report_evidence,
                role_id=role_id,
            )
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "reason_codes": ["OPERATIONAL_ACCEPTANCE_CONTEXT_CREATE_FAILED", str(exc).split(":", 1)[0]],
                "detail": str(exc),
            }
        return {
            "status": "PASS",
            "accepted": True,
            "request_id": request["request_id"],
            "role_id": role_id,
            "central_authority": "P1-CURRENT",
            "active_work_packet_ref": snapshot["work_ref"],
            "transition": decision,
            "acceptance_ref": finalized["acceptance_ref"],
            "head_sha": finalized["head_sha"],
            "report_ref": finalized["report_ref"],
            "next_action": finalized["next_action"],
        }

    try:
        _persist_cognitive_transition(
            root=root,
            snapshot=snapshot,
            role_id=role_id,
            transition=decision,
        )
    except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": ["COGNITIVE_STATE_PERSIST_FAILED", str(exc).split(":", 1)[0]],
        }
    next_action = {
        "THINKING": "PAUSE_CONSTRUCTION_AND_RETHINK",
        "RESEARCH": "PRODUCE_BOUNDED_RESEARCH_RECORD",
        "PLAN_READY": "REVIEW_AND_APPROVE_COMPLETE_PLAN",
        "CONSTRUCTION": "CONTINUE_AUTHORIZED_CONSTRUCTION",
        "SIMULATION": "RUN_LOCAL_CASE_SIMULATION_ONLY",
        "FINAL_ACCEPTANCE": "REQUEST_CENTRAL_CLOSE_STATUS_THEN_INDEPENDENT_VERIFIER",
        "CLOSE": "CLOSE_WORK_UNIT_AND_REFRESH_CURRENT",
    }[decision["mode"]]
    return {
        "status": "PASS",
        "accepted": True,
        "request_id": request["request_id"],
        "role_id": role_id,
        "central_authority": "P1-CURRENT",
        "active_work_packet_ref": current.get("implementation_control", {}).get("active_work_packet"),
        "transition": decision,
        "next_action": next_action,
    }


def activate(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    validate_request(request)
    if request["operation"] != "ROLE_ACTIVATE":
        raise ValueError("ROLE_ACTIVATE_REQUIRED")

    command = request.get("activation_command")
    if not command or command not in SHORTCUT_TO_ROLE:
        return {
            "status": "BLOCK",
            "admitted": False,
            "request_id": request["request_id"],
            "reason_codes": ["UNKNOWN_ACTIVATION_COMMAND"],
        }

    role_id, profile_id, mode = SHORTCUT_TO_ROLE[command]
    if request["role_id"] != role_id:
        return {
            "status": "BLOCK",
            "admitted": False,
            "request_id": request["request_id"],
            "reason_codes": ["ROLE_COMMAND_MISMATCH"],
        }

    from role_command_router import resolve

    routed = resolve(command)
    if routed["role_id"] != role_id or routed["profile_id"] != profile_id:
        return {
            "status": "BLOCK",
            "admitted": False,
            "request_id": request["request_id"],
            "reason_codes": ["ROLE_ROUTE_RESOLUTION_MISMATCH"],
        }

    current = load_current(root)
    stage = current.get("current_stage", {})
    if not request.get("work_unit_ref"):
        request = dict(request)
        request["work_unit_ref"] = _stage_work_unit_id(stage)

    return _role_request(
        request,
        activation_command=command,
        profile_id=profile_id,
        mode=mode,
        operation={
            "ROLE:EXECUTOR": "TASK_ADMIT",
            "ROLE:VERIFIER": "VERIFY_TASK",
            "ROLE:CONTROL_RESEARCH": "READ_CURRENT",
        }[role_id],
        root=root,
    )


def get_role_context(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    validate_request(request)
    if request["operation"] != "GET_ROLE_CONTEXT":
        raise ValueError("GET_ROLE_CONTEXT_REQUIRED")

    current = load(root / "P1-CURRENT.json")
    stage = current.get("current_stage", {})
    role_id = request["role_id"]
    if role_id == "ROLE:VERIFIER" and not request.get("work_unit_ref"):
        request = dict(request)
        request["work_unit_ref"] = _stage_work_unit_id(stage)
    activation_command, profile_id, mode = {
        "ROLE:EXECUTOR": ("！施工", "IP:CONSTRUCTION-EXECUTOR", "CONSTRUCTION"),
        "ROLE:VERIFIER": ("！驗收", "IP:ACCEPTANCE-VERIFIER", "ACCEPTANCE"),
        "ROLE:CONTROL_RESEARCH": ("！討論", "IP:CONTROL-DISCUSSION", "DISCUSSION"),
    }[role_id]
    admission_result = _role_request(
        request,
        activation_command=activation_command,
        profile_id=profile_id,
        mode=mode,
        operation={
            "ROLE:EXECUTOR": "TASK_ADMIT",
            "ROLE:VERIFIER": "VERIFY_TASK",
            "ROLE:CONTROL_RESEARCH": "READ_CURRENT",
        }[role_id],
        root=root,
    )
    if admission_result["status"] != "PASS":
        return admission_result

    implementation = current.get("implementation_control", {})

    context: dict[str, Any] = {
        "status": "PASS",
        "request_id": request["request_id"],
        "role_id": role_id,
        "context_authority": "P1-CURRENT",
        "current_stage": {
            "id": stage.get("id"),
            "name": stage.get("name"),
            "status": stage.get("status"),
            "implementation_step": stage.get("implementation_step"),
            "next_exact_action": stage.get("next_exact_action"),
        },
    }

    if role_id == "ROLE:EXECUTOR":
        active = implementation.get("active_work_packet")
        context["construction"] = {
            "active_work_packet_ref": active,
            "task_packet_ref": (
            load(root / active).get("task_packet_ref")
            if active
            and (root / active).is_file()
            else _stage_work_unit_id(stage)
        ),
        }
        if active:
            path = root / active if not Path(active).is_absolute() else Path(active)
            if path.is_file():
                work = load(path)
                context["construction"]["work_id"] = work.get("work_id")
                context["construction"]["work_status"] = work.get("status")
                context["construction"]["objective"] = work.get("objective")
                context["construction"]["next_action"] = work.get("next_action")

    elif role_id == "ROLE:VERIFIER":
        acceptance = current.get("current_stage", {}).get("acceptance_ref")
        if not acceptance:
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACCEPTANCE_CONTEXT_MISSING"],
            }
        acceptance_relative = Path(acceptance)
        if acceptance_relative.is_absolute() or ".." in acceptance_relative.parts:
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
            }
        root_resolved = root.resolve()
        acceptance_path = root_resolved / acceptance_relative
        acceptance_cursor = root_resolved
        for part in acceptance_relative.parts:
            acceptance_cursor = acceptance_cursor / part
            if acceptance_cursor.is_symlink():
                return {
                    "status": "BLOCK",
                    "admitted": False,
                    "request_id": request["request_id"],
                    "role_id": role_id,
                    "reason_codes": ["ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
                }
        if not acceptance_path.resolve().is_relative_to(root_resolved):
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
            }
        if not acceptance_path.is_file():
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACCEPTANCE_CONTEXT_NOT_FOUND"],
            }
        try:
            acceptance_context = load(acceptance_path)
            context_kind = acceptance_context.get("kind")
            if acceptance_context.get("authority") != "P1-CURRENT":
                raise ValueError("ACCEPTANCE_CONTEXT_AUTHORITY_INVALID")
            if acceptance_context.get("work_unit_ref") != (_stage_work_unit_id(stage)):
                raise ValueError("ACCEPTANCE_CONTEXT_WORK_UNIT_MISMATCH")
            if context_kind == "OPERATIONAL_ACCEPTANCE_CONTEXT":
                context_schema = load(root / "P1-Central-Control/schemas/operational_acceptance_context.schema.json")
                Draft202012Validator(context_schema).validate(acceptance_context)
                context_base = {key: value for key, value in acceptance_context.items() if key != "content_sha256"}
                expected_digest = "sha256:" + hashlib.sha256(
                    json.dumps(context_base, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                ).hexdigest()
                if acceptance_context.get("content_sha256") != expected_digest:
                    raise ValueError("OPERATIONAL_ACCEPTANCE_CONTEXT_DIGEST_MISMATCH")
                evidence = _validate_final_batch_report(root, acceptance_context.get("final_batch_report_ref"))
                if (
                    evidence.get("report_sha256") != acceptance_context.get("report_sha256")
                    or evidence.get("repository_commit") != acceptance_context.get("head_sha")
                ):
                    raise ValueError("FINAL_BATCH_REPORT_BINDING_MISMATCH")
                active_work_path, active_work_ref = _active_work_location(root, current)
                active_work = load(active_work_path)
                control = active_work.get("brain_mode_control", {})
                if (
                    active_work_ref != current.get("implementation_control", {}).get("active_work_packet")
                    or active_work.get("work_id") != acceptance_context.get("work_id")
                    or active_work.get("construction_packet_ref") != acceptance_context.get("construction_packet_ref")
                    or stage.get("status") not in PENDING_STAGE_STATUSES
                    or active_work.get("status") not in PENDING_STAGE_STATUSES
                    or control.get("mode") != "FINAL_ACCEPTANCE"
                    or control.get("final_batch_report_ref") != acceptance_context.get("final_batch_report_ref")
                ):
                    raise ValueError("OPERATIONAL_ACCEPTANCE_STATE_MISMATCH")
            elif context_kind == "ACCEPTANCE_CONTEXT":
                legacy_schema = load(root / "P1-Central-Control/schemas/acceptance_context.schema.json")
                Draft202012Validator(legacy_schema).validate(acceptance_context)
            else:
                raise ValueError("ACCEPTANCE_CONTEXT_KIND_UNSUPPORTED")
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["ACCEPTANCE_CONTEXT_INVALID", str(exc).split(":", 1)[0]],
            }
        context["acceptance"] = {
            "acceptance_request_ref": acceptance,
            "context": acceptance_context,
            "runtime_observation": current.get("latest_runtime_observation"),
        }

    elif role_id == "ROLE:CONTROL_RESEARCH":
        context["control"] = {
            "active_work_packet": implementation.get("active_work_packet"),
            "blueprint": current.get("blueprint"),
            "build_plan": current.get("build_plan"),
            "latest_runtime_observation": current.get("latest_runtime_observation"),
        }

    # Verifier remains a projection-only recipient. Executor and Control Research
    # receive the same bounded cognitive policy but keep their distinct authority.
    if role_id in {"ROLE:EXECUTOR", "ROLE:CONTROL_RESEARCH"}:
        try:
            work_path, _ = _active_work_location(root, current)
            active_work = load(work_path)
        except (OSError, ValueError) as exc:
            return {
                "status": "BLOCK",
                "admitted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": [str(exc).split(":", 1)[0]],
            }
        context["cognitive_supervision"] = build_role_supervision_context(
            current=current,
            work_packet=active_work,
            role_id=role_id,
        )

    return context


def _construction_progress_fingerprint(root: Path, work: dict[str, Any]) -> str:
    """Fingerprint persisted construction progress, not prose or lifecycle wording."""
    contract = work.get("operational_contract")
    contract = contract if isinstance(contract, dict) else {}
    manifest_ref = contract.get("feature_batch_manifest_ref")
    manifest_state: dict[str, Any] = {"status": "MANIFEST_REF_UNAVAILABLE"}
    if isinstance(manifest_ref, str) and manifest_ref.strip():
        relative = Path(manifest_ref)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("PROGRESS_MANIFEST_PATH_FORBIDDEN")
        manifest_path = root
        for part in relative.parts:
            manifest_path = manifest_path / part
            if manifest_path.is_symlink():
                raise ValueError("PROGRESS_MANIFEST_PATH_FORBIDDEN")
        if not manifest_path.resolve().is_relative_to(root.resolve()):
            raise ValueError("PROGRESS_MANIFEST_PATH_FORBIDDEN")
        if manifest_path.is_file():
            manifest = load(manifest_path)
            features = manifest.get("features")
            if not isinstance(features, list):
                raise ValueError("PROGRESS_MANIFEST_FEATURES_INVALID")
            manifest_state = {
                "status": "AVAILABLE",
                "batch_id": manifest.get("batch_id"),
                "scope_fingerprint": manifest.get("scope_fingerprint"),
                "batch_phase": manifest.get("batch_phase"),
                "features": [
                    {
                        "feature_id": feature.get("feature_id"),
                        "implementation_status": feature.get("implementation_status"),
                        "local_case_sim_status": feature.get("local_case_sim_status"),
                        "local_case_sim_evidence_refs": feature.get("local_case_sim_evidence_refs", []),
                        "implementation_refs": feature.get("implementation_refs", []),
                    }
                    for feature in features if isinstance(feature, dict)
                ],
            }
        else:
            manifest_state = {"status": "MISSING", "ref": manifest_ref}

    # Hash frozen implementation outputs, not only packet status. This distinguishes
    # real source changes from repeated status/readback reports even before a receipt
    # or prose field is updated. Missing expected files are represented explicitly.
    declared_refs = {
        reference
        for feature in manifest_state.get("features", [])
        if isinstance(feature, dict)
        for reference in feature.get("implementation_refs", [])
        if isinstance(reference, str) and reference.strip()
    }
    # Operational Work Packets without a selected feature-batch manifest
    # still declare output paths at the top level. Include those files too so a
    # source change cannot be misclassified as "no progress" without a manifest.
    declared_outputs = work.get("outputs", [])
    if isinstance(declared_outputs, list):
        for output in declared_outputs:
            reference = output if isinstance(output, str) else (
                output.get("path") if isinstance(output, dict) else None
            )
            if isinstance(reference, str) and reference.strip():
                declared_refs.add(reference.strip())
    implementation_refs = sorted(declared_refs)
    implementation_sources: list[dict[str, str]] = []
    root_resolved = root.resolve()
    current = load_current(root)
    active_work_path, _ = _active_work_location(root, current)
    active_work_resolved = active_work_path.resolve()
    for reference in implementation_refs:
        relative = Path(reference)
        if relative.is_absolute() or ".." in relative.parts or not relative.parts:
            raise ValueError("PROGRESS_IMPLEMENTATION_PATH_FORBIDDEN")
        # Do not hash lifecycle envelopes that this same checkpoint writes.
        # Otherwise updating progress_guard changes the next fingerprint itself
        # and the watchdog can never observe two consecutive identical checkpoints.
        normalized_ref = relative.as_posix()
        if normalized_ref == "P1-CURRENT.json":
            continue
        if (
            normalized_ref.startswith("P1-Central-Control/progress/")
            and normalized_ref.endswith((".work.json", ".construction.json"))
        ):
            continue
        source_path = root
        for part in relative.parts:
            source_path = source_path / part
            if source_path.is_symlink():
                raise ValueError("PROGRESS_IMPLEMENTATION_PATH_FORBIDDEN")
        if not source_path.resolve().is_relative_to(root_resolved):
            raise ValueError("PROGRESS_IMPLEMENTATION_PATH_FORBIDDEN")
        if source_path.resolve() == active_work_resolved:
            continue
        source_digest = (
            hashlib.sha256(source_path.read_bytes()).hexdigest()
            if source_path.is_file()
            else "MISSING"
        )
        implementation_sources.append({"ref": reference, "sha256": source_digest})

    current_stage = current.get("current_stage", {})
    progress_state = {
        "work_id": work.get("work_id"),
        "implementation_step": work.get("implementation_step"),
        "work_status": work.get("status"),
        "current_stage": {
            "id": current_stage.get("id"),
            "work_unit_id": _stage_work_unit_id(current_stage),
            "status": current_stage.get("status"),
            "implementation_step": current_stage.get("implementation_step"),
        },
        "current_result": work.get("current_result"),
        "manifest": manifest_state,
        "implementation_sources": implementation_sources,
    }
    payload = json.dumps(progress_state, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _persist_progress_checkpoint(root: Path, snapshot: dict[str, Any]) -> None:
    """Persist only the latest progress checkpoint; no event-history log is created."""
    current_path = root / "P1-CURRENT.json"
    if current_path.is_symlink():
        raise ValueError("CURRENT_PATH_SYMLINK")
    current_raw = current_path.read_bytes()
    if _sha256_bytes(current_raw) != snapshot["current_raw_sha256"]:
        raise ValueError("PROGRESS_CURRENT_CONCURRENT_MODIFICATION")
    current = json.loads(current_raw.decode("utf-8"))
    active_path, active_ref = _active_work_location(root, current)
    stage = current.get("current_stage", {})
    if (
        active_ref != snapshot["work_ref"]
        or active_path != snapshot["work_path"]
        or stage.get("id") != snapshot["stage_id"]
        or _stage_work_unit_id(stage) != snapshot["work_unit_id"]
    ):
        raise ValueError("PROGRESS_STATE_AUTHORITY_CHANGED")
    work_path = snapshot["work_path"]
    if work_path.is_symlink() or not work_path.resolve().is_relative_to(root.resolve()):
        raise ValueError("ACTIVE_WORK_PATH_FORBIDDEN")
    raw = work_path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != snapshot["raw_sha256"]:
        raise ValueError("PROGRESS_WORK_PACKET_CONCURRENT_MODIFICATION")
    _validate_document_schema(
        root, snapshot["work"], "P1-Central-Control/schemas/operational_work_unit.schema.json",
        "PROGRESS_WORK_PACKET",
    )
    _atomic_write_json(work_path, snapshot["work"])


def _admit_construction_progress_request(
    request: dict[str, Any], root: Path, protocol_operation: str
) -> dict[str, Any]:
    """Apply the canonical role admission gate before checkpoint/result-driven writes."""
    role_id = request.get("role_id")
    gate_configs = {
        "REPORT_PROGRESS": {
            "ROLE:EXECUTOR": (
                "！施工", "IP:CONSTRUCTION-EXECUTOR", "CONSTRUCTION",
                "WRITE_CHECKPOINT", ["CHECKPOINT"]
            ),
            "ROLE:CONTROL_RESEARCH": (
                "！討論", "IP:CONTROL-DISCUSSION", "DISCUSSION",
                "MODIFY_CONSTRUCTION", ["TASK_ARTIFACTS"]
            ),
        },
        "SUBMIT_ROLE_RESULT": {
            "ROLE:EXECUTOR": (
                "！施工", "IP:CONSTRUCTION-EXECUTOR", "CONSTRUCTION",
                "WRITE_RESULT", ["RESULT"]
            ),
            "ROLE:CONTROL_RESEARCH": (
                "！討論", "IP:CONTROL-DISCUSSION", "DISCUSSION",
                "MODIFY_CONSTRUCTION", ["TASK_ARTIFACTS"]
            ),
            "ROLE:VERIFIER": (
                "！驗收", "IP:ACCEPTANCE-VERIFIER", "ACCEPTANCE",
                "WRITE_VERIFICATION_RESULT", ["VERIFICATION_RESULT"]
            ),
        },
    }
    config = gate_configs.get(protocol_operation, {}).get(role_id)
    if config is None:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request.get("request_id"),
            "role_id": role_id,
            "reason_codes": ["ROLE_NOT_ALLOWED_FOR_PROGRESS_CHECKPOINT"],
        }
    activation_command, profile_id, mode, admitted_operation, write_targets = config
    current = load_current(root)
    gate_request = dict(request)
    if not gate_request.get("work_unit_ref"):
        gate_request["work_unit_ref"] = _stage_work_unit_id(current.get("current_stage", {}))
    return _role_request(
        gate_request,
        activation_command=activation_command,
        profile_id=profile_id,
        mode=mode,
        operation=admitted_operation,
        requested_write_targets=write_targets,
        root=root,
    )


def _record_construction_progress_checkpoint(
    request: dict[str, Any], root: Path
) -> dict[str, Any] | None:
    """Watch progress reports and repeated unresolved executor results through Central."""
    role_id = request.get("role_id")
    current = load_current(root)
    snapshot = _load_active_work_snapshot(root, current)
    work = snapshot["work"]
    if role_id not in {"ROLE:EXECUTOR", "ROLE:CONTROL_RESEARCH"}:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": role_id,
            "reason_codes": ["ROLE_NOT_ALLOWED_FOR_PROGRESS_CHECKPOINT"],
        }
    current_stage = current.get("current_stage", {})
    if (
        work.get("status") not in EXECUTOR_READY_STATUSES
        or current_stage.get("status") not in EXECUTOR_READY_STATUSES
    ):
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": role_id,
            "reason_codes": ["WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION"],
            "work_status": work.get("status"),
            "stage_status": current_stage.get("status"),
        }
    control = _normalize_brain_mode_control(work)
    guard = dict(control.get("progress_guard") or initial_control_state()["progress_guard"])
    fingerprint = _construction_progress_fingerprint(root, work)
    previous = guard.get("last_checkpoint_fingerprint", "")
    same_checkpoint = previous == fingerprint and bool(previous)

    # A stall recovery leaves Brain in THINKING. Neither repeated reports nor a
    # changed source file alone may resume construction; require an authorized
    # successful transition back into CONSTRUCTION to clear this latch.
    stalled_pause_latched = (
        guard.get("last_classification") == "STALLED"
        and guard.get("last_review_status") in {"REVIEW_GENERATED", "BLOCKED", "ERROR"}
        and bool(guard.get("last_reviewed_fingerprint"))
    )
    if stalled_pause_latched:
        repeats = (
            min(100, int(guard.get("no_progress_repeats", 0)) + 1)
            if same_checkpoint else 0
        )
        guard["last_checkpoint_fingerprint"] = fingerprint
        guard["no_progress_repeats"] = repeats
        guard["last_classification"] = "STALLED"
        control["progress_guard"] = guard
        source_changed_after_review = guard.get("last_reviewed_fingerprint") != fingerprint
        reason_code = (
            "CONSTRUCTION_PAUSED_SOURCE_CHANGED_REVIEW_REQUIRED"
            if source_changed_after_review
            else "CONSTRUCTION_STALLED_ALREADY_REVIEWED"
        )
        if source_changed_after_review:
            work["next_action"] = (
                "REVIEW_SOURCE_CHANGE_IN_THINKING_AND_EXPLICITLY_APPROVE_CONSTRUCTION_RESUME"
            )
            handoff = work.get("handoff")
            if isinstance(handoff, dict):
                handoff["next_step"] = work["next_action"]
        _persist_progress_checkpoint(root, snapshot)
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": role_id,
            "reason_codes": [reason_code],
            "progress_classification": "STALLED",
            "no_progress_repeats": repeats,
            "health_review_rerun": False,
            "next_action": (
                work["next_action"] if source_changed_after_review else work.get("next_action")
            ),
        }

    # After the dedicated stall-latch path has persisted any source drift, all
    # other Executor progress remains blocked while Brain is paused or unapproved.
    if role_id == "ROLE:EXECUTOR" and (
        control.get("mode") != "CONSTRUCTION"
        or control.get("plan_approved") is not True
    ):
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": role_id,
            "reason_codes": ["BRAIN_NOT_IN_AUTHORIZED_CONSTRUCTION_MODE"],
            "brain_mode": control.get("mode"),
            "plan_approved": control.get("plan_approved") is True,
        }

    if same_checkpoint:
        repeats = min(100, int(guard.get("no_progress_repeats", 0)) + 1)
        classification = "NO_PROGRESS_REPEAT"
    else:
        repeats = 0
        classification = "PROGRESS_CHANGED" if previous else "NOT_CHECKED"
        guard["last_reviewed_fingerprint"] = ""
        guard["last_review_status"] = "NOT_RUN"

    guard["last_checkpoint_fingerprint"] = fingerprint
    guard["no_progress_repeats"] = repeats
    guard["last_classification"] = classification
    control["progress_guard"] = guard

    if same_checkpoint and repeats >= 2:
        if guard.get("last_reviewed_fingerprint") != fingerprint:
            try:
                health_review = generate_construction_health_review(trigger="stalled", root=root)
                review_status = "REVIEW_GENERATED" if health_review.get("status") == "REVIEW_GENERATED" else "BLOCKED"
            except (OSError, ValueError, TypeError, RuntimeError, subprocess.TimeoutExpired) as exc:
                health_review = {
                    "status": "BLOCKED",
                    "reason_code": str(exc).split(":", 1)[0],
                    "detail": str(exc)[:500],
                }
                review_status = "ERROR"

            transition = transition_mode(
                current_mode=control.get("mode", "THINKING"),
                event="CONSTRUCTION_STALLED",
                plan_gates=control.get("plan_gates"),
                plan_approved=control.get("plan_approved") is True,
                feature_batch_complete=control.get("feature_batch_complete") is True,
                simulation_batch_passed=control.get("simulation_batch_passed") is True,
                integration_batch_passed=control.get("integration_batch_passed") is True,
            )
            if transition.get("status") != "PASS":
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "reason_codes": ["CONSTRUCTION_STALLED_TRANSITION_BLOCKED", transition.get("reason_code", "UNKNOWN")],
                    "transition": transition,
                }
            guard["last_reviewed_fingerprint"] = fingerprint
            guard["last_review_status"] = review_status
            guard["last_classification"] = "STALLED"
            control["progress_guard"] = guard
            recommendations = health_review.get("recommendations", [])
            first_recommendation = next(
                (
                    " ".join(item.split())[:350]
                    for item in recommendations
                    if isinstance(item, str) and item.strip()
                ),
                "",
            ) if isinstance(recommendations, list) else ""
            work["next_action"] = (
                (
                    "FIX_ROOT_CAUSE_FROM_BOUNDED_HEALTH_REVIEW_FIRST: "
                    + first_recommendation
                    + " THEN_ADVANCE_TO_NEXT_UNBLOCKED_FEATURE"
                )
                if review_status == "REVIEW_GENERATED" and first_recommendation
                else (
                    "USE_BOUNDED_HEALTH_REVIEW_TO_FIX_ROOT_CAUSE_THEN_ADVANCE_TO_NEXT_UNBLOCKED_FEATURE"
                    if review_status == "REVIEW_GENERATED"
                    else "RESOLVE_HEALTH_REVIEW_BLOCKER_THEN_ADVANCE_TO_NEXT_UNBLOCKED_FEATURE"
                )
            )
            handoff = work.get("handoff")
            if isinstance(handoff, dict):
                handoff["next_step"] = work["next_action"]
            _persist_cognitive_transition(
                root=root, snapshot=snapshot, role_id=role_id, transition=transition
            )
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": role_id,
                "reason_codes": ["CONSTRUCTION_STALLED_NO_PROGRESS"],
                "progress_classification": "STALLED",
                "no_progress_repeats": repeats,
                "recovery_state_persisted": True,
                "next_action": work["next_action"],
                "transition": transition,
                "health_review": health_review,
            }
        guard["last_classification"] = "STALLED"
        control["progress_guard"] = guard
        _persist_progress_checkpoint(root, snapshot)
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": role_id,
            "reason_codes": ["CONSTRUCTION_STALLED_ALREADY_REVIEWED"],
            "progress_classification": "STALLED",
            "no_progress_repeats": repeats,
            "next_action": work.get("next_action"),
            "health_review_rerun": False,
        }

    _persist_progress_checkpoint(root, snapshot)
    return {
        "status": "PASS",
        "accepted": True,
        "request_id": request["request_id"],
        "role_id": role_id,
        "central_authority": "P1-CURRENT",
        "progress_classification": classification,
        "no_progress_repeats": repeats,
        "next_action": "RETURN_PROGRESS_TO_CENTRAL",
    }


def report_progress(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    validate_request(request)
    if request["operation"] != "REPORT_PROGRESS":
        raise ValueError("REPORT_PROGRESS_REQUIRED")
    if not request.get("summary"):
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": ["PROGRESS_SUMMARY_REQUIRED"],
        }

    try:
        admission = _admit_construction_progress_request(request, root, "REPORT_PROGRESS")
        if admission.get("status") != "PASS":
            return admission
        checkpoint = _record_construction_progress_checkpoint(request, root)
    except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": request["role_id"],
            "reason_codes": ["PROGRESS_CHECKPOINT_FAILED", str(exc).split(":", 1)[0]],
            "detail": str(exc)[:500],
        }
    if checkpoint is not None:
        checkpoint["summary"] = request["summary"]
        return checkpoint

    return {
        "status": "PASS",
        "accepted": True,
        "request_id": request["request_id"],
        "role_id": request["role_id"],
        "central_authority": "P1-CURRENT",
        "summary": request["summary"],
        "next_action": "RETURN_PROGRESS_TO_CENTRAL",
    }


def submit_role_result(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    validate_request(request)
    if request["operation"] != "SUBMIT_ROLE_RESULT":
        raise ValueError("SUBMIT_ROLE_RESULT_REQUIRED")
    if not request.get("result_ref"):
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": ["RESULT_REF_REQUIRED"],
        }

    status = request.get("result_status")
    if status not in ALLOWED_RESULT_STATUS[request["role_id"]]:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": request["role_id"],
            "reason_codes": ["RESULT_STATUS_NOT_ALLOWED_FOR_ROLE"],
            "result_status": status,
        }

    # Every submitted role result must pass the same canonical role/session gate
    # before any result-specific transition or persistence.
    try:
        admission = _admit_construction_progress_request(request, root, "SUBMIT_ROLE_RESULT")
        if admission.get("status") != "PASS":
            return admission
    except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
        return {
            "status": "BLOCK",
            "accepted": False,
            "request_id": request["request_id"],
            "role_id": request["role_id"],
            "reason_codes": ["ROLE_RESULT_ADMISSION_FAILED", str(exc).split(":", 1)[0]],
            "detail": str(exc)[:500],
        }

    # Repeated unresolved Executor/Control results are progress checkpoints too.
    # Two unchanged repeats after a baseline pause the loop and trigger one bounded review.
    if (
        status in {"INCOMPLETE", "BLOCK", "UNRESOLVED", "BLOCKED"}
        and request["role_id"] in {"ROLE:EXECUTOR", "ROLE:CONTROL_RESEARCH"}
    ):
        try:
            progress_check = _record_construction_progress_checkpoint(request, root)
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["PROGRESS_CHECKPOINT_FAILED", str(exc).split(":", 1)[0]],
                "detail": str(exc)[:500],
            }
        if progress_check is not None and (
            progress_check.get("status") != "PASS"
            or progress_check.get("progress_classification") == "STALLED"
        ):
            progress_check["result_ref"] = request["result_ref"]
            progress_check["result_status"] = status
            return progress_check

    # WORK_COMPLETE is a construction claim. During the feature batch it advances
    # to local case simulation only; formal acceptance requires an explicit request
    # after the Central-controlled batch readiness flags have both been set.
    if request["role_id"] == "ROLE:EXECUTOR" and status == "WORK_COMPLETE":
        current_for_work = load_current(root)
        stage_for_work = current_for_work.get("current_stage", {})
        try:
            snapshot = _load_active_work_snapshot(root, current_for_work)
            work_path = snapshot["work_path"]
            active_work = snapshot["work"]
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": [str(exc).split(":", 1)[0]],
            }
        control = _normalize_brain_mode_control(active_work)
        final_requested = request.get("final_batch_acceptance") is True
        if not final_requested:
            if (
                stage_for_work.get("status") in PENDING_STAGE_STATUSES
                or active_work.get("status") in PENDING_STAGE_STATUSES
            ):
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "role_id": request["role_id"],
                    "reason_codes": ["FINAL_BATCH_ACCEPTANCE_NOT_REQUESTED"],
                }
            transition = transition_mode(
                current_mode=control.get("mode", "THINKING"),
                event="CONSTRUCTION_STEP_COMPLETE",
                plan_gates=control.get("plan_gates"),
                plan_approved=control.get("plan_approved") is True,
                feature_batch_complete=control.get("feature_batch_complete") is True,
                simulation_batch_passed=control.get("simulation_batch_passed") is True,
            )
            if transition["status"] != "PASS":
                recovery_persisted = False
                if transition["mode"] == "THINKING" and transition["construction_paused"]:
                    try:
                        _persist_cognitive_transition(
                            root=root,
                            snapshot=snapshot,
                            role_id="ROLE:EXECUTOR",
                            transition=transition,
                        )
                        recovery_persisted = True
                    except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
                        return {
                            "status": "BLOCK",
                            "accepted": False,
                            "request_id": request["request_id"],
                            "role_id": request["role_id"],
                            "reason_codes": [
                                "COGNITIVE_RECOVERY_PERSIST_FAILED",
                                str(exc).split(":", 1)[0],
                            ],
                            "cognitive_transition": transition,
                        }
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "role_id": request["role_id"],
                    "reason_codes": [transition["reason_code"]],
                    "cognitive_transition": transition,
                    "recovery_state_persisted": recovery_persisted,
                }
            try:
                _persist_cognitive_transition(
                    root=root,
                    snapshot=snapshot,
                    role_id="ROLE:EXECUTOR",
                    transition=transition,
                )
            except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "role_id": request["role_id"],
                    "reason_codes": ["COGNITIVE_STATE_PERSIST_FAILED", str(exc).split(":", 1)[0]],
                }
            return {
                "status": "PASS",
                "accepted": True,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "result_ref": request["result_ref"],
                "result_status": status,
                "central_authority": "P1-CURRENT",
                "next_action": "LOCAL_CASE_SIMULATION_REQUIRED",
                "cognitive_transition": transition,
                "formal_acceptance_created": False,
            }

        if (
            control.get("feature_batch_complete") is not True
            or control.get("simulation_batch_passed") is not True
            or control.get("integration_batch_passed") is not True
            or not isinstance(control.get("final_batch_report_ref"), str)
            or control.get("mode") != "FINAL_ACCEPTANCE"
        ):
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["FINAL_BATCH_NOT_READY"],
                "formal_acceptance_created": False,
            }
        if (
            stage_for_work.get("status") not in PENDING_STAGE_STATUSES
            or active_work.get("status") not in PENDING_STAGE_STATUSES
        ):
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["WORK_UNIT_NOT_READY_FOR_ACCEPTANCE_CONTEXT"],
                "formal_acceptance_created": False,
            }

    if request["role_id"] == "ROLE:VERIFIER":
        current = load_current(root)
        stage = current.get("current_stage", {})
        current_acceptance_ref = stage.get("acceptance_ref")
        submitted_acceptance_ref = request.get("acceptance_ref")
        submitted_head_sha = request.get("head_sha")

        if not current_acceptance_ref:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_MISSING"],
            }
        if submitted_acceptance_ref != current_acceptance_ref:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_REF_MISMATCH"],
            }

        context_relative = Path(current_acceptance_ref)
        if (
            context_relative.is_absolute()
            or ".." in context_relative.parts
            or current_acceptance_ref.startswith("/")
        ):
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
            }
        root_resolved = root.resolve()
        context_path = root_resolved / context_relative
        context_cursor = root_resolved
        for part in context_relative.parts:
            context_cursor = context_cursor / part
            if context_cursor.is_symlink():
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "role_id": request["role_id"],
                    "reason_codes": ["ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
                }
        if not context_path.resolve().is_relative_to(root_resolved):
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
            }
        if not context_path.is_file():
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_NOT_FOUND"],
            }
        try:
            context = load(context_path)
            context_kind = context.get("kind")
            if context_kind == "OPERATIONAL_ACCEPTANCE_CONTEXT":
                context_schema = load(root / "P1-Central-Control/schemas/operational_acceptance_context.schema.json")
                Draft202012Validator(context_schema).validate(context)
                context_base = {key: value for key, value in context.items() if key != "content_sha256"}
                expected_digest = "sha256:" + hashlib.sha256(
                    json.dumps(context_base, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
                ).hexdigest()
                if context.get("content_sha256") != expected_digest:
                    raise ValueError("OPERATIONAL_ACCEPTANCE_CONTEXT_DIGEST_MISMATCH")
                evidence = _validate_final_batch_report(root, context.get("final_batch_report_ref"))
                if evidence.get("report_sha256") != context.get("report_sha256"):
                    raise ValueError("FINAL_BATCH_REPORT_DIGEST_MISMATCH")
                if evidence.get("repository_commit") != context.get("head_sha"):
                    raise ValueError("ACCEPTANCE_CONTEXT_REPORT_HEAD_MISMATCH")
                active_work_path, active_work_ref = _active_work_location(root, current)
                active_work = load(active_work_path)
                active_control = active_work.get("brain_mode_control", {})
                if (
                    active_work_ref != current.get("implementation_control", {}).get("active_work_packet")
                    or active_work.get("work_id") != context.get("work_id")
                    or (_stage_work_unit_id(stage)) != context.get("work_unit_ref")
                    or active_work.get("construction_packet_ref") != context.get("construction_packet_ref")
                    or stage.get("status") not in PENDING_STAGE_STATUSES
                    or active_work.get("status") not in PENDING_STAGE_STATUSES
                    or active_control.get("mode") != "FINAL_ACCEPTANCE"
                    or active_control.get("feature_batch_complete") is not True
                    or active_control.get("simulation_batch_passed") is not True
                    or active_control.get("integration_batch_passed") is not True
                    or active_control.get("final_batch_report_ref") != context.get("final_batch_report_ref")
                ):
                    raise ValueError("OPERATIONAL_ACCEPTANCE_STATE_MISMATCH")
            elif context_kind == "ACCEPTANCE_CONTEXT":
                legacy_schema = load(root / "P1-Central-Control/schemas/acceptance_context.schema.json")
                Draft202012Validator(legacy_schema).validate(context)
            else:
                raise ValueError("ACCEPTANCE_CONTEXT_KIND_UNSUPPORTED")
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_INVALID", str(exc).split(":", 1)[0]],
            }
        expected_head_sha = context.get("head_sha")
        if not expected_head_sha:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["ACCEPTANCE_CONTEXT_HEAD_MISSING"],
            }
        if submitted_head_sha != expected_head_sha:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["STALE_ACCEPTANCE_HEAD_SHA"],
            }

    acceptance_ref = None
    admission = None
    if request["role_id"] == "ROLE:VERIFIER" and request.get("result_status") == "PASS":
        admission = compute_next_stage_admission(current=load_current(root))
        next_action = (
            "CENTRAL_NEXT_STAGE_ADMITTED"
            if admission["status"] == "PASS"
            else admission.get("next_action", "CENTRAL_NEXT_STAGE_ADMISSION_PENDING")
        )
    elif request["role_id"] == "ROLE:VERIFIER":
        next_action = "RETURN_TO_CONTROL_RESEARCH"
    elif request["role_id"] == "ROLE:EXECUTOR":
        next_action = "CENTRAL_EVALUATE_WORK_UNIT_CLOSE"
        if request.get("result_status") == "WORK_COMPLETE":
            if (
                request.get("final_batch_acceptance") is True
                and isinstance(active_work, dict)
                and isinstance(active_work.get("operational_contract"), dict)
                and isinstance(active_work.get("work_id"), str)
                and not active_work.get("task_packet_ref")
            ):
                # Operational Work Units have already received their report-bound
                # context through FINAL_BATCH_READY. Never run the legacy creator again.
                current_after_batch = load_current(root)
                stage_after_batch = current_after_batch.get("current_stage", {})
                acceptance_ref = stage_after_batch.get("acceptance_ref")
                if not isinstance(acceptance_ref, str) or not acceptance_ref:
                    return {
                        "status": "BLOCK",
                        "accepted": False,
                        "request_id": request["request_id"],
                        "role_id": request["role_id"],
                        "reason_codes": ["OPERATIONAL_ACCEPTANCE_CONTEXT_NOT_BOUND"],
                    }
                context_relative = Path(acceptance_ref)
                if context_relative.is_absolute() or ".." in context_relative.parts:
                    return {
                        "status": "BLOCK",
                        "accepted": False,
                        "request_id": request["request_id"],
                        "role_id": request["role_id"],
                        "reason_codes": ["OPERATIONAL_ACCEPTANCE_CONTEXT_PATH_FORBIDDEN"],
                    }
                context_path = root / context_relative
                if (
                    context_path.is_symlink()
                    or not context_path.is_file()
                    or not context_path.resolve().is_relative_to(root.resolve())
                ):
                    return {
                        "status": "BLOCK",
                        "accepted": False,
                        "request_id": request["request_id"],
                        "role_id": request["role_id"],
                        "reason_codes": ["OPERATIONAL_ACCEPTANCE_CONTEXT_NOT_FOUND"],
                    }
                try:
                    context_document = load(context_path)
                except (OSError, ValueError, json.JSONDecodeError) as exc:
                    return {
                        "status": "BLOCK",
                        "accepted": False,
                        "request_id": request["request_id"],
                        "role_id": request["role_id"],
                        "reason_codes": ["OPERATIONAL_ACCEPTANCE_CONTEXT_INVALID", str(exc).split(":", 1)[0]],
                    }
                if (
                    context_document.get("kind") != "OPERATIONAL_ACCEPTANCE_CONTEXT"
                    or context_document.get("status") != "OPEN"
                    or context_document.get("work_id") != active_work.get("work_id")
                    or context_document.get("head_sha") != stage_after_batch.get("validated_head_sha")
                ):
                    return {
                        "status": "BLOCK",
                        "accepted": False,
                        "request_id": request["request_id"],
                        "role_id": request["role_id"],
                        "reason_codes": ["OPERATIONAL_ACCEPTANCE_CONTEXT_BINDING_MISMATCH"],
                    }
                next_action = "CENTRAL_ACCEPTANCE_CONTEXT_READY"
            else:
                # Legacy Task Packets retain their existing acceptance lifecycle.
                try:
                    lifecycle_result = create_acceptance_context(root=root)
                except ValueError as exc:
                    return {
                        "status": "BLOCK",
                        "accepted": False,
                        "request_id": request["request_id"],
                        "role_id": request["role_id"],
                        "reason_codes": ["WORK_UNIT_CLOSE_BOUNDARY_NOT_REACHED"],
                        "detail": str(exc),
                    }
                acceptance_ref = lifecycle_result["acceptance_ref"]
                next_action = "CENTRAL_ACCEPTANCE_CONTEXT_READY"
    else:
        next_action = "CENTRAL_PROCESS_RESEARCH_RESULT"

    cognitive_transition = None
    if (
        request["role_id"] == "ROLE:VERIFIER"
        and context.get("kind") == "OPERATIONAL_ACCEPTANCE_CONTEXT"
        and status in {"PASS", "FAIL", "BLOCK", "INCOMPLETE"}
    ):
        event = "FINAL_ACCEPTANCE_PASSED" if status == "PASS" else "FINAL_ACCEPTANCE_FAILED"
        try:
            snapshot = _load_active_work_snapshot(root, current)
            work_path = snapshot["work_path"]
            active_work = snapshot["work"]
        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": [str(exc).split(":", 1)[0]],
            }
        control = _normalize_brain_mode_control(active_work)
        cognitive_transition = transition_mode(
            current_mode=control.get("mode", "THINKING"),
            event=event,
            plan_gates=control.get("plan_gates"),
            plan_approved=control.get("plan_approved") is True,
            feature_batch_complete=control.get("feature_batch_complete") is True,
            simulation_batch_passed=control.get("simulation_batch_passed") is True,
            integration_batch_passed=control.get("integration_batch_passed") is True,
        )
        if cognitive_transition["status"] != "PASS":
            return {
                "status": "BLOCK",
                "accepted": False,
                "request_id": request["request_id"],
                "role_id": request["role_id"],
                "reason_codes": ["COGNITIVE_STATE_TRANSITION_BLOCKED", cognitive_transition["reason_code"]],
            }
        if context.get("kind") == "OPERATIONAL_ACCEPTANCE_CONTEXT":
            try:
                outcome = _persist_operational_verifier_outcome(
                    root=root,
                    current=current,
                    snapshot=snapshot,
                    context_ref=current_acceptance_ref,
                    transition=cognitive_transition,
                    verifier_passed=(status == "PASS"),
                )
            except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "role_id": request["role_id"],
                    "reason_codes": ["OPERATIONAL_VERIFIER_OUTCOME_PERSIST_FAILED", str(exc).split(":", 1)[0]],
                    "detail": str(exc),
                }
            admission = outcome["next_stage_admission"]
            next_action = outcome["next_action"]
        else:
            try:
                _persist_cognitive_transition(
                    root=root,
                    snapshot=snapshot,
                    role_id="ROLE:VERIFIER",
                    transition=cognitive_transition,
                )
            except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
                return {
                    "status": "BLOCK",
                    "accepted": False,
                    "request_id": request["request_id"],
                    "role_id": request["role_id"],
                    "reason_codes": ["COGNITIVE_STATE_PERSIST_FAILED", str(exc).split(":", 1)[0]],
                }

    result = {
        "status": "PASS",
        "accepted": True,
        "request_id": request["request_id"],
        "role_id": request["role_id"],
        "result_ref": request["result_ref"],
        "result_status": request.get("result_status"),
        "central_authority": "P1-CURRENT",
        "next_action": next_action,
    }
    if acceptance_ref is not None:
        result["acceptance_ref"] = acceptance_ref
    if request["role_id"] == "ROLE:VERIFIER":
        result["acceptance_ref"] = request.get("acceptance_ref")
        result["head_sha"] = request.get("head_sha")
    if admission is not None:
        result["admission"] = admission
    if cognitive_transition is not None:
        result["cognitive_transition"] = cognitive_transition
    return result



def control_feature_batch(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    """Central-authorized batch control, separate from per-work cognitive modes."""
    action = request.get("batch_action")
    role_id = request.get("role_id")
    allowed_roles = {
        "STATUS": {"ROLE:CONTROL_RESEARCH", "ROLE:EXECUTOR", "ROLE:VERIFIER"},
        "MARK_IMPLEMENTED": {"ROLE:EXECUTOR"},
        "ADVANCE_CLOSURE": {"ROLE:CONTROL_RESEARCH"},
        "PREPARE_OFFICIAL_ROSTER": {"ROLE:CONTROL_RESEARCH"},
        "ADVANCE_FINAL_TEST": {"ROLE:CONTROL_RESEARCH"},
    }
    if action not in allowed_roles:
        return {
            "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
            "reason_codes": ["FEATURE_BATCH_ACTION_UNKNOWN"],
        }
    if role_id not in allowed_roles[action]:
        return {
            "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
            "reason_codes": ["FEATURE_BATCH_ACTION_ROLE_FORBIDDEN"],
        }

    # STATUS is read-only; every batch mutation additionally requires canonical
    # role/session admission, not merely a caller-supplied role_id string.
    if action != "STATUS":
        gate_configs = {
            "MARK_IMPLEMENTED": (
                "ROLE:EXECUTOR", "！施工", "IP:CONSTRUCTION-EXECUTOR",
                "CONSTRUCTION", "WRITE_RESULT", ["RESULT"]
            ),
            "ADVANCE_CLOSURE": (
                "ROLE:CONTROL_RESEARCH", "！討論", "IP:CONTROL-DISCUSSION",
                "DISCUSSION", "MODIFY_CONSTRUCTION", ["TASK_ARTIFACTS"]
            ),
            "PREPARE_OFFICIAL_ROSTER": (
                "ROLE:CONTROL_RESEARCH", "！討論", "IP:CONTROL-DISCUSSION",
                "DISCUSSION", "MODIFY_CONSTRUCTION", ["TASK_ARTIFACTS"]
            ),
            "ADVANCE_FINAL_TEST": (
                "ROLE:CONTROL_RESEARCH", "！討論", "IP:CONTROL-DISCUSSION",
                "DISCUSSION", "MODIFY_CONSTRUCTION", ["TASK_ARTIFACTS"]
            ),
        }
        activation_role, activation_command, profile_id, mode, admitted_operation, write_targets = gate_configs[action]
        if role_id != activation_role:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["FEATURE_BATCH_ACTION_ROLE_FORBIDDEN"],
            }
        try:
            current = load_current(root)
            gate_request = dict(request)
            if not gate_request.get("work_unit_ref"):
                gate_request["work_unit_ref"] = _stage_work_unit_id(current.get("current_stage", {}))
            admission = _role_request(
                gate_request,
                activation_command=activation_command,
                profile_id=profile_id,
                mode=mode,
                operation=admitted_operation,
                requested_write_targets=write_targets,
                root=root,
            )
            if admission.get("status") != "PASS":
                return admission

        except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["FEATURE_BATCH_ROLE_ADMISSION_FAILED", str(exc).split(":", 1)[0]],
                "detail": str(exc)[:500],
            }

    feature_id = request.get("feature_id")
    try:
        if action == "STATUS":
            outcome = inspect_batch(root)
        elif action == "MARK_IMPLEMENTED":
            if not isinstance(feature_id, str) or not feature_id:
                raise BatchGateError("FEATURE_ID_REQUIRED")
            outcome = mark_feature_implemented(root, feature_id)
        elif action == "ADVANCE_CLOSURE":
            outcome = advance_phase(root, "CLOSURE")
        elif action == "PREPARE_OFFICIAL_ROSTER":
            outcome = prepare_official_test_roster(root)
        else:
            outcome = advance_phase(root, "FINAL_TEST")
        return {
            "status": "PASS", "accepted": True,
            "request_id": request["request_id"],
            "operation": "FEATURE_BATCH_CONTROL",
            "batch_action": action, "batch_result": outcome,
            "central_authority": "P1-CURRENT",
            "execution_evidence": (
                "NO_RUNTIME_TEST_EXECUTED_BY_CONTROL_OPERATION"
                if action != "STATUS" else "READ_ONLY_BATCH_INSPECTION"
            ),
        }
    except BatchGateError as exc:
        return {
            "status": "BLOCK", "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": [exc.code], "detail": exc.detail,
            "central_authority": "P1-CURRENT",
        }
    except (OSError, ValueError, json.JSONDecodeError, ValidationError) as exc:
        return {
            "status": "BLOCK", "accepted": False,
            "request_id": request["request_id"],
            "reason_codes": ["FEATURE_BATCH_CONTROL_INVALID"], "detail": str(exc)[:1000],
            "central_authority": "P1-CURRENT",
        }




def control_feature_decision(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    """Invoke F27/F28 through the existing Central role boundary without writing state."""
    operation = request.get("operation")
    role_id = request.get("role_id")
    if operation == "ROOT_CAUSE_DISTILLATION":
        if role_id != "ROLE:CONTROL_RESEARCH":
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["ROOT_CAUSE_DISTILLATION_ROLE_FORBIDDEN"],
            }
        payload = request.get("root_cause_request")
        try:
            if not isinstance(payload, dict):
                raise RootCauseDistillationError("ROOT_CAUSE_REQUEST_OBJECT_REQUIRED")
            decision = distill_root_cause(payload)
            return {
                "status": "PASS", "accepted": True, "request_id": request["request_id"],
                "operation": operation, "root_cause_decision": decision,
                "domain_decision_status": decision["status"],
                "central_authority": "P1-CURRENT",
                "state_written": False, "registry_written": False, "execution_authorized": False,
            }
        except (OSError, ValueError, RootCauseDistillationError) as exc:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": [str(exc).split(":", 1)[0]], "detail": str(exc)[:1000],
                "state_written": False, "registry_written": False, "execution_authorized": False,
            }
    if operation == "CAPABILITY_LIFECYCLE_REVIEW":
        if role_id != "ROLE:CONTROL_RESEARCH":
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["CAPABILITY_LIFECYCLE_ROLE_FORBIDDEN"],
            }
        payload = request.get("capability_lifecycle_request")
        try:
            if not isinstance(payload, dict):
                raise ValueError("CAPABILITY_LIFECYCLE_REQUEST_OBJECT_REQUIRED")
            decision = review_capability_lifecycle(payload)
            return {
                "status": "PASS", "accepted": True, "request_id": request["request_id"],
                "operation": operation, "capability_lifecycle": decision,
                "domain_decision_status": decision["status"],
                "central_authority": "P1-CURRENT",
                "state_written": False,
                "registry_written": False,
                "execution_authorized": False,
            }
        except (OSError, ValueError) as exc:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": [str(exc).split(":", 1)[0]], "detail": str(exc)[:1000],
                "state_written": False,
                "registry_written": False,
                "execution_authorized": False,
            }
    if operation == "SYSTEM_FACTORY_STRATEGY":
        if role_id != "ROLE:CONTROL_RESEARCH":
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["FACTORY_STRATEGY_ROLE_FORBIDDEN"],
            }
        payload = request.get("factory_strategy_request")
        try:
            if not isinstance(payload, dict):
                raise FactoryStrategyError("FACTORY_STRATEGY_REQUEST_OBJECT_REQUIRED")
            decision = decide_strategy(payload, root)
            validate_factory_strategy_result(decision, root)
            return {
                "status": "PASS", "accepted": True, "request_id": request["request_id"],
                "operation": operation, "factory_strategy": decision,
                "domain_decision_status": decision["status"],
                "central_authority": "P1-CURRENT",
                "state_written": False,
                "execution_authorized": False,
            }
        except (OSError, ValueError, FactoryStrategyError, ValidationError) as exc:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": [str(exc).split(":", 1)[0]], "detail": str(exc)[:1000],
                "execution_authorized": False,
            }
    if operation == "INTENT_RESOLUTION":
        if role_id != "ROLE:CONTROL_RESEARCH":
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["INTENT_RESOLUTION_ROLE_FORBIDDEN"],
            }
        payload = request.get("intent_request")
        try:
            if not isinstance(payload, dict):
                raise IntentResolutionError("INTENT_REQUEST_OBJECT_REQUIRED")
            result = resolve_intent(payload)
            validate_result(result, root)
            return {
                "status": "PASS", "accepted": True, "request_id": request["request_id"],
                "operation": operation, "intent_resolution": result,
                "domain_decision_status": result["status"],
                "central_authority": "P1-CURRENT",
                "state_written": False,
            }
        except (OSError, ValueError, IntentResolutionError) as exc:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": [str(exc).split(":", 1)[0]], "detail": str(exc)[:1000],
            }
    if operation == "PRESENTATION_DECISION":
        # F27 adaptive presentation was archived in R3d3 (archive/f27-presentation/).
        # The enum value stays in the locked schema; the operation is always refused.
        return {
            "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
            "reason_codes": ["PRESENTATION_ARCHIVED"],
        }
    if operation == "CHANGE_CLASSIFICATION":
        if role_id != "ROLE:CONTROL_RESEARCH":
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": ["CHANGE_CLASSIFICATION_ROLE_FORBIDDEN"],
            }
        payload = request.get("change_request")
        try:
            if not isinstance(payload, dict):
                raise ChangeClassificationError("CHANGE_REQUEST_OBJECT_REQUIRED")
            record = classify_and_route(payload)
            validate_record(record, root)
            return {
                "status": "PASS", "accepted": True, "request_id": request["request_id"],
                "operation": operation, "classification_record": record,
                "central_authority": "P1-CURRENT",
                "state_written": False,
                "domain_decision_status": record["status"],
            }
        except (OSError, ValueError, ChangeClassificationError) as exc:
            return {
                "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
                "reason_codes": [str(exc).split(":", 1)[0]], "detail": str(exc)[:1000],
            }
    if operation == "BLUEPRINT_UPDATE_ASSESSMENT":
        if role_id != "ROLE:CONTROL_RESEARCH":
            return {"status":"BLOCK","accepted":False,"request_id":request["request_id"],"reason_codes":["BLUEPRINT_UPDATE_ROLE_FORBIDDEN"]}
        payload=request.get("blueprint_update_request")
        try:
            if not isinstance(payload,dict): raise BlueprintUpdateError("BLUEPRINT_UPDATE_REQUEST_OBJECT_REQUIRED")
            payload=dict(payload)
            payload["mode"]="ASSESS_ONLY"
            validate_blueprint_update_request(payload,root)
            result=assess_update(root,payload)
            validate_blueprint_update_result(result,root)
            status="PASS" if result["status"]=="ASSESSMENT_READY" else "BLOCK"
            return {"status":status,"accepted":status=="PASS","request_id":request["request_id"],"operation":operation,
                    "blueprint_update_assessment":result,"domain_decision_status":result["status"],
                    "central_authority":"P1-CURRENT","state_written":False}
        except (OSError,ValueError,BlueprintUpdateError) as exc:
            return {"status":"BLOCK","accepted":False,"request_id":request["request_id"],
                    "reason_codes":[str(exc).split(":",1)[0]],"detail":str(exc)[:1000]}
    return {
        "status": "BLOCK", "accepted": False, "request_id": request["request_id"],
        "reason_codes": ["FEATURE_DECISION_OPERATION_UNKNOWN"],
    }



def execute(request: dict[str, Any], root: Path = ROOT) -> dict[str, Any]:
    validate_request(request)
    operation = request["operation"]
    if operation == "ROLE_ACTIVATE":
        return activate(request, root)
    if operation == "GET_ROLE_CONTEXT":
        return get_role_context(request, root)
    if operation == "REPORT_PROGRESS":
        return report_progress(request, root)
    if operation == "SUBMIT_ROLE_RESULT":
        return submit_role_result(request, root)
    if operation == "COGNITIVE_TRANSITION":
        return transition_cognition(request, root)
    if operation == "FEATURE_BATCH_CONTROL":
        return control_feature_batch(request, root)
    if operation in {
        "INTENT_RESOLUTION",
        "PRESENTATION_DECISION",
        "CHANGE_CLASSIFICATION",
        "BLUEPRINT_UPDATE_ASSESSMENT",
        "SYSTEM_FACTORY_STRATEGY",
        "CAPABILITY_LIFECYCLE_REVIEW",
        "ROOT_CAUSE_DISTILLATION",
    }:
        return control_feature_decision(request, root)
    raise ValueError(f"UNSUPPORTED_OPERATION:{operation}")


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Central-mediated role interface")
    parser.add_argument("--request", required=True)
    parser.add_argument("--output")
    args = parser.parse_args()

    request = load(Path(args.request).resolve())
    result = execute(request)
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        Path(args.output).write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if result.get("status") == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
