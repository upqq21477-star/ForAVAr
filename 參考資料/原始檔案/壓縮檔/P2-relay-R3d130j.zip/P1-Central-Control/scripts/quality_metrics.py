#!/usr/bin/env python3
"""CS-1 B8 Q1 品質指標：純函式，輸入為模擬／量測資料；SIMULATION_ONLY（結果不是 OBSERVED_RUNTIME）。

比率一律 0..1；分母為 0 時回傳 `empty`（預設 1.0＝無違規）。目標見 `TARGETS`；`EXTERNAL` 為模擬量不到、須 R-4 真實任務的指標。
"""
from __future__ import annotations

from typing import Any, Iterable

from archive_governance import retrieval_precision  # noqa: F401  (Archive Retrieval Precision，B4 定義)
from knowledge_retrieval import Retriever

# (指標, 方向, 門檻)：MIN＝不得低於；MAX＝不得高於
TARGETS = {
    "context_load": ("MAX", 1.0), "memory_contamination_rate": ("MAX", 0.0),
    "coverage_completeness": ("MIN", 1.0), "provenance_completeness": ("MIN", 1.0),
    "conflict_preservation_rate": ("MIN", 1.0), "unknown_preservation_rate": ("MIN", 1.0),
    "false_promotion_rate": ("MAX", 0.0), "archive_leakage_rate": ("MAX", 0.0),
    "archive_retrieval_precision": ("MIN", 1.0), "recovery_success_rate": ("MIN", 1.0),
}
EXTERNAL = ("context_rebuild_cost", "planning_rework_rate", "task_success_rate", "verifier_catch_rate", "token_cost", "latency")


def ratio(n: int, d: int, empty: float | None = None) -> float | None:
    """No denominator means unmeasured unless the caller gives a metric-specific neutral value."""
    return n / d if d else empty


def context_load(ctx: dict[str, Any]) -> float:
    d = ctx["data"]
    used = sum(len(c["content"]) for c in d["claims"]) + sum(len(e["fragment"]) for e in d["evidence"])
    return ratio(used, ctx["budget_chars"], 0.0)


def memory_contamination_rate(ctx: dict[str, Any], needed: Iterable[str]) -> float:
    """Context 內非當前必要的 Claim 佔比（Master §45）；趨近 0。"""
    need = set(needed)
    refs = [c["claim_ref"] for c in ctx["data"]["claims"]]
    return ratio(sum(r not in need for r in refs), len(refs), 0.0)


def coverage_completeness(ledger: Any, contract: dict[str, Any]) -> float:
    req = list(contract["required"])
    return ratio(sum(ledger.state(r) == "PROCESSED" for r in req), len(req))


def provenance_completeness(store: Any) -> float:
    refs = [c for c, rec in store.claims.items() if rec["promotion"] == "CANONICAL"]
    if not refs:
        return ratio(0, 0)  # 零樣本＝未量測（None），不需建立 Retriever（修補 018）
    r = Retriever(store)
    ok = 0
    for ref in refs:
        t = r.trace(ref)
        ok += bool(t["evidence"]) and all(e["fragment"] and e["source_ref"] for e in t["evidence"])
    return ratio(ok, len(refs))


def conflict_preservation_rate(store: Any, injected: Iterable[str]) -> float:
    """注入的 Conflict 仍在記錄中，且已解決者附 resolution（不被抹平）。"""
    ids = list(injected)
    ok = sum(k in store.conflicts and (store.conflicts[k]["status"] == "UNRESOLVED" or bool(store.conflicts[k].get("resolution"))) for k in ids)
    return ratio(ok, len(ids))


def unknown_preservation_rate(store: Any, unknown_refs: Iterable[str]) -> float:
    """UNKNOWN Observation 仍為 UNKNOWN，且未被任何 Claim 當 basis（沒被生成 Fact）。"""
    refs = list(unknown_refs)
    used = {o for c in store.claims.values() for o in c["observation_refs"]}
    ok = sum(store.obs[u]["observation_class"] == "UNKNOWN" and u not in used for u in refs)
    return ratio(ok, len(refs))


def false_promotion_rate(promoted_flags: Iterable[bool]) -> float:
    """每項＝一次「故意注入的錯誤」是否成功進入 CANONICAL。"""
    f = list(promoted_flags)
    return ratio(sum(f), len(f))


def archive_leakage_rate(reached_archive_flags: Iterable[bool]) -> float:
    """每項＝一次正常（非協定）搜尋是否取得 ARCHIVE 內容。"""
    f = list(reached_archive_flags)
    return ratio(sum(f), len(f))


def recovery_success_rate(recovered_flags: Iterable[bool]) -> float:
    f = list(recovered_flags)
    return ratio(sum(f), len(f))


def violations(metrics: dict[str, float | None]) -> list[str]:
    """對照 TARGETS；缺指標或零樣本未量測都算未通過，不得靜默略過。"""
    out = []
    for name, (kind, bound) in TARGETS.items():
        if name not in metrics:
            out.append(f"METRIC_MISSING:{name}")
        elif metrics[name] is None:
            out.append(f"METRIC_UNMEASURED:{name}")
        elif (kind == "MIN" and metrics[name] < bound) or (kind == "MAX" and metrics[name] > bound):
            out.append(f"METRIC_OUT_OF_TARGET:{name}={metrics[name]}")
    return out
