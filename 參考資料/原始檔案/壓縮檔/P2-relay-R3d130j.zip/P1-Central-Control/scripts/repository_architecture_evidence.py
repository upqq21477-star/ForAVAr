#!/usr/bin/env python3
"""Shared repository evidence adapter built on the existing progressive scanner.

This module deliberately reuses the scanner's inventory/import/dependency logic.
It adds only boundary-oriented evidence that the scanner does not currently model.
"""

from __future__ import annotations

import ast
import json
from pathlib import Path
from typing import Any

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT = SCRIPT_DIR.parents[1]

import sys
sys.path.insert(0, str(SCRIPT_DIR))
import progressive_repository_scanner as prs


SYSTEM_ROOTS = {"P1-CENTRAL-CONTROL": "P1-Central-Control/"}
SYSTEM_MODULE_ALIASES: dict[str, tuple[str, ...]] = {}


def _bind_systems(registered_systems: list[str]) -> None:
    for sid in registered_systems:
        SYSTEM_ROOTS.setdefault(sid, f"{sid}/")
        SYSTEM_MODULE_ALIASES.setdefault(sid, (sid.replace("-", "_"), sid))


def system_for_path(path: str) -> str | None:
    path = path.replace("\\", "/")
    for system_id, prefix in SYSTEM_ROOTS.items():
        if path.startswith(prefix):
            return system_id
    if path.startswith(".github/"):
        return "P1-CENTRAL-CONTROL"
    return None


def collect_dependency_evidence(root: Path) -> dict[str, Any]:
    inventory, consumed, inventory_complete, inventory_issues = prs._inventory(
        root,
        prs.DEFAULT_EXCLUDES,
        10000,
        20_000_000,
        mode="BOUNDED_RECONSTRUCTION",
    )
    symbols, modules, syntax_errors, stubs, imports = prs._structure(root, inventory)
    edges, unresolved = prs._dependencies(root, imports)
    return {
        "inventory": inventory,
        "bytes": consumed,
        "inventory_complete": inventory_complete,
        "inventory_issues": inventory_issues,
        "modules": modules,
        "symbols": symbols,
        "syntax_errors": syntax_errors,
        "stubs": stubs,
        "imports": imports,
        "edges": edges,
        "unresolved": unresolved,
    }


def _string_literals(node: ast.AST) -> list[str]:
    return [
        x.value for x in ast.walk(node)
        if isinstance(x, ast.Constant) and isinstance(x.value, str)
    ]


def _call_name(node: ast.Call) -> str:
    fn = node.func
    if isinstance(fn, ast.Name):
        return fn.id
    if isinstance(fn, ast.Attribute):
        return fn.attr
    return ""


def _target_system_for_module(target: str) -> str | None:
    target_path = target.replace(".", "/")
    return next(
        (
            sid
            for sid, aliases in SYSTEM_MODULE_ALIASES.items()
            if any(
                target.startswith(alias + ".") or target_path.startswith(alias + "/")
                for alias in aliases
            )
        ),
        None,
    )


def inspect_boundary_evidence(root: Path, inventory: list[dict[str, Any]], registered_systems: list[str]) -> dict[str, Any]:
    _bind_systems(registered_systems)
    direct_cross_system_imports: list[dict[str, str]] = []
    direct_file_writes: list[dict[str, str]] = []
    foreign_current_mutations: list[dict[str, str]] = []
    handoff_calls: list[dict[str, str]] = []
    dynamic_boundary_unknown: list[str] = []

    for row in inventory:
        if row["language"] != "python" or row["kind"] != "SOURCE":
            continue
        path = row["path"]
        source_system = system_for_path(path)
        if source_system is None:
            continue
        source = root / path
        try:
            tree = ast.parse(source.read_text(encoding="utf-8", errors="replace"), filename=path)
        except (OSError, SyntaxError):
            continue

        for node in ast.walk(tree):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = []
                if isinstance(node, ast.Import):
                    names = [alias.name for alias in node.names]
                elif node.module:
                    names = [node.module]
                for target in names:
                    target_system = _target_system_for_module(target)
                    if target_system and target_system != source_system:
                        direct_cross_system_imports.append({
                            "source": path,
                            "source_system": source_system,
                            "target": target,
                            "target_system": target_system,
                            "evidence": "python-import",
                        })

            if isinstance(node, ast.Call):
                call_name = _call_name(node)
                strings = _string_literals(node)
                joined = " ".join(strings)
                if call_name.split(".")[-1] in {"import_module", "__import__"} and node.args:
                    first = node.args[0]
                    if isinstance(first, ast.Constant) and isinstance(first.value, str):
                        target_system = _target_system_for_module(first.value)
                        if target_system and target_system != source_system:
                            direct_cross_system_imports.append({
                                "source": path,
                                "source_system": source_system,
                                "target": first.value,
                                "target_system": target_system,
                                "evidence": "python-importlib-literal",
                            })
                write_like = call_name in {"open", "write_text", "write_bytes", "mkdir", "unlink", "remove"}
                if write_like and any(prefix in joined for prefix in SYSTEM_ROOTS.values()):
                    target_systems = [
                        sid for sid, prefix in SYSTEM_ROOTS.items()
                        if prefix in joined
                    ]
                    for target_system in sorted(set(target_systems)):
                        if target_system != source_system:
                            direct_file_writes.append({
                                "source": path,
                                "source_system": source_system,
                                "target_system": target_system,
                                "call": call_name,
                                "evidence": "python-write-call-string-path",
                            })

                if "P1-CURRENT.json" in joined and call_name in {"open", "write_text", "write_bytes"}:
                    foreign_current_mutations.append({
                        "source": path,
                        "source_system": source_system,
                        "call": call_name,
                        "evidence": "python-current-write",
                    })

                if any(token in call_name.lower() for token in ("handoff", "dispatch", "route", "forward")):
                    target_systems = [sid for sid in registered_systems if sid in joined]
                    if target_systems:
                        for target_system in sorted(set(target_systems)):
                            if target_system != source_system:
                                handoff_calls.append({
                                    "source": path,
                                    "source_system": source_system,
                                    "target_system": target_system,
                                    "call": call_name,
                                    "evidence": "python-handoff-call-string-system",
                                })
                    elif not strings:
                        dynamic_boundary_unknown.append(
                            f"{path}:{call_name}:dynamic-handoff-target"
                        )

                if write_like and not strings:
                    dynamic_boundary_unknown.append(
                        f"{path}:{call_name}:dynamic-write-target"
                    )

    return {
        "direct_cross_system_imports": direct_cross_system_imports,
        "direct_file_writes": direct_file_writes,
        "foreign_current_mutations": foreign_current_mutations,
        "handoff_calls": handoff_calls,
        "dynamic_boundary_unknown": sorted(set(dynamic_boundary_unknown)),
    }


def collect(root: Path, registered_systems: list[str]) -> dict[str, Any]:
    dependency = collect_dependency_evidence(root)
    boundary = inspect_boundary_evidence(
        root,
        dependency["inventory"],
        registered_systems,
    )
    return {
        "schema_version": "1.0",
        "root": str(root),
        "dependency": dependency,
        "boundary": boundary,
    }


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--systems", nargs="*", default=[])
    args = parser.parse_args()
    print(json.dumps(collect(Path(args.root).resolve(), args.systems), ensure_ascii=False, indent=2))
