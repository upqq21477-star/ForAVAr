#!/usr/bin/env python3
"""Daily discovery of mature external tools for P1 pain points and core capabilities.

The radar is a discovery layer, not an adoption decision. GitHub repository
search provides candidates; popularity is a ranking signal, never a quality truth.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
CATALOG_DEFAULT = ROOT / "P1-Central-Control/canonical/external_tool_radar_catalog.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/external_tool_radar_result.schema.json"
CATALOG_SCHEMA = ROOT / "P1-Central-Control/schemas/external_tool_radar_catalog.schema.json"
API_DEFAULT = "https://api.github.com"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def validate(value: dict[str, Any], schema: dict[str, Any]) -> None:
    Draft202012Validator(schema).validate(value)


def iso_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def parse_time(value: str) -> dt.datetime:
    return dt.datetime.fromisoformat(value.replace("Z", "+00:00"))


def days_since(value: str, now: dt.datetime) -> float:
    delta = now - parse_time(value)
    return max(0.0, delta.total_seconds() / 86400.0)


def clamp(value: float, low: float = 0.0, high: float = 1.0) -> float:
    return min(high, max(low, value))


def component_stars(stars: int) -> float:
    return clamp(math.log10(stars + 1) / math.log10(10001))


def component_forks(forks: int) -> float:
    return clamp(math.log10(forks + 1) / math.log10(1001))


def component_activity(days: float) -> float:
    if days <= 30:
        return 1.0
    if days >= 365:
        return 0.0
    return clamp(1.0 - ((days - 30.0) / 335.0))


def popularity_score(stars: int, forks: int, freshness_days: float, weights: dict[str, float]) -> float:
    raw = (
        weights["stars"] * component_stars(stars)
        + weights["activity"] * component_activity(freshness_days)
        + weights["forks"] * component_forks(forks)
    )
    return round(raw * 100.0, 2)


def build_query(terms: str, cutoff: dt.date, min_stars: int) -> str:
    return (
        f"{terms} in:name,description,readme "
        f"stars:>={min_stars} pushed:>={cutoff.isoformat()}"
    )


def github_get_json(
    api_url: str,
    path: str,
    params: dict[str, Any],
    token: str | None,
) -> dict[str, Any]:
    query = urllib.parse.urlencode(params)
    url = f"{api_url.rstrip('/')}{path}?{query}"
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2026-03-10",
        "User-Agent": "P1-External-Tool-Radar/1.0",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    request = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except Exception as exc:
        raise RuntimeError(f"GITHUB_SEARCH_FAILED:{type(exc).__name__}") from exc


def iter_scopes(catalog: dict[str, Any]) -> list[tuple[str, dict[str, Any]]]:
    scopes: list[tuple[str, dict[str, Any]]] = []
    for item in catalog["pain_points"]:
        scopes.append(("PAIN_POINT", item))
    for item in catalog["core_capabilities"]:
        scopes.append(("CORE_CAPABILITY", item))
    return scopes


def classify(
    *,
    archived: bool,
    stars: int,
    score: float,
    freshness_days: float,
    policy: dict[str, Any],
) -> str:
    if archived:
        return "ARCHIVED"
    if stars < policy["min_stars"] or score < policy["min_popularity_score"]:
        return "BELOW_THRESHOLD"
    if freshness_days > 180:
        return "STALE"
    if score >= policy["candidate_score_threshold"]:
        return "ADOPT_CANDIDATE"
    return "WATCH"


def search_catalog(
    catalog: dict[str, Any],
    *,
    now: dt.datetime,
    token: str | None,
    api_url: str,
) -> dict[str, Any]:
    policy = catalog["search_policy"]
    cutoff = now.date() - dt.timedelta(days=policy["lookback_days"])
    results: dict[str, dict[str, Any]] = {}
    query_count = 0

    for scope_type, scope in iter_scopes(catalog):
        for terms in scope["queries"]:
            query_count += 1
            query = build_query(terms, cutoff, policy["min_stars"])
            payload = github_get_json(
                api_url,
                "/search/repositories",
                {
                    "q": query,
                    "sort": "updated",
                    "order": "desc",
                    "per_page": policy["max_results_per_query"],
                },
                token,
            )
            for repo in payload.get("items", []):
                full_name = repo.get("full_name")
                pushed_at = repo.get("pushed_at")
                created_at = repo.get("created_at")
                if not full_name or not pushed_at or not created_at:
                    continue

                stars = int(repo.get("stargazers_count", 0))
                forks = int(repo.get("forks_count", 0))
                freshness = days_since(pushed_at, now)
                score = popularity_score(
                    stars,
                    forks,
                    freshness,
                    policy["weights"],
                )

                candidate = results.setdefault(
                    full_name,
                    {
                        "repository": full_name,
                        "name": repo.get("name", full_name.split("/", 1)[-1]),
                        "url": repo.get("html_url"),
                        "description": repo.get("description"),
                        "stars": stars,
                        "forks": forks,
                        "created_at": created_at,
                        "pushed_at": pushed_at,
                        "updated_at": repo.get("updated_at"),
                        "archived": bool(repo.get("archived", False)),
                        "topics": list(repo.get("topics") or []),
                        "popularity_score": score,
                        "freshness_days": round(freshness, 2),
                        "is_new_tool": days_since(created_at, now) <= policy["new_tool_days"],
                        "matched_scopes": [],
                    },
                )

                candidate["matched_scopes"].append(
                    {
                        "scope_type": scope_type,
                        "scope_id": scope["id"],
                        "scope_name": scope["name"],
                        "query": terms,
                    }
                )
                if score > candidate["popularity_score"]:
                    candidate["popularity_score"] = score

    for candidate in results.values():
        candidate["classification"] = classify(
            archived=candidate["archived"],
            stars=candidate["stars"],
            score=candidate["popularity_score"],
            freshness_days=candidate["freshness_days"],
            policy=policy,
        )
        candidate["matched_scopes"] = sorted(
            candidate["matched_scopes"],
            key=lambda x: (x["scope_type"], x["scope_id"], x["query"]),
        )

    order = {
        "ADOPT_CANDIDATE": 0,
        "WATCH": 1,
        "STALE": 2,
        "BELOW_THRESHOLD": 3,
        "ARCHIVED": 4,
    }
    candidates = sorted(
        results.values(),
        key=lambda item: (
            order[item["classification"]],
            -item["popularity_score"],
            item["freshness_days"],
            item["repository"],
        ),
    )

    summary = {
        "scope_count": len(iter_scopes(catalog)),
        "query_count": query_count,
        "candidate_count": sum(c["classification"] == "ADOPT_CANDIDATE" for c in candidates),
        "watch_count": sum(c["classification"] == "WATCH" for c in candidates),
        "below_threshold_count": sum(c["classification"] == "BELOW_THRESHOLD" for c in candidates),
    }

    return {
        "schema_version": "1.0",
        "run_id": f"RADAR-{now.strftime('%Y%m%d')}",
        "observed_date": now.date().isoformat(),
        "source": "GITHUB_REPOSITORY_SEARCH",
        "catalog_version": catalog["version"],
        "summary": summary,
        "candidates": candidates,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 daily external tool radar")
    parser.add_argument("--catalog", default=str(CATALOG_DEFAULT))
    parser.add_argument("--output", required=True)
    parser.add_argument("--api-url", default=os.environ.get("GITHUB_API_URL", API_DEFAULT))
    args = parser.parse_args()

    catalog = load_json(Path(args.catalog))
    validate(catalog, load_json(CATALOG_SCHEMA))

    result = search_catalog(
        catalog,
        now=iso_now(),
        token=os.environ.get("GITHUB_TOKEN"),
        api_url=args.api_url,
    )
    validate(result, load_json(RESULT_SCHEMA))

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "run_id": result["run_id"],
                "queries": result["summary"]["query_count"],
                "adopt_candidates": result["summary"]["candidate_count"],
                "watch": result["summary"]["watch_count"],
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
