#!/usr/bin/env python3
"""result_chain — run the 020c result chains for real (R3d12w, stdlib + repo scripts only).

Orchestrator for CH-RECEIPT-INGEST-ACCEPT and CH-PACKET-INGEST-ACCEPT. It owns no state, taxonomy or truth:
every step is an existing function.
  receipt chain  runtime_evidence_probe.execute (real subprocess) -> ResultPacket -> repository_result_ingestion.ingest
                 -> (central_controller -> execution_truth -> evidence_provenance_guard, called inside ingest)
                 -> evidence_provenance_guard.validate_* replay -> current_truth_reconciliation.classify_repository_result
  packet chain   same, starting from a persisted ResultPacket instead of a probe receipt.
`links_exercised` is MEASURED (sys.setprofile records which scripts/ modules were entered), never typed by hand.
A failed receipt stops before ingestion (RECEIPT_NOT_PASS): a failed probe is never turned into a success result.
Usage: python3 scripts/result_chain.py --run [--out BASE_DIR] | --simulate      exit 0 only when every scenario matches
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import central_controller  # noqa: E402
import current_truth_reconciliation  # noqa: E402
import evidence_provenance_guard  # noqa: E402
import repository_result_ingestion  # noqa: E402
import runtime_evidence_probe  # noqa: E402
from brain_proposal import accept_proposal, materialize_command  # noqa: E402
from event_log import EventLog  # noqa: E402
from packet_layer import content_hash  # noqa: E402
from repository_result_writer import persist  # noqa: E402
from system_result_adapter import adapt  # noqa: E402

CHAIN_RECEIPT = "CH-RECEIPT-INGEST-ACCEPT"
CHAIN_PACKET = "CH-PACKET-INGEST-ACCEPT"
EVIDENCE_FILES = {  # run records read by tools/wiring_chain_audit.py (WIRED_EXECUTED needs them)
    CHAIN_PACKET: "evidence/wiring-chains/CH-PACKET-INGEST-ACCEPT.json",
    CHAIN_RECEIPT: "evidence/wiring-chains/CH-RECEIPT-INGEST-ACCEPT.json",
}
LINKS = [
    "runtime_evidence_probe", "packet_layer", "repository_result_ingestion", "central_controller",
    "execution_truth", "evidence_provenance_guard", "current_truth_reconciliation",
]


def trace_modules(fn: Callable[[], Any]) -> tuple[Any, set[str]]:
    """Run fn() and return (result, names of scripts/ modules whose functions were entered)."""
    seen: set[str] = set()

    def prof(frame, event, _arg):
        if event == "call":
            p = Path(frame.f_code.co_filename)
            if p.parent == SCRIPTS:
                seen.add(p.stem)

    sys.setprofile(prof)
    try:
        out = fn()
    finally:
        sys.setprofile(None)
    return out, seen


def _segment(tag: str) -> dict[str, Any]:
    return {
        "segment_id": f"SEG-{tag}", "workflow_id": f"WF-{tag}", "system_id": f"SYSTEM-{tag}",
        "skill_id": "result-chain", "skill_version": "1.0.0", "objective": "020c result chain",
        "input_scope": "chain", "input_refs": ["ARTIFACT:INPUT"], "requested_outputs": ["result"],
        "constraints": [], "stop_condition": ["result_ready"], "failure_condition": ["invalid"],
        "dependency_refs": [], "completion_contract": {"required_outputs": ["result"], "handoff_allowed": True},
        "execution_record_ref": "EXECUTION:placeholder", "context_cohort_id": f"COHORT-{tag}",
        "context_budget": {"estimated_total_context": 100, "target_context_budget": 1000,
                           "hard_context_ceiling": 2000, "risk": "LOW"},
        "retry_policy": {"max_attempts": 1, "retry_on": []}, "timeout_ms": 1000,
    }


def _start_proposal(state: dict[str, Any]) -> dict[str, Any]:
    """Stand-in START proposal (same shape the tests use); the real Brain path is p2_run's job."""
    p = {
        "object_id": "BRAIN_PROPOSAL:chain-start", "kind": "BRAIN_PROPOSAL", "schema_version": "1.0",
        "content_hash": "sha256:" + "b" * 64, "proposal_id": "chain-start", "workflow_id": state["workflow_id"],
        "aggregate_type": "WORKFLOW", "target_id": state["workflow_id"], "command_type": "START",
        "expected_state_revision": state["state_revision"], "idempotency_key": "chain-start:START",
        "route_mode": "DIRECT_COMMAND", "decision_code": "EXECUTE", "capability_refs": ["CAPABILITY:CAP-SEARCH"],
        "required_controls": ["STATE_VALIDATION", "IDEMPOTENCY", "EVENT_LOG", "SCHEDULER", "EXECUTION_TRUTH",
                              "EVIDENCE_GUARD", "PROVENANCE_GUARD", "DISTILLATION"],
        "evidence_refs": [], "contract_gap_refs": [], "semantic_explanation_ref": None,
    }
    p["content_hash"] = content_hash(p)
    accept_proposal(state, p)
    materialize_command(state, p, actor_id="COMMANDER")
    return p


def _prepare(root: Path, tag: str, outputs: dict[str, Any], step: dict[str, Any]) -> dict[str, Any]:
    state = central_controller.init_state(f"WF-{tag}", f"TASK-{tag}")
    state = central_controller.queue_segment(state, _segment(tag))
    log = EventLog(root / "events.jsonl")
    state, applied = central_controller.commit_brain_proposal(state, _start_proposal(state), event_log=log)
    if applied["status"] != "APPLIED":
        raise RuntimeError(f"START_NOT_APPLIED:{applied['status']}")
    store: dict[str, Any] = {}
    state, packets = central_controller.dispatch(state, event_log=log, execution_store=store, max_concurrency=1)
    env = store[packets[0]["execution_record_ref"]]
    system_result = {
        "segment_id": packets[0]["segment_id"], "system_id": f"SYSTEM-{tag}", "status": "WORK_COMPLETE",
        "outputs": {"result": outputs}, "evidence_refs": [], "provenance_refs": [], "gaps": [], "unresolved": [],
        "trace": [step], "completion": {"segment_complete": True, "handoff_ready": False, "summary": tag},
        "observed_usage": {"model_calls": 0, "tool_calls": 1, "wall_time_ms": 1, "usage_observed": True},
    }
    result, ev, pv = adapt(env["task_packet"], system_result, env["execution_record"])
    persisted = persist(result, root=root / "repo")
    return {"state": state, "task": env["task_packet"], "result": result, "evidence": ev["records"],
            "provenance": pv["records"], "envelopes": list(store.values()), "log_path": log.path,
            "result_path": root / "repo" / persisted["path"]}


def _ingest_and_accept(p: dict[str, Any]) -> dict[str, Any]:
    pending, _ = current_truth_reconciliation.classify_repository_result(p["state"], p["result"])
    out = repository_result_ingestion.ingest(
        result_packet=p["result"], task_packet=p["task"], current_state=p["state"],
        execution_envelopes=p["envelopes"], event_log_path=p["log_path"],
        evidence_records=p["evidence"], provenance_records=p["provenance"])
    for rec in p["evidence"]:
        evidence_provenance_guard.validate_evidence(rec)
    for rec in p["provenance"]:
        evidence_provenance_guard.validate_provenance(rec)
    final, check = current_truth_reconciliation.classify_repository_result(out["central_state"], p["result"])
    return {"ingest_status": out["status"], "central_status": out["central_state"]["status"],
            "before": pending, "after": final, "check_status": (check or {}).get("status")}


def run_packet_chain(root: Path) -> dict[str, Any]:
    p = _prepare(root, "PACKET", {"status": "complete"}, {"step": "packet-chain"})
    return _ingest_and_accept(p)


def run_receipt_chain(root: Path, command: list[str] | None = None, expected: int = 0) -> dict[str, Any]:
    receipt = runtime_evidence_probe.execute({
        "schema_version": "1.0", "probe_id": "PROBE:CHAIN", "root_path": str(root),
        "command": command or [sys.executable, "-c", "print('ok')"], "expected_exit_code": expected})
    if receipt.get("return_code") != receipt.get("expected_exit_code"):
        return {"stopped": "RECEIPT_NOT_PASS", "return_code": receipt.get("return_code")}
    out = {k: receipt.get(k) for k in ("probe_id", "return_code", "stdout_sha256", "stderr_sha256", "evidence_class")}
    p = _prepare(root, "RECEIPT", out, {"step": "runtime_probe", "probe_id": receipt["probe_id"]})
    res = _ingest_and_accept(p)
    res["receipt_class"] = receipt.get("evidence_class")
    return res


def _expect_raises(fn: Callable[[], Any]) -> bool:
    try:
        fn()
    except Exception:  # noqa: BLE001 - any refusal counts; the scenario only needs "did not pass silently"
        return True
    return False


def scenarios() -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    """Return ({chain_id: {exit_code, links_exercised, method}}, scenario rows)."""
    rows: list[dict[str, Any]] = []
    chains: dict[str, dict[str, Any]] = {}
    for cid, fn in ((CHAIN_PACKET, run_packet_chain), (CHAIN_RECEIPT, run_receipt_chain)):
        with tempfile.TemporaryDirectory() as tmp:
            res, mods = trace_modules(lambda f=fn, t=tmp: f(Path(t)))
        ok = (res.get("ingest_status") == "PASS" and res.get("central_status") == "COMPLETED"
              and res.get("before") == "PERSISTED_PENDING_CENTRAL" and res.get("after") == "INGESTED"
              and res.get("check_status") == "PASS")
        rows.append({"scenario": f"{cid}:positive", "ok": ok, "detail": res})
        chains[cid] = {"chain_id": cid, "exit_code": 0, "links_exercised": sorted(m for m in LINKS if m in mods),
                       "method": "sys.setprofile module trace of the real run", "positive_ok": ok}
    with tempfile.TemporaryDirectory() as tmp:
        bad, mods = trace_modules(lambda: run_receipt_chain(Path(tmp), [sys.executable, "-c", "raise SystemExit(3)"]))
    rows.append({"scenario": "receipt:failed_probe_stops_before_ingest",
                 "ok": bad.get("stopped") == "RECEIPT_NOT_PASS" and "repository_result_ingestion" not in mods, "detail": bad})
    with tempfile.TemporaryDirectory() as tmp:
        p = _prepare(Path(tmp), "MUT1", {"status": "complete"}, {"step": "mut"})
        p["result"] = dict(p["result"], segment_id="SEG-OTHER")
        rows.append({"scenario": "packet:identity_mismatch_refused", "ok": _expect_raises(lambda: _ingest_and_accept(p))})
    with tempfile.TemporaryDirectory() as tmp:
        p = _prepare(Path(tmp), "MUT2", {"status": "complete"}, {"step": "mut"})
        broken = dict(p["evidence"][0])
        broken.pop("content_hash", None)
        broken.pop("evidence_class", None)
        rows.append({"scenario": "evidence:tampered_record_refused",
                     "ok": _expect_raises(lambda: evidence_provenance_guard.validate_evidence(broken))})
    bad_rows = [r["scenario"] for r in rows if not r["ok"]]
    if bad_rows:
        for c in chains.values():
            c["exit_code"] = 1
    return chains, rows


def main(argv: list[str]) -> int:
    chains, rows = scenarios()
    for r in rows:
        print("PASS" if r["ok"] else "FAIL", r["scenario"])
    if "--run" in argv:
        base = Path(argv[argv.index("--out") + 1]) if "--out" in argv else SCRIPTS.parent
        for cid, rec in chains.items():
            target = base / EVIDENCE_FILES[cid]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(rec, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            print("wrote", target, "links_exercised", rec["links_exercised"])
    return 0 if all(r["ok"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
