#!/usr/bin/env python3
"""Enforce mandatory central admission before a construction task enters P1 execution."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/task_admission_request.schema.json"


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def validate_request(request: dict[str, Any]) -> None:
    schema = load(SCHEMA)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(request),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def changed_paths(root: Path, base: str, head: str) -> list[str]:
    command = ["git", "diff", "--name-only", f"{base}..{head}"]
    result = subprocess.run(
        command, cwd=root, capture_output=True, text=True, check=False
    )
    if result.returncode != 0:
        raise RuntimeError("GIT_CHANGESET_UNAVAILABLE")
    return sorted({line.strip() for line in result.stdout.splitlines() if line.strip()})


def path_in_scope(path: str, scope: list[str]) -> bool:
    return any(path == item or path.startswith(item.rstrip("/") + "/") for item in scope)


def execute(
    request: dict[str, Any],
    *,
    root: Path | None = None,
    current_path: str = "P1-CURRENT.json",
    base: str | None = None,
    head: str | None = None,
) -> dict[str, Any]:
    validate_request(request)
    root = (root or ROOT).resolve()

    current = load(root / current_path)
    current_control = current.get("implementation_control", {})
    if current_control.get("active_work_packet") != request["active_work_packet"]:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["ACTIVE_WORK_PACKET_MISMATCH"],
        }

    work = load(root / request["active_work_packet"])
    if work.get("work_id") != request["active_work_packet"].rsplit("/", 1)[-1].replace(".work.json",""):
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["WORK_PACKET_ID_MISMATCH"],
        }
    if work.get("central_admission_ref") != request["request_id"]:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["CENTRAL_ADMISSION_REF_MISMATCH"],
        }
    if work.get("construction_packet_ref") != request["construction_packet"]:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["WORK_CONSTRUCTION_REF_MISMATCH"],
        }
    if work.get("task_packet_ref") != request["task_packet_ref"]:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["WORK_TASK_PACKET_REF_MISMATCH"],
        }

    construction = load(root / request["construction_packet"])
    if construction.get("task_packet_ref") != request["task_packet_ref"]:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["CONSTRUCTION_TASK_PACKET_REF_MISMATCH"],
        }
    if construction.get("status") not in {
        "READY","BUILDING","CHANGE_OBSERVED","ACCEPTANCE","VERIFIED"
    }:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["CONSTRUCTION_NOT_ADMISSIBLE"],
        }

    task_packet_path = root / request["task_packet_path"]
    if not task_packet_path.is_file():
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["TASK_PACKET_MISSING"],
        }

    import sys
    sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
    from packet_layer import validate_task_packet
    from simulated_amnesia_resume import reconstruct_task_context
    from continuation_context_box import locate

    task_packet = load(task_packet_path)
    try:
        validate_task_packet(task_packet)
    except Exception as exc:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["TASK_PACKET_INVALID"],
            "error":str(exc),
        }

    if task_packet.get("object_id") != request["task_packet_ref"]:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["TASK_PACKET_IDENTITY_MISMATCH"],
        }
    if task_packet.get("acceptance_ref") != construction.get("packet_id"):
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["TASK_ACCEPTANCE_REF_MISMATCH"],
        }

    try:
        continuation_box = None
        continuation_box_path = None
        continuation_box_ref = task_packet.get("continuation_box_ref")
        if continuation_box_ref:
            continuation_box_path_obj, continuation_box = locate(
                root,
                continuation_box_ref,
            )
            continuation_box_path = str(continuation_box_path_obj.relative_to(root))
        amnesia_context = reconstruct_task_context(
            current=current,
            task_packet=task_packet,
            continuation_box=continuation_box,
        )
    except Exception as exc:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["AMNESIA_RECONSTRUCTION_BLOCKED"],
            "error":str(exc),
        }

    system_update_detected = bool(
        head
        and current.get("current_stage", {}).get("merged_commit_sha")
        and head != current["current_stage"]["merged_commit_sha"]
    )
    if system_update_detected and not task_packet.get("continuation_box_ref"):
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["CONTINUATION_BOX_REQUIRED_AFTER_SYSTEM_UPDATE"],
        }

    contract = request["interface_contract"]
    violations = []
    for field, expected in (
        ("inbound","CENTRAL_TO_MODULE"),
        ("outbound","MODULE_TO_CENTRAL"),
        ("system_to_system_handoff",False),
        ("foreign_current_mutation",False),
        ("direct_cross_system_import",False),
    ):
        if contract.get(field) != expected:
            violations.append(field)
    if violations:
        return {
            "status":"BLOCK",
            "admitted":False,
            "request_id":request["request_id"],
            "reason_codes":["INTERFACE_CONTRACT_VIOLATION"],
            "violations":violations,
        }

    result: dict[str, Any] = {
        "status":"PASS",
        "admitted":True,
        "request_id":request["request_id"],
        "task_packet_ref":request["task_packet_ref"],
        "construction_packet":request["construction_packet"],
        "active_work_packet":request["active_work_packet"],
        "interface_contract":"CENTRAL_ONLY",
        "amnesia_context": amnesia_context,
        "continuation_box_ref": continuation_box_ref,
        "continuation_box_path": continuation_box_path,
        "amnesia_boundary": "MANDATORY_ON_TASK_PACKET_ADMISSION",
        "system_update_detected": system_update_detected,
        "changed_paths":[],
        "out_of_scope_paths":[],
        "reason_codes":[
            "CENTRAL_AUTHORITY_CONFIRMED",
            "TASK_PACKET_CONFIRMED",
            "CONSTRUCTION_LIFECYCLE_CONFIRMED",
            "CENTRAL_ONLY_INTERFACE_CONFIRMED",
            "AMNESIA_CONTEXT_RECONSTRUCTED"
        ] + (["SYSTEM_UPDATE_CONTEXT_REBUILT"] if system_update_detected else []),
    }

    if base and head:
        changed = changed_paths(root, base, head)
        allowed = (
            list(construction.get("write_scope", {}).get("create", []))
            + list(construction.get("write_scope", {}).get("update", []))
        )
        out_of_scope = [path for path in changed if not path_in_scope(path, allowed)]
        result["changed_paths"] = changed
        result["out_of_scope_paths"] = sorted(out_of_scope)
        if out_of_scope:
            result["status"] = "BLOCK"
            result["admitted"] = False
            result["reason_codes"] = ["OUT_OF_SCOPE_CHANGE"]
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 mandatory task admission gate")
    parser.add_argument("--request", required=True)
    parser.add_argument("--current", default="P1-CURRENT.json")
    parser.add_argument("--base")
    parser.add_argument("--head")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    request = load(Path(args.request).resolve())
    result = execute(
        request,
        root=Path(".").resolve(),
        current_path=args.current,
        base=args.base,
        head=args.head,
    )
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2 if result.get("status") == "INCOMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
