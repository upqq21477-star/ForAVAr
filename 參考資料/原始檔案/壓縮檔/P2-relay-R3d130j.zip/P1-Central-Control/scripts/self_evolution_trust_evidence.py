#!/usr/bin/env python3
"""Evidence-bound validator quorum and rollback verification for P1 self-evolution."""

from __future__ import annotations

import hashlib
import json
import re
from copy import deepcopy
from typing import Any

HEX64 = re.compile(r"^[a-f0-9]{64}$")


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return canonical_sha256(material)


def build_attestation(
    *,
    validator_id: str,
    trust_domain: str,
    candidate_digest: str,
    constitution_digest: str,
    decision: str,
    epoch: int,
    attestation_id: str,
) -> dict[str, Any]:
    evidence = {
        "attestation_id": attestation_id,
        "validator_id": validator_id,
        "trust_domain": trust_domain,
        "candidate_digest": candidate_digest,
        "constitution_digest": constitution_digest,
        "decision": decision,
        "epoch": epoch,
    }
    evidence["content_hash"] = _content_hash(evidence)
    return evidence


def build_rollback_evidence(
    *,
    snapshot_id: str,
    snapshot_digest: str,
    constitution_digest: str,
    verification_epoch: int,
    verification_status: str = "PASS",
) -> dict[str, Any]:
    evidence = {
        "snapshot_id": snapshot_id,
        "snapshot_digest": snapshot_digest,
        "constitution_digest": constitution_digest,
        "verification_epoch": verification_epoch,
        "verification_status": verification_status,
    }
    evidence["content_hash"] = _content_hash(evidence)
    return evidence


def validate_attestation(
    attestation: dict[str, Any],
    *,
    validator_registry: dict[str, Any],
    candidate_digest: str,
    constitution_digest: str,
    min_epoch: int = 1,
) -> list[str]:
    violations: list[str] = []
    required = (
        "attestation_id",
        "validator_id",
        "trust_domain",
        "candidate_digest",
        "constitution_digest",
        "decision",
        "epoch",
        "content_hash",
    )
    for field in required:
        if field not in attestation:
            violations.append(f"ATTESTATION_MISSING_{field.upper()}")

    if violations:
        return violations

    validator_id = attestation["validator_id"]
    registered = validator_registry.get("validators", {}).get(validator_id)
    if not registered:
        violations.append("VALIDATOR_NOT_REGISTERED")
        return violations

    if not registered.get("active", False):
        violations.append("VALIDATOR_NOT_ACTIVE")

    if attestation["trust_domain"] != registered.get("trust_domain"):
        violations.append("VALIDATOR_TRUST_DOMAIN_MISMATCH")

    if attestation["candidate_digest"] != candidate_digest:
        violations.append("ATTESTATION_CANDIDATE_DIGEST_MISMATCH")

    if attestation["constitution_digest"] != constitution_digest:
        violations.append("ATTESTATION_CONSTITUTION_DIGEST_MISMATCH")

    if attestation["decision"] not in {"PASS", "FAIL"}:
        violations.append("ATTESTATION_DECISION_INVALID")

    if not isinstance(attestation["epoch"], int) or attestation["epoch"] < min_epoch:
        violations.append("ATTESTATION_EPOCH_INVALID")

    registered_min_epoch = int(registered.get("min_epoch", 1))
    if isinstance(attestation["epoch"], int) and attestation["epoch"] < registered_min_epoch:
        violations.append("ATTESTATION_EPOCH_REVOKED")

    if attestation["content_hash"] != _content_hash(attestation):
        violations.append("ATTESTATION_CONTENT_HASH_INVALID")

    return violations


def validate_rollback_evidence(
    evidence: dict[str, Any],
    *,
    rollback_registry: dict[str, Any],
    constitution_digest: str,
    min_epoch: int = 1,
) -> list[str]:
    violations: list[str] = []
    required = (
        "snapshot_id",
        "snapshot_digest",
        "constitution_digest",
        "verification_epoch",
        "verification_status",
        "content_hash",
    )
    for field in required:
        if field not in evidence:
            violations.append(f"ROLLBACK_EVIDENCE_MISSING_{field.upper()}")

    if violations:
        return violations

    snapshot_id = evidence["snapshot_id"]
    registered = rollback_registry.get("snapshots", {}).get(snapshot_id)
    if not registered:
        violations.append("ROLLBACK_SNAPSHOT_NOT_REGISTERED")
        return violations

    if not registered.get("legal", False):
        violations.append("ROLLBACK_SNAPSHOT_NOT_LEGAL")

    if evidence["snapshot_digest"] != registered.get("snapshot_digest"):
        violations.append("ROLLBACK_SNAPSHOT_DIGEST_MISMATCH")

    if evidence["constitution_digest"] != constitution_digest:
        violations.append("ROLLBACK_CONSTITUTION_DIGEST_MISMATCH")

    if evidence["verification_status"] != "PASS":
        violations.append("ROLLBACK_VERIFICATION_NOT_PASS")

    if (
        not isinstance(evidence["verification_epoch"], int)
        or evidence["verification_epoch"] < min_epoch
    ):
        violations.append("ROLLBACK_VERIFICATION_EPOCH_INVALID")

    if evidence["content_hash"] != _content_hash(evidence):
        violations.append("ROLLBACK_EVIDENCE_CONTENT_HASH_INVALID")

    return violations


def evaluate_validator_quorum(
    attestations: list[dict[str, Any]],
    *,
    validator_registry: dict[str, Any],
    candidate_digest: str,
    constitution_digest: str,
    min_validators: int = 2,
    min_trust_domains: int = 2,
    min_epoch: int = 1,
) -> dict[str, Any]:
    violations: list[str] = []
    valid: list[dict[str, Any]] = []
    seen_validators: dict[str, list[dict[str, Any]]] = {}

    for attestation in attestations:
        validator_id = attestation.get("validator_id")
        if validator_id:
            seen_validators.setdefault(validator_id, []).append(attestation)
        item_violations = validate_attestation(
            attestation,
            validator_registry=validator_registry,
            candidate_digest=candidate_digest,
            constitution_digest=constitution_digest,
            min_epoch=min_epoch,
        )
        if item_violations:
            violations.extend(item_violations)
        else:
            valid.append(attestation)

    for validator_id, items in seen_validators.items():
        if len(items) > 1:
            decisions = {item.get("decision") for item in items}
            if len(decisions) > 1:
                violations.append("VALIDATOR_EQUIVOCATION")
            else:
                violations.append("DUPLICATE_VALIDATOR_ATTESTATION")

    if violations:
        return {
            "status": "BLOCK",
            "decision": "SAFE_HOLD",
            "violations": sorted(set(violations)),
            "validators": sorted({item.get("validator_id") for item in valid}),
            "trust_domains": sorted({item.get("trust_domain") for item in valid}),
            "pass_validators": sorted(
                item["validator_id"] for item in valid if item["decision"] == "PASS"
            ),
            "fail_validators": sorted(
                item["validator_id"] for item in valid if item["decision"] == "FAIL"
            ),
        }

    decisions = {item["decision"] for item in valid}
    if "PASS" in decisions and "FAIL" in decisions:
        return {
            "status": "BLOCK",
            "decision": "SAFE_HOLD",
            "violations": ["VALIDATOR_RESULT_CONFLICT"],
            "validators": sorted({item["validator_id"] for item in valid}),
            "trust_domains": sorted({item["trust_domain"] for item in valid}),
            "pass_validators": sorted(
                item["validator_id"] for item in valid if item["decision"] == "PASS"
            ),
            "fail_validators": sorted(
                item["validator_id"] for item in valid if item["decision"] == "FAIL"
            ),
        }

    pass_items = [item for item in valid if item["decision"] == "PASS"]
    pass_validators = sorted({item["validator_id"] for item in pass_items})
    pass_domains = sorted({item["trust_domain"] for item in pass_items})

    if len(pass_validators) < min_validators:
        return {
            "status": "BLOCK",
            "decision": "SAFE_HOLD",
            "violations": ["VALIDATOR_QUORUM_INSUFFICIENT"],
            "validators": pass_validators,
            "trust_domains": pass_domains,
            "pass_validators": pass_validators,
            "fail_validators": sorted(
                item["validator_id"] for item in valid if item["decision"] == "FAIL"
            ),
        }

    if len(pass_domains) < min_trust_domains:
        return {
            "status": "BLOCK",
            "decision": "SAFE_HOLD",
            "violations": ["TRUST_DOMAIN_QUORUM_INSUFFICIENT"],
            "validators": pass_validators,
            "trust_domains": pass_domains,
            "pass_validators": pass_validators,
            "fail_validators": sorted(
                item["validator_id"] for item in valid if item["decision"] == "FAIL"
            ),
        }

    return {
        "status": "PASS",
        "decision": "PROMOTE",
        "violations": [],
        "validators": pass_validators,
        "trust_domains": pass_domains,
        "pass_validators": pass_validators,
        "fail_validators": [],
    }
