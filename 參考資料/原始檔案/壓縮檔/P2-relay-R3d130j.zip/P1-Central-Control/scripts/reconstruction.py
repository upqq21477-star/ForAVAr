#!/usr/bin/env python3
"""CS-1 B5：Blueprint v2、Reconstruction Input Set、Clean Build gate（G2／G3；Master §19–22；03「重建與自我修復」）。

stdlib only、決定性、不需 git／網路。Blueprint（canonical/blueprint.json）宣告元件與歸屬；輸入集
（canonical/reconstruction_input_set.json）由 Blueprint＋現行檔案產生（`write`），記每個元件的 hash。
Reconstruction Gate：INPUT_SET → SCHEMA_CONTRACT → CLEAN_BUILD → STRUCTURAL → BEHAVIORAL → ACCEPTANCE；
Clean Build 只複製 REQUIRED／DERIVED 元件（不補入舊資料）、在乾淨目錄跑驗收測試；任一失敗＝RECONSTRUCTION_BLOCKED。
機器只做可確定的事（歸屬、hash、schema、編譯、測試）；元件分類與 Blueprint 是否足夠屬 CONTROL_RESEARCH 語義判斷（可被推翻）。
重大更新才須通過本 gate；日常小改用增量變更。reason code 為 `CODE[:detail]`，碼表見 policy/reconstruction.v1.0.json。
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any

from event_log import content_hash
from knowledge_intake import validate

ROOT = Path(__file__).resolve().parents[2]
POLICY_PATH = ROOT / "P1-Central-Control" / "policy" / "reconstruction.v1.0.json"
PATH_REASONS = {"SCHEMA_REF_MISSING", "CONTRACT_REF_MISSING", "INVARIANT_TEST_MISSING", "GATE_TEST_MISSING"}


def policy() -> dict[str, Any]:
    return json.loads(POLICY_PATH.read_text(encoding="utf-8"))


def _rx(pattern: str) -> re.Pattern[str]:
    out, i = "", 0
    while i < len(pattern):
        if pattern.startswith("**", i):
            out, i = out + ".*", i + 2
        elif pattern[i] == "*":
            out, i = out + "[^/]*", i + 1
        else:
            out, i = out + re.escape(pattern[i]), i + 1
    return re.compile("^" + out + "$")


def _read_json(root: Path, rel: str) -> Any:
    return json.loads((root / rel).read_text(encoding="utf-8"))


def seal(record: dict[str, Any], schema: str) -> dict[str, Any]:
    record.pop("content_hash", None)
    record["content_hash"] = content_hash(record)
    validate(schema, record)
    return record


def load_blueprint(root: Path) -> dict[str, Any]:
    try:
        bp = _read_json(root, policy()["blueprint_path"])
        validate("blueprint", bp)
    except (OSError, ValueError) as exc:
        raise ValueError(f"BLUEPRINT_INVALID:{exc}") from exc
    if bp["content_hash"] != content_hash(bp):
        raise ValueError("BLUEPRINT_INVALID:content_hash")
    return bp


def _all_files(root: Path) -> list[str]:
    p = policy()
    out = []
    for path in sorted(root.rglob("*")):
        rel = path.relative_to(root)
        if not path.is_file() or set(rel.parts) & set(p["ignored_parts"]) or path.suffix in p["ignored_suffixes"]:
            continue
        out.append(rel.as_posix())
    return out


def ownership(root: Path, bp: dict[str, Any]) -> tuple[dict[str, list[str]], list[str]]:
    """component_id → 檔案；回傳 (歸屬, reasons)。每個檔案須恰好屬於一個元件。"""
    comps = {c["component_id"]: ([_rx(x) for x in c["include"]], [_rx(x) for x in c.get("exclude", [])]) for c in bp["components"]}
    owned: dict[str, list[str]] = {cid: [] for cid in comps}
    reasons = []
    for rel in _all_files(root):
        hit = [cid for cid, (inc, exc) in comps.items() if any(r.match(rel) for r in inc) and not any(r.match(rel) for r in exc)]
        if not hit:
            reasons.append(f"UNOWNED_FILE:{rel}")
        elif len(hit) > 1:
            reasons.append(f"OVERLAPPING_OWNERSHIP:{rel}={'+'.join(hit)}")
        else:
            owned[hit[0]].append(rel)
    return owned, reasons


def _digest(root: Path, files: list[str], skip: str) -> tuple[str, int, int]:
    lines, size = [], 0
    for rel in files:
        if rel == skip:
            continue
        data = (root / rel).read_bytes()
        size += len(data)
        lines.append(f"{rel}\0{hashlib.sha256(data).hexdigest()}\n")
    return "sha256:" + hashlib.sha256("".join(lines).encode("utf-8")).hexdigest(), size, len(lines)


def build_input_set(root: Path, bp: dict[str, Any] | None = None) -> dict[str, Any]:
    bp = bp or load_blueprint(root)
    p = policy()
    owned, reasons = ownership(root, bp)
    if reasons:
        raise ValueError(reasons[0])
    versions, hashes = {}, {}
    for c in (c for c in bp["components"] if c["class"] in p["build_classes"]):  # 非建置元件不入 hash：改 docs 不使輸入集過期
        files = owned[c["component_id"]]
        digest, size, count = _digest(root, files, p["input_set_path"])
        versions[c["component_id"]] = {"file_count": count, "bytes": size}
        hashes[c["component_id"]] = digest
    reg = _read_json(root, "P1-Central-Control/canonical/canonical_object_registry.json")
    schemas = sorted({o["schema"] for o in reg["objects"]} | {"P1-Central-Control/schemas/canonical_identity.schema.json",
                                                              "P1-Central-Control/schemas/canonical_common.schema.json"})
    caps = sorted(c["capability_id"] for c in _read_json(root, "P1-Central-Control/capability_registry.json")["capabilities"])
    rec = {
        "object_id": f"RECONSTRUCTION_INPUT_SET:{bp['blueprint_version']}", "kind": "RECONSTRUCTION_INPUT_SET", "schema_version": "1.0",
        "blueprint_version": bp["blueprint_version"], "blueprint_hash": bp["content_hash"],
        "required_components": [{"component_id": c["component_id"], "class": c["class"]} for c in bp["components"]],
        "component_versions": versions, "schema_refs": schemas, "contract_refs": sorted(c["ref"] for c in bp["contracts"]),
        "dependency_policy": list(bp["external_dependency_rules"]), "required_capabilities": caps,
        "required_external_adapters": sorted(c["component_id"] for c in bp["components"] if c["class"] == "EXTERNAL"),
        "integrity_hashes": hashes, "acceptance_requirements": [r["requirement_id"] for r in bp["acceptance_requirements"]],
    }
    return seal(rec, "reconstruction_input_set")


def write_input_set(root: Path) -> dict[str, Any]:
    rec = build_input_set(root)
    (root / policy()["input_set_path"]).write_text(json.dumps(rec, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return rec


# ---- 各階段：回傳 reasons（空＝PASS） ----

def _stage_input_set(root: Path, bp: dict[str, Any]) -> list[str]:
    owned, reasons = ownership(root, bp)
    reasons += [f"ARCHIVE_INPUT_UNBOUND:{c['component_id']}" for c in bp["components"] if c["class"] == "ARCHIVE_DERIVED" and not c.get("rescue_ref")]
    path = root / policy()["input_set_path"]
    if not path.is_file():
        return reasons + ["INPUT_SET_MISSING"]
    try:
        stored = json.loads(path.read_text(encoding="utf-8"))
        validate("reconstruction_input_set", stored)
    except (ValueError, OSError) as exc:
        return reasons + [f"INPUT_SET_INVALID:{exc}"]
    if reasons:
        return reasons
    fresh = build_input_set(root, bp)
    if stored.get("content_hash") != fresh["content_hash"]:
        diff = sorted(k for k in fresh["integrity_hashes"] if stored["integrity_hashes"].get(k) != fresh["integrity_hashes"][k])
        reasons.append("INPUT_SET_STALE:" + (",".join(diff) or "metadata"))
    return reasons


def _build_files(root: Path, bp: dict[str, Any], owned: dict[str, list[str]]) -> list[str]:
    keep = set(policy()["build_classes"])
    return [f for c in bp["components"] if c["class"] in keep for f in owned[c["component_id"]]]


def _stage_schema_contract(root: Path, bp: dict[str, Any], files: list[str]) -> list[str]:
    reasons = []
    for rel in files:
        if rel.endswith(".json"):
            try:
                _read_json(root, rel)
            except ValueError as exc:
                reasons.append(f"JSON_INVALID:{rel}:{exc}")
    inputs = build_input_set(root, bp)
    reasons += [f"SCHEMA_REF_MISSING:{r}" for r in inputs["schema_refs"] if r not in files]
    reasons += [f"CONTRACT_REF_MISSING:{r}" for r in inputs["contract_refs"] if r not in files]
    reasons += [f"INVARIANT_TEST_MISSING:{i['test_ref']}" for i in bp["invariants"] if i["test_ref"] not in files]
    return reasons


def clean_build(root: Path, files: list[str], dest: Path) -> None:
    if dest.exists() and any(dest.iterdir()):
        raise ValueError(f"DEST_NOT_EMPTY:{dest}")
    for rel in files:
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(root / rel, target)


def _stage_build_check(dest: Path, bp: dict[str, Any], inputs: dict[str, Any], files: list[str]) -> list[str]:
    reasons, built = [], set(files)
    owned, _ = ownership(dest, bp)
    skip = policy()["input_set_path"]
    keep = set(policy()["build_classes"])
    for c in bp["components"]:
        got = owned[c["component_id"]]
        if c["class"] in keep:
            if _digest(dest, got, skip)[0] != inputs["integrity_hashes"][c["component_id"]]:
                reasons.append(f"BUILD_HASH_MISMATCH:{c['component_id']}")
        elif got:
            reasons.append(f"NON_INPUT_PRESENT:{c['component_id']}")
    return reasons + [f"NON_INPUT_PRESENT:{r}" for r in _all_files(dest) if r not in built]


def _stage_structural(dest: Path) -> list[str]:
    reasons = []
    for rel in _all_files(dest):
        if rel.endswith(".py"):
            try:
                compile((dest / rel).read_text(encoding="utf-8"), rel, "exec")
            except (SyntaxError, ValueError) as exc:
                reasons.append(f"PY_SYNTAX:{rel}:{exc}")
    gate = dest / "P1-Central-Control" / "control_gate_registry.json"
    if gate.is_file():
        reasons += [f"GATE_TEST_MISSING:{t}" for t in json.loads(gate.read_text(encoding="utf-8")).get("tests", []) if not (dest / t).is_file()]
    return reasons


def _run_unittest(dest: Path, req: dict[str, Any]) -> tuple[list[str], int]:
    env = {k: v for k, v in os.environ.items() if k != "PYTHONPATH"}
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    cmd = [sys.executable, "-B", "-m", "unittest", "discover", "-s", req["start_dir"], "-p", req.get("pattern", "test_*.py")]
    try:
        proc = subprocess.run(cmd, cwd=dest, env=env, capture_output=True, text=True, timeout=req.get("timeout_sec", 600))
    except subprocess.TimeoutExpired:
        return ["BEHAVIOR_TIMEOUT"], 0
    out = proc.stderr + proc.stdout
    m = re.search(r"Ran (\d+) tests?", out)
    ran = int(m.group(1)) if m else 0
    if proc.returncode != 0:
        tail = " | ".join(x for x in out.strip().splitlines()[-4:])
        return [f"BEHAVIOR_FAILED:{tail}"], ran
    if ran < req.get("min_tests", 1):
        return [f"NO_TESTS_RAN:ran={ran}<min={req.get('min_tests', 1)}"], ran
    return [], ran


def reconstruct(root: Path, dest: Path, *, run_behavioral: bool = True) -> dict[str, Any]:
    """Reconstruction Gate。回傳報告；status＝RECONSTRUCTED／PARTIAL_NOT_ACCEPTED／RECONSTRUCTION_BLOCKED。"""
    stages = {s: "SKIPPED" for s in policy()["stages"]}
    report: dict[str, Any] = {"status": "RECONSTRUCTION_BLOCKED", "stage": None, "reasons": [], "stages": stages, "tests_ran": 0}

    def block(stage: str, reasons: list[str]) -> dict[str, Any]:
        stages[stage] = "FAIL"
        report.update(stage=stage, reasons=reasons)
        return report

    try:
        bp = load_blueprint(root)
    except ValueError as exc:
        return block("INPUT_SET", [str(exc)])
    reasons = _stage_input_set(root, bp)
    if reasons:
        return block("INPUT_SET", reasons)
    stages["INPUT_SET"] = "PASS"
    owned, _ = ownership(root, bp)
    files = _build_files(root, bp, owned)
    reasons = _stage_schema_contract(root, bp, files)
    if reasons:
        return block("SCHEMA_CONTRACT", reasons)
    stages["SCHEMA_CONTRACT"] = "PASS"
    inputs = build_input_set(root, bp)
    try:
        clean_build(root, files, dest)
    except ValueError as exc:
        return block("CLEAN_BUILD", [str(exc)])
    reasons = _stage_build_check(dest, bp, inputs, files)
    if reasons:
        return block("CLEAN_BUILD", reasons)
    stages["CLEAN_BUILD"] = "PASS"
    reasons = _stage_structural(dest)
    if reasons:
        return block("STRUCTURAL", reasons)
    stages["STRUCTURAL"] = "PASS"
    if not run_behavioral:
        report.update(status="PARTIAL_NOT_ACCEPTED", stage="STRUCTURAL")
        return report
    for req in (r for r in bp["acceptance_requirements"] if r["kind"] == "UNITTEST"):
        reasons, ran = _run_unittest(dest, req)
        report["tests_ran"] += ran
        if reasons:
            return block("BEHAVIORAL", reasons)
    stages["BEHAVIORAL"] = stages["ACCEPTANCE"] = "PASS"
    report.update(status="RECONSTRUCTED", stage="ACCEPTANCE")
    return report


def rescue_targets(report: dict[str, Any]) -> list[dict[str, str]]:
    """Blueprint 不足時的缺失權威（自我修復）：回傳可交給 `ArchiveAccess.retrieve(target=…, purpose=RECONSTRUCTION_SUPPORT)` 的精確 target。"""
    out = []
    for r in report.get("reasons", []):
        code, _, detail = r.partition(":")
        if code in PATH_REASONS and detail:
            out.append({"origin_path": detail})
    return out


def main(argv: list[str]) -> int:
    cmd = argv[1] if len(argv) > 1 else "check"
    root = Path(argv[2]).resolve() if len(argv) > 2 and not argv[2].startswith("--") else ROOT
    if cmd == "write":
        print(write_input_set(root)["content_hash"])
        return 0
    if cmd == "check":
        try:
            reasons = _stage_input_set(root, load_blueprint(root))
        except ValueError as exc:
            reasons = [str(exc)]
        print(json.dumps({"status": "PASS" if not reasons else "RECONSTRUCTION_BLOCKED", "reasons": reasons}, ensure_ascii=False, indent=2))
        return 1 if reasons else 0
    if cmd == "reconstruct":
        dest = Path(argv[argv.index("--dest") + 1]) if "--dest" in argv else Path("/tmp/p1-clean-build")
        report = reconstruct(root, dest, run_behavioral="--no-behavioral" not in argv)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report["status"] == "RECONSTRUCTED" else 1
    print("usage: reconstruction.py write|check|reconstruct [root] [--dest D] [--no-behavioral]", file=sys.stderr)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
