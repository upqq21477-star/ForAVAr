#!/usr/bin/env python3
"""Central-owned creation of an immutable Acceptance Request/Context artifact."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/acceptance_context.schema.json"
ACCEPTANCE_DIR = ROOT / "P1-Central-Control/acceptance"

PENDING_STAGE_STATUSES = {"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE", "READY_FOR_CLOSE_ACCEPTANCE"}


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def dump(value: dict[str, Any]) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2) + "\n"


def validate(value: dict[str, Any]) -> None:
    schema = load(SCHEMA)
    Draft202012Validator(schema).validate(value)


def sha256_payload(value: dict[str, Any]) -> str:
    normalized = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return "sha256:" + hashlib.sha256(normalized).hexdigest()


def create_acceptance_context(
    *,
    root: Path = ROOT,
    output_path: Path | None = None,
) -> dict[str, Any]:
    current_path = root / "P1-CURRENT.json"
    current = load(current_path)
    stage = current.get("current_stage", {})
    if stage.get("status") not in PENDING_STAGE_STATUSES:
        raise ValueError("WORK_UNIT_NOT_READY_FOR_ACCEPTANCE_CONTEXT")

    work_ref = current.get("implementation_control", {}).get("active_work_packet")
    if not work_ref:
        raise ValueError("ACTIVE_WORK_PACKET_MISSING")

    work_path = root / work_ref if not Path(work_ref).is_absolute() else Path(work_ref)
    if not work_path.is_file():
        raise ValueError("ACTIVE_WORK_PACKET_NOT_FOUND")
    work = load(work_path)

    work_unit = stage.get("work_unit_id") or stage.get("id")
    if work.get("work_unit") != work_unit:
        raise ValueError("WORK_UNIT_MISMATCH")
    if work.get("status") not in PENDING_STAGE_STATUSES:
        raise ValueError("WORK_PACKET_NOT_READY_FOR_ACCEPTANCE_CONTEXT")

    task_ref = work.get("task_packet_ref")
    construction_ref = work.get("construction_packet_ref")
    if not task_ref or not construction_ref:
        raise ValueError("ACCEPTANCE_CONTEXT_DEPENDENCY_REF_MISSING")

    task_path = root / task_ref if not Path(task_ref).is_absolute() else Path(task_ref)
    construction_path = (
        root / construction_ref
        if not Path(construction_ref).is_absolute()
        else Path(construction_ref)
    )
    if not task_path.is_file():
        raise ValueError("TASK_PACKET_NOT_FOUND")
    if not construction_path.is_file():
        raise ValueError("CONSTRUCTION_PACKET_NOT_FOUND")

    task = load(task_path)
    construction = load(construction_path)

    if construction.get("work_unit") != work_unit:
        raise ValueError("CONSTRUCTION_WORK_UNIT_MISMATCH")
    if construction.get("status") not in PENDING_STAGE_STATUSES:
        raise ValueError("CONSTRUCTION_NOT_READY_FOR_ACCEPTANCE_CONTEXT")
    if task.get("object_id") != "TASK_PACKET:" + task.get("packet_id", ""):
        raise ValueError("TASK_PACKET_IDENTITY_INVALID")

    required_checks = [
        "repository_result_reentry",
        "duplicate_result_identity",
        "current_truth_reconciliation",
        "continuation_box_amnesia_reconstruction",
        "segment_state_event_replay",  # D11（r20 登錄）：Segment 狀態僅憑 Event Log 重建相符
    ]
    head_sha = stage.get("validated_head_sha") or stage.get("merged_commit_sha")
    if not head_sha:
        raise ValueError("ACCEPTANCE_CONTEXT_IMPLEMENTATION_HEAD_MISSING")

    context_base = {
        "context_id": f"ACCEPTANCE_CONTEXT:{work_unit}",
        "kind": "ACCEPTANCE_CONTEXT",
        "status": "OPEN",
        "authority": "P1-CURRENT",
        "lifecycle_owner": "CENTRAL",
        "mode": "SIMULATION_ONLY",
        "head_sha": head_sha,
        "work_unit_ref": work_unit,
        "work_id": work["work_id"],
        "task_packet_ref": task_ref,
        "construction_packet_ref": construction_ref,
        "required_checks": required_checks,
        "source_refs": [
            "P1-CURRENT.json",
            work_ref,
            task_ref,
            construction_ref,
            "P1-Central-Control/tests/test_m32_close_vertical_slice.py",
            "P1-Central-Control/tests/test_repository_result_ingestion.py",
            "P1-Central-Control/tests/test_continuation_context_box.py",
            "P1-Central-Control/tests/test_current_truth_reconciliation.py",
            "P1-Central-Control/tests/test_segment_event_replay.py",
        ],
    }
    context = dict(context_base)
    context["content_sha256"] = sha256_payload(context_base)
    validate(context)

    current_ref = stage.get("acceptance_ref")
    if current_ref:
        existing_path = root / current_ref if not Path(current_ref).is_absolute() else Path(current_ref)
        if not existing_path.is_file():
            raise ValueError("ACCEPTANCE_CONTEXT_REFERENCE_MISSING")
        existing = load(existing_path)
        validate(existing)
        if existing["content_sha256"] != context["content_sha256"]:
            raise ValueError("ACCEPTANCE_CONTEXT_CONFLICT")
        return {
            "status": "IDEMPOTENT_REPLAY",
            "acceptance_ref": current_ref,
            "context": existing,
        }

    target = output_path or (root / "P1-Central-Control/acceptance" / f"{work_unit}.acceptance.json")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(dump(context), encoding="utf-8")

    relative_target = target.relative_to(root).as_posix()
    updated_current = dict(current)
    updated_stage = dict(stage)
    updated_stage["acceptance_ref"] = relative_target
    updated_stage["acceptance_mode"] = "SIMULATION_ONLY"
    updated_current["current_stage"] = updated_stage
    current_path.write_text(dump(updated_current), encoding="utf-8")

    return {
        "status": "CREATED",
        "acceptance_ref": relative_target,
        "context": context,
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--output")
    args = parser.parse_args()
    result = create_acceptance_context(
        root=Path(args.root).resolve(),
        output_path=Path(args.output).resolve() if args.output else None,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
