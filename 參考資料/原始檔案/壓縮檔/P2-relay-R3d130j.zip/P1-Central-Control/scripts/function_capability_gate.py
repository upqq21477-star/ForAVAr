#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

VALID_CLASSIFICATIONS = {
    "MODEL_NATIVE",
    "TOOL_GUARD",
    "DOMAIN_SPECIALIZED",
    "RETIRED_AS_SYSTEM",
}

VALID_RUNTIME_STATUS = {
    "EXECUTABLE_NOW",
    "ROUTE_ONLY",
    "MODEL_OR_LOOP_NATIVE",
}

def load(path: str):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def main() -> int:
    ap = argparse.ArgumentParser(description="P1 F01-F48 canonical capability mapping gate")
    ap.add_argument("function_registry")
    ap.add_argument("capability_registry")
    args = ap.parse_args()

    fdata = load(args.function_registry)
    cdata = load(args.capability_registry)

    errors = []
    rows = fdata.get("functions", [])
    capability_ids = {x.get("capability_id") for x in cdata.get("capabilities", [])}

    expected = {f"F{i:02d}" for i in range(1, 49)}
    actual = {x.get("function_id") for x in rows}

    missing = sorted(expected - actual)
    extra = sorted(actual - expected)
    if missing:
        errors.append("缺少 Function: " + ", ".join(missing))
    if extra:
        errors.append("存在非 F01-F48 Function: " + ", ".join(extra))

    if len(rows) != 48:
        errors.append(f"Function mapping 數量必須為 48，目前為 {len(rows)}")

    seen = set()
    for row in rows:
        fid = row.get("function_id", "UNKNOWN")
        if fid in seen:
            errors.append(f"{fid}: function_id 重複")
        seen.add(fid)

        if row.get("classification") not in VALID_CLASSIFICATIONS:
            errors.append(f"{fid}: classification 不合法")
        cid = row.get("canonical_capability")
        if cid not in capability_ids:
            errors.append(f"{fid}: canonical_capability {cid} 不存在於 capability registry")
        status = row.get("runtime_status")
        if status not in VALID_RUNTIME_STATUS:
            errors.append(f"{fid}: runtime_status 不合法")
        if status == "EXECUTABLE_NOW" and not row.get("runtime_owner"):
            errors.append(f"{fid}: EXECUTABLE_NOW 必須指定 runtime_owner")
        if status != "EXECUTABLE_NOW" and row.get("runtime_owner"):
            errors.append(f"{fid}: 非 EXECUTABLE_NOW 不應宣稱已有 runtime_owner: {row.get('runtime_owner')}")

    result = {
        "status": "BLOCK" if errors else "PASS",
        "function_count": len(rows),
        "canonical_capability_count": len(capability_ids),
        "executable_now": sum(x.get("runtime_status") == "EXECUTABLE_NOW" for x in rows),
        "route_only": sum(x.get("runtime_status") == "ROUTE_ONLY" for x in rows),
        "model_or_loop_native": sum(x.get("runtime_status") == "MODEL_OR_LOOP_NATIVE" for x in rows),
        "errors": errors,
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 3 if errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
