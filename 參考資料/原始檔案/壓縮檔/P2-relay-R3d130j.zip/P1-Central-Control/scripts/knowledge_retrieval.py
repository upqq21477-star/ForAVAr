#!/usr/bin/env python3
"""CS-1 B7：Knowledge Retrieval（Exact／Structural；Master §10、02 P9）與狀態快照（P16／P20 的持久化邊界）。

stdlib only、決定性、不讀時鐘。Semantic／向量檢索不做（K10：索引限本機、不用需 API 的服務）。
回傳一律是「資料」：`instruction_content`＝False；非 CANONICAL 者 `truth_status`＝UNTRUSTED_CANDIDATE。
一般檢索走 B4 `scoped_search`（ACTIVE／WARM；SUPERSEDED／ARCHIVED 屬 COLD，須 reason；ARCHIVE 永遠拒）。
Conflict 不抹平：每筆結果帶 `state`（含未解 Conflict）。快照 restore 以 `integrity_gate` 把關，竄改即 RESTORE_BLOCKED。
"""

from __future__ import annotations

from typing import Any

from archive_governance import check_scope, scoped_search
from event_log import content_hash
from knowledge_intake import ReadingLedger, _sha
from knowledge_versioning import TemporalKnowledgeStore

EXACT_KEYS = ("claim_ref", "source_ref", "segment_ref", "observation_ref", "revision")
HARD_CAP = 50
_SCOPE_OF = {"ACTIVE": "ACTIVE", "TEMPORARY": "ACTIVE", "EXPERIMENTAL": "ACTIVE", "SUPERSEDED": "COLD", "ARCHIVED": "COLD"}
SNAPSHOT_KIND = "KNOWLEDGE_SNAPSHOT"


def _fail(code: str, detail: str = "") -> None:
    raise ValueError(f"{code}:{detail}" if detail else code)


class Retriever:
    def __init__(self, store: TemporalKnowledgeStore) -> None:
        if not isinstance(store, TemporalKnowledgeStore):
            _fail("STORE_TYPE_INVALID")
        self.s = store

    # ---- 投影 ----
    def view(self, ref: str) -> dict[str, Any]:
        c = self.s.claims[ref]
        canon = c["promotion"] == "CANONICAL"
        return {
            "claim_ref": ref, "claim_kind": c["claim_kind"], "content": c["content"], "revision": c["revision"],
            "promotion": c["promotion"], "state": self.s.state_vector(ref), "source_refs": list(c["source_refs"]),
            "evidence_refs": list(c["evidence_refs"]),
            "truth_status": "CANONICAL_CLAIM" if canon else "UNTRUSTED_CANDIDATE", "instruction_content": False,
        }

    def _segments(self, ref: str) -> set[str]:
        c = self.s.claims[ref]
        return {self.s.obs[o]["segment_ref"] for o in c["observation_refs"]} | {
            self.s.evid[e]["segment_ref"] for e in c["evidence_refs"] if e in self.s.evid}

    def _items(self, promotion: tuple[str, ...], at: str | None) -> list[dict[str, Any]]:
        live: set[str] | None = None
        if at is not None:
            v = self.s.valid_at(at)
            live = set(v["valid"]) | set(v["disputed"])
        return [{"ref": r, "scope": _SCOPE_OF[c["lifecycle"]]} for r, c in sorted(self.s.claims.items())
                if c["promotion"] in promotion and (live is None or r in live)]

    def _run(self, match: Any, scope: Any, reason: str | None, promotion: tuple[str, ...], at: str | None, query: dict[str, Any]) -> dict[str, Any]:
        hits = scoped_search(self._items(promotion, at), match, scope, reason=reason)
        if len(hits) > HARD_CAP:
            _fail("TARGET_TOO_BROAD", f"{len(hits)}>{HARD_CAP}")
        sc = [scope] if isinstance(scope, str) else list(scope)
        return {"query": query, "scope": sc, "at": at, "results": [self.view(h["ref"]) for h in hits]}

    # ---- Exact（claim／source／segment／observation／revision；至少一鍵、多鍵為 AND）----
    def exact(self, *, scope: Any = ("ACTIVE", "WARM"), reason: str | None = None, promotion: tuple[str, ...] = ("CANONICAL",),
              at: str | None = None, **keys: Any) -> dict[str, Any]:
        if not keys:
            _fail("EXACT_KEY_REQUIRED")
        if set(keys) - set(EXACT_KEYS):
            _fail("EXACT_KEY_UNKNOWN", ",".join(sorted(set(keys) - set(EXACT_KEYS))))
        if any(v is None or v == "" for v in keys.values()):
            _fail("EXACT_KEY_EMPTY")

        def match(item: dict[str, Any]) -> bool:
            c = self.s.claims[item["ref"]]
            tests = {"claim_ref": item["ref"] == keys.get("claim_ref"), "source_ref": keys.get("source_ref") in c["source_refs"],
                     "segment_ref": keys.get("segment_ref") in self._segments(item["ref"]),
                     "observation_ref": keys.get("observation_ref") in c["observation_refs"], "revision": c["revision"] == keys.get("revision")}
            return all(tests[k] for k in keys)

        return self._run(match, scope, reason, promotion, at, {"mode": "EXACT", **keys})

    def text(self, needle: str, *, scope: Any = ("ACTIVE", "WARM"), reason: str | None = None,
             promotion: tuple[str, ...] = ("CANONICAL",), at: str | None = None) -> dict[str, Any]:
        """內容精確子字串（casefold）；不是語義檢索。過短（<2）拒。"""
        n = (needle or "").strip().casefold()
        if len(n) < 2:
            _fail("TEXT_TOO_SHORT")
        return self._run(lambda i: n in self.s.claims[i["ref"]]["content"].casefold(), scope, reason, promotion, at,
                         {"mode": "TEXT", "needle": needle})

    # ---- Structural：claim → version → conflict → evidence → source ----
    def trace(self, claim_ref: str) -> dict[str, Any]:
        if claim_ref not in self.s.claims:
            _fail("CLAIM_UNKNOWN", claim_ref)
        versions = self.s.history(claim_ref)
        vrefs = {v["claim"] for v in versions}
        conflicts = [{"conflict": k, "status": c["status"], "claim_a": c["claim_a"], "claim_b": c["claim_b"]}
                     for k, c in sorted(self.s.conflicts.items()) if {c["claim_a"], c["claim_b"]} & vrefs]
        evidence, edges = [], []
        for v in versions:
            edges.append((v["claim"], "VERSION_OF", claim_ref))
            for e in self.s.claims[v["claim"]]["evidence_refs"]:
                ev = self.s.evid[e]
                ob = self.s.obs[ev["observation_ref"]]
                evidence.append({"claim_ref": v["claim"], "evidence_ref": e, "relation": ev["relation"], "locator": ev["locator"],
                                 "observation_ref": ob["object_id"], "segment_ref": ev["segment_ref"], "source_ref": ev["source_ref"],
                                 "fragment": ob["quote"], "segment_read_state": self.s.ledger.state(ev["segment_ref"])})
                edges += [(v["claim"], "SUPPORTED_BY", e), (e, "DERIVED_FROM", ob["object_id"]),
                          (ob["object_id"], "QUOTED_IN", ev["segment_ref"]), (ev["segment_ref"], "PART_OF", ev["source_ref"])]
        for c in conflicts:
            edges += [(c["claim_a"], "CONFLICTS_WITH", c["claim_b"])]
        return {"claim": self.view(claim_ref), "versions": versions, "conflicts": conflicts, "evidence": evidence,
                "sources": sorted({e["source_ref"] for e in evidence}), "edges": sorted(set(edges)), "instruction_content": False}

    def check_scope_for(self, scope: str, reason: str | None = None) -> str:
        return check_scope(scope, reason=reason)


# ---- 快照（Working Context 清除後的權威恢復邊界）----

def snapshot(store: TemporalKnowledgeStore) -> dict[str, Any]:
    body: dict[str, Any] = {
        "kind": SNAPSHOT_KIND, "schema_version": "1.0", "ledger_head": store.ledger.head(),
        "source_hashes": {r: _sha(t.encode("utf-8")) for r, t in sorted(store.texts.items())},
        "observations": [store.obs[k] for k in sorted(store.obs)], "evidence": [store.evid[k] for k in sorted(store.evid)],
        "claims": [store.claims[k] for k in sorted(store.claims)], "conflicts": [store.conflicts[k] for k in sorted(store.conflicts)],
    }
    body["snapshot_hash"] = content_hash(body)
    return body


def restore(snap: dict[str, Any], ledger: ReadingLedger, texts: dict[str, str]) -> TemporalKnowledgeStore:
    """快照＋Ledger＋原文 → 新 Store；任一不符即 `RESTORE_BLOCKED:<原因>`（不靠模型記憶補資料）。"""
    body = {k: v for k, v in snap.items() if k != "snapshot_hash"}
    if snap.get("kind") != SNAPSHOT_KIND or snap.get("snapshot_hash") != content_hash(body):
        _fail("RESTORE_BLOCKED", "SNAPSHOT_HASH")
    if snap["ledger_head"] != ledger.head():
        _fail("RESTORE_BLOCKED", "LEDGER_HEAD_MISMATCH")
    if snap["source_hashes"] != {r: _sha(t.encode("utf-8")) for r, t in sorted(texts.items())}:
        _fail("RESTORE_BLOCKED", "SOURCE_TEXT_MISMATCH")
    st = TemporalKnowledgeStore(ledger, texts)
    st.obs, st.evid = {o["object_id"]: o for o in snap["observations"]}, {e["object_id"]: e for e in snap["evidence"]}
    st.claims, st.conflicts = {c["object_id"]: c for c in snap["claims"]}, {c["object_id"]: c for c in snap["conflicts"]}
    gate = st.integrity_gate()
    if gate["status"] != "PASS":
        _fail("RESTORE_BLOCKED", "INTEGRITY:" + ";".join(gate["errors"][:5]))
    return st
