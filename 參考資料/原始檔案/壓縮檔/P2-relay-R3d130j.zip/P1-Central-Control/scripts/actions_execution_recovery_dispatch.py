#!/usr/bin/env python3
"""Execute or preview an Actions execution recovery decision."""

from __future__ import annotations

import argparse
import json
import os
import subprocess
import urllib.parse
from pathlib import Path
from typing import Any
from urllib.request import Request, urlopen

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_recovery_dispatch.schema.json"
RECOVERY = ROOT / "P1-Central-Control/scripts/actions_execution_recovery.py"


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _validate(value: dict[str, Any]) -> None:
    schema = _load(SCHEMA)
    Draft202012Validator(schema).validate(value)


def _dispatch_workflow(repo: str, workflow_file: str, ref: str, token: str) -> dict[str, Any]:
    encoded_workflow = urllib.parse.quote(workflow_file, safe="")
    url = f"https://api.github.com/repos/{repo}/actions/workflows/{encoded_workflow}/dispatches"
    request = Request(
        url,
        method="POST",
        data=json.dumps({"ref": ref}).encode("utf-8"),
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urlopen(request, timeout=20) as response:
        body = response.read().decode("utf-8", errors="replace")
        return {"status": response.status, "body": body}


def _rerun_failed_jobs(repo: str, run_id: int, token: str) -> dict[str, Any]:
    url = f"https://api.github.com/repos/{repo}/actions/runs/{run_id}/rerun-failed-jobs"
    request = Request(
        url,
        method="POST",
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    with urlopen(request, timeout=20) as response:
        body = response.read().decode("utf-8", errors="replace")
        return {"status": response.status, "body": body}


def _local_diagnostic_command(
    output: Path,
    acceptance_output: Path,
    local_head_sha: str | None,
) -> list[str]:
    command = [
        "python3",
        str(ROOT / "P1-Central-Control/scripts/local_acceptance.py"),
        "--output",
        str(output),
        "--acceptance-output",
        str(acceptance_output),
    ]
    if local_head_sha:
        command.extend(["--head", local_head_sha])
    return command


def _local_replay_command(
    selection: Path,
    observation: Path,
    output: Path,
    acceptance_output: Path,
    local_head_sha: str | None,
) -> list[str]:
    command = [
        "python3",
        str(ROOT / "P1-Central-Control/scripts/actions_regression_replay.py"),
        str(selection),
        str(observation),
        "--output",
        str(output),
        "--acceptance-output",
        str(acceptance_output),
        "--skip-unit-tests",
    ]
    if local_head_sha:
        command.extend(["--local-head-sha", local_head_sha])
    return command


def dispatch(
    diagnostic: dict[str, Any],
    *,
    mode: str = "PLAN",
    repo: str | None = None,
    run_id: int | None = None,
    token: str | None = None,
    selection: Path | None = None,
    observation: Path | None = None,
    output: Path | None = None,
    acceptance_output: Path | None = None,
    local_head_sha: str | None = None,
    workflow_file: str | None = None,
    workflow_ref: str | None = None,
    attempt_index: int = 0,
    max_external_retries: int = 2,
) -> dict[str, Any]:
    from actions_execution_recovery import build

    local_diagnostic_available = output is not None and acceptance_output is not None
    local_replay_available = local_diagnostic_available or all(
        x is not None for x in (selection, observation, output, acceptance_output)
    )
    recovery = build(
        diagnostic,
        attempt_index=attempt_index,
        max_external_retries=max_external_retries,
        local_replay_available=local_replay_available,
    )
    decision = recovery["decision"]
    source = recovery["source_classification"]
    dispatch_id = f"ACTIONS_DISPATCH:{recovery['recovery_id'].split(':', 1)[-1]}"

    base = {
        "dispatch_id": dispatch_id,
        "decision": decision,
        "mode": mode,
        "status": "PLANNED",
        "action": recovery["recommended_command"],
        "source_classification": source,
        "external_run_id": run_id,
        "external_repo": repo,
        "external_response": None,
        "local_return_code": None,
        "local_command": [],
        "error": None,
    }

    if decision == "COMPLETE":
        base["status"] = "NOOP"
        base["action"] = "none"
        return _validated(base)

    if decision in {"BLOCK", "REQUIRE_MANUAL_REVIEW"}:
        base["status"] = "BLOCKED"
        return _validated(base)

    if decision == "RETRY_EXTERNAL":
        if source == "NOT_DISPATCHED":
            if mode == "PLAN":
                base["action"] = "github_actions.workflow_dispatch"
                return _validated(base)
            if not repo or not token or not workflow_file or not workflow_ref:
                base["status"] = "ERROR"
                base["error"] = "WORKFLOW_REDISPATCH_REQUIRES_REPO_WORKFLOW_TOKEN_REF"
                return _validated(base)
            try:
                base["external_response"] = _dispatch_workflow(repo, workflow_file, workflow_ref, token)
                base["status"] = "EXECUTED"
            except Exception as exc:  # pragma: no cover - network boundary
                base["status"] = "ERROR"
                base["error"] = str(exc)
            return _validated(base)

        if mode == "PLAN":
            base["action"] = "github_actions.rerun_failed_jobs"
            return _validated(base)
        if not repo or run_id is None or not token:
            base["status"] = "ERROR"
            base["error"] = "EXTERNAL_RETRY_REQUIRES_REPO_RUN_ID_TOKEN"
            return _validated(base)
        try:
            base["external_response"] = _rerun_failed_jobs(repo, run_id, token)
            base["status"] = "EXECUTED"
        except Exception as exc:  # pragma: no cover - network boundary
            base["status"] = "ERROR"
            base["error"] = str(exc)
        return _validated(base)

    if decision == "DIAGNOSE":
        if output is None or acceptance_output is None:
            base["status"] = "ERROR"
            base["error"] = "DIAGNOSTIC_REQUIRES_OUTPUTS"
            return _validated(base)
        command = _local_diagnostic_command(
            output,
            acceptance_output,
            local_head_sha or diagnostic.get("head_sha"),
        )
        base["local_command"] = command
        if mode == "PLAN":
            return _validated(base)
        try:
            completed = subprocess.run(command, cwd=ROOT, check=False)
            base["local_return_code"] = completed.returncode
            if completed.returncode not in {0, 1, 2}:
                base["status"] = "ERROR"
                base["error"] = f"LOCAL_DIAGNOSTIC_EXIT_CODE:{completed.returncode}"
            elif source == "RUNNER_STARTUP_FAILURE":
                if completed.returncode != 0:
                    base["status"] = "BLOCKED"
                    base["error"] = (
                        "LOCAL_DIAGNOSTIC_DID_NOT_PASS"
                        if completed.returncode == 1
                        else "LOCAL_DIAGNOSTIC_INCOMPLETE"
                    )
                elif attempt_index >= max_external_retries:
                    base["status"] = "BLOCKED"
                    base["error"] = "RECOVERY_RETRY_BUDGET_EXHAUSTED"
                elif not (repo and token and workflow_file and workflow_ref):
                    base["status"] = "ERROR"
                    base["error"] = "WORKFLOW_REDISPATCH_REQUIRES_REPO_WORKFLOW_TOKEN_REF"
                else:
                    base["external_response"] = _dispatch_workflow(
                        repo,
                        workflow_file,
                        workflow_ref,
                        token,
                    )
                    base["status"] = "EXECUTED"
                    base["action"] = "github_actions.workflow_dispatch_after_local_diagnosis"
            else:
                base["status"] = "EXECUTED"
        except Exception as exc:  # pragma: no cover - process boundary
            base["status"] = "ERROR"
            base["error"] = str(exc)
        return _validated(base)

    if decision == "REPLAY_LOCAL":
        if selection is None or observation is None or output is None or acceptance_output is None:
            base["status"] = "ERROR"
            base["error"] = "LOCAL_REPLAY_REQUIRES_SELECTION_OBSERVATION_OUTPUTS"
            return _validated(base)
        command = _local_replay_command(
            selection, observation, output, acceptance_output, local_head_sha
        )
        base["local_command"] = command
        if mode == "PLAN":
            return _validated(base)
        try:
            completed = subprocess.run(command, cwd=ROOT, check=False)
            base["local_return_code"] = completed.returncode
            base["status"] = "EXECUTED" if completed.returncode in {0, 2} else "ERROR"
            if base["status"] == "ERROR":
                base["error"] = f"LOCAL_REPLAY_EXIT_CODE:{completed.returncode}"
        except Exception as exc:  # pragma: no cover - process boundary
            base["status"] = "ERROR"
            base["error"] = str(exc)
        return _validated(base)

    base["status"] = "ERROR"
    base["error"] = f"UNHANDLED_RECOVERY_DECISION:{decision}"
    return _validated(base)


def _validated(value: dict[str, Any]) -> dict[str, Any]:
    _validate(value)
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description="Dispatch P1 Actions recovery")
    parser.add_argument("diagnostic")
    parser.add_argument("output")
    parser.add_argument("--mode", choices=["PLAN", "EXECUTE"], default="PLAN")
    parser.add_argument("--repo")
    parser.add_argument("--run-id", type=int)
    parser.add_argument("--token", default=os.environ.get("GITHUB_TOKEN"))
    parser.add_argument("--selection")
    parser.add_argument("--observation")
    parser.add_argument("--local-output")
    parser.add_argument("--acceptance-output")
    parser.add_argument("--local-head-sha")
    parser.add_argument("--workflow-file")
    parser.add_argument("--workflow-ref")
    parser.add_argument("--attempt-index", type=int, default=0)
    parser.add_argument("--max-external-retries", type=int, default=2)
    args = parser.parse_args()

    result = dispatch(
        _load(Path(args.diagnostic).resolve()),
        mode=args.mode,
        repo=args.repo,
        run_id=args.run_id,
        token=args.token,
        selection=Path(args.selection).resolve() if args.selection else None,
        observation=Path(args.observation).resolve() if args.observation else None,
        output=Path(args.local_output).resolve() if args.local_output else None,
        acceptance_output=Path(args.acceptance_output).resolve() if args.acceptance_output else None,
        local_head_sha=args.local_head_sha,
        workflow_file=args.workflow_file,
        workflow_ref=args.workflow_ref,
        attempt_index=args.attempt_index,
        max_external_retries=args.max_external_retries,
    )
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] not in {"ERROR"} else 1


if __name__ == "__main__":
    raise SystemExit(main())
