#!/usr/bin/env python3
"""Observe and automatically recover repository-controlled GitHub Actions execution.

This is an orchestration adapter only. Classification, recovery policy, local
diagnostic and truth semantics remain owned by the existing canonical scripts.
"""

from __future__ import annotations

import argparse
import json
import os
import urllib.parse
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
WORKFLOW_NAME = "M32-CLOSE acceptance"
WORKFLOW_FILE = ".github/workflows/m32-close-acceptance.yml"
DEFAULT_GRACE_MINUTES = 5


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _github_json(
    *,
    repo: str,
    token: str,
    endpoint: str,
    params: dict[str, str] | None = None,
    method: str = "GET",
    body: dict[str, Any] | None = None,
) -> dict[str, Any]:
    query = f"?{urllib.parse.urlencode(params)}" if params else ""
    request = urllib.request.Request(
        f"https://api.github.com/repos/{repo}{endpoint}{query}",
        method=method,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "Content-Type": "application/json",
        },
        data=json.dumps(body).encode("utf-8") if body is not None else None,
    )
    with urllib.request.urlopen(request, timeout=20) as response:
        payload = response.read().decode("utf-8", errors="replace")
        if not payload:
            return {}
        value = json.loads(payload)
        if not isinstance(value, dict):
            raise ValueError("GitHub API response must be an object")
        return value


def _event() -> dict[str, Any]:
    event_path = os.environ.get("GITHUB_EVENT_PATH")
    if not event_path:
        return {}
    path = Path(event_path)
    return _load(path) if path.is_file() else {}


def _current() -> dict[str, Any]:
    return _load(ROOT / "P1-CURRENT.json")


def _pending_close(current: dict[str, Any]) -> bool:
    stage = current.get("current_stage", {})
    return (
        stage.get("id") == "M32-CLOSE"
        and stage.get("status")
        in {"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE", "READY_FOR_CLOSE_ACCEPTANCE"}
        and current.get("latest_runtime_observation", {}).get("classification")
        in {"CLOSE_ACCEPTANCE_REQUESTED", "NOT_DISPATCHED", "INCOMPLETE"}
    )


def _list_runs(repo: str, token: str, *, since: str | None = None) -> list[dict[str, Any]]:
    params = {"per_page": "20"}
    if since:
        params["created"] = f">={since}"
    payload = _github_json(
        repo=repo,
        token=token,
        endpoint=f"/actions/workflows/{urllib.parse.quote(WORKFLOW_FILE, safe='')}/runs",
        params=params,
    )
    runs = payload.get("workflow_runs", [])
    return runs if isinstance(runs, list) else []


def _fetch_jobs(repo: str, token: str, run_id: int) -> dict[str, Any]:
    return _github_json(
        repo=repo,
        token=token,
        endpoint=f"/actions/runs/{run_id}/jobs",
        params={"per_page": "100"},
    )


def _diagnose(run: dict[str, Any], jobs: dict[str, Any]) -> dict[str, Any]:
    import sys

    sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
    from actions_execution_diagnostic import build

    return build(run, jobs)


def _dispatch(
    diagnostic: dict[str, Any],
    *,
    repo: str,
    token: str,
    workflow_ref: str,
    output_dir: Path,
    attempt_index: int,
) -> dict[str, Any]:
    import sys

    sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
    from actions_execution_recovery_dispatch import dispatch

    output_dir.mkdir(parents=True, exist_ok=True)
    return dispatch(
        diagnostic,
        mode="EXECUTE",
        repo=repo,
        token=token,
        run_id=(
            int(str(diagnostic["diagnostic_id"]).split(":", 1)[1])
            if str(diagnostic["diagnostic_id"]).split(":", 1)[-1].isdigit()
            else None
        ),
        output=output_dir / "local-diagnostic.json",
        acceptance_output=output_dir / "local-acceptance.json",
        local_head_sha=None,
        workflow_file=WORKFLOW_FILE,
        workflow_ref=workflow_ref,
        attempt_index=attempt_index,
        max_external_retries=1,
    )


def build_observation(
    *,
    current: dict[str, Any],
    diagnostic: dict[str, Any],
    recovery: dict[str, Any],
) -> dict[str, Any]:
    return {
        "schema_version": "1.0",
        "source": "actions_execution_orchestrator",
        "workflow": WORKFLOW_NAME,
        "current_stage": current.get("current_stage", {}).get("id"),
        "current_stage_status": current.get("current_stage", {}).get("status"),
        "run_id": diagnostic.get("diagnostic_id", "").split(":", 1)[-1],
        "head_sha": diagnostic.get("head_sha"),
        "classification": diagnostic.get("classification"),
        "step_execution_observed": diagnostic.get("evidence", {}).get("step_execution_observed", False),
        "runner_assigned": diagnostic.get("evidence", {}).get("runner_assigned", False),
        "logs_available": diagnostic.get("evidence", {}).get("logs_available", False),
        "recovery_decision": recovery.get("decision"),
        "recovery_status": recovery.get("status"),
        "recovery_action": recovery.get("action"),
    }


def retry_attempt_index(
    runs: list[dict[str, Any]],
    *,
    workflow_name: str,
    workflow_ref: str,
    head_sha: str | None,
) -> int:
    """Count only prior failed runs for the same workflow, branch, and code head."""
    relevant = [
        run for run in runs
        if run.get("name") == workflow_name
        and run.get("head_branch") == workflow_ref
        and (not head_sha or run.get("head_sha") == head_sha)
    ]
    relevant.sort(
        key=lambda item: str(item.get("created_at") or item.get("updated_at") or ""),
        reverse=True,
    )
    consecutive = 0
    for run in relevant:
        conclusion = run.get("conclusion")
        if conclusion in {"failure", "cancelled", "timed_out"}:
            consecutive += 1
            continue
        # A completed success/neutral/skipped run breaks the failure streak.
        if conclusion in {"success", "neutral", "skipped"} or run.get("status") == "completed":
            break
        # An in-progress run is not evidence of a consecutive failure.
        break
    # The caller's current failed run is part of this sequence; its zero-based
    # retry index is one less than the consecutive failure count.
    return max(0, consecutive - 1)


def execute(
    *,
    repo: str,
    token: str,
    workflow_ref: str,
    current: dict[str, Any],
    event: dict[str, Any],
    output_dir: Path,
    grace_minutes: int = DEFAULT_GRACE_MINUTES,
) -> dict[str, Any]:
    event_run = event.get("workflow_run", {})
    run_id = event_run.get("id")
    runs: list[dict[str, Any]] = []
    observed_at = current.get("latest_runtime_observation", {}).get("observed_at")

    if not isinstance(run_id, int) and not _pending_close(current):
        return {
            "status": "NOOP",
            "classification": "NO_ACTIVE_M32_CLOSE",
            "reason": "CURRENT_STAGE_NOT_PENDING_CLOSE_ACCEPTANCE",
            "runs_observed": 0,
        }

    if isinstance(run_id, int):
        runs = _list_runs(repo, token, since=observed_at)
        event_match = [run for run in runs if run.get("id") == run_id]
        if event_match:
            runs = [event_match[0]] + [run for run in runs if run.get("id") != run_id]
        else:
            runs = [event_run]
    elif _pending_close(current):
        since = observed_at
        if since:
            try:
                start = datetime.fromisoformat(str(since).replace("Z", "+00:00"))
                if datetime.now(timezone.utc) - start < timedelta(minutes=grace_minutes):
                    return {
                        "status": "WAIT",
                        "classification": "INCOMPLETE",
                        "reason": "CLOSE_ACCEPTANCE_GRACE_PERIOD",
                        "runs_observed": 0,
                    }
            except ValueError:
                since = None

        runs = _list_runs(repo, token, since=since)
        runs = [
            run for run in runs
            if run.get("name") == WORKFLOW_NAME
            and run.get("head_branch") == workflow_ref
        ]

    if not runs:
        diagnostic = {
            "diagnostic_id": "ACTIONS_DIAGNOSTIC:NOT_DISPATCHED",
            "run_status": "completed",
            "run_conclusion": "not_dispatched",
            "head_sha": current.get("latest_runtime_observation", {}).get("head_sha")
            or current.get("current_stage", {}).get("merged_commit_sha"),
            "classification": "NOT_DISPATCHED",
            "job_count": 0,
            "jobs": [],
            "evidence": {
                "runner_assigned": False,
                "step_execution_observed": False,
                "logs_available": False,
            },
        }
    else:
        run = runs[0]
        jobs = _fetch_jobs(repo, token, int(run["id"]))
        diagnostic = _diagnose(run, jobs)

    (output_dir / "diagnostic.json").write_text(
        json.dumps(diagnostic, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    from debug_escalation_policy import decide as decide_escalation
    escalation = decide_escalation(
        current=current,
        runs=runs,
        diagnostic=diagnostic,
    )
    (output_dir / "debug-escalation.json").write_text(
        json.dumps(escalation, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    if escalation["level"] == 2:
        repair_request = {
            "mode": "MINIMAL_ESCALATION",
            "trigger": "SECOND_CONSECUTIVE_FAILURE",
            "failure_level": 2,
            "failure_signature": {
                "head_sha": diagnostic.get("head_sha"),
                "classification": diagnostic.get("classification"),
                "reason_code": diagnostic.get("reason_code") or diagnostic.get("run_conclusion"),
            },
            "required_actions": [
                "STOP_AUTOMATIC_RETRY",
                "ADD_ONE_MINIMAL_CAPABILITY_ONLY",
                "REBUILD_FROM_CURRENT_CANONICAL_PATH",
                "REPLAY_FROM_OBSERVED_EVIDENCE_ONLY",
            ],
            "completion_condition": "NEW_HEAD_SHA_WITH_REPAIRED_IMPLEMENTATION",
        }
        (output_dir / "minimal-escalation-required.json").write_text(
            json.dumps(repair_request, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            "status": "MINIMAL_ESCALATION_REQUIRED",
            "diagnostic": diagnostic,
            "escalation": escalation,
            "recovery": {
                "decision": "BLOCK",
                "status": "BLOCKED",
                "action": "MINIMAL_ESCALATION_REQUIRED",
            },
            "observation": build_observation(
                current=current,
                diagnostic=diagnostic,
                recovery={
                    "decision": "BLOCK",
                    "status": "BLOCKED",
                    "action": "MINIMAL_ESCALATION_REQUIRED",
                },
            ),
        }

    if escalation["level"] >= 3:
        research_request = {
            "mode": "DEEP_RESEARCH",
            "trigger": "THIRD_OR_LATER_CONSECUTIVE_FAILURE",
            "failure_level": escalation["level"],
            "failure_signature": {
                "head_sha": diagnostic.get("head_sha"),
                "classification": diagnostic.get("classification"),
                "reason_code": diagnostic.get("reason_code") or diagnostic.get("run_conclusion"),
            },
            "required_actions": [
                "STOP_AUTOMATIC_REPAIR",
                "COMPARE_EXTERNAL_REFERENCE_SOLUTIONS",
                "IDENTIFY_ROOT_CAUSE",
                "PROPOSE_MINIMAL_REPAIR",
                "REPLAY_FROM_OBSERVED_EVIDENCE_ONLY",
            ],
            "reference_sources": [
                "https://docs.github.com/en/actions/reference/workflows-and-actions/events-that-trigger-workflows",
                "https://docs.github.com/en/rest/actions/workflows",
                "https://kubernetes.io/docs/concepts/architecture/controller/",
                "https://github.com/weskerllc/cronicorn/blob/e9bd7d926e8f4a250dbdcf9ae8af6e33b8183a87/docs/public/automated-error-recovery.md",
                "https://hookdeck.com/blog/webhooks-at-scale.md",
            ],
        }
        (output_dir / "deep-research-required.json").write_text(
            json.dumps(research_request, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return {
            "status": "RESEARCH_REQUIRED",
            "diagnostic": diagnostic,
            "escalation": escalation,
            "recovery": {
                "decision": "BLOCK",
                "status": "BLOCKED",
                "action": "DEEP_RESEARCH_REQUIRED",
            },
            "observation": build_observation(
                current=current,
                diagnostic=diagnostic,
                recovery={
                    "decision": "BLOCK",
                    "status": "BLOCKED",
                    "action": "DEEP_RESEARCH_REQUIRED",
                },
            ),
        }

    attempt_index = retry_attempt_index(
        runs,
        workflow_name=WORKFLOW_NAME,
        workflow_ref=workflow_ref,
        head_sha=diagnostic.get("head_sha"),
    )

    recovery = _dispatch(
        diagnostic,
        repo=repo,
        token=token,
        workflow_ref=workflow_ref,
        output_dir=output_dir,
        attempt_index=attempt_index,
    )
    observation = build_observation(
        current=current,
        diagnostic=diagnostic,
        recovery=recovery,
    )
    (output_dir / "observation.json").write_text(
        json.dumps(observation, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    status = "RECOVERY_TRIGGERED" if recovery["status"] in {"EXECUTED", "NOOP"} else "RECOVERY_BLOCKED"
    return {
        "status": status,
        "diagnostic": diagnostic,
        "recovery": recovery,
        "observation": observation,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Actions execution observer/recovery orchestrator")
    parser.add_argument("--output-dir", default="/tmp/p1-actions-recovery")
    parser.add_argument("--grace-minutes", type=int, default=DEFAULT_GRACE_MINUTES)
    args = parser.parse_args()

    repo = os.environ.get("GITHUB_REPOSITORY")
    token = os.environ.get("GITHUB_TOKEN")
    workflow_ref = os.environ.get("GITHUB_DEFAULT_BRANCH", "main")
    if not repo or not token:
        raise SystemExit("GITHUB_REPOSITORY_AND_TOKEN_REQUIRED")

    result = execute(
        repo=repo,
        token=token,
        workflow_ref=workflow_ref,
        current=_current(),
        event=_event(),
        output_dir=Path(args.output_dir),
        grace_minutes=args.grace_minutes,
    )
    rendered = json.dumps(result, ensure_ascii=False, indent=2)
    print(rendered)
    if result["status"] == "MINIMAL_ESCALATION_REQUIRED":
        print("::error::P1 minimal capability escalation required after second failure", flush=True)
    elif result["status"] == "RESEARCH_REQUIRED":
        print("::error::P1 deep research required after repeated failure", flush=True)
    elif result["status"] == "RECOVERY_BLOCKED":
        print(
            "::error::P1 Actions recovery blocked: "
            + str(result.get("diagnostic", {}).get("classification"))
            + " / "
            + str(result.get("recovery", {}).get("reason_code")),
            flush=True,
        )
    return 0 if result["status"] in {"WAIT", "RECOVERY_TRIGGERED"} else 3


if __name__ == "__main__":
    raise SystemExit(main())
