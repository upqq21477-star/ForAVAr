#!/usr/bin/env python3
"""Deterministic Architecture Fit decision from reconstructed system facts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
REQUEST_SCHEMA = ROOT / "P1-Central-Control/schemas/architecture_fit_request.schema.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/architecture_fit_result.schema.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any], schema_path: Path) -> None:
    schema = _load(schema_path)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(value),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def execute(request: dict[str, Any]) -> dict[str, Any]:
    _validate(request, REQUEST_SCHEMA)
    state = request["system_state"]
    classification = state["classification"]
    required = set(request.get("required_capabilities", []))
    owned = set(state.get("owned_capabilities", []))
    missing = sorted(required - owned)
    boundary_conflict = bool(state.get("boundary_conflict", False))
    split_required = bool(state.get("split_required", False))
    supports_extension = bool(state.get("supports_extension", False))
    merge_candidates = request.get("merge_candidate_system_ids", [])
    allow_new = bool(request.get("allow_new_system", False))

    observed = [
        f"system.classification={classification}",
        f"required_capabilities={len(required)}",
        f"owned_capabilities={len(owned)}",
        f"missing_capabilities={len(missing)}",
        f"boundary_conflict={boundary_conflict}",
        f"split_required={split_required}",
        f"supports_extension={supports_extension}",
    ]
    confirmed = []
    inferred = []
    unknown = []
    conflict = []
    reasons = []

    if classification in {"BLOCKED", "UNKNOWN"}:
        decision = "DEFER"
        reasons.append("SYSTEM_STATE_NOT_SUFFICIENT")
        unknown.append("architecture_fit_requires_more_reconstruction_evidence")
    elif split_required:
        decision = "SPLIT"
        reasons.append("BOUNDARY_SPLIT_REQUIRED")
        inferred.append("split_required_was_explicit_input")
    elif merge_candidates:
        decision = "MERGE"
        reasons.append("MERGE_CANDIDATES_EXPLICIT")
        confirmed.append("merge_candidates_present")
    elif boundary_conflict:
        decision = "INTERFACE_ONLY"
        reasons.append("BOUNDARY_CONFLICT")
        confirmed.append("boundary_conflict_is_explicit")
    elif classification == "BROKEN":
        decision = "REFACTOR"
        reasons.append("CURRENT_IMPLEMENTATION_BROKEN")
        confirmed.append("syntax_or_runtime_break_detected_during_reconstruction")
    elif not missing and classification == "IMPLEMENTED":
        decision = "REUSE"
        reasons.append("CAPABILITY_COVERAGE_COMPLETE")
        confirmed.append("required_capabilities_are_covered")
    elif missing and supports_extension:
        decision = "EXTEND"
        reasons.append("MISSING_CAPABILITIES_CAN_BE_ADDED_WITHIN_BOUNDARY")
        confirmed.append("extension_support_is_explicit")
    elif allow_new:
        decision = "NEW_SYSTEM"
        reasons.append("NO_EXISTING_FIT_AND_NEW_SYSTEM_ALLOWED")
        inferred.append("new_system_is_selected_by_explicit_policy")
    else:
        decision = "DEFER"
        reasons.append("NO_SAFE_FIT_DECISION")
        unknown.append("no permitted action satisfies current evidence")

    if classification in {"PARTIAL", "STUB"}:
        inferred.append(f"existing_system_state={classification}")
    if request.get("constraints"):
        observed.append(f"constraints={len(request['constraints'])}")

    result = {
        "schema_version": "1.0",
        "request_id": request["request_id"],
        "status": "PASS",
        "decision": decision,
        "reason_codes": sorted(set(reasons)),
        "target_system_id": state.get("system_id"),
        "missing_capabilities": missing,
        "evidence": {
            "observed": sorted(set(observed)),
            "confirmed": sorted(set(confirmed)),
            "inferred": sorted(set(inferred)),
            "unknown": sorted(set(unknown)),
            "conflict": sorted(set(conflict)),
        },
    }
    _validate(result, RESULT_SCHEMA)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run deterministic architecture-fit decision")
    parser.add_argument("request")
    args = parser.parse_args()
    result = execute(_load(Path(args.request).resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
