from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
REGISTRY = ROOT / "P1-Central-Control/control_gate_registry.json"

from control_gate_report import write as _write_report


def write_report(output: Any, base_sha: Any, head_sha: Any, status: str, stages: list[dict[str, Any]]) -> Any:
    """U-ISSUE：gate 失敗時登錄 signature（TRANSIENT；是否為機制由 CONTROL_RESEARCH 判斷）。登錄失敗不遮蓋 gate 結果。"""
    if status == "FAIL":
        try:
            import lifecycle_sweep

            for stage in stages:
                if stage["status"] == "FAIL":
                    lifecycle_sweep.record_failure(
                        ROOT, f"gate:{stage['stage_id']}:{stage.get('reason_code') or 'FAIL'}",
                        f"control gate stage {stage['stage_id']} FAIL",
                        "待 CONTROL_RESEARCH 依證據判斷：暫時或機制（classify_issue）")
        except Exception:  # noqa: BLE001  best-effort record; the gate result must not change
            pass
    return _write_report(output, base_sha, head_sha, status, stages)


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def run(command: list[str], *, cwd: Path = ROOT) -> int:
    completed = subprocess.run(
        command,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    return completed.returncode


def git_sha(ref: str) -> str:
    completed = subprocess.run(
        ["git", "rev-parse", ref],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError("無法取得 git SHA")
    return completed.stdout.strip()


def default_base_sha(head_sha: str) -> str:
    completed = subprocess.run(
        ["git", "rev-list", "--max-parents=1", head_sha],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise RuntimeError("無法取得預設 base SHA")
    values = [line.strip() for line in completed.stdout.splitlines() if line.strip()]
    if not values:
        raise RuntimeError("找不到預設 base SHA")
    return values[-1]


def run_research_memory_box_close_gate() -> tuple[str, str]:
    """Run the real Research Memory Box create -> evidence -> alternative -> close path."""
    from research_memory_box import add_alternative, add_external, close_box, create_box
    from research_memory_box_provenance import validate as validate_provenance

    fixture = ROOT / "P1-Central-Control/fixtures/m20-p5-research-box-close-gate.json"
    scenario = load_json(fixture)

    box = create_box(scenario["baseline"], ttl_minutes=60)
    for evidence in scenario["external_evidence"]:
        box = add_external(box, evidence)
    for alternative in scenario["alternatives"]:
        box = add_alternative(box, alternative)

    decision = dict(scenario["decision"])
    preclose = dict(box)
    preclose["decision"] = decision
    provenance = validate_provenance(preclose)
    if provenance["status"] != "PASS":
        raise RuntimeError(
            "Research Memory Box provenance pre-close gate failed: "
            + json.dumps(provenance["errors"], ensure_ascii=False)
        )

    closed = close_box(box, decision)
    if closed.get("status") != "CLOSED":
        raise RuntimeError("Research Memory Box close path did not produce CLOSED state")
    return closed["box_id"], closed["decision"]["decision_id"]


def classify_return(code: int, accepted_codes: set[int]) -> str:
    return "PASS" if code in accepted_codes else "FAIL"


def report_status(stages: list[dict[str, Any]]) -> str:
    if any(stage["status"] == "FAIL" for stage in stages):
        return "FAIL"
    if any(stage["status"] == "INCOMPLETE" for stage in stages):
        return "INCOMPLETE"
    return "PASS"


def classify_semantic_impact(code: int, status: str) -> str:
    if code == 0 and status == "PASS":
        return "PASS"
    if status == "BLOCK":
        return "INCOMPLETE"
    return "FAIL"


def classify_repository_independence(status: str) -> str:
    if status == "INDEPENDENT":
        return "PASS"
    if status == "UNKNOWN":
        return "INCOMPLETE"
    return "FAIL"



def execute(
    *,
    base_sha: str,
    head_sha: str,
    output: str,
    external_result: str | None = None,
    skip_unit_tests: bool = False,
) -> int:
    registry = load_json(REGISTRY)
    stages: list[dict[str, Any]] = []

    try:
        box_id, decision_id = run_research_memory_box_close_gate()
        stages.append({
            "stage_id": "RESEARCH_MEMORY_BOX_CLOSE_PROVENANCE",
            "status": "PASS",
            "object_ref": f"{box_id}:{decision_id}",
            "reason_code": None,
        })
    except Exception as exc:
        stages.append({
            "stage_id": "RESEARCH_MEMORY_BOX_CLOSE_PROVENANCE",
            "status": "FAIL",
            "object_ref": None,
            "reason_code": f"RESEARCH_MEMORY_BOX_CLOSE_PROVENANCE_FAILED:{exc}",
        })
        return write_report(output, base_sha, head_sha, "FAIL", stages)

    current_path = ROOT / "P1-CURRENT.json"
    current = load_json(current_path)
    reconciliation_config = current["implementation_control"]["current_truth_reconciliation"]
    runtime_observation = current.get("latest_runtime_observation") or current.get("current_stage", {}).get("latest_runtime_observation") or {}
    truth_record_ref = runtime_observation.get("truth_record")
    fixture_ref = runtime_observation.get("fixture_ref")
    reconciliation_output = Path(output).with_name("current-truth-reconciliation.json")
    if not truth_record_ref or not fixture_ref:
        stages.append({
            "stage_id": "CURRENT_TRUTH_RECONCILIATION",
            "status": "INCOMPLETE",
            "object_ref": None,
            "reason_code": "CURRENT_TRUTH_INPUT_REFERENCES_MISSING",
        })
        return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)

    reconciliation_command = [
        sys.executable,
        reconciliation_config["script"],
        "--current",
        "P1-CURRENT.json",
        "--work-packet",
        current["implementation_control"]["active_work_packet"],
        "--truth-record",
        truth_record_ref,
        "--runtime-fixture",
        fixture_ref,
        "--output",
        str(reconciliation_output),
    ]
    reconciliation_code = run(reconciliation_command)
    if not reconciliation_output.is_file():
        stages.append({
            "stage_id": "CURRENT_TRUTH_RECONCILIATION",
            "status": "INCOMPLETE",
            "object_ref": None,
            "reason_code": "CURRENT_TRUTH_RECONCILIATION_OUTPUT_MISSING",
        })
        report_status_value = "FAIL" if reconciliation_code not in {0, 2, 3} else "INCOMPLETE"
        return write_report(output, base_sha, head_sha, report_status_value, stages)
    try:
        reconciliation_value = load_json(reconciliation_output)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        stages.append({
            "stage_id": "CURRENT_TRUTH_RECONCILIATION",
            "status": "INCOMPLETE",
            "object_ref": None,
            "reason_code": f"CURRENT_TRUTH_RECONCILIATION_OUTPUT_INVALID:{type(exc).__name__}",
        })
        return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
    reconciliation_status = reconciliation_value["status"]
    stages.append({
        "stage_id": "CURRENT_TRUTH_RECONCILIATION",
        "status": (
            "FAIL" if reconciliation_status == "RECONCILIATION_REQUIRED"
            else "INCOMPLETE" if reconciliation_status == "INCOMPLETE"
            else "PASS"
        ),
        "object_ref": reconciliation_value["reconciliation_id"],
        "reason_code": (
            "CURRENT_TRUTH_RECONCILIATION_REQUIRED"
            if reconciliation_status == "RECONCILIATION_REQUIRED"
            else None
            if reconciliation_status == "PASS"
            else "CURRENT_TRUTH_INCOMPLETE"
        ),
    })
    if reconciliation_code == 2:
        return write_report(output, base_sha, head_sha, "FAIL", stages)
    if reconciliation_code == 3:
        write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
        return 2

    if not skip_unit_tests:
        code = run([sys.executable, "-m", "unittest", "-v", *registry["tests"]])
        unit_status = classify_return(code, {0})
        stages.append({
            "stage_id": "UNIT_TEST",
            "status": unit_status,
            "object_ref": None,
            "reason_code": None if code == 0 else "UNIT_TEST_FAILED",
        })
        if unit_status == "FAIL":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

    with tempfile.TemporaryDirectory(prefix="p1-control-gate-") as temp:
        temp_dir = Path(temp)
        admission_output = temp_dir / "task-admission-result.json"
        admission_proc = subprocess.run(
            [
                sys.executable,
                "P1-Central-Control/scripts/task_admission_gate.py",
                "--request",
                current["implementation_control"]["canonical_task_admission"]["request"],
                "--current",
                "P1-CURRENT.json",
                "--base",
                base_sha,
                "--head",
                head_sha,
                "--output",
                str(admission_output),
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        admission_value = load_json(admission_output) if admission_output.is_file() else {}
        admission_status = admission_value.get("status")
        admission_class = (
            "PASS" if admission_proc.returncode == 0 and admission_status == "PASS"
            else "INCOMPLETE" if admission_proc.returncode == 2
            else "FAIL"
        )
        stages.append({
            "stage_id": "TASK_ADMISSION",
            "status": admission_class,
            "object_ref": admission_value.get("request_id"),
            "reason_code": (
                None if admission_class == "PASS"
                else "TASK_ADMISSION_INCOMPLETE" if admission_class == "INCOMPLETE"
                else (admission_value.get("reason_codes") or ["TASK_ADMISSION_FAILED"])[0]
            ),
        })
        if admission_class == "INCOMPLETE":
            return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
        if admission_class != "PASS":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        m1 = temp_dir / "m1-impact.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/change_impact_scan.py",
            "--base", base_sha, "--head", head_sha, "--output", str(m1),
        ])
        stages.append({
            "stage_id": "IMPACT_SCAN",
            "status": classify_return(code, {0}),
            "object_ref": None,
            "reason_code": None if code == 0 else "IMPACT_SCAN_FAILED",
        })
        if code != 0:
            return write_report(output, base_sha, head_sha, report_status(stages), stages)

        scope = temp_dir / "change-scope.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/change_scope_gate.py",
            "--base", base_sha, "--head", head_sha,
            "--impact", str(m1), "--output", str(scope),
        ])
        if code != 0:
            stages.append({
                "stage_id": "CHANGE_SCOPE",
                "status": "FAIL",
                "object_ref": None,
                "reason_code": "CHANGE_SCOPE_REJECTED",
            })
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        scope_value = load_json(scope)
        stages.append({
            "stage_id": "CHANGE_SCOPE",
            "status": "PASS",
            "object_ref": scope_value.get("change_scope_id"),
            "reason_code": None,
        })

        semantic_impact = temp_dir / "change-impact-v2.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/change_impact_v2.py",
            "--base", base_sha, "--head", head_sha, "--output", str(semantic_impact),
        ])
        semantic_value = load_json(semantic_impact)
        semantic_status = semantic_value.get("impact_scan", {}).get("status")
        stages.append({
            "stage_id": "CHANGE_IMPACT_V2",
            "status": classify_semantic_impact(code, semantic_status),
            "object_ref": semantic_value.get("impact_scan", {}).get("scan_id"),
            "reason_code": (
                None if code == 0 and semantic_status == "PASS"
                else "SEMANTIC_IMPACT_UNRESOLVED" if semantic_status == "BLOCK"
                else "CHANGE_IMPACT_V2_FAILED"
            ),
        })
        if semantic_status == "BLOCK":
            return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
        if code != 0:
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        independence = run([
            sys.executable, "P1-Central-Control/scripts/system_independence_gate.py",
            "P1-Central-Control/system_registry.json",
        ])
        stages.append({
            "stage_id": "SYSTEM_INDEPENDENCE",
            "status": classify_return(independence, {0}),
            "object_ref": None,
            "reason_code": None if independence == 0 else "SYSTEM_INDEPENDENCE_FAILED",
        })
        if independence != 0:
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        repository_independence = temp_dir / "system-independence-repository.json"
        # Capture the structured decision once; repository gate emits JSON on stdout.
        proc = subprocess.run(
            [
                sys.executable,
                "P1-Central-Control/scripts/system_independence_repository_gate.py",
                "--registry", "P1-Central-Control/system_registry.json",
                "--root", ".",
            ],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=False,
        )
        repository_value = None
        try:
            repository_value = json.loads(proc.stdout)
            repository_independence.write_text(
                json.dumps(repository_value, ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )
        except json.JSONDecodeError:
            repository_value = {"status": "UNKNOWN", "reason_codes": ["INVALID_GATE_OUTPUT"]}

        repository_status = repository_value.get("status")
        stages.append({
            "stage_id": "SYSTEM_INDEPENDENCE_REPOSITORY",
            "status": classify_repository_independence(repository_status),
            "object_ref": None,
            "reason_code": (
                None if repository_status == "INDEPENDENT"
                else "BOUNDARY_UNRESOLVED" if repository_status == "UNKNOWN"
                else "SYSTEM_INDEPENDENCE_REPOSITORY_VIOLATION"
            ),
        })
        if repository_status == "UNKNOWN":
            return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
        if repository_status != "INDEPENDENT":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        external_evidence = temp_dir / "external-architecture-evidence.json"
        external_fixture = ROOT / "P1-Central-Control/fixtures/p14-external-architecture-sample.sarif"
        code = run([
            sys.executable, "P1-Central-Control/scripts/external_architecture_evidence_adapter.py",
            "--input", str(external_fixture),
            "--source-type", "OTHER",
            "--source-uri", "fixture://p14-external-architecture-sample.sarif",
            "--source-revision", head_sha,
            "--output", str(external_evidence),
        ])
        external_value = load_json(external_evidence) if external_evidence.is_file() else {}
        external_status = (
            "PASS"
            if code == 0
            and external_value.get("truth_boundary") == "EXTERNAL_EVIDENCE_ONLY"
            and external_value.get("summary", {}).get("finding_count") == 1
            else "FAIL"
        )
        stages.append({
            "stage_id": "EXTERNAL_ARCHITECTURE_EVIDENCE_ADAPTER",
            "status": external_status,
            "object_ref": external_value.get("adapter_id"),
            "reason_code": None if external_status == "PASS" else "EXTERNAL_EVIDENCE_ADAPTER_FAILED",
        })
        if external_status != "PASS":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        dynamic_probe = temp_dir / "dynamic-boundary-runtime-probe.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/dynamic_boundary_runtime_probe.py",
            "--root", ".",
            "--output", str(dynamic_probe),
        ])
        dynamic_value = load_json(dynamic_probe) if dynamic_probe.is_file() else {}
        dynamic_status = dynamic_value.get("status")
        stages.append({
            "stage_id": "DYNAMIC_BOUNDARY_RUNTIME_PROBE",
            "status": (
                "PASS" if code == 0 and dynamic_status == "PASS"
                else "INCOMPLETE" if dynamic_status == "INCOMPLETE" or code == 2
                else "FAIL"
            ),
            "object_ref": dynamic_value.get("probe_run_id"),
            "reason_code": (
                None if dynamic_status == "PASS" and code == 0
                else "DYNAMIC_BOUNDARY_RUNTIME_INCOMPLETE"
                if dynamic_status == "INCOMPLETE" or code == 2
                else "DYNAMIC_BOUNDARY_RUNTIME_FAILED"
            ),
        })
        if dynamic_status == "INCOMPLETE" or code == 2:
            return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
        if dynamic_status != "PASS" or code != 0:
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        local_p14_d = temp_dir / "local-p14-d-runtime.json"
        code = run([
            sys.executable,
            "P1-Central-Control/scripts/local_p14_d_runtime_acceptance.py",
            "--output",
            str(local_p14_d),
        ])
        local_p14_value = load_json(local_p14_d) if local_p14_d.is_file() else {}
        local_p14_status = local_p14_value.get("status")
        stages.append({
            "stage_id": "P14_D_LOCAL_RUNTIME_ACCEPTANCE",
            "status": (
                "PASS" if code == 0 and local_p14_status == "PASS"
                else "INCOMPLETE" if local_p14_status == "INCOMPLETE" or code == 2
                else "FAIL"
            ),
            "object_ref": local_p14_value.get("evidence_id"),
            "reason_code": (
                None if code == 0 and local_p14_status == "PASS"
                else "P14_D_LOCAL_RUNTIME_INCOMPLETE"
                if local_p14_status == "INCOMPLETE" or code == 2
                else "P14_D_LOCAL_RUNTIME_FAILED"
            ),
        })
        if local_p14_status == "INCOMPLETE" or code == 2:
            return write_report(output, base_sha, head_sha, "INCOMPLETE", stages)
        if local_p14_status != "PASS" or code != 0:
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        sweep_out = temp_dir / "lifecycle-sweep.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/lifecycle_sweep.py",
            ".", "--output", str(sweep_out),
        ])
        sweep_value = load_json(sweep_out) if sweep_out.is_file() else {}
        stages.append({
            "stage_id": "LIFECYCLE_SWEEP",
            "status": "PASS" if code == 0 and sweep_value.get("status") == "PASS" else "FAIL",
            "object_ref": None,
            "reason_code": (
                "CANDIDATES_RECORDED" if code == 0 and sweep_value.get("candidates")
                else None if code == 0
                else (sweep_value.get("reason_codes") or ["LIFECYCLE_SWEEP_FAILED"])[0]
            ),
        })
        if code != 0:
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        m2 = temp_dir / "m2-reevaluation.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/capability_reevaluation.py",
            str(m1), str(m2),
            "--measurements",
            "P1-Central-Control/fixtures/m2-capability-reevaluation-measurements.json",
        ])
        if code not in {0, 3}:
            stages.append({"stage_id":"CAPABILITY_REEVALUATION","status":"FAIL","object_ref":None,"reason_code":"M2_EXECUTION_FAILED"})
            return write_report(output, base_sha, head_sha, "FAIL", stages)
        m2_value = load_json(m2)
        m2_status = m2_value.get("status")
        stages.append({
            "stage_id": "CAPABILITY_REEVALUATION",
            "status": "FAIL" if m2_status == "BLOCK" else "INCOMPLETE" if m2_status == "INSUFFICIENT_DATA" else "PASS",
            "object_ref": m2_value.get("object_id"),
            "reason_code": None if m2_status == "PASS" else "M2_NOT_READY",
        })
        if m2_status == "BLOCK":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        m3 = temp_dir / "m3-routing.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/routing_reevaluation.py",
            str(m2), str(m3),
        ])
        if code != 0:
            stages.append({"stage_id":"ROUTING_REEVALUATION","status":"FAIL","object_ref":None,"reason_code":"M3_EXECUTION_FAILED"})
            return write_report(output, base_sha, head_sha, "FAIL", stages)
        m3_value = load_json(m3)
        m3_status = m3_value.get("status")
        stages.append({
            "stage_id": "ROUTING_REEVALUATION",
            "status": "FAIL" if m3_status == "BLOCK" else "INCOMPLETE" if m3_status == "INSUFFICIENT_DATA" else "PASS",
            "object_ref": m3_value.get("object_id"),
            "reason_code": None if m3_status == "PASS" else "M3_NOT_READY",
        })
        if m3_status == "BLOCK":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        m4 = temp_dir / "m4-selection.json"
        code = run([
            sys.executable, "P1-Central-Control/scripts/regression_selection.py",
            str(m3), str(m1), str(m4),
        ])
        if code != 0:
            stages.append({"stage_id":"REGRESSION_SELECTION","status":"FAIL","object_ref":None,"reason_code":"M4_EXECUTION_FAILED"})
            return write_report(output, base_sha, head_sha, "FAIL", stages)
        m4_value = load_json(m4)
        m4_status = m4_value.get("status")
        stages.append({
            "stage_id": "REGRESSION_SELECTION",
            "status": "FAIL" if m4_status == "BLOCK" else "INCOMPLETE" if m4_status == "INSUFFICIENT_DATA" else "PASS",
            "object_ref": m4_value.get("object_id"),
            "reason_code": None if m4_status == "PASS" else "M4_NOT_READY",
        })
        if m4_status == "BLOCK":
            return write_report(output, base_sha, head_sha, "FAIL", stages)

        m7 = temp_dir / "m7-regression-result.json"
        command = [
            sys.executable, "P1-Central-Control/scripts/regression_executor.py",
            str(m4), str(m7),
        ]
        if external_result:
            command.extend(["--external-result", external_result])
        code = run(command)
        if code not in {0, 2}:
            stages.append({"stage_id":"REGRESSION_EXECUTION","status":"FAIL","object_ref":None,"reason_code":"M7_EXECUTION_FAILED"})
            return write_report(output, base_sha, head_sha, "FAIL", stages)
        m7_value = load_json(m7)
        m7_status = m7_value.get("status")
        stages.append({
            "stage_id": "REGRESSION_EXECUTION",
            "status": "INCOMPLETE" if m7_status == "INCOMPLETE" else "FAIL" if m7_status == "FAIL" else "PASS",
            "object_ref": m7_value.get("result_id"),
            "reason_code": None if m7_status == "PASS" else "M7_NOT_COMPLETE",
        })

    return write_report(output, base_sha, head_sha, report_status(stages), stages)
