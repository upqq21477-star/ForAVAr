#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "native_replacement_eval.schema.json"
STATE_SCHEMA_PATH = SCHEMA_DIR / "native_replacement_eval_state.schema.json"
COMMAND_SCHEMA_PATH = SCHEMA_DIR / "native_replacement_eval_command.schema.json"
POLICY_PATH = ROOT / "P1-Central-Control" / "native_replacement_policy.json"


def load_policy(path: Path = POLICY_PATH) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def _identity(kind: str, object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    value = deepcopy(value)
    value["object_id"] = f"{kind}:{str(object_id).replace(':', '.')}"
    value["kind"] = kind
    value["schema_version"] = "1.0"
    value["content_hash"] = ""
    value["content_hash"] = content_hash(value)
    return value


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "native_replacement_eval.schema.json",
        "native_replacement_eval_state.schema.json",
        "native_replacement_eval_command.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"], Resource.from_contents(schema)
        )
    return registry


def _validate(path: Path, value: dict[str, Any]) -> None:
    schema = json.loads(path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(
        schema,
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(validator.iter_errors(value), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            f"{path.name} 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def validate_eval(record: dict[str, Any]) -> None:
    _validate(SCHEMA_PATH, record)
    if record.get("content_hash") != content_hash(record):
        raise ValueError("Native Replacement Eval content_hash 不正確")


def validate_eval_state(state: dict[str, Any]) -> None:
    _validate(STATE_SCHEMA_PATH, state)


def validate_eval_command(command: dict[str, Any]) -> None:
    _validate(COMMAND_SCHEMA_PATH, command)


def initial_state(evaluation_id: str) -> dict[str, Any]:
    state = {
        "evaluation_id": evaluation_id,
        "state_revision": 0,
        "status": "DRAFT",
        "last_command_id": None,
        "last_idempotency_key": None,
    }
    validate_eval_state(state)
    return state


def build_command(
    state: dict[str, Any],
    command_type: str,
    *,
    command_id: str,
    idempotency_key: str,
    issued_at: str | None = None,
) -> dict[str, Any]:
    command = {
        "command_id": command_id,
        "evaluation_id": state["evaluation_id"],
        "command_type": command_type,
        "expected_state_revision": state["state_revision"],
        "idempotency_key": idempotency_key,
        "issued_at": issued_at or datetime.now(timezone.utc).isoformat(),
    }
    validate_eval_command(command)
    return command


def apply_command(
    state: dict[str, Any],
    command: dict[str, Any],
    *,
    evaluation: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], str]:
    validate_eval_state(state)
    validate_eval_command(command)

    if command["evaluation_id"] != state["evaluation_id"]:
        raise ValueError("Evaluation command evaluation_id 不一致")

    if command["idempotency_key"] == state.get("last_idempotency_key"):
        return deepcopy(state), "IDEMPOTENT_REPLAY"

    if command["expected_state_revision"] != state["state_revision"]:
        raise ValueError("Evaluation state revision conflict")

    next_state = deepcopy(state)
    command_type = command["command_type"]

    if command_type == "START_EVALUATION":
        if state["status"] != "DRAFT":
            raise ValueError("只有 DRAFT evaluation 可以 START_EVALUATION")
        next_state["status"] = "RUNNING"

    elif command_type == "FINALIZE_EVALUATION":
        if state["status"] != "RUNNING":
            raise ValueError("只有 RUNNING evaluation 可以 FINALIZE_EVALUATION")
        if evaluation is None:
            raise ValueError("FINALIZE_EVALUATION 必須提供 evaluation record")
        validate_eval(evaluation)
        if evaluation["evaluation_id"] != state["evaluation_id"]:
            raise ValueError("Evaluation record 與 state 不一致")
        if evaluation["evaluation_state"] != "FINALIZED":
            raise ValueError("Evaluation record 尚未 FINALIZED")
        next_state["status"] = "FINALIZED"

    else:
        raise ValueError(f"未知 Native Replacement Eval command: {command_type}")

    next_state["state_revision"] += 1
    next_state["last_command_id"] = command["command_id"]
    next_state["last_idempotency_key"] = command["idempotency_key"]
    validate_eval_state(next_state)
    return next_state, "APPLIED"


def _rate(passed: int, total: int) -> float:
    if total <= 0:
        return 0.0
    return round(passed / total, 6)


_EVAL_BLOCK_KEYS: dict[str, tuple[str, ...]] = {
    "schema_compatibility": ("checked", "passed"),
    "behavior_compatibility": ("passed", "total", "rate"),
    "acceptance": ("passed", "total", "rate"),
    "reliability": ("successes", "total", "rate"),
    "cost": ("baseline_unit_cost", "candidate_unit_cost", "ratio"),
}


def _project(block: dict[str, Any], keys: tuple[str, ...]) -> dict[str, Any]:
    return {k: deepcopy(block[k]) for k in keys if k in block}


def evaluate(
    measurement: dict[str, Any],
    *,
    policy: dict[str, Any] | None = None,
) -> dict[str, Any]:
    policy = deepcopy(policy or load_policy())
    sample_size = int(measurement.get("sample_size", 0))
    # measurement 子區塊可帶 evidence_refs / unit / observed_case_count 等額外欄位；
    # canonical eval schema 為 unevaluatedProperties:false，故只投影 schema 允許的鍵。
    # 被投影掉的區塊級 evidence_refs 併入頂層 evidence_refs，不遺失證據來源。
    block_refs: list[str] = []
    for _name in ("schema_compatibility", "behavior_compatibility", "acceptance", "reliability"):
        block_refs.extend(measurement[_name].get("evidence_refs", []) or [])
    schema_check = _project(measurement["schema_compatibility"], _EVAL_BLOCK_KEYS["schema_compatibility"])
    # measurement 的 schema_compatibility.passed 是通過計數（int）、total 為總數；
    # eval schema 要 boolean：全數通過且 total>0 才算 passed。已是 bool 者原樣保留。
    _sc = measurement["schema_compatibility"]
    if not isinstance(_sc.get("passed"), bool):
        _total = _sc.get("total")
        schema_check["passed"] = (
            int(_sc["passed"]) == int(_total) and int(_total) > 0
            if _total is not None else int(_sc["passed"]) > 0
        )
    behavior = _project(measurement["behavior_compatibility"], _EVAL_BLOCK_KEYS["behavior_compatibility"])
    acceptance = _project(measurement["acceptance"], _EVAL_BLOCK_KEYS["acceptance"])
    reliability = _project(measurement["reliability"], _EVAL_BLOCK_KEYS["reliability"])
    cost = _project(measurement["cost"], _EVAL_BLOCK_KEYS["cost"])

    behavior["rate"] = _rate(int(behavior["passed"]), int(behavior["total"]))
    acceptance["rate"] = _rate(int(acceptance["passed"]), int(acceptance["total"]))
    reliability["rate"] = _rate(int(reliability["successes"]), int(reliability["total"]))
    baseline_cost = float(cost["baseline_unit_cost"])
    candidate_cost = float(cost["candidate_unit_cost"])
    if baseline_cost <= 0 or candidate_cost <= 0:
        raise ValueError("unit cost 必須 > 0")
    cost["ratio"] = round(candidate_cost / baseline_cost, 6)

    failed: list[str] = []
    if sample_size < int(policy["min_sample_size"]):
        failed.append("SAMPLE_SIZE_BELOW_MINIMUM")

    if policy["require_schema_compatibility"]:
        if not schema_check["checked"]:
            failed.append("SCHEMA_COMPATIBILITY_NOT_CHECKED")
        elif not schema_check["passed"]:
            failed.append("SCHEMA_COMPATIBILITY_FAILED")

    if behavior["total"] == 0:
        failed.append("BEHAVIOR_EVAL_EMPTY")
    elif behavior["rate"] < float(policy["min_behavior_rate"]):
        failed.append("BEHAVIOR_COMPATIBILITY_BELOW_THRESHOLD")

    if acceptance["total"] == 0:
        failed.append("ACCEPTANCE_EVAL_EMPTY")
    elif acceptance["rate"] < float(policy["min_acceptance_rate"]):
        failed.append("ACCEPTANCE_RATE_BELOW_THRESHOLD")

    if reliability["total"] == 0:
        failed.append("RELIABILITY_EVAL_EMPTY")
    elif reliability["rate"] < float(policy["min_reliability_rate"]):
        failed.append("RELIABILITY_BELOW_THRESHOLD")

    if int(measurement["regression_count"]) > int(policy["max_regression_count"]):
        failed.append("REGRESSION_DETECTED")

    if cost["ratio"] > float(policy["max_cost_ratio"]):
        failed.append("COST_RATIO_ABOVE_THRESHOLD")

    evidence_refs = sorted(set(measurement.get("evidence_refs", [])) | set(block_refs))
    if policy["require_evidence_refs"] and not evidence_refs:
        failed.append("EVIDENCE_REFS_MISSING")

    status = "INSUFFICIENT_DATA" if sample_size < int(policy["min_sample_size"]) else (
        "PASS" if not failed else "BLOCK"
    )

    record = _identity(
        "NATIVE_REPLACEMENT_EVAL",
        measurement["evaluation_id"],
        {
            "evaluation_id": measurement["evaluation_id"],
            "capability_id": measurement["capability_id"],
            "baseline_mode": measurement["baseline_mode"],
            "candidate_mode": measurement["candidate_mode"],
            "sample_size": sample_size,
            "schema_compatibility": schema_check,
            "behavior_compatibility": behavior,
            "acceptance": acceptance,
            "reliability": reliability,
            "cost": cost,
            "regression_count": int(measurement["regression_count"]),
            "evidence_refs": evidence_refs,
            "status": status,
            "failed_checks": sorted(set(failed)),
            "policy_id": policy["policy_id"],
            "evaluation_state": "FINALIZED",
        },
    )
    validate_eval(record)
    return record


def main() -> int:
    import argparse

    parser = argparse.ArgumentParser(description="P1 Native Replacement Eval")
    parser.add_argument("measurement")
    parser.add_argument("output")
    args = parser.parse_args()

    measurement = json.loads(
        Path(args.measurement).read_text(encoding="utf-8")
    )
    record = evaluate(measurement)
    Path(args.output).write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(record, ensure_ascii=False, indent=2))
    return 0 if record["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
