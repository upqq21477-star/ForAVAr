#!/usr/bin/env python3
"""交接檔由資料產生：docs/handoffs/handoff.data.json → Markdown（單一資料來源，不手寫 Markdown）。

資料格式：{handoff_id, date, store_key, headline, sections:[{title, blocks:[...]}]}
block 型別（恰一個鍵）：p（段落）、bullets（清單）、table（{header, rows}）、code（程式碼區塊）。
用法：handoff_render.py [data.json] [--out FILE]；無 --out 則輸出到 stdout。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = ROOT / "docs" / "handoffs" / "handoff.data.json"
MAX_CHARS = 24_000  # 交接檔字數上限：防止重新膨脹
MAX_BYTES = 12_000  # UTF-8 位元組上限：讀取預算以位元組計，中文每字 3 B，字數上限擋不住膨脹
BLOCK_KEYS = {"p", "bullets", "table", "code", "budget"}


def budget_table(root: Path = ROOT) -> dict[str, Any]:
    """Measured budget table (never hand-written numbers)."""
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from repository_hygiene_gate import BUDGET_PATH, measure, tracked_files

    budgets = json.loads((root / BUDGET_PATH).read_text(encoding="utf-8"))["budgets"]
    sizes = measure(root, tracked_files(root))
    rows = [[b["path"] or "全 repo", f"{sizes[b['path']]:,}", f"{b['max_bytes']:,}", f"{b['target_bytes']:,}"]
            for b in budgets]
    return {"header": ["路徑", "實測 B", "max", "target"], "rows": rows}


def validate(data: dict[str, Any]) -> None:
    for key in ("handoff_id", "date", "store_key", "headline", "sections"):
        if not data.get(key):
            raise ValueError(f"HANDOFF_FIELD_REQUIRED:{key}")
    for section in data["sections"]:
        if not section.get("title") or not section.get("blocks"):
            raise ValueError(f"HANDOFF_SECTION_EMPTY:{section.get('title')}")
        for block in section["blocks"]:
            if len(block) != 1 or not set(block) <= BLOCK_KEYS:
                raise ValueError(f"HANDOFF_BLOCK_INVALID:{section['title']}:{sorted(block)}")
            if "budget" in block:
                if block["budget"] is not True:
                    raise ValueError(f"HANDOFF_BLOCK_INVALID:{section['title']}:budget")
            elif "table" in block:
                table = block["table"]
                width = len(table["header"])
                if not table["rows"] or any(len(row) != width for row in table["rows"]):
                    raise ValueError(f"HANDOFF_TABLE_INVALID:{section['title']}")
            elif "bullets" in block and not block["bullets"]:
                raise ValueError(f"HANDOFF_BLOCK_EMPTY:{section['title']}")


def render(data: dict[str, Any]) -> str:
    validate(data)
    lines = [
        f"# {data['handoff_id']}｜P1 交接（{data['date']}）",
        "",
        f"STORE_KEY: {data['store_key']}",
        "",
        f"**一句話：{data['headline']}**",
    ]
    for number, section in enumerate(data["sections"], 1):
        lines += ["", f"## {number}. {section['title']}", ""]
        for block in section["blocks"]:
            if "p" in block:
                lines += [block["p"], ""]
            elif "bullets" in block:
                lines += [f"- {item}" for item in block["bullets"]] + [""]
            elif "table" in block or "budget" in block:
                table = block["table"] if "table" in block else budget_table()
                lines.append("| " + " | ".join(table["header"]) + " |")
                lines.append("|" + "---|" * len(table["header"]))
                lines += ["| " + " | ".join(row) + " |" for row in table["rows"]]
                lines.append("")
            else:
                lines += ["```bash", block["code"].rstrip("\n"), "```", ""]
    text = "\n".join(lines).rstrip("\n") + "\n"
    if len(text) > MAX_CHARS:
        raise ValueError(f"HANDOFF_TOO_LARGE:{len(text)}>{MAX_CHARS}")
    if len(text.encode("utf-8")) > MAX_BYTES:
        raise ValueError(f"HANDOFF_TOO_LARGE:{len(text.encode('utf-8'))}B>{MAX_BYTES}B")
    return text


def main() -> int:
    parser = argparse.ArgumentParser(description="Render P1 handoff from data")
    parser.add_argument("data", nargs="?", default=str(DEFAULT_DATA))
    parser.add_argument("--out")
    args = parser.parse_args()
    text = render(json.loads(Path(args.data).read_text(encoding="utf-8")))
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    else:
        sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
