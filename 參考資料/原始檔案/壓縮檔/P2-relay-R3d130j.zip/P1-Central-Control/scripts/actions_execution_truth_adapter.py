#!/usr/bin/env python3
"""Convert Actions recovery closure into the canonical Current Truth evidence record."""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
TRUTH_SCHEMA = ROOT / "P1-Central-Control/schemas/current_truth_evidence_record.schema.json"
CLOSURE_SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_closure.schema.json"
DIAGNOSTIC_SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_diagnostic.schema.json"

STATUS_BY_PROGRAM_TRUTH = {
    "PROGRAM_VERIFIED": "PASS",
    "PROGRAM_REGRESSION": "FAIL",
    "PROGRAM_UNRESOLVED": "INCOMPLETE",
    "EVIDENCE_CONFLICT": "INCOMPLETE",
    "BLOCKED": "INCOMPLETE",
}
RUN_ID_PATTERN = re.compile(r"^ACTIONS_DIAGNOSTIC:(\d+)$")

def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value

def _validate(value: dict[str, Any], schema_path: Path) -> None:
    Draft202012Validator(_load(schema_path)).validate(value)

def _run_id(diagnostic: dict[str, Any]) -> int:
    match = RUN_ID_PATTERN.match(str(diagnostic.get("diagnostic_id", "")))
    if not match:
        raise ValueError("INVALID_ACTIONS_DIAGNOSTIC_ID")
    return int(match.group(1))

def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")

def build(
    diagnostic: dict[str, Any],
    closure: dict[str, Any],
    *,
    head_sha: str,
    observed_at: str | None = None,
) -> dict[str, Any]:
    _validate(diagnostic, DIAGNOSTIC_SCHEMA)
    _validate(closure, CLOSURE_SCHEMA)

    if not isinstance(head_sha, str) or len(head_sha) < 7:
        raise ValueError("INVALID_HEAD_SHA")

    diagnostic_id = diagnostic["diagnostic_id"]
    if diagnostic_id not in closure.get("evidence_refs", []):
        raise ValueError("CLOSURE_MISSING_DIAGNOSTIC_REFERENCE")

    closure_head = closure.get("head_sha")
    if closure_head and closure_head != head_sha:
        raise ValueError("CLOSURE_HEAD_SHA_MISMATCH")

    program_truth = closure["program_truth"]
    status = STATUS_BY_PROGRAM_TRUTH[program_truth]
    evidence = diagnostic["evidence"]

    result = {
        "evidence_id": f"ACTIONS_TRUTH:{_run_id(diagnostic)}",
        "head_sha": head_sha,
        "runtime_run_id": _run_id(diagnostic),
        "classification": closure["external_classification"],
        "status": status,
        "observed_at": observed_at or now_iso(),
        "source": "actions_execution_recovery_closure",
        "step_execution_observed": bool(evidence["step_execution_observed"]),
        "step_count": sum(int(job.get("step_count", 0)) for job in diagnostic.get("jobs", [])),
        "logs_available": bool(evidence["logs_available"]),
        "closure_id": closure["closure_id"],
        "closure_status": closure["closure_status"],
        "program_truth": program_truth,
        "reason_code": closure.get("reason_code", "UNSPECIFIED"),
        "evidence_refs": list(closure["evidence_refs"]),
    }
    _validate(result, TRUTH_SCHEMA)
    return result

def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Actions closure to Current Truth adapter")
    parser.add_argument("diagnostic")
    parser.add_argument("closure")
    parser.add_argument("--head-sha", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--observed-at")
    args = parser.parse_args()
    result = build(
        _load(Path(args.diagnostic).resolve()),
        _load(Path(args.closure).resolve()),
        head_sha=args.head_sha,
        observed_at=args.observed_at,
    )
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
