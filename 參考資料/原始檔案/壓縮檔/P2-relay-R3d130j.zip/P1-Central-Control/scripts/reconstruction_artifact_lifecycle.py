#!/usr/bin/env python3
"""Deterministic lifecycle gate for reverse-reconstruction artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/reconstruction_artifact_lifecycle.schema.json"

ALLOWED = {
    "CREATE": {"ABSENT": "CREATED"},
    "USE": {"CREATED": "USED", "USED": "USED", "VERIFIED": "USED", "PROMOTED": "USED"},
    "VERIFY": {"CREATED": "VERIFIED", "USED": "VERIFIED"},
    "RETIRE": {"CREATED": "RETIRED", "USED": "RETIRED", "VERIFIED": "RETIRED"},
    "PROMOTE": {"VERIFIED": "PROMOTED"},
}


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any]) -> None:
    schema = _load(SCHEMA)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(value),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def execute(
    artifact_id: str,
    artifact_type: str,
    source_request_id: str,
    current_status: str,
    action: str,
    evidence_refs: list[str] | None = None,
) -> dict[str, Any]:
    evidence_refs = sorted(set(evidence_refs or []))
    expected = ALLOWED.get(action, {}).get(current_status)
    if expected is None:
        raise ValueError(f"ILLEGAL_ARTIFACT_TRANSITION:{current_status}->{action}")

    if action in {"VERIFY", "PROMOTE"} and not evidence_refs:
        raise ValueError("EVIDENCE_REQUIRED_FOR_ARTIFACT_ACTION")

    result = {
        "schema_version": "1.0",
        "artifact_id": artifact_id,
        "artifact_type": artifact_type,
        "status": expected,
        "source_request_id": source_request_id,
        "evidence_refs": evidence_refs,
        "next_action": (
            "VERIFY" if expected == "CREATED"
            else "VERIFY_OR_RETIRE" if expected in {"USED", "RETIRED"}
            else "PROMOTE_OR_RETIRE" if expected == "VERIFIED"
            else "NONE"
        ),
        "reason": f"{action}:{current_status}->{expected}",
    }
    _validate(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run reverse artifact lifecycle transition")
    parser.add_argument("--artifact-id", required=True)
    parser.add_argument("--artifact-type", required=True)
    parser.add_argument("--source-request-id", required=True)
    parser.add_argument("--current-status", required=True)
    parser.add_argument("--action", required=True)
    parser.add_argument("--evidence-ref", action="append", default=[])
    args = parser.parse_args()
    result = execute(
        args.artifact_id,
        args.artifact_type,
        args.source_request_id,
        args.current_status,
        args.action,
        args.evidence_ref,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
