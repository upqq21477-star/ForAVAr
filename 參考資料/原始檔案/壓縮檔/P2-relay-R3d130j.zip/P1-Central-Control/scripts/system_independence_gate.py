#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def evaluate(data: dict, _repository_evidence: dict | None = None) -> dict:
    """純函式：只檢查 registry 契約；repository evidence 由 system_independence_repository_gate 處理。"""
    errors = []
    if data.get("global_rules", {}).get("central_state_owner") is not True:
        errors.append("central_state_owner 必須為 true")
    if data.get("global_rules", {}).get("system_to_system_handoff") is not False:
        errors.append("system_to_system_handoff 必須為 false")
    if data.get("global_rules", {}).get("partial_handoff") is not False:
        errors.append("partial_handoff 必須為 false")
    if data.get("global_rules", {}).get("handoff_unit") != "WORK_SEGMENT":
        errors.append("handoff_unit 必須為 WORK_SEGMENT")

    systems = data.get("systems", [])
    if not isinstance(systems, list):
        errors.append("systems 必須為 array")
        systems = []
    elif not systems:
        errors.append("SYSTEM_REGISTRY_EMPTY：沒有已登錄的 System，無法證明獨立性")

    for system in systems:
        sid = system.get("system_id", "UNKNOWN")
        if system.get("runtime_dependencies") != []:
            errors.append(f"{sid}: runtime_dependencies 必須為空")
        if system.get("allowed_inbound") != "CENTRAL_TO_SYSTEM":
            errors.append(f"{sid}: inbound 必須只允許 CENTRAL_TO_SYSTEM")
        if system.get("allowed_outbound") != "SYSTEM_TO_CENTRAL":
            errors.append(f"{sid}: outbound 必須只允許 SYSTEM_TO_CENTRAL")
        if system.get("direct_system_handoff") is not False:
            errors.append(f"{sid}: direct_system_handoff 必須為 false")
        if system.get("state_owner") != "SYSTEM_LOCAL_ONLY":
            errors.append(f"{sid}: state_owner 必須為 SYSTEM_LOCAL_ONLY")

    return {
        "status": "BLOCK" if errors else "PASS",
        "system_count": len(systems),
        "errors": errors,
        "registry_errors": errors,
        "rules": {
            "central_state_owner": True,
            "system_to_system_handoff": False,
            "partial_handoff": False,
            "handoff_unit": "WORK_SEGMENT"
        }
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 system independence contract gate")
    parser.add_argument("registry")
    args = parser.parse_args()
    data = json.loads(Path(args.registry).read_text(encoding="utf-8"))

    result = evaluate(data)
    result.pop("registry_errors")  # CLI 輸出格式維持原樣
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 3 if result["errors"] else 0


if __name__ == "__main__":
    raise SystemExit(main())