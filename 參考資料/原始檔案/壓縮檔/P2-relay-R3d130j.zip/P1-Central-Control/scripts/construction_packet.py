#!/usr/bin/env python3
"""Runtime for bounded construction packets: mutate first, accept once, retry only after failure."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/construction_packet.schema.json"


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def validate(packet: dict[str, Any]) -> None:
    Draft202012Validator(load(SCHEMA)).validate(packet)


def git_sha(cwd: Path) -> str:
    result = subprocess.run(
        ["git", "rev-parse", "HEAD"],
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("GIT_HEAD_UNAVAILABLE")
    return result.stdout.strip()


def changed_paths(cwd: Path, start_sha: str, end_sha: str) -> list[str]:
    if start_sha == end_sha:
        diff_command = ["git", "diff", "--name-only", start_sha]
    else:
        diff_command = ["git", "diff", "--name-only", f"{start_sha}..{end_sha}"]

    result = subprocess.run(
        diff_command,
        cwd=cwd,
        capture_output=True,
        text=True,
        check=False,
    )
    if result.returncode != 0:
        raise RuntimeError("GIT_CHANGESET_UNAVAILABLE")

    paths = {path for path in result.stdout.splitlines() if path}

    if start_sha == end_sha:
        status = subprocess.run(
            ["git", "status", "--short", "--untracked-files=all"],
            cwd=cwd,
            capture_output=True,
            text=True,
            check=False,
        )
        if status.returncode != 0:
            raise RuntimeError("GIT_STATUS_UNAVAILABLE")
        for line in status.stdout.splitlines():
            raw = line[3:].strip() if len(line) >= 4 else ""
            if raw.startswith('"') and raw.endswith('"'):
                raw = raw[1:-1]
            if " -> " in raw:
                raw = raw.split(" -> ", 1)[-1]
            if raw:
                paths.add(raw)

    return sorted(paths)


def in_scope(path: str, scope: list[str]) -> bool:
    return any(path == item or path.startswith(item.rstrip("/") + "/") for item in scope)


def mutation_scope(packet: dict[str, Any], changed: list[str]) -> tuple[list[str], list[str]]:
    scope = packet["write_scope"]
    allowed = scope["create"] + scope["update"]
    forbidden = scope["forbidden"]
    out_of_scope = [path for path in changed if not in_scope(path, allowed)]
    forbidden_changes = [path for path in changed if in_scope(path, forbidden)]
    return sorted(set(out_of_scope)), sorted(set(forbidden_changes))


def observe_change(packet: dict[str, Any], *, start_sha: str, end_sha: str, cwd: Path) -> dict[str, Any]:
    changed = changed_paths(cwd, start_sha, end_sha)
    if not changed and not packet["required_state_delta"]["allow_zero_files_changed"]:
        return {
            "status": "ZERO_PROGRESS",
            "changed_paths": [],
            "out_of_scope": [],
            "forbidden_changes": [],
        }

    out_of_scope, forbidden_changes = mutation_scope(packet, changed)
    if forbidden_changes:
        status = "FORBIDDEN_SCOPE"
    elif out_of_scope:
        status = "OUT_OF_SCOPE"
    else:
        required = packet["required_state_delta"]["required_paths"]
        missing = [path for path in required if path not in changed]
        status = "CHANGE_OBSERVED" if not missing else "MISSING_REQUIRED_STATE_DELTA"
    return {
        "status": status,
        "changed_paths": changed,
        "out_of_scope": out_of_scope,
        "forbidden_changes": forbidden_changes,
    }


def run_acceptance(
    packet: dict[str, Any],
    *,
    cwd: Path,
    observed: dict[str, Any],
) -> dict[str, Any]:
    if observed["status"] != "CHANGE_OBSERVED":
        raise ValueError(f"ACCEPTANCE_NOT_ALLOWED:{observed['status']}")

    command = packet["acceptance"]["command"]
    allowed_runs = packet["acceptance"]["max_total_runs"]
    runs: list[dict[str, Any]] = []
    for attempt in range(1, allowed_runs + 1):
        result = subprocess.run(
            command,
            cwd=cwd,
            capture_output=True,
            text=True,
            check=False,
        )
        runs.append({
            "attempt": attempt,
            "returncode": result.returncode,
            "stdout": result.stdout,
            "stderr": result.stderr,
        })
        if result.returncode == 0:
            return {"status": "VERIFIED", "runs": runs}
        if attempt == 1 and "FAIL" in packet["acceptance"]["rerun_on"]:
            continue
        break
    return {"status": "BLOCKED", "runs": runs}


def execute(
    packet: dict[str, Any],
    *,
    cwd: Path,
    start_sha: str | None = None,
    end_sha: str | None = None,
    run_acceptance_now: bool = False,
) -> dict[str, Any]:
    validate(packet)
    if packet["status"] not in {"READY", "BUILDING", "CHANGE_OBSERVED"}:
        raise ValueError(f"PACKET_NOT_BUILDABLE:{packet['status']}")

    start = start_sha or git_sha(cwd)
    end = end_sha or start
    observed = observe_change(packet, start_sha=start, end_sha=end, cwd=cwd)

    result = {
        "packet_id": packet["packet_id"],
        "status": observed["status"],
        "start_sha": start,
        "end_sha": end,
        "observation": observed,
    }

    if run_acceptance_now:
        result["acceptance"] = run_acceptance(packet, cwd=cwd, observed=observed)
        if result["acceptance"]["status"] == "VERIFIED":
            result["status"] = "VERIFIED"

    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 construction packet runtime")
    parser.add_argument("packet")
    parser.add_argument("--base-dir", default=".")
    parser.add_argument("--start-sha")
    parser.add_argument("--end-sha")
    parser.add_argument("--acceptance", action="store_true")
    args = parser.parse_args()

    packet = load((Path(args.base_dir) / args.packet).resolve())
    result = execute(
        packet,
        cwd=Path(args.base_dir).resolve(),
        start_sha=args.start_sha,
        end_sha=args.end_sha,
        run_acceptance_now=args.acceptance,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"CHANGE_OBSERVED", "VERIFIED"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
