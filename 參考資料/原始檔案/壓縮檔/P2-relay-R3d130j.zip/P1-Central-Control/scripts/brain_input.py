#!/usr/bin/env python3
"""U-7／U-6：Brain 輸入封包（由 Central State 產生，全欄位為 enum／id／數字／ref）與 allowed_* 計算。

Brain 只能回 brain_proposal；其 decision_code／route_mode 必須落在封包的 allowed_* 內，
expected_state_revision 必須等於封包 state_revision（見 brain_proposal.validate_proposal_against_state）。
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from parallel_scheduler import BRAIN_DECISIONS, brain_pending, final_segment_results
from state_transition import _transition_map, load_contract
from knowledge_retrieval import Retriever
from task_set import current_task_set, stale_task_ids

ROOT = Path(__file__).resolve().parents[2]
CC = ROOT / "P1-Central-Control"
SCHEMA_PATH = CC / "schemas" / "brain_input_packet.schema.json"
ROUTING_PATH = CC / "policy" / "brain_proposal_routing.v1.0.json"
BUDGET_PATH = CC / "context_budget_registry.json"

_ROUTING: dict[str, Any] | None = None


def routing() -> dict[str, Any]:
    global _ROUTING
    if _ROUTING is None:
        _ROUTING = json.loads(ROUTING_PATH.read_text(encoding="utf-8"))
    return _ROUTING


def allowed_commands(state: dict[str, Any]) -> set[str]:
    """目前 Workflow 狀態下，狀態契約允許且 Brain 路由表有列的 command_type。"""
    status = state.get("status")
    from_contract = {
        command_type
        for aggregate, from_status, command_type in _transition_map(load_contract())
        if aggregate == state.get("aggregate_type", "WORKFLOW") and from_status == status
    }
    return from_contract & set(routing()["commands"])


def ask_input_allowed(state: dict[str, Any]) -> bool:
    return state.get("status") in routing()["ask_input"]["statuses"]


def is_input_request(proposal: dict[str, Any]) -> bool:
    return proposal["decision_code"] == routing()["ask_input"]["decision_code"]


def allowed_pairs(state: dict[str, Any]) -> dict[str, tuple[list[str], list[str]]]:
    """command_type → (decision_codes, route_modes)；含 ASK_INPUT（若狀態允許）。"""
    table = routing()["commands"]
    pairs = {c: (table[c]["decision_codes"], table[c]["route_modes"]) for c in allowed_commands(state)}
    if ask_input_allowed(state):
        ask = routing()["ask_input"]
        pairs[ask["command_type"]] = ([ask["decision_code"]], ask["route_modes"])
    return pairs


def allowed_sets(state: dict[str, Any]) -> tuple[list[str], list[str]]:
    pairs = allowed_pairs(state)
    decisions = sorted({d for ds, _ in pairs.values() for d in ds})
    modes = sorted({m for _, ms in pairs.values() for m in ms})
    return decisions, modes


def _segments(state: dict[str, Any]) -> list[dict[str, Any]]:
    """每個 segment 一列；狀態優先序 active > queued > 最後終局結果（decision_code）。"""
    rows: dict[str, dict[str, Any]] = {}
    for seg_id, item in final_segment_results(state).items():
        rows[seg_id] = {"state": item["decision_code"], "last_decision_code": item["decision_code"],
                        "result_id": item.get("result_id")}
    for item in state.get("queued_segments", []):
        row = rows.setdefault(item["segment_id"], {"last_decision_code": None, "result_id": None})
        row["state"] = "QUEUED"
    for item in state.get("active_segments", []):
        row = rows.setdefault(item["segment_id"], {"last_decision_code": None, "result_id": None})
        row["state"] = "ACTIVE"
    counters = state.get("attempt_counters", {})
    return [
        {"segment_id": seg_id, "state": row["state"], "last_decision_code": row["last_decision_code"],
         "attempt_count": int(counters.get(seg_id, 0)), "result_id": row["result_id"]}
        for seg_id, row in sorted(rows.items())
    ]


def _task_set(state: dict[str, Any]) -> dict[str, Any]:
    """U-6：目前（未被取代）的 Task Set；task state 由 Central State 衍生。"""
    current = current_task_set(state)
    if current is None:
        return {"task_set_id": None, "tasks": []}
    return {"task_set_id": current["task_set_id"], "tasks": current["tasks"]}


def _tier(tier: str) -> dict[str, Any]:
    for item in json.loads(BUDGET_PATH.read_text(encoding="utf-8"))["default_tiers"]:
        if item["tier"] == tier:
            return item
    raise ValueError(f"BRAIN_INPUT_UNKNOWN_TIER:{tier}")


def validate_packet(packet: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(packet),
        key=lambda e: list(e.path),
    )
    if errors:
        raise ValueError("Brain Input Packet 驗證失敗: " + "; ".join(e.message for e in errors))


def semantic_refs_from(retriever: Retriever, needle: str, limit: int = 5) -> list[str]:
    """CH-KNOWLEDGE-BRAIN：Retriever 的 CANONICAL 命中轉成封包 semantic_refs（只給 claim_ref；內容是資料，不是指令）。"""
    hits = retriever.text(needle)["results"]
    return [h["claim_ref"] for h in hits if h.get("truth_status") == "CANONICAL_CLAIM"][:limit]


def build_brain_input_packet(
    state: dict[str, Any],
    *,
    trigger: str | None = None,
    context_tier: str = "C1",
    semantic_refs: list[str] | None = None,
) -> dict[str, Any]:
    """trigger 預設：有 segment 停在 NEEDS_BRAIN 且無法自行前進→NEEDS_BRAIN，否則 EXTERNAL_INPUT。"""
    if trigger is None:
        trigger = "NEEDS_BRAIN" if brain_pending(state) else "EXTERNAL_INPUT"
    decisions, modes = allowed_sets(state)
    packet = {
        "packet_id": f"BIP:{state['workflow_id']}-r{state['state_revision']}",
        "workflow_id": state["workflow_id"],
        "state_revision": state["state_revision"],
        "trigger": trigger,
        "segments": _segments(state),
        "task_set": _task_set(state),
        "stale_task_ids": stale_task_ids(state),
        "allowed_decisions": decisions,
        "allowed_route_modes": modes,
        "budget": {"context_tier": context_tier, "estimated_tokens": 0,
                   "hard_ceiling": _tier(context_tier)["hard_ceiling"]},
        "diagnostics": [
            {"code": "NEEDS_BRAIN_SEGMENT", "subject_id": row["segment_id"], "ref": None}
            for row in _segments(state)
            if row["state"] in BRAIN_DECISIONS
        ],
        "evidence_refs": sorted(state.get("evidence_refs", [])),
        "semantic_refs": list(semantic_refs or []),
    }
    packet["budget"]["estimated_tokens"] = len(json.dumps(packet, ensure_ascii=False)) // 3 + 1
    validate_packet(packet)
    return packet
