#!/usr/bin/env python3
"""Fail-closed boundary guard for P1 self-evolution."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Any

from self_evolution_trust_evidence import (
    evaluate_validator_quorum,
    validate_rollback_evidence,
)

DEFAULT_CONSTITUTION_PATH = (
    Path(__file__).resolve().parents[1]
    / "canonical"
    / "self_evolution_constitution.json"
)
TRUSTED_ANCHOR_ENV = "P1_TRUSTED_CONSTITUTION_SHA256"
TRUSTED_VALIDATOR_REGISTRY_ENV = "P1_TRUSTED_VALIDATOR_REGISTRY_SHA256"
TRUSTED_ROLLBACK_REGISTRY_ENV = "P1_TRUSTED_ROLLBACK_REGISTRY_SHA256"


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def load_constitution(path: Path = DEFAULT_CONSTITUTION_PATH) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _load_registry(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def evaluate_candidate(
    candidate: dict[str, Any],
    *,
    constitution: dict[str, Any] | None = None,
    trusted_constitution_sha256: str | None = None,
    validator_evidence: list[dict[str, Any]] | None = None,
    validator_registry: dict[str, Any] | None = None,
    trusted_validator_registry_sha256: str | None = None,
    rollback_evidence: dict[str, Any] | None = None,
    rollback_registry: dict[str, Any] | None = None,
    trusted_rollback_registry_sha256: str | None = None,
    required_validator_quorum: int = 2,
    required_trust_domains: int = 2,
    active_canonical_authorities: list[str] | None = None,
) -> dict[str, Any]:
    constitution = constitution or load_constitution()
    trusted_anchor = trusted_constitution_sha256 or os.getenv(TRUSTED_ANCHOR_ENV)
    trusted_validator_anchor = (
        trusted_validator_registry_sha256
        or os.getenv(TRUSTED_VALIDATOR_REGISTRY_ENV)
    )
    trusted_rollback_anchor = (
        trusted_rollback_registry_sha256
        or os.getenv(TRUSTED_ROLLBACK_REGISTRY_ENV)
    )
    authorities = active_canonical_authorities or []
    violations: list[str] = []
    claims = candidate.get("claims", {})
    evidence = candidate.get("evidence", {})

    current_constitution_hash = canonical_sha256(constitution)
    candidate_digest = canonical_sha256(candidate)

    if not trusted_anchor:
        violations.append("TRUST_ANCHOR_UNAVAILABLE")
    elif current_constitution_hash != trusted_anchor:
        violations.append("CONSTITUTION_ANCHOR_MISMATCH")

    if validator_registry is None:
        violations.append("VALIDATOR_REGISTRY_UNAVAILABLE")
    else:
        current_validator_registry_hash = canonical_sha256(validator_registry)
        if not trusted_validator_anchor:
            violations.append("VALIDATOR_REGISTRY_ANCHOR_UNAVAILABLE")
        elif current_validator_registry_hash != trusted_validator_anchor:
            violations.append("VALIDATOR_REGISTRY_ANCHOR_MISMATCH")

    if rollback_registry is None:
        violations.append("ROLLBACK_REGISTRY_UNAVAILABLE")
    else:
        current_rollback_registry_hash = canonical_sha256(rollback_registry)
        if not trusted_rollback_anchor:
            violations.append("ROLLBACK_REGISTRY_ANCHOR_UNAVAILABLE")
        elif current_rollback_registry_hash != trusted_rollback_anchor:
            violations.append("ROLLBACK_REGISTRY_ANCHOR_MISMATCH")

    if validator_evidence is None:
        violations.append("VALIDATOR_EVIDENCE_REQUIRED")
    elif validator_registry is not None:
        quorum = evaluate_validator_quorum(
            validator_evidence,
            validator_registry=validator_registry,
            candidate_digest=candidate_digest,
            constitution_digest=current_constitution_hash,
            min_validators=required_validator_quorum,
            min_trust_domains=required_trust_domains,
        )
        if quorum["status"] != "PASS":
            violations.extend(quorum["violations"])

    if rollback_evidence is None:
        violations.append("ROLLBACK_EVIDENCE_REQUIRED")
    elif rollback_registry is not None:
        violations.extend(
            validate_rollback_evidence(
                rollback_evidence,
                rollback_registry=rollback_registry,
                constitution_digest=current_constitution_hash,
            )
        )

    if len(authorities) != 1:
        violations.append("ONE_CANONICAL_AUTHORITY")
    if not evidence.get("provenance_ref"):
        violations.append("PROMOTION_REQUIRES_PROVENANCE")
    if not evidence.get("rollback_snapshot_ref"):
        violations.append("PROMOTION_REQUIRES_ROLLBACK_POINT")
    if claims.get("superseded_control_still_active"):
        violations.append("SUPERSEDED_CONTROL_CANNOT_REMAIN_ACTIVE")
    if claims.get("validator_self_certified"):
        violations.append("MUTABLE_VALIDATOR_CANNOT_SELF_CERTIFY")
    if claims.get("hot_state_unbounded"):
        violations.append("HOT_STATE_MUST_REMAIN_BOUNDED")
    if claims.get("promotes_unknown_or_conflict"):
        violations.append("UNKNOWN_OR_CONFLICT_CANNOT_BE_PROMOTED_AS_FACT")

    return {
        "status": "PASS" if not violations else "BLOCK",
        "decision": "PROMOTE" if not violations else "SAFE_HOLD",
        "constitution_id": constitution.get("constitution_id"),
        "constitution_version": constitution.get("version"),
        "constitution_sha256": current_constitution_hash,
        "candidate_digest": candidate_digest,
        "candidate_id": candidate.get("candidate_id"),
        "violations": sorted(set(violations)),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("candidate_json")
    parser.add_argument("--constitution")
    parser.add_argument("--validator-evidence")
    parser.add_argument("--validator-registry")
    parser.add_argument("--rollback-evidence")
    parser.add_argument("--rollback-registry")
    parser.add_argument("--trusted-constitution-sha256")
    parser.add_argument("--trusted-validator-registry-sha256")
    parser.add_argument("--trusted-rollback-registry-sha256")
    parser.add_argument("--required-validator-quorum", type=int, default=2)
    parser.add_argument("--required-trust-domains", type=int, default=2)
    parser.add_argument("--canonical-authority", action="append", default=[])
    args = parser.parse_args()

    candidate = json.loads(Path(args.candidate_json).read_text(encoding="utf-8"))
    constitution = (
        json.loads(Path(args.constitution).read_text(encoding="utf-8"))
        if args.constitution
        else load_constitution()
    )
    validator_evidence = (
        json.loads(Path(args.validator_evidence).read_text(encoding="utf-8"))
        if args.validator_evidence
        else None
    )
    validator_registry = (
        _load_registry(Path(args.validator_registry))
        if args.validator_registry
        else None
    )
    rollback_evidence = (
        json.loads(Path(args.rollback_evidence).read_text(encoding="utf-8"))
        if args.rollback_evidence
        else None
    )
    rollback_registry = (
        _load_registry(Path(args.rollback_registry))
        if args.rollback_registry
        else None
    )

    report = evaluate_candidate(
        candidate,
        constitution=constitution,
        trusted_constitution_sha256=args.trusted_constitution_sha256,
        validator_evidence=validator_evidence,
        validator_registry=validator_registry,
        trusted_validator_registry_sha256=args.trusted_validator_registry_sha256,
        rollback_evidence=rollback_evidence,
        rollback_registry=rollback_registry,
        trusted_rollback_registry_sha256=args.trusted_rollback_registry_sha256,
        required_validator_quorum=args.required_validator_quorum,
        required_trust_domains=args.required_trust_domains,
        active_canonical_authorities=args.canonical_authority,
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
