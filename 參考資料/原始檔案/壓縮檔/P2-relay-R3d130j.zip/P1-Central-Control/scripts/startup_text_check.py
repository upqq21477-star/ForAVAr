#!/usr/bin/env python3
"""R4L-S3-M3b static check of the startup text (Skill + activation interface + brief_slots.former_startup_list).
Evidence level STATIC_CHECK: it proves the required rule text is present and the old read-everything list is gone;
it cannot prove an AI follows the text (that part stays POLICY_ONLY, observed by Track A dry runs)."""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SKILL = ROOT / ".agents/skills/p2-brain/SKILL.md"
IFACE = ROOT / "docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md"
SLOTS = ROOT / "P1-Central-Control/brief_slots.json"

SKILL_REQUIRED = {
    "SKILL_NO_BRIEF_MODE": "non-STALE Brain Brief",
    "SKILL_NO_DEGRADED_SET": "HOT summary of P1-CURRENT.json",
    "SKILL_NO_NEVER_READ_ALL": "Never fall back to reading everything",
    "SKILL_NO_PREP_RULE": "！備料 opens a librarian session",
    "SKILL_NO_ASCII_RULE": "A leading ASCII ! on any official command counts as ！",
    "SKILL_NO_WRITE_GUARD": "all three must hold",
    "SKILL_NO_RECOVERY_POINT": "a recovery point exists",
    "SKILL_NO_CLARIFY_RULE": "Ask a clarifying question only when the ambiguity changes the route",
}
SKILL_FORBIDDEN = {
    "SKILL_OLD_FULL_LIST": "Read docs/plans/P2-Conversation-Brain-Activation-Interface-v1.0.md and, as needed",
    "SKILL_OLD_BLUEPRINT_STEP": "then the unique P2 blueprint at docs/architecture/P2-System-Blueprint-v1.0.md",
}
IFACE_REQUIRED = {"IFACE_NO_DEGRADED_SET": "降級讀集", "IFACE_NO_BRIEF_MODE": "未 STALE 的 Brain Brief",
                  "IFACE_NO_MODE_BASIS": "librarian.select_startup_mode"}
IFACE_FORBIDDEN = {"IFACE_OLD_STARTUP": "先讀取最新 P1-CURRENT.json、唯一藍圖",
                   "IFACE_OLD_INIT_STEP": "1. **讀取權威現況：**"}


def check(skill: str, iface: str, slots: dict, root: Path = ROOT) -> list[str]:
    errs = [k for k, v in SKILL_REQUIRED.items() if v not in skill]
    errs += [k for k, v in SKILL_FORBIDDEN.items() if v in skill]
    errs += [k for k, v in IFACE_REQUIRED.items() if v not in iface]
    errs += [k for k, v in IFACE_FORBIDDEN.items() if v in iface]
    fl = slots.get("former_startup_list")
    if not isinstance(fl, dict) or not fl.get("paths"):
        errs.append("SLOTS_NO_FORMER_STARTUP_LIST")
    else:
        errs += [f"SLOTS_FORMER_PATH_MISSING:{p}" for p in fl["paths"] if not (root / p).is_file()]
    return errs


def main() -> int:
    errs = check(SKILL.read_text(encoding="utf-8"), IFACE.read_text(encoding="utf-8"),
                 json.loads(SLOTS.read_text(encoding="utf-8")))
    print("startup_text_check:", "PASS (STATIC_CHECK)" if not errs else "FAIL " + ",".join(errs))
    return 1 if errs else 0


if __name__ == "__main__":
    sys.exit(main())
