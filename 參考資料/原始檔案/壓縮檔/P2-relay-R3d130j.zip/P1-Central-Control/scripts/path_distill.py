#!/usr/bin/env python3
"""P2 path_distill (R6) - inventory mechanical steps of the p2_run loop and distill them into code fast paths.

Fast paths mirror existing p2_run.Run decisions (a miss returns None and the original path runs; nothing is deleted):
  FP1 fp_path_gate    mirrors Run._path      (PATH_ESCAPE / SUFFIX_NOT_ALLOWED)
  FP2 fp_tool_gate    mirrors Run.step       (TOOL_UNKNOWN / BUDGET_EXHAUSTED)
  FP3 fp_test_outcome mirrors Run._run_tests (exit code -> success/failure attempt record)
Subcommands (all SIMULATED_PASS, toy repo in a temp dir, no network):
  inventory | fast_paths | replay | threshold | measure      e.g. python3 scripts/path_distill.py inventory
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
if __name__ == "__main__":  # p2_run does `import path_distill`; share ONE module so HITS counts the same copy
    sys.modules["path_distill"] = sys.modules[__name__]
ROOT = HERE.parent
EVID = ROOT / "evidence" / "r6"
R5_TRACE = ROOT / "evidence" / "r5-trace" / "closure_trace.json"
SEMANTIC_TOOLS = ("edit",)  # edit content is a judgement; never distilled
TOOLS = ("read", "search", "edit", "run_tests")
HITS: dict[str, int] = {}
FP_ERR = {"PATH_ESCAPE": "FP1", "SUFFIX_NOT_ALLOWED": "FP1", "TOOL_UNKNOWN": "FP2", "BUDGET_EXHAUSTED": "FP2"}


def _hit(fp: str) -> None:
    HITS[fp] = HITS.get(fp, 0) + 1


# ---- fast path functions (miss -> None / original path) ------------------------------------------------------
def fp_path_gate(args: Any, tool: str, work: Any, suffixes: tuple) -> str | None:
    need, allowed = {"read": ({"path"}, {"path"}), "edit": ({"path", "old", "new"}, {"path", "old", "new", "preview_lines"})}.get(tool, (None, None))
    if need is None or not isinstance(args, dict) or not need <= set(args) <= allowed:
        return None
    rel, code = args["path"], None
    if not isinstance(rel, str) or not rel or os.path.isabs(rel) or ".." in Path(rel).parts:
        code = "PATH_ESCAPE"
    else:
        base = Path(work).resolve()
        p = (base / rel).resolve()
        try:
            p.relative_to(base)
        except ValueError:
            code = "PATH_ESCAPE"
        if code is None and p.suffix not in suffixes:
            code = "SUFFIX_NOT_ALLOWED"
    if code:
        _hit("FP1")
    return code


def fp_tool_gate(tool: Any, budget: int, tools: tuple = TOOLS) -> str | None:
    code = "TOOL_UNKNOWN" if tool not in tools else ("BUDGET_EXHAUSTED" if budget <= 0 else None)
    if code:
        _hit("FP2")
    return code


def fp_test_outcome(attempts: list, exit_code: int, run_id: str) -> str:
    outcome = "success" if exit_code == 0 else "failure"
    attempts.append({"step": "run_tests", "outcome": outcome, "head_sha": run_id, "t": len(attempts)})
    _hit("FP3")
    return outcome


FAST_PATHS = [
    {"fast_path_id": "FP1", "function": "path_distill:fp_path_gate", "mirrors": "p2_run.Run._path",
     "trigger": "tool in (read, edit) with exact arg keys and path absolute / contains .. / escapes workdir / suffix not allowed"},
    {"fast_path_id": "FP2", "function": "path_distill:fp_tool_gate", "mirrors": "p2_run.Run.step",
     "trigger": "tool not in TOOLS (TOOL_UNKNOWN) or budget <= 0 (BUDGET_EXHAUSTED)"},
    {"fast_path_id": "FP3", "function": "path_distill:fp_test_outcome", "mirrors": "p2_run.Run._run_tests",
     "trigger": "run_tests subprocess finished: exit code decides success/failure attempt registration"},
]


# ---- helpers -------------------------------------------------------------------------------------------------
def sha_file(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _write(p: Path, obj: Any) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")


def _rel(p: Path) -> str:
    return "P1-Central-Control/" + p.resolve().relative_to(ROOT).as_posix()


def capture(use_fast: bool) -> dict[str, Any]:
    """Run p2_run.simulate once with fast paths on/off; record every trace entry, attempt and row result."""
    import p2_run
    rec: list[list[Any]] = []
    o_log, o_rt = p2_run.Run._log, p2_run.Run._run_tests

    def log(self: Any, *a: Any) -> None:
        o_log(self, *a)
        e = self.trace[-1]
        rec.append([self.run_id, e["seq"], e["tool"], e["verdict"], e["code"], e["hash"]])

    def rt(self: Any, *a: Any, **k: Any) -> Any:
        r = o_rt(self, *a, **k)
        rec.append([self.run_id, "attempt", json.dumps(self.attempts[-1], sort_keys=True)])
        return r

    HITS.clear()
    prev = p2_run.DEFAULT_FAST
    p2_run.DEFAULT_FAST, p2_run.Run._log, p2_run.Run._run_tests = use_fast, log, rt
    try:
        rows = p2_run.simulate()
    finally:
        p2_run.DEFAULT_FAST, p2_run.Run._log, p2_run.Run._run_tests = prev, o_log, o_rt
    return {"rec": rec, "rows": [[n, ok] for n, ok, _ in rows], "hits": dict(HITS)}


def compare(a: list, b: list) -> dict[str, Any]:
    n = max(len(a), len(b))
    bad = [{"index": i, "semantic": a[i] if i < len(a) else None, "fast": b[i] if i < len(b) else None}
           for i in range(n) if i >= len(a) or i >= len(b) or a[i] != b[i]]
    return {"steps_compared": n, "matched": n - len(bad), "equivalence_rate": (n - len(bad)) / n if n else 0.0, "mismatches": bad}


# ---- M1 inventory --------------------------------------------------------------------------------------------
def classify(runs: list[list[dict]]) -> list[dict[str, Any]]:
    out = []
    for i, first in enumerate(runs[0]):
        col = [r[i] if i < len(r) else None for r in runs]
        sig = lambda e, keys: tuple(e.get(k) for k in keys) if e else None  # noqa: E731
        same_full = all(sig(e, ("tool", "verdict", "code", "args_digest")) == sig(first, ("tool", "verdict", "code", "args_digest")) for e in col)
        same_core = all(sig(e, ("tool", "verdict", "code", "mode")) == sig(first, ("tool", "verdict", "code", "mode")) for e in col)
        if first["tool"] in SEMANTIC_TOOLS:
            cls, basis = "semantic", "content_judgement_tool"
        elif same_full:
            cls, basis = "mechanical", "identical_tool_verdict_code_args_digest"
        elif same_core:
            cls, basis = "mechanical", "identical_tool_verdict_code_mode(args_digest_varies)"
        else:
            cls, basis = "semantic", "unstable_across_runs"
        out.append({"seq": first["seq"], "tool": first["tool"], "verdict": first["verdict"], "code": first["code"], "class": cls, "basis": basis})
    return out


def inventory(evid: Path = EVID, n: int = 3) -> dict[str, Any]:
    import tempfile
    import p2_run
    runs = []
    with tempfile.TemporaryDirectory() as td:
        for k in range(n):
            f = Path(td) / f"t{k}.json"
            p2_run.simulate(save_trace=str(f))
            runs.append(json.loads(f.read_text(encoding="utf-8"))["trace"])
    steps = classify(runs)
    r5 = json.loads(R5_TRACE.read_text(encoding="utf-8")).get("trace", []) if R5_TRACE.exists() else []
    inv = {"evidence_level": "SIMULATED_PASS", "runs": n, "steps": steps,
           "mechanical": sum(s["class"] == "mechanical" for s in steps), "semantic": sum(s["class"] == "semantic" for s in steps),
           "r5_saved_trace_matches": [(e["tool"], e["verdict"], e["code"]) for e in r5] == [(s["tool"], s["verdict"], s["code"]) for s in steps]}
    _write(evid / "inventory.json", inv)
    return inv


# ---- M2 fast_paths.json --------------------------------------------------------------------------------------
def fast_paths(evid: Path = EVID) -> dict[str, Any]:
    inv = json.loads((evid / "inventory.json").read_text(encoding="utf-8"))
    mech = {s["tool"] for s in inv["steps"] if s["class"] == "mechanical"}
    if "run_tests" not in mech:
        raise SystemExit("inventory does not mark run_tests mechanical; FP3 not justified")
    ev = "P1-Central-Control/evidence/r6/replay.json"
    d = {"evidence_level": "SIMULATED_PASS", "inventory_ref": "P1-Central-Control/evidence/r6/inventory.json",
         "fast_paths": [dict(fp, equivalence_evidence=ev) for fp in FAST_PATHS],
         "note": "miss -> original path (never deleted); equivalence proven by `path_distill.py replay`"}
    _write(evid / "fast_paths.json", d)
    return d


# ---- M4 replay -----------------------------------------------------------------------------------------------
def replay(evid: Path = EVID) -> dict[str, Any]:
    sem, fast = capture(False), capture(True)
    c = compare(sem["rec"], fast["rec"])
    rows_equal = sem["rows"] == fast["rows"]
    ok = c["equivalence_rate"] == 1.0 and rows_equal and not sem["hits"] and all(fast["hits"].get(f["fast_path_id"], 0) > 0 for f in FAST_PATHS)
    rep = {"evidence_level": "SIMULATED_PASS", "steps_compared": c["steps_compared"], "matched": c["matched"],
           "equivalence_rate": c["equivalence_rate"], "rows_equal": rows_equal, "semantic_run_hits": sem["hits"],
           "fast_run_hits": fast["hits"], "ok": ok}
    bad = []
    for m in c["mismatches"]:
        e = m["fast"] or m["semantic"]
        bad.append(dict(m, fast_path=FP_ERR.get(str(e[4]) if len(e) > 4 else "", "FP3" if len(e) == 3 else "UNKNOWN"), action="revert_to_semantic"))
    _write(evid / "replay.json", rep)
    _write(evid / "mismatch.json", {"mismatches": bad})
    return rep


# ---- M5 threshold + measure ----------------------------------------------------------------------------------
def write_threshold(evid: Path = EVID) -> str:
    t = {"metric": "gate_class_steps_handled_by_fast_path_ratio", "min_ratio": 0.5,
         "gate_class": "tool steps that are REJECT, or run_tests", "frozen_before_measure": True}
    _write(evid / "threshold.json", t)
    sha = sha_file(evid / "threshold.json")
    (evid / "threshold.sha256").write_text(sha + "\n", encoding="utf-8")
    return sha


def measure(evid: Path = EVID) -> dict[str, Any]:
    th, rec_sha = evid / "threshold.json", evid / "threshold.sha256"
    if not th.exists() or not rec_sha.exists() or sha_file(th) != rec_sha.read_text(encoding="utf-8").strip():
        raise SystemExit("THRESHOLD_NOT_FROZEN_OR_ALTERED")
    t = json.loads(th.read_text(encoding="utf-8"))
    cap = capture(True)
    gate = [r for r in cap["rec"] if r[1] != "attempt" and r[2] in TOOLS and (r[3] == "REJECT" or r[2] == "run_tests")]
    hits = sum(cap["hits"].values())
    ratio = hits / len(gate) if gate else 0.0
    met = ratio >= t["min_ratio"]
    m = {"evidence_level": "SIMULATED_PASS", "threshold_sha256": sha_file(th), "gate_class_steps": len(gate), "fast_hits": hits,
         "per_fp": cap["hits"], "ratio": round(ratio, 4), "min_ratio": t["min_ratio"], "met": met,
         "token_proxy": {"semantic_steps_before": len(gate), "semantic_steps_after": len(gate) - hits},
         "decision": "keep_fast_paths" if met else "keep_semantic_path_unmet",
         "reason_if_unmet": "" if met else "gate-class steps not covered by FP1-FP3 (e.g. scope/protected/command/diff gates) stay on the original path"}
    _write(evid / "measure.json", m)
    return m


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=["inventory", "fast_paths", "replay", "threshold", "measure"])
    a = ap.parse_args()
    r = {"inventory": inventory, "fast_paths": fast_paths, "replay": replay, "threshold": write_threshold, "measure": measure}[a.cmd]()
    print(json.dumps(r, ensure_ascii=False)[:600])
    if a.cmd == "replay" and not r["ok"]:
        return 1
    print("SIMULATED_PASS " + a.cmd)
    return 0


if __name__ == "__main__":
    sys.exit(main())
