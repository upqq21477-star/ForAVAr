#!/usr/bin/env python3
"""Render and verify the human README projection from P1-CURRENT."""

from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from typing import Any
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/current_projection_sync.schema.json"
START = "<!-- P1-CURRENT-PROJECTION:START -->"
END = "<!-- P1-CURRENT-PROJECTION:END -->"

def load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def current_runtime_observation(current: dict[str, Any]) -> dict[str, Any]:
    """Return the newest explicitly present observation without reviving stale fallbacks.

    Presence is significant: an explicitly empty/null Current observation means there
    is no current observation. It must not fall through to historical legacy fields.
    """
    impl = current.get("implementation_control", {})
    truth = impl.get("runtime_execution_truth", {}) if isinstance(impl, dict) else {}
    stage = current.get("current_stage", {})
    if isinstance(truth, dict) and "latest_observation" in truth:
        value = truth.get("latest_observation")
        return value if isinstance(value, dict) else {}
    if isinstance(stage, dict) and "latest_runtime_observation" in stage:
        value = stage.get("latest_runtime_observation")
        return value if isinstance(value, dict) else {}
    value = current.get("latest_runtime_observation", {})
    return value if isinstance(value, dict) else {}

def render(current: dict[str, Any]) -> str:
    stage = current["current_stage"]
    impl = current["implementation_control"]
    truth = impl.get("runtime_execution_truth", {})
    # Current field presence is authoritative, even when the value is empty/null.
    # Never use truthiness to resurrect a superseded historical PASS.
    runtime = current_runtime_observation(current)
    step_evidence = runtime.get("step_evidence")
    if step_evidence is None:
        step_evidence = runtime.get("steps_executed")
    lines = [
        START,
        "> ## Current Projection",
        "> **唯一 Current Authority：** P1-CURRENT.json",
        f"> **目前 Active Work：** {impl['active_work_packet']}",
        f"> **Current Stage：** {stage['id']} / {stage['status']} / active slice {stage.get('slice_id', '-')} / next slice {stage.get('next_slice_id', '-')}",
        f"> **Runtime Truth：** {truth.get('status', 'UNKNOWN')}",
        f"> **最新 Runtime Observation：** run {runtime.get('run_id')} / attempt {runtime.get('run_attempt')} / {runtime.get('classification')} / step evidence {step_evidence}",
        "> **Projection Rule：** README 只作 Human Projection；與 P1-CURRENT.json 衝突時，以 Current 為準。",
        END,
    ]
    return "\n".join(lines) + "\n"

def sync(readme: str, current: dict[str, Any]) -> str:
    block = render(current).strip() + "\n"
    if START in readme and END in readme:
        prefix, rest = readme.split(START, 1)
        _, suffix = rest.split(END, 1)
        return prefix + block + suffix.lstrip("\n")
    first, sep, tail = readme.partition("\n")
    return first + "\n\n" + block + "\n" + tail if sep else first + "\n\n" + block

LABEL_RE = re.compile(r"^> \*\*(.+?)：\*\* ?(.*)$")

def projection_fields(block: str) -> tuple[list[tuple[str, str]], list[str]]:
    """Split a projection block into labelled fields and every other line."""
    fields: list[tuple[str, str]] = []
    others: list[str] = []
    for line in block.splitlines():
        m = LABEL_RE.match(line.strip())
        if m:
            fields.append((m.group(1), m.group(2)))
        elif line.strip():
            others.append(line.strip())
    return fields, others

def diff_projection_fields(current_block: str, desired_block: str) -> list[str]:
    """Return the labels of fields that differ (C31: name the exact field, never a bare block)."""
    cur_f, cur_o = projection_fields(current_block)
    des_f, des_o = projection_fields(desired_block)
    cur_d, des_d = dict(cur_f), dict(des_f)
    out = [label for label, _ in des_f if cur_d.get(label) != des_d[label]]
    out += [label for label, _ in cur_f if label not in des_d and label not in out]
    if cur_o != des_o or (not out and cur_f != des_f):
        out.append("UNPARSED_LINES")
    return out

def inspect(readme: str, current: dict[str, Any]) -> dict[str, Any]:
    desired = render(current).strip()
    found = START in readme and END in readme
    current_block = ""
    if found:
        current_block = readme.split(START, 1)[1].split(END, 1)[0].strip()
    desired_block = desired.split(START, 1)[1].split(END, 1)[0].strip()
    matches = found and current_block == desired_block
    result = {
        "status": "PASS" if matches else "DRIFT",
        "active_work_packet": current["implementation_control"]["active_work_packet"],
        "current_stage_id": current["current_stage"]["id"],
        "current_stage_status": current["current_stage"]["status"],
        "runtime_status": current["implementation_control"].get("runtime_execution_truth", {}).get("status", "UNKNOWN"),
        "readme_has_projection_markers": found,
        "projection_matches": matches,
        "diff_fields": [] if matches else (diff_projection_fields(current_block, desired_block) if found else ["CURRENT_PROJECTION_BLOCK"]),
    }
    Draft202012Validator(json.loads(SCHEMA.read_text(encoding="utf-8"))).validate(result)
    return result

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--current", required=True)
    parser.add_argument("--readme", required=True)
    parser.add_argument("--output")
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args()
    current = load(Path(args.current))
    readme_path = Path(args.readme)
    readme = readme_path.read_text(encoding="utf-8")
    synced = sync(readme, current)
    result = inspect(readme, current)
    if args.write:
        readme_path.write_text(synced, encoding="utf-8")
        # Read back from disk: verify what was written, not the in-memory string (C31).
        result = inspect(readme_path.read_text(encoding="utf-8"), current)
    if args.output:
        Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2

if __name__ == "__main__":
    raise SystemExit(main())
