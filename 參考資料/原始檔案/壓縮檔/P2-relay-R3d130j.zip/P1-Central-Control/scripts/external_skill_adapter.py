#!/usr/bin/env python3
from __future__ import annotations

import json
from copy import deepcopy
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from packet_layer import build_result_packet, validate_task_packet


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
MANIFEST_SCHEMA = SCHEMA_DIR / "skill_manifest.schema.json"
INVOCATION_SCHEMA = SCHEMA_DIR / "skill_invocation.schema.json"

SkillExecutor = Callable[[dict[str, Any]], dict[str, Any]]


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "skill_manifest.schema.json",
        "skill_invocation.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"], Resource.from_contents(schema)
        )
    return registry


def _validate(path: Path, value: dict[str, Any]) -> None:
    schema = json.loads(path.read_text(encoding="utf-8"))
    validator = Draft202012Validator(
        schema,
        registry=_registry(),
        format_checker=FormatChecker(),
    )
    errors = sorted(validator.iter_errors(value), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            f"{path.name} 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def validate_manifest(manifest: dict[str, Any]) -> None:
    _validate(MANIFEST_SCHEMA, manifest)


def validate_invocation(invocation: dict[str, Any]) -> None:
    _validate(INVOCATION_SCHEMA, invocation)


def _executor_payload(task_packet: dict[str, Any]) -> dict[str, Any]:
    return deepcopy(task_packet)


def invoke_skill(
    task_packet: dict[str, Any],
    manifest: dict[str, Any],
    executor: SkillExecutor,
    *,
    invocation_id: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    validate_task_packet(task_packet)
    validate_manifest(manifest)

    if task_packet["skill_id"] != manifest["skill_id"]:
        raise ValueError("SKILL_ID_MISMATCH")
    if task_packet["skill_version"] != manifest["skill_version"]:
        raise ValueError("SKILL_VERSION_MISMATCH")

    allowed_scopes = set(manifest.get("input_scope", []))
    task_scope = task_packet["scope"]["input_scope"]
    if "*" not in allowed_scopes and task_scope not in allowed_scopes:
        raise ValueError("INPUT_SCOPE_MISMATCH")

    invocation = {
        "invocation_id": invocation_id or f"INV:{task_packet['attempt_id']}",
        "skill_id": task_packet["skill_id"],
        "skill_version": task_packet["skill_version"],
        "task_packet_ref": task_packet["object_id"],
        "execution_record_ref": task_packet["execution_record_ref"],
        "status": "DISPATCHED",
        "error_code": None,
    }
    validate_invocation(invocation)

    raw = executor(_executor_payload(task_packet))
    if not isinstance(raw, dict):
        raise ValueError("EXTERNAL_SKILL_RESULT_NOT_OBJECT")

    forbidden = {"state", "state_after", "event", "command", "workflow_status"}
    leaked = sorted(forbidden & set(raw))
    if leaked:
        raise ValueError(
            "EXTERNAL_SKILL_RESULT_CONTROL_LEAK:" + ",".join(leaked)
        )

    decision_code = raw.get("decision_code", raw.get("status"))
    if decision_code == "WORK_COMPLETE":
        if manifest["output_contract"]["requested_outputs_required"] and not raw.get("output_refs"):
            raise ValueError("EXTERNAL_SKILL_MISSING_OUTPUT_REFS")
        if manifest["execution_policy"]["evidence_required"] and not raw.get("evidence_refs"):
            raise ValueError("EXTERNAL_SKILL_MISSING_EVIDENCE_REFS")
        if manifest["execution_policy"]["provenance_required"] and not raw.get("provenance_refs"):
            raise ValueError("EXTERNAL_SKILL_MISSING_PROVENANCE_REFS")

    result_packet = build_result_packet(
        task_packet,
        raw,
    )
    invocation["status"] = "RETURNED"
    validate_invocation(invocation)
    return result_packet, invocation
