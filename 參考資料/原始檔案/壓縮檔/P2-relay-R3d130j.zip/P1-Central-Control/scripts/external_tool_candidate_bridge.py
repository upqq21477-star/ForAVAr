#!/usr/bin/env python3
"""Bridge external-tool research artifacts into existing P1 evaluation contracts.

This layer creates research/source and architecture-fit inputs only.
It never adopts candidates and never mutates capability registries.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
from pathlib import Path
from typing import Any
from urllib.parse import quote

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
REVIEW_SCHEMA = ROOT / "P1-Central-Control/schemas/external_tool_candidate_review.schema.json"
BRIDGE_SCHEMA = ROOT / "P1-Central-Control/schemas/external_tool_candidate_bridge.schema.json"
SOURCE_SCHEMA = ROOT / "P1-Central-Control/schemas/research_source.schema.json"
SOURCE_RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/research_source_normalization.schema.json"
FIT_SCHEMA = ROOT / "P1-Central-Control/schemas/architecture_fit_request.schema.json"

import sys
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
from architecture_fit import execute as execute_fit
from research_source_normalization import normalize as normalize_sources


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def validate(path: Path, value: dict[str, Any]) -> None:
    schema = load(path)
    Draft202012Validator(
        schema, registry=schema_registry(), format_checker=FormatChecker()
    ).validate(value)


def schema_registry() -> Registry:
    registry = Registry()
    for path in (SOURCE_SCHEMA, SOURCE_RESULT_SCHEMA, BRIDGE_SCHEMA, FIT_SCHEMA):
        schema = load(path)
        registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    return registry


def fit_request(candidate: dict[str, Any]) -> dict[str, Any]:
    core_ids = sorted({
        scope["scope_id"]
        for scope in candidate.get("matched_scopes", [])
        if scope.get("scope_type") == "CORE_CAPABILITY"
    })
    request_id = "FIT:EXT-" + candidate["repository"].replace("/", "-")
    return {
        "schema_version":"1.0",
        "request_id":request_id,
        "goal":"評估外部工具候選與 P1 既有架構的適配位置；不得由此直接產生採用決策。",
        "required_capabilities":core_ids,
        "system_state":{
            "classification":"UNKNOWN",
            "system_id":None,
            "boundary_conflict":False,
            "split_required":False,
            "supports_extension":False,
            "owned_capabilities":[]
        },
        "merge_candidate_system_ids":[],
        "allow_new_system":False,
        "constraints":[
            "EXTERNAL_RESEARCH_ARTIFACT_ONLY",
            "NO_DIRECT_ADOPTION",
            "CANONICAL_REGISTRY_UNMODIFIED"
        ]
    }


def source_inputs(candidate: dict[str, Any], observed_at: str) -> list[dict[str, Any]]:
    repository = candidate["repository"]
    sources=[
        {
            "source_title":f"GitHub repository: {repository}",
            "source_url":candidate["url"],
            "captured_at":observed_at,
            "claim_scope":[
                "repository_identity",
                "repository_metadata",
                "radar_candidate_status",
                "popularity_and_activity_observation"
            ],
            "source_type":"WEB"
        }
    ]
    tag=candidate.get("latest_release_tag")
    if tag:
        sources.append({
            "source_title":f"GitHub releases: {repository}",
            "source_url":f"https://github.com/{repository}/releases",
            "captured_at":observed_at,
            "claim_scope":[
                "latest_release_presence",
                "latest_release_tag",
                "release_metadata"
            ],
            "source_type":"WEB"
        })
    return sources


def bridge(review: dict[str, Any], observed_at: str) -> dict[str, Any]:
    validate(REVIEW_SCHEMA, review)
    output_candidates=[]
    errors=[]
    fit_count=0
    source_count=0
    deferred_count=0

    for candidate in review["candidates"]:
        try:
            fit_req=fit_request(candidate)
            validate(FIT_SCHEMA, fit_req)
            fit_result=execute_fit(fit_req)

            normalized=normalize_sources(source_inputs(candidate, observed_at))
            if normalized["status"] != "PASS":
                raise ValueError("RESEARCH_SOURCE_NORMALIZATION_BLOCKED")

            source_count += normalized["unique_source_count"]
            fit_count += 1

            output_candidates.append({
                "repository":candidate["repository"],
                "review_status":candidate["review_status"],
                "research_sources":normalized["sources"],
                "architecture_fit_request":fit_req,
                "architecture_fit_result":fit_result,
                "native_replacement_gate":{
                    "status":"DEFERRED",
                    "reason_codes":[
                        "CANONICAL_CAPABILITY_BINDING_REQUIRED",
                        "BASELINE_AND_CANDIDATE_RUNTIME_MODE_REQUIRED",
                        "MEASUREMENT_EVIDENCE_REQUIRED"
                    ],
                    "required_inputs":[
                        "canonical capability_id",
                        "baseline_mode",
                        "candidate_mode",
                        "schema compatibility measurement",
                        "behavior compatibility measurement",
                        "acceptance measurement",
                        "reliability measurement",
                        "regression count",
                        "unit cost measurement",
                        "evidence_refs"
                    ]
                }
            })
            deferred_count += 1
        except Exception as exc:
            errors.append({
                "code":"CANDIDATE_BRIDGE_FAILED",
                "repository":candidate.get("repository","UNKNOWN"),
                "detail":str(exc)
            })

    result={
        "schema_version":"1.0",
        "run_id":"BRIDGE-"+review["observed_date"].replace("-",""),
        "observed_date":review["observed_date"],
        "input_run_id":review["run_id"],
        "status":"PASS" if not errors else "BLOCK",
        "summary":{
            "input_count":len(review["candidates"]),
            "bridged_count":len(output_candidates),
            "fit_request_count":fit_count,
            "fit_result_count":fit_count,
            "research_source_count":source_count,
            "evaluation_deferred_count":deferred_count
        },
        "candidates":output_candidates,
        "errors":errors
    }
    validate(BRIDGE_SCHEMA, result)
    return result


def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--input",required=True)
    parser.add_argument("--output",required=True)
    args=parser.parse_args()

    review=load(Path(args.input))
    observed_at=dt.datetime.now(dt.timezone.utc).isoformat()
    result=bridge(review, observed_at)

    out=Path(args.output)
    out.parent.mkdir(parents=True,exist_ok=True)
    out.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(result["summary"],ensure_ascii=False))
    return 0 if result["status"]=="PASS" else 2


if __name__=="__main__":
    raise SystemExit(main())
