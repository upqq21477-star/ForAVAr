#!/usr/bin/env python3
"""CS-1 B3：四維狀態、Conflict、Temporal／Version（P7／P8／P12／P19；Master §7–9）。

`TemporalKnowledgeStore` 繼承 B2 `KnowledgeStore`（加 Claim 欄位，不建第二個庫）。stdlib only、決定性（不讀時鐘，
時間一律由呼叫端傳入）。機器只做可確定的事：狀態轉移表、時間區間算術、證據存在性、lineage／雜湊完整性；
「衝突誰對、證據是否真支持取代」屬語義判斷，由 CONTROL_RESEARCH 以 adjudication（by＋rationale）負責，可被推翻。

四維（Claim 上只存 lifecycle 與 temporal；其餘由既有欄位推導，避免第二份真相）：
- Epistemic（推導）：CONFLICTED（有未解 Conflict／Observation CONFLICT）＞UNKNOWN＞INFERRED＞OBSERVED。
- Adjudication（推導）：`promotion` PROPOSED／CANONICAL／REJECTED＋未解 Conflict；CANONICAL≡CONFIRMED（B2 命名保留），
  CONFIRMED 且有未解 Conflict＝DISPUTED。
- Lifecycle（存）：ACTIVE／SUPERSEDED／ARCHIVED／TEMPORARY／EXPERIMENTAL；與 `policy/lifecycle.v1.0.json` 同語意
  （TEMPORARY≡TRANSIENT：附 expires_at，到期由機器 TTL 算術退場；退場＝ARCHIVED，保留 lineage）。
- Temporal（存）：valid_from／valid_to／observed_at（區間 [valid_from, valid_to)；缺＝該端無界／未知）。
"""

from __future__ import annotations

from datetime import datetime
from typing import Any

from event_log import content_hash
from knowledge_canon import KnowledgeStore, _seal

LIVE = ("ACTIVE", "TEMPORARY", "EXPERIMENTAL")
# 手動轉移表；SUPERSEDED 只能經 supersede／rollback 路徑，ARCHIVED 為終態
MANUAL = {
    "ACTIVE": {"TEMPORARY", "EXPERIMENTAL", "ARCHIVED"},
    "TEMPORARY": {"ACTIVE", "ARCHIVED"},
    "EXPERIMENTAL": {"ACTIVE", "ARCHIVED"},
    "SUPERSEDED": {"ARCHIVED"},
    "ARCHIVED": set(),
}
OUTCOMES = {"SUPERSEDES", "COEXIST_DISJOINT_TIME", "REJECTED_ONE"}
_VALID_NOW = ("ACTIVE", "TEMPORARY", "SUPERSEDED")  # valid_at 納入；SUPERSEDED 靠 valid_to 自然排除現在


def _t(value: str) -> datetime:
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError(f"時間須含時區: {value}")
    return dt


def _blank(*vals: str) -> bool:
    return any(not v or not v.strip() for v in vals)


class TemporalKnowledgeStore(KnowledgeStore):
    def __init__(self, *args: Any, **kw: Any) -> None:
        super().__init__(*args, **kw)
        self.conflicts: dict[str, dict[str, Any]] = {}

    # ---- 內部 ----
    def _replace(self, ref: str, **changes: Any) -> dict[str, Any]:
        rec = {k: v for k, v in {**self.claims[ref], **changes}.items() if v is not None}
        self.claims[ref] = _seal(rec, "claim")
        return rec

    def _log(self, ref: str, to: str, by: str, rationale: str, **extra: Any) -> list[dict[str, Any]]:
        entry = {"from": self.claims[ref]["lifecycle"], "to": to, "by": by, "rationale": rationale, **extra}
        return [*self.claims[ref]["lifecycle_log"], entry]

    def _open_conflicts(self, ref: str) -> list[str]:
        return sorted(c["object_id"] for c in self.conflicts.values()
                      if c["status"] == "UNRESOLVED" and ref in (c["claim_a"], c["claim_b"]))

    def _apply_supersede(self, winner: str, loser: str, by: str, rationale: str) -> None:
        w, lo = self.claims[winner], self.claims[loser]
        before = lo.get("valid_to")
        cut = w["valid_from"] if before is None or _t(w["valid_from"]) < _t(before) else before
        extra: dict[str, Any] = {"superseded_by": winner}
        if before is not None:
            extra["valid_to_before"] = before
        self._replace(loser, lifecycle="SUPERSEDED", valid_to=cut, lifecycle_log=self._log(loser, "SUPERSEDED", by, rationale, **extra))
        if loser not in w["supersedes"]:
            self._replace(winner, supersedes=[*w["supersedes"], loser])

    def _supersede_errors(self, winner: dict[str, Any], loser_ref: str) -> list[str]:
        lo = self.claims.get(loser_ref)
        if lo is None or lo["promotion"] != "CANONICAL" or lo["lifecycle"] != "ACTIVE":
            return [f"SUPERSEDES_TARGET_NOT_ACTIVE:{loser_ref}"]
        if "valid_from" not in winner:
            return ["SUPERSEDER_VALID_FROM_REQUIRED"]
        if "valid_from" in lo and _t(winner["valid_from"]) < _t(lo["valid_from"]):
            return [f"SUPERSEDE_NOT_LATER:{loser_ref}"]
        return []

    # ---- Claim（加 Temporal／Lifecycle 欄位；revision＝前版 revision＋1）----
    def propose_claim(self, claim_id: str, claim_kind: str, content: str, observation_refs: list[str],
                      evidence_refs: list[str], *, valid_from: str | None = None, valid_to: str | None = None,
                      supersedes: list[str] | None = None) -> dict[str, Any]:
        sup = list(supersedes or [])
        if any(s not in self.claims or self.claims[s]["claim_kind"] != claim_kind for s in sup):
            raise ValueError("supersedes 須指向已存在且 claim_kind 相同的 Claim")
        if valid_from and valid_to and _t(valid_to) < _t(valid_from):
            raise ValueError("valid_to 不得早於 valid_from")
        rec = super().propose_claim(claim_id, claim_kind, content, observation_refs, evidence_refs)
        ref = rec["object_id"]
        observed = min((self.obs[o]["captured_at"] for o in observation_refs), key=_t)
        return self._replace(ref, lifecycle="ACTIVE", observed_at=observed, supersedes=sup, lifecycle_log=[],
                             valid_from=valid_from, valid_to=valid_to,
                             revision=max([self.claims[s]["revision"] for s in sup], default=0) + 1)

    def _promote_errors(self, claim: dict[str, Any]) -> list[str]:
        errs = [e for s in claim.get("supersedes", []) for e in self._supersede_errors(claim, s)]
        return errs + ([f"LIFECYCLE_NOT_LIVE:{claim['lifecycle']}"] if claim.get("lifecycle") not in (None, *LIVE) else [])

    def _after_promote(self, claim_ref: str) -> None:
        rev = self.claims[claim_ref]["revision"]
        for s in list(self.claims[claim_ref].get("supersedes", [])):
            self._apply_supersede(claim_ref, s, f"MACHINE:SUPERSEDES:{claim_ref}", f"revision {rev} promoted")

    # ---- Lifecycle ----
    def set_lifecycle(self, ref: str, to: str, *, by: str, rationale: str, expires_at: str | None = None) -> dict[str, Any]:
        cur = self.claims[ref]["lifecycle"]
        if to not in MANUAL.get(cur, set()):
            raise ValueError(f"LIFECYCLE_TRANSITION_INVALID:{cur}->{to}")
        if _blank(by, rationale):
            raise ValueError("ADJUDICATION_REQUIRED")
        if (to == "TEMPORARY") != bool(expires_at):
            raise ValueError("TEMPORARY 須附 expires_at，其他狀態不得附")
        if expires_at:
            _t(expires_at)
        return self._replace(ref, lifecycle=to, expires_at=expires_at, lifecycle_log=self._log(ref, to, by, rationale))

    def sweep_expired(self, now: str) -> list[str]:
        """TTL 算術（機器可確定）：TEMPORARY 到期→ARCHIVED（保留 lineage）。"""
        out = sorted(r for r, c in self.claims.items() if c.get("lifecycle") == "TEMPORARY" and _t(c["expires_at"]) <= _t(now))
        for r in out:
            self._replace(r, lifecycle="ARCHIVED", lifecycle_log=self._log(r, "ARCHIVED", "MACHINE:TTL", f"expired {self.claims[r]['expires_at']}"))
        return out

    # ---- Conflict（保留兩側，不抹平；P7）----
    def open_conflict(self, conflict_id: str, claim_a: str, claim_b: str, statement: str, *, by: str, opened_at: str) -> dict[str, Any]:
        ref = f"CONFLICT:{conflict_id}"
        if ref in self.conflicts:
            raise ValueError(f"Conflict 已存在: {ref}")
        if claim_a == claim_b or any(c not in self.claims or self.claims[c]["promotion"] == "REJECTED" for c in (claim_a, claim_b)):
            raise ValueError("Conflict 須指向兩個不同、已存在且未被拒絕的 Claim")
        if _blank(statement, by):
            raise ValueError("Conflict 須附 statement 與 by")
        if any({c["claim_a"], c["claim_b"]} == {claim_a, claim_b} and c["status"] == "UNRESOLVED" for c in self.conflicts.values()):
            raise ValueError("CONFLICT_DUPLICATE：同一對 Claim 已有未解 Conflict")
        a, b = self.claims[claim_a], self.claims[claim_b]
        rec = {"object_id": ref, "kind": "CONFLICT", "schema_version": "1.0", "claim_a": claim_a, "claim_b": claim_b,
               "source_refs_a": a["source_refs"], "source_refs_b": b["source_refs"], "revision_a": a["revision"],
               "revision_b": b["revision"], "observed_at_a": a["observed_at"], "observed_at_b": b["observed_at"],
               "statement": statement, "status": "UNRESOLVED", "opened_by": by, "opened_at": opened_at}
        self.conflicts[ref] = _seal(rec, "conflict")
        return rec

    def resolve_conflict(self, conflict_ref: str, outcome: str, *, by: str, rationale: str, winner: str | None = None,
                         rejected: str | None = None, evidence_refs: list[str] | None = None) -> dict[str, Any]:
        """證據不足＝BLOCK 並維持 UNRESOLVED（Brain 不得以「看起來合理」代替 Resolution）。"""
        c = self.conflicts[conflict_ref]
        a, b = c["claim_a"], c["claim_b"]
        ev = list(evidence_refs or [])
        errs = [] if c["status"] == "UNRESOLVED" else ["NOT_UNRESOLVED"]
        errs += ["ADJUDICATION_REQUIRED"] if _blank(by, rationale) else []
        res: dict[str, Any] = {"outcome": outcome, "by": by, "rationale": rationale}
        loser = None
        if outcome not in OUTCOMES:
            errs.append(f"OUTCOME_INVALID:{outcome}")
        elif outcome == "SUPERSEDES":
            loser = b if winner == a else a
            if winner not in (a, b):
                errs.append("WINNER_INVALID")
            else:
                errs += [f"CLAIM_NOT_CANONICAL:{x}" for x in (a, b) if self.claims[x]["promotion"] != "CANONICAL"]
                if self.claims[winner]["lifecycle"] != "ACTIVE":
                    errs.append(f"WINNER_NOT_ACTIVE:{winner}")
                errs += self._supersede_errors(self.claims[winner], loser)
                if not ev or any((self.evid.get(e) or {}).get("claim_ref") != winner or self.evid[e]["relation"] != "SUPPORTS" for e in ev):
                    errs.append("RESOLUTION_EVIDENCE_INSUFFICIENT")
            res.update(winner=winner, loser=loser, evidence_refs=ev)
        elif outcome == "COEXIST_DISJOINT_TIME":
            x, y = self.claims[a], self.claims[b]
            errs += [f"CLAIM_NOT_CANONICAL:{r}" for r in (a, b) if self.claims[r]["promotion"] != "CANONICAL"]
            ok = any(p.get("valid_to") and q.get("valid_from") and _t(p["valid_to"]) <= _t(q["valid_from"]) for p, q in ((x, y), (y, x)))
            if not ok:
                errs.append("INTERVALS_NOT_DISJOINT")
        elif outcome == "REJECTED_ONE":
            other = b if rejected == a else a
            if rejected not in (a, b) or self.claims[rejected]["promotion"] != "REJECTED":
                errs.append("CLAIM_NOT_REJECTED")
            elif self.claims[other]["promotion"] == "REJECTED":
                errs.append("BOTH_REJECTED")
            res.update(loser=rejected)
        if errs:
            return {"status": "BLOCK", "reason_codes": errs}
        if outcome == "SUPERSEDES":
            self._apply_supersede(winner, loser, f"MACHINE:CONFLICT:{conflict_ref}", f"resolved by {by}")  # type: ignore[arg-type]
        self.conflicts[conflict_ref] = _seal({**c, "status": "RESOLVED", "resolution": res}, "conflict")
        return {"status": "RESOLVED", "reason_codes": []}

    # ---- Rollback（P19：前版可回、lineage 保留）----
    def rollback(self, ref: str, *, by: str, rationale: str) -> dict[str, Any]:
        """撤回最新版：前版回 ACTIVE（valid_to 還原）、本版 ARCHIVED（保留於 lineage）、其解決的 Conflict 重開。"""
        cl = self.claims[ref]
        errs = ["ADJUDICATION_REQUIRED"] if _blank(by, rationale) else []
        if cl.get("lifecycle") != "ACTIVE" or not cl.get("supersedes"):
            errs.append("ROLLBACK_NOT_APPLICABLE")
        else:
            errs += [f"ROLLBACK_TARGET_MISMATCH:{p}" for p in cl["supersedes"]
                     if self.claims[p]["lifecycle"] != "SUPERSEDED" or self.claims[p]["lifecycle_log"][-1].get("superseded_by") != ref]
        if errs:
            return {"status": "BLOCK", "reason_codes": errs}
        for p in cl["supersedes"]:
            before = self.claims[p]["lifecycle_log"][-1].get("valid_to_before")
            self._replace(p, lifecycle="ACTIVE", valid_to=before, lifecycle_log=self._log(p, "ACTIVE", by, f"rollback of {ref}: {rationale}"))
        self._replace(ref, lifecycle="ARCHIVED", lifecycle_log=self._log(ref, "ARCHIVED", by, rationale))
        for cid, c in list(self.conflicts.items()):
            if c["status"] == "RESOLVED" and c["resolution"].get("winner") == ref:
                old = c["resolution"]
                rest = {k: v for k, v in c.items() if k not in ("resolution", "content_hash")}
                self.conflicts[cid] = _seal({**rest, "status": "UNRESOLVED", "reopened": [
                    *c.get("reopened", []), {"outcome": old["outcome"], "by": by, "rationale": f"rollback of {ref}: {rationale}"}]}, "conflict")
        return {"status": "ROLLED_BACK", "reason_codes": []}

    # ---- 視圖 ----
    def state_vector(self, ref: str) -> dict[str, Any]:
        cl = self.claims[ref]
        open_c = self._open_conflicts(ref)
        classes = {self.obs[o]["observation_class"] for o in cl["observation_refs"]}
        mine = set(cl["observation_refs"])
        obs_conflict = any(o["observation_class"] == "CONFLICT" and mine & set(o["conflict_with"]) for o in self.obs.values())
        epi = ("CONFLICTED" if open_c or obs_conflict else "UNKNOWN" if "UNKNOWN" in classes
               else "INFERRED" if "INFERENCE" in classes else "OBSERVED")
        adj = {"PROPOSED": "PROPOSED", "REJECTED": "REJECTED"}.get(cl["promotion"]) or ("DISPUTED" if open_c else "CONFIRMED")
        return {"epistemic": epi, "adjudication": adj, "lifecycle": cl["lifecycle"],
                "temporal": {k: cl.get(k) for k in ("valid_from", "valid_to", "observed_at")}, "open_conflicts": open_c}

    def valid_at(self, at: str, claim_kind: str | None = None) -> dict[str, list[str]]:
        """P8：預設取「該時點有效」而非「最近提到」。有未解 Conflict 者列 disputed，不混入 valid 也不隱藏。"""
        t = _t(at)
        out: dict[str, list[str]] = {"valid": [], "disputed": []}
        for ref, c in sorted(self.claims.items()):
            if c["promotion"] != "CANONICAL" or c.get("lifecycle") not in _VALID_NOW or (claim_kind and c["claim_kind"] != claim_kind):
                continue
            if c["lifecycle"] == "TEMPORARY" and _t(c["expires_at"]) <= t:
                continue
            if ("valid_from" in c and t < _t(c["valid_from"])) or ("valid_to" in c and t >= _t(c["valid_to"])):
                continue
            out["disputed" if self._open_conflicts(ref) else "valid"].append(ref)
        return out

    def history(self, ref: str) -> list[dict[str, Any]]:
        """lineage（含已撤回版本）：沿 supersedes 邊雙向走訪，依 revision 排序；每版帶 source／evidence 以供追溯。"""
        edges: dict[str, set[str]] = {r: set() for r in self.claims}
        for r, c in self.claims.items():
            for s in c.get("supersedes", []):
                edges[r].add(s)
                edges[s].add(r)
        seen, todo = {ref}, [ref]
        while todo:
            for n in edges[todo.pop()] - seen:
                seen.add(n)
                todo.append(n)
        return [{"claim": r, "revision": self.claims[r]["revision"], "promotion": self.claims[r]["promotion"],
                 "lifecycle": self.claims[r]["lifecycle"], "valid_from": self.claims[r].get("valid_from"),
                 "valid_to": self.claims[r].get("valid_to"), "source_refs": self.claims[r]["source_refs"],
                 "evidence_refs": self.claims[r]["evidence_refs"]}
                for r in sorted(seen, key=lambda x: (self.claims[x]["revision"], x))]

    # ---- Integrity（B2 gate＋B3）----
    def integrity_gate(self) -> dict[str, Any]:
        errs = list(super().integrity_gate()["errors"])
        for ref, c in self.claims.items():
            if "lifecycle" not in c:
                continue
            log = c["lifecycle_log"]
            if (log[-1]["to"] if log else "ACTIVE") != c["lifecycle"]:
                errs.append(f"LIFECYCLE_LOG_MISMATCH:{ref}")
            if c["lifecycle"] == "TEMPORARY" and "expires_at" not in c:
                errs.append(f"EXPIRES_AT_MISMATCH:{ref}")
            if "valid_from" in c and "valid_to" in c and _t(c["valid_to"]) < _t(c["valid_from"]):
                errs.append(f"VALID_RANGE_INVERTED:{ref}")
            errs += [f"SUPERSEDES_UNKNOWN:{ref}->{s}" for s in c["supersedes"] if s not in self.claims]
            if c["lifecycle"] == "SUPERSEDED" and not any(
                    ref in d.get("supersedes", []) and d["promotion"] == "CANONICAL" and d.get("lifecycle") in ("ACTIVE", "SUPERSEDED", "TEMPORARY")
                    for d in self.claims.values()):
                errs.append(f"SUPERSEDED_WITHOUT_SUCCESSOR:{ref}")
        for ref in self.claims:  # supersedes 環
            seen, todo = set(), list(self.claims[ref].get("supersedes", []))
            while todo:
                n = todo.pop()
                if n == ref:
                    errs.append(f"SUPERSEDES_CYCLE:{ref}")
                    break
                if n not in seen and n in self.claims:
                    seen.add(n)
                    todo += self.claims[n].get("supersedes", [])
        for cid, k in self.conflicts.items():
            if k["content_hash"] != content_hash(k):
                errs.append(f"HASH_MISMATCH:{cid}")
            errs += [f"CONFLICT_CLAIM_UNKNOWN:{cid}:{x}" for x in (k["claim_a"], k["claim_b"]) if x not in self.claims]
            res = k.get("resolution")
            if (k["status"] == "RESOLVED") != bool(res):
                errs.append(f"RESOLUTION_STATE_MISMATCH:{cid}")
            elif res and res["outcome"] == "SUPERSEDES" and res["loser"] not in self.claims.get(res["winner"], {}).get("supersedes", []):
                errs.append(f"RESOLUTION_NOT_APPLIED:{cid}")
        return {"status": "BLOCK" if errs else "PASS", "errors": errs}
