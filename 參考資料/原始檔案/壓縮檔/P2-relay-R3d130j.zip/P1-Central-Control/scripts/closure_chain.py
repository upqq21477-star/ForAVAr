#!/usr/bin/env python3
"""P2 closure_chain — FR-05 eight-step update closure check + FR-06 baseline guard (R4R-M3; stdlib only).

It only CHECKS a closure record; it never reads or writes the Current authority (callers pass a revision value).
Steps, in this order: SCOPE, IMPACT, ARTIFACTS, EVIDENCE, REGRESSION, LIFECYCLE, CURRENT, CLOSURE.
Result status: COMPLETE | INCOMPLETE (missing step / no ref / weak evidence) | REJECTED (order, duplicate, unknown step,
bad record) | STALE (baseline drifted).  Priority: REJECTED > STALE > INCOMPLETE > COMPLETE.

  python3 P1-Central-Control/scripts/closure_chain.py --simulate-closure   # producer -> consumer -> verifier -> feedback (SIMULATED_PASS)
  python3 P1-Central-Control/scripts/closure_chain.py --check <record.json> [--root <repo>]

Track A (manual equivalent, no code): 1) list the eight steps in order; 2) write one ref (file, commit or test output) per step;
3) tag each step with an evidence level (PROGRAM_EXECUTED_PASS / SIMULATED_PASS / STATIC_CHECK / DOC_ONLY / *_UNVERIFIED);
4) a step without a ref, or marked NOT_EXECUTED, means the chain is INCOMPLETE; 5) steps out of order mean REJECTED, redo the record;
6) before resuming, hash the files in change_radius and compare with the saved semantic_baseline_hash; a difference means STALE;
7) on STALE rebuild the baseline and rerun the chain; 8) only a COMPLETE chain may go to HANDOFF.
"""
from __future__ import annotations

import argparse
import json
import sys
import tempfile
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import continuation_context_box as ccb  # noqa: E402

STEPS = ("SCOPE", "IMPACT", "ARTIFACTS", "EVIDENCE", "REGRESSION", "LIFECYCLE", "CURRENT", "CLOSURE")
LEVELS = frozenset({"PROGRAM_EXECUTED_PASS", "SIMULATED_PASS", "STATIC_CHECK", "DOC_ONLY",
                    "IMPLEMENTED_UNVERIFIED", "PATCHED_UNVERIFIED"})
_DEMO_STEPS = tuple(STEPS)  # frozen copy: the simulation must notice if the canonical order is changed
NEXT = {"COMPLETE": "HANDOFF", "INCOMPLETE": "FILL_MISSING_STEPS",
        "REJECTED": "FIX_RECORD_ORDER_OR_NAMES", "STALE": "REBUILD_BASELINE_AND_RERUN"}


def _result(status: str, reasons: list[str]) -> dict[str, Any]:
    return {"status": status, "reasons": reasons, "next_action": NEXT[status]}


def evaluate(record: Any, root: Path | None = None, current_revision: Any = None) -> dict[str, Any]:
    if not isinstance(record, dict) or not isinstance(record.get("steps"), list):
        return _result("REJECTED", ["RECORD_SHAPE"])
    steps = record["steps"]
    if any(not isinstance(s, dict) for s in steps):
        return _result("REJECTED", ["STEP_NOT_OBJECT"])
    names = [s.get("step") for s in steps]
    reasons: list[str] = []
    unknown = [str(n) for n in names if n not in STEPS]
    if unknown:
        reasons.append("UNKNOWN_STEP:" + ",".join(unknown))
    if len(set(names)) != len(names):
        reasons.append("DUPLICATE_STEP")
    known = [STEPS.index(n) for n in names if n in STEPS]
    if known != sorted(known):
        reasons.append("ORDER_VIOLATION")
    if reasons:
        return _result("REJECTED", reasons)
    baseline = record.get("baseline")
    if baseline is not None:
        if root is None:
            return _result("REJECTED", ["BASELINE_ROOT_REQUIRED"])
        res = ccb.check_baseline(baseline, root, current_revision=current_revision)
        if res["status"] in ("REJECTED", "MISSING"):
            return _result("REJECTED", res["reasons"])
        if res["status"] == "STALE":
            return _result("STALE", res["reasons"])
    weak = [f"MISSING_STEP:{n}" for n in STEPS if n not in names]
    for s in steps:
        if not str(s.get("ref") or "").strip():
            weak.append(f"NO_REF:{s['step']}")
        level = s.get("evidence_level")
        if level == "NOT_EXECUTED":
            weak.append(f"NOT_EXECUTED:{s['step']}")
        elif level not in LEVELS:
            weak.append(f"BAD_LEVEL:{s['step']}")
    return _result("INCOMPLETE", weak) if weak else _result("COMPLETE", [])


def _demo_record(baseline: dict[str, Any] | None) -> dict[str, Any]:
    rec: dict[str, Any] = {"steps": [{"step": n, "ref": f"demo/{n.lower()}.txt", "evidence_level": "SIMULATED_PASS"} for n in _DEMO_STEPS]}
    if baseline is not None:
        rec["baseline"] = baseline
    return rec


def _demo_segment() -> dict[str, Any]:
    return {"segment_id": "SEG-CLOSE", "workflow_id": "WF-CLOSE", "system_id": "SYSTEM-CLOSE", "skill_id": "skill-close",
            "skill_version": "1.0", "objective": "resume", "input_scope": "simulate", "input_refs": ["INPUT:CLOSE"],
            "requested_outputs": ["result"], "constraints": ["CENTRAL_ONLY"], "stop_condition": ["done"],
            "failure_condition": ["fail"], "dependency_refs": [],
            "completion_contract": {"required_outputs": ["result"], "handoff_allowed": False},
            "context_cohort_id": "COHORT-CLOSE",
            "context_budget": {"estimated_total_context": 10, "target_context_budget": 20, "hard_context_ceiling": 40, "risk": "LOW"},
            "retry_policy": {"max_attempts": 1, "retry_on": []}, "timeout_ms": 1000}


def simulate() -> list[tuple[str, bool, str]]:
    """Closed loop on a temp mini repo with the real functions: producer (baseline+box) -> consumer (resume) ->
    verifier (closure chain) -> feedback (STALE -> rebuild -> COMPLETE)."""
    from packet_layer import build_attempt, build_task_packet

    out: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str = "") -> None:
        out.append((name, bool(ok), note))

    seg = _demo_segment()
    task = build_task_packet(seg, build_attempt(seg, attempt_number=1, started_at="2026-10-15T10:00:00+00:00"))
    current = {"revision": 7, "state_revision": 3, "current_stage": {"id": "M-SIM", "status": "BUILDING"},
               "next_exact_action": "WAIT_EXTERNAL_RESULT"}
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        (root / "sub").mkdir()
        (root / "a.txt").write_text("alpha\n", encoding="utf-8")
        (root / "sub" / "b.txt").write_text("beta\n", encoding="utf-8")
        (root / "outside.txt").write_text("free\n", encoding="utf-8")
        baseline = ccb.make_baseline(root, ["a.txt", "sub"], 7)
        box = ccb.build(current=current, task_packet=task, execution_record_ref=task["execution_record_ref"], baseline=baseline)
        rec("producer: box carries the baseline", box.get("baseline") == baseline)
        r = ccb.resume_check(current=current, task_packet=task, box=box, root=root)
        rec("consumer: resume OK while the baseline holds", r["status"] == "OK", str(r.get("reason")))
        (root / "outside.txt").write_text("changed outside the radius\n", encoding="utf-8")
        rec("consumer: change outside change_radius stays OK",
            ccb.resume_check(current=current, task_packet=task, box=box, root=root)["status"] == "OK")
        v = evaluate(_demo_record(baseline), root, 7)
        rec("verifier: full chain COMPLETE", v["status"] == "COMPLETE", str(v["reasons"]))
        (root / "sub" / "b.txt").write_text("beta changed\n", encoding="utf-8")
        r = ccb.resume_check(current=current, task_packet=task, box=box, root=root)
        rec("consumer: change inside radius -> STALE", r["status"] == "STALE" and "SEMANTIC_BASELINE_STALE" in r["reason"], str(r))
        v = evaluate(_demo_record(baseline), root, 7)
        rec("verifier: drifted baseline -> STALE", v["status"] == "STALE", str(v))
        rec("feedback: STALE asks for rebuild", v["next_action"] == "REBUILD_BASELINE_AND_RERUN")
        rebuilt = ccb.make_baseline(root, ["a.txt", "sub"], 7)
        v = evaluate(_demo_record(rebuilt), root, 7)
        rec("feedback: rebuilt baseline -> COMPLETE", v["status"] == "COMPLETE" and v["next_action"] == "HANDOFF", str(v))
        short = _demo_record(rebuilt)
        short["steps"].pop(3)
        rec("verifier: missing step -> INCOMPLETE", evaluate(short, root, 7)["status"] == "INCOMPLETE")
        swapped = _demo_record(rebuilt)
        swapped["steps"][1], swapped["steps"][2] = swapped["steps"][2], swapped["steps"][1]
        rec("verifier: swapped order -> REJECTED", evaluate(swapped, root, 7)["status"] == "REJECTED")
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--simulate-closure", action="store_true")
    ap.add_argument("--check", metavar="RECORD_JSON")
    ap.add_argument("--root", default=".")
    args = ap.parse_args()
    if args.check:
        res = evaluate(json.loads(Path(args.check).read_text(encoding="utf-8")), Path(args.root))
        print(json.dumps(res, ensure_ascii=False))
        return 0 if res["status"] == "COMPLETE" else 1
    if not args.simulate_closure:
        ap.print_help()
        return 2
    results = simulate()
    for name, ok, note in results:
        print(("PASS " if ok else "FAIL ") + name + ("" if ok or not note else f"  [{note}]"))
    bad = [n for n, ok, _ in results if not ok]
    print(f"closure simulation (SIMULATED_PASS): {len(results) - len(bad)}/{len(results)}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
