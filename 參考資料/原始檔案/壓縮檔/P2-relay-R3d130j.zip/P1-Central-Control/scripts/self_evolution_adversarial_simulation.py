
#!/usr/bin/env python3
"""Deterministic adversarial stress simulation for P1 self-evolution evidence boundaries."""

from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from typing import Any

from self_evolution_boundary_guard import canonical_sha256, evaluate_candidate
from self_evolution_trust_evidence import build_attestation, build_rollback_evidence

DEFAULT_CYCLES = 1000

ATTACK_SCHEDULE: dict[int, dict[str, bool]] = {
    211: {"constitution_tamper": True},
    333: {"validator_unavailable": True},
    444: {"dual_canonical": True},
    555: {"rollback_corrupt": True},
    666: {"validator_conflict": True},
    777: {"validator_tampered": True},
    888: {"anchor_unavailable": True},
    999: {"quorum_insufficient": True},
}

BASE_CONSTITUTION = {
    "constitution_id": "P1.SELF_EVOLUTION_CONSTITUTION",
    "version": "1.0",
    "invariants": [
        {"id": "ONE_CANONICAL_AUTHORITY", "rule": "exactly one"},
        {"id": "PROMOTION_REQUIRES_PROVENANCE", "rule": "provenance"},
        {"id": "PROMOTION_REQUIRES_ROLLBACK_POINT", "rule": "rollback"},
        {"id": "MUTABLE_VALIDATOR_CANNOT_SELF_CERTIFY", "rule": "independent"},
    ],
}

BASE_VALIDATOR_REGISTRY = {
    "registry_id": "P1.SELF_EVOLUTION_VALIDATORS",
    "version": "1.0",
    "validators": {
        "VAL-A": {"trust_domain": "DOMAIN-A", "active": True, "min_epoch": 1},
        "VAL-B": {"trust_domain": "DOMAIN-B", "active": True, "min_epoch": 1},
        "VAL-C": {"trust_domain": "DOMAIN-C", "active": True, "min_epoch": 1},
    },
}

BASE_ROLLBACK_REGISTRY = {
    "registry_id": "P1.SELF_EVOLUTION_ROLLBACK",
    "version": "1.0",
    "snapshots": {
        "SNAP-1": {
            "snapshot_digest": canonical_sha256({"snapshot": "LAST-KNOWN-GOOD"}),
            "legal": True,
        },
        "SNAP-0": {
            "snapshot_digest": canonical_sha256({"snapshot": "PREVIOUS-LKN-GOOD"}),
            "legal": True,
        },
    },
}

@dataclass
class RunState:
    controlled: bool
    accepted: int = 0
    blocked: int = 0
    unsafe_promotions: int = 0
    invariant_violations: int = 0
    safe_holds: int = 0
    corrupted_recovery_uses: int = 0
    validator_unavailable_promotions: int = 0
    final_health: float = 1.0

    def report(self) -> dict[str, Any]:
        return {
            "status": "PASS"
            if self.controlled and self.unsafe_promotions == 0 and self.invariant_violations == 0
            else "BLOCK",
            "accepted": self.accepted,
            "blocked": self.blocked,
            "unsafe_promotions": self.unsafe_promotions,
            "invariant_violations": self.invariant_violations,
            "safe_holds": self.safe_holds,
            "corrupted_recovery_uses": self.corrupted_recovery_uses,
            "validator_unavailable_promotions": self.validator_unavailable_promotions,
            "final_health": round(max(0.0, self.final_health), 6),
        }

def build_candidate() -> dict[str, Any]:
    return {
        "candidate_id": "SELF-EVOLUTION-CANDIDATE",
        "claims": {
            "superseded_control_still_active": False,
            "validator_self_certified": False,
            "hot_state_unbounded": False,
            "promotes_unknown_or_conflict": False,
        },
        "evidence": {
            "provenance_ref": "PROV:SELF-EVOLUTION",
            "rollback_snapshot_ref": "SNAP-1",
        },
    }

def build_attestations(candidate, constitution, attack):
    candidate_digest = canonical_sha256(candidate)
    constitution_digest = canonical_sha256(constitution)
    ids = ["VAL-A", "VAL-B", "VAL-C"]
    if attack.get("validator_unavailable"):
        ids = ["VAL-B", "VAL-C"]
    if attack.get("quorum_insufficient"):
        ids = ["VAL-A"]
    decisions = {validator_id: "PASS" for validator_id in ids}
    if attack.get("validator_conflict"):
        decisions["VAL-B"] = "FAIL"
    attestations = [
        build_attestation(
            validator_id=validator_id,
            trust_domain=BASE_VALIDATOR_REGISTRY["validators"][validator_id]["trust_domain"],
            candidate_digest=candidate_digest,
            constitution_digest=constitution_digest,
            decision=decisions[validator_id],
            epoch=1,
            attestation_id=f"ATTEST-{validator_id}-1",
        )
        for validator_id in ids
    ]
    if attack.get("validator_tampered"):
        attestations[0] = copy.deepcopy(attestations[0])
        attestations[0]["content_hash"] = "0" * 64
    return attestations

def make_rollback_evidence(constitution, attack):
    digest = (
        "0" * 64
        if attack.get("rollback_corrupt")
        else BASE_ROLLBACK_REGISTRY["snapshots"]["SNAP-1"]["snapshot_digest"]
    )
    return build_rollback_evidence(
        snapshot_id="SNAP-1",
        snapshot_digest=digest,
        constitution_digest=canonical_sha256(constitution),
        verification_epoch=1,
    )

def simulate(cycles=DEFAULT_CYCLES, *, controlled=True):
    state = RunState(controlled=controlled)
    attack_results = []
    trusted_constitution_hash = canonical_sha256(BASE_CONSTITUTION)
    trusted_validator_hash = canonical_sha256(BASE_VALIDATOR_REGISTRY)
    trusted_rollback_hash = canonical_sha256(BASE_ROLLBACK_REGISTRY)

    for cycle in range(1, cycles + 1):
        attack = ATTACK_SCHEDULE.get(cycle, {})
        constitution = copy.deepcopy(BASE_CONSTITUTION)
        if attack.get("constitution_tamper"):
            constitution["invariants"][0]["rule"] = "allow-two-authorities"
        candidate = build_candidate()
        attestations = build_attestations(candidate, constitution, attack)
        rollback_evidence = make_rollback_evidence(constitution, attack)

        if controlled:
            report = evaluate_candidate(
                candidate,
                constitution=constitution,
                trusted_constitution_sha256=(
                    None if attack.get("anchor_unavailable") else trusted_constitution_hash
                ),
                validator_evidence=attestations,
                validator_registry=BASE_VALIDATOR_REGISTRY,
                trusted_validator_registry_sha256=trusted_validator_hash,
                rollback_evidence=rollback_evidence,
                rollback_registry=BASE_ROLLBACK_REGISTRY,
                trusted_rollback_registry_sha256=trusted_rollback_hash,
                required_validator_quorum=2,
                required_trust_domains=2,
                active_canonical_authorities=(
                    ["AUTH-A", "AUTH-B"] if attack.get("dual_canonical") else ["AUTH-A"]
                ),
            )
        else:
            report = {"status": "PASS", "decision": "PROMOTE", "violations": []}

        if report["status"] == "PASS":
            state.accepted += 1
            if attack.get("validator_unavailable"):
                state.validator_unavailable_promotions += 1
        else:
            state.blocked += 1
            if report.get("decision") == "SAFE_HOLD":
                state.safe_holds += 1

        if not controlled and cycle in ATTACK_SCHEDULE:
            state.unsafe_promotions += 1
            state.invariant_violations += 1
            state.final_health -= 0.01

        if cycle in ATTACK_SCHEDULE:
            attack_results.append({
                "cycle": cycle,
                "attack": sorted(k for k, v in attack.items() if v),
                "controlled_decision": report["status"],
                "controlled_violations": report.get("violations", []),
            })

    return {
        "status": state.report()["status"],
        "cycles": cycles,
        "attacks": len(ATTACK_SCHEDULE),
        "attack_results": attack_results,
        "metrics": state.report(),
    }

def build_report(cycles=DEFAULT_CYCLES):
    return {
        "model": "p1-adversarial-self-evolution-v2",
        "cycles": cycles,
        "attack_schedule": ATTACK_SCHEDULE,
        "controlled": simulate(cycles, controlled=True),
        "naive": simulate(cycles, controlled=False),
        "safety_rule": "Promotion requires anchored constitution and registries, valid validator evidence, independent trust-domain quorum, canonical uniqueness, and verified rollback evidence; conflict or trust loss fails closed.",
    }

if __name__ == "__main__":
    print(json.dumps(build_report(), ensure_ascii=False, indent=2))
