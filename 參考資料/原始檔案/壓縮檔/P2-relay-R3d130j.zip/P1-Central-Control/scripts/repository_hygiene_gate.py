#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import subprocess
from collections import defaultdict
from pathlib import Path

BANNED_DIRS = {"runtime", "artifacts", "logs", "tmp", "temp", "outputs", "generated"}
BANNED_SUFFIXES = {".raw.json", ".trace.json", ".tmp", ".bak"}
VERSION_RE = re.compile(r"[-_ ]v\d+(?:\.\d+)*$", re.IGNORECASE)


def tracked_files(root: Path) -> list[str]:
    """Git's file list; without git (or outside a repo) the same files by directory walk."""
    try:
        proc = subprocess.run(
            ["git", "-c", "core.quotepath=false", "ls-files"],
            cwd=root,
            text=True,
            capture_output=True,
            check=True,
        )
        return [x for x in proc.stdout.splitlines() if x]
    except (subprocess.CalledProcessError, FileNotFoundError):
        return sorted(
            path.relative_to(root).as_posix()
            for path in root.rglob("*")
            if path.is_file() and ".git" not in path.parts
            and "__pycache__" not in path.parts and path.suffix != ".pyc"
        )


BUDGET_PATH = "P1-Central-Control/policy/repo_budget.json"


def measure(root: Path, paths: list[str]) -> dict[str, int]:
    """Actual bytes per budgeted path prefix (measured on disk, never self-reported)."""
    budgets = json.loads((root / BUDGET_PATH).read_text(encoding="utf-8"))["budgets"]
    sizes = {b["path"]: 0 for b in budgets}
    for rel in paths:
        file = root / rel
        if not file.is_file():
            continue
        for prefix in sizes:
            if rel.startswith(prefix):
                sizes[prefix] += file.stat().st_size
    return sizes


def budget_errors(root: Path, paths: list[str]) -> list[str]:
    if not (root / BUDGET_PATH).is_file():
        return []
    budgets = json.loads((root / BUDGET_PATH).read_text(encoding="utf-8"))["budgets"]
    sizes = measure(root, paths)
    return [
        f"over budget: {b['path'] or 'TOTAL'} {sizes[b['path']]} > {b['max_bytes']}"
        for b in budgets
        if sizes[b["path"]] > b["max_bytes"]
    ]


def validate(paths: list[str], root: Path | None = None) -> dict:
    errors = []
    warnings = []
    active_versioned: dict[str, list[str]] = defaultdict(list)

    for path in paths:
        parts = Path(path).parts
        lower_parts = {p.lower() for p in parts}

        if "歷史" in parts or "history" in lower_parts:
            continue

        # Archived material is out of the active set: not an "active version", not a legacy-looking active file.
        if path.startswith("docs/archive/"):
            continue

        # Evidence snapshots are intentionally tracked (class EVIDENCE); the banned-dir rule targets live runtime output.
        in_evidence = path.startswith("P1-Central-Control/evidence/")
        if not in_evidence and any(p in BANNED_DIRS for p in lower_parts):
            errors.append(f"runtime/generated path tracked: {path}")

        lower = path.lower()
        if any(lower.endswith(s) for s in BANNED_SUFFIXES):
            errors.append(f"raw/debug artifact tracked: {path}")

        stem = Path(path).stem
        match = VERSION_RE.search(stem)
        if match:
            active_versioned[VERSION_RE.sub("", stem)].append(path)

        if re.search(r"(?:^|[-_])(backup|old|deprecated)(?:[-_.]|$)", path, re.IGNORECASE):
            warnings.append(f"legacy-looking active file: {path}")

    for stem, files in active_versioned.items():
        if len(files) > 1:
            errors.append(
                "multiple active versions for canonical object: "
                + stem + " => " + ", ".join(sorted(files))
            )

    if root is not None:
        errors.extend(budget_errors(root, paths))

    return {
        "status": "BLOCK" if errors else "PASS",
        "tracked_file_count": len(paths),
        "errors": errors,
        "warnings": warnings,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="P1 repository hygiene gate")
    ap.add_argument("root", nargs="?", default=".")
    args = ap.parse_args()

    root = Path(args.root)
    result = validate(tracked_files(root), root)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 3 if result["status"] == "BLOCK" else 0


if __name__ == "__main__":
    raise SystemExit(main())
