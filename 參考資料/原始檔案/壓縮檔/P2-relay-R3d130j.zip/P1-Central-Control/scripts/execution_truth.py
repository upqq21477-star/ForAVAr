#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

from evidence_provenance_guard import guard_success

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "work_execution_record.schema.json"


def _validator() -> Draft202012Validator:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema, format_checker=FormatChecker())


def canonical_json(value: Any) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def manifest_hash(value: Any) -> str:
    return "sha256:" + hashlib.sha256(canonical_json(value)).hexdigest()


def execution_id_for(attempt_id: str) -> str:
    return f"exec-{attempt_id}"


def execution_ref_for(attempt_id: str) -> str:
    return f"EXECUTION:{execution_id_for(attempt_id)}"


def validate_execution_record(record: dict[str, Any]) -> None:
    errors = sorted(_validator().iter_errors(record), key=lambda item: list(item.path))
    if errors:
        raise ValueError(
            "work_execution_record.schema.json 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )


def _input_manifest(task_packet: dict[str, Any]) -> dict[str, Any]:
    return {
        "workflow_id": task_packet["workflow_id"],
        "segment_id": task_packet["segment_id"],
        "attempt_id": task_packet["attempt_id"],
        "skill_id": task_packet["skill_id"],
        "skill_version": task_packet["skill_version"],
        "input_refs": task_packet["input_refs"],
        "requested_outputs": task_packet["requested_outputs"],
        "constraints": task_packet["constraints"],
        "scope": task_packet["scope"],
    }


def _output_manifest(result_packet: dict[str, Any]) -> dict[str, Any]:
    return {
        "result_id": result_packet["result_id"],
        "decision_code": result_packet["decision_code"],
        "output_refs": result_packet["output_refs"],
        "unresolved": result_packet["unresolved"],
    }


def build_execution_record(
    task_packet: dict[str, Any],
    *,
    started_at: str | None = None,
) -> dict[str, Any]:
    attempt_id = task_packet["attempt_id"]
    execution_id = execution_id_for(attempt_id)
    start_time = started_at or datetime.now(timezone.utc).isoformat()
    record = {
        "execution_id": execution_id,
        "workflow_id": task_packet["workflow_id"],
        "segment_id": task_packet["segment_id"],
        "attempt_id": attempt_id,
        "skill_id": task_packet["skill_id"],
        "skill_version": task_packet["skill_version"],
        "status": "RUNNING",
        "decision_code": None,
        "input_hash": manifest_hash(_input_manifest(task_packet)),
        "output_hash": None,
        "start_time": start_time,
        "end_time": None,
        "verification_result": {
            "status": "PENDING",
            "verified_at": None,
            "checks": {
                "identity_bound": True,
                "input_bound": True,
                "output_bound": False,
                "usage_observed": False,
                "evidence_bound": False,
                "provenance_bound": False,
                "completion_contract_satisfied": False,
            },
        },
        "evidence_refs": [],
        "provenance_refs": [],
        "observed_usage": {
            "model_calls": 0,
            "tool_calls": 0,
            "wall_time_ms": 0,
            "observed": False,
        },
        "execution_record_ref": f"EXECUTION:{execution_id}",
    }
    validate_execution_record(record)
    return record


def _require_identity_match(execution: dict[str, Any], task_packet: dict[str, Any], result_packet: dict[str, Any]) -> None:
    pairs = (
        ("workflow_id", execution, task_packet),
        ("segment_id", execution, task_packet),
        ("attempt_id", execution, task_packet),
        ("skill_id", execution, task_packet),
        ("skill_version", execution, task_packet),
    )
    for field, left, right in pairs:
        if left[field] != right[field]:
            raise ValueError(f"{field} 與 TaskPacket 不一致")
    for field in ("workflow_id", "segment_id", "attempt_id", "skill_id", "skill_version"):
        if execution[field] != result_packet[field]:
            raise ValueError(f"{field} 與 ResultPacket 不一致")
    if task_packet["attempt_id"] != result_packet["attempt_id"]:
        raise ValueError("TaskPacket / ResultPacket attempt_id 不一致")
    if result_packet.get("execution_record_ref") != execution["execution_record_ref"]:
        raise ValueError("ResultPacket execution_record_ref 與 ExecutionRecord 不一致")


LATE_RESULT_DUPLICATE = "DUPLICATE"
LATE_RESULT_AFTER_NO_RESULT = "LATE_AFTER_NO_RESULT"


def classify_late_result(
    execution: dict[str, Any],
    attempt: dict[str, Any],
    task_packet: dict[str, Any],
    result_packet: dict[str, Any],
) -> str:
    """Read-only comparison of a result against an already-closed execution truth.

    Called only when execution["status"] != "RUNNING". It never mutates truth and
    never finalizes. It decides whether the result may be recorded as a late result:

      DUPLICATE             execution has a bound result and this is that same result
                            (same object_id, decision_code and output manifest hash).
      LATE_AFTER_NO_RESULT  execution closed without a result (TIMEOUT / CANCELLED);
                            the result is informational only and cannot reopen truth.

    Anything else is a conflict with Execution Truth and raises ValueError, so the
    caller rejects it before any store or workflow state is touched.
    """
    status = execution["status"]
    if status == "RUNNING":
        raise ValueError("classify_late_result 只處理已結束的 ExecutionRecord")
    _require_identity_match(execution, task_packet, result_packet)

    bound_ref = attempt.get("result_packet_ref")

    if status in {"SUCCEEDED", "FAILED"}:
        if not bound_ref:
            raise ValueError(
                f"EXECUTION_TRUTH_RESULT_UNBOUND: {status} Execution 未綁定 ResultPacket"
            )
        if result_packet["object_id"] != bound_ref:
            raise ValueError(
                "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:RESULT_REF "
                "Attempt 已綁定另一個 ResultPacket"
            )
        if result_packet["decision_code"] != execution.get("decision_code"):
            raise ValueError(
                "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:DECISION_CODE"
            )
        if manifest_hash(_output_manifest(result_packet)) != execution.get("output_hash"):
            raise ValueError(
                "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:OUTPUT_HASH"
            )
        return LATE_RESULT_DUPLICATE

    if status in {"TIMEOUT", "CANCELLED"}:
        if bound_ref:
            raise ValueError(
                "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:"
                f"{status} Execution 不應已綁定 ResultPacket"
            )
        return LATE_RESULT_AFTER_NO_RESULT

    raise ValueError(f"UNKNOWN_EXECUTION_STATUS:{status}")


def finalize_execution(
    execution: dict[str, Any],
    task_packet: dict[str, Any],
    result_packet: dict[str, Any],
    *,
    ended_at: str | None = None,
    evidence_records: list[dict[str, Any]] | None = None,
    provenance_records: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    if execution["status"] != "RUNNING":
        raise ValueError("ExecutionRecord 只有 RUNNING 可以完成驗證")
    _require_identity_match(execution, task_packet, result_packet)

    usage = result_packet.get("observed_usage", {})
    usage_observed = bool(result_packet.get("usage_observed", False))
    output_refs = list(result_packet.get("output_refs", []))
    success = result_packet["decision_code"] == "WORK_COMPLETE"

    checks = {
        "identity_bound": True,
        "input_bound": bool(execution["input_hash"]),
        "output_bound": bool(output_refs) if success else True,
        "usage_observed": usage_observed,
        "evidence_bound": bool(result_packet.get("evidence_refs")) if success else True,
        "provenance_bound": bool(result_packet.get("provenance_refs")) if success else True,
        "completion_contract_satisfied": (
            bool(output_refs)
            and len(output_refs) >= len(task_packet.get("requested_outputs", []))
            if success
            else True
        ),
    }

    verification_pass = all(checks.values())
    if not verification_pass:
        missing = [key for key, value in checks.items() if not value]
        raise ValueError(
            "Execution Truth 驗收失敗: " + ", ".join(missing)
        )

    current = deepcopy(execution)
    current["status"] = "SUCCEEDED" if success else "FAILED"
    current["decision_code"] = result_packet["decision_code"]
    current["output_hash"] = manifest_hash(_output_manifest(result_packet))
    current["end_time"] = ended_at or datetime.now(timezone.utc).isoformat()
    current["evidence_refs"] = list(result_packet.get("evidence_refs", []))
    current["provenance_refs"] = list(result_packet.get("provenance_refs", []))
    current["observed_usage"] = {
        "model_calls": int(usage.get("model_calls", 0)),
        "tool_calls": int(usage.get("tool_calls", 0)),
        "wall_time_ms": int(usage.get("wall_time_ms", 0)),
        "observed": usage_observed,
    }
    current["verification_result"] = {
        "status": "PASSED",
        "verified_at": current["end_time"],
        "checks": checks,
    }
    if success and evidence_records is not None and provenance_records is not None:
        guard_success(
            task_packet=task_packet,
            result_packet=result_packet,
            execution_record=current,
            evidence_records=evidence_records,
            provenance_records=provenance_records,
        )
    validate_execution_record(current)
    return current


def bind_attempt_result(
    attempt: dict[str, Any],
    result_packet: dict[str, Any],
    execution: dict[str, Any],
) -> dict[str, Any]:
    if attempt["attempt_id"] != execution["attempt_id"]:
        raise ValueError("Attempt / ExecutionRecord 不一致")
    if result_packet["attempt_id"] != attempt["attempt_id"]:
        raise ValueError("Attempt / ResultPacket 不一致")
    if result_packet.get("execution_record_ref") != attempt["execution_record_ref"]:
        raise ValueError("Attempt / ResultPacket execution_record_ref 不一致")

    updated = deepcopy(attempt)
    updated["ended_at"] = execution["end_time"]
    updated["result_packet_ref"] = result_packet["object_id"]
    updated["output_hash"] = execution["output_hash"]
    updated["status"] = "SUCCESS" if result_packet["decision_code"] == "WORK_COMPLETE" else "FAILED"
    return updated


def timeout_execution(
    execution: dict[str, Any],
    *,
    ended_at: str | None = None,
) -> dict[str, Any]:
    if execution["status"] != "RUNNING":
        raise ValueError("只有 RUNNING Execution 可以 timeout")
    updated = deepcopy(execution)
    updated["status"] = "TIMEOUT"
    updated["decision_code"] = None
    updated["end_time"] = ended_at or datetime.now(timezone.utc).isoformat()
    updated["verification_result"] = {
        "status": "PASSED",
        "verified_at": updated["end_time"],
        "checks": {
            "identity_bound": True,
            "input_bound": bool(updated["input_hash"]),
            "output_bound": True,
            "usage_observed": False,
            "evidence_bound": True,
            "provenance_bound": True,
            "completion_contract_satisfied": True,
        },
    }
    validate_execution_record(updated)
    return updated


def cancel_execution(
    execution: dict[str, Any],
    *,
    ended_at: str | None = None,
) -> dict[str, Any]:
    if execution["status"] != "RUNNING":
        raise ValueError("只有 RUNNING Execution 可以 cancel")
    updated = deepcopy(execution)
    updated["status"] = "CANCELLED"
    updated["decision_code"] = None
    updated["end_time"] = ended_at or datetime.now(timezone.utc).isoformat()
    updated["verification_result"] = {
        "status": "PASSED",
        "verified_at": updated["end_time"],
        "checks": {
            "identity_bound": True,
            "input_bound": bool(updated["input_hash"]),
            "output_bound": True,
            "usage_observed": False,
            "evidence_bound": True,
            "provenance_bound": True,
            "completion_contract_satisfied": True,
        },
    }
    validate_execution_record(updated)
    return updated
