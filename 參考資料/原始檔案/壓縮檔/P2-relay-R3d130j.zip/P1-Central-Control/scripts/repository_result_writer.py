#!/usr/bin/env python3
"""Persist an existing canonical ResultPacket into the repository.

This is a persistence adapter only. It does not create a second result
taxonomy, mutate Current, retry work, or decide program truth.
"""

from __future__ import annotations

import argparse
import json
import os
import re
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
RESULT_ROOT = ROOT / "P1-Central-Control" / "results"


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"RESULT_PACKET_OBJECT_REQUIRED:{path}")
    return value


def _validate(packet: dict[str, Any]) -> None:
    import sys
    sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
    from packet_layer import validate_result_packet
    validate_result_packet(packet)


def _filename(result_id: str) -> str:
    token = re.sub(r"[^A-Za-z0-9._-]+", "_", result_id).strip("_")
    if not token:
        raise ValueError("RESULT_ID_PATH_TOKEN_EMPTY")
    return token[:180] + ".json"


def result_path(result_id: str, root: Path = ROOT) -> Path:
    return root / "P1-Central-Control" / "results" / _filename(result_id)


def _canonical_bytes(packet: dict[str, Any]) -> bytes:
    return (json.dumps(packet, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def persist(
    packet: dict[str, Any],
    *,
    root: Path = ROOT,
) -> dict[str, Any]:
    _validate(packet)
    result_id = packet["result_id"]
    target = result_path(result_id, root)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = _canonical_bytes(packet)

    if target.exists():
        existing = target.read_bytes()
        if existing == payload:
            return {
                "status": "IDEMPOTENT_REPLAY",
                "result_id": result_id,
                "path": str(target.relative_to(root)),
            }
        raise ValueError(
            "RESULT_ID_CONFLICT:" + result_id
        )

    temp = target.with_suffix(".tmp")
    temp.write_bytes(payload)
    os.replace(temp, target)

    return {
        "status": "CREATED",
        "result_id": result_id,
        "path": str(target.relative_to(root)),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Persist canonical ResultPacket")
    parser.add_argument("--result-packet", required=True)
    args = parser.parse_args()

    result = persist(_load(Path(args.result_packet).resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
