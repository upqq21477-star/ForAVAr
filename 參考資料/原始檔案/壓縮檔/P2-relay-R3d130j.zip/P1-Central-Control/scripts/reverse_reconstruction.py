#!/usr/bin/env python3
"""Compatibility entrypoint for progressive reverse reconstruction."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
REQUEST_SCHEMA = ROOT / "P1-Central-Control/schemas/reverse_reconstruction_request.schema.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/reverse_reconstruction_result.schema.json"

sys.path.insert(0, str(Path(__file__).resolve().parent))
from progressive_repository_scanner import execute as progressive_scan


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any], schema_path: Path) -> None:
    schema = _load(schema_path)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(value),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def execute(request: dict[str, Any]) -> dict[str, Any]:
    _validate(request, REQUEST_SCHEMA)
    suffix = request["request_id"].split(":", 1)[1]
    scan_request = {
        "schema_version": "1.0",
        "request_id": "SCAN:" + suffix,
        "root_path": request["root_path"],
        "focus_paths": request.get("focus_paths", []),
        "exclude_dirs": request.get("exclude_dirs", []),
        # 逆向重建本身就是明確的整庫重建請求；scanner 預設 TARGETED（只掃焦點與其本地 import），
        # 需明示 BOUNDED_RECONSTRUCTION 才會列舉整棵樹（受 max_inventory_files 限制）。
        "inventory_mode": "BOUNDED_RECONSTRUCTION",
        "max_inventory_files": request.get("max_inventory_files", 10000),
        "max_deep_read_files": request.get("max_focus_files", 8),
        "max_deep_read_bytes": 20000,
        "target_context_budget": 12000,
        "hard_context_ceiling": 20000,
    }
    result = progressive_scan(scan_request)
    projection = dict(result["reverse_reconstruction"])
    projection["request_id"] = request["request_id"]
    _validate(projection, RESULT_SCHEMA)
    return projection


def main() -> int:
    parser = argparse.ArgumentParser(description="Run progressive reverse reconstruction")
    parser.add_argument("request")
    args = parser.parse_args()
    result = execute(_load(Path(args.request).resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
