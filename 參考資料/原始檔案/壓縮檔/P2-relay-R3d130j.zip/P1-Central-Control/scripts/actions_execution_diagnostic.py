#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_diagnostic.schema.json"


class ActionsDiagnosticError(ValueError):
    pass


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ActionsDiagnosticError(f"{path} 必須是 JSON object")
    return value


def validate(value: dict[str, Any]) -> None:
    Draft202012Validator(load(SCHEMA)).validate(value)


def steps_evidence(job: dict[str, Any]) -> str:
    if job.get("steps") is None:
        return "NULL"
    if job.get("steps") == []:
        return "EMPTY"
    return "PRESENT"


def runner_assigned(job: dict[str, Any]) -> bool:
    runner_id = job.get("runner_id")
    runner_name = job.get("runner_name")
    return bool(runner_name) or (isinstance(runner_id, int) and runner_id > 0)


def elapsed_seconds(job: dict[str, Any]) -> float | None:
    started = job.get("started_at")
    completed = job.get("completed_at")
    if not started or not completed:
        return None
    try:
        start = datetime.fromisoformat(started.replace("Z", "+00:00"))
        end = datetime.fromisoformat(completed.replace("Z", "+00:00"))
    except (TypeError, ValueError):
        return None
    return round((end - start).total_seconds(), 3)


def classify_job(job: dict[str, Any]) -> str:
    status = job.get("status")
    conclusion = job.get("conclusion")
    evidence = steps_evidence(job)
    if status != "completed":
        return "INCOMPLETE"
    if conclusion == "success":
        return "PASS"
    if conclusion in {"failure", "cancelled", "timed_out"} and (
        evidence in {"NULL", "EMPTY"} or not runner_assigned(job)
    ):
        return "RUNNER_STARTUP_FAILURE"
    if conclusion in {"failure", "cancelled", "timed_out"} and evidence == "PRESENT":
        return "WORKFLOW_EXECUTION_FAILURE"
    return "UNKNOWN"


def classify_run(run: dict[str, Any], jobs: list[dict[str, Any]]) -> str:
    status = run.get("status")
    conclusion = run.get("conclusion")
    if not jobs:
        return "NOT_DISPATCHED"
    if status != "completed":
        return "INCOMPLETE"
    classes = [classify_job(job) for job in jobs]
    if any(item == "WORKFLOW_EXECUTION_FAILURE" for item in classes):
        return "WORKFLOW_EXECUTION_FAILURE"
    if any(item == "RUNNER_STARTUP_FAILURE" for item in classes):
        return "RUNNER_STARTUP_FAILURE"
    if conclusion == "success" and all(item == "PASS" for item in classes):
        return "PASS"
    if conclusion in {"failure", "cancelled", "timed_out"}:
        return "UNKNOWN"
    return "UNKNOWN"


def build(run: dict[str, Any], jobs_doc: dict[str, Any]) -> dict[str, Any]:
    jobs = jobs_doc.get("jobs")
    if not isinstance(jobs, list):
        raise ActionsDiagnosticError("jobs 必須是 array")

    run_id = run.get("id") or run.get("run_id")
    if run_id is None:
        raise ActionsDiagnosticError("workflow run 缺少 id")

    run_head_sha = run.get("head_sha")
    if run_head_sha is not None and (not isinstance(run_head_sha, str) or len(run_head_sha) < 7):
        raise ActionsDiagnosticError("workflow run head_sha invalid")

    job_records = []
    runner_seen = False
    step_observed = False
    logs_available = False

    for job in jobs:
        job_head_sha = job.get("head_sha")
        if (
            run_head_sha
            and isinstance(job_head_sha, str)
            and len(job_head_sha) >= 7
            and job_head_sha != run_head_sha
        ):
            raise ActionsDiagnosticError("RUN_JOB_HEAD_SHA_MISMATCH")

        evidence = steps_evidence(job)
        job_class = classify_job(job)
        assigned = runner_assigned(job)
        runner_seen = runner_seen or assigned
        step_observed = step_observed or evidence == "PRESENT"
        logs_available = logs_available or bool(job.get("logs_url"))

        labels = job.get("labels")
        if not isinstance(labels, list):
            labels = []

        job_records.append({
            "job_id": job.get("id"),
            "name": job.get("name", "unknown"),
            "status": job.get("status"),
            "conclusion": job.get("conclusion"),
            "runner_id": job.get("runner_id"),
            "runner_name": job.get("runner_name", ""),
            "runner_group_id": job.get("runner_group_id"),
            "steps_evidence": evidence,
            "step_count": len(job.get("steps", [])) if isinstance(job.get("steps"), list) else 0,
            "classification": job_class,
            "labels": labels,
            "started_at": job.get("started_at"),
            "completed_at": job.get("completed_at"),
            "elapsed_seconds": elapsed_seconds(job),
        })

    result = {
        "diagnostic_id": f"ACTIONS_DIAGNOSTIC:{run_id}",
        "run_status": run.get("status"),
        "run_conclusion": run.get("conclusion"),
        "head_sha": run_head_sha,
        "classification": classify_run(run, jobs),
        "job_count": len(jobs),
        "jobs": job_records,
        "evidence": {
            "runner_assigned": runner_seen,
            "step_execution_observed": step_observed,
            "logs_available": logs_available,
        },
    }
    validate(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 GitHub Actions execution diagnostic")
    parser.add_argument("run")
    parser.add_argument("jobs")
    parser.add_argument("output")
    args = parser.parse_args()
    result = build(load(Path(args.run)), load(Path(args.jobs)))
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
