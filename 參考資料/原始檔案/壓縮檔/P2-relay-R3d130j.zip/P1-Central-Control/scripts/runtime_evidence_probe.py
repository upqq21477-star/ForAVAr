#!/usr/bin/env python3
"""Execute an explicit, shell-free runtime probe and emit bounded evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import time
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
REQUEST_SCHEMA = ROOT / "P1-Central-Control/schemas/runtime_evidence_probe.schema.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/runtime_evidence_result.schema.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any], schema_path: Path) -> None:
    schema = _load(schema_path)
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def _hash_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def execute(request: dict[str, Any]) -> dict[str, Any]:
    _validate(request, REQUEST_SCHEMA)
    root = Path(request["root_path"]).resolve()
    if not root.is_dir():
        raise ValueError("ROOT_PATH_UNAVAILABLE")

    timeout = request.get("timeout_seconds", 120)
    expected = request.get("expected_exit_code", 0)
    env = None
    requested_keys = request.get("environment_keys", [])
    if requested_keys:
        env = {key: os.environ[key] for key in requested_keys if key in os.environ}

    started = time.monotonic()
    try:
        completed = subprocess.run(
            request["command"],
            cwd=root,
            env=env,
            shell=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout,
            check=False,
        )
        duration_ms = int((time.monotonic() - started) * 1000)
        status = "PASS" if completed.returncode == expected else "FAIL"
        result = {
            "schema_version": "1.0",
            "probe_id": request["probe_id"],
            "status": status,
            "return_code": completed.returncode,
            "duration_ms": duration_ms,
            "stdout_sha256": _hash_bytes(completed.stdout),
            "stderr_sha256": _hash_bytes(completed.stderr),
            "evidence_class": "OBSERVED_RUNTIME",
            "expected_exit_code": expected,
            "error": None,
        }
    except subprocess.TimeoutExpired:
        duration_ms = int((time.monotonic() - started) * 1000)
        result = {
            "schema_version": "1.0",
            "probe_id": request["probe_id"],
            "status": "TIMEOUT",
            "return_code": None,
            "duration_ms": duration_ms,
            "stdout_sha256": _hash_bytes(b""),
            "stderr_sha256": _hash_bytes(b""),
            "evidence_class": "OBSERVED_RUNTIME",
            "expected_exit_code": expected,
            "error": f"timeout_seconds={timeout}",
        }
    except OSError as exc:
        duration_ms = int((time.monotonic() - started) * 1000)
        result = {
            "schema_version": "1.0",
            "probe_id": request["probe_id"],
            "status": "ERROR",
            "return_code": None,
            "duration_ms": duration_ms,
            "stdout_sha256": _hash_bytes(b""),
            "stderr_sha256": _hash_bytes(b""),
            "evidence_class": "OBSERVED_RUNTIME",
            "expected_exit_code": expected,
            "error": str(exc),
        }

    _validate(result, RESULT_SCHEMA)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Run an explicit shell-free runtime evidence probe")
    parser.add_argument("request")
    args = parser.parse_args()
    result = execute(_load(Path(args.request).resolve()))
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if result["status"] != "ERROR" else 1


if __name__ == "__main__":
    raise SystemExit(main())
