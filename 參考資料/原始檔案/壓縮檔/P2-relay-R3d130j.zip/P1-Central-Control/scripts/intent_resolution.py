#!/usr/bin/env python3
"""Bounded, conservative intent resolution for P2-F24; this is not an LLM."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[2]
SCHEMA_REF="P1-Central-Control/schemas/intent_resolution.schema.json"
FACT_STATUSES={"OBSERVED","CONFIRMED","INFERRED","UNKNOWN","CONFLICT"}
LABEL_HINTS={
 "xray":"STRUCTURED_ANALYSIS","diagram":"DIAGRAM_AS_CODE","deepthink":"STRUCTURED_REASONING",
 "critique":"ADVERSARIAL_REVIEW","debug":"DIAGNOSTIC_ANALYSIS"
}
AMBIGUOUS_TERMS=("優化","改善","處理一下","幫我弄","弄好","optimize","improve","handle this","fix it")
HIGH_RISK_TERMS=("刪除","永久移除","封存","刪庫","部署到正式環境","付費","付款","權限提升","改變權限","delete","destroy","production deploy","paid","credential","permission escalation")

class IntentResolutionError(ValueError): pass

def _text(value:Any,field:str,limit:int=4000)->str:
 if not isinstance(value,str) or not value.strip() or len(value)>limit:
  raise IntentResolutionError(f"INTENT_{field.upper()}_INVALID")
 return value.strip()

def _facts(value:Any)->list[dict[str,Any]]:
 if not isinstance(value,list) or len(value)>50: raise IntentResolutionError("INTENT_CONTEXT_FACTS_INVALID")
 result=[]
 for fact in value:
  if not isinstance(fact,dict) or fact.get("status") not in FACT_STATUSES:
   raise IntentResolutionError("INTENT_FACT_STATUS_INVALID")
  statement=_text(fact.get("statement"),"FACT_STATEMENT",1500)
  source=fact.get("source_ref")
  if source is not None and (not isinstance(source,str) or not source.strip() or len(source)>500 or source.strip().startswith(("/","\\")) or ".." in Path(source.strip()).parts):
   raise IntentResolutionError("INTENT_FACT_SOURCE_REF_INVALID")
  result.append({"status":fact["status"],"statement":statement,"source_ref":source.strip() if isinstance(source,str) else None})
 return result

def _category(text:str)->str:
 t=text.casefold()
 if any(x in t for x in ("權限","權威","角色職權","permission","authority","authorization","p1-current","current authority","change current")): return "CHANGE_AUTHORITY"
 if any(x in t for x in ("刪除","永久移除","封存","刪庫","delete","destroy","archive")): return "DELETE_OR_ARCHIVE"
 if any(x in t for x in ("圖表","流程圖","視覺化","diagram","chart","visualize")): return "VISUALIZE"
 if any(x in t for x in ("比較","compare","compare options")): return "COMPARE"
 if any(x in t for x in ("摘要","統整","總結","summarize","summary","list current progress")): return "SUMMARIZE"
 if any(x in t for x in ("解釋","說明","explain","describe")): return "EXPLAIN"
 if any(x in t for x in ("搜尋","查找","找出","search","find")): return "SEARCH"
 if any(x in t for x in ("修復","修正","除錯","debug","repair","fix the bug","fix error")): return "REPAIR"
 if any(x in t for x in ("建立","新增","實作","施工","撰寫程式","implement","build","create","write code")): return "IMPLEMENT"
 if any(x in t for x in ("分析","評估","診斷","analyze","analyse","assess","diagnose","critique")): return "ANALYZE"
 return "UNKNOWN"

def _clarification_options(text:str, facts:list[dict[str,Any]])->list[dict[str,str]]:
 # Bounded default options; labels are options, not inferred user approvals.
 return [
  {"option_id":"INTENT-1","label":"釐清目標與成功條件","interpretation":"先整理想達到的結果、範圍及不可變限制。","consequence":"不會直接修改程式或權威文件。"},
  {"option_id":"INTENT-2","label":"檢查問題並提出方案","interpretation":"先分析現況與證據，列出根因假說及可比較的方案。","consequence":"僅形成分析／建議，執行前仍需範圍與權限確認。"},
  {"option_id":"INTENT-3","label":"直接施工一個明確子目標","interpretation":"由使用者指定單一可交付成果、目標路徑與驗收條件。","consequence":"只有範圍可判定且已授權時才可修改。"},
 ]

def resolve_intent(request:dict[str,Any])->dict[str,Any]:
 if not isinstance(request,dict): raise IntentResolutionError("INTENT_REQUEST_OBJECT_REQUIRED")
 request_id=_text(request.get("request_id"),"REQUEST_ID",120)
 raw=_text(request.get("user_text"),"USER_TEXT")
 correction=request.get("user_correction")
 if correction is not None and (not isinstance(correction,str) or len(correction)>4000):
  raise IntentResolutionError("INTENT_CORRECTION_INVALID")
 corrected=isinstance(correction,str) and bool(correction.strip())
 effective=correction.strip() if corrected else raw
 facts=_facts(request.get("context_facts",[]))
 constraints=request.get("constraints",[])
 if not isinstance(constraints,list) or len(constraints)>30 or any(not isinstance(x,str) or not x.strip() or len(x)>1000 for x in constraints):
  raise IntentResolutionError("INTENT_CONSTRAINTS_INVALID")
 scope=request.get("explicit_scope")
 if scope is not None: scope=_text(scope,"EXPLICIT_SCOPE",1000)
 labels=[]
 for label,hint in LABEL_HINTS.items():
  if re.search(r"(?<!\w)/"+re.escape(label)+r"(?!\w)",effective,re.IGNORECASE):
   labels.append({"label":"/"+label,"method_hint":hint,"not_hidden_command":True})
 intent_text=re.sub(r"/(?:xray|diagram|deepthink|critique|debug)\b","",effective,flags=re.IGNORECASE)
 category=_category(intent_text)
 lower=effective.casefold()
 generic=any(term in lower for term in AMBIGUOUS_TERMS)
 has_conflict=any(f["status"]=="CONFLICT" for f in facts)
 high_risk=category in {"DELETE_OR_ARCHIVE","CHANGE_AUTHORITY"} or any(x in lower for x in HIGH_RISK_TERMS)
 confirmation=category in {"DELETE_OR_ARCHIVE","CHANGE_AUTHORITY"} or high_risk
 auth_status="GOVERNANCE_REVIEW_REQUIRED" if category=="CHANGE_AUTHORITY" else ("CONFIRMATION_REQUIRED" if confirmation else "NOT_REQUIRED")
 options=[]
 warnings=[]
 if any(f["status"] in {"UNKNOWN","CONFLICT"} for f in facts):
  warnings.append("Context includes UNKNOWN/CONFLICT facts; they are not treated as resolved intent or confirmed world state.")
 if labels:
  warnings.append("Slash labels are mapped to ordinary method/capability hints, not treated as built-in hidden commands.")
 if generic or category=="UNKNOWN":
  status="CONFLICT_REQUIRES_CLARIFICATION" if has_conflict else "NEEDS_CLARIFICATION"
  options=_clarification_options(effective,facts)
  warnings.append("Intent remains unresolved; the selector has not chosen an execution target.")
 else:
  status="CONFLICT_REQUIRES_CLARIFICATION" if has_conflict else "RESOLVED"
  if has_conflict: options=_clarification_options(effective,facts)
 if confirmation:
  warnings.append("High-impact intent is not authorization; explicit confirmation and applicable governance checks remain required.")
 if corrected:
  warnings.append("Explicit user correction overrides prior inference for this request; it does not silently rewrite persistent policy.")
 return {
  "request_id":request_id,"status":status,"intent_category":category,
  "normalized_goal":effective,"explicit_scope":scope,"constraints":[x.strip() for x in constraints],
  "needs_clarification":status in {"NEEDS_CLARIFICATION","CONFLICT_REQUIRES_CLARIFICATION"},
  "clarification_options":options,"source_facts":facts,"slash_labels_as_capability_hints":labels,
  "correction_overrides_prior_inference":corrected,"confirmation_required":confirmation,
  "authorization_status":auth_status,"warnings":warnings
 }

def validate_result(result:dict[str,Any],root:Path=ROOT)->None:
 path=root/SCHEMA_REF
 if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
  raise IntentResolutionError("INTENT_SCHEMA_PATH_INVALID")
 try:
  from jsonschema import Draft202012Validator
  schema=json.loads(path.read_text(encoding="utf-8"))
  Draft202012Validator.check_schema(schema); Draft202012Validator(schema).validate(result)
 except IntentResolutionError: raise
 except Exception as exc: raise IntentResolutionError(f"INTENT_RESULT_SCHEMA_INVALID:{type(exc).__name__}") from exc

def main()->int:
 parser=argparse.ArgumentParser(description="Resolve intent conservatively and return bounded clarification options")
 parser.add_argument("--request",required=True); parser.add_argument("--output")
 args=parser.parse_args()
 try:
  result=resolve_intent(json.loads(Path(args.request).read_text(encoding="utf-8"))); validate_result(result)
  rendered=json.dumps(result,ensure_ascii=False,indent=2)+"\n"
  if args.output: Path(args.output).write_text(rendered,encoding="utf-8")
  print(rendered,end=""); return 0 if result["status"]=="RESOLVED" else 2
 except (OSError,json.JSONDecodeError,IntentResolutionError) as exc:
  print(json.dumps({"status":"BLOCKED","reason_code":str(exc).split(":",1)[0],"detail":str(exc)},ensure_ascii=False,indent=2)); return 2

if __name__=="__main__": raise SystemExit(main())
