#!/usr/bin/env python3
"""Deterministic requirement ranking and guarded P2 blueprint update transaction."""
from __future__ import annotations
import argparse, hashlib, json, os, tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
CURRENT_REF = "P1-CURRENT.json"
MANIFEST_REF = "P1-Central-Control/progress/P2-B1-B8.feature-batch.json"
WORK_REF = "P1-Central-Control/progress/P2-B1-B8.work.json"
CONSTRUCTION_REF = "P1-Central-Control/progress/construction/P2-B1-B8.construction.json"
BLUEPRINT_REF = "docs/architecture/P2-System-Blueprint-v1.0.md"
ROADMAP_REF = "docs/plans/P2-Relay-Update-Plan.md"
MATRIX_REF = "docs/plans/P2-Feature-Triage.md"
TEST_STRATEGY_REF = "docs/plans/P2-Relay-Update-Plan.md"
REQUEST_SCHEMA_REF = "P1-Central-Control/schemas/blueprint_update_request.schema.json"
RESULT_SCHEMA_REF = "P1-Central-Control/schemas/blueprint_update_assessment.schema.json"
TIERS = {"P0_BLOCKED": 0, "P1_CORE": 1, "P2_FOUNDATION": 2, "P3_REQUIRED": 3, "P4_DEFER": 4}
DISPOSITIONS = {"NO_REWORK_REQUIRED", "DOC_SYNC_REQUIRED", "REVALIDATION_REQUIRED", "REWORK_REQUIRED", "BLOCKED_UNKNOWN"}
OWNERS = {ROADMAP_REF: "EVOLUTION", MATRIX_REF: "EVOLUTION", TEST_STRATEGY_REF: "EVOLUTION", WORK_REF: "CENTRAL", CONSTRUCTION_REF: "CENTRAL", MANIFEST_REF: "CENTRAL", CURRENT_REF: "CURRENT_AUTHORITY"}
INVALIDATED = {"LOCAL_CASE_RECEIPTS", "CLOSURE_EVIDENCE", "OFFICIAL_TEST_ROSTER", "FINAL_TEST_ADMISSION"}

class BlueprintUpdateError(ValueError): pass

def _sha(data: bytes) -> str: return hashlib.sha256(data).hexdigest()
def sha256_file(path: Path) -> str: return _sha(path.read_bytes())
def _hash(value: Any) -> bool: return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)
def _safe_path(root: Path, ref: str) -> Path:
    if root.is_symlink() or not isinstance(ref, str) or not ref.strip() or ref.startswith(("/", "\\")) or ".." in Path(ref).parts:
        raise BlueprintUpdateError("BLUEPRINT_UPDATE_PATH_INVALID")
    base = root.resolve(); path = base / ref
    try: path.resolve(strict=False).relative_to(base)
    except ValueError as exc: raise BlueprintUpdateError("BLUEPRINT_UPDATE_PATH_ESCAPE") from exc
    cursor = path
    while cursor != base:
        if cursor.is_symlink(): raise BlueprintUpdateError("BLUEPRINT_UPDATE_SYMLINK_FORBIDDEN")
        cursor = cursor.parent
    return path

def _json(root: Path, ref: str, code: str) -> dict:
    try: value = json.loads(_safe_path(root, ref).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc: raise BlueprintUpdateError(f"{code}:{type(exc).__name__}") from exc
    if not isinstance(value, dict): raise BlueprintUpdateError(code + ":OBJECT_REQUIRED")
    return value

def _scope_fingerprint(manifest: dict) -> str:
    """Exact immutable-intent algorithm shared with feature_batch_orchestrator."""
    try:
        rows = [manifest["batch_id"]]
        rows += [f"W|{x['section_id']}|{','.join(sorted(x['feature_ids']))}" for x in sorted(manifest["workstreams"], key=lambda x:x["section_id"])]
        rows += [f"F|{x['feature_id']}|{x['name']}|{','.join(sorted(x['roadmap_sections']))}|{','.join(sorted(x['depends_on']))}" for x in sorted(manifest["features"], key=lambda x:x["feature_id"])]
        return "sha256:" + _sha(("\n".join(rows)+"\n").encode())
    except (KeyError, TypeError, AttributeError) as exc: raise BlueprintUpdateError("BLUEPRINT_SCOPE_FINGERPRINT_INPUT_INVALID") from exc

def rank_requirements(candidates: Any, policy: dict | None = None) -> list[dict]:
    """Rank hard-gate first, enforce Current-selected policy classification, then P1-P4."""
    if not isinstance(candidates, list) or not candidates or len(candidates) > 200: raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_LIST_INVALID")
    by_id = {}
    for raw in candidates:
        if not isinstance(raw, dict) or not isinstance(raw.get("requirement_id"), str) or not raw["requirement_id"].strip() or not isinstance(raw.get("title"), str) or not raw["title"].strip(): raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_INVALID")
        x = dict(raw); rid = x["requirement_id"]
        if rid in by_id: raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_ID_DUPLICATED")
        deps = x.get("depends_on", [])
        if not isinstance(deps, list) or len(deps) != len(set(deps)) or any(not isinstance(d, str) or not d.strip() or d == rid for d in deps): raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_DEPENDENCIES_INVALID")
        if x.get("redline_status", "UNRESOLVED") not in {"CLEAR", "UNRESOLVED", "VIOLATION"}: raise BlueprintUpdateError("BLUEPRINT_REDLINE_STATUS_INVALID")
        if type(x.get("classification_complete", False)) is not bool: raise BlueprintUpdateError("BLUEPRINT_CLASSIFICATION_COMPLETE_INVALID")
        if not x.get("classification_complete", False): x["redline_status"] = "UNRESOLVED"
        for field in ("protected_categories", "requested_operations"):
            vals=x.get(field)
            if not isinstance(vals,list) or len(vals)!=len(set(vals)) or any(not isinstance(v,str) or not v.strip() for v in vals) or (field=="requested_operations" and not vals):
                raise BlueprintUpdateError("BLUEPRINT_PROTECTION_CLASSIFICATION_REQUIRED:"+field)
        for field in ("impact_score", "urgency_score", "rework_risk_score", "effort_score"):
            x.setdefault(field, 1 if field == "effort_score" else 3)
            if type(x[field]) is not int or not 1 <= x[field] <= 5: raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_SCORE_INVALID:"+field)
        x.setdefault("blocking_downstream_count", 0)
        if type(x["blocking_downstream_count"]) is not int or x["blocking_downstream_count"] < 0: raise BlueprintUpdateError("BLUEPRINT_DOWNSTREAM_COUNT_INVALID")
        x.setdefault("reversibility", "HIGH")
        if x["reversibility"] not in {"HIGH", "MEDIUM", "LOW"}: raise BlueprintUpdateError("BLUEPRINT_REVERSIBILITY_INVALID")
        for f in ("core_loop_failure", "authority_conflict", "data_integrity_risk", "irreversible_action", "dependency_foundation"):
            if f in x and type(x[f]) is not bool: raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_BOOLEAN_INVALID:"+f)
        x["depends_on"] = deps; by_id[rid] = x
    for x in by_id.values():
        missing = sorted(set(x["depends_on"]) - by_id.keys())
        if missing: raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_DEPENDENCY_UNKNOWN:"+",".join(missing))
    protected_catalog=set((policy or {}).get("default_protected_categories", []))
    known_ops=set((policy or {}).get("known_operation_ids", []))
    forbidden_ops=set((policy or {}).get("forbidden_operations_without_explicit_authorization", []))
    if not known_ops: raise BlueprintUpdateError("BLUEPRINT_KNOWN_OPERATION_REGISTRY_UNAVAILABLE")
    details = {}
    for rid,x in by_id.items():
        rl=x.get("redline_status", "UNRESOLVED")
        unknown_categories=set(x["protected_categories"])-protected_catalog
        unknown_operations=set(x["requested_operations"])-known_ops
        forbidden=set(x["requested_operations"]) & forbidden_ops
        if rl in {"UNRESOLVED", "VIOLATION"}: details[rid]=(0, 10000, "P0_BLOCKED", "PROTECTED_REDLINE_"+rl)
        elif unknown_categories: details[rid]=(0, 10000, "P0_BLOCKED", "UNKNOWN_PROTECTED_CATEGORY")
        elif unknown_operations: details[rid]=(0, 10000, "P0_BLOCKED", "UNKNOWN_REQUESTED_OPERATION")
        elif forbidden: details[rid]=(0, 10000, "P0_BLOCKED", "FORBIDDEN_PROTECTED_OPERATION")
        else:
            core=any(x.get(k,False) for k in ("core_loop_failure","authority_conflict","data_integrity_risk","irreversible_action")) or x["rework_risk_score"]==5
            tier="P1_CORE" if core else "P2_FOUNDATION" if x.get("dependency_foundation") or x["blocking_downstream_count"] else "P3_REQUIRED" if max(x["impact_score"],x["urgency_score"])>=3 else "P4_DEFER"
            score=3*x["impact_score"]+3*x["urgency_score"]+2*x["rework_risk_score"]+2*min(x["blocking_downstream_count"],5)-x["effort_score"]-{"HIGH":0,"MEDIUM":1,"LOW":2}[x["reversibility"]]
            details[rid]=(TIERS[tier],score,tier,None)
    pending=set(by_id); emitted=set(); ranked=[]
    while pending:
        ready=[rid for rid in pending if set(by_id[rid]["depends_on"]) <= emitted]
        if not ready: raise BlueprintUpdateError("BLUEPRINT_REQUIREMENT_DEPENDENCY_CYCLE")
        ready.sort(key=lambda rid:(details[rid][0],-details[rid][1],rid))
        for rid in ready:
            x=by_id[rid]; _,score,tier,reason=details[rid]
            ranked.append({"rank":len(ranked)+1,"requirement_id":rid,"title":x["title"],"priority_tier":tier,"priority_score":score,"depends_on":x["depends_on"],"blocked":reason is not None,"block_reason":reason})
            emitted.add(rid); pending.remove(rid)
    return ranked

def _load_context(root: Path) -> dict:
    current=_json(root,CURRENT_REF,"BLUEPRINT_CURRENT_UNAVAILABLE")
    refs={"current":CURRENT_REF,"blueprint":current.get("p2_target_blueprint_ref"),"roadmap":current.get("p2_current_roadmap_ref"),"work":current.get("implementation_control",{}).get("active_work_packet"),"construction":current.get("active_construction_packet") or current.get("implementation_control",{}).get("active_construction_packet"),"redline_policy":current.get("p2_blueprint_pointer_policy",{}).get("redline_policy_ref"),"redline_policy_schema":current.get("p2_blueprint_pointer_policy",{}).get("redline_policy_schema_ref"),"matrix":MATRIX_REF,"test_strategy":TEST_STRATEGY_REF}
    if not all(isinstance(x,str) and x.strip() for x in refs.values()): raise BlueprintUpdateError("BLUEPRINT_CURRENT_POINTERS_INCOMPLETE")
    if refs["blueprint"] != BLUEPRINT_REF: raise BlueprintUpdateError("BLUEPRINT_CURRENT_AUTHORITY_POINTER_MISMATCH")
    work=_json(root,refs["work"],"BLUEPRINT_ACTIVE_WORK_UNAVAILABLE"); construction=_json(root,refs["construction"],"BLUEPRINT_ACTIVE_CONSTRUCTION_UNAVAILABLE")
    manifest_ref=work.get("operational_contract",{}).get("feature_batch_manifest_ref")
    if not isinstance(manifest_ref,str) or not manifest_ref.strip(): raise BlueprintUpdateError("BLUEPRINT_MANIFEST_POINTER_UNBOUND")
    refs["manifest"]=manifest_ref; manifest=_json(root,manifest_ref,"BLUEPRINT_MANIFEST_UNAVAILABLE")
    if manifest.get("scope_fingerprint") != _scope_fingerprint(manifest): raise BlueprintUpdateError("BLUEPRINT_SCOPE_FINGERPRINT_MISMATCH")
    policy=_json(root,refs["redline_policy"],"BLUEPRINT_REDLINE_POLICY_UNAVAILABLE")
    _validate_schema(root,policy,refs["redline_policy_schema"],"BLUEPRINT_REDLINE_POLICY_SCHEMA_INVALID")
    if policy.get("status")!="ACTIVE" or policy.get("non_applicability_requires_explicit_confirmation") is not True:
        raise BlueprintUpdateError("BLUEPRINT_REDLINE_POLICY_INACTIVE_OR_UNSAFE")
    for r in refs.values():
        if not _safe_path(root,r).is_file(): raise BlueprintUpdateError("BLUEPRINT_SOURCE_UNAVAILABLE:"+r)
    hashes={k:sha256_file(_safe_path(root,r)) for k,r in refs.items()}
    return {"current":current,"work":work,"construction":construction,"manifest":manifest,"redline_policy":policy,"refs":refs,"hashes":hashes,"scope_fingerprint":manifest["scope_fingerprint"]}

def _scope_change_blockers(request: dict, ctx: dict) -> list[str]:
    if request.get("scope_change_required") is not True: return []
    if ctx["manifest"].get("scope_frozen") is not True: return []
    s=request.get("scope_change")
    if not isinstance(s,dict): return ["BATCH_SCOPE_CHANGE_APPROVAL_REQUIRED"]
    affected=s.get("affected_feature_ids")
    special_f28_f30=s.get("change_id")=="SC-2026-10-11-BLUEPRINT-F28-F30"
    checks={"change_id":lambda v:isinstance(v,str) and bool(v.strip()),"status":lambda v:v=="APPROVED","approval_ref":lambda v:isinstance(v,str) and bool(v.strip()),"previous_scope_fingerprint":lambda v:v==ctx["scope_fingerprint"],"affected_feature_ids":lambda v:isinstance(v,list) and bool(v) and all(isinstance(fid,str) and fid in {f.get("feature_id") for f in ctx["manifest"].get("features",[])} for fid in v) and (not special_f28_f30 or {"P2-F28","P2-F30"}.issubset(set(v))),"dependency_graph_recomputed":lambda v:v is True,"downstream_evidence_invalidated":lambda v:v is True,"reopened_to_planning":lambda v:v is True,"refrozen_after_review":lambda v:v is True,"phase_transition":lambda v:isinstance(v,list) and len(v)==3 and v[0]==ctx["manifest"].get("batch_phase") and v[0] in {"PLANNING","REALIZATION","CLOSURE","FINAL_TEST"} and v[1]=="PLANNING" and v[2]=="REALIZATION"}
    bad=[k for k,fn in checks.items() if not fn(s.get(k))]
    return ["BATCH_SCOPE_CHANGE_INVALID:"+",".join(bad)] if bad else []

def _core_review_blockers(req: dict) -> list[str]:
    if req.get("core_principle_change") is not True: return []
    review=req.get("core_principle_review"); auth=req.get("authorization",{}); bad=[]
    if not isinstance(review,dict): return ["CORE_PRINCIPLE_REVIEW_MISSING"]
    for k in ("evidence_refs","counterexamples","alternatives"):
        if not isinstance(review.get(k),list) or not review[k] or any(not isinstance(x,str) or not x.strip() for x in review[k]): bad.append("CORE_PRINCIPLE_REVIEW_"+k.upper()+"_MISSING")
    for k in ("retaining_consequences","revision_consequences","migration_plan","rollback_plan"):
        if not isinstance(review.get(k),str) or not review[k].strip(): bad.append("CORE_PRINCIPLE_REVIEW_"+k.upper()+"_MISSING")
    if not isinstance(auth,dict) or auth.get("core_principle_revision_approved") is not True: bad.append("CORE_PRINCIPLE_REVISION_APPROVAL_REQUIRED")
    if not isinstance(auth,dict) or not isinstance(auth.get("approval_ref"),str) or not auth["approval_ref"].strip(): bad.append("CORE_PRINCIPLE_APPROVAL_REFERENCE_REQUIRED")
    return bad

def _protected_gate_blockers(root: Path, req: dict, ctx: dict) -> list[str]:
    gate=req.get("protected_gate")
    if not isinstance(gate,dict):
        return ["PROTECTED_GATE_ASSESSMENT_REQUIRED"] if req.get("mode")=="APPLY" else []
    if type(gate.get("required")) is not bool: return ["PROTECTED_GATE_OBJECT_INVALID"]
    policy_sha=ctx["hashes"]["redline_policy"]
    if gate.get("policy_sha256")!=policy_sha: return ["PROTECTED_GATE_POLICY_FINGERPRINT_MISMATCH"]
    candidate_rows=req.get("candidate_requirements",[])
    protected_catalog=set(ctx["redline_policy"].get("default_protected_categories",[]))
    touches_protected=any(
        isinstance(row,dict) and bool(set(row.get("protected_categories",[])) & protected_catalog)
        for row in candidate_rows
    )
    if not gate.get("required"):
        if touches_protected: return ["PROTECTED_GATE_RECEIPT_REQUIRED_FOR_PROTECTED_CATEGORY"]
        if gate.get("disposition")!="NOT_APPLICABLE" or gate.get("user_confirmed_not_applicable") is not True:
            return ["PROTECTED_GATE_NOT_APPLICABLE_CONFIRMATION_REQUIRED"]
        if not isinstance(gate.get("approval_ref"),str) or not gate["approval_ref"].strip():
            return ["PROTECTED_GATE_NOT_APPLICABLE_APPROVAL_REFERENCE_REQUIRED"]
        if not isinstance(gate.get("rationale"),str) or len(gate["rationale"].strip())<16:
            return ["PROTECTED_GATE_NOT_APPLICABLE_RATIONALE_REQUIRED"]
        return []
    ref=gate.get("receipt_ref")
    if not isinstance(ref,str) or not ref.strip(): return ["PROTECTED_GATE_RECEIPT_REQUIRED"]
    try: receipt=_json(root,ref,"PROTECTED_GATE_RECEIPT_INVALID")
    except BlueprintUpdateError as e: return [str(e).split(":")[0]]
    expected_scope=(req.get("scope_change",{}).get("new_scope_fingerprint") if req.get("scope_change_required") is True and isinstance(req.get("scope_change"),dict) else ctx["scope_fingerprint"])
    expected={"status":"PASS","executed":True,"sandbox_id":gate.get("sandbox_id"),"policy_sha256":policy_sha,"policy_version":ctx["redline_policy"].get("policy_version"),"source_sha256":ctx["hashes"]["blueprint"],"candidate_source_sha256":gate.get("candidate_source_sha256"),"test_source_sha256":gate.get("test_source_sha256"),"scope_fingerprint":expected_scope}
    if any(receipt.get(k)!=v for k,v in expected.items()): return ["PROTECTED_GATE_RECEIPT_MISMATCH"]
    if not isinstance(gate.get("sandbox_id"),str) or not gate["sandbox_id"].strip(): return ["PROTECTED_GATE_SANDBOX_ID_REQUIRED"]
    if any(not _hash(gate.get(k)) for k in ("candidate_source_sha256","test_source_sha256")): return ["PROTECTED_GATE_HASH_INVALID"]
    conditions=receipt.get("sandbox_conditions")
    if not isinstance(conditions,list) or not set(ctx["redline_policy"].get("required_sandbox_conditions",[])).issubset(set(conditions)):
        return ["PROTECTED_GATE_SANDBOX_CONDITIONS_INCOMPLETE"]
    return []

def _write_owner(path: str, blueprint: str) -> str | None:
    return "BLUEPRINT_ENGINEERING" if path==blueprint else OWNERS.get(path)

def _assessment_impact_blockers(root: Path, req: dict, ctx: dict) -> list[str]:
    """Require explicit dispositions for every Current-selected and derived source before approving an assessment."""
    impact=req.get("impact_matrix")
    if not isinstance(impact,list) or not impact:
        return ["BLUEPRINT_IMPACT_MATRIX_REQUIRED"]
    dispositions={}
    bad=[]
    for row in impact:
        if not isinstance(row,dict) or not isinstance(row.get("path"),str) or row.get("disposition") not in DISPOSITIONS:
            bad.append("BLUEPRINT_IMPACT_DISPOSITION_INVALID")
            continue
        metadata=("owner","current_evidence","reason","required_action","unlock_condition")
        if any(not isinstance(row.get(key),str) or not row[key].strip() for key in metadata):
            bad.append("BLUEPRINT_IMPACT_METADATA_INVALID:"+row["path"])
        invalidates=row.get("evidence_invalidation")
        if not isinstance(invalidates,list) or any(not isinstance(v,str) or not v.strip() for v in invalidates):
            bad.append("BLUEPRINT_IMPACT_EVIDENCE_INVALIDATION_INVALID:"+row["path"])
        path=row["path"]
        if path in dispositions:
            bad.append("BLUEPRINT_IMPACT_PATH_DUPLICATED")
            continue
        dispositions[path]=row["disposition"]
        try:
            if not _safe_path(root,path).is_file():
                bad.append("BLUEPRINT_IMPACT_PATH_UNAVAILABLE:"+path)
        except BlueprintUpdateError:
            bad.append("BLUEPRINT_IMPACT_PATH_INVALID:"+path)
    if "BLOCKED_UNKNOWN" in dispositions.values():
        bad.append("BLUEPRINT_IMPACT_UNKNOWN_BLOCKS_WRITE")
    missing=set(ctx["refs"].values())-set(dispositions)
    if missing:
        bad.append("BLUEPRINT_IMPACT_MATRIX_INCOMPLETE:"+",".join(sorted(missing)))
    return list(dict.fromkeys(bad))


def _write_blockers(root: Path, req: dict, ctx: dict) -> list[str]:
    writes=req.get("proposed_writes"); impact=req.get("impact_matrix"); auth=req.get("authorization",{}); bad=[]
    if not isinstance(writes,list) or not writes or len(writes)>30: return ["BLUEPRINT_WRITE_SET_INVALID"]
    if not isinstance(impact,list): return ["BLUEPRINT_IMPACT_MATRIX_REQUIRED"]
    im={}
    for x in impact:
        if not isinstance(x,dict) or not isinstance(x.get("path"),str) or x.get("disposition") not in DISPOSITIONS: bad.append("BLUEPRINT_IMPACT_DISPOSITION_INVALID"); continue
        if x["path"] in im: bad.append("BLUEPRINT_IMPACT_PATH_DUPLICATED")
        im[x["path"]]=x["disposition"]
    if "BLOCKED_UNKNOWN" in im.values(): bad.append("BLUEPRINT_IMPACT_UNKNOWN_BLOCKS_WRITE")
    required_impact_paths=set(ctx["refs"].values())
    missing_impact_paths=required_impact_paths-set(im)
    if missing_impact_paths: bad.append("BLUEPRINT_IMPACT_MATRIX_INCOMPLETE:"+",".join(sorted(missing_impact_paths)))
    for impact_path in im:
        try:
            if not _safe_path(root,impact_path).is_file(): bad.append("BLUEPRINT_IMPACT_PATH_UNAVAILABLE:"+impact_path)
        except BlueprintUpdateError:
            bad.append("BLUEPRINT_IMPACT_PATH_INVALID:"+str(impact_path))
    if not isinstance(auth,dict) or auth.get("blueprint_write_approved") is not True: bad.append("BLUEPRINT_WRITE_APPROVAL_REQUIRED")
    if not isinstance(auth,dict) or not isinstance(auth.get("approval_ref"),str) or not auth["approval_ref"].strip(): bad.append("BLUEPRINT_WRITE_APPROVAL_REFERENCE_REQUIRED")
    scope_change_required = req.get("scope_change_required", False) is True
    seen=set(); has_blueprint=False; has_manifest=False
    for w in writes:
        if not isinstance(w,dict): bad.append("BLUEPRINT_WRITE_ENTRY_INVALID"); continue
        p=w.get("path"); content=w.get("content"); expected=w.get("expected_sha256")
        if not isinstance(p,str) or p in seen: bad.append("BLUEPRINT_WRITE_PATH_DUPLICATED_OR_INVALID"); continue
        seen.add(p)
        if w.get("owner")!=_write_owner(p,ctx["refs"]["blueprint"]): bad.append("BLUEPRINT_WRITE_OWNER_FORBIDDEN:"+p); continue
        if not isinstance(content,str) or not _hash(expected): bad.append("BLUEPRINT_WRITE_PAYLOAD_INVALID:"+p); continue
        try: path=_safe_path(root,p); existing=path.read_bytes()
        except (BlueprintUpdateError,OSError): bad.append("BLUEPRINT_WRITE_TARGET_UNAVAILABLE:"+p); continue
        if _sha(existing)!=expected: bad.append("BLUEPRINT_WRITE_SOURCE_DRIFT:"+p)
        if p not in im: bad.append("BLUEPRINT_WRITE_IMPACT_UNDECLARED:"+p)
        if p==ctx["refs"]["blueprint"]: has_blueprint=True
        if p!=ctx["refs"]["manifest"]: continue
        has_manifest=True
        if not scope_change_required: bad.append("BLUEPRINT_UNEXPECTED_SCOPE_MANIFEST_WRITE")
        try: new=json.loads(content); fp=_scope_fingerprint(new)
        except (json.JSONDecodeError,BlueprintUpdateError,TypeError): bad.append("BLUEPRINT_PROPOSED_MANIFEST_INVALID"); continue
        if new.get("scope_fingerprint")!=fp or fp==ctx["scope_fingerprint"]: bad.append("BLUEPRINT_SCOPE_FINGERPRINT_INVALID_OR_UNCHANGED")
        old=ctx["manifest"].get("features",[]); new_features=new.get("features",[])
        old_ids={x.get("feature_id") for x in old}; new_ids={x.get("feature_id") for x in new_features if isinstance(x,dict)}
        rec=next((x for x in new.get("scope_change_history",[]) if isinstance(x,dict) and x.get("change_id")==req.get("scope_change",{}).get("change_id")),None)
        if not isinstance(rec,dict) or rec.get("status")!="APPROVED" or rec.get("previous_scope_fingerprint")!=ctx["scope_fingerprint"] or rec.get("new_scope_fingerprint")!=fp: bad.append("BLUEPRINT_SCOPE_CHANGE_RECORD_INVALID")
        else:
            required={"dependency_graph_recomputed":True,"downstream_evidence_invalidated":True,"reopened_to_planning":True,"refrozen_after_review":True}
            if not isinstance(rec.get("approval_ref"),str) or not rec["approval_ref"].strip() or any(rec.get(k)!=v for k,v in required.items()): bad.append("BLUEPRINT_SCOPE_CHANGE_RECORD_INCOMPLETE")
            phase=rec.get("phase_transition")
            phase_valid=isinstance(phase,list) and len(phase)==3 and phase[0]==ctx["manifest"].get("batch_phase") and phase[0] in {"PLANNING","REALIZATION","CLOSURE","FINAL_TEST"} and phase[1]=="PLANNING" and phase[2]=="REALIZATION"
            affected=set(rec.get("affected_feature_ids",[]))
            required_features={"P2-F28","P2-F30"} if req.get("scope_change",{}).get("change_id")=="SC-2026-10-11-BLUEPRINT-F28-F30" else affected
            if not affected or not affected.issubset(new_ids) or not required_features.issubset(affected) or not phase_valid or not INVALIDATED.issubset(set(rec.get("evidence_invalidated",[]))): bad.append("BLUEPRINT_SCOPE_CHANGE_TRACE_INVALID")
        if len(old)!=len(new_features) or old_ids!=new_ids: bad.append("BLUEPRINT_SCOPE_CHANGE_FEATURE_ROSTER_CHANGED")
        old_graph={x.get("feature_id"):sorted(x.get("depends_on",[])) for x in old}
        new_graph={x.get("feature_id"):sorted(x.get("depends_on",[])) for x in new_features if isinstance(x,dict)}
        changed_dependencies={fid for fid in old_graph if old_graph.get(fid)!=new_graph.get(fid)}
        specific_f28_f30_change=req.get("scope_change",{}).get("change_id")=="SC-2026-10-11-BLUEPRINT-F28-F30"
        if specific_f28_f30_change:
            if not changed_dependencies: bad.append("BLUEPRINT_SCOPE_CHANGE_DEPENDENCY_GRAPH_UNCHANGED")
            new_f30=next((x for x in new_features if x.get("feature_id")=="P2-F30"),{})
            if "P2-F28" not in new_f30.get("depends_on",[]): bad.append("BLUEPRINT_SCOPE_CHANGE_F28_F30_DEPENDENCY_MISSING")
            if "P2-F30" not in changed_dependencies: bad.append("BLUEPRINT_SCOPE_CHANGE_F30_DEPENDENCY_NOT_CHANGED")
        else:
            affected=set(req.get("scope_change",{}).get("affected_feature_ids",[]))
            if not affected or not affected.issubset(new_ids): bad.append("BLUEPRINT_SCOPE_CHANGE_FEATURE_BINDING_INVALID")
        for f in new_features:
            prior=next((x for x in old if x.get("feature_id")==f.get("feature_id")), {})
            if len(f.get("local_case_plan",[]))!=len(prior.get("local_case_plan",[])): bad.append("BLUEPRINT_SCOPE_CHANGE_CASE_COUNT_CHANGED"); break
            if f.get("local_case_sim_status")!="NOT_RUN" or f.get("local_case_sim_evidence_refs")!=[]: bad.append("BLUEPRINT_OLD_RECEIPT_NOT_INVALIDATED"); break
        if new.get("scope_frozen") is not True or new.get("batch_phase")!="REALIZATION" or new.get("official_test_roster")!=[] or new.get("closure_evidence_ref") is not None: bad.append("BLUEPRINT_DOWNSTREAM_EVIDENCE_NOT_INVALIDATED")
    if not has_blueprint: bad.append("BLUEPRINT_CANONICAL_TARGET_REQUIRED")
    if scope_change_required and ctx["manifest"].get("scope_frozen") is True and not has_manifest: bad.append("BLUEPRINT_SCOPE_MANIFEST_UPDATE_REQUIRED")
    if not scope_change_required and has_manifest: bad.append("BLUEPRINT_UNEXPECTED_SCOPE_MANIFEST_WRITE")
    if not seen.issubset(set(im)): bad.append("BLUEPRINT_IMPACT_COVERAGE_INCOMPLETE")
    for p,d in im.items():
        if d in {"REWORK_REQUIRED","DOC_SYNC_REQUIRED"} and p not in seen: bad.append("BLUEPRINT_REQUIRED_SYNC_NOT_IN_WRITE_SET:"+p)
    return list(dict.fromkeys(bad))

def assess_update(root: Path, req: dict) -> dict:
    if not isinstance(req,dict): raise BlueprintUpdateError("BLUEPRINT_UPDATE_REQUEST_OBJECT_REQUIRED")
    mode=req.get("mode","ASSESS_ONLY")
    if mode not in {"ASSESS_ONLY","APPLY"}: raise BlueprintUpdateError("BLUEPRINT_UPDATE_MODE_INVALID")
    ctx=_load_context(root); snapshot=req.get("expected_snapshot",{})
    if not isinstance(snapshot,dict): raise BlueprintUpdateError("BLUEPRINT_EXPECTED_SNAPSHOT_INVALID")
    bad=[]
    fields={"current_sha256":"current","blueprint_sha256":"blueprint","work_sha256":"work","construction_sha256":"construction","manifest_sha256":"manifest","roadmap_sha256":"roadmap","redline_policy_sha256":"redline_policy","redline_policy_schema_sha256":"redline_policy_schema","matrix_sha256":"matrix","test_strategy_sha256":"test_strategy"}
    if mode=="APPLY":
        missing=(set(fields)|{"manifest_scope_fingerprint"})-snapshot.keys()
        if missing: bad.append("BLUEPRINT_EXPECTED_SNAPSHOT_INCOMPLETE:"+",".join(sorted(missing)))
    for field,key in fields.items():
        if field in snapshot and snapshot[field]!=ctx["hashes"][key]: bad.append("BLUEPRINT_EXPECTED_"+key.upper()+"_DRIFT")
    if "manifest_scope_fingerprint" in snapshot and snapshot["manifest_scope_fingerprint"]!=ctx["scope_fingerprint"]: bad.append("BLUEPRINT_EXPECTED_SCOPE_DRIFT")
    ranked=rank_requirements(req.get("candidate_requirements"),ctx["redline_policy"])
    bad+=_assessment_impact_blockers(root,req,ctx)
    if mode=="APPLY":
        if type(req.get("scope_change_required", False)) is not bool: bad.append("BLUEPRINT_SCOPE_CHANGE_FLAG_INVALID")
        bad+=_scope_change_blockers(req,ctx)
    bad+=_core_review_blockers(req)+_protected_gate_blockers(root,req,ctx)
    if any(x["blocked"] for x in ranked): bad.append("BLUEPRINT_PROTECTED_REDLINE_BLOCKS_TRANSACTION")
    if mode=="APPLY": bad+=_write_blockers(root,req,ctx)
    im=req.get("impact_matrix",[])
    if not isinstance(im,list): im=[]
    dispositions={x.get("path"):x.get("disposition") for x in im if isinstance(x,dict)}
    rework=sorted(p for p,d in dispositions.items() if d in {"REVALIDATION_REQUIRED","REWORK_REQUIRED"})
    status="BLOCKED" if bad else "READY_TO_APPLY" if mode=="APPLY" else "ASSESSMENT_READY"
    return {"status":status,"request_id":req.get("request_id"),"mode":mode,"write_performed":False,"blueprint_ref":ctx["refs"]["blueprint"],"source_fingerprints":ctx["hashes"],"batch_scope_fingerprint":ctx["scope_fingerprint"],"priority_order":ranked,"scope_change_id":req.get("scope_change",{}).get("change_id") if isinstance(req.get("scope_change"),dict) else None,"scope_change_required":req.get("scope_change_required", False) is True,"impacted_paths":sorted(dispositions),"rework_or_revalidation_paths":rework,"blockers":list(dict.fromkeys(bad)),"acceptance":["Current-selected sole blueprint path matches the write target.","Priority tiers, risk-adjusted score and dependency order are deterministic.","Redline and core-principle governance gates cannot be traded against scores.","Frozen-scope changes require an approved scope-change record and evidence invalidation.","Every write requires owner, impact disposition and expected source SHA-256.","Successful writes are read back and hashed; write failures trigger rollback."]}

def _atomic_write_set(root: Path, writes: list[dict]) -> list[dict]:
    original={}; staged={}; replaced=[]
    try:
        for w in writes:
            p=w["path"]; dest=_safe_path(root,p)
            if not dest.is_file(): raise BlueprintUpdateError("BLUEPRINT_WRITE_TARGET_NOT_FILE:"+p)
            original[p]=dest.read_bytes()
            if _sha(original[p])!=w.get("expected_sha256"): raise BlueprintUpdateError("BLUEPRINT_WRITE_SOURCE_DRIFT:"+p)
            fd,tmp=tempfile.mkstemp(prefix=".blueprint-update-",dir=str(dest.parent)); staged[p]=Path(tmp)
            with os.fdopen(fd,"wb") as f: f.write(w["content"].encode()); f.flush(); os.fsync(f.fileno())
        for w in writes:
            p=w["path"]; os.replace(staged[p],_safe_path(root,p)); replaced.append(p)
        result=[]
        for w in writes:
            actual=sha256_file(_safe_path(root,w["path"])); expected=_sha(w["content"].encode())
            if actual!=expected: raise BlueprintUpdateError("BLUEPRINT_WRITE_READBACK_MISMATCH:"+w["path"])
            result.append({"path":w["path"],"sha256":actual})
        return result
    except Exception as exc:
        failures=[]
        for p in reversed(replaced):
            try:
                fd,tmp=tempfile.mkstemp(prefix=".blueprint-rollback-",dir=str(_safe_path(root,p).parent))
                with os.fdopen(fd,"wb") as f: f.write(original[p]); f.flush(); os.fsync(f.fileno())
                os.replace(tmp,_safe_path(root,p))
            except Exception as rollback: failures.append(p+":"+type(rollback).__name__)
        if failures: raise BlueprintUpdateError("BLUEPRINT_WRITE_ROLLBACK_FAILED:"+",".join(failures)) from exc
        if isinstance(exc,BlueprintUpdateError): raise
        raise BlueprintUpdateError("BLUEPRINT_WRITE_TRANSACTION_FAILED:"+type(exc).__name__) from exc
    finally:
        for temp in staged.values():
            try: temp.unlink(missing_ok=True)
            except OSError: pass

def apply_update_transaction(root: Path, req: dict) -> dict:
    if req.get("mode")!="APPLY": raise BlueprintUpdateError("BLUEPRINT_APPLY_MODE_REQUIRED")
    assessment=assess_update(root,req)
    if assessment["status"]!="READY_TO_APPLY": return assessment
    assessment=dict(assessment); assessment.update(status="COMMITTED",write_performed=True,readback=_atomic_write_set(root,req["proposed_writes"]))
    return assessment

def validate_request(req: dict, root: Path=ROOT) -> None:
    _validate_schema(root,req,REQUEST_SCHEMA_REF,"BLUEPRINT_UPDATE_REQUEST_SCHEMA_INVALID")
def validate_result(result: dict, root: Path=ROOT) -> None:
    _validate_schema(root,result,RESULT_SCHEMA_REF,"BLUEPRINT_UPDATE_RESULT_SCHEMA_INVALID")
def _validate_schema(root: Path, value: dict, ref: str, code: str) -> None:
    try:
        from jsonschema import Draft202012Validator
        schema=_json(root,ref,code); Draft202012Validator.check_schema(schema); Draft202012Validator(schema).validate(value)
    except BlueprintUpdateError: raise
    except Exception as exc: raise BlueprintUpdateError(code+":"+type(exc).__name__) from exc

def main() -> int:
    parser=argparse.ArgumentParser(description="Read-only P2 blueprint priority assessment; --apply enables the guarded transaction")
    parser.add_argument("--request",required=True); parser.add_argument("--apply",action="store_true"); args=parser.parse_args()
    try:
        req=json.loads(Path(args.request).read_text(encoding="utf-8"))
        if not isinstance(req,dict): raise BlueprintUpdateError("BLUEPRINT_UPDATE_REQUEST_OBJECT_REQUIRED")
        req=dict(req); req["mode"]="APPLY" if args.apply else "ASSESS_ONLY"; validate_request(req,ROOT)
        result=apply_update_transaction(ROOT,req) if args.apply else assess_update(ROOT,req); validate_result(result,ROOT)
        print(json.dumps(result,ensure_ascii=False,indent=2,sort_keys=True)); return 0 if result["status"] in {"ASSESSMENT_READY","READY_TO_APPLY","COMMITTED"} else 2
    except (OSError,UnicodeError,json.JSONDecodeError,BlueprintUpdateError) as exc:
        print(json.dumps({"status":"BLOCKED","write_performed":False,"reason_code":str(exc).split(":")[0],"detail":str(exc)[:1000]},ensure_ascii=False,indent=2)); return 2

if __name__=="__main__": raise SystemExit(main())
