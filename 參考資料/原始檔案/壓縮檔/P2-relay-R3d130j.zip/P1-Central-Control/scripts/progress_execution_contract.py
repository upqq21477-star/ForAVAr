#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

# Acceptance is simulation-only for the current construction phase.
# Live execution remains available only through an explicit later opt-in.
SIMULATION_PROFILES = {
    "TEST_PRINT_PASS": {
        "cases": ["fixed_acceptance_profile"],
    },
    "M32-C01-A": {
        "cases": [
            "arbitrary_argv_blocked",
            "unknown_action_blocked",
            "typed_action_shape",
            "typed_args_validation",
            "path_traversal_blocked",
            "symlink_escape_blocked",
            "credential_environment_minimized",
            "legacy_next_command_ignored",
            "runner_startup_failure_routes_to_diagnose",
            "recovery_dispatch_is_guarded",
        ],
    },
    "M32-C01-CLOSE": {
        "cases": [
            "A_command_trust_boundary",
            "B_thin_continuation",
            "C_failure_replay",
            "D_crash_recovery",
            "E_current_truth_reconciliation",
            "F_ci_actions_security",
            "simulation_boundary_preserved",
            "runtime_truth_remains_observed_only",
        ],
    },
}
SENSITIVE_NAMES = {
    ".env",
    ".git",
    ".github",
    ".ssh",
    "credentials",
    "secrets",
    "id_rsa",
    "id_ed25519",
}

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/progress_execution_contract.schema.json"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_contract(contract: dict[str, Any]) -> None:
    schema = load_json(SCHEMA)
    Draft202012Validator(schema).validate(contract)
    step_ids = [step["step_id"] for step in contract["steps"]]
    if len(step_ids) != len(set(step_ids)):
        raise ValueError("execution_contract step_id 必須唯一")

    acceptance_indexes = [
        index
        for index, step in enumerate(contract["steps"])
        if step["op"] == "RUN_ACCEPTANCE_COMMAND"
    ]
    if len(acceptance_indexes) > 1:
        raise ValueError("WORK_UNIT_CLOSE_ONLY_ONE_ACCEPTANCE")
    if acceptance_indexes:
        acceptance_index = acceptance_indexes[0]
        if contract["steps"][acceptance_index].get("gate") != "WORK_UNIT_CLOSE":
            raise ValueError("ACCEPTANCE_GATE_MUST_BE_WORK_UNIT_CLOSE")
        if acceptance_index != len(contract["steps"]) - 2:
            raise ValueError("ACCEPTANCE_MUST_BE_LAST_WORK_UNIT_OPERATION")
        if contract["steps"][-1]["op"] != "EMIT_NEXT_COMMAND":
            raise ValueError("ACCEPTANCE_MUST_PRECEDE_HANDOFF")


def _command(value: Any, *, field: str) -> list[str]:
    if (
        not isinstance(value, list)
        or not value
        or not all(isinstance(item, str) and item.strip() for item in value)
    ):
        raise ValueError(f"{field} 必須是非空 argv array")
    return list(value)


def _safe_output_path(root: Path, raw_path: Any) -> Path:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ValueError("OUTPUT_PATH_MISSING")
    candidate = Path(raw_path)
    if candidate.is_absolute():
        raise ValueError("OUTPUT_ABSOLUTE_PATH_BLOCKED")
    if ".." in candidate.parts:
        raise ValueError("OUTPUT_PATH_TRAVERSAL_BLOCKED")
    if {part.lower() for part in candidate.parts} & SENSITIVE_NAMES:
        raise ValueError("OUTPUT_SENSITIVE_PATH_BLOCKED")
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root.resolve())
    except ValueError as exc:
        raise ValueError("OUTPUT_PATH_OUTSIDE_WORKSPACE") from exc
    relative_resolved = resolved.relative_to(root.resolve())
    if {part.lower() for part in relative_resolved.parts} & SENSITIVE_NAMES:
        raise ValueError("OUTPUT_SENSITIVE_PATH_BLOCKED")
    if not resolved.is_file():
        raise ValueError(f"OUTPUT_MISSING:{raw_path}")
    return resolved


def _check_outputs(root: Path, packet: dict[str, Any]) -> dict[str, Any]:
    outputs = packet.get("outputs")
    if not isinstance(outputs, list) or not outputs:
        raise ValueError("OUTPUTS_EMPTY")

    measured: list[dict[str, Any]] = []
    for index, output in enumerate(outputs):
        if not isinstance(output, dict):
            raise ValueError(f"OUTPUT_ENTRY_INVALID:{index}")
        raw_path = output.get("path")
        path = _safe_output_path(root, raw_path)

        size = path.stat().st_size
        digest = sha256_file(path)
        measured.append({
            "path": raw_path,
            "bytes": size,
            "sha256": digest,
        })

        if size < 1:
            raise ValueError(f"OUTPUT_EMPTY:{raw_path}")

        before_hash = output.get("before_sha256")
        if before_hash and before_hash == digest:
            raise ValueError(f"OUTPUT_UNCHANGED:{raw_path}")

    return {"outputs": measured}


def require_work_unit_close_ready(root: Path) -> dict[str, Any]:
    current_path = root / "P1-CURRENT.json"
    if not current_path.is_file():
        raise ValueError("CURRENT_AUTHORITY_MISSING")
    current = load_json(current_path)
    stage = current.get("current_stage", {})
    implementation = current.get("implementation_control", {})
    work_path_raw = implementation.get("active_work_packet")
    if not isinstance(work_path_raw, str) or not work_path_raw:
        raise ValueError("ACTIVE_WORK_PACKET_MISSING")

    work_path = Path(work_path_raw)
    resolved = work_path if work_path.is_absolute() else root / work_path
    if not resolved.is_file():
        raise ValueError("ACTIVE_WORK_PACKET_NOT_FOUND")

    # 已驗收是終態，優先於「尚未就緒」回報（兩者皆拒絕，僅決定原因碼）。
    if stage.get("status") == "VERIFIED":
        raise ValueError("WORK_UNIT_ALREADY_ACCEPTED")
    if stage.get("validated_control_gate_run") is not None:
        raise ValueError("WORK_UNIT_ALREADY_ACCEPTED")
    if stage.get("validated_head_sha") is not None:
        raise ValueError("WORK_UNIT_ALREADY_ACCEPTED")

    work = load_json(resolved)
    if work.get("status") not in {"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE", "READY_FOR_CLOSE_ACCEPTANCE"}:
        raise ValueError("WORK_UNIT_NOT_READY_FOR_CLOSE_ACCEPTANCE")

    stage_work_unit = stage.get("work_unit_id") or stage.get("id")
    if work.get("work_unit") != stage_work_unit:
        raise ValueError("WORK_UNIT_AUTHORITY_MISMATCH")

    acceptance = work.get("acceptance") or {}
    if acceptance.get("mode") != "SIMULATION_ONLY":
        raise ValueError("WORK_UNIT_ACCEPTANCE_MODE_NOT_SIMULATION")

    if work.get("handoff", {}).get("gate") != "WORK_UNIT_CLOSE_ACCEPTANCE_ONLY":
        raise ValueError("WORK_UNIT_CLOSE_GATE_INVALID")

    return {
        "work_unit": work.get("work_unit"),
        "status": work.get("status"),
        "mode": acceptance.get("mode"),
    }


def _run_acceptance(root: Path, packet: dict[str, Any], timeout_seconds: int) -> dict[str, Any]:
    close_ready = require_work_unit_close_ready(root)
    del timeout_seconds
    acceptance = packet.get("acceptance")
    if not isinstance(acceptance, dict):
        raise ValueError("ACCEPTANCE_MISSING")
    if "command" in acceptance:
        raise ValueError("ARBITRARY_ACCEPTANCE_COMMAND_BLOCKED")
    profile = acceptance.get("profile")
    simulation = SIMULATION_PROFILES.get(profile)
    if simulation is None:
        raise ValueError("UNKNOWN_ACCEPTANCE_PROFILE")

    return {
        "mode": "SIMULATION_ONLY",
        "profile": profile,
        "gate": "WORK_UNIT_CLOSE",
        "close_ready": close_ready,
        "returncode": 0,
        "simulated": True,
        "cases": [
            {"case": case, "status": "PASS", "reason_code": "SIMULATED"}
            for case in simulation["cases"]
        ],
        "stdout": "",
        "stderr": "",
    }


def _emit_next_command(packet: dict[str, Any]) -> dict[str, Any]:
    """Legacy construction-harness handoff; trusted runtime does not execute it."""
    command = _command(packet.get("next_command"), field="next_command")
    return {"next_command": command}


def execute(root: Path, packet: dict[str, Any]) -> dict[str, Any]:
    contract = packet.get("execution_contract")
    if not isinstance(contract, dict):
        return {
            "status": "BLOCK",
            "step_results": [{
                "step_id": "CONTRACT",
                "op": "VALIDATE_CONTRACT",
                "status": "FAIL",
                "error": "EXECUTION_CONTRACT_MISSING",
            }],
        }

    try:
        validate_contract(contract)
    except Exception as exc:
        return {
            "status": "BLOCK",
            "step_results": [{
                "step_id": "CONTRACT",
                "op": "VALIDATE_CONTRACT",
                "status": "FAIL",
                "error": str(exc),
            }],
        }

    step_results: list[dict[str, Any]] = []
    for step in contract["steps"]:
        op = step["op"]
        timeout_seconds = int(step.get("timeout_seconds", 30))
        try:
            if op == "CHECK_OUTPUTS":
                output = _check_outputs(root, packet)
            elif op == "RUN_ACCEPTANCE_COMMAND":
                output = _run_acceptance(root, packet, timeout_seconds)
            elif op == "EMIT_NEXT_COMMAND":
                output = _emit_next_command(packet)
            else:
                raise ValueError(f"UNSUPPORTED_OPERATION:{op}")
            step_results.append({
                "step_id": step["step_id"],
                "op": op,
                "status": "PASS",
                "output": output,
            })
        except Exception as exc:
            step_results.append({
                "step_id": step["step_id"],
                "op": op,
                "status": "FAIL",
                "error": str(exc),
            })
            return {
                "status": "BLOCK",
                "step_results": step_results,
            }

    return {
        "status": "PASS",
        "step_results": step_results,
    }
