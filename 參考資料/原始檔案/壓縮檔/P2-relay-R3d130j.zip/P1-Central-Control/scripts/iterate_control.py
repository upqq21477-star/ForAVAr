"""iterate_control -- round control from the gap checkpoint, decided by code not by the model (CAP-ITERATE).
DONE (no high-priority gap) / LIMIT (round >= limit; unresolved reported) / STALLED (same gap set as last round) / CONTINUE.
Retries stay in Run.ladder; this layer only counts rounds.  HIGH = FAIL, INCOMPLETE (HYPOTHESIS).
DEFAULT_LIMIT: no first-party number exists; 3 is a budget choice (D-R3d12zq-ITER-LIMIT, overridable)."""
from __future__ import annotations

from typing import Any

DEFAULT_LIMIT = 3
HIGH = ("FAIL", "INCOMPLETE")


def high_ids(ck: dict[str, Any]) -> list[str]:
    return sorted(g["id"] for g in ck["gaps"] if g["priority"] in HIGH)


def decide(ck: dict[str, Any], limit: int = DEFAULT_LIMIT) -> dict[str, Any]:
    ids = high_ids(ck)
    if not ids:
        d = "DONE"
    elif ck["round"] >= limit:
        d = "LIMIT"
    elif ck["prev_ids"] and ids == sorted(ck["prev_ids"]):
        d = "STALLED"
    else:
        d = "CONTINUE"
    return {"decision": d, "round": ck["round"], "unresolved": ids}


def finish_round(ck: dict[str, Any], prev_ids: list[str]) -> dict[str, Any]:
    ck["round"] += 1  # a round that errored still counts
    ck["prev_ids"] = sorted(prev_ids)
    return ck
