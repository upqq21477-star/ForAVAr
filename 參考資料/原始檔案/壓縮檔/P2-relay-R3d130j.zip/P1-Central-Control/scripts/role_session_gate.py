#!/usr/bin/env python3
"""Fail-closed admission gate for isolated P1 Control / Executor / Verifier sessions."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
ROLE_SCHEMA = ROOT / "P1-Central-Control/schemas/role_contract.schema.json"
REQUEST_SCHEMA = ROOT / "P1-Central-Control/schemas/role_session_request.schema.json"
PROFILE_SCHEMA = ROOT / "P1-Central-Control/schemas/instruction_profile.schema.json"
REGISTRY = ROOT / "P1-Central-Control/canonical/role_contract_registry.json"
PROFILE_DIR = ROOT / "P1-Central-Control/canonical/instruction_profiles"


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def validate_with_schema(value: dict[str, Any], schema_path: Path) -> None:
    errors = sorted(
        Draft202012Validator(load_json(schema_path)).iter_errors(value),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def load_roles() -> dict[str, dict[str, Any]]:
    registry = load_json(REGISTRY)
    roles: dict[str, dict[str, Any]] = {}
    for role in registry.get("roles", []):
        validate_with_schema(role, ROLE_SCHEMA)
        role_id = role["role_id"]
        if role_id in roles:
            raise ValueError(f"DUPLICATE_ROLE_ID:{role_id}")
        roles[role_id] = role
    return roles


def load_active_profile(profile_id: str) -> dict[str, Any]:
    if not profile_id.startswith("IP:"):
        raise ValueError("PROFILE_ID_INVALID")
    path = PROFILE_DIR / f"{profile_id[3:].lower()}.json"
    if not path.is_file():
        raise ValueError("PROFILE_MISSING")
    profile = load_json(path)
    validate_with_schema(profile, PROFILE_SCHEMA)
    if profile["profile_id"] != profile_id:
        raise ValueError("PROFILE_ID_MISMATCH")
    if profile["status"] != "ACTIVE":
        raise ValueError("PROFILE_NOT_ACTIVE")
    return profile


def admission(request: dict[str, Any]) -> dict[str, Any]:
    validate_with_schema(request, REQUEST_SCHEMA)
    roles = load_roles()

    role_id = request["role_id"]
    role = roles.get(role_id)
    if role is None:
        return block(request, "UNKNOWN_ROLE")

    if role["status"] != "ACTIVE":
        return block(request, "ROLE_NOT_ACTIVE")

    capability_id = request.get("capability_id")
    if capability_id:  # U-8 啟用層：宣告要用的 capability 必須綁在此 role（未宣告＝不使用 capability）
        from task_set import assert_role_capability

        try:
            assert_role_capability(role_id, capability_id)
        except ValueError:
            return block(request, "CAPABILITY_NOT_BOUND_TO_ROLE")

    if request["activation_command"] not in role["activation_commands"]:
        return block(request, "ACTIVATION_COMMAND_NOT_BOUND_TO_ROLE")

    profile_id = request["profile_id"]
    if profile_id not in role["instruction_profile_ids"]:
        return block(request, "PROFILE_NOT_BOUND_TO_ROLE")

    try:
        profile = load_active_profile(profile_id)
    except ValueError as exc:
        return block(request, str(exc))

    mode = request["mode"]
    expected_mode = {
        "ROLE:EXECUTOR": {"CONSTRUCTION"},
        "ROLE:VERIFIER": {"ACCEPTANCE"},
        "ROLE:CONTROL_RESEARCH": {"DISCUSSION", "GUIDANCE"},
    }[role_id]
    if mode not in expected_mode:
        return block(request, "MODE_NOT_ALLOWED")

    operation = request["operation"]
    if operation in role["denied_operations"]:
        return block(request, "OPERATION_DENIED")
    if operation not in role["allowed_operations"]:
        return block(request, "OPERATION_NOT_ALLOWED")

    requested_targets = set(request["requested_write_targets"])
    allowed_targets = set(role["allowed_write_targets"])
    denied_targets = set(role["denied_write_targets"])

    if requested_targets & denied_targets:
        return block(request, "WRITE_TARGET_DENIED")
    if not requested_targets.issubset(allowed_targets):
        return block(request, "WRITE_TARGET_NOT_ALLOWED")

    if role["direct_current_mutation"]:
        return block(request, "ROLE_CAN_NEVER_REQUIRE_DIRECT_CURRENT_MUTATION")
    if "P1_CURRENT" in requested_targets:
        return block(request, "DIRECT_CURRENT_MUTATION_DENIED")

    if request["external_research"] and not role["allowed_research"]:
        return block(request, "EXTERNAL_RESEARCH_DENIED")
    if request["external_research"] and role_id != "ROLE:CONTROL_RESEARCH":
        return block(request, "EXTERNAL_RESEARCH_ROLE_DENIED")

    if role["amnesia_required"]:
        if request["history_loaded"] != 0:
            return block(request, "AMNESIA_HISTORY_LOADED")
        if request["transient_context_loaded"]:
            return block(request, "TRANSIENT_CONTEXT_LOADED")
        if not request["targeted_retrieval_only"]:
            return block(request, "TARGETED_RETRIEVAL_REQUIRED")

    if role_id == "ROLE:EXECUTOR" and not request.get("task_packet_ref"):
        return block(request, "EXECUTOR_TASK_PACKET_REQUIRED")

    if role_id == "ROLE:VERIFIER":
        targets = request.get("verification_target_refs") or []
        legacy_target = request.get("verification_target_ref")
        if not targets and legacy_target:
            targets = [legacy_target]
        if not targets:
            return block(request, "VERIFIER_TARGET_REQUIRED")
        acceptance_mode = request.get("acceptance_mode")
        if acceptance_mode not in {"SIMULATION_FIRST", "CONTRACT_ONLY_SIMULATION_FIRST"}:
            return block(request, "VERIFIER_ACCEPTANCE_MODE_REQUIRED")
        if operation not in {"VERIFY_TASK", "RUN_ACCEPTANCE", "INSPECT_ARTIFACT", "INSPECT_DIFF", "WRITE_VERIFICATION_RESULT", "WRITE_EVIDENCE"}:
            return block(request, "VERIFIER_OPERATION_NOT_IN_ACCEPTANCE_SCOPE")

    if role_id != "ROLE:VERIFIER" and request.get("acceptance_mode") not in {None, "NONE"}:
        return block(request, "ACCEPTANCE_MODE_ROLE_DENIED")

    return {
        "status": "PASS",
        "admitted": True,
        "request_id": request["request_id"],
        "role_id": role_id,
        "activation_command": request["activation_command"],
        "profile_id": profile["profile_id"],
        "mode": mode,
        "context_mode": role["context_mode"],
        "amnesia_required": role["amnesia_required"],
        "external_research": request["external_research"],
        "allowed_operations": role["allowed_operations"],
        "allowed_write_targets": role["allowed_write_targets"],
        "handoff_mode": role["handoff_mode"],
        "reason_codes": [
            "ROLE_CONFIRMED",
            "ACTIVATION_CONFIRMED",
            "PROFILE_CONFIRMED",
            "OPERATION_CONFIRMED",
            "WRITE_SCOPE_CONFIRMED",
            "CURRENT_MUTATION_DENIED",
            "CONTEXT_POLICY_CONFIRMED",
        ],
    }


def block(request: dict[str, Any], reason: str) -> dict[str, Any]:
    return {
        "status": "BLOCK",
        "admitted": False,
        "request_id": request.get("request_id"),
        "role_id": request.get("role_id"),
        "reason_codes": [reason],
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 role-isolated session admission")
    parser.add_argument("--request", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    request = load_json(Path(args.request).resolve())
    result = admission(request)
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
