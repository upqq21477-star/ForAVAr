#!/usr/bin/env python3
from __future__ import annotations

from typing import Any

import regression_executor


def prepare_regression_stage(
    selection: dict[str, Any],
    *,
    regression_result: dict[str, Any] | None,
    execute_regressions: bool,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    if selection["status"] != "PASS":
        if regression_result is not None:
            raise ValueError("M6 不接受 M4 非 PASS 狀態下的 regression_result")
        return None, None

    origin = None
    if regression_result is None and execute_regressions:
        regression_result = regression_executor.execute_selection(selection)
        origin = "EXECUTED_BY_CYCLE"
    elif regression_result is not None:
        origin = "RESULT_SUPPLIED"

    if regression_result is None:
        return None, None

    if regression_result.get("selection_id") != selection["selection_id"]:
        raise ValueError("regression_result selection_id 與 M4 selection_id 不一致")

    execution_status = regression_result.get("status")
    if execution_status not in {"PASS", "FAIL", "INCOMPLETE"}:
        raise ValueError("未知 REGRESSION_EXECUTION_RESULT status")

    return regression_result, {
        "stage_id": "REGRESSION_EXECUTION",
        "status": "INSUFFICIENT_DATA" if execution_status == "INCOMPLETE" else execution_status,
        "object_ref": "REGRESSION_EXECUTION_RESULT:" + str(regression_result["result_id"]),
        "reason_code": origin,
    }
