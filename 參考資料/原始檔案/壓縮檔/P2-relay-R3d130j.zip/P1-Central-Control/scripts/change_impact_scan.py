#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
REGISTRY_PATH = ROOT / "P1-Central-Control/change_impact_registry.json"
CAPABILITY_REGISTRY_PATH = ROOT / "P1-Central-Control/capability_registry.json"


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def normalize_paths(paths: list[str]) -> list[str]:
    normalized = set()
    for raw in paths:
        path = raw.strip().replace("\\", "/")
        while path.startswith("./"):
            path = path[2:]
        if path:
            normalized.add(path)
    return sorted(normalized)


def path_matches(path: str, rule: dict[str, Any]) -> bool:
    if path in rule.get("exact_paths", []):
        return True
    return any(path.startswith(prefix) for prefix in rule.get("prefix_paths", []))


def matching_rules(path: str, registry: dict[str, Any]) -> list[dict[str, Any]]:
    return [
        rule for rule in registry.get("rules", [])
        if path_matches(path, rule)
    ]


def capability_ids(registry: dict[str, Any]) -> list[str]:
    value = load_json(CAPABILITY_REGISTRY_PATH)
    return sorted(
        item["capability_id"]
        for item in value.get("capabilities", [])
        if isinstance(item, dict) and isinstance(item.get("capability_id"), str)
    )


def event_type_for_paths(
    path_results: list[dict[str, Any]],
    has_unknown: bool,
) -> str:
    types = {result["change_type"] for result in path_results}
    if has_unknown:
        types.add("UNKNOWN")
    if len(types) == 1:
        return next(iter(types))
    return "MIXED"


def deterministic_id(prefix: str, value: Any) -> str:
    encoded = json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return f"{prefix}:{hashlib.sha256(encoded).hexdigest()[:16]}"


def build_change_event(
    paths: list[str],
    *,
    base_ref: str,
    head_ref: str,
    registry: dict[str, Any],
) -> dict[str, Any]:
    normalized = normalize_paths(paths)
    if not normalized:
        raise ValueError("CHANGE_EVENT 不能沒有 changed_paths")

    path_results = []
    unknown = False
    for path in normalized:
        rules = matching_rules(path, registry)
        if not rules:
            unknown = True
            path_results.append(
                {
                    "path": path,
                    "matched_rule_ids": [],
                    "change_type": "UNKNOWN",
                    "known": False,
                }
            )
            continue

        types = sorted({rule["change_type"] for rule in rules})
        path_results.append(
            {
                "path": path,
                "matched_rule_ids": [rule["rule_id"] for rule in rules],
                "change_type": types[0] if len(types) == 1 else "MIXED",
                "known": True,
            }
        )

    change_id = deterministic_id(
        "CHANGE",
        {
            "base_ref": base_ref,
            "head_ref": head_ref,
            "changed_paths": normalized,
        },
    )
    return {
        "change_id": change_id,
        "change_type": event_type_for_paths(path_results, unknown),
        "base_ref": base_ref,
        "head_ref": head_ref,
        "changed_paths": normalized,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "detector": "P1_CHANGE_EVENT",
    }


def scan_impact(
    event: dict[str, Any],
    *,
    registry: dict[str, Any],
    capabilities: list[str],
) -> dict[str, Any]:
    affected_capabilities: set[str] = set()
    regression_sets: set[str] = set()
    unknown_paths: list[str] = []

    path_results = []
    for path in event["changed_paths"]:
        rules = matching_rules(path, registry)
        if not rules:
            unknown_paths.append(path)
            path_results.append(
                {
                    "path": path,
                    "matched_rule_ids": [],
                    "change_type": "UNKNOWN",
                    "known": False,
                }
            )
            continue

        for rule in rules:
            mode = rule.get("affected_capabilities", "NONE")
            if mode == "ALL":
                affected_capabilities.update(capabilities)
            elif mode not in ("NONE", None):
                affected_capabilities.update(mode)

            regression_sets.update(rule.get("regression_sets", []))

        path_types = sorted({rule["change_type"] for rule in rules})
        path_results.append(
            {
                "path": path,
                "matched_rule_ids": [rule["rule_id"] for rule in rules],
                "change_type": path_types[0] if len(path_types) == 1 else "MIXED",
                "known": True,
            }
        )

    blocked = bool(unknown_paths)
    reason_codes = (
        ["IMPACT_UNRESOLVED_PATH"]
        if blocked
        else ["IMPACT_RESOLVED"]
    )

    scan = {
        "scan_id": deterministic_id(
            "IMPACT",
            {
                "change_id": event["change_id"],
                "registry_id": registry["registry_id"],
                "path_results": path_results,
            },
        ),
        "change_id": event["change_id"],
        "status": "BLOCK" if blocked else "PASS",
        "decision": "BLOCK" if blocked else "PROCEED",
        "unknown_paths": sorted(set(unknown_paths)),
        "affected_capabilities": sorted(affected_capabilities),
        "required_regression_sets": sorted(regression_sets),
        "path_results": path_results,
        "rule_registry": registry["registry_id"],
        "reason_codes": reason_codes,
    }
    return scan


def changed_paths_from_git(base_ref: str, head_ref: str) -> list[str]:
    proc = subprocess.run(
        [
            "git",
            "-c",
            "core.quotepath=false",
            "diff",
            "--name-only",
            "--diff-filter=ACMRTD",
            base_ref,
            head_ref,
        ],
        cwd=ROOT,
        text=True,
        capture_output=True,
        check=False,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            "無法取得 git diff: " + (proc.stderr.strip() or f"returncode={proc.returncode}")
        )
    return normalize_paths(proc.stdout.splitlines())


def run(
    *,
    paths: list[str],
    base_ref: str,
    head_ref: str,
) -> dict[str, Any]:
    registry = load_json(REGISTRY_PATH)
    capabilities = capability_ids(registry)
    event = build_change_event(
        paths,
        base_ref=base_ref,
        head_ref=head_ref,
        registry=registry,
    )
    impact = scan_impact(
        event,
        registry=registry,
        capabilities=capabilities,
    )
    return {
        "change_event": event,
        "impact_scan": impact,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 M1 CHANGE_EVENT -> IMPACT_SCAN")
    parser.add_argument("--base", required=True, help="git base ref")
    parser.add_argument("--head", required=True, help="git head ref")
    parser.add_argument("--output", help="optional JSON output path")
    args = parser.parse_args()

    result = run(
        paths=changed_paths_from_git(args.base, args.head),
        base_ref=args.base,
        head_ref=args.head,
    )
    encoded = json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + "\n"

    if args.output:
        Path(args.output).write_text(encoded, encoding="utf-8")
    print(encoded, end="")
    return 0 if result["impact_scan"]["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
