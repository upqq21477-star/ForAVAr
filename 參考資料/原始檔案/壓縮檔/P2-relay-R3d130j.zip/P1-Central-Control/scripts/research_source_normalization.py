#!/usr/bin/env python3
"""Normalize durable external research source metadata into stable source identities."""

from __future__ import annotations
import argparse
import hashlib
import json
from datetime import datetime
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from jsonschema import Draft202012Validator, FormatChecker, ValidationError
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
SOURCE_SCHEMA = ROOT / "P1-Central-Control/schemas/research_source.schema.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/research_source_normalization.schema.json"

def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))

def _registry() -> Registry:
    source_schema = _load(SOURCE_SCHEMA)
    result_schema = _load(RESULT_SCHEMA)
    return Registry().with_resource(source_schema["$id"], Resource.from_contents(source_schema)).with_resource(
        result_schema["$id"], Resource.from_contents(result_schema)
    )

def _validate(value: dict[str, Any]) -> None:
    schema = _load(RESULT_SCHEMA)
    Draft202012Validator(schema, registry=_registry(), format_checker=FormatChecker()).validate(value)

def _canonical_url(value: str) -> str:
    parsed = urlsplit(value.strip())
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("INVALID_SOURCE_URL")
    path = parsed.path.rstrip("/") or "/"
    return urlunsplit((parsed.scheme.lower(), parsed.netloc.lower(), path, parsed.query, parsed.fragment))

def _source_id(source_url: str, source_title: str, claim_scope: list[str]) -> str:
    material = json.dumps(
        {"source_url":source_url,"source_title":source_title,"claim_scope":sorted(set(claim_scope))},
        ensure_ascii=False, sort_keys=True, separators=(",",":")
    )
    return "SOURCE:" + hashlib.sha256(material.encode("utf-8")).hexdigest()[:16]

def normalize(sources: list[dict[str, Any]]) -> dict[str, Any]:
    normalized: dict[str, dict[str, Any]] = {}
    mapping: list[dict[str, Any]] = []
    errors: list[dict[str, Any]] = []

    for index, raw in enumerate(sources):
        if not isinstance(raw, dict):
            errors.append({"code":"SOURCE_NOT_OBJECT","input_index":index})
            continue
        try:
            title = str(raw.get("source_title") or "").strip()
            if not title:
                raise ValueError("SOURCE_TITLE_MISSING")
            url = _canonical_url(str(raw.get("source_url") or ""))
            captured_at = str(raw.get("captured_at") or "").strip()
            try:
                parsed_capture_time = datetime.fromisoformat(captured_at.replace("Z", "+00:00"))
            except ValueError as exc:
                raise ValueError("SOURCE_CAPTURED_AT_INVALID") from exc
            if parsed_capture_time.tzinfo is None:
                raise ValueError("SOURCE_CAPTURED_AT_TIMEZONE_REQUIRED")
            scope = raw.get("claim_scope")
            if not isinstance(scope, list) or not scope or any(not isinstance(x,str) or not x.strip() for x in scope):
                raise ValueError("CLAIM_SCOPE_MISSING")
            scope = sorted(set(x.strip() for x in scope))
            item = {
                "source_id": str(raw.get("source_id") or _source_id(url,title,scope)),
                "source_title": title,
                "source_url": url,
                "captured_at": captured_at,
                "claim_scope": scope,
                "source_type": raw.get("source_type","WEB")
            }
            try:
                Draft202012Validator(_load(SOURCE_SCHEMA), format_checker=FormatChecker()).validate(item)
            except ValidationError as exc:
                # Invalid source items become structured BLOCK rows; unrelated
                # programming/configuration errors must not be hidden as data errors.
                errors.append({
                    "code": "SOURCE_SCHEMA_INVALID",
                    "input_index": index,
                    "detail": str(exc),
                })
                continue
            source_url_key = url
            existing = next((x for x in normalized.values() if x["source_url"] == source_url_key), None)
            if existing:
                if existing["source_title"] != item["source_title"] or existing["claim_scope"] != item["claim_scope"]:
                    errors.append({"code":"SOURCE_URL_METADATA_CONFLICT","input_index":index,"detail":url})
                    continue
                mapping.append({"input_index":index,"source_id":existing["source_id"]})
                continue
            if item["source_id"] in normalized and normalized[item["source_id"]] != item:
                errors.append({"code":"SOURCE_ID_CONFLICT","input_index":index,"detail":item["source_id"]})
                continue
            normalized[item["source_id"]] = item
            mapping.append({"input_index":index,"source_id":item["source_id"]})
        except ValueError as exc:
            errors.append({"code":str(exc),"input_index":index})

    result = {
        "status":"PASS" if not errors else "BLOCK",
        "input_count":len(sources),
        "unique_source_count":len(normalized),
        "sources":list(normalized.values()),
        "mapping":mapping,
        "errors":errors
    }
    _validate(result)
    return result

def main() -> int:
    parser=argparse.ArgumentParser()
    parser.add_argument("--input",required=True)
    parser.add_argument("--output")
    args=parser.parse_args()
    value=_load(Path(args.input))
    result=normalize(value)
    text=json.dumps(result,ensure_ascii=False,indent=2)+"\n"
    if args.output:
        Path(args.output).write_text(text,encoding="utf-8")
    print(text,end="")
    return 0 if result["status"]=="PASS" else 2

if __name__=="__main__":
    raise SystemExit(main())
