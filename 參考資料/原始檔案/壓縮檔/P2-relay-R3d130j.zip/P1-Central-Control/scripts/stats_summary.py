"""stats_summary -- pure stdlib descriptive statistics with status codes (CAP-STATISTICS, R3d12zu S4b batch 1).
Input {dataset_id, values[], range mark, trust}; values accept int/float only (bool, NaN, inf, str -> REJECTED with bad_index).
End: OK (n>=2) | PARTIAL (n=1, stdev None, reason 資料不足) | INSUFFICIENT_DATA (n=0) | REJECTED (bad value/label) |
STAT_ERROR (StatisticsError caught inside; never leaks, never guessed).  No side effects: key = sha256(values, range), so
a rerun after an interruption gives the same output.  downstream_value() returns UNKNOWN for unusable results (never computes on null).
Evidence ceiling: SIMULATED_PASS.  The 3.12 exception conditions follow the 3.4 docs (UNKNOWN until measured)."""
from __future__ import annotations

import hashlib
import json
import math
import statistics
from typing import Any

TRUST = ("UNTRUSTED", "VERIFIED", "ACCEPTED")
FIELDS = ("n", "min", "max", "mean", "median", "stdev")


def _key(values: Any, range_mark: Any) -> str:
    return hashlib.sha256(json.dumps([values, range_mark], default=repr).encode("utf-8")).hexdigest()


def _result(ds: Any, values: Any, rng: Any, trust: Any, status: str, reason: str = "", bad: int | None = None, **f: Any) -> dict[str, Any]:
    out: dict[str, Any] = {"dataset_id": ds, "status": status, "reason": reason, "bad_index": bad, "range": rng, "trust": trust,
                           "key": _key(values, rng), **{k: None for k in FIELDS}}
    out.update(f)
    return out


def _bad_index(values: list[Any]) -> int | None:
    for i, v in enumerate(values):
        try:
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v):
                return i
        except OverflowError:  # an int too large for float
            return i
    return None


def summarize(dataset_id: Any, values: Any, range_mark: Any, trust: Any) -> dict[str, Any]:
    def rej(why: str, bad: int | None = None) -> dict[str, Any]:
        return _result(dataset_id, values, range_mark, trust, "REJECTED", why, bad)

    if not isinstance(range_mark, str) or not range_mark:
        return rej("缺範圍標記")
    if trust not in TRUST:
        return rej("缺信任標記")
    if not isinstance(values, (list, tuple)):
        return rej("values 必須是 list")
    bad = _bad_index(list(values))
    if bad is not None:
        return rej(f"第 {bad} 列不是有限的 int/float", bad)
    if not values:
        return _result(dataset_id, values, range_mark, trust, "INSUFFICIENT_DATA", "n=0", n=0)
    base = {"n": len(values), "min": min(values), "max": max(values)}
    try:
        base.update(mean=statistics.mean(values), median=statistics.median(values))
        if len(values) == 1:
            return _result(dataset_id, values, range_mark, trust, "PARTIAL", "資料不足", **base)
        base["stdev"] = statistics.stdev(values)
    except statistics.StatisticsError as e:  # converted here; nothing guessed
        return _result(dataset_id, values, range_mark, trust, "STAT_ERROR", str(e)[:80], n=len(values))
    return _result(dataset_id, values, range_mark, trust, "OK", **base)


def check_result(result: dict[str, Any], values: list[Any]) -> bool:
    """VF: recompute with plain arithmetic (not the statistics module) and compare."""
    if result.get("status") not in ("OK", "PARTIAL") or _bad_index(list(values)) is not None or not values:
        return False
    s, n = sorted(values), len(values)
    mean = sum(values) / n
    med = s[n // 2] if n % 2 else (s[n // 2 - 1] + s[n // 2]) / 2
    exp: dict[str, Any] = {"n": n, "min": s[0], "max": s[-1], "mean": mean, "median": med}
    if n >= 2:
        exp["stdev"] = math.sqrt(sum((x - mean) ** 2 for x in values) / (n - 1))
    elif result.get("stdev") is not None:
        return False
    return all(result.get(k) is not None and math.isclose(result[k], v, rel_tol=1e-9, abs_tol=1e-12) for k, v in exp.items())


def downstream_value(result: dict[str, Any], field: str) -> Any:
    """E7: an unusable result is UNKNOWN for consumers (RELATION strength), never a null calculation."""
    v = result.get(field)
    return v if result.get("status") in ("OK", "PARTIAL") and v is not None else "UNKNOWN"
