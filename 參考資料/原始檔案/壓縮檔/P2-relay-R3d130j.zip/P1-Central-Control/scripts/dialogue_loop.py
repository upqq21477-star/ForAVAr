#!/usr/bin/env python3
"""P2 dialogue_loop — FR-10 closed loop: turn -> Event Log -> Brief.recent -> continued conversation (R4R-S4; stdlib only).

Facts live in event_log (DIALOGUE_TURN, hash only, never the text).  This file holds the CONSUMER (resume_from_brief),
the VERIFIER (verify_dialogue) and the rerunnable closed-loop simulation (producer -> consumer -> verifier -> feedback).
Evidence level of the simulation: SIMULATED_PASS (temp Event Log; real librarian and real role router; no model, no network).

  python3 P1-Central-Control/scripts/dialogue_loop.py --simulate-dialogue

Track A (manual equivalent, no code, 8 lines):
1) give each conversation an id; number every turn 1, 2, 3 ... without gaps;
2) per turn write one line: conversation id, turn, USER/ASSISTANT/COMMAND, first 12 hex of sha256 of the text, optional ref;
3) never paste the full text into the line (hash only);   4) a `!` command is also one line; a blocked command gets a BLOCKED ref;
5) start the next session by pasting the last 10 lines as "recent";   6) the next turn number = last number + 1;
7) if the pasted lines do not end at the newest line you have, they are BEHIND: re-paste first;
8) to check a quote, hash it and compare with the line's 12 hex characters; a difference means the quote is not that turn.
"""
from __future__ import annotations

import argparse
import re
import sys
import tempfile
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
import event_log as el  # noqa: E402

_RECENT_RE = re.compile(r"^DIALOGUE:(?P<cid>.+)#(?P<turn>\d+) (?P<role>USER|ASSISTANT|COMMAND) sha256:(?P<h12>[0-9a-f]{12})")
NEXT = {"OK": "CONTINUE", "BRIEF_BEHIND": "REBUILD_BRIEF", "REJECTED": "FIX_RECORD", "NO_DIALOGUE": "START_AT_TURN_1"}


def _res(status: str, reasons: list[str], next_turn: int | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {"status": status, "reasons": reasons, "next_action": NEXT[status]}
    if next_turn is not None:
        out["next_turn"] = next_turn
    return out


def resume_from_brief(brief: dict[str, Any], events: list[dict[str, Any]], conversation_id: str) -> dict[str, Any]:
    """Consumer: does Brief.recent end where the Event Log ends?  Fail-closed on any disagreement.
    OK -> next_turn = last + 1;  BRIEF_BEHIND -> the log has newer turns;  REJECTED -> brief claims what the log lacks,
    hash prefix differs, or the log itself has a gap;  NO_DIALOGUE -> nothing recorded yet."""
    try:
        turns = el.read_dialogue(events, conversation_id)
    except ValueError as exc:
        return _res("REJECTED", [str(exc)])
    seen = []
    for item in brief.get("recent", []):
        m = _RECENT_RE.match(item) if isinstance(item, str) else None
        if m and m["cid"] == conversation_id:
            seen.append((int(m["turn"]), m["role"], m["h12"]))
    if not seen:
        return _res("NO_DIALOGUE", [], 1) if not turns else _res("BRIEF_BEHIND", [f"BRIEF_HAS_NO_DIALOGUE:log_last={len(turns)}"])
    last_turn, role, h12 = seen[-1]
    if last_turn > len(turns):
        return _res("REJECTED", [f"BRIEF_AHEAD_OF_LOG:brief={last_turn} log={len(turns)}"])
    logged = turns[last_turn - 1]
    if logged["content_hash"][:12] != h12 or logged["role"] != role:
        return _res("REJECTED", [f"RECENT_DISAGREES_WITH_LOG:turn={last_turn}"])
    if last_turn < len(turns):
        return _res("BRIEF_BEHIND", [f"BRIEF_BEHIND:brief={last_turn} log={len(turns)}"])
    return _res("OK", [], last_turn + 1)


def verify_dialogue(events: list[dict[str, Any]], conversation_id: str, contents: dict[int, str] | None = None) -> dict[str, Any]:
    """Verifier: contiguous turns, and every supplied text hashes to its logged hash (independent re-derivation)."""
    try:
        turns = el.read_dialogue(events, conversation_id)
    except ValueError as exc:
        return _res("REJECTED", [str(exc)])
    bad = []
    for number, text in sorted((contents or {}).items()):
        if not 1 <= number <= len(turns):
            bad.append(f"NO_SUCH_TURN:{number}")
        elif el.dialogue_content_hash(text) != turns[number - 1]["content_hash"]:
            bad.append(f"DIALOGUE_HASH_MISMATCH:{number}")
    return _res("REJECTED", bad) if bad else _res("OK", [], len(turns) + 1)


def simulate() -> list[tuple[str, bool, str]]:
    """Closed loop with the real functions: producer (record turns + routed command) -> consumer (Brief.recent, resume) ->
    verifier (hash check) -> feedback (brief behind -> rebuild).  Everything goes through module attributes, so a broken
    function makes a step FAIL."""
    import librarian
    import role_command_router as router

    out: list[tuple[str, bool, str]] = []

    def rec(name: str, ok: bool, note: str = "") -> None:
        out.append((name, bool(ok), note))

    wf, cid, t0 = "work-sim-0001", "conv-sim-0001", "2026-10-15T10:00:0{}+00:00"
    texts = {1: "SECRET-MARK user asks about the build", 2: "assistant answers 你好"}
    req = {"brief_session_id": "sess-sim-0001", "work_id": wf, "route": "BUILD",
           "topics": [{"topic": "conversation record", "question": "which dialogue turns exist", "function_id": "F05"}]}
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp) / "events.jsonl"
        log = el.EventLog(path)
        el.record_dialogue_turn(log, workflow_id=wf, conversation_id=cid, role="USER", content=texts[1], occurred_at=t0.format(1))
        el.record_dialogue_turn(log, workflow_id=wf, conversation_id=cid, role="ASSISTANT", content=texts[2], ref="reply/1",
                                occurred_at=t0.format(2))
        router.resolve_and_record("!施工", event_log_path=path, workflow_id=wf, conversation_id=cid, occurred_at=t0.format(3))
        rec("producer: three turns recorded, turn numbers 1..3 contiguous",
            [t["turn"] for t in el.read_dialogue(log.read_all(), cid)] == [1, 2, 3])
        rec("producer: the log keeps hashes, not text", "SECRET-MARK" not in path.read_text(encoding="utf-8"))
        try:
            router.resolve_and_record("!不存在的指令", event_log_path=path, workflow_id=wf, conversation_id=cid, occurred_at=t0.format(4))
            blocked = False
        except ValueError:
            blocked = True
        last = el.read_dialogue(log.read_all(), cid)[-1]
        rec("producer: a blocked command is raised AND recorded with a BLOCKED ref",
            blocked and last["role"] == "COMMAND" and last["ref"].startswith("ROLE_ROUTE_BLOCKED:"), str(last))
        events = log.read_all()
        brief = librarian.collect_brief(req, recent=el.dialogue_recent_refs(events, cid))
        rec("consumer: Brief.recent carries the four turn refs", len(brief["recent"]) == 4, str(brief["recent"]))
        _, ev = librarian.deliver(brief, path, occurred_at=t0.format(5))
        rec("consumer: BRIEF_DELIVERED shares the revision line with the turns", ev["revision"] == 5)
        r = resume_from_brief(brief, log.read_all(), cid)
        rec("consumer: resume OK at next turn 5", r["status"] == "OK" and r["next_turn"] == 5, str(r))
        el.record_dialogue_turn(log, workflow_id=wf, conversation_id=cid, role="USER", content="continue please",
                                occurred_at=t0.format(6))
        events = log.read_all()
        rec("continuation: turn 5 recorded after the Brief delivery", el.read_dialogue(events, cid)[-1]["turn"] == 5)
        v = verify_dialogue(events, cid, {1: texts[1], 2: texts[2]})
        rec("verifier: true texts hash to the logged hashes", v["status"] == "OK", str(v))
        v = verify_dialogue(events, cid, {2: texts[2] + " (edited)"})
        rec("verifier: an edited text -> DIALOGUE_HASH_MISMATCH", v["status"] == "REJECTED" and v["reasons"] == ["DIALOGUE_HASH_MISMATCH:2"], str(v))
        r = resume_from_brief(brief, events, cid)
        rec("feedback: the old Brief is now BRIEF_BEHIND and asks for a rebuild",
            r["status"] == "BRIEF_BEHIND" and r["next_action"] == "REBUILD_BRIEF", str(r))
        brief2 = librarian.collect_brief(req, recent=el.dialogue_recent_refs(events, cid))
        r = resume_from_brief(brief2, events, cid)
        rec("feedback: rebuilt Brief -> OK at next turn 6", r["status"] == "OK" and r["next_turn"] == 6, str(r))
        gapped = [e for e in events if not (e["event_type"] == "DIALOGUE_TURN" and e["segment_delta"]["turn"] == 2)]
        rec("verifier: a missing turn -> REJECTED (gap)", verify_dialogue(gapped, cid)["status"] == "REJECTED")
        rec("projection: the reducer counts the turns", librarian.reduce_events(events)["type_counts"].get("DIALOGUE_TURN") == 5)
    return out


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--simulate-dialogue", action="store_true")
    args = ap.parse_args()
    if not args.simulate_dialogue:
        ap.print_help()
        return 2
    results = simulate()
    for name, ok, note in results:
        print(("PASS " if ok else "FAIL ") + name + ("" if ok or not note else f"  [{note}]"))
    bad = [n for n, ok, _ in results if not ok]
    print(f"dialogue simulation (SIMULATED_PASS): {len(results) - len(bad)}/{len(results)}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
