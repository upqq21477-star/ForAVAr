#!/usr/bin/env python3
"""P1 P14-D one-command recovery, closure, and truth projection entrypoint."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/p14_d_recovery_entrypoint.schema.json"
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

from actions_execution_closure import close
from actions_execution_diagnostic import build as build_diagnostic
from actions_execution_truth_adapter import build as build_truth
from current_truth_reconciliation import reconcile


def load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def validate(value: dict[str, Any]) -> None:
    Draft202012Validator(load(SCHEMA)).validate(value)


def normalize_local_bundle(bundle: dict[str, Any], *, allow_simulated: bool = False) -> dict[str, Any]:
    evidence_id = bundle.get("evidence_id")
    status = bundle.get("status")
    head_sha = bundle.get("head_sha")
    evidence_class = bundle.get("evidence_class")
    truth_boundary = bundle.get("truth_boundary")
    if not isinstance(evidence_id, str) or not evidence_id:
        raise ValueError("LOCAL_BUNDLE_EVIDENCE_ID_MISSING")
    if status not in {"PASS", "FAIL", "INCOMPLETE"}:
        raise ValueError("LOCAL_BUNDLE_STATUS_INVALID")
    if not isinstance(head_sha, str) or len(head_sha) < 7:
        raise ValueError("LOCAL_BUNDLE_HEAD_SHA_INVALID")

    expected_class = "SIMULATED_SCENARIO" if allow_simulated else "OBSERVED_LOCAL_RUNTIME"
    expected_boundary = "SIMULATED_SCENARIO_ONLY" if allow_simulated else "LOCAL_RUNTIME_ONLY_NOT_GITHUB_ACTIONS"
    if evidence_class != expected_class:
        raise ValueError("LOCAL_BUNDLE_EVIDENCE_CLASS_INVALID")
    if truth_boundary != expected_boundary:
        raise ValueError("LOCAL_BUNDLE_TRUTH_BOUNDARY_INVALID")

    return {
        "acceptance_id": evidence_id,
        "status": status,
        "head_sha": head_sha,
        "evidence_class": evidence_class,
    }


def runtime_fixture_from_diagnostic(diagnostic: dict[str, Any], *, head_sha: str) -> dict[str, Any]:
    run_id = diagnostic["diagnostic_id"].split(":", 1)[-1]
    if not run_id.isdigit():
        raise ValueError("INVALID_DIAGNOSTIC_RUN_ID")
    return {"run": {"id": int(run_id), "head_sha": head_sha}, "classification": diagnostic["classification"]}


def execute(
    *,
    run_path: Path,
    jobs_path: Path,
    local_bundle_path: Path,
    head_sha: str,
    current_path: Path | None = None,
    work_packet_path: Path | None = None,
    output_path: Path | None = None,
    allow_simulated: bool = False,
) -> dict[str, Any]:
    run = load(run_path)
    jobs = load(jobs_path)
    raw_bundle = load(local_bundle_path)

    run_head_sha = run.get("head_sha")
    if not isinstance(run_head_sha, str) or len(run_head_sha) < 7:
        raise ValueError("ACTIONS_RUN_HEAD_SHA_MISSING")
    if run_head_sha != head_sha:
        raise ValueError("ACTIONS_RUN_HEAD_SHA_MISMATCH")

    diagnostic = build_diagnostic(run, jobs)
    acceptance = normalize_local_bundle(raw_bundle, allow_simulated=allow_simulated)
    closure = close(diagnostic, acceptance)
    truth_record = build_truth(
        diagnostic,
        closure,
        head_sha=head_sha,
        observed_at=raw_bundle.get("completed_at"),
    )

    reconciliation = None
    if current_path or work_packet_path:
        if not (current_path and work_packet_path):
            raise ValueError("CURRENT_AND_WORK_PACKET_MUST_BE_PROVIDED_TOGETHER")
        reconciliation = reconcile(
            current=load(current_path),
            work_packet=load(work_packet_path),
            truth_record=truth_record,
            runtime_fixture=runtime_fixture_from_diagnostic(diagnostic, head_sha=head_sha),
        )

    result = {
        "schema_version": "1.0",
        "status": (
            "PASS"
            if closure["program_truth"] == "PROGRAM_VERIFIED"
            and (reconciliation is None or reconciliation["status"] == "PASS")
            else "FAIL"
            if closure["program_truth"] in {"PROGRAM_REGRESSION", "EVIDENCE_CONFLICT", "BLOCKED"}
            or (reconciliation is not None and reconciliation["status"] == "RECONCILIATION_REQUIRED")
            else "INCOMPLETE"
        ),
        "diagnostic": diagnostic,
        "local_acceptance": acceptance,
        "closure": closure,
        "truth_record": truth_record,
        "reconciliation": reconciliation,
        "truth_boundary": "EXISTING_P1_DIAGNOSTIC_CLOSURE_TRUTH_CHAIN",
    }
    validate(result)

    if output_path:
        output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 P14-D one-command Actions diagnostic -> local evidence -> closure -> truth")
    parser.add_argument("--run", required=True)
    parser.add_argument("--jobs", required=True)
    parser.add_argument("--local-bundle", required=True)
    parser.add_argument("--head-sha", required=True)
    parser.add_argument("--current")
    parser.add_argument("--work-packet")
    parser.add_argument("--output", required=True)
    args = parser.parse_args()

    result = execute(
        run_path=Path(args.run).resolve(),
        jobs_path=Path(args.jobs).resolve(),
        local_bundle_path=Path(args.local_bundle).resolve(),
        head_sha=args.head_sha,
        current_path=Path(args.current).resolve() if args.current else None,
        work_packet_path=Path(args.work_packet).resolve() if args.work_packet else None,
        output_path=Path(args.output).resolve(),
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 2 if result["status"] == "INCOMPLETE" else 1


if __name__ == "__main__":
    raise SystemExit(main())
