#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
EVIDENCE_SCHEMA = ROOT / "P1-Central-Control/schemas/repository_architecture_evidence.schema.json"

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
import system_independence_gate as registry_gate


def evaluate(repository_registry: dict[str, Any], repository_evidence: dict[str, Any]) -> dict[str, Any]:
    registry = registry_gate.evaluate(repository_registry, None)
    boundary = repository_evidence.get("boundary", {})
    dependency = repository_evidence.get("dependency", {})

    violations = []
    for key in (
        "direct_cross_system_imports",
        "direct_file_writes",
        "foreign_current_mutations",
        "handoff_calls",
    ):
        violations.extend(boundary.get(key, []))

    unknowns = sorted(set(
        dependency.get("unresolved", [])
        + boundary.get("dynamic_boundary_unknown", [])
    ))

    if registry["registry_errors"] or violations:
        status = "VIOLATION"
    elif unknowns:
        status = "UNKNOWN"
    else:
        status = "INDEPENDENT"

    reason_codes = []
    if registry["registry_errors"]:
        reason_codes.append("REGISTRY_CONTRACT_VIOLATION")
    if boundary.get("direct_cross_system_imports"):
        reason_codes.append("DIRECT_CROSS_SYSTEM_IMPORT")
    if boundary.get("direct_file_writes"):
        reason_codes.append("DIRECT_CROSS_SYSTEM_WRITE")
    if boundary.get("foreign_current_mutations"):
        reason_codes.append("FOREIGN_CURRENT_MUTATION")
    if boundary.get("handoff_calls"):
        reason_codes.append("DIRECT_SYSTEM_HANDOFF")
    if unknowns:
        reason_codes.append("BOUNDARY_UNRESOLVED")
    if not reason_codes:
        reason_codes.append("INDEPENDENCE_CONFIRMED")

    return {
        "status": status,
        "system_count": registry["system_count"],
        "registry_errors": registry["registry_errors"],
        "violations": violations,
        "unknowns": unknowns,
        "reason_codes": sorted(set(reason_codes)),
        "evidence_model": "REGISTRY_PLUS_REPOSITORY_EVIDENCE",
        "dependency_edge_count": len(dependency.get("edges", [])),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 repository-level System Independence Gate")
    parser.add_argument("--registry", default=str(ROOT / "P1-Central-Control/system_registry.json"))
    parser.add_argument("--root", default=str(ROOT))
    parser.add_argument("--evidence", help="precomputed repository_architecture_evidence.json")
    args = parser.parse_args()

    registry = json.loads(Path(args.registry).read_text(encoding="utf-8"))

    if args.evidence:
        evidence = json.loads(Path(args.evidence).read_text(encoding="utf-8"))
    else:
        import repository_architecture_evidence as evidence_adapter
        evidence = evidence_adapter.collect(
            Path(args.root).resolve(),
            [x["system_id"] for x in registry.get("systems", [])],
        )

    schema = json.loads(EVIDENCE_SCHEMA.read_text(encoding="utf-8"))
    errors = sorted(Draft202012Validator(schema).iter_errors(evidence), key=lambda e: list(e.path))
    if errors:
        result = {
            "status": "UNKNOWN",
            "reason_codes": ["INVALID_REPOSITORY_EVIDENCE"],
            "errors": [e.message for e in errors],
        }
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 3

    result = evaluate(registry, evidence)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "INDEPENDENT" else 3


if __name__ == "__main__":
    raise SystemExit(main())
