#!/usr/bin/env python3
"""Validate finalized construction output at the canonical registry boundary."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/construction_registration.schema.json"

REGISTRY_PATHS = {
    "SYSTEM": "P1-Central-Control/system_registry.json",
    "CAPABILITY": "P1-Central-Control/capability_registry.json",
    "FUNCTION": "P1-Central-Control/function_capability_registry.json",
}


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"JSON_OBJECT_REQUIRED:{path}")
    return value


def _validate_request(registration: dict[str, Any]) -> None:
    schema = _load(SCHEMA)
    errors = sorted(
        Draft202012Validator(schema).iter_errors(registration),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError("; ".join(error.message for error in errors))


def _existing_ids(target_type: str, registry: dict[str, Any]) -> set[str]:
    rows = registry.get("systems" if target_type == "SYSTEM" else
                        "capabilities" if target_type == "CAPABILITY" else
                        "functions", [])
    key = "system_id" if target_type == "SYSTEM" else (
        "capability_id" if target_type == "CAPABILITY" else "function_id"
    )
    return {row.get(key) for row in rows if isinstance(row, dict) and row.get(key)}


def _validate_record(target_type: str, record: dict[str, Any], target_id: str) -> None:
    required = {
        "SYSTEM": [
            "system_id", "name", "interface", "result_contract",
            "allowed_inbound", "allowed_outbound", "direct_system_handoff",
            "runtime_dependencies", "state_owner", "completion", "profile_ref",
        ],
        "CAPABILITY": [
            "capability_id", "class", "implementation", "levels", "kind",
            "context_tier", "dependencies", "retirement_state",
        ],
        "FUNCTION": [
            "function_id", "function_name", "classification",
            "canonical_capability", "runtime_status", "execution_policy",
        ],
    }.get(target_type)
    if required is None:
        return
    missing = [field for field in required if field not in record]
    if missing:
        raise ValueError(
            f"REGISTRATION_FIELDS_MISSING:{target_type}:{','.join(missing)}"
        )
    id_field = {
        "SYSTEM": "system_id",
        "CAPABILITY": "capability_id",
        "FUNCTION": "function_id",
    }[target_type]
    if record.get(id_field) != target_id:
        raise ValueError(f"REGISTRATION_ID_MISMATCH:{id_field}")


def validate(
    registration: dict[str, Any],
    *,
    base_dir: str | Path | None = None,
    canonical_registry_root: str | Path | None = None,
) -> dict[str, Any]:
    _validate_request(registration)
    base = Path(base_dir or ".").resolve()
    target_type = registration["target_type"]
    target_id = registration["target_id"]
    mode = registration["mode"]

    if target_type == "ARCHITECTURE_CHANGE":
        return {
            "status": "PASS",
            "target_type": target_type,
            "target_id": target_id,
            "mode": mode,
            "registration": "DECISION_REF_READY",
        }

    if target_type == "SKILL":
        artifact = base / registration["artifact_path"]
        if not artifact.is_file():
            return {"status": "BLOCK", "reason": "REGISTRATION_ARTIFACT_MISSING"}
        manifest = _load(artifact)
        required = [
            "skill_id", "skill_version", "capabilities",
            "input_scope", "output_contract", "execution_policy",
        ]
        missing = [field for field in required if field not in manifest]
        if missing:
            return {
                "status": "BLOCK",
                "reason": "SKILL_MANIFEST_FIELDS_MISSING",
                "missing": missing,
            }
        if manifest.get("skill_id") != target_id:
            return {"status": "BLOCK", "reason": "SKILL_ID_MISMATCH"}
        return {
            "status": "PASS",
            "target_type": target_type,
            "target_id": target_id,
            "mode": mode,
            "registration": "SKILL_MANIFEST_READY",
        }

    registry_base = Path(canonical_registry_root or base).resolve()
    registry_path = registry_base / REGISTRY_PATHS[target_type]
    if not registry_path.is_file():
        return {"status": "BLOCK", "reason": "CANONICAL_REGISTRY_MISSING"}
    registry = _load(registry_path)
    artifact = base / registration["artifact_path"]
    if not artifact.is_file():
        return {"status": "BLOCK", "reason": "REGISTRATION_ARTIFACT_MISSING"}
    record = _load(artifact)
    _validate_record(target_type, record, target_id)

    existing = _existing_ids(target_type, registry)
    if mode == "CREATE_NEW" and target_id in existing:
        return {"status": "BLOCK", "reason": "TARGET_ALREADY_EXISTS"}
    if mode == "UPDATE_EXISTING" and target_id not in existing:
        return {"status": "BLOCK", "reason": "TARGET_NOT_FOUND"}

    return {
        "status": "PASS",
        "target_type": target_type,
        "target_id": target_id,
        "mode": mode,
        "registry_path": REGISTRY_PATHS[target_type],
        "registration": "READY",
    }
