#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
from typing import Any
from datetime import datetime, timezone

import jsonschema
from jsonschema import Draft202012Validator

ROOT=Path(__file__).resolve().parents[2]
REPORT_SCHEMA=ROOT/"P1-Central-Control/schemas/control_gate_report.schema.json"
ACCEPTANCE_SCHEMA=ROOT/"P1-Central-Control/schemas/local_acceptance_record.schema.json"


def load(path: Path) -> dict[str, Any]:
    value=json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value,dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def validate_report(report: dict[str, Any]) -> None:
    schema=load(REPORT_SCHEMA)
    Draft202012Validator(schema).validate(report)


def validate_record(record: dict[str, Any]) -> None:
    schema=load(ACCEPTANCE_SCHEMA)
    Draft202012Validator(schema).validate(record)


def write_state_atomically(files: dict[Path, dict[str, Any]]) -> None:
    """Write several JSON state files all-or-nothing.

    Every file is serialised to a temp file first; only then are they swapped in. If a
    swap fails part-way, the files already swapped are restored from their original bytes,
    so a failed close never leaves Current/Work/Construction disagreeing with each other.
    """
    originals = {path: path.read_bytes() for path in files}
    staged: list[tuple[Path, Path]] = []
    swapped: list[Path] = []
    try:
        for path, value in files.items():
            tmp = path.with_name(path.name + ".tmp")
            tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            staged.append((tmp, path))
        for tmp, path in staged:
            os.replace(tmp, path)
            swapped.append(path)
    except BaseException:
        for path in swapped:
            path.write_bytes(originals[path])
        raise
    finally:
        for tmp, _ in staged:
            tmp.unlink(missing_ok=True)


def validator_kind() -> str:
    """Which schema validator ran: the real package, or the in-repo stdlib fallback."""
    if getattr(jsonschema, "FALLBACK", False):
        return "STDLIB_FALLBACK"
    return "jsonschema==" + str(getattr(jsonschema, "__version__", "unknown"))


def content_hash(path: Path) -> str:
    return "sha256:"+hashlib.sha256(path.read_bytes()).hexdigest()


def build(
    report: dict[str, Any],
    report_path: Path,
    *,
    execution_source: str = "LOCAL",
    execution_id: str | None = None,
) -> dict[str, Any]:
    validate_report(report)
    status = report["status"]
    if execution_source not in {"LOCAL", "GITHUB_ACTIONS", "SELF_HOSTED"}:
        raise ValueError("INVALID_EXECUTION_SOURCE")
    if not execution_id:
        execution_id = f"{execution_source}:{report['head_sha']}"
    record={
        "acceptance_id":f"LOCAL_ACCEPTANCE:{report['head_sha']}",
        "report_id":report["report_id"],
        "report_sha256":content_hash(report_path),
        "head_sha":report["head_sha"],
        "execution_source":execution_source,
        "execution_id":execution_id,
        "schema_validator":validator_kind(),
        "status":status,
        "stages":[
            {
                "stage_id":stage["stage_id"],
                "status":stage["status"],
                "reason_code":stage["reason_code"],
            }
            for stage in report["stages"]
        ],
    }
    validate_record(record)
    return record


def close_simulation(
    report: dict[str, Any],
    record: dict[str, Any],
    *,
    current_path: Path,
    work_packet_path: Path,
    construction_packet_path: Path,
    execution_source: str = "LOCAL",
    execution_id: str | None = None,
    head_sha: str = "",
) -> dict[str, Any]:
    """Close the active Work Unit from its one SIMULATION_ONLY acceptance result.

    This is the existing acceptance owner's closure step, not a second acceptance engine.
    It mutates only canonical Current/Work/Construction state after a PASS record.
    """
    if report.get("mode") != "SIMULATION_ONLY" or not report.get("simulated"):
        raise ValueError("SIMULATION_CLOSE_REQUIRES_SIMULATION_ONLY_REPORT")
    if record.get("status") != "PASS":
        raise ValueError("SIMULATION_CLOSE_REQUIRES_PASS")
    if record.get("head_sha") != head_sha or report.get("head_sha") != head_sha:
        raise ValueError("SIMULATION_CLOSE_HEAD_SHA_MISMATCH")
    if execution_source not in {"LOCAL", "GITHUB_ACTIONS", "SELF_HOSTED"}:
        raise ValueError("INVALID_EXECUTION_SOURCE")
    if execution_id is None:
        execution_id = f"{execution_source}:{head_sha}"
    if not isinstance(execution_id, str) or not execution_id.strip():
        raise ValueError("EXECUTION_ID_REQUIRED")

    current = load(current_path)
    work = load(work_packet_path)
    construction = load(construction_packet_path)

    stage = current.get("current_stage", {})
    acceptance_ref = stage.get("acceptance_ref")
    if not acceptance_ref:
        raise ValueError("SIMULATION_CLOSE_REQUIRES_CENTRAL_ACCEPTANCE_CONTEXT")
    acceptance_path = (
        current_path.parent / acceptance_ref
        if not Path(acceptance_ref).is_absolute()
        else Path(acceptance_ref)
    )
    if not acceptance_path.is_file():
        raise ValueError("SIMULATION_CLOSE_CENTRAL_ACCEPTANCE_CONTEXT_NOT_FOUND")
    acceptance_context = load(acceptance_path)
    if (
        acceptance_context.get("kind") != "ACCEPTANCE_CONTEXT"
        or acceptance_context.get("authority") != "P1-CURRENT"
        or acceptance_context.get("lifecycle_owner") != "CENTRAL"
        or acceptance_context.get("mode") != "SIMULATION_ONLY"
    ):
        raise ValueError("SIMULATION_CLOSE_CENTRAL_ACCEPTANCE_CONTEXT_INVALID")
    unit = stage.get("work_unit_id") or stage.get("id")
    if not unit or acceptance_context.get("work_unit_ref") != unit:
        raise ValueError("SIMULATION_CLOSE_CENTRAL_ACCEPTANCE_CONTEXT_WORK_UNIT_MISMATCH")
    if acceptance_context.get("head_sha") != head_sha:
        raise ValueError("SIMULATION_CLOSE_ACCEPTANCE_CONTEXT_HEAD_SHA_MISMATCH")
    if stage.get("status") not in {"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE", "READY_FOR_CLOSE_ACCEPTANCE"}:
        raise ValueError("SIMULATION_CLOSE_NOT_PENDING")
    if work.get("status") not in {"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE", "READY_FOR_CLOSE_ACCEPTANCE"}:
        raise ValueError("SIMULATION_CLOSE_WORK_PACKET_NOT_PENDING")
    if work.get("acceptance", {}).get("mode") != "SIMULATION_ONLY":
        raise ValueError("SIMULATION_CLOSE_WORK_PACKET_MODE_INVALID")
    if construction.get("work_unit") != unit:
        raise ValueError("SIMULATION_CLOSE_CONSTRUCTION_MISMATCH")

    observed_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
    close_result = {
        "mode": "SIMULATION_ONLY",
        "status": "PASS",
        "simulated": True,
        "acceptance_id": record["acceptance_id"],
        "report_id": record["report_id"],
        "report_sha256": record["report_sha256"],
        "head_sha": head_sha,
        "execution_source": execution_source,
        "execution_id": execution_id,
        "closed_at": observed_at,
    }

    stage["status"] = "VERIFIED"
    stage["validated_control_gate_run"] = (
        int(execution_id)
        if execution_source == "GITHUB_ACTIONS" and execution_id.isdigit()
        else None
    )
    stage["validated_head_sha"] = head_sha
    stage["simulation_acceptance"] = close_result
    stage["next_exact_action"] = f"{unit} 已驗收，不再重複 close；下一步見 docs/handoffs/handoff.data.json『下一步』。"
    stage["implementation_step"] = "FINALIZE"

    current["current_stage"] = stage
    current["latest_runtime_observation"] = {
        "observed_at": observed_at,
        "workflow": f"{unit} acceptance",
        "run_id": None,
        "run_attempt": None,
        "job_id": None,
        "head_sha": head_sha,
        "job_conclusion": None,
        "step_evidence": False,
        "classification": "SIMULATION_ACCEPTANCE_PASS",
        "program_regression_status": "NOT_EVALUATED_RUNTIME",
        "evidence_policy": f"Simulation acceptance is the {unit} program close result; this observation is not external runtime evidence.",
        "source": record["acceptance_id"],
        "evidence": False,
    }

    current["current_stage"]["operational_result"] = (
        f"{unit} implementation and SIMULATION_ONLY Work Unit Close Acceptance passed. "
        "Actions observation/recovery remains infrastructure-only; external runtime evidence is deferred until real use."
    )

    work["status"] = "VERIFIED"
    work["implementation_step"] = "FINALIZE"
    work["completion"]["verified_at"] = observed_at
    work["completion"]["acceptance_result"] = close_result
    work["next_action"] = stage["next_exact_action"]

    construction["status"] = "VERIFIED"
    construction["implementation_step"] = "FINALIZE"
    construction["acceptance_result"] = close_result
    construction["next_action"] = stage["next_exact_action"]

    write_state_atomically({
        current_path: current,
        work_packet_path: work,
        construction_packet_path: construction,
    })
    return close_result


def main() -> int:
    parser=argparse.ArgumentParser(description="P1 local acceptance capture")
    parser.add_argument("report")
    parser.add_argument("output")
    parser.add_argument("--close-simulation", action="store_true")
    parser.add_argument("--current")
    parser.add_argument("--work-packet")
    parser.add_argument("--construction-packet")
    parser.add_argument("--execution-source", choices=["LOCAL", "GITHUB_ACTIONS", "SELF_HOSTED"], default="LOCAL")
    parser.add_argument("--execution-id")
    parser.add_argument("--head-sha")
    args=parser.parse_args()

    report_path=Path(args.report)
    record=build(
        load(report_path),
        report_path,
        execution_source=args.execution_source,
        execution_id=args.execution_id,
    )
    Path(args.output).write_text(
        json.dumps(record,ensure_ascii=False,indent=2)+"\n",
        encoding="utf-8",
    )

    if args.close_simulation:
        required = {
            "current": args.current,
            "work_packet": args.work_packet,
            "construction_packet": args.construction_packet,
            "head_sha": args.head_sha,
        }
        if any(value is None for value in required.values()):
            raise SystemExit("SIMULATION_CLOSE_ARGUMENTS_MISSING")
        close_result = close_simulation(
            load(report_path),
            record,
            current_path=Path(args.current),
            work_packet_path=Path(args.work_packet),
            construction_packet_path=Path(args.construction_packet),
            execution_source=str(args.execution_source),
            execution_id=str(args.execution_id or record["execution_id"]),
            head_sha=str(args.head_sha),
        )
        print(json.dumps(close_result, ensure_ascii=False, indent=2))

    print(json.dumps(record,ensure_ascii=False,indent=2))
    return 0 if record["status"]=="PASS" else 2 if record["status"]=="INCOMPLETE" else 1


if __name__=="__main__":
    raise SystemExit(main())
