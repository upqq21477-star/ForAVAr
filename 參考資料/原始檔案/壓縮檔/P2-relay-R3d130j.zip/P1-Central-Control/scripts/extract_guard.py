"""extract_guard -- schema check + retry ledger around a model extraction (CAP-EXTRACT, R3d12zs S4a).  The model extracts; this
module only checks.  Field = {value, locator{segment_id,start,end}}; type must match the schema and every field needs a locator
inside its segment.  Mismatch -> re-extract at most MAX_RETRY (2, card-defined) times -> field UNKNOWN (never filled).
Model error -> INCOMPLETE at once (retries belong to Run.ladder).  Idempotency key = segment_id:schema_version; results are
written per segment with atomic_write and a rerun skips finished segments (INCOMPLETE ones are retried).  Ceiling: SIMULATED_PASS."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Callable

from atomic_write import atomic_write

MAX_RETRY = 2
TYPES = {"str": str, "int": int, "float": (int, float), "bool": bool, "list": list, "dict": dict}


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _type_ok(v: Any, t: str) -> bool:
    if t == "int":
        return _is_int(v)
    if t == "float":
        return isinstance(v, (int, float)) and not isinstance(v, bool)
    return isinstance(v, TYPES[t])


def check_fields(schema: dict[str, Any], record: Any, segment: dict[str, Any]) -> dict[str, str]:
    out = {}
    for name, t in schema["fields"].items():
        f = record.get(name) if isinstance(record, dict) else None
        if not isinstance(f, dict) or "value" not in f:
            out[name] = "MISSING"
        elif t not in TYPES or not _type_ok(f["value"], t):
            out[name] = "TYPE_MISMATCH"
        elif not isinstance(f.get("locator"), dict):
            out[name] = "NO_LOCATOR"
        else:
            loc = f["locator"]
            s, e = loc.get("start"), loc.get("end")
            ok = loc.get("segment_id") == segment["segment_id"] and _is_int(s) and _is_int(e) and 0 <= s < e <= len(segment["text"])
            out[name] = "OK" if ok else "BAD_LOCATOR"
    return out


def extract_segment(segment: dict[str, Any], schema: dict[str, Any], model: Callable[..., Any], max_retry: int = MAX_RETRY) -> dict[str, Any]:
    best: dict[str, Any] = {}
    verdicts: dict[str, str] = {}
    base = {"segment_id": segment["segment_id"], "schema_version": schema["version"]}
    for attempt in range(max_retry + 1):
        try:
            rec = model(segment, schema, attempt)
        except Exception:  # model call failed: INCOMPLETE, no value is made up, no extra retry here
            return {**base, "status": "INCOMPLETE", "reason": "MODEL_ERROR", "attempts": attempt + 1, "fields": {}}
        verdicts = check_fields(schema, rec, segment)
        for name, v in verdicts.items():
            if v == "OK" and name not in best:
                best[name] = {**rec[name], "trust": segment.get("trust")}
        if all(v == "OK" for v in verdicts.values()):
            break
    fields = {n: best.get(n, {"value": None, "status": "UNKNOWN"}) for n in schema["fields"]}
    return {**base, "status": "OK" if len(best) == len(fields) else "PARTIAL", "reason": "", "attempts": attempt + 1, "fields": fields}


def unknown_rate(results: dict[str, Any]) -> float:
    fs = [f for r in results.values() for f in r.get("fields", {}).values()]
    return sum(1 for f in fs if f.get("status") == "UNKNOWN") / len(fs) if fs else 0.0


def run_extraction(segments: list[dict[str, Any]], schema: dict[str, Any], model: Callable[..., Any], results_path: str | Path) -> dict[str, Any]:
    p = Path(results_path)
    try:
        res = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        if not isinstance(res, dict):
            raise ValueError("shape")
    except (OSError, ValueError):
        raise ValueError("RESULTS_CORRUPT") from None
    for s in segments:
        key = f"{s['segment_id']}:{schema['version']}"
        if key in res and res[key]["status"] != "INCOMPLETE":
            continue  # finished before the interruption
        res[key] = extract_segment(s, schema, model)
        atomic_write(p, json.dumps(res, ensure_ascii=False, sort_keys=True))
    return {"results": res, "unknown_rate": unknown_rate(res)}
