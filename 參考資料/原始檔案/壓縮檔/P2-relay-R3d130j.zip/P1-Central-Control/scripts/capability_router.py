#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any


VALID_FUNCTIONS = {f"F{i:02d}" for i in range(1, 49)}


def load(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def all_cohort_capabilities(cohort: dict[str, Any]) -> set[str]:
    return set(cohort.get("primary_capabilities", [])) | set(cohort.get("optional_capabilities", []))


def profile_capabilities(profile: dict[str, Any]) -> set[str]:
    return {
        item["capability_id"]
        for item in profile.get("capabilities", [])
        if item.get("enabled", True)
    }


def route(
    task: dict[str, Any],
    function_registry: dict[str, Any],
    cohort_registry: dict[str, Any],
    system_profiles: list[dict[str, Any]],
) -> dict[str, Any]:
    function_refs = task.get("function_refs")
    if not isinstance(function_refs, list) or not function_refs:
        return {"status": "BLOCK", "errors": ["task.function_refs 必須是非空陣列"]}

    unknown_functions = sorted(set(function_refs) - VALID_FUNCTIONS)
    if unknown_functions:
        return {"status": "BLOCK", "errors": ["未知 Function: " + ", ".join(unknown_functions)]}

    rows_by_id = {row["function_id"]: row for row in function_registry.get("functions", [])}
    missing_mapping = sorted(set(function_refs) - set(rows_by_id))
    if missing_mapping:
        return {"status": "BLOCK", "errors": ["Function 缺少 canonical mapping: " + ", ".join(missing_mapping)]}

    capability_refs: list[str] = []
    runtime_owners: list[str] = []
    execution_policies: set[str] = set()
    for fid in function_refs:
        row = rows_by_id[fid]
        cid = row["canonical_capability"]
        if cid not in capability_refs:
            capability_refs.append(cid)
        if row.get("runtime_owner"):
            runtime_owners.append(row["runtime_owner"])
        if row.get("execution_policy"):
            execution_policies.add(row["execution_policy"])

    runtime_owner_set = sorted(set(runtime_owners))
    cohorts = cohort_registry.get("cohorts", [])

    explicit_cohort = task.get("cohort_id")
    candidate_cohorts = []
    if explicit_cohort:
        candidate_cohorts = [c for c in cohorts if c.get("cohort_id") == explicit_cohort]
        if not candidate_cohorts:
            return {"status": "BLOCK", "errors": [f"未知 cohort_id: {explicit_cohort}"]}
    else:
        for cohort in cohorts:
            covered = all_cohort_capabilities(cohort)
            if set(capability_refs).issubset(covered):
                candidate_cohorts.append(cohort)

    cohort_id = None
    context_budget = None
    cohort_missing: dict[str, list[str]] = {}
    if candidate_cohorts:
        candidate_cohorts = sorted(
            candidate_cohorts,
            key=lambda c: (int(c.get("target_context_budget", 10**18)), c.get("cohort_id", "")),
        )
        selected = candidate_cohorts[0]
        missing_capabilities = sorted(set(capability_refs) - all_cohort_capabilities(selected))
        if missing_capabilities:
            return {
                "status": "BLOCK",
                "errors": [
                    f"{selected['cohort_id']} 不提供必要 Capability: " + ", ".join(missing_capabilities)
                ],
                "function_refs": function_refs,
                "capability_refs": capability_refs,
            }
        cohort_id = selected["cohort_id"]
        context_budget = {
            "target_context_budget": selected.get("target_context_budget"),
            "hard_context_ceiling": selected.get("hard_context_ceiling"),
        }
    else:
        for cohort in cohorts:
            missing = sorted(set(capability_refs) - all_cohort_capabilities(cohort))
            cohort_missing[cohort.get("cohort_id", "UNKNOWN")] = missing

    system_id = None
    mode = "CAPABILITY_ONLY"
    profile_match = None

    if len(runtime_owner_set) > 1:
        return {
            "status": "SPLIT_REQUIRED",
            "reason": "本次 Function refs 同時要求多個已存在 System runtime owner，必須切成多個 Work Segment。",
            "function_refs": function_refs,
            "capability_refs": capability_refs,
            "runtime_owners": runtime_owner_set,
            "cohort_id": cohort_id,
            "context_budget": context_budget,
            "cohort_missing": cohort_missing,
        }

    explicit_system = task.get("system_id")
    if explicit_system:
        profile_match = next((p for p in system_profiles if p.get("system_id") == explicit_system), None)
        if not profile_match:
            return {"status": "BLOCK", "errors": [f"未知 system_id: {explicit_system}"]}
        missing_caps = sorted(set(capability_refs) - profile_capabilities(profile_match))
        if missing_caps:
            return {
                "status": "BLOCK",
                "errors": [f"{explicit_system} 不提供必要 Capability: " + ", ".join(missing_caps)],
                "function_refs": function_refs,
                "capability_refs": capability_refs,
            }
        if runtime_owner_set and explicit_system not in runtime_owner_set:
            return {
                "status": "BLOCK",
                "errors": [f"指定 system_id={explicit_system} 與 Function runtime_owner 不一致: {runtime_owner_set}"],
            }
        system_id = explicit_system
        mode = "SYSTEM_RUNTIME"
    elif runtime_owner_set:
        system_id = runtime_owner_set[0]
        profile_match = next((p for p in system_profiles if p.get("system_id") == system_id), None)
        if not profile_match:
            return {"status": "BLOCK", "errors": [f"runtime_owner {system_id} 缺少 system profile"]}
        missing_caps = sorted(set(capability_refs) - profile_capabilities(profile_match))
        if missing_caps:
            return {
                "status": "BLOCK",
                "errors": [f"{system_id} 尚未覆蓋必要 Capability: " + ", ".join(missing_caps)],
                "function_refs": function_refs,
                "capability_refs": capability_refs,
            }
        mode = "SYSTEM_RUNTIME"

    if cohort_id is None:
        return {
            "status": "SPLIT_REQUIRED",
            "reason": "沒有單一 Context Cohort 能容納本次完整 Capability 集合；需先拆 Work Segment。",
            "function_refs": function_refs,
            "capability_refs": capability_refs,
            "system_id": system_id,
            "mode": mode,
            "cohort_missing": cohort_missing,
        }

    return {
        "status": "PASS",
        "route_id": f"ROUTE-{task.get('task_id', 'UNKNOWN')}",
        "task_id": task.get("task_id"),
        "mode": mode,
        "system_id": system_id,
        "cohort_id": cohort_id,
        "function_refs": function_refs,
        "capability_refs": capability_refs,
        "execution_policies": sorted(execution_policies),
        "runtime_owners": runtime_owner_set,
        "context_budget": context_budget,
    }


def main() -> int:
    ap = argparse.ArgumentParser(description="P1 Function -> Capability -> Cohort -> System deterministic router")
    ap.add_argument("task")
    ap.add_argument("function_registry")
    ap.add_argument("cohort_registry")
    ap.add_argument("output")
    ap.add_argument("--system-profile", action="append", dest="system_profiles", default=[])
    args = ap.parse_args()

    task = load(args.task)
    function_registry = load(args.function_registry)
    cohort_registry = load(args.cohort_registry)
    profiles = [load(path) for path in args.system_profiles]

    result = route(task, function_registry, cohort_registry, profiles)
    Path(args.output).write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
