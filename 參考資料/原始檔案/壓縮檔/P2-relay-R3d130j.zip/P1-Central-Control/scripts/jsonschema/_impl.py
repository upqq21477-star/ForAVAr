"""Minimal local stand-in for jsonschema Draft 2020-12 (sandbox has no network). NOT the real package.
Supports only the keywords used by the P1 repo schemas. Re-run with real jsonschema==4.26.0 for truth."""
import re, datetime
from collections import deque
from urllib.parse import urljoin, urldefrag

__version__ = "0.0-shim"

class ValidationError(Exception):
    def __init__(self, message, path=(), validator=None):
        super().__init__(message)
        self.message = message
        self.path = deque(path)
        self.absolute_path = self.path
        self.validator = validator
        self.json_path = "$" + "".join(f"[{p!r}]" if isinstance(p, str) else f"[{p}]" for p in self.path)

class SchemaError(Exception): pass

class FormatChecker:
    def check(self, inst, fmt):
        if fmt == "date" and isinstance(inst, str):
            try: datetime.date.fromisoformat(inst)
            except ValueError: return False
        return True  # date-time / uri unchecked (as real jsonschema without optional extras)

def _isint(x): return isinstance(x, int) and not isinstance(x, bool) or (isinstance(x, float) and x.is_integer())
def _type_ok(t, x):
    if t == "object": return isinstance(x, dict)
    if t == "array": return isinstance(x, list)
    if t == "string": return isinstance(x, str)
    if t == "boolean": return isinstance(x, bool)
    if t == "null": return x is None
    if t == "integer": return _isint(x)
    if t == "number": return isinstance(x, (int, float)) and not isinstance(x, bool)
    return False
def _eq(a, b):
    if isinstance(a, bool) or isinstance(b, bool): return isinstance(a, bool) and isinstance(b, bool) and a == b
    if isinstance(a, dict) and isinstance(b, dict):
        return a.keys() == b.keys() and all(_eq(a[k], b[k]) for k in a)
    if isinstance(a, list) and isinstance(b, list):
        return len(a) == len(b) and all(_eq(x, y) for x, y in zip(a, b))
    return a == b

class Draft202012Validator:
    def __init__(self, schema, registry=None, format_checker=None, **kw):
        self.schema = schema; self.registry = registry; self.fc = format_checker
    @classmethod
    def check_schema(cls, schema):
        if not isinstance(schema, (dict, bool)): raise SchemaError("schema must be object or boolean")
    def is_valid(self, inst): return not list(self.iter_errors(inst))
    def validate(self, inst):
        errs = list(self.iter_errors(inst))
        if errs: raise errs[0]
    def iter_errors(self, inst):
        base = self.schema.get("$id", "") if isinstance(self.schema, dict) else ""
        errs, _, _ = self._v(self.schema, inst, (), self.schema, base)
        return iter(errs)

    # ---- ref resolution
    def _resolve(self, ref, root, base):
        full = urljoin(base, ref) if base else ref
        uri, frag = urldefrag(full)
        target = root; nbase = base
        if uri and uri != (root.get("$id") if isinstance(root, dict) else None):
            res = None
            reg = getattr(self.registry, "_r", {}) if self.registry is not None else {}
            if uri in reg: res = reg[uri].contents
            else:
                for k, v in reg.items():
                    if k.endswith(ref.split("#")[0]) and ref.split("#")[0]: res = v.contents; uri = k; break
            if res is None: raise ValidationError(f"Unresolvable reference {ref!r}")
            target = res; nbase = res.get("$id", uri)
            root = res
        if frag:
            node = target
            for part in frag.lstrip("/").split("/"):
                if part == "": continue
                part = part.replace("~1", "/").replace("~0", "~")
                node = node[int(part)] if isinstance(node, list) else node[part]
            target = node
        return target, root, nbase

    def _v(self, s, x, path, root, base):
        """returns (errors, evaluated_props, evaluated_items)"""
        if s is True: return [], set(), set()
        if s is False: return [ValidationError("False schema does not allow " + repr(x), path)], set(), set()
        errs = []; ep = set(); ei = set()
        def add(m, v=None): errs.append(ValidationError(m, path, v))
        if "$id" in s and s is not root: pass
        if "$ref" in s:
            try:
                t, r2, b2 = self._resolve(s["$ref"], root, base)
                e, p, i = self._v(t, x, path, r2, b2); errs += e; ep |= p; ei |= i
            except ValidationError as ex: errs.append(ex)
        if "type" in s:
            ts = s["type"] if isinstance(s["type"], list) else [s["type"]]
            if not any(_type_ok(t, x) for t in ts): add(f"{x!r} is not of type {', '.join(repr(t) for t in ts)}", "type")
        if "const" in s and not _eq(s["const"], x): add(f"{s['const']!r} was expected", "const")
        if "enum" in s and not any(_eq(x, v) for v in s["enum"]): add(f"{x!r} is not one of {s['enum']!r}", "enum")
        if isinstance(x, (int, float)) and not isinstance(x, bool):
            if "minimum" in s and x < s["minimum"]: add(f"{x!r} is less than the minimum of {s['minimum']!r}", "minimum")
            if "maximum" in s and x > s["maximum"]: add(f"{x!r} is greater than the maximum of {s['maximum']!r}", "maximum")
            if "exclusiveMinimum" in s and x <= s["exclusiveMinimum"]: add(f"{x!r} is less than or equal to the minimum of {s['exclusiveMinimum']!r}", "exclusiveMinimum")
            if "exclusiveMaximum" in s and x >= s["exclusiveMaximum"]: add(f"{x!r} is greater than or equal to the maximum of {s['exclusiveMaximum']!r}", "exclusiveMaximum")
            if "multipleOf" in s and s["multipleOf"] and (x / s["multipleOf"]) % 1: add(f"{x!r} is not a multiple of {s['multipleOf']!r}", "multipleOf")
        if isinstance(x, str):
            if "minLength" in s and len(x) < s["minLength"]: add(f"{x!r} is too short", "minLength")
            if "maxLength" in s and len(x) > s["maxLength"]: add(f"{x!r} is too long", "maxLength")
            if "pattern" in s and not re.search(s["pattern"], x): add(f"{x!r} does not match {s['pattern']!r}", "pattern")
            if "format" in s and self.fc is not None and not self.fc.check(x, s["format"]): add(f"{x!r} is not a {s['format']!r}", "format")
        if isinstance(x, list):
            if "minItems" in s and len(x) < s["minItems"]: add(f"{x!r} is too short", "minItems")
            if "maxItems" in s and len(x) > s["maxItems"]: add(f"{x!r} is too long", "maxItems")
            if s.get("uniqueItems"):
                for i in range(len(x)):
                    if any(_eq(x[i], x[j]) for j in range(i)): add(f"{x!r} has non-unique elements", "uniqueItems"); break
            pre = s.get("prefixItems", [])
            for i, sub in enumerate(pre):
                if i < len(x):
                    e, _, _ = self._v(sub, x[i], path + (i,), root, base); errs += e; ei.add(i)
            if "items" in s:
                for i in range(len(pre), len(x)):
                    e, _, _ = self._v(s["items"], x[i], path + (i,), root, base); errs += e; ei.add(i)
            if "contains" in s:
                if not any(not self._v(s["contains"], v, path, root, base)[0] for v in x): add(f"{x!r} does not contain items matching the given schema", "contains")
        if isinstance(x, dict):
            if "minProperties" in s and len(x) < s["minProperties"]: add(f"{x!r} does not have enough properties", "minProperties")
            if "maxProperties" in s and len(x) > s["maxProperties"]: add(f"{x!r} has too many properties", "maxProperties")
            for k in s.get("required", []):
                if k not in x: add(f"{k!r} is a required property", "required")
            for k, dep in s.get("dependentRequired", {}).items():
                if k in x:
                    for d in dep:
                        if d not in x: add(f"{d!r} is a dependency of {k!r}", "dependentRequired")
            props = s.get("properties", {}); pp = s.get("patternProperties", {})
            for k, v in x.items():
                hit = False
                if k in props:
                    e, _, _ = self._v(props[k], v, path + (k,), root, base); errs += e; hit = True
                for pat, sub in pp.items():
                    if re.search(pat, k):
                        e, _, _ = self._v(sub, v, path + (k,), root, base); errs += e; hit = True
                if hit: ep.add(k)
            if "propertyNames" in s:
                for k in x:
                    e, _, _ = self._v(s["propertyNames"], k, path, root, base); errs += e
            if "additionalProperties" in s:
                extra = [k for k in x if k not in props and not any(re.search(p, k) for p in pp)]
                ap = s["additionalProperties"]
                if ap is False:
                    if extra: add(f"Additional properties are not allowed ({', '.join(repr(k) for k in extra)} {'was' if len(extra)==1 else 'were'} unexpected)", "additionalProperties")
                else:
                    for k in extra:
                        e, _, _ = self._v(ap, x[k], path + (k,), root, base); errs += e
                ep |= set(extra)
        # applicators
        for sub in s.get("allOf", []):
            e, p, i = self._v(sub, x, path, root, base); errs += e; ep |= p; ei |= i
        if "anyOf" in s:
            ok = False; pe = set(); pi = set()
            for sub in s["anyOf"]:
                e, p, i = self._v(sub, x, path, root, base)
                if not e: ok = True; pe |= p; pi |= i
            if not ok: add(f"{x!r} is not valid under any of the given schemas", "anyOf")
            else: ep |= pe; ei |= pi
        if "oneOf" in s:
            res = [self._v(sub, x, path, root, base) for sub in s["oneOf"]]
            good = [r for r in res if not r[0]]
            if len(good) == 0: add(f"{x!r} is not valid under any of the given schemas", "oneOf")
            elif len(good) > 1: add(f"{x!r} is valid under each of the given schemas", "oneOf")
            else: ep |= good[0][1]; ei |= good[0][2]
        if "not" in s and not self._v(s["not"], x, path, root, base)[0]:
            add(f"{x!r} should not be valid under {s['not']!r}", "not")
        if "if" in s:
            e, p, i = self._v(s["if"], x, path, root, base)
            if not e:
                ep |= p; ei |= i
                if "then" in s:
                    e2, p2, i2 = self._v(s["then"], x, path, root, base); errs += e2; ep |= p2; ei |= i2
            elif "else" in s:
                e2, p2, i2 = self._v(s["else"], x, path, root, base); errs += e2; ep |= p2; ei |= i2
        if "unevaluatedProperties" in s and isinstance(x, dict):
            extra = [k for k in x if k not in ep]
            up = s["unevaluatedProperties"]
            if up is False:
                if extra: add(f"Unevaluated properties are not allowed ({', '.join(repr(k) for k in extra)} {'was' if len(extra)==1 else 'were'} unexpected)", "unevaluatedProperties")
            else:
                for k in extra:
                    e, _, _ = self._v(up, x[k], path + (k,), root, base); errs += e
            ep |= set(extra)
        return errs, ep, ei

def validate(instance, schema, *a, **kw):
    Draft202012Validator(schema, **kw).validate(instance)
