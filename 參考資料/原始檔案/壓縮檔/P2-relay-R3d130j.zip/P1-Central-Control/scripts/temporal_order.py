"""temporal_order -- pure stdlib ordering / interval relations / periodicity for claims with time (CAP-TEMPORAL, R3d12zv S5 batch 1).
Claim {id, time: ISO string | {start, end}, tz?}.  Unparseable, id-less, zero-length or reversed interval -> that claim UNKNOWN (never guessed,
never raised).  Naive and aware are never compared: if any aware claim exists, naive ones are UNKNOWN (NAIVE_VS_AWARE); an optional tz
("Z","UTC","+08:00") makes a naive value aware.  Ties keep input order (stable).  relation(): before | after | overlaps (touching = overlaps)
| UNKNOWN; disjoint() = before or after.  periodicity(): < 3 usable claims -> UNKNOWN; PERIODIC when every gap is within rel_tol of the mean.
End: OK | PARTIAL (unknown list + ratio) | INCOMPLETE (> max_items, nothing truncated).  No state: an interrupted call is simply rerun.
Evidence ceiling: SIMULATED_PASS.  Time-zone policy, touching-as-overlap, rel_tol 0.05, max_items 1000 are HYPOTHESIS."""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

MAX_ITEMS = 1000


def _tz(v: Any) -> Any:
    if v is None:
        return None
    if v in ("Z", "UTC"):
        return timezone.utc
    try:
        sign = {"+": 1, "-": -1}[v[0]]
        return timezone(sign * timedelta(hours=int(v[1:3]), minutes=int(v[4:6])))
    except (KeyError, ValueError, IndexError, TypeError):
        return False


def _dt(v: Any, tz: Any) -> Any:
    try:
        d = datetime.fromisoformat(v)
    except (TypeError, ValueError):
        return None
    return d.replace(tzinfo=tz) if d.tzinfo is None and tz else d


def _parse(claim: Any) -> Any:
    """-> (start, end) datetimes, or a reason string."""
    if not isinstance(claim, dict) or not isinstance(claim.get("id"), str) or not claim["id"]:
        return "NO_ID"
    tz, t = _tz(claim.get("tz")), claim.get("time")
    if tz is False:
        return "UNPARSEABLE"
    if isinstance(t, dict):
        s, e = _dt(t.get("start"), tz), _dt(t.get("end"), tz)
        if s is None or e is None:
            return "UNPARSEABLE"
        if (s.tzinfo is None) != (e.tzinfo is None):
            return "MIXED_TZ_IN_INTERVAL"
        return "ZERO_LENGTH_INTERVAL" if s == e else "INVALID_INTERVAL" if e < s else (s, e)
    s = _dt(t, tz)
    return "UNPARSEABLE" if s is None else (s, s)


def _prepare(claims: list[Any]) -> tuple[list[tuple[str, datetime, datetime]], list[dict[str, Any]]]:
    ok, unknown = [], []
    for cl in claims:
        p = _parse(cl)
        if isinstance(p, str):
            unknown.append({"id": cl.get("id") if isinstance(cl, dict) else None, "reason": p})
        else:
            ok.append((cl["id"], p[0], p[1]))
    if any(s.tzinfo for _, s, _ in ok) and any(not s.tzinfo for _, s, _ in ok):
        unknown += [{"id": i, "reason": "NAIVE_VS_AWARE"} for i, s, _ in ok if not s.tzinfo]
        ok = [t for t in ok if t[1].tzinfo]
    ok.sort(key=lambda t: (t[1], t[2]))  # stable
    return ok, unknown


def order(claims: Any, max_items: int = MAX_ITEMS) -> dict[str, Any]:
    if not isinstance(claims, list) or len(claims) > max_items:
        return {"status": "INCOMPLETE", "reason": "TOO_MANY" if isinstance(claims, list) else "NOT_A_LIST", "order": [], "unknown": [],
                "unknown_ratio": None}
    ok, unknown = _prepare(claims)
    ratio = len(unknown) / len(claims) if claims else 0.0
    return {"status": "PARTIAL" if unknown else "OK", "reason": "", "order": [i for i, _, _ in ok], "unknown": unknown, "unknown_ratio": ratio}


def relation(a: Any, b: Any) -> str:
    pa, pb = _parse(a), _parse(b)
    if isinstance(pa, str) or isinstance(pb, str) or (pa[0].tzinfo is None) != (pb[0].tzinfo is None):
        return "UNKNOWN"
    return "before" if pa[1] < pb[0] else "after" if pb[1] < pa[0] else "overlaps"


def disjoint(a: Any, b: Any) -> Any:
    r = relation(a, b)
    return None if r == "UNKNOWN" else r in ("before", "after")


def periodicity(claims: list[Any], rel_tol: float = 0.05) -> dict[str, Any]:
    ok, _ = _prepare(claims)
    if len(ok) < 3:
        return {"status": "UNKNOWN", "reason": "FEWER_THAN_3", "period_seconds": None}
    gaps = [(ok[i + 1][1] - ok[i][1]).total_seconds() for i in range(len(ok) - 1)]
    mean = sum(gaps) / len(gaps)
    if mean <= 0:
        return {"status": "UNKNOWN", "reason": "ZERO_MEAN_GAP", "period_seconds": None}
    per = all(abs(g - mean) <= rel_tol * mean for g in gaps)
    return {"status": "PERIODIC" if per else "NOT_PERIODIC", "reason": "", "period_seconds": mean if per else None}
