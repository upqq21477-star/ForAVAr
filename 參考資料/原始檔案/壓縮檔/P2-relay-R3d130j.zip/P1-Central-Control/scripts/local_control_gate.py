#!/usr/bin/env python3
from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import control_gate_runtime as runtime  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 Local / CI-equivalent Control Gate")
    parser.add_argument("--base")
    parser.add_argument("--head")
    parser.add_argument("--output", required=True)
    parser.add_argument("--external-result")
    parser.add_argument("--skip-unit-tests", action="store_true")
    parser.add_argument("--actions-run")
    parser.add_argument("--actions-jobs")
    args = parser.parse_args()

    if bool(args.actions_run) != bool(args.actions_jobs):
        raise SystemExit("--actions-run 與 --actions-jobs 必須同時提供")

    head_sha = args.head or runtime.git_sha("HEAD")
    base_sha = args.base or runtime.default_base_sha(head_sha)
    code = runtime.execute(
        base_sha=base_sha,
        head_sha=head_sha,
        output=args.output,
        external_result=args.external_result,
        skip_unit_tests=args.skip_unit_tests,
    )

    if args.actions_run:
        import json
        from actions_execution_diagnostic import build as build_diagnostic

        output = Path(args.output)
        report = json.loads(output.read_text(encoding="utf-8"))
        run = json.loads(Path(args.actions_run).read_text(encoding="utf-8"))
        jobs = json.loads(Path(args.actions_jobs).read_text(encoding="utf-8"))
        diagnostic = build_diagnostic(run, jobs)
        classification = diagnostic["classification"]
        stage_status = (
            "FAIL" if classification == "WORKFLOW_EXECUTION_FAILURE"
            else "INCOMPLETE" if classification in {"RUNNER_STARTUP_FAILURE", "NOT_DISPATCHED", "INCOMPLETE", "UNKNOWN"}
            else "PASS"
        )
        report["stages"].append({
            "stage_id": "ACTIONS_EXECUTION_DIAGNOSTIC",
            "status": stage_status,
            "object_ref": diagnostic["diagnostic_id"],
            "reason_code": classification,
        })
        report["status"] = (
            "FAIL" if any(stage["status"] == "FAIL" for stage in report["stages"])
            else "INCOMPLETE" if any(stage["status"] == "INCOMPLETE" for stage in report["stages"])
            else "PASS"
        )
        output.write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        print(json.dumps(diagnostic, ensure_ascii=False, indent=2))

        final_status = report["status"]
        return 0 if final_status == "PASS" else 2 if final_status == "INCOMPLETE" else 1

    return code


if __name__ == "__main__":
    raise SystemExit(main())
