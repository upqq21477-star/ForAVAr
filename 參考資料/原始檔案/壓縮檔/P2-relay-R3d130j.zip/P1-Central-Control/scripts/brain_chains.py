#!/usr/bin/env python3
"""brain_chains — run the last two 020c chains for real (R3d12x, stdlib + repo scripts only).

Orchestrator for CH-PLAN-TASK-COMMAND and CH-KNOWLEDGE-BRAIN; owns no state or rules, every step is an existing function.
  plan chain       planner_library.assemble_team -> central_controller.apply_control_output (-> task_set.plan_issue)
                   -> revision 2 supersedes revision 1 -> command_layer.build_command / task_admission_errors / execute_command
  knowledge chain  knowledge_intake/versioning store -> knowledge_retrieval.Retriever -> brain_input.semantic_refs_from
                   -> brain_input.build_brain_input_packet (schema-validated)
`links_exercised` is MEASURED by result_chain.trace_modules (sys.setprofile), never typed by hand.
Usage: python3 scripts/brain_chains.py --run [--out BASE_DIR] | --simulate      exit 0 only when every scenario matches
"""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path
from typing import Any

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import brain_input  # noqa: E402
import central_controller  # noqa: E402
import command_layer  # noqa: E402
import knowledge_intake as ki  # noqa: E402
import knowledge_retrieval  # noqa: E402
import knowledge_versioning as kv  # noqa: E402
import planner_library  # noqa: E402
from event_log import EventLog  # noqa: E402
from state_transition import ACCEPTED  # noqa: E402
from result_chain import _expect_raises, _segment, trace_modules  # noqa: E402

CHAIN_PLAN = "CH-PLAN-TASK-COMMAND"
CHAIN_KNOW = "CH-KNOWLEDGE-BRAIN"
EVIDENCE_FILES = {  # run records read by tools/wiring_chain_audit.py (WIRED_EXECUTED needs them)
    CHAIN_PLAN: "evidence/wiring-chains/CH-PLAN-TASK-COMMAND.json",
    CHAIN_KNOW: "evidence/wiring-chains/CH-KNOWLEDGE-BRAIN.json",
}
LINKS = {CHAIN_PLAN: ["planner_library", "task_set", "command_layer"], CHAIN_KNOW: ["knowledge_retrieval", "brain_input"]}
TS = "2026-10-15T00:00:00Z"


def _team(pattern: str, rev: int, prefix: str, supersedes: str | None) -> dict[str, Any]:
    return planner_library.assemble_team(
        pattern, task_set_ref=f"TASKSET:team{rev}", revision=rev, correlation_id=f"corr-{rev}", diagnosis_ref="DIAGNOSIS:chain",
        input_ref="INPUT:chain", prefix=prefix, supersedes=supersedes)


def _segments(team: dict[str, Any], workflow_id: str) -> dict[str, dict[str, Any]]:
    store = {}
    for ref in team["control_output"]["task_refs"]:
        seg = _segment("PLAN")
        seg.update(segment_id=ref["task_id"], workflow_id=workflow_id, execution_record_ref=f"EXECUTION:exec-{ref['task_id']}",
                   dependency_refs=team["dependencies"][ref["task_id"]])
        store[ref["task_id"]] = seg
    return store


def run_plan_chain(root: Path) -> dict[str, Any]:
    pattern = sorted(planner_library.load_library()["patterns"])[0]
    state = central_controller.init_state("WF-PLAN", "TASK-PLAN")
    log = EventLog(root / "events.jsonl")
    t1 = _team(pattern, 1, "SEG-P1", None)
    state = central_controller.apply_control_output(state, t1["control_output"], segment_store=_segments(t1, "WF-PLAN"), event_log=log)[0]
    t2 = _team(pattern, 2, "SEG-P2", "TASKSET:team1")
    state = central_controller.apply_control_output(state, t2["control_output"], segment_store=_segments(t2, "WF-PLAN"), event_log=log,
                                                    execution_store={})[0]
    stale = [r["task_id"] for r in t1["control_output"]["task_refs"]]
    live = [r["task_id"] for r in t2["control_output"]["task_refs"]]
    cmd = command_layer.build_command(state, "START")
    on_stale = command_layer.task_admission_errors(state, dict(cmd, target_id=stale[0]))
    on_live = command_layer.task_admission_errors(state, dict(cmd, target_id=live[0]))
    state, result = command_layer.execute_command(state, cmd, event_log=log, has_queued_work=True)
    return {"pattern": pattern, "stale_refused": on_stale, "live_admitted": on_live, "command_status": result["status"],
            "queued": len(state.get("queued_segments", []))}


def _store(root: Path, promote: bool) -> tuple[knowledge_retrieval.Retriever, str]:
    raw = "系統 A 使用 SQLite 儲存。".encode("utf-8")
    _, segs = ki.build_source("d", raw, location="mem://d", version="v1", max_chars=40)
    refs = [x["object_id"] for x in segs]
    led = ki.ReadingLedger(root / "ledger.jsonl", segs)
    led.append(refs[0], "READ", reader="R1", timestamp=TS)
    store = kv.TemporalKnowledgeStore(led, {"SOURCE:d": ki.normalize(raw)})
    obs = store.add_observation("OBSERVED", "obs", refs[0], producer="R1", captured_at=TS, quote="SQLite")["object_id"]
    ev = store.add_evidence(obs, "CLAIM:c1", "SUPPORTS", producer="R1", scope="TASK:t", captured_at=TS)["object_id"]
    ref = store.propose_claim("c1", "FACT", "系統 A 使用 SQLite 儲存", [obs], [ev], valid_from="2026-01-01T00:00:00Z")["object_id"]
    if promote:
        store.promote(ref, by="CONTROL_RESEARCH", rationale="引文直接支持")
    return knowledge_retrieval.Retriever(store), ref


def run_knowledge_chain(root: Path, promote: bool = True) -> dict[str, Any]:
    retriever, ref = _store(root, promote)
    state = central_controller.init_state("WF-KNOW", "TASK-KNOW")
    refs = brain_input.semantic_refs_from(retriever, "SQLite")
    packet = brain_input.build_brain_input_packet(state, semantic_refs=refs)
    return {"claim_ref": ref, "semantic_refs": packet["semantic_refs"], "content_leaked": "SQLite" in json.dumps(packet, ensure_ascii=False),
            "packet": packet}


def scenarios() -> tuple[dict[str, dict[str, Any]], list[dict[str, Any]]]:
    rows: list[dict[str, Any]] = []
    chains: dict[str, dict[str, Any]] = {}
    with tempfile.TemporaryDirectory() as tmp:
        res, mods = trace_modules(lambda: run_plan_chain(Path(tmp)))
    ok = (res["stale_refused"] == ["TARGET_TASK_STALE"] and res["live_admitted"] == [] and res["command_status"] == ACCEPTED
          and res["queued"] > 0)
    rows.append({"scenario": f"{CHAIN_PLAN}:positive", "ok": ok, "detail": res})
    chains[CHAIN_PLAN] = {"chain_id": CHAIN_PLAN, "exit_code": 0, "links_exercised": sorted(m for m in LINKS[CHAIN_PLAN] if m in mods),
                          "method": "sys.setprofile module trace of the real run", "positive_ok": ok}
    with tempfile.TemporaryDirectory() as tmp:
        res, mods = trace_modules(lambda: run_knowledge_chain(Path(tmp)))
    ok = res["semantic_refs"] == [res["claim_ref"]] and not res["content_leaked"]
    rows.append({"scenario": f"{CHAIN_KNOW}:positive", "ok": ok, "detail": {k: v for k, v in res.items() if k != "packet"}})
    chains[CHAIN_KNOW] = {"chain_id": CHAIN_KNOW, "exit_code": 0, "links_exercised": sorted(m for m in LINKS[CHAIN_KNOW] if m in mods),
                          "method": "sys.setprofile module trace of the real run", "positive_ok": ok}
    rows.append({"scenario": "plan:unknown_pattern_refused", "ok": _expect_raises(lambda: _team("NOPE", 1, "S", None))})
    with tempfile.TemporaryDirectory() as tmp:
        def second_without_supersedes() -> None:
            pat = sorted(planner_library.load_library()["patterns"])[0]
            st = central_controller.init_state("WF-PLAN", "TASK-PLAN")
            log = EventLog(Path(tmp) / "e.jsonl")
            a, b = _team(pat, 1, "SEG-A", None), _team(pat, 2, "SEG-B", None)
            st = central_controller.apply_control_output(st, a["control_output"], segment_store=_segments(a, "WF-PLAN"), event_log=log)[0]
            central_controller.apply_control_output(st, b["control_output"], segment_store=_segments(b, "WF-PLAN"), event_log=log)
        rows.append({"scenario": "plan:second_set_without_supersedes_refused", "ok": _expect_raises(second_without_supersedes)})
    with tempfile.TemporaryDirectory() as tmp:
        res = run_knowledge_chain(Path(tmp), promote=False)
        rows.append({"scenario": "knowledge:unpromoted_claim_not_given_to_brain", "ok": res["semantic_refs"] == []})
    with tempfile.TemporaryDirectory() as tmp:
        bad = dict(run_knowledge_chain(Path(tmp))["packet"], unexpected_field="x")
        rows.append({"scenario": "knowledge:packet_with_extra_field_refused", "ok": _expect_raises(lambda: brain_input.validate_packet(bad))})
    if [r for r in rows if not r["ok"]]:
        for c in chains.values():
            c["exit_code"] = 1
    return chains, rows


def main(argv: list[str]) -> int:
    chains, rows = scenarios()
    for r in rows:
        print("PASS" if r["ok"] else "FAIL", r["scenario"], "" if r["ok"] else json.dumps(r.get("detail"), ensure_ascii=False, default=str)[:300])
    if "--run" in argv:
        base = Path(argv[argv.index("--out") + 1]) if "--out" in argv else SCRIPTS.parent
        for cid, rec in chains.items():
            target = base / EVIDENCE_FILES[cid]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(rec, ensure_ascii=False, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            print("wrote", target, "links_exercised", rec["links_exercised"])
    return 0 if all(r["ok"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
