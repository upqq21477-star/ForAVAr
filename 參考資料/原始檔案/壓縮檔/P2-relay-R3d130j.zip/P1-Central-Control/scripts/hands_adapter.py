#!/usr/bin/env python3
"""P2 hands_adapter (R8-M1) - contract for asking an external executor to do one thing and return result + evidence.

Contract: schemas/hands_adapter.schema.json (request / result). Only a stub executor exists (SIMULATED_PASS, stdlib, no network);
real Agent-S / Computer Use integration is follow-up work (HYPOTHESIS: contract fits it, untested). Real executor kinds are REFUSED.

  FP8  fp_hands_success   valid request -> SUCCEEDED + hashed evidence; malformed request / evidence-less success are rejected
  FP9  fp_hands_failure   FAILED / TIMEOUT / INCOMPLETE must carry error_code; INCOMPLETE (no step evidence) is not a failure (25D README rule)
  FP10 fp_hands_refusal   un-integrated executor kinds and denied actions are REFUSED, NOT_EXECUTED, no evidence
  python3 scripts/hands_adapter.py success|failure|refusal|replay
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
SCHEMA_PATH = HERE.parent / "schemas" / "hands_adapter.schema.json"
EVID = HERE.parent / "evidence" / "r8"
DENIED_ACTIONS = {"run_shell"}
OUTCOMES = {"fail": ("FAILED", "SIMULATED_FAILURE"), "timeout": ("TIMEOUT", "SIMULATED_TIMEOUT"), "incomplete": ("INCOMPLETE", "NO_STEP_EVIDENCE")}


def load_schema() -> dict[str, Any]:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _check(v: Any, s: dict[str, Any], root: dict[str, Any], path: str = "$") -> list[str]:
    """Minimal stdlib validator for the keywords this schema uses (real jsonschema validation is deferred to R9)."""
    if "$ref" in s:
        node = root
        for part in s["$ref"][2:].split("/"):
            node = node[part]
        return _check(v, node, root, path)
    errs: list[str] = []
    t = {"object": dict, "array": list, "string": str, "integer": int}.get(s.get("type", ""))
    if t and (not isinstance(v, t) or isinstance(v, bool)):
        return [f"{path}:TYPE"]
    if "enum" in s and v not in s["enum"]:
        errs.append(f"{path}:ENUM")
    if "const" in s and v != s["const"]:
        errs.append(f"{path}:CONST")
    if isinstance(v, str):
        if len(v) < s.get("minLength", 0):
            errs.append(f"{path}:MINLEN")
        if "pattern" in s and not re.search(s["pattern"], v):
            errs.append(f"{path}:PATTERN")
    if isinstance(v, list):
        if len(v) < s.get("minItems", 0):
            errs.append(f"{path}:MINITEMS")
        for i, x in enumerate(v):
            errs += _check(x, s["items"], root, f"{path}[{i}]") if "items" in s else []
    if isinstance(v, dict):
        errs += [f"{path}.{k}:REQUIRED" for k in s.get("required", []) if k not in v]
        props = s.get("properties", {})
        if s.get("additionalProperties") is False:
            errs += [f"{path}.{k}:EXTRA" for k in v if k not in props]
        for k, sub in props.items():
            if k in v:
                errs += _check(v[k], sub, root, f"{path}.{k}")
        if "if" in s:
            branch = s.get("then") if not _check(v, s["if"], root, path) else s.get("else")
            errs += _check(v, branch, root, path) if branch else []
    return errs


def validate(obj: Any, kind: str) -> list[str]:
    schema = load_schema()
    return _check(obj, schema["$defs"][kind], schema)


def _sha(o: Any) -> str:
    return hashlib.sha256(json.dumps(o, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def check_exchange(req: dict[str, Any], res: dict[str, Any]) -> list[str]:
    """Request and result must each satisfy the schema, and the result must answer this request (cf. 25D identity-field checks)."""
    errs = [f"REQUEST{e}" for e in validate(req, "request")] + [f"RESULT{e}" for e in validate(res, "result")]
    if res.get("request_id") != req.get("request_id"):
        errs.append("REQUEST_ID_MISMATCH")
    return errs


def is_failure(res: dict[str, Any]) -> bool:
    """Only FAILED is a failure; INCOMPLETE / TIMEOUT / REFUSED give no verdict on the task (same rule as the 25D regression bridge)."""
    return res.get("status") == "FAILED"


class StubHands:
    """Deterministic stand-in executor. params.simulate = 'fail' | 'timeout' drives the non-success paths."""

    def execute(self, req: dict[str, Any]) -> dict[str, Any]:
        rid = req.get("request_id", "")
        base = {"request_id": rid, "evidence": []}
        if req.get("executor_kind") != "SIMULATED_STUB":
            return {**base, "status": "REFUSED", "evidence_level": "NOT_EXECUTED", "error_code": "EXECUTOR_NOT_INTEGRATED"}
        if req.get("action") in DENIED_ACTIONS:
            return {**base, "status": "REFUSED", "evidence_level": "NOT_EXECUTED", "error_code": "ACTION_DENIED"}
        sim = (req.get("params") or {}).get("simulate")
        if sim in OUTCOMES:
            st, code = OUTCOMES[sim]
            return {**base, "status": st, "evidence_level": "SIMULATED_PASS", "error_code": code}
        ev = {"kind": "screenshot" if req["action"] == "screenshot" else "action_log", "ref": f"sim://{rid}/{req['action']}", "sha256": _sha(req)}
        return {**base, "status": "SUCCEEDED", "evidence_level": "SIMULATED_PASS", "evidence": [ev]}


def _req(rid: str, **kw: Any) -> dict[str, Any]:
    return {"request_id": rid, "executor_kind": "SIMULATED_STUB", "action": "click", "target": "button#ok", **kw}


def _out(name: str, asserts: list[list[Any]], state: dict[str, Any]) -> dict[str, Any]:
    ok = all(a[1] for a in asserts)
    return {"name": name, "ok": ok, "assertions": asserts, "state": state, "digest": _sha([asserts, state])}


def fp_hands_success() -> dict[str, Any]:
    stub, req = StubHands(), _req("r-ok-1")
    res = stub.execute(req)
    bad_req = {k: v for k, v in req.items() if k != "request_id"}
    no_ev = {**res, "evidence": []}
    a = [["request_valid", validate(req, "request") == []], ["result_valid", validate(res, "result") == []],
         ["status_succeeded", res["status"] == "SUCCEEDED"], ["request_id_echoed", res["request_id"] == req["request_id"]],
         ["evidence_hash_matches_request", res["evidence"][0]["sha256"] == _sha(req)],
         ["evidence_level_is_simulated", res["evidence_level"] == "SIMULATED_PASS"],
         ["missing_request_id_rejected", "$.request_id:REQUIRED" in validate(bad_req, "request")],
         ["success_without_evidence_rejected", "$.evidence:MINITEMS" in validate(no_ev, "result")],
         ["exchange_valid", check_exchange(req, res) == []],
         ["mismatched_request_id_rejected", "REQUEST_ID_MISMATCH" in check_exchange(req, {**res, "request_id": "other"})],
         ["success_claiming_not_executed_rejected", "$.evidence_level:ENUM" in validate({**res, "evidence_level": "NOT_EXECUTED"}, "result")]]
    return _out("S_HANDS_SUCCESS", a, {"result": res})


def fp_hands_failure() -> dict[str, Any]:
    stub = StubHands()
    rf, rt = stub.execute(_req("r-f", params={"simulate": "fail"})), stub.execute(_req("r-t", params={"simulate": "timeout"}))
    ri = stub.execute(_req("r-i", params={"simulate": "incomplete"}))
    naked = {k: v for k, v in rf.items() if k != "error_code"}
    a = [["failed_result_valid", validate(rf, "result") == [] and rf["status"] == "FAILED"],
         ["timeout_result_valid", validate(rt, "result") == [] and rt["status"] == "TIMEOUT"],
         ["failures_carry_error_code", bool(rf["error_code"]) and bool(rt["error_code"])],
         ["failure_without_error_code_rejected", "$.error_code:REQUIRED" in validate(naked, "result")],
         ["bad_status_rejected", "$.status:ENUM" in validate({**rf, "status": "OK"}, "result")],
         ["incomplete_result_valid_no_evidence", validate(ri, "result") == [] and ri["status"] == "INCOMPLETE" and ri["evidence"] == []],
         ["only_failed_is_failure", is_failure(rf) and not any(is_failure(r) for r in (rt, ri))]]
    return _out("S_HANDS_FAILURE", a, {"failed": rf, "timeout": rt, "incomplete": ri})


def fp_hands_refusal() -> dict[str, Any]:
    stub = StubHands()
    r_real = stub.execute(_req("r-real", executor_kind="COMPUTER_USE"))
    r_deny = stub.execute(_req("r-deny", action="run_shell", target="ls"))
    a = [["real_executor_refused", r_real["status"] == "REFUSED" and r_real["error_code"] == "EXECUTOR_NOT_INTEGRATED"],
         ["denied_action_refused", r_deny["status"] == "REFUSED" and r_deny["error_code"] == "ACTION_DENIED"],
         ["refusals_not_executed_no_evidence", all(r["evidence_level"] == "NOT_EXECUTED" and r["evidence"] == [] for r in (r_real, r_deny))],
         ["refusals_valid_results", validate(r_real, "result") == [] and validate(r_deny, "result") == []],
         ["unknown_action_rejected", "$.action:ENUM" in validate(_req("r-x", action="fly"), "request")]]
    return _out("S_HANDS_REFUSAL", a, {"real": r_real, "denied": r_deny})


SCENARIOS = {"success": ("FP8", fp_hands_success), "failure": ("FP9", fp_hands_failure), "refusal": ("FP10", fp_hands_refusal)}


def replay(n: int = 3, evid: Path = EVID) -> dict[str, Any]:
    per, same = {}, 0
    for key, (fp, fn) in SCENARIOS.items():
        runs = [fn() for _ in range(n)]
        ok = all(r["ok"] for r in runs) and len({r["digest"] for r in runs}) == 1
        per[fp] = {"scenario": runs[0]["name"], "runs": n, "ok": ok, "digest": runs[0]["digest"], "assertions": len(runs[0]["assertions"])}
        same += int(ok)
    rep = {"evidence_level": "SIMULATED_PASS", "equivalence_rate": same / len(SCENARIOS), "per_fast_path": per, "ok": same == len(SCENARIOS)}
    evid.mkdir(parents=True, exist_ok=True)
    (evid / "replay.json").write_text(json.dumps(rep, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
    return rep


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("cmd", choices=[*SCENARIOS, "replay"])
    a = ap.parse_args()
    r = replay() if a.cmd == "replay" else SCENARIOS[a.cmd][1]()
    print(json.dumps({k: v for k, v in r.items() if k != "state"}, ensure_ascii=False)[:900])
    print(("SIMULATED_PASS " if r["ok"] else "FAILED ") + a.cmd)
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
