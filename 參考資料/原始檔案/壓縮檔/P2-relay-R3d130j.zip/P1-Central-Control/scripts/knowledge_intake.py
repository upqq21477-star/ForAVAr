#!/usr/bin/env python3
"""CS-1 B1 Knowledge Intake：Source Manifest → KnowledgeSegment → Reading Ledger → Coverage Gate。

stdlib only；決定性（無時鐘、無網路）。「是否讀完」只由 Ledger＋Coverage Contract 算出，不由 AI 宣稱。
Ledger 狀態：NOT_READ（隱含、不寫入）／READ／PROCESSED／FAILED／BLOCKED／REQUIRES_REVIEW。
read＝READ 或 PROCESSED。PROCESSED 須附非空 observation_refs（B2；其真實性由 knowledge_canon.integrity_gate 檢查）。
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import unicodedata
from pathlib import Path
from typing import Any

from event_log import canonical_json, content_hash
from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

SCHEMA_DIR = Path(__file__).resolve().parents[1] / "schemas"
PARSER = {"id": "UTF8_TEXT", "version": "1"}
NORMALIZER = {"id": "NFC_LF_RSTRIP", "version": "1"}
SEGMENTER_ID = "PARAGRAPH_PACK_V1"
DEFAULT_MAX_CHARS = 2000
_SLUG = re.compile(r"^[A-Za-z0-9._-]+$")
_COMMON = ("canonical_identity", "canonical_common")

# 非法轉移一律拒收；PROCESSED 為終態（來源改動＝新 hash＝新 Segment，不改舊紀錄）
TRANSITIONS = {
    "NOT_READ": {"READ", "FAILED", "BLOCKED"},
    "READ": {"PROCESSED", "FAILED", "REQUIRES_REVIEW"},
    "REQUIRES_REVIEW": {"PROCESSED", "FAILED", "BLOCKED"},
    "FAILED": {"READ"},
    "BLOCKED": {"READ"},
    "PROCESSED": set(),
}


def _sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def _validator(name: str) -> Draft202012Validator:
    registry = Registry()
    for stem in (*_COMMON, name):
        schema = json.loads((SCHEMA_DIR / f"{stem}.schema.json").read_text(encoding="utf-8"))
        registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    schema = json.loads((SCHEMA_DIR / f"{name}.schema.json").read_text(encoding="utf-8"))
    return Draft202012Validator(schema, registry=registry, format_checker=FormatChecker())


def validate(name: str, record: dict[str, Any]) -> None:
    errors = sorted(_validator(name).iter_errors(record), key=lambda e: list(e.path))
    if errors:
        raise ValueError(f"{name} 驗證失敗: " + "; ".join(e.message for e in errors))


def _seal(record: dict[str, Any], schema: str) -> dict[str, Any]:
    record["content_hash"] = content_hash(record)
    validate(schema, record)
    return record


def normalize(raw: bytes) -> str:
    """固定 parser＋normalizer（UTF8_TEXT／NFC_LF_RSTRIP v1）。"""
    text = unicodedata.normalize("NFC", raw.decode("utf-8"))
    lines = [ln.rstrip() for ln in text.replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    while lines and not lines[-1]:
        lines.pop()
    return "\n".join(lines)


def _spans(text: str, max_chars: int) -> list[tuple[int, int]]:
    """PARAGRAPH_PACK_V1：依空行分段落，貪婪合併至 max_chars；超長段落於 max_chars 硬切。"""
    paras = [(m.start(), m.end()) for m in re.finditer(r"[^\n]+(?:\n[^\n]+)*", text)]
    pieces: list[tuple[int, int]] = []
    for s, e in paras:
        while e - s > max_chars:
            pieces.append((s, s + max_chars))
            s += max_chars
        pieces.append((s, e))
    spans: list[tuple[int, int]] = []
    for s, e in pieces:
        if spans and e - spans[-1][0] <= max_chars:
            spans[-1] = (spans[-1][0], e)
        else:
            spans.append((s, e))
    return spans


def build_source(
    source_id: str,
    raw: bytes,
    *,
    location: str,
    version: str,
    max_chars: int = DEFAULT_MAX_CHARS,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """回傳 (Source Manifest, KnowledgeSegment 清單)；同輸入必得同 hash。"""
    if not _SLUG.match(source_id):
        raise ValueError(f"source_id 不合法: {source_id!r}")
    text = normalize(raw)
    spans = _spans(text, max_chars)
    segments = []
    for n, (s, e) in enumerate(spans, 1):
        segments.append(
            _seal(
                {
                    "object_id": f"KNOWLEDGE_SEGMENT:{source_id}.S{n:04d}",
                    "kind": "KNOWLEDGE_SEGMENT",
                    "schema_version": "1.0",
                    "source_ref": f"SOURCE:{source_id}",
                    "sequence": n,
                    "location": {"start": s, "end": e},
                    "segment_text_hash": _sha(text[s:e].encode("utf-8")),
                    "depends_on": [],
                },
                "knowledge_segment",
            )
        )
    manifest = _seal(
        {
            "object_id": f"SOURCE:{source_id}",
            "kind": "SOURCE",
            "schema_version": "1.0",
            "source_version": version,
            "location": location,
            "source_hash": _sha(raw),
            "size": len(raw),
            "parser": dict(PARSER),
            "normalizer": dict(NORMALIZER),
            "representation_hash": _sha(text.encode("utf-8")),
            "segmenter": {"id": SEGMENTER_ID, "max_chars": max_chars},
            "segment_count": len(segments),
            "segments_digest": _sha(b"".join(s["content_hash"].encode() for s in segments)),
        },
        "source_manifest",
    )
    return manifest, segments


def verify_segments(manifest: dict[str, Any], segments: list[dict[str, Any]]) -> None:
    """Manifest 與 Segment 清單須一致（數量、digest、逐筆 hash、來源）；不符即拒。"""
    for seg in segments:
        validate("knowledge_segment", seg)
        if seg["content_hash"] != content_hash(seg) or seg["source_ref"] != manifest["object_id"]:
            raise ValueError(f"Segment 不一致: {seg['object_id']}")
    digest = _sha(b"".join(s["content_hash"].encode() for s in segments))
    if len(segments) != manifest["segment_count"] or digest != manifest["segments_digest"]:
        raise ValueError("Segment 清單與 Source Manifest 不符")


class ReadingLedger:
    """append-only JSONL＋prev_hash 鏈；未知 segment、非法轉移、斷鏈皆拒收。"""

    def __init__(self, path: Path, segments: list[dict[str, Any]]) -> None:
        self.path = Path(path)
        self.segments = {s["object_id"]: s for s in segments}
        self.entries: list[dict[str, Any]] = []
        if self.path.exists():
            for line in self.path.read_text(encoding="utf-8").splitlines():
                self._accept(json.loads(line))

    def head(self) -> str | None:
        return self.entries[-1]["content_hash"] if self.entries else None

    def state(self, segment_ref: str) -> str:
        for entry in reversed(self.entries):
            if entry["segment_ref"] == segment_ref:
                return entry["status"]
        return "NOT_READ"

    def _accept(self, entry: dict[str, Any]) -> None:
        validate("reading_ledger_entry", entry)
        seg = self.segments.get(entry["segment_ref"])
        if seg is None:
            raise ValueError(f"未知 segment: {entry['segment_ref']}")
        if entry["source_ref"] != seg["source_ref"]:
            raise ValueError("source_ref 與 segment 不符")
        if entry["content_hash"] != content_hash(entry):
            raise ValueError("Ledger 紀錄 hash 不符")
        if entry["seq"] != len(self.entries) + 1 or entry["prev_hash"] != self.head():
            raise ValueError("Ledger 序號或 prev_hash 斷鏈")
        if entry["status"] == "PROCESSED" and not entry["observation_refs"]:
            raise ValueError("PROCESSED 須附 observation_refs（B2）")
        old = self.state(entry["segment_ref"])
        if entry["status"] not in TRANSITIONS[old]:
            raise ValueError(f"非法轉移 {old} → {entry['status']}")
        self.entries.append(entry)

    def append(
        self,
        segment_ref: str,
        status: str,
        *,
        reader: str,
        timestamp: str,
        observation_refs: list[str] | None = None,
        checkpoint_ref: str | None = None,
    ) -> dict[str, Any]:
        seg = self.segments.get(segment_ref)
        if seg is None:
            raise ValueError(f"未知 segment: {segment_ref}")
        n = len(self.entries) + 1
        entry: dict[str, Any] = {
            "object_id": f"READING_LEDGER_ENTRY:{segment_ref.split(':', 1)[1]}.L{n:05d}",
            "kind": "READING_LEDGER_ENTRY",
            "schema_version": "1.0",
            "seq": n,
            "segment_ref": segment_ref,
            "source_ref": seg["source_ref"],
            "status": status,
            "reader": reader,
            "timestamp": timestamp,
            "observation_refs": list(observation_refs or []),
            "prev_hash": self.head(),
        }
        if checkpoint_ref:
            entry["checkpoint_ref"] = checkpoint_ref
        entry["content_hash"] = content_hash(entry)
        file_existed = self.path.exists()
        original_size = self.path.stat().st_size if file_existed else 0
        self._accept(entry)
        try:
            with self.path.open("ab") as fh:
                fh.write(canonical_json(entry) + b"\n")
                fh.flush()
                os.fsync(fh.fileno())
        except OSError:
            # Restore the in-memory chain and best-effort restore the durable tail.
            if self.entries and self.entries[-1] is entry:
                self.entries.pop()
            try:
                if file_existed and self.path.exists():
                    with self.path.open("r+b") as fh:
                        fh.truncate(original_size)
                        fh.flush()
                        os.fsync(fh.fileno())
                elif not file_existed and self.path.exists():
                    self.path.unlink()
            except OSError as rollback_error:
                raise OSError("READING_LEDGER_APPEND_ROLLBACK_INCOMPLETE") from rollback_error
            raise
        return entry


def _check_contract(contract: dict[str, Any], segments: dict[str, Any]) -> None:
    if not str(contract.get("required_basis", "")).strip() or not str(contract.get("declared_by", "")).strip():
        raise ValueError("Coverage Contract 須有 required_basis 與 declared_by（必要 Segment 須有明定來源）")
    seen: set[str] = set()
    for group in ("required", "optional", "derived"):
        for ref in contract.get(group, []):
            if ref not in segments or ref in seen:
                raise ValueError(f"Contract 引用未知或重複 segment: {ref}")
            seen.add(ref)
    if not contract.get("required"):
        raise ValueError("Coverage Contract 的 required 不得為空")


def coverage(ledger: ReadingLedger, contract: dict[str, Any]) -> dict[str, Any]:
    """Coverage Gate：BLOCK（required FAILED／BLOCKED 或被依賴阻擋）> INCOMPLETE > COMPLETE。"""
    segs = ledger.segments
    _check_contract(contract, segs)
    states = {ref: ledger.state(ref) for ref in segs}
    counts = {k: 0 for k in ("read", "processed", "failed", "blocked", "review", "not_read")}
    for st in states.values():
        key = {"READ": "read", "PROCESSED": "processed", "FAILED": "failed", "BLOCKED": "blocked",
               "REQUIRES_REVIEW": "review", "NOT_READ": "not_read"}[st]
        counts[key] += 1
    counts["read"] += counts["processed"]
    classified = set(contract["required"]) | set(contract.get("optional", [])) | set(contract.get("derived", []))
    required = list(contract["required"])
    bad = {"FAILED", "BLOCKED"}
    by_dep = [
        r for r in required
        if states[r] not in bad and any(states.get(d) in bad for d in segs[r]["depends_on"])
    ]
    missing = [r for r in required if states[r] != "PROCESSED"]
    done = len(required) - len(missing)
    if any(states[r] in bad for r in required) or by_dep:
        status = "BLOCK"
    elif missing:
        status = "INCOMPLETE"
    else:
        status = "COMPLETE"
    source_ref = next(iter(segs.values()))["source_ref"]
    report = {
        "object_id": f"COVERAGE_REPORT:{source_ref.split(':', 1)[1]}.L{len(ledger.entries):05d}",
        "kind": "COVERAGE_REPORT",
        "schema_version": "1.0",
        "source_ref": source_ref,
        "contract_hash": _sha(canonical_json(contract)),
        "ledger_head": ledger.head(),
        "counts": {"total": len(segs), **counts, "unclassified": len(segs) - len(classified)},
        "required_total": len(required),
        "required_processed": done,
        "coverage_ratio": round(done / len(required), 4),
        "status": status,
        "missing_required": missing,
        "blocked_by_dependency": by_dep,
    }
    return _seal(report, "coverage_report")


def full_read_claim_holds(report: dict[str, Any], ledger: ReadingLedger, contract: dict[str, Any]) -> bool:
    """「已全讀」宣稱成立＝報告可由 Ledger＋Contract 重算相同，且 COMPLETE、Ledger 非空。"""
    try:
        return (
            report.get("status") == "COMPLETE"
            and ledger.head() is not None
            and coverage(ledger, contract) == report
        )
    except ValueError:
        return False
