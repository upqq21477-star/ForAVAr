#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker

from packet_layer import build_result_packet, content_hash, validate_result_packet


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SYSTEM_RESULT_SCHEMA = SCHEMA_DIR / "system_result.schema.json"


def load(path: str) -> dict[str, Any]:
    value = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def save(path: str, value: dict[str, Any]) -> None:
    Path(path).write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def validate_system_result(value: dict[str, Any]) -> None:
    schema = json.loads(SYSTEM_RESULT_SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator.check_schema(schema)
    validator = Draft202012Validator(schema, format_checker=FormatChecker())
    errors = list(validator.iter_errors(value))
    if errors:
        raise ValueError(
            "System Result 驗證失敗: "
            + "；".join(error.message for error in errors)
        )


def normalize_ref_token(value: str) -> str:
    token = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    if not token:
        raise ValueError("無法建立合法 canonical ref token")
    return token[:60]


def map_status(system_status: str) -> str:
    mapping = {
        "WORK_COMPLETE": "WORK_COMPLETE",
        "UNRESOLVED": "UNRESOLVED",
        "BLOCK": "BLOCK",
        "FAIL": "FAIL",
    }
    if system_status not in mapping:
        raise ValueError(f"未知 System Result status: {system_status}")
    return mapping[system_status]


def find_execution_record(
    envelopes: list[dict[str, Any]],
    execution_ref: str,
) -> dict[str, Any]:
    for envelope in envelopes:
        execution = envelope.get("execution_record")
        if isinstance(execution, dict) and execution.get("execution_record_ref") == execution_ref:
            return execution
    raise ValueError(f"找不到 ExecutionRecord: {execution_ref}")


def adapt(
    task_packet: dict[str, Any],
    system_result: dict[str, Any],
    execution: dict[str, Any],
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    validate_system_result(system_result)

    if system_result.get("segment_id") != task_packet["segment_id"]:
        raise ValueError("System Result segment_id 與 TaskPacket 不一致")
    if system_result.get("status") not in {"WORK_COMPLETE", "UNRESOLVED", "BLOCK", "FAIL"}:
        raise ValueError("System Result status 不可轉換為 ResultPacket")

    requested_outputs = list(task_packet.get("requested_outputs", []))
    output_payload = system_result.get("outputs", {})
    if not isinstance(output_payload, dict):
        raise ValueError("System Result outputs 必須是 object")

    decision_code = map_status(system_result["status"])

    if decision_code == "WORK_COMPLETE":
        missing = [name for name in requested_outputs if name not in output_payload]
        if missing:
            raise ValueError(
                "WORK_COMPLETE 缺少 requested_outputs: " + ", ".join(missing)
            )

    artifact_refs = [
        "ARTIFACT:"
        + normalize_ref_token(task_packet["segment_id"])
        + "-"
        + normalize_ref_token(task_packet["attempt_id"])
        + "-"
        + normalize_ref_token(name)
        for name in requested_outputs
    ]

    evidence_ref = (
        "EVIDENCE:"
        + normalize_ref_token(task_packet["segment_id"])
        + "-"
        + normalize_ref_token(task_packet["attempt_id"])
    )
    provenance_ref = (
        "PROVENANCE:"
        + normalize_ref_token(task_packet["segment_id"])
        + "-"
        + normalize_ref_token(task_packet["attempt_id"])
    )

    usage = system_result.get("observed_usage")
    if not isinstance(usage, dict) or not usage.get("usage_observed", False):
        raise ValueError(
            "System Runtime 必須提供 observed_usage.usage_observed=true；禁止補造 Execution Truth"
        )

    skill_result = {
        "decision_code": decision_code,
        "output_refs": artifact_refs,
        "unresolved": list(system_result.get("unresolved", [])),
        "evidence_refs": [evidence_ref] if decision_code == "WORK_COMPLETE" else [],
        "provenance_refs": [provenance_ref] if decision_code == "WORK_COMPLETE" else [],
        "observed_usage": {
            "model_calls": int(usage.get("model_calls", 0)),
            "tool_calls": int(usage.get("tool_calls", 0)),
            "wall_time_ms": int(usage.get("wall_time_ms", 0)),
        },
        "usage_observed": True,
    }
    result_packet = build_result_packet(
        task_packet,
        skill_result,
    )
    validate_result_packet(result_packet)

    evidence_records: list[dict[str, Any]] = []
    provenance_records: list[dict[str, Any]] = []

    if decision_code == "WORK_COMPLETE":
        evidence_records.append({
            "object_id": evidence_ref,
            "kind": "EVIDENCE",
            "schema_version": "1.0",
            "content_hash": "",
            "source_ref": task_packet["input_refs"][0],
            "claim_ref": result_packet["object_id"],
            "relation": "SUPPORTS",
            "captured_at": execution["start_time"],
        })
        evidence_records[-1]["content_hash"] = content_hash(evidence_records[-1])
        provenance_records.append({
            "object_id": provenance_ref,
            "kind": "PROVENANCE",
            "schema_version": "1.0",
            "content_hash": "sha256:" + "0" * 64,
            "subject_ref": result_packet["object_id"],
            "activity_ref": execution["execution_record_ref"],
            "agent_ref": (
                f"SKILL:{result_packet['skill_id']}-{result_packet['skill_version']}"
            ),
            "input_refs": list(task_packet["input_refs"]),
            "output_refs": artifact_refs,
            "relation": "WAS_GENERATED_BY",
        })
        provenance_records[-1]["content_hash"] = content_hash(provenance_records[-1])

    return result_packet, {
        "records": evidence_records,
    }, {
        "records": provenance_records,
    }


def main() -> int:
    parser = argparse.ArgumentParser(
        description="System Result → canonical ResultPacket bridge"
    )
    parser.add_argument("--task-packet", required=True)
    parser.add_argument("--system-result", required=True)
    parser.add_argument("--execution-envelope", required=True)
    parser.add_argument("--result-output", required=True)
    parser.add_argument("--evidence-output", required=True)
    parser.add_argument("--provenance-output", required=True)
    parser.add_argument("--persist-repository", action="store_true")
    args = parser.parse_args()

    task_packet = load(args.task_packet)
    system_result = load(args.system_result)
    envelope_value = json.loads(
        Path(args.execution_envelope).read_text(encoding="utf-8")
    )
    if not isinstance(envelope_value, list):
        raise ValueError("Execution envelope 必須是 array")

    execution = find_execution_record(
        envelope_value,
        task_packet["execution_record_ref"],
    )
    result_packet, evidence, provenance = adapt(
        task_packet,
        system_result,
        execution,
    )

    save(args.result_output, result_packet)
    save(args.evidence_output, evidence)
    save(args.provenance_output, provenance)

    persistence = None
    if args.persist_repository:
        from repository_result_writer import persist
        persistence = persist(result_packet)

    print(json.dumps({
        "status": "PASS",
        "result_id": result_packet["result_id"],
        "decision_code": result_packet["decision_code"],
        "output_ref_count": len(result_packet["output_refs"]),
        "evidence_count": len(evidence["records"]),
        "provenance_count": len(provenance["records"]),
        "repository_persistence": persistence,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
