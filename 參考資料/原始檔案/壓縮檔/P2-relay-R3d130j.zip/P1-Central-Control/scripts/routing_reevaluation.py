#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

import capability_reevaluation


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "routing_reevaluation.schema.json"


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def identity(kind: str, object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(value)
    result["object_id"] = f"{kind}:{object_id}"
    result["kind"] = kind
    result["schema_version"] = "1.0"
    result["content_hash"] = ""
    result["content_hash"] = content_hash(result)
    return result


def _registry() -> Registry:
    registry = Registry()
    for filename in ("canonical_identity.schema.json", "canonical_common.schema.json", "routing_reevaluation.schema.json"):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    return registry


def validate_report(report: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(
            schema,
            registry=_registry(),
            format_checker=FormatChecker(),
        ).iter_errors(report),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError(
            "routing_reevaluation.schema.json 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )
    if report.get("content_hash") != content_hash(report):
        raise ValueError("Routing Reevaluation content_hash 不正確")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def reevaluate(
    capability_report: dict[str, Any],
    *,
    routing_reevaluation_id: str | None = None,
) -> dict[str, Any]:
    # M3 的唯一能力狀態來源是 M2；不得讀取原始 measurement、capability registry
    # 或重新呼叫 Native Replacement Eval。
    capability_reevaluation.validate_report(capability_report)

    if capability_report.get("kind") != "CAPABILITY_REEVALUATION":
        raise ValueError("M3 只接受 CAPABILITY_REEVALUATION")
    source_status = capability_report["status"]

    routes: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []
    blocked = False

    for item in capability_report["evaluations"]:
        status = item["status"]
        route = {
            "capability_id": item["capability_id"],
            "evaluation_ref": item["evaluation_ref"],
            "evaluation_status": status,
            "evaluation_state": item["evaluation_state"],
            "route_mode": None,
            "decision_code": "DEFER",
            "capability_refs": [item["capability_id"]],
            "required_controls": [],
            "evidence_refs": [],
            "contract_gap_refs": [],
        }

        if status == "PASS":
            route["route_mode"] = item["candidate_mode"]
            route["decision_code"] = "CANDIDATE_READY"
        elif status == "BLOCK":
            blocked = True
            route["decision_code"] = "BLOCK"
        else:
            route["decision_code"] = "DEFER"
            pending.append({
                "capability_id": item["capability_id"],
                "reason_code": "M2_EVALUATION_INSUFFICIENT_DATA",
            })

        routes.append(route)

    for item in capability_report["pending"]:
        pending.append({
            "capability_id": item["capability_id"],
            "reason_code": "M2_PENDING",
        })

    if blocked or source_status == "BLOCK":
        status = "BLOCK"
    elif pending or source_status == "INSUFFICIENT_DATA":
        status = "INSUFFICIENT_DATA"
    else:
        status = "PASS"

    report = identity(
        "ROUTING_REEVALUATION",
        routing_reevaluation_id or capability_report["reevaluation_id"].replace("M2-", "M3-"),
        {
            "routing_reevaluation_id": routing_reevaluation_id
            or capability_report["reevaluation_id"].replace("M2-", "M3-"),
            "source_reevaluation_id": capability_report["reevaluation_id"],
            "source_reevaluation_status": source_status,
            "routes": routes,
            "pending": pending,
            "status": status,
        },
    )
    validate_report(report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 M3 Routing Reevaluation")
    parser.add_argument("capability_reevaluation")
    parser.add_argument("output")
    args = parser.parse_args()

    capability_report = load_json(Path(args.capability_reevaluation))
    report = reevaluate(capability_report)
    Path(args.output).write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] in {"PASS", "INSUFFICIENT_DATA"} else 3


if __name__ == "__main__":
    raise SystemExit(main())
