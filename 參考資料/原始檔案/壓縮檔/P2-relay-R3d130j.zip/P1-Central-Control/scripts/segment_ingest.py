"""segment_ingest -- deterministic Source -> Segment split with coverage check (CAP-INGEST, R3d12zs S4a).
Source {id, trust, text}; trust must be labelled (missing = FAILED, fail closed).  Segment {segment_id, derived_from, offset, length,
text_hash, trust}; segment_id = sha256(source_id|offset|text)[:12], so a rerun keeps ids and one file per segment.
End: OK | INCOMPLETE (missing list, nothing silently dropped) | FAILED (unreadable source or no trust label).
Parser failure or a split that does not cover the text -> fixed-size FALLBACK_SPLIT.  Resume: valid segment file = skipped.
Evidence ceiling: SIMULATED_PASS.  Segment size / id rule are HYPOTHESIS."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

from atomic_write import atomic_write

TRUST = ("UNTRUSTED", "VERIFIED", "ACCEPTED")


def sha(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def segment_id(source_id: str, offset: int, text: str) -> str:
    return hashlib.sha256(f"{source_id}|{offset}|{text}".encode("utf-8")).hexdigest()[:12]


def split_text(text: str, max_chars: int = 1000) -> list[tuple[int, str]]:
    out, i = [], 0
    while i < len(text):
        j = min(i + max_chars, len(text))
        k = text.find("\n\n", i, j)  # prefer a paragraph boundary that still fits
        j = k + 2 if k != -1 else j
        out.append((i, text[i:j]))
        i = j
    return out


def _fixed(text: str, max_chars: int) -> list[tuple[int, str]]:
    return [(i, text[i:i + max_chars]) for i in range(0, len(text), max_chars)]


def _segments(source: dict[str, Any], pieces: Any) -> list[dict[str, Any]]:
    return [{"segment_id": segment_id(source["id"], o, t), "derived_from": source["id"], "offset": o, "length": len(t),
             "text_hash": sha(t), "trust": source["trust"]} for o, t in pieces]


def check_coverage(text: str, segments: list[dict[str, Any]]) -> list[str]:
    """Deterministic verifier: offsets join up, no overlap, hashes recompute, the whole text is covered."""
    problems, cursor = [], 0
    for s in sorted(segments, key=lambda x: x["offset"]):
        if s["offset"] != cursor:
            problems.append(f"{'GAP' if s['offset'] > cursor else 'OVERLAP'}@{s['offset']}")
        if sha(text[s["offset"]:s["offset"] + s["length"]]) != s["text_hash"]:
            problems.append(f"HASH@{s['offset']}")
        cursor = s["offset"] + s["length"]
    if cursor != len(text):
        problems.append(f"TAIL@{cursor}")
    return problems


def _failed(reason: str) -> dict[str, Any]:
    return {"status": "FAILED", "reason": reason, "segments": [], "missing": [], "written": 0, "skipped": 0, "split_mode": None}


def ingest(source: Any, out_dir: str | Path, splitter: Callable[[str, int], Any] | None = None, max_chars: int = 1000) -> dict[str, Any]:
    if not isinstance(source, dict) or not isinstance(source.get("id"), str) or not source["id"]:
        return _failed("SOURCE_ID_MISSING")
    if source.get("trust") not in TRUST:
        return _failed("TRUST_MISSING")
    text = source.get("text")
    if not isinstance(text, str) or not text:
        return _failed("SOURCE_UNREADABLE")
    mode = "DETERMINISTIC"
    try:
        segs = _segments(source, (splitter or split_text)(text, max_chars))
        if check_coverage(text, segs):
            raise ValueError("COVERAGE")
    except Exception:  # parser failure or a split that loses text: fixed-size fallback, marked
        segs, mode = _segments(source, _fixed(text, max_chars)), "FALLBACK_SPLIT"
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    written, skipped, missing = 0, 0, []
    for s in segs:
        p = out / f"{s['segment_id']}.json"
        try:
            if p.exists() and json.loads(p.read_text(encoding="utf-8")) == s:
                skipped += 1
                continue
        except (OSError, ValueError):
            pass  # unreadable earlier file: rewrite it
        try:
            atomic_write(p, json.dumps(s, ensure_ascii=False, sort_keys=True))
            written += 1
        except OSError:  # this segment is INCOMPLETE; the others carry on
            missing.append(s["segment_id"])
    return {"status": "INCOMPLETE" if missing else "OK", "reason": "", "segments": segs, "missing": missing, "written": written,
            "skipped": skipped, "split_mode": mode}
