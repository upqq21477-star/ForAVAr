#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

import routing_reevaluation

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "regression_selection.schema.json"
REGISTRY_PATH = ROOT / "P1-Central-Control" / "regression_selection_registry.json"
IMPACT_SCHEMA_PATH = SCHEMA_DIR / "impact_scan.schema.json"


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def identity(kind: str, object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(value)
    result["object_id"] = f"{kind}:{object_id}"
    result["kind"] = kind
    result["schema_version"] = "1.0"
    result["content_hash"] = ""
    result["content_hash"] = content_hash(result)
    return result


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "routing_reevaluation.schema.json",
        "regression_selection.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(schema["$id"], Resource.from_contents(schema))
    return registry


def validate_report(report: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(
            schema, registry=_registry(), format_checker=FormatChecker()
        ).iter_errors(report),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError(
            "regression_selection.schema.json 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )
    if report.get("content_hash") != content_hash(report):
        raise ValueError("Regression Selection content_hash 不正確")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def validate_impact_scan(impact_scan: dict[str, Any]) -> None:
    schema = json.loads(IMPACT_SCHEMA_PATH.read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(impact_scan)
    if impact_scan.get("status") != "PASS" or impact_scan.get("decision") != "PROCEED":
        raise ValueError("M4 不接受未通過的 IMPACT_SCAN")
    if impact_scan.get("unknown_paths"):
        raise ValueError("M4 不接受含 unknown_paths 的 IMPACT_SCAN")


def load_set_registry(path: Path = REGISTRY_PATH) -> dict[str, dict[str, Any]]:
    data = load_json(path)
    result = {}
    for item in data.get("sets", []):
        if not isinstance(item, dict):
            continue
        set_id = item.get("regression_set_id")
        if isinstance(set_id, str):
            result[set_id] = item
    return result


def select(
    routing_report: dict[str, Any],
    impact_scan: dict[str, Any],
    *,
    registry: dict[str, dict[str, Any]],
    selection_id: str | None = None,
) -> dict[str, Any]:
    routing_reevaluation.validate_report(routing_report)
    validate_impact_scan(impact_scan)

    if routing_report.get("kind") != "ROUTING_REEVALUATION":
        raise ValueError("M4 只接受 ROUTING_REEVALUATION")
    if routing_report["source_reevaluation_status"] == "BLOCK" or routing_report["status"] == "BLOCK":
        raise ValueError("M4 不得從 BLOCK routing report 產生 regression selection")

    required = sorted(set(impact_scan.get("required_regression_sets", [])))
    unknown = [set_id for set_id in required if set_id not in registry]
    if unknown:
        raise ValueError("M4 發現未知 regression set: " + ", ".join(unknown))

    selected: list[str] = []
    selections: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []

    for route in routing_report["routes"]:
        if route["decision_code"] == "CANDIDATE_READY":
            selected_for_route = required[:]
            selections.append({
                "capability_id": route["capability_id"],
                "evaluation_ref": route["evaluation_ref"],
                "route_mode": route["route_mode"],
                "decision_code": "CANDIDATE_READY",
                "regression_sets": selected_for_route,
            })
            selected.extend(selected_for_route)
        elif route["decision_code"] == "DEFER":
            pending.append({
                "capability_id": route["capability_id"],
                "reason_code": "ROUTE_DEFERRED",
            })
        elif route["decision_code"] == "BLOCK":
            pending.append({
                "capability_id": route["capability_id"],
                "reason_code": "ROUTE_BLOCKED",
            })

    for item in routing_report["pending"]:
        pending.append({
            "capability_id": item["capability_id"],
            "reason_code": "ROUTE_DEFERRED",
        })

    selected_unique = sorted(set(selected))
    reason_codes: list[str] = []
    if not required:
        reason_codes.append("NO_REQUIRED_REGRESSION_SETS")
    if not selected_unique:
        reason_codes.append("NO_REGRESSION_SETS_SELECTED")
    if routing_report["status"] == "INSUFFICIENT_DATA" or pending or reason_codes:
        status = "INSUFFICIENT_DATA"
    else:
        status = "PASS"

    report = identity(
        "REGRESSION_SELECTION",
        selection_id or routing_report["routing_reevaluation_id"].replace("M3-", "M4-"),
        {
            "selection_id": selection_id
            or routing_report["routing_reevaluation_id"].replace("M3-", "M4-"),
            "source_routing_reevaluation_id": routing_report["routing_reevaluation_id"],
            "source_impact_scan_id": impact_scan["scan_id"],
            "source_routing_status": routing_report["status"],
            "required_regression_sets": required,
            "selected_regression_sets": selected_unique,
            "selections": selections,
            "pending": pending,
            "reason_codes": sorted(set(reason_codes)),
            "status": status,
        },
    )
    validate_report(report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 M4 Regression Selection")
    parser.add_argument("routing_reevaluation")
    parser.add_argument("impact_scan")
    parser.add_argument("output")
    parser.add_argument("--registry", default=str(REGISTRY_PATH))
    args = parser.parse_args()

    routing_report = load_json(Path(args.routing_reevaluation))
    impact_scan_document = load_json(Path(args.impact_scan))
    impact_scan = impact_scan_document.get("impact_scan", impact_scan_document)
    if not isinstance(impact_scan, dict):
        raise ValueError("M1 IMPACT_SCAN 輸出缺少 impact_scan object")

    report = select(
        routing_report,
        impact_scan,
        registry=load_set_registry(Path(args.registry)),
    )
    Path(args.output).write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] in {"PASS", "INSUFFICIENT_DATA"} else 3


if __name__ == "__main__":
    raise SystemExit(main())
