"""G4 (S2): atomic text write. Same-dir temp -> flush+fsync -> os.replace -> fsync dir. On any failure the old file is untouched
and the temp is removed. Directory fsync is best-effort (platform dependent, HYPOTHESIS on non-POSIX)."""
from __future__ import annotations

import os
import stat
import tempfile
from pathlib import Path


def atomic_write(path: str | Path, text: str) -> None:
    p = Path(path)
    fd, tmp = tempfile.mkstemp(dir=str(p.parent), prefix=p.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text)
            f.flush()
            os.fsync(f.fileno())
        mode = stat.S_IMODE(p.stat().st_mode) if p.exists() else 0o644
        os.chmod(tmp, mode)
        os.replace(tmp, p)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    try:
        dfd = os.open(str(p.parent), os.O_RDONLY)
        try:
            os.fsync(dfd)
        finally:
            os.close(dfd)
    except OSError:
        pass


def stale_temps(directory: str | Path) -> list[str]:
    """Leftover temp files from a writer that died before os.replace (reported by Run.resume)."""
    return sorted(p.name for p in Path(directory).iterdir() if p.is_file() and p.name.endswith(".tmp"))
