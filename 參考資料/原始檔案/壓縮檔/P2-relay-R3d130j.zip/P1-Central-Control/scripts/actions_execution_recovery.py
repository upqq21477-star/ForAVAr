#!/usr/bin/env python3
"""Turn GitHub Actions execution diagnostics into an explicit recovery decision."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_recovery.schema.json"


DECISIONS = {
    "PASS": ("COMPLETE", "EXTERNAL_PASS"),
    "WORKFLOW_EXECUTION_FAILURE": ("REPLAY_LOCAL", "EXTERNAL_RUNTIME_FAILED_AFTER_STEP_ALLOCATION"),
    "RUNNER_STARTUP_FAILURE": ("DIAGNOSE", "RUNNER_STARTUP_FAILURE_NO_STEP_EVIDENCE"),
    "NOT_DISPATCHED": ("RETRY_EXTERNAL", "RUN_NOT_DISPATCHED_REDISPATCH_REQUIRED"),
    "INCOMPLETE": ("REQUIRE_MANUAL_REVIEW", "EXECUTION_INCOMPLETE"),
    "UNKNOWN": ("BLOCK", "EXECUTION_CLASSIFICATION_UNKNOWN"),
}


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _validate(value: dict[str, Any]) -> None:
    schema = _load(SCHEMA)
    Draft202012Validator(schema).validate(value)


def build(
    diagnostic: dict[str, Any],
    *,
    attempt_index: int = 0,
    max_external_retries: int = 2,
    local_replay_available: bool = True,
) -> dict[str, Any]:
    classification = diagnostic.get("classification")
    if classification not in DECISIONS:
        raise ValueError(f"UNKNOWN_ACTIONS_CLASSIFICATION:{classification}")

    if attempt_index < 0 or max_external_retries < 0:
        raise ValueError("INVALID_RETRY_BUDGET")

    decision, reason = DECISIONS[classification]
    notes: list[str] = []
    retryable = False
    local_allowed = local_replay_available and classification in {
        "RUNNER_STARTUP_FAILURE",
        "WORKFLOW_EXECUTION_FAILURE",
    }

    if classification == "NOT_DISPATCHED":
        decision = "RETRY_EXTERNAL"
        reason = "RUN_NOT_DISPATCHED_REDISPATCH_REQUIRED"
        retryable = False
        local_allowed = False
        notes.append("no completed acceptance run was observed; re-dispatch the same logical close request")
    elif classification == "RUNNER_STARTUP_FAILURE":
        decision = "DIAGNOSE"
        reason = "RUNNER_STARTUP_FAILURE_SWITCH_TO_LOCAL_DIAGNOSTIC"
        retryable = False
        local_allowed = local_replay_available
        if local_replay_available:
            notes.append("do not retry the same external path; switch to local diagnostic execution")
        else:
            decision = "REQUIRE_MANUAL_REVIEW"
            reason = "RUNNER_STARTUP_FAILURE_NO_DIAGNOSTIC_PATH"
            local_allowed = False
    elif classification == "WORKFLOW_EXECUTION_FAILURE":
        if not local_replay_available:
            decision = "BLOCK"
            reason = "LOCAL_REPLAY_UNAVAILABLE"
            local_allowed = False
        else:
            notes.append("replay selected regression locally before treating external failure as canonical")
    elif classification == "PASS":
        notes.append("runtime evidence is complete enough for external PASS classification")

    run_id = diagnostic.get("diagnostic_id", "UNKNOWN").split(":", 1)[-1]
    result = {
        "recovery_id": f"ACTIONS_RECOVERY:{run_id}:{attempt_index}",
        "source_classification": classification,
        "decision": decision,
        "reason_code": reason,
        "retryable": retryable,
        "local_replay_allowed": local_allowed,
        "attempt_index": attempt_index,
        "max_external_retries": max_external_retries,
        "recommended_command": (
            "github_actions.workflow_dispatch"
            if decision == "RETRY_EXTERNAL" and classification == "NOT_DISPATCHED"
            else "github_actions.rerun_failed_jobs"
            if decision == "RETRY_EXTERNAL"
            else "actions_execution_local_fallback.py"
            if decision == "DIAGNOSE"
            else "actions_regression_replay.py"
            if decision == "REPLAY_LOCAL"
            else "none"
        ),
        "notes": notes,
    }
    _validate(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Build P1 Actions execution recovery decision")
    parser.add_argument("diagnostic")
    parser.add_argument("output")
    parser.add_argument("--attempt-index", type=int, default=0)
    parser.add_argument("--max-external-retries", type=int, default=2)
    parser.add_argument("--no-local-replay", action="store_true")
    args = parser.parse_args()

    result = build(
        _load(Path(args.diagnostic).resolve()),
        attempt_index=args.attempt_index,
        max_external_retries=args.max_external_retries,
        local_replay_available=not args.no_local_replay,
    )
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
