#!/usr/bin/env python3
from __future__ import annotations

import copy
from typing import Any, Iterable

from state_transition import (
    _transition_map,
    load_contract,
    validate_contract,
)
from event_log import make_segment_event, validate_event


WORKFLOW_TERMINAL = {"COMPLETED", "FAILED", "CANCELLED"}


def initial_workflow_projection(
    workflow_id: str,
    *,
    status: str = "READY",
) -> dict[str, Any]:
    if status not in load_contract()["states"]["WORKFLOW"]:
        raise ValueError(f"不合法 Workflow 初始狀態: {status}")
    return {
        "workflow_id": workflow_id,
        "status": status,
        "state_revision": 0,
        "last_command_id": None,
        "last_idempotency_key": None,
        "last_command_fingerprint": None,
        "last_transition": None,
    }


def reduce_event(
    state: dict[str, Any],
    event: dict[str, Any],
) -> dict[str, Any]:
    """純 deterministic event reducer：不呼叫模型、工具或外部副作用。"""
    contract = load_contract()
    errors = validate_contract(contract)
    if errors:
        raise ValueError("invalid transition contract: " + "; ".join(errors))

    validate_event(event)

    current = copy.deepcopy(state)
    if event["aggregate_type"] != "WORKFLOW":
        raise ValueError("Replay 目前只接受 WORKFLOW Event")
    if event["aggregate_id"] != state["workflow_id"]:
        raise ValueError("Event aggregate_id 與 projection workflow_id 不一致")

    if event["event_type"] != "STATE_TRANSITION_APPLIED":
        raise ValueError(
            f"Reducer 不支援事件類型: {event['event_type']}"
        )

    expected_revision = state["state_revision"] + 1
    if event["revision"] != expected_revision:
        raise ValueError(
            f"Replay revision 不連續: expected={expected_revision} "
            f"actual={event['revision']}"
        )

    if event["from_status"] != state["status"]:
        raise ValueError(
            f"Replay from_status 不匹配: state={state['status']} "
            f"event={event['from_status']}"
        )

    if state["status"] in WORKFLOW_TERMINAL:
        raise ValueError(
            f"Replay 嘗試由 terminal state 繼續轉移: {state['status']}"
        )

    transitions = _transition_map(contract)
    expected_to = transitions.get(
        ("WORKFLOW", state["status"], event["command_type"])
        if event.get("command_type")
        else ("WORKFLOW", state["status"], "")
    )
    if expected_to != event["to_status"]:
        # Event 已保留 from/to，但仍由 contract 決定合法性。
        possible = {
            key[2]: value
            for key, value in transitions.items()
            if key[0] == "WORKFLOW"
            and key[1] == state["status"]
        }
        command_type = event.get("command_type")
        if command_type is None or possible.get(command_type) != event["to_status"]:
            raise ValueError(
                "Replay event 不符合 State Transition Contract: "
                f"{state['status']} -> {event['to_status']}"
            )

    current["status"] = event["to_status"]
    current["state_revision"] = event["revision"]
    current["last_command_id"] = event["command_id"]
    current["last_idempotency_key"] = event["idempotency_key"]
    current["last_command_fingerprint"] = event["command_fingerprint"]
    current["last_transition"] = copy.deepcopy(event)
    return current


def replay_workflow(
    initial_state: dict[str, Any],
    events: Iterable[dict[str, Any]],
) -> dict[str, Any]:
    state = copy.deepcopy(initial_state)
    seen_event_ids: set[str] = set()
    for event in events:
        if event["aggregate_type"] == "SEGMENT":
            continue  # Segment 事件由 replay_segments 處理（D11）
        if event["event_id"] in seen_event_ids:
            raise ValueError(f"Replay 發現重複 event_id: {event['event_id']}")
        seen_event_ids.add(event["event_id"])
        state = reduce_event(state, event)
    return state


def recover_workflow(
    current_state: dict[str, Any],
    event_log,
    *,
    candidate_command: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Reconcile Current against durable events and classify one pending command.

    This function does not persist, retry, schedule, or mutate canonical state.
    It only reconstructs the durable workflow projection and tells the caller
    whether a candidate command was committed, uncommitted, or unknowable.
    """
    events, log_observation = event_log.read_recoverable()
    initial = initial_workflow_projection(current_state["workflow_id"])
    replayed = replay_workflow(initial, events)

    current_view = projection_control_view(current_state)
    replay_view = projection_control_view(replayed)
    projection_matches = current_view == replay_view

    candidate_status = None
    matched_event = None
    if candidate_command is not None:
        candidate_id = candidate_command.get("command_id")
        candidate_key = candidate_command.get("idempotency_key")
        for event in events:
            if (
                event.get("command_id") == candidate_id
                or (
                    candidate_key is not None
                    and event.get("idempotency_key") == candidate_key
                )
            ):
                matched_event = event
                break

        if matched_event is not None:
            candidate_status = "COMMITTED"
        elif log_observation["status"] == "CLEAN":
            candidate_status = "UNCOMMITTED"
        else:
            candidate_status = "UNKNOWN"

    segment_logged = any(e["aggregate_type"] == "SEGMENT" for e in events)
    replayed_segments = replay_segments(initial_segment_projection(), events, workflow_id=current_state["workflow_id"])
    if segment_logged:
        segment_matches = segment_control_view(current_state) == segment_control_view(replayed_segments)
        segment_status = "MATCH" if segment_matches else "MISMATCH"
    else:
        current_segments = segment_control_view(current_state)
        empty_segments = segment_control_view(initial_segment_projection())
        segment_matches = current_segments == empty_segments
        segment_status = "NOT_LOGGED" if segment_matches else "NOT_LOGGED_CURRENT_NONEMPTY"

    if log_observation["status"] != "CLEAN" or not projection_matches or not segment_matches:
        overall = "RECONCILIATION_REQUIRED"
    else:
        overall = "RECOVERED"

    if log_observation["status"] != "CLEAN" or not segment_matches:
        next_action = "RECONCILIATION_REQUIRED"
    elif candidate_status == "UNCOMMITTED":
        next_action = "REISSUE_THROUGH_COMMAND_LAYER"
    else:
        next_action = "CONTINUE"

    return {
        "status": overall,
        "execution_status": candidate_status,
        "next_action": next_action,
        "log_observation": log_observation,
        "projection": replayed,
        "current_projection": current_view,
        "replay_projection": replay_view,
        "projection_matches": projection_matches,
        "segment_status": segment_status,
        "segment_projection": replayed_segments,
        "matched_event_id": matched_event["event_id"] if matched_event else None,
    }


def projection_control_view(state: dict[str, Any]) -> dict[str, Any]:
    keys = (
        "workflow_id",
        "status",
        "state_revision",
        "last_command_id",
        "last_idempotency_key",
        "last_command_fingerprint",
    )
    return {key: state.get(key) for key in keys}


# ---- D11：Segment 狀態 reducer（純函式；只讀 Event，不讀 Execution Store）----

SEGMENT_TABLES = {  # delta 鍵 → projection 表；值為該表去重用的 id 欄位（None=只 append）
    "queued": ("queued_segments", "segment_id"),
    "active": ("active_segments", "attempt_id"),
    "completed": ("completed_segments", None),
    "blocked": ("blocked_segments", None),
    "task_sets": ("task_sets", None),        # U-6：Task Set 發行紀錄（append-only；狀態由此衍生）
    "void": ("void_segments", None),         # U-6：作廢 segment（SUPERSEDED／INVALID／ABANDONED；append-only）
}
SEGMENT_SCALARS = {
    "attempt_counters": {},
    "scheduler_max_concurrency": 4,
    "retry_count": 0,
    "timeout_count": 0,
    "late_result_count": 0,
    "cancel_count": 0,
    "last_cancelled_segment_id": None,
    "last_cancel_reason": None,
}


def initial_segment_projection() -> dict[str, Any]:
    proj: dict[str, Any] = {table: [] for table, _ in SEGMENT_TABLES.values()}
    proj.update(copy.deepcopy(SEGMENT_SCALARS))
    return proj


def segment_control_view(state: dict[str, Any]) -> dict[str, Any]:
    """從 Central state（或 replay 結果）取出 Segment 控制面；缺欄位以預設值正規化。"""
    view: dict[str, Any] = {}
    for table, _ in SEGMENT_TABLES.values():
        view[table] = copy.deepcopy(state.get(table) or [])
    for key, default in SEGMENT_SCALARS.items():
        value = state.get(key)
        view[key] = copy.deepcopy(default if value is None and default is not None else value)
    return view


def apply_segment_delta(proj: dict[str, Any], delta: dict[str, Any]) -> dict[str, Any]:
    current = copy.deepcopy(proj)
    for name, (table, id_key) in SEGMENT_TABLES.items():
        part = delta.get(name)
        if not part:
            continue
        rows = current[table]
        for rid in part.get("remove", []):
            if id_key is None:
                raise ValueError(f"Segment delta 不可從 {table} 移除")
            if not any(r.get(id_key) == rid for r in rows):
                raise ValueError(f"Segment delta 移除不存在的項目: {table}:{rid}")
            rows = [r for r in rows if r.get(id_key) != rid]
        rows = rows + copy.deepcopy(part.get("add", []))
        current[table] = rows
    for key, value in delta.get("set", {}).items():
        if key not in SEGMENT_SCALARS:
            raise ValueError(f"Segment delta 含未知欄位: {key}")
        current[key] = copy.deepcopy(value)
    return current


def compute_segment_delta(before: dict[str, Any], after: dict[str, Any]) -> dict[str, Any]:
    """由兩份 Central state 計算 Segment 控制面差異，並驗證 apply(before, delta) == after（fail-closed）。"""
    b, a = segment_control_view(before), segment_control_view(after)
    delta: dict[str, Any] = {}
    for name, (table, id_key) in SEGMENT_TABLES.items():
        part: dict[str, Any] = {}
        if id_key is None:
            if a[table][: len(b[table])] != b[table]:
                raise ValueError(f"{table} 不是 append-only，無法以事件表達")
            added = a[table][len(b[table]):]
        else:
            before_ids = [r[id_key] for r in b[table]]
            after_ids = {r[id_key] for r in a[table]}
            removed = [rid for rid in before_ids if rid not in after_ids]
            added = [r for r in a[table] if r[id_key] not in set(before_ids)]
            if removed:
                part["remove"] = removed
        if added:
            part["add"] = added
        if part:
            delta[name] = part
    changed = {k: a[k] for k in SEGMENT_SCALARS if a[k] != b[k]}
    if changed:
        delta["set"] = changed
    if apply_segment_delta(b, delta) != a:
        raise ValueError("Segment 狀態變更無法由事件重建（順序或內容不符）")
    return delta


def _delta_segment_ids(delta: dict[str, Any]) -> list[str]:
    ids: list[str] = []
    for name, part in delta.items():
        if name == "set":
            if delta["set"].get("last_cancelled_segment_id"):
                ids.append(delta["set"]["last_cancelled_segment_id"])
            continue
        _, id_key = SEGMENT_TABLES[name]
        for rid in part.get("remove", []):
            if id_key == "segment_id":
                ids.append(rid)
        for row in part.get("add", []):
            if row.get("segment_id"):
                ids.append(row["segment_id"])
    return sorted(set(ids))


def _catch_up_unlogged_queue(
    event_log,
    before: dict[str, Any],
    *,
    occurred_at: str,
    correlation_id: str | None,
) -> None:
    """queue_segment 呼叫端沒傳 event_log 時，queued 項目不在 Log。

    只補「純 queued 新增」並以 CATCHUP 因果標記留痕；其他任何分歧一律 fail-closed（需 reconcile）。
    """
    workflow_id = before["workflow_id"]
    logged = replay_segments(
        initial_segment_projection(), event_log.read_all("SEGMENT"), workflow_id=workflow_id
    )
    gap = compute_segment_delta(logged, before)
    if not gap:
        return
    if set(gap) != {"queued"} or set(gap["queued"]) != {"add"}:
        raise ValueError("Segment 狀態與 Event Log 分歧（非純 queued 補記），需 reconcile: " + ",".join(sorted(gap)))
    last = event_log._last_event_for("SEGMENT", workflow_id)
    event_log.append(make_segment_event(
        workflow_id=workflow_id,
        event_type="SEGMENT_QUEUED",
        revision=(last["revision"] + 1) if last else 1,
        delta=gap,
        segment_ids=_delta_segment_ids(gap),
        correlation_id=correlation_id or f"CORR:{workflow_id}",
        causation_id="CATCHUP:UNLOGGED_QUEUE",
        occurred_at=occurred_at,
    ))


def log_segment_change(
    event_log,
    before: dict[str, Any],
    after: dict[str, Any],
    *,
    event_type: str,
    causation_id: str,
    occurred_at: str,
    correlation_id: str | None = None,
) -> dict[str, Any] | None:
    """把一次排程操作造成的 Segment 差異寫入 Event Log；無差異則不寫。"""
    workflow_id = after["workflow_id"]
    _catch_up_unlogged_queue(event_log, before, occurred_at=occurred_at, correlation_id=correlation_id)
    delta = compute_segment_delta(before, after)
    if not delta:
        return None
    last = event_log._last_event_for("SEGMENT", workflow_id)
    event = make_segment_event(
        workflow_id=workflow_id,
        event_type=event_type,
        revision=(last["revision"] + 1) if last else 1,
        delta=delta,
        segment_ids=_delta_segment_ids(delta),
        correlation_id=correlation_id or f"CORR:{workflow_id}",
        causation_id=causation_id,
        occurred_at=occurred_at,
    )
    event_log.append(event)
    return event


def reduce_segment_event(proj: dict[str, Any], event: dict[str, Any], *, expected_revision: int) -> dict[str, Any]:
    validate_event(event)
    if event["aggregate_type"] != "SEGMENT":
        raise ValueError("reduce_segment_event 只接受 SEGMENT Event")
    if event["revision"] != expected_revision:
        raise ValueError(
            f"Segment replay revision 不連續: expected={expected_revision} actual={event['revision']}"
        )
    return apply_segment_delta(proj, event.get("segment_delta") or {})


def replay_segments(
    initial: dict[str, Any],
    events: Iterable[dict[str, Any]],
    *,
    workflow_id: str | None = None,
) -> dict[str, Any]:
    proj = copy.deepcopy(initial)
    revision = 0
    for event in events:
        if event["aggregate_type"] != "SEGMENT":
            continue
        if workflow_id is not None and event["aggregate_id"] != workflow_id:
            raise ValueError("Segment Event aggregate_id 與 workflow_id 不一致")
        revision += 1
        proj = reduce_segment_event(proj, event, expected_revision=revision)
    return proj


if __name__ == "__main__":
    print("P2 Event Reducer ready")
