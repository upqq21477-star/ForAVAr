"""classify_guard -- guard around model classification (CAP-CLASSIFY, R3d12zu S4b batch 2).  Classification itself stays with the model.
Table {version, categories[]}; item {item_id, text}; model(item, table_copy, attempt) -> {category, confidence 0..1, locator} or
{category: None, propose: name}.  Guard: category must be in the table, confidence a finite number in 0..1, locator a non-empty dict;
below threshold -> UNCLASSIFIED (never forced); not-in-table / invalid -> retry up to max_retries, then UNCLASSIFIED; a proposed new
category goes to _proposals.json (PENDING_REVIEW) only; the model gets a deep copy and any change to it -> INCOMPLETE TABLE_MUTATED.
End: OK | PARTIAL (UNCLASSIFIED list) | INCOMPLETE (model error / table mutation; finished items kept, missing listed) | FAILED (bad table/items,
nothing written).  Idempotency key = (item_id, table version); resume = valid record skipped; mark_stale() flags other-version records STALE.
Evidence ceiling: SIMULATED_PASS.  threshold 0.6, max_retries 2, f09 ratio 0.3 are HYPOTHESIS; correctness of the labels is UNKNOWN (human sampling)."""
from __future__ import annotations

import copy
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Callable

from atomic_write import atomic_write

DONE = ("CLASSIFIED", "UNCLASSIFIED")


def _dump(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


def _table_error(table: Any) -> str:
    if not isinstance(table, dict) or not isinstance(table.get("version"), str) or not table["version"]:
        return "TABLE_NO_VERSION"
    cats = table.get("categories")
    if not isinstance(cats, list) or not cats or not all(isinstance(c, str) and c for c in cats):
        return "TABLE_BAD_CATEGORIES"
    return ""


def _items_error(items: Any) -> str:
    if not isinstance(items, list) or not all(isinstance(i, dict) and isinstance(i.get("item_id"), str) and i["item_id"] for i in items):
        return "ITEM_NO_ID"
    ids = [i["item_id"] for i in items]
    return "ITEM_DUPLICATE_ID" if len(set(ids)) != len(ids) else ""


def _path(out_dir: Path, item_id: str, version: str) -> Path:
    return out_dir / (hashlib.sha256(f"{item_id}|{version}".encode("utf-8")).hexdigest()[:12] + ".json")


def _valid_answer(ans: Any, table: dict[str, Any], threshold: float) -> tuple[bool, str]:
    if not isinstance(ans, dict):
        return False, "INVALID_ANSWER"
    c = ans.get("confidence")
    if isinstance(c, bool) or not isinstance(c, (int, float)) or not math.isfinite(c) or not 0 <= c <= 1:
        return False, "INVALID_ANSWER"
    if not isinstance(ans.get("locator"), dict) or not ans["locator"]:
        return False, "INVALID_ANSWER"
    if ans.get("category") not in table["categories"]:
        return False, "NOT_IN_TABLE"
    return (False, "LOW_CONFIDENCE") if c < threshold else (True, "")


def _load(p: Path) -> Any:
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _propose(out_dir: Path, name: str, item_id: str, version: str) -> None:
    p = out_dir / "_proposals.json"
    cur = _load(p) if p.exists() else []
    cur = cur if isinstance(cur, list) else []
    if not any(x.get("name") == name for x in cur):
        cur.append({"name": name, "item_id": item_id, "table_version": version, "status": "PENDING_REVIEW"})
        atomic_write(p, _dump(cur))


def _record(item_id: str, version: str, status: str, reason: str, ans: Any = None) -> dict[str, Any]:
    ok = status == "CLASSIFIED"
    return {"item_id": item_id, "table_version": version, "status": status, "reason": reason,
            "category": ans["category"] if ok else None, "confidence": ans.get("confidence") if ok else None,
            "locator": ans.get("locator") if ok else None}


def classify_items(items: list[dict[str, Any]], table: dict[str, Any], model: Callable[..., Any], out_dir: str | Path, *,
                   threshold: float = 0.6, max_retries: int = 2, f09_ratio: float = 0.3) -> dict[str, Any]:
    err = _table_error(table) or _items_error(items)
    if err:
        return {"status": "FAILED", "reason": err, "results": {}, "unclassified": [], "missing": []}
    out, ver = Path(out_dir), table["version"]
    out.mkdir(parents=True, exist_ok=True)
    results: dict[str, dict[str, Any]] = {}
    for idx, item in enumerate(items):
        iid, p = item["item_id"], _path(out, item["item_id"], ver)
        old = _load(p) if p.exists() else None
        if isinstance(old, dict) and old.get("item_id") == iid and old.get("table_version") == ver and old.get("status") in DONE:
            results[iid] = old
            continue
        rec = None
        for attempt in range(max_retries + 1):
            snap = copy.deepcopy(table)
            try:
                ans = model(item, snap, attempt)
            except Exception:  # model call failed: keep finished items, list the rest, no raise
                return _incomplete(results, items[idx:], "MODEL_ERROR")
            if _dump(snap) != _dump(table):
                return _incomplete(results, items[idx:], "TABLE_MUTATED")
            if isinstance(ans, dict) and ans.get("category") is None and isinstance(ans.get("propose"), str) and ans["propose"]:
                _propose(out, ans["propose"], iid, ver)
                rec = _record(iid, ver, "UNCLASSIFIED", "PROPOSED_NEW_CATEGORY")
                break
            ok, why = _valid_answer(ans, table, threshold)
            rec = _record(iid, ver, "CLASSIFIED", "", ans) if ok else _record(iid, ver, "UNCLASSIFIED", why)
            if ok or why == "LOW_CONFIDENCE":
                break
        atomic_write(p, _dump(rec))
        results[iid] = rec
    unc = [i for i, r in results.items() if r["status"] == "UNCLASSIFIED"]
    ratio = len(unc) / len(items) if items else 0.0
    hint = ratio > f09_ratio
    atomic_write(out / "_summary.json", _dump({"table_version": ver, "total": len(items), "unclassified_ratio": ratio, "f09_hint": hint}))
    return {"status": "PARTIAL" if unc else "OK", "reason": "", "results": results, "unclassified": unc, "missing": [],
            "unclassified_ratio": ratio, "f09_hint": hint}


def _incomplete(results: dict[str, Any], rest: list[dict[str, Any]], why: str) -> dict[str, Any]:
    return {"status": "INCOMPLETE", "reason": why, "results": results, "unclassified": [], "missing": [i["item_id"] for i in rest]}


def mark_stale(out_dir: str | Path, table_version: str) -> list[str]:
    """Records made under another table version -> STALE (handed to F08 re-classification).  Already-STALE ones are skipped."""
    marked = []
    for p in sorted(Path(out_dir).glob("*.json")):
        rec = _load(p) if not p.name.startswith("_") else None
        if isinstance(rec, dict) and rec.get("status") in DONE and rec.get("table_version") != table_version:
            rec["status"] = "STALE"
            atomic_write(p, _dump(rec))
            marked.append(rec["item_id"])
    return marked
