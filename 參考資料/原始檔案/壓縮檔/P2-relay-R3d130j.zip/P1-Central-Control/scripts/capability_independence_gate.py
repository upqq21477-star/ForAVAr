#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

def load(path: str) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))

def main() -> int:
    ap = argparse.ArgumentParser(description="P1 canonical capability independence gate")
    ap.add_argument("registry")
    args = ap.parse_args()
    data = load(args.registry)

    errors: list[str] = []
    rules = data.get("global_rules", {})
    if rules.get("canonical_implementation_per_capability") is not True:
        errors.append("canonical_implementation_per_capability 必須為 true")
    if rules.get("capability_to_capability_direct_interface") is not False:
        errors.append("capability_to_capability_direct_interface 必須為 false")
    if rules.get("capability_to_central_direct_interface") is not False:
        errors.append("capability_to_central_direct_interface 必須為 false")

    seen: set[str] = set()
    for cap in data.get("capabilities", []):
        cid = cap.get("capability_id", "UNKNOWN")
        if cid in seen:
            errors.append(f"{cid}: capability_id 重複")
        seen.add(cid)
        if cap.get("implementation") != "CANONICAL":
            errors.append(f"{cid}: implementation 必須為 CANONICAL")
        deps = cap.get("dependencies", [])
        if deps:
            errors.append(f"{cid}: Capability-to-Capability dependencies 必須為空")

    result = {
        "status": "BLOCK" if errors else "PASS",
        "capability_count": len(data.get("capabilities", [])),
        "errors": errors,
        "rules": {
            "canonical_implementation_per_capability": True,
            "capability_to_capability_direct_interface": False,
            "capability_to_central_direct_interface": False,
        },
    }
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 3 if errors else 0

if __name__ == "__main__":
    raise SystemExit(main())
