"""hypothesis_guard -- deterministic guard around model-made hypotheses (CAP-HYPOTHESIS, R3d12zw S6 batch 1).  Producing/criticising hypotheses stays with the model.
Input: {id [A-Za-z0-9_-], version int>=1, statement, scope_limit, alternatives[>=1 non-empty str], counterexample_ref, level int>=0}.
check() verdict: REJECTED (fields missing; level>=2 without a resolvable record of THIS hypothesis with a non-empty scope; counterexample FOUND -- make a revised version)
| PROVISIONAL (level 0-1; record is SCOPE_LIMITED; search_error=True with no record -- usable, never promoted) | ACCEPTABLE (level>=2 and record NONE_IN_SCOPE)
| INCOMPLETE (counterexample_log missing/unreadable: nothing saved, never promoted).  Semantic correctness is not judged.
submit(): idempotency key = id + version, one atomic file per version; a revision is a new version and old versions are kept; same version + same content is reused without
recomputing, same version + different content -> REJECTED VERSION_EXISTS.  history() lists (version, status).  Evidence ceiling: SIMULATED_PASS.
FOUND -> REJECTED is this module's choice (the plan lists only fail-closed cases): HYPOTHESIS."""
from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

import counterexample_log
from atomic_write import atomic_write

LEVEL_MIN = 2


def _dump(o: Any) -> str:
    return json.dumps(o, ensure_ascii=False, sort_keys=True)


def _v(status: str, reason: str) -> dict[str, Any]:
    return {"status": status, "reason": reason}


def _needs_record(level: int) -> bool:
    return level >= LEVEL_MIN


def _text(x: Any) -> bool:
    return isinstance(x, str) and bool(x.strip())


def _fields_ok(h: Any) -> bool:
    if not isinstance(h, dict) or not isinstance(h.get("id"), str) or not re.fullmatch(r"[A-Za-z0-9_-]+", h["id"]):
        return False
    ints = all(isinstance(h.get(k), int) and not isinstance(h.get(k), bool) for k in ("version", "level"))
    alts = h.get("alternatives")
    return (ints and h["version"] >= 1 and h["level"] >= 0 and _text(h.get("statement")) and _text(h.get("scope_limit"))
            and isinstance(alts, list) and bool(alts) and all(_text(a) for a in alts))


def check(h: Any, log_dir: str | Path, search_error: bool = False) -> dict[str, Any]:
    if not _fields_ok(h):
        return _v("REJECTED", "FIELDS")
    if not _needs_record(h["level"]):
        return _v("PROVISIONAL", "LOW_LEVEL")
    ref = h.get("counterexample_ref")
    if not _text(ref):
        return _v("PROVISIONAL", "SEARCH_ERROR") if search_error else _v("REJECTED", "NO_COUNTEREXAMPLE_RECORD")
    r = counterexample_log.resolve(ref, log_dir)
    if r["status"] in ("MISSING", "UNREADABLE"):
        return _v("INCOMPLETE", "LOG_UNAVAILABLE")
    if r["status"] != "OK":
        return _v("REJECTED", "NO_COUNTEREXAMPLE_RECORD")
    rec = r["record"]
    if rec["hypothesis"] != h["id"]:
        return _v("REJECTED", "COUNTEREXAMPLE_MISMATCH")
    if rec["status"] == "FOUND":
        return _v("REJECTED", "COUNTEREXAMPLE_FOUND")
    return _v("PROVISIONAL", "SCOPE_LIMITED") if rec["status"] == "SCOPE_LIMITED" else _v("ACCEPTABLE", "")


def _load(p: Path) -> Any:
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None
    except (OSError, ValueError):
        return None


def submit(h: Any, log_dir: str | Path, store_dir: str | Path, search_error: bool = False) -> dict[str, Any]:
    if not _fields_ok(h):
        return {**_v("REJECTED", "FIELDS"), "cached": False}
    p = Path(store_dir) / f"{h['id']}.v{h['version']}.json"
    digest = hashlib.sha256(_dump(h).encode("utf-8")).hexdigest()
    old = _load(p)
    if isinstance(old, dict) and isinstance(old.get("verdict"), dict):
        if old.get("digest") == digest:
            return {**old["verdict"], "cached": True}
        return {**_v("REJECTED", "VERSION_EXISTS"), "cached": False}
    v = check(h, log_dir, search_error)
    if v["status"] != "INCOMPLETE":
        Path(store_dir).mkdir(parents=True, exist_ok=True)
        atomic_write(p, _dump({"digest": digest, "hypothesis": h, "verdict": v}))
    return {**v, "cached": False}


def history(hid: str, store_dir: str | Path) -> list[tuple[int, str]]:
    out = []
    for p in Path(store_dir).glob(f"{hid}.v*.json"):
        d = _load(p)
        if isinstance(d, dict) and isinstance(d.get("hypothesis"), dict) and isinstance(d.get("verdict"), dict):
            out.append((d["hypothesis"]["version"], d["verdict"]["status"]))
    return sorted(out)
