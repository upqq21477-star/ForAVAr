#!/usr/bin/env python3
"""CS-1 B7：Working Context 組裝（Master §11、02 P10）與可回答的狀態報告（02 §11 末項、P20）。

Context 不是資料庫，是一次工作的組裝結果；Reset 後不要求模型記得，從權威資料重新組裝。
指令通道（`instructions`）只收呼叫端傳入的權威項（Current Truth／Active Task）；Knowledge、Evidence、
Checkpoint、Card 一律進 `data`（Data≠Instruction，Master §25）——結構分離，不靠偵測惡意字句。
COLD／ARCHIVE 預設不進 Context；超出預算的項目列入 `omitted_refs`，不靜默省略。stdlib only、決定性。
"""

from __future__ import annotations

from typing import Any

from event_log import content_hash
from knowledge_intake import coverage
from knowledge_retrieval import Retriever, snapshot
from knowledge_versioning import TemporalKnowledgeStore

DATA_KEYS = ("claims", "evidence", "checkpoint", "cards")


def _claim_traceable(store: TemporalKnowledgeStore, claim_ref: str) -> bool:
    """Check the current claim's evidence chain without traversing version history."""
    claim = store.claims.get(claim_ref)
    if not claim:
        return False

    observation_refs = set(claim.get("observation_refs", []))
    evidence_refs = claim.get("evidence_refs", [])
    if not observation_refs or not evidence_refs:
        return False

    supported_observations: set[str] = set()
    for evidence_ref in evidence_refs:
        evidence = store.evid.get(evidence_ref)
        if not evidence or evidence.get("claim_ref") != claim_ref or evidence.get("relation") != "SUPPORTS":
            return False

        observation_ref = evidence.get("observation_ref")
        observation = store.obs.get(observation_ref or "")
        if not observation or observation.get("observation_class") != "OBSERVED":
            return False
        if (evidence.get("segment_ref"), evidence.get("source_ref")) != (
            observation.get("segment_ref"), observation.get("source_ref")
        ):
            return False
        quote = observation.get("quote")
        if not isinstance(quote, str) or not quote:
            return False
        try:
            if store.ledger.state(evidence["segment_ref"]) not in ("READ", "PROCESSED"):
                return False
            if quote not in store.segment_text(evidence["segment_ref"]):
                return False
        except (KeyError, TypeError, ValueError):
            return False
        supported_observations.add(observation_ref)

    return observation_refs.issubset(supported_observations)


def assemble_context(store: TemporalKnowledgeStore, *, current_truth: dict[str, Any], active_task: dict[str, Any], at: str,
                     checkpoint: dict[str, Any] | None = None, cards: list[dict[str, Any]] | None = None,
                     claim_kind: str | None = None, budget_chars: int = 6000) -> dict[str, Any]:
    if not current_truth or not active_task:
        raise ValueError("CONTEXT_AUTHORITY_REQUIRED:current_truth／active_task")
    snap_hash = snapshot(store)["snapshot_hash"]
    if checkpoint is not None and checkpoint.get("knowledge_snapshot_hash") != snap_hash:
        raise ValueError("CHECKPOINT_STALE:knowledge_snapshot_hash")
    r = Retriever(store)
    valid = store.valid_at(at, claim_kind)
    claims, evidence, omitted, used = [], [], [], 0
    for ref in valid["valid"] + valid["disputed"]:  # 爭議項保留可見，不混入也不隱藏
        t = r.trace(ref)
        size = len(t["claim"]["content"]) + sum(len(e["fragment"]) for e in t["evidence"] if e["claim_ref"] == ref)
        if used + size > budget_chars:
            omitted.append(ref)
            continue
        used += size
        claims.append(t["claim"])
        evidence += [e for e in t["evidence"] if e["claim_ref"] == ref]
    ctx: dict[str, Any] = {
        "kind": "WORKING_CONTEXT", "at": at, "knowledge_snapshot_hash": snap_hash,
        "instructions": {"current_truth": current_truth, "active_task": active_task},
        "data": {"claims": claims, "evidence": evidence, "checkpoint": checkpoint, "cards": list(cards or [])},
        "trust": {"instructions": "AUTHORITATIVE", "data": "DATA"}, "scopes_included": ["ACTIVE", "WARM"],
        "omitted_refs": omitted, "budget_chars": budget_chars,
    }
    ctx["context_hash"] = content_hash(ctx)
    return ctx


def instruction_channel(ctx: dict[str, Any]) -> dict[str, Any]:
    """唯一可被當作指令的部分；任何 data 內容都不在此。"""
    return ctx["instructions"]


def status_report(store: TemporalKnowledgeStore, contract: dict[str, Any], at: str) -> dict[str, Any]:
    """已讀／未讀／已確認／衝突／未知／目前有效規則／來源與採用版本理由（結構化，可重建，非文字漂亮）。"""
    led = store.ledger
    states = {ref: led.state(ref) for ref in sorted(led.segments)}
    v = store.valid_at(at)
    unknown = sorted({o["object_id"] for o in store.obs.values() if o["observation_class"] == "UNKNOWN"})
    adopted = []
    for ref in v["valid"] + v["disputed"]:
        c = store.claims[ref]
        adopted.append({"claim": ref, "revision": c["revision"], "adjudication": c.get("adjudication"),
                        "supersedes": c.get("supersedes", []), "source_refs": c["source_refs"]})
    return {
        "coverage": coverage(led, contract)["status"],
        "read": [s for s, st in states.items() if st in ("READ", "PROCESSED")],
        "unread": [s for s, st in states.items() if st not in ("READ", "PROCESSED")],
        "confirmed": sorted(c for c, rec in store.claims.items() if rec["promotion"] == "CANONICAL"),
        "conflicts": [{"conflict": k, "status": c["status"], "claims": [c["claim_a"], c["claim_b"]]} for k, c in sorted(store.conflicts.items())],
        "unknown_observations": unknown, "currently_valid": v["valid"], "disputed": v["disputed"], "adopted": adopted,
        "traceable": all(_claim_traceable(store, a["claim"]) for a in adopted),
    }
