#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT=Path(__file__).resolve().parents[2]
SCHEMA=ROOT/"P1-Central-Control/schemas/control_gate_report.schema.json"


def validate(report: dict[str, Any]) -> None:
    schema=json.loads(SCHEMA.read_text(encoding="utf-8"))
    Draft202012Validator(schema).validate(report)


def write(
    output: str,
    base_sha: str,
    head_sha: str,
    status: str,
    stages: list[dict[str, Any]],
) -> int:
    report={
        "report_id":f"LOCAL_CONTROL_GATE:{head_sha}",
        "base_sha":base_sha,
        "head_sha":head_sha,
        "status":status,
        "stages":stages,
    }
    validate(report)
    Path(output).write_text(
        json.dumps(report,ensure_ascii=False,indent=2)+"\n",
        encoding="utf-8",
    )
    print(json.dumps(report,ensure_ascii=False,indent=2))
    return 0 if status=="PASS" else 2 if status=="INCOMPLETE" else 1
