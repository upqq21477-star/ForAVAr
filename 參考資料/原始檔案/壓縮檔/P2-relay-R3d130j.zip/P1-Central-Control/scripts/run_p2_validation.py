#!/usr/bin/env python3
"""Reproducible offline validation for P2-B2.2.

Modes:
  simulation: run unit/fixture tests plus the repository's non-writing pack check.
  integration: require simulation success, write/verify one canonical pack,
                then prove an identical rebuild is a no-op.

This runner never changes P1-CURRENT.json and never calls GitHub Actions or an API.
A SIMULATION_PASS is not a runtime or end-to-end feasibility claim.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

from feature_batch_orchestrator import BatchGateError, validate_final_test_gate

ROOT = Path(__file__).resolve().parents[2]
CURRENT_REF = "P1-CURRENT.json"
REQUEST_REF = "P1-Central-Control/examples/operational_reference_pack.request.example.json"
ACTIVE_WORK_DEFAULT = "P1-Central-Control/progress/P2-B2.2.work.json"
PACK_REF = "P1-Central-Control/canonical/operational_reference_pack.json"
REPORT_ROOT_REF = "P1-Central-Control/acceptance/reports"
REPORT_SCHEMA_VERSION = "2.1"
TEST_FILES = (
    "P1-Central-Control/tests/test_continuation_context_box.py",
    "P1-Central-Control/tests/test_knowledge_retrieval.py",
    "P1-Central-Control/tests/test_operational_reference_pack.py",
    "P1-Central-Control/tests/test_current_projection_sync.py",
    "P1-Central-Control/tests/test_run_p2_validation.py",
    "P1-Central-Control/tests/test_brain_mode_controller.py",
    "P1-Central-Control/tests/test_brain_mode_runtime_interface.py",
)
EXPECTED_TEST_COUNTS = {
    "P1-Central-Control/tests/test_continuation_context_box.py": 11,
    "P1-Central-Control/tests/test_knowledge_retrieval.py": 18,
    "P1-Central-Control/tests/test_operational_reference_pack.py": 35,
    "P1-Central-Control/tests/test_current_projection_sync.py": 10,
    "P1-Central-Control/tests/test_run_p2_validation.py": 15,
    "P1-Central-Control/tests/test_brain_mode_controller.py": 15,
    "P1-Central-Control/tests/test_brain_mode_runtime_interface.py": 5,
}
PACK_CLI = "P1-Central-Control/scripts/operational_reference_pack.py"
WORK_SCHEMA_REF = "P1-Central-Control/schemas/operational_work_unit.schema.json"


class ValidationBlocked(RuntimeError):
    def __init__(self, code: str, detail: str = "") -> None:
        self.code = code
        self.detail = detail
        super().__init__(f"{code}:{detail}" if detail else code)


def check_pinned_dependencies(root: Path) -> dict[str, Any]:
    """Compare the running environment with every exact pin in requirements-runtime.txt."""
    lock_path = path_ref(root, "P1-Central-Control/requirements-runtime.txt")
    packages = []
    try:
        lines = lock_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        return {"status": "LOCK_MISSING", "packages": [], "detail": str(exc)}
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        match = re.fullmatch(r"([A-Za-z0-9_.-]+)==([A-Za-z0-9_.+!-]+)", line)
        if not match:
            return {"status": "LOCK_INVALID", "packages": [], "detail": line}
        name, expected = match.groups()
        try:
            actual = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            actual = None
        packages.append({"name": name, "expected_version": expected, "actual_version": actual, "matches": actual == expected})
    status = "MATCH" if packages and all(item["matches"] for item in packages) else "MISMATCH"
    return {"status": status, "packages": packages}


def test_count_from_output(step: dict[str, Any]) -> int | None:
    output = (step.get("stdout_tail") or "") + "\n" + (step.get("stderr_tail") or "")
    matches = re.findall(r"Ran\s+(\d+)\s+tests?\s+in\s+", output)
    return int(matches[-1]) if matches else None

def read_json(path: Path, code: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationBlocked(code, str(path)) from exc
    if not isinstance(value, dict):
        raise ValidationBlocked(code, f"JSON object required: {path}")
    return value


def path_ref(root: Path, ref: str) -> Path:
    candidate = Path(ref)
    if not ref or candidate.is_absolute() or ".." in candidate.parts:
        raise ValidationBlocked("VALIDATION_PATH_FORBIDDEN", ref)
    resolved_root = root.resolve()
    resolved = (resolved_root / candidate).resolve()
    try:
        resolved.relative_to(resolved_root)
    except ValueError as exc:
        raise ValidationBlocked("VALIDATION_PATH_FORBIDDEN", ref) from exc
    return resolved


def path_like_inputs(values: list[Any]) -> set[str]:
    suffixes = {".json", ".md", ".py", ".txt", ".yaml", ".yml", ".toml", ".csv", ".svg", ".png"}
    return {
        value for value in values
        if isinstance(value, str) and ("/" in value or Path(value).suffix.lower() in suffixes)
    }


def validate_json_schema(
    root: Path,
    value: dict[str, Any],
    schema_ref: str,
    error_code: str,
) -> None:
    """Validate a JSON object against an explicitly referenced repository schema."""
    schema = read_json(path_ref(root, schema_ref), error_code)
    try:
        from jsonschema import Draft202012Validator
        Draft202012Validator.check_schema(schema)
        errors = sorted(
            Draft202012Validator(schema).iter_errors(value),
            key=lambda error: list(error.path),
        )
    except Exception as exc:
        raise ValidationBlocked(error_code, f"{schema_ref}: {exc}") from exc
    if errors:
        detail = "; ".join(
            f"{'/'.join(str(part) for part in error.path)}: {error.message}"
            for error in errors[:8]
        )
        raise ValidationBlocked(error_code, detail)


def validate_current_schema(root: Path, current: dict[str, Any]) -> None:
    """Validate the authoritative Current object against its declared repository schema."""
    validate_json_schema(
        root,
        current,
        "P1-Central-Control/schemas/p1_current.schema.json",
        "VALIDATION_CURRENT_SCHEMA_INVALID",
    )


def _stable_payload_sha256(value: dict[str, Any]) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def active_work_contract_sha256(work: dict[str, Any]) -> str:
    """Fingerprint declared work scope while excluding lifecycle-owned runtime state."""
    projection = json.loads(json.dumps(work, ensure_ascii=False))
    for key in ("status", "implementation_step", "current_result", "next_action", "brain_mode_control"):
        projection.pop(key, None)
    handoff = projection.get("handoff")
    if isinstance(handoff, dict):
        handoff.pop("next_step", None)
    return _stable_payload_sha256(projection)


def active_construction_contract_sha256(construction: dict[str, Any]) -> str:
    """Fingerprint construction authority while excluding status and lifecycle notes."""
    projection = json.loads(json.dumps(construction, ensure_ascii=False))
    projection.pop("status", None)
    handoff = projection.get("handoff")
    if isinstance(handoff, dict):
        notes = handoff.get("notes", [])
        if isinstance(notes, list):
            handoff["notes"] = [
                note for note in notes
                if not (isinstance(note, str) and note.startswith("B2.2 lifecycle:"))
            ]
    return _stable_payload_sha256(projection)


def _current_stage_work_unit_id(stage: dict[str, Any]) -> str | None:
    """Use Pack/Central precedence and reject malformed truthy identity values."""
    candidate = stage.get("work_unit_id") or stage.get("slice_id") or stage.get("id")
    return candidate if isinstance(candidate, str) and candidate.strip() else None


def preflight(root: Path) -> dict[str, Any]:
    """Check the intended work binding and every explicitly required path; no discovery."""
    current = read_json(path_ref(root, CURRENT_REF), "CURRENT_INVALID")
    validate_current_schema(root, current)
    request = read_json(path_ref(root, REQUEST_REF), "PACK_REQUEST_INVALID")
    validate_json_schema(
        root,
        request,
        "P1-Central-Control/schemas/operational_pack_request.schema.json",
        "PACK_REQUEST_SCHEMA_INVALID",
    )
    implementation = current.get("implementation_control")
    stage = current.get("current_stage")
    if not isinstance(implementation, dict) or not isinstance(stage, dict):
        raise ValidationBlocked("CURRENT_ACTIVE_WORK_POINTER_INVALID")
    active_ref = implementation.get("active_work_packet")
    if active_ref != request.get("active_work_ref"):
        raise ValidationBlocked("PACK_ACTIVE_WORK_REF_NOT_CURRENT", str(request.get("active_work_ref")))
    target_blueprint = current.get("p2_target_blueprint_ref")
    if target_blueprint != request.get("blueprint_ref"):
        raise ValidationBlocked("PACK_BLUEPRINT_REF_NOT_CURRENT", str(request.get("blueprint_ref")))
    active_path = path_ref(root, active_ref)
    work = read_json(active_path, "PACK_ACTIVE_WORK_PACKET_INVALID")
    validate_json_schema(
        root,
        work,
        WORK_SCHEMA_REF,
        "PACK_ACTIVE_WORK_SCHEMA_INVALID",
    )
    expected_work_unit = _current_stage_work_unit_id(stage)
    if work.get("work_id") != stage.get("id") or work.get("work_unit") != expected_work_unit:
        raise ValidationBlocked("PACK_CURRENT_ACTIVE_WORK_MISMATCH", active_ref)
    if work.get("status") not in {"READY", "IN_PROGRESS", "BUILDING", "CHANGE_OBSERVED", "ACCEPTANCE"}:
        raise ValidationBlocked("PACK_ACTIVE_WORK_NOT_ACTIVE", str(work.get("status")))
    if work.get("blueprint_ref") != request.get("blueprint_ref"):
        raise ValidationBlocked("PACK_BLUEPRINT_WORK_PACKET_MISMATCH", str(work.get("blueprint_ref")))

    active_construction_ref = implementation.get("active_construction_packet")
    if not isinstance(active_construction_ref, str) or not active_construction_ref:
        raise ValidationBlocked("PACK_CURRENT_ACTIVE_CONSTRUCTION_INVALID")
    if work.get("construction_packet_ref") != active_construction_ref:
        raise ValidationBlocked("PACK_CURRENT_ACTIVE_CONSTRUCTION_MISMATCH", active_ref)
    construction_path = path_ref(root, active_construction_ref)
    construction = read_json(construction_path, "PACK_ACTIVE_CONSTRUCTION_PACKET_INVALID")
    try:
        from jsonschema import Draft202012Validator
        construction_schema = read_json(
            path_ref(root, "P1-Central-Control/schemas/construction_packet.schema.json"),
            "PACK_ACTIVE_CONSTRUCTION_SCHEMA_INVALID",
        )
        Draft202012Validator(construction_schema).validate(construction)
    except Exception as exc:
        raise ValidationBlocked("PACK_ACTIVE_CONSTRUCTION_PACKET_INVALID", str(exc)) from exc
    if construction.get("packet_id") != f"CONSTRUCTION:{work.get('work_unit')}":
        raise ValidationBlocked("PACK_ACTIVE_CONSTRUCTION_ID_MISMATCH", active_construction_ref)
    if construction.get("work_segment_ref") != work.get("work_unit"):
        raise ValidationBlocked("PACK_ACTIVE_CONSTRUCTION_WORK_UNIT_MISMATCH", active_construction_ref)
    if construction.get("status") not in {"READY", "BUILDING", "CHANGE_OBSERVED", "ACCEPTANCE"}:
        raise ValidationBlocked("PACK_ACTIVE_CONSTRUCTION_NOT_ACTIVE", str(construction.get("status")))
    if construction.get("implementation_contract", {}).get("runtime_entrypoint") != PACK_CLI:
        raise ValidationBlocked("PACK_ACTIVE_CONSTRUCTION_ENTRYPOINT_MISMATCH", active_construction_ref)

    source_refs = request.get("source_refs")
    if not isinstance(source_refs, list):
        raise ValidationBlocked("PACK_REQUEST_INVALID", "source_refs must be an array")
    source_by_path = {item.get("path"): item for item in source_refs if isinstance(item, dict)}
    if len(source_by_path) != len(source_refs):
        raise ValidationBlocked("PACK_SOURCE_REF_DUPLICATE_OR_INVALID")
    declared = set(source_by_path)
    active_spec = source_by_path.get(active_ref)
    if active_spec is None or active_spec.get("required") is not True:
        raise ValidationBlocked("PACK_ACTIVE_WORK_REF_NOT_DECLARED_REQUIRED", active_ref)
    construction_spec = source_by_path.get(active_construction_ref)
    if construction_spec is None or construction_spec.get("required") is not True:
        raise ValidationBlocked("PACK_ACTIVE_CONSTRUCTION_REF_NOT_DECLARED_REQUIRED", active_construction_ref)
    contract = work.get("operational_contract")
    if not isinstance(contract, dict):
        raise ValidationBlocked("PACK_ACTIVE_WORK_PACKET_INVALID", "operational_contract")
    needed = path_like_inputs(contract.get("required_inputs", []))
    missing_declarations = sorted(needed - declared - {CURRENT_REF, request.get("blueprint_ref")})
    if missing_declarations:
        raise ValidationBlocked("PACK_REQUIRED_WORK_INPUT_NOT_DECLARED", ",".join(missing_declarations))
    required_declared = {
        ref for ref, item in source_by_path.items() if item.get("required") is True
    }
    missing_files = sorted(
        ref for ref in required_declared | needed | {CURRENT_REF, request.get("blueprint_ref"), active_construction_ref}
        if isinstance(ref, str) and not path_ref(root, ref).is_file()
    )
    if missing_files:
        raise ValidationBlocked("PACK_REQUIRED_REF_MISSING", ",".join(missing_files))

    # Check JSON syntax of declared schemas explicitly. The active construction
    # packet is also validated here; the Builder validates it again on build/verify.
    for schema_ref in (
        "P1-Central-Control/schemas/operational_pack_request.schema.json",
        "P1-Central-Control/schemas/operational_reference_pack.schema.json",
        WORK_SCHEMA_REF,
        "P1-Central-Control/schemas/construction_packet.schema.json",
    ):
        read_json(path_ref(root, schema_ref), "VALIDATION_SCHEMA_JSON_INVALID")

    return {
        "status": "PREFLIGHT_PASS",
        "current_stage_id": stage.get("id"),
        "current_stage_acceptance": stage.get("acceptance"),
        "current_stage_regression_tests": stage.get("regression_tests"),
        "current_blueprint_ref": target_blueprint,
        "active_work_ref": active_ref,
        "active_work_unit": work.get("work_unit"),
        "active_construction_ref": active_construction_ref,
        "active_construction_packet_id": construction.get("packet_id"),
        "active_work_contract_sha256": active_work_contract_sha256(work),
        "active_construction_contract_sha256": active_construction_contract_sha256(construction),
        "declared_source_count": len(source_refs),
        "required_source_count": len(required_declared),
        "path_like_required_input_count": len(needed),
        "historical_context_loaded": False,
        "repository_scan_performed": False,
    }


def run_step(root: Path, name: str, command: list[str], timeout: int = 180) -> dict[str, Any]:
    started = time.monotonic()
    try:
        result = subprocess.run(
            command, cwd=root, text=True, capture_output=True, timeout=timeout, check=False
        )
        elapsed = round(time.monotonic() - started, 3)
        return {
            "name": name,
            "command": command,
            "status": "PASS" if result.returncode == 0 else "FAIL",
            "return_code": result.returncode,
            "elapsed_seconds": elapsed,
            "stdout_tail": result.stdout[-5000:],
            "stderr_tail": result.stderr[-3000:],
        }
    except subprocess.TimeoutExpired as exc:
        elapsed = round(time.monotonic() - started, 3)
        stdout = exc.stdout.decode("utf-8", "replace") if isinstance(exc.stdout, bytes) else (exc.stdout or "")
        stderr = exc.stderr.decode("utf-8", "replace") if isinstance(exc.stderr, bytes) else (exc.stderr or "")
        return {
            "name": name,
            "command": command,
            "status": "TIMEOUT",
            "return_code": None,
            "elapsed_seconds": elapsed,
            "stdout_tail": stdout[-5000:],
            "stderr_tail": stderr[-3000:],
        }


def parse_json_result(
    step: dict[str, Any],
    *,
    expected_status: str | tuple[str, ...] | set[str] | None = None,
) -> dict[str, Any]:
    """Parse a successful CLI result and optionally enforce its semantic status.

    A zero process exit is transport success only; callers that depend on the
    result must require the exact documented status (or an explicit set).
    """
    if step["status"] != "PASS":
        raise ValidationBlocked("VALIDATION_STEP_FAILED", step["name"])
    try:
        value = json.loads(step["stdout_tail"])
    except json.JSONDecodeError as exc:
        raise ValidationBlocked("VALIDATION_COMMAND_OUTPUT_NOT_JSON", step["name"]) from exc
    if not isinstance(value, dict):
        raise ValidationBlocked("VALIDATION_COMMAND_OUTPUT_NOT_OBJECT", step["name"])
    actual = value.get("status")
    step["result_status"] = actual
    if value.get("reason_code") is not None:
        step["cli_reason_code"] = value["reason_code"]
    if value.get("detail") is not None:
        step["cli_detail"] = value["detail"]
    if not isinstance(actual, str) or not actual.strip():
        raise ValidationBlocked(
            "VALIDATION_UNEXPECTED_RESULT_STATUS",
            f"{step['name']}: result status must be a non-empty string; actual_type={type(actual).__name__}",
        )
    if expected_status is not None:
        allowed = {expected_status} if isinstance(expected_status, str) else set(expected_status)
        if actual not in allowed:
            expected = ",".join(sorted(allowed))
            detail = f"{step['name']}: expected=[{expected}] actual={actual!r}"
            if actual == "BLOCKED":
                detail += (
                    f" cli_reason_code={value.get('reason_code', 'VALIDATION_COMMAND_BLOCKED')!r}"
                    f" cli_detail={value.get('detail', '')!r}"
                )
            raise ValidationBlocked("VALIDATION_UNEXPECTED_RESULT_STATUS", detail)
    elif actual == "BLOCKED":
        detail = (
            f"{step['name']}: expected=[non-BLOCKED result] actual='BLOCKED'"
            f" cli_reason_code={value.get('reason_code', 'VALIDATION_COMMAND_BLOCKED')!r}"
            f" cli_detail={value.get('detail', '')!r}"
        )
        raise ValidationBlocked("VALIDATION_UNEXPECTED_RESULT_STATUS", detail)
    return value


def classify_validation_block(exc: ValidationBlocked) -> tuple[str, str | None]:
    """Keep result-contract failures distinct from preflight/environment blocks."""
    if exc.code == "PINNED_DEPENDENCY_MISMATCH":
        return "BLOCKED_DEPENDENCY", None
    if exc.code in {
        "VALIDATION_COMMAND_OUTPUT_NOT_JSON",
        "VALIDATION_COMMAND_OUTPUT_NOT_OBJECT",
        "VALIDATION_UNEXPECTED_RESULT_STATUS",
        "VALIDATION_CHECK_ONLY_SIDE_EFFECT_DECLARED",
    }:
        failed_step = exc.detail.split(":", 1)[0]
        status = (
            "SIMULATION_FAIL"
            if failed_step == "operational-pack-check-only"
            else "INTEGRATION_FAIL"
        )
        return status, failed_step
    return "BLOCKED", None


def mark_failed_result_step(
    report: dict[str, Any],
    failed_step: str | None,
    exc: ValidationBlocked,
    report_status: str,
) -> None:
    """Reflect semantic acceptance failures in the step record, not only the report."""
    if not failed_step or exc.code not in {
        "VALIDATION_COMMAND_OUTPUT_NOT_JSON",
        "VALIDATION_COMMAND_OUTPUT_NOT_OBJECT",
        "VALIDATION_UNEXPECTED_RESULT_STATUS",
        "VALIDATION_CHECK_ONLY_SIDE_EFFECT_DECLARED",
    }:
        return
    for step in reversed(report.get("steps", [])):
        if step.get("name") == failed_step:
            # Keep the actual subprocess result visible: exit code zero is not
            # equivalent to satisfying the CLI result contract.
            step["process_status"] = step.get("status")
            step["status"] = "RESULT_CONTRACT_FAIL"
            step["failure_class"] = report_status
            step["reason_code"] = exc.code
            step["detail"] = exc.detail
            return


def mark_canonical_write_started(report: dict[str, Any]) -> None:
    """Record that the canonical writer was invoked while keeping its result unknown."""
    report["canonical_pack_write_attempted"] = True
    report["canonical_pack_write_occurred"] = None
    report["canonical_pack_write_outcome"] = "UNKNOWN"


def record_canonical_write_result(report: dict[str, Any], result: dict[str, Any]) -> None:
    """Resolve write truth only from a parsed, contract-valid builder result."""
    status = result.get("status")
    if not isinstance(status, str) or status not in {"WRITTEN", "UNCHANGED"}:
        raise ValidationBlocked(
            "VALIDATION_UNEXPECTED_RESULT_STATUS",
            f"operational-pack-promote-canonical: expected=[UNCHANGED,WRITTEN] actual={status!r}",
        )
    report["canonical_pack_write_outcome"] = status
    report["canonical_pack_write_occurred"] = status == "WRITTEN"


def _report_output_path(root: Path, report_ref: str) -> Path:
    """Confine reports to their physical reports subtree and reject symlink redirects."""
    root = root.resolve()
    candidate = Path(report_ref)
    reports_lexical = Path(REPORT_ROOT_REF)
    if (
        not report_ref
        or candidate.is_absolute()
        or ".." in candidate.parts
        or candidate == reports_lexical
    ):
        raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref)
    try:
        candidate.relative_to(reports_lexical)
    except ValueError as exc:
        raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref) from exc

    # Do not follow any symlink supplied by the checkout or existing report tree.
    cursor = root
    for index, part in enumerate(candidate.parts):
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref)
        if index < len(candidate.parts) - 1 and cursor.exists() and not cursor.is_dir():
            raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref)

    target = path_ref(root, report_ref)
    if target.exists() and not target.is_file():
        raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref)
    reports_root = path_ref(root, REPORT_ROOT_REF)
    try:
        target.relative_to(reports_root)
    except ValueError as exc:
        raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref) from exc
    if target == reports_root:
        raise ValidationBlocked("VALIDATION_REPORT_PATH_FORBIDDEN", report_ref)
    return target


def _validated_report_target(root: Path, report_ref: str) -> Path:
    target = _report_output_path(root, report_ref)
    protected = {
        path_ref(root, CURRENT_REF),
        path_ref(root, PACK_REF),
        path_ref(root, REQUEST_REF),
        path_ref(root, PACK_CLI),
        *(path_ref(root, item) for item in TEST_FILES),
    }
    if target in protected:
        raise ValidationBlocked("VALIDATION_REPORT_OVERWRITE_FORBIDDEN", report_ref)
    return target


def write_report(root: Path, report_ref: str, report: dict[str, Any]) -> None:
    target = _validated_report_target(root, report_ref)
    target.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n"
    temp_path: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w", encoding="utf-8", newline="\n", dir=target.parent,
            prefix=f".{target.name}.", suffix=".tmp", delete=False,
        ) as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
            temp_path = Path(stream.name)
        os.replace(temp_path, target)
    finally:
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()


def main() -> int:
    parser = argparse.ArgumentParser(description="Offline P2 validation; no Actions/API dependency")
    parser.add_argument("--mode", choices=("simulation", "integration"), default="simulation")
    parser.add_argument("--report", help="optional repo-relative JSON report path (not Current or the Active Pack)")
    parser.add_argument("--timeout", type=int, default=180)
    args = parser.parse_args()

    report: dict[str, Any] = {
        "report_schema_version": REPORT_SCHEMA_VERSION,
        "mode": args.mode,
        "status": "BLOCKED",
        "python_version": sys.version.split()[0],
        "python_executable": sys.executable,
        "repository_commit": None,
        "repository_worktree_clean_at_start": None,
        "expected_test_method_count": sum(EXPECTED_TEST_COUNTS.values()),
        "actual_test_method_count": 0,
        "feature_batch_gate": None,
        "pinned_dependencies": {"status": "NOT_CHECKED", "packages": []},
        "tests_are_runtime_feasibility_proof": False,
        "canonical_pack_write_attempted": False,
        "canonical_pack_write_occurred": None,
        "canonical_pack_write_outcome": "NOT_ATTEMPTED",
        "steps": [],
        "limitations": [
            "Unit tests use fixtures/temp directories; their pass establishes tested logic, not external runtime availability.",
            "simulation mode does not write the canonical pack.",
            "Even integration mode does not establish a caller-driven B1-to-B7 end-to-end loop.",
            "P1-CURRENT.json is never modified by this runner.",
        ],
    }
    # Validate any requested report destination before running tests or writing
    # the canonical Pack. Invalid report paths must not permit partial side effects.
    if args.report:
        try:
            _validated_report_target(ROOT, args.report)
        except ValidationBlocked as exc:
            report["reason_code"] = exc.code
            report["detail"] = exc.detail
            print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
            return 2

    try:
        try:
            batch_gate = validate_final_test_gate(ROOT)
        except BatchGateError as exc:
            report["status"] = "BLOCKED"
            report["reason_code"] = "FEATURE_BATCH_CLOSURE_GATE_REQUIRED"
            report["detail"] = exc.detail or exc.code
            report["feature_batch_gate"] = {
                "required": True,
                "status": "BLOCKED",
                "reason_code": exc.code,
                "detail": exc.detail,
            }
            print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
            return 2
        batch_required = batch_gate.get("required") is True
        if batch_required:
            report["expected_test_method_count"] = batch_gate["expected_test_method_count"]
            report["feature_batch_gate"] = {
                "required": True,
                "status": "READY_FOR_FINAL_TEST",
                "batch_id": batch_gate["batch_id"],
                "batch_phase": batch_gate["batch_phase"],
                "manifest_ref": batch_gate["manifest_ref"],
                "manifest_fingerprint": batch_gate["manifest_fingerprint"],
                "scope_fingerprint": batch_gate["scope_fingerprint"],
                "feature_count": batch_gate["feature_count"],
                "expected_test_method_count": batch_gate["expected_test_method_count"],
                "test_roster": batch_gate["test_roster"],
            }
            expected_counts = {item["test_ref"]: item["expected_method_count"] for item in batch_gate["test_roster"]}
            test_files = tuple(expected_counts)
            if not test_files or sum(expected_counts.values()) != batch_gate["expected_test_method_count"]:
                raise ValidationBlocked("FEATURE_BATCH_TEST_ROSTER_INVALID")
        else:
            expected_counts = EXPECTED_TEST_COUNTS
            test_files = TEST_FILES
        if sys.version_info[:2] != (3, 11):
            raise ValidationBlocked("VALIDATION_PYTHON_VERSION_MISMATCH", f"expected 3.11.x, got {sys.version.split()[0]}")
        try:
            head = subprocess.run(
                ["git", "rev-parse", "HEAD"], cwd=ROOT, capture_output=True,
                text=True, timeout=5, check=False,
            )
            if head.returncode == 0:
                report["repository_commit"] = head.stdout.strip() or None
        except (OSError, subprocess.SubprocessError):
            pass
        # Check dependency availability/version before preflight imports jsonschema.
        # Missing packages must be reported as dependency blockers, not packet/schema defects.
        report["pinned_dependencies"] = check_pinned_dependencies(ROOT)
        if report["pinned_dependencies"]["status"] != "MATCH":
            package_summary = ", ".join(
                f"{item['name']} expected={item['expected_version']} actual={item['actual_version']}"
                for item in report["pinned_dependencies"].get("packages", []) if not item.get("matches")
            )
            raise ValidationBlocked("PINNED_DEPENDENCY_MISMATCH", package_summary or report["pinned_dependencies"].get("detail", ""))

        # A report used to unlock the final acceptance gate must describe a clean
        # committed source tree. Simulation remains usable in isolated non-Git tests.
        if args.mode == "integration" and args.report:
            try:
                git_status = subprocess.run(
                    ["git", "status", "--porcelain", "--untracked-files=all"],
                    cwd=ROOT,
                    capture_output=True,
                    text=True,
                    timeout=5,
                    check=False,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                raise ValidationBlocked("VALIDATION_GIT_WORKTREE_UNAVAILABLE", str(exc)) from exc
            if git_status.returncode != 0:
                raise ValidationBlocked(
                    "VALIDATION_GIT_WORKTREE_UNAVAILABLE",
                    git_status.stderr.strip() or f"git status exit={git_status.returncode}",
                )
            dirty_paths = git_status.stdout.strip()
            report["repository_worktree_clean_at_start"] = not bool(dirty_paths)
            if dirty_paths:
                raise ValidationBlocked(
                    "VALIDATION_WORKTREE_NOT_CLEAN",
                    dirty_paths[:2000],
                )

        report["preflight"] = preflight(ROOT)

        for test_ref in test_files:
            test_path = path_ref(ROOT, test_ref)
            if not test_path.is_file():
                raise ValidationBlocked("VALIDATION_TEST_FILE_MISSING", test_ref)
            step = run_step(ROOT, test_ref, [sys.executable, test_ref], args.timeout)
            expected_count = expected_counts[test_ref]
            actual_count = test_count_from_output(step)
            step["expected_test_count"] = expected_count
            step["actual_test_count"] = actual_count
            if step["status"] == "PASS" and actual_count != expected_count:
                step["status"] = "TEST_COUNT_MISMATCH"
            report["steps"].append(step)
            if step["actual_test_count"] is not None:
                report["actual_test_method_count"] += step["actual_test_count"]

        failed_tests = [s for s in report["steps"] if s["status"] != "PASS"]
        if failed_tests:
            missing_module = any("No module named" in s["stderr_tail"] for s in failed_tests)
            report["status"] = "BLOCKED_DEPENDENCY" if missing_module else "SIMULATION_FAIL"
            report["failed_test_suites"] = [s["name"] for s in failed_tests]
        else:
            check = run_step(
                ROOT, "operational-pack-check-only",
                [sys.executable, PACK_CLI, "build", "--request", REQUEST_REF, "--check-only"],
                args.timeout,
            )
            report["steps"].append(check)
            if check["status"] != "PASS":
                report["status"] = "SIMULATION_FAIL"
                report["failed_step"] = check["name"]
            else:
                check_result = parse_json_result(check, expected_status="READY")
                report["check_only_result"] = check_result
                if check_result.get("write_performed") is not False:
                    raise ValidationBlocked("VALIDATION_CHECK_ONLY_SIDE_EFFECT_DECLARED", check["name"])
                if args.mode == "simulation":
                    report["status"] = "SIMULATION_PASS"
                else:
                    canonical_dir = path_ref(ROOT, "P1-Central-Control/canonical")
                    if not canonical_dir.is_dir():
                        raise ValidationBlocked("VALIDATION_CANONICAL_DIRECTORY_MISSING")
                    with tempfile.TemporaryDirectory(prefix=".p2-validation-", dir=canonical_dir) as temp_dir:
                        temp_pack_ref = (Path(temp_dir) / "operational_reference_pack.json").relative_to(ROOT).as_posix()
                        temp_build = run_step(
                            ROOT, "operational-pack-build-temporary",
                            [sys.executable, PACK_CLI, "build", "--request", REQUEST_REF, "--output", temp_pack_ref],
                            args.timeout,
                        )
                        report["steps"].append(temp_build)
                        if temp_build["status"] != "PASS":
                            report["status"] = "INTEGRATION_FAIL"
                            report["failed_step"] = temp_build["name"]
                        else:
                            report["temporary_build_result"] = parse_json_result(temp_build, expected_status="WRITTEN")
                            temp_verify = run_step(
                                ROOT, "operational-pack-verify-temporary",
                                [sys.executable, PACK_CLI, "verify", "--pack", temp_pack_ref],
                                args.timeout,
                            )
                            report["steps"].append(temp_verify)
                            if temp_verify["status"] != "PASS":
                                report["status"] = "INTEGRATION_FAIL"
                                report["failed_step"] = temp_verify["name"]
                            else:
                                report["temporary_verify_result"] = parse_json_result(temp_verify, expected_status="VERIFIED")
                                temp_repeat = run_step(
                                    ROOT, "operational-pack-idempotency-temporary",
                                    [sys.executable, PACK_CLI, "build", "--request", REQUEST_REF, "--output", temp_pack_ref],
                                    args.timeout,
                                )
                                report["steps"].append(temp_repeat)
                                if temp_repeat["status"] != "PASS":
                                    report["status"] = "INTEGRATION_FAIL"
                                    report["failed_step"] = temp_repeat["name"]
                                else:
                                    report["temporary_idempotency_result"] = parse_json_result(temp_repeat, expected_status="UNCHANGED")
                                    if report["temporary_idempotency_result"].get("status") != "UNCHANGED":
                                        report["status"] = "INTEGRATION_FAIL"
                                        report["failed_step"] = temp_repeat["name"]
                    # Promote to the single canonical output only after isolated build,
                    # verify and idempotency all succeed. The Current authority is never changed.
                    if report.get("status") != "INTEGRATION_FAIL":
                        mark_canonical_write_started(report)
                        final_build = run_step(
                            ROOT, "operational-pack-promote-canonical",
                            [sys.executable, PACK_CLI, "build", "--request", REQUEST_REF, "--output", PACK_REF],
                            args.timeout,
                        )
                        report["steps"].append(final_build)
                        if final_build["status"] != "PASS":
                            report["status"] = "INTEGRATION_FAIL"
                            report["failed_step"] = final_build["name"]
                        else:
                            report["canonical_build_result"] = parse_json_result(final_build, expected_status=("WRITTEN", "UNCHANGED"))
                            record_canonical_write_result(report, report["canonical_build_result"])
                            final_verify = run_step(
                                ROOT, "operational-pack-verify-canonical",
                                [sys.executable, PACK_CLI, "verify", "--pack", PACK_REF],
                                args.timeout,
                            )
                            report["steps"].append(final_verify)
                            if final_verify["status"] != "PASS":
                                report["status"] = "INTEGRATION_FAIL"
                                report["failed_step"] = final_verify["name"]
                            else:
                                report["canonical_verify_result"] = parse_json_result(final_verify, expected_status="VERIFIED")
                                final_repeat = run_step(
                                    ROOT, "operational-pack-idempotency-canonical",
                                    [sys.executable, PACK_CLI, "build", "--request", REQUEST_REF, "--output", PACK_REF],
                                    args.timeout,
                                )
                                report["steps"].append(final_repeat)
                                if final_repeat["status"] != "PASS":
                                    report["status"] = "INTEGRATION_FAIL"
                                    report["failed_step"] = final_repeat["name"]
                                else:
                                    report["canonical_idempotency_result"] = parse_json_result(final_repeat, expected_status="UNCHANGED")
                                    if report["canonical_idempotency_result"].get("status") != "UNCHANGED":
                                        report["status"] = "INTEGRATION_FAIL"
                                        report["failed_step"] = final_repeat["name"]
                                    else:
                                        report["status"] = "PACK_INTEGRATION_PASS"
                                        report["end_to_end_caller_wired"] = False
                                        canonical_path = ROOT / PACK_REF
                                        if canonical_path.is_symlink() or not canonical_path.is_file():
                                            raise ValidationBlocked(
                                                "VALIDATION_CANONICAL_PACK_HASH_SOURCE_INVALID",
                                                PACK_REF,
                                            )
                                        report["canonical_pack_sha256"] = (
                                            "sha256:" + hashlib.sha256(canonical_path.read_bytes()).hexdigest()
                                        )
    except ValidationBlocked as exc:
        report_status, failed_step = classify_validation_block(exc)
        report["status"] = report_status
        if failed_step:
            report["failed_step"] = failed_step
            mark_failed_result_step(report, failed_step, exc, report_status)
        report["reason_code"] = exc.code
        report["detail"] = exc.detail
    except Exception as exc:
        report["status"] = "FAIL_UNCLASSIFIED"
        report["detail"] = f"{type(exc).__name__}: {exc}"

    if args.report:
        try:
            write_report(ROOT, args.report, report)
        except (ValidationBlocked, OSError) as exc:
            # Do not emit a PASS report when the requested evidence report
            # could not be persisted. Preserve the validation result separately.
            report["validation_status_before_report_write"] = report.get("status")
            report["validation_reason_code_before_report_write"] = report.get("reason_code")
            report["validation_detail_before_report_write"] = report.get("detail")
            report["status"] = "REPORT_WRITE_FAIL"
            if isinstance(exc, ValidationBlocked):
                report["reason_code"] = exc.code
                report["detail"] = exc.detail
            else:
                report["reason_code"] = "VALIDATION_REPORT_WRITE_FAILED"
                report["detail"] = f"{type(exc).__name__}: {exc}"
            report["report_write_status"] = "FAILED"
            print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
            return 3
    print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
    return 0 if report["status"] in {"SIMULATION_PASS", "PACK_INTEGRATION_PASS"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
