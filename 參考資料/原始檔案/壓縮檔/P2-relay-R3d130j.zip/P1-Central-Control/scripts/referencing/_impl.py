"""Minimal local stand-in for `referencing` (sandbox has no network). NOT the real package."""
class Resource:
    def __init__(self, contents): self.contents = contents
    @classmethod
    def from_contents(cls, contents, default_specification=None): return cls(contents)
class Registry:
    def __init__(self, resources=None): self._r = dict(resources or {})
    def with_resource(self, uri, resource):
        r = dict(self._r); r[uri] = resource; return Registry(r)
    def with_resources(self, pairs):
        r = dict(self._r)
        for u, res in pairs: r[u] = res
        return Registry(r)
    def __or__(self, other):
        r = dict(self._r); r.update(other._r); return Registry(r)
