"""In-repo stdlib fallback for `referencing`. The real package wins when installed.

Reduced coverage (only the keywords the P1 schemas use); `FALLBACK = True` marks it so an
acceptance record can say which validator ran.
"""
import importlib.machinery
import importlib.util
import os
import sys

_HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_others = [p for p in sys.path if os.path.abspath(p or os.getcwd()) != _HERE]
_spec = importlib.machinery.PathFinder.find_spec("referencing", _others)
if _spec is not None and _spec.loader is not None:
    _real = importlib.util.module_from_spec(_spec)
    sys.modules["referencing"] = _real
    _spec.loader.exec_module(_real)
else:
    from . import _impl as _i

    globals().update({k: v for k, v in vars(_i).items() if not k.startswith("__")})
    FALLBACK = True
