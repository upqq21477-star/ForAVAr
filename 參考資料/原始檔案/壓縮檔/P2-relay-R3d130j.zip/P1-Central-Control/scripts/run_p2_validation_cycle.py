#!/usr/bin/env python3
"""Run P2 Simulation and, only on an observed pass, Integration.

This is a convenience orchestrator for the saved VS Code task. The authoritative
validation logic and phase contracts remain in run_p2_validation.py.
"""
from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[2]
RUNNER = ROOT / "P1-Central-Control" / "scripts" / "run_p2_validation.py"


FINAL_INTEGRATION_REPORT = "P1-Central-Control/acceptance/reports/P2-B2.2-final-integration.json"
B1_B8_BATCH_ID = "P2-B1-B8-CODE-FIRST"

def selected_final_integration_report(root: Path = ROOT) -> str:
    """Select a report filename from the Current-bound active batch, without discovery."""
    current_path = root / "P1-CURRENT.json"
    if current_path.is_symlink() or not current_path.is_file():
        raise RuntimeError("CURRENT_PATH_INVALID_FOR_FINAL_REPORT")
    try:
        current = json.loads(current_path.read_text(encoding="utf-8"))
        implementation = current.get("implementation_control", {})
        work_ref = implementation.get("active_work_packet")
        if not isinstance(work_ref, str) or not work_ref or Path(work_ref).is_absolute() or ".." in Path(work_ref).parts:
            raise RuntimeError("ACTIVE_WORK_REF_INVALID_FOR_FINAL_REPORT")
        work_path = root / work_ref
        if work_path.is_symlink() or not work_path.is_file() or not work_path.resolve().is_relative_to(root.resolve()):
            raise RuntimeError("ACTIVE_WORK_PATH_INVALID_FOR_FINAL_REPORT")
        work = json.loads(work_path.read_text(encoding="utf-8"))
        contract = work.get("operational_contract", {})
        batch_id = contract.get("feature_batch_id")
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise RuntimeError("ACTIVE_BATCH_UNAVAILABLE_FOR_FINAL_REPORT") from exc
    if batch_id == B1_B8_BATCH_ID:
        return "P1-Central-Control/acceptance/reports/P2-B1-B8-final-integration.json"
    return FINAL_INTEGRATION_REPORT

def _validate_report_count(report: dict[str, Any], phase: str) -> tuple[bool, str]:
    expected = report.get("expected_test_method_count")
    actual = report.get("actual_test_method_count")
    if type(expected) is not int or expected < 1 or actual != expected:
        return False, f"{phase}_TEST_COUNT_MISMATCH"
    gate = report.get("feature_batch_gate")
    if isinstance(gate, dict) and gate.get("required") is True:
        if (gate.get("status") != "READY_FOR_FINAL_TEST" or gate.get("batch_phase") != "FINAL_TEST"
                or gate.get("expected_test_method_count") != expected or not gate.get("manifest_fingerprint")
                or not isinstance(gate.get("scope_fingerprint"), str) or re.fullmatch(r"sha256:[0-9a-f]{64}", gate.get("scope_fingerprint")) is None):
            return False, f"{phase}_FEATURE_BATCH_GATE_INVALID"
    elif expected != 102:
        return False, f"{phase}_LEGACY_TEST_COUNT_MISMATCH"
    return True, ""


def run_phase(mode: str) -> tuple[int, dict[str, Any] | None]:
    print(f"\n===== P2 VALIDATION: {mode.upper()} =====", flush=True)
    command = [sys.executable, str(RUNNER), "--mode", mode]
    # Persist the authoritative Integration report so Central can bind its final
    # acceptance gate to the exact checked-out HEAD and machine-readable evidence.
    if mode == "integration":
        # The Runner validates every path component before creating the report
        # directory; do not mkdir here, where an ancestor symlink could redirect it.
        command.extend(["--report", selected_final_integration_report(ROOT)])
    try:
        result = subprocess.run(
            command,
            cwd=ROOT,
            text=True,
            capture_output=True,
            check=False,
        )
    except OSError as exc:
        print(f"LAUNCH_ERROR={type(exc).__name__}: {exc}", flush=True)
        return 2, None

    if result.stdout:
        print(result.stdout, end="" if result.stdout.endswith("\n") else "\n", flush=True)
    if result.stderr:
        print("VALIDATION_STDERR_BEGIN", flush=True)
        print(result.stderr, end="" if result.stderr.endswith("\n") else "\n", flush=True)
        print("VALIDATION_STDERR_END", flush=True)

    try:
        report = json.loads(result.stdout)
    except (json.JSONDecodeError, TypeError) as exc:
        print(f"REPORT_PARSE_ERROR={type(exc).__name__}: {exc}", flush=True)
        print(f"PROCESS_EXIT_CODE={result.returncode}", flush=True)
        return result.returncode or 2, None

    if not isinstance(report, dict):
        print("REPORT_PARSE_ERROR=JSON report is not an object", flush=True)
        return result.returncode or 2, None

    status = report.get("status")
    print(
        f"P2_PHASE_SUMMARY mode={mode} status={status!r} "
        f"process_exit_code={result.returncode}",
        flush=True,
    )
    return result.returncode, report


def seal_cycle_gate_evidence(
    simulation: dict[str, Any],
    integration: dict[str, Any],
    *,
    simulation_exit_code: int,
    integration_exit_code: int,
) -> tuple[bool, str]:
    """Persist observed exit codes and the outer Simulation→Integration gate."""
    if simulation_exit_code != 0 or integration_exit_code != 0:
        return False, "FINAL_CYCLE_EXIT_CODE_NOT_ZERO"
    report_ref = selected_final_integration_report(ROOT)
    candidate = Path(report_ref)
    root = ROOT.resolve()
    report_path = root / candidate
    cursor = root
    for part in candidate.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            return False, "FINAL_INTEGRATION_REPORT_PATH_SYMLINK"
    if candidate.is_absolute() or ".." in candidate.parts or not report_path.is_file():
        return False, "FINAL_INTEGRATION_REPORT_MISSING_OR_FORBIDDEN"
    try:
        if not report_path.resolve().is_relative_to(root):
            return False, "FINAL_INTEGRATION_REPORT_PATH_FORBIDDEN"
        report = json.loads(report_path.read_text(encoding="utf-8"))
        if not isinstance(report, dict):
            return False, "FINAL_INTEGRATION_REPORT_NOT_OBJECT"
        head = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if head.returncode != 0 or head.stdout.strip() != integration.get("repository_commit"):
            return False, "FINAL_INTEGRATION_HEAD_CHANGED_BEFORE_SEAL"
        status = subprocess.run(
            ["git", "status", "--porcelain", "--untracked-files=all"],
            cwd=root,
            capture_output=True,
            text=True,
            timeout=5,
            check=False,
        )
        if status.returncode != 0 or status.stdout.strip():
            return False, "FINAL_INTEGRATION_WORKTREE_CHANGED_AFTER_RUN"
        simulation_count_ok, simulation_count_error = _validate_report_count(simulation, "SIMULATION")
        integration_count_ok, integration_count_error = _validate_report_count(integration, "INTEGRATION")
        simulation_batch_gate = simulation.get("feature_batch_gate")
        integration_batch_gate = integration.get("feature_batch_gate")
        if (
            report.get("status") != "PACK_INTEGRATION_PASS"
            or report.get("repository_commit") != integration.get("repository_commit")
            or not simulation_count_ok
            or not integration_count_ok
            or not simulation_batch_gate == integration_batch_gate
            or simulation.get("repository_commit") != integration.get("repository_commit")
        ):
            return False, "FINAL_SIMULATION_INTEGRATION_BINDING_MISMATCH:" + ";".join([simulation_count_error, integration_count_error])
        report["cycle_gate_evidence"] = {
            "status": "P2_PACK_CYCLE_PASS",
            "simulation_status": simulation["status"],
            "simulation_exit_code": simulation_exit_code,
            "simulation_repository_commit": simulation["repository_commit"],
            "simulation_expected_test_method_count": simulation["expected_test_method_count"],
            "simulation_actual_test_method_count": simulation["actual_test_method_count"],
            "integration_expected_test_method_count": integration["expected_test_method_count"],
            "integration_actual_test_method_count": integration["actual_test_method_count"],
            "integration_status": integration["status"],
            "integration_exit_code": integration_exit_code,
            "integration_repository_commit": integration["repository_commit"],
            "feature_batch_gate": simulation.get("feature_batch_gate"),
            "same_head": True,
            "final_worktree_clean": True,
        }
        payload = (json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")
        temporary_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                mode="wb",
                dir=report_path.parent,
                prefix=f".{report_path.name}.",
                suffix=".tmp",
                delete=False,
            ) as stream:
                stream.write(payload)
                stream.flush()
                os.fsync(stream.fileno())
                temporary_path = Path(stream.name)
            os.replace(temporary_path, report_path)
        finally:
            if temporary_path is not None and temporary_path.exists():
                temporary_path.unlink()
        return True, "CYCLE_GATE_EVIDENCE_SEALED"
    except (OSError, ValueError, json.JSONDecodeError, subprocess.SubprocessError) as exc:
        return False, f"CYCLE_GATE_EVIDENCE_SEAL_FAILED:{type(exc).__name__}:{exc}"


def main() -> int:
    if not RUNNER.is_file():
        print(f"STOP: validation runner missing: {RUNNER}", flush=True)
        return 2

    print(f"REPOSITORY_ROOT={ROOT}", flush=True)
    print(f"PYTHON={sys.version.split()[0]} ({sys.executable})", flush=True)
    simulation_rc, simulation = run_phase("simulation")

    if simulation_rc != 0 or not simulation or simulation.get("status") != "SIMULATION_PASS":
        observed = simulation.get("status") if simulation else "NO_VALID_REPORT"
        print(
            f"INTEGRATION_SKIPPED: Simulation did not produce an actual "
            f"SIMULATION_PASS (observed={observed!r}, exit={simulation_rc}).",
            flush=True,
        )
        return simulation_rc if simulation_rc != 0 else 2
    simulation_count_ok, simulation_count_error = _validate_report_count(simulation, "SIMULATION")
    if not simulation_count_ok or not simulation.get("repository_commit"):
        print(
            f"INTEGRATION_SKIPPED: Simulation report lacks exact roster-bound test evidence ({simulation_count_error}) "
            "or a bound repository commit.",
            flush=True,
        )
        return 2

    print(
        "GATE_PASS: observed SIMULATION_PASS; proceeding to Integration.",
        flush=True,
    )
    integration_rc, integration = run_phase("integration")
    integration_count_ok, integration_count_error = (
        _validate_report_count(integration, "INTEGRATION") if integration else (False, "INTEGRATION_REPORT_MISSING")
    )
    if (
        integration_rc != 0
        or not integration
        or integration.get("status") != "PACK_INTEGRATION_PASS"
        or not integration_count_ok
        or integration.get("feature_batch_gate") != simulation.get("feature_batch_gate")
        or integration.get("repository_commit") != simulation.get("repository_commit")
        or integration.get("repository_worktree_clean_at_start") is not True
    ):
        observed = integration.get("status") if integration else "NO_VALID_REPORT"
        print(
            f"CYCLE_NOT_PASSED: Integration did not produce a report-bound PACK_INTEGRATION_PASS "
            f"with exact roster-bound counts ({integration_count_error}), the same HEAD as Simulation, and a clean start "
            f"(observed={observed!r}, exit={integration_rc}).",
            flush=True,
        )
        return integration_rc if integration_rc != 0 else 2

    sealed, seal_detail = seal_cycle_gate_evidence(
        simulation,
        integration,
        simulation_exit_code=simulation_rc,
        integration_exit_code=integration_rc,
    )
    if not sealed:
        print(f"CYCLE_REPORT_SEAL_FAILED: {seal_detail}", flush=True)
        return 3

    print(
        "P2_PACK_CYCLE_PASS: Simulation and Pack Integration passed at the same HEAD, "
        f"with {simulation['actual_test_method_count']}/{simulation['expected_test_method_count']} methods, a clean Integration start, and persisted cycle-gate evidence. "
        "This does not prove the full B1-to-B7 end-to-end loop.",
        flush=True,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
