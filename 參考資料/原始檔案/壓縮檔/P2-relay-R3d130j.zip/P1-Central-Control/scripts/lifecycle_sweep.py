#!/usr/bin/env python3
"""Single lifecycle engine (policy/lifecycle.v1.0.json).

U-RETIRE: reachability from declared entry roots -> retire candidates (a/b/c) with evidence.
U-ISSUE : issue register records with TTL / count arithmetic (judgment stays with CONTROL_RESEARCH).
Deterministic only: it never decides semantics, it only refuses records without a rationale.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import tempfile
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parent))
from repository_hygiene_gate import BUDGET_PATH, measure, tracked_files  # noqa: E402

CTRL = "P1-Central-Control/"
POLICY_PATH = CTRL + "policy/lifecycle.v1.0.json"
TEXT_SUFFIXES = {".py", ".json", ".md", ".yml", ".yaml", ".txt", ".toml", ".cfg", ".sarif", ".jsonl"}
QUARANTINE_REL = CTRL + "archive/quarantine/"
TOKEN_RE = re.compile(r"[\w.\-/]+", re.UNICODE)


def _load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def load_policy(root: Path) -> dict[str, Any]:
    return _load(root / POLICY_PATH)


def _files(root: Path) -> list[str]:
    return [f for f in tracked_files(root) if "__pycache__" not in f and not f.endswith(".pyc") and not f.startswith(QUARANTINE_REL)]


def _text(root: Path, rel: str) -> str:
    p = root / rel
    if p.suffix.lower() not in TEXT_SUFFIXES and p.name not in {"CODEOWNERS", ".gitignore"}:
        return ""
    try:
        return p.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""


def _is_doc(rel: str) -> bool:
    return rel.endswith(".md") or rel.startswith("docs/")


def _is_test(rel: str) -> bool:
    return rel.startswith(CTRL + "tests/")


def _is_test_module(rel: str) -> bool:
    return _is_test(rel) and Path(rel).name.startswith("test_") and rel.endswith(".py")


def _needles(rel: str) -> set[str]:
    p = Path(rel)
    out = {rel, p.name}
    if rel.startswith(CTRL):
        out.add(rel[len(CTRL):])
    if p.suffix in {".py", ".json", ".yml", ".md"} and len(p.stem) >= 4:
        out.add(p.stem)
    return out


def _tokens(text: str) -> set[str]:
    toks: set[str] = set()
    for t in TOKEN_RE.findall(text):
        t = t.strip(".-/")
        if not t:
            continue
        parts = t.split("/")
        for i in range(len(parts)):
            toks.add("/".join(parts[i:]))
        last = parts[-1]
        toks.add(last)
        if "." in last:
            toks.add(last.rsplit(".", 1)[0])
        for sub in re.split(r"[.\-]", last):
            if len(sub) >= 4:
                toks.add(sub)
    return toks


def build_graph(root: Path, files: list[str]) -> dict[str, set[str]]:
    index: dict[str, set[str]] = {}
    for rel in files:
        for n in _needles(rel):
            index.setdefault(n, set()).add(rel)
    graph: dict[str, set[str]] = {}
    for rel in files:
        if _is_test(rel):
            continue  # tests are never a source of edges (self-test is not an entry)
        text = _text(root, rel)
        if not text:
            continue
        doc = _is_doc(rel)
        out: set[str] = set()
        for tok in _tokens(text):
            for tgt in index.get(tok, ()):
                if tgt != rel and (not doc or _is_doc(tgt)):
                    out.add(tgt)
        graph[rel] = out
    return graph


def _is_protected(rel: str, policy: dict[str, Any]) -> bool:
    pr = policy["protected"]
    return rel in pr["files"] or any(rel.startswith(p) for p in pr["prefixes"])


def entry_roots(files: list[str], policy: dict[str, Any]) -> set[str]:
    r = policy["roots"]
    roots = {f for f in files if f in r["files"] or any(f.startswith(p) for p in r["prefixes"])}
    roots |= {e["path"] for e in policy.get("declared_entries", []) if e["path"] in files}
    return roots


def reachable(graph: dict[str, set[str]], roots: set[str]) -> set[str]:
    seen, stack = set(roots), list(roots)
    while stack:
        for nxt in graph.get(stack.pop(), ()):
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return seen


def expired_declared(policy: dict[str, Any], today: date) -> list[str]:
    return [e["path"] for e in policy.get("declared_entries", [])
            if date.fromisoformat(e["review_after"]) < today]


def find_candidates(root: Path, today: date | None = None) -> dict[str, Any]:
    """Return {'candidates': [{path, category, evidence}], 'test_owned': [...], 'roots': n}."""
    policy = load_policy(root)
    files = _files(root)
    graph = build_graph(root, files)
    roots = entry_roots(files, policy)
    reach = reachable(graph, roots)
    fileset = set(files)
    cands: dict[str, dict[str, str]] = {}

    def add(path: str, cat: str, ev: str) -> None:
        if path not in cands and not _is_protected(path, policy):
            cands[path] = {"path": path, "category": cat, "evidence": ev}

    for rel in files:
        if rel in reach or _is_test(rel) or _is_protected(rel, policy):
            continue
        add(rel, "a", "UNREACHABLE_FROM_ENTRY_ROOTS")

    scripts = {Path(f).stem: f for f in files if f.startswith(CTRL + "scripts/") and f.endswith(".py")}
    retired = {p for p, c in cands.items() if p in scripts.values()}
    tests = [f for f in files if _is_test(f) and f.endswith(".py")]
    test_tokens = {t: _tokens(_text(root, t)) for t in tests}

    def targets(t: str) -> set[str]:
        return {scripts[s] for s in scripts if s in test_tokens[t]}

    changed = True
    while changed:
        changed = False
        for t in tests:
            if t in cands or not _is_test_module(t):
                continue
            name = Path(t).stem[5:]
            direct = scripts.get(name)
            tg = {direct} if direct else targets(t)
            if tg and tg <= retired:
                add(t, "b", "TARGET_SCRIPT_RETIRED:" + ",".join(sorted(tg)))
                changed = True
        live_text = {t for t in tests if _is_test_module(t) and t not in cands}
        for t in tests:  # helper files without a live user
            if _is_test_module(t) or t in cands or Path(t).name == "__init__.py":
                continue
            stem = Path(t).stem
            if not any(stem in test_tokens[u] for u in live_text) and not any(
                    stem in _tokens(_text(root, f)) for f in files if f != t and not _is_test(f)):
                add(t, "b", "TEST_HELPER_WITHOUT_USER")
                changed = True
        for p in [p for p in retired]:
            pass

    live_tests = [t for t in tests if _is_test_module(t) and t not in cands]
    owned: set[str] = set()
    idx: dict[str, set[str]] = {}
    for rel in files:
        for n in _needles(rel):
            idx.setdefault(n, set()).add(rel)
    for t in live_tests:
        for tok in test_tokens[t]:
            for tgt in idx.get(tok, ()):
                if tgt in cands and cands[tgt]["category"] == "a" and tgt not in scripts.values():
                    owned.add(tgt)
    for p in owned:
        del cands[p]
    # records past their window (category c)
    for path in _expired_record_paths(root, policy, today or date.today()):
        if path in fileset:
            add(path, "c", "RECORD_EXPIRED")
    return {"candidates": sorted(cands.values(), key=lambda c: c["path"]),
            "test_owned": sorted(owned), "roots": len(roots), "reachable": len(reach),
            "files": len(files)}


def _expired_record_paths(root: Path, policy: dict[str, Any], today: date) -> list[str]:
    return []


def batches(candidates: list[dict[str, str]], limit: int) -> list[list[str]]:
    """Groups = mother script + its derived tests; each batch <= limit; groups never split."""
    paths = [c["path"] for c in candidates]
    groups: dict[str, list[str]] = {}
    for c in candidates:
        key = c["path"]
        if c["category"] == "b" and c["evidence"].startswith("TARGET_SCRIPT_RETIRED:"):
            key = c["evidence"].split(":", 1)[1].split(",")[0]
        groups.setdefault(key, []).append(c["path"])
    out: list[list[str]] = []
    cur: list[str] = []
    for key in sorted(groups):
        g = groups[key]
        if cur and len(cur) + len(g) > limit:
            out.append(cur)
            cur = []
        cur.extend(g)
    if cur:
        out.append(cur)
    assert sorted(p for b in out for p in b) == sorted(paths)
    return out


def _drop(node: Any, needles: set[str]) -> tuple[Any, int]:
    removed = 0
    if isinstance(node, list):
        kept = []
        for item in node:
            if _mentions(item, needles) and (isinstance(item, str) or isinstance(item, dict)):
                removed += 1
                continue
            sub, n = _drop(item, needles)
            removed += n
            kept.append(sub)
        return kept, removed
    if isinstance(node, dict):
        out = {}
        for k, v in node.items():
            sub, n = _drop(v, needles)
            removed += n
            out[k] = sub
        return out, removed
    return node, 0


def _mentions(node: Any, needles: set[str]) -> bool:
    if isinstance(node, str):
        return node in needles or any(node.endswith("/" + n) for n in needles)
    if isinstance(node, dict):
        return any(_mentions(v, needles) for v in node.values())
    return False


def strip_json_refs(root: Path, paths: list[str]) -> dict[str, list[str]]:
    """Remove list-entry references to `paths` from JSON files (JSON-aware, never sed).
    Returns {'changed': [...], 'unresolved': [file, ...]} (structural refs need a human/Task)."""
    needles = set()
    for p in paths:
        needles |= {p, p[len(CTRL):] if p.startswith(CTRL) else p}
    changed, unresolved = [], []
    for rel in _files(root):
        if not rel.endswith(".json") or rel in paths or _is_protected_ref_free(rel):
            continue
        f = root / rel
        try:
            data = _load(f)
        except (OSError, ValueError):
            continue
        new, n = _drop(data, needles)
        if n:
            f.write_text(json.dumps(new, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
            changed.append(rel)
        if _still_mentions(new if n else data, needles):
            unresolved.append(rel)
    return {"changed": changed, "unresolved": unresolved}


def _is_protected_ref_free(rel: str) -> bool:
    return rel.startswith("docs/handoffs/")


def _still_mentions(node: Any, needles: set[str]) -> bool:
    if isinstance(node, str):
        return node in needles or any(node.endswith("/" + n) for n in needles)
    if isinstance(node, list):
        return any(_still_mentions(v, needles) for v in node)
    if isinstance(node, dict):
        return any(_still_mentions(v, needles) for v in node.values())
    return False


def delete_batch(root: Path, paths: list[str]) -> dict[str, Any]:
    """Delete only freshly computed candidates; refuse protected / stale / oversize batches."""
    policy = load_policy(root)
    if len(paths) > policy["batch_max_files"]:
        raise ValueError("BATCH_TOO_LARGE")
    current = {c["path"] for c in find_candidates(root)["candidates"]}
    for p in paths:
        if _is_protected(p, policy):
            raise ValueError(f"PROTECTED:{p}")
        if p not in current:
            raise ValueError(f"NOT_A_CANDIDATE:{p}")
    needles = set()
    for p in paths:
        needles |= {p, p[len(CTRL):] if p.startswith(CTRL) else p}
    for rel in _files(root):
        if rel in paths or not rel.endswith(".json") or _is_protected_ref_free(rel):
            continue
        try:
            if _still_mentions(_load(root / rel), needles):
                raise ValueError(f"PENDING_REF:{rel}")
        except (OSError, ValueError) as exc:
            if str(exc).startswith("PENDING_REF"):
                raise
    failed: list[str] = []
    for p in paths:
        try:
            (root / p).unlink()
        except OSError:  # one file failing keeps that file and is recorded; it never stops the rest of the batch
            failed.append(p)
    for p in sorted({str((root / p).parent) for p in paths}, reverse=True):
        d = Path(p)
        while d != root and d.is_dir() and not any(d.iterdir()):
            d.rmdir()
            d = d.parent
    after = find_candidates(root)
    return {"deleted": len(paths) - len(failed), "failed": failed, "new_orphans": [c["path"] for c in after["candidates"]]}


def run_retirement(root: Path, limit: int | None = None) -> dict[str, Any]:
    """Fixpoint: candidates -> batches -> strip JSON refs -> delete -> rescan until none."""
    policy = load_policy(root)
    limit = limit or policy["batch_max_files"]
    deleted: list[str] = []
    unresolved: set[str] = set()
    while True:
        cands = find_candidates(root)["candidates"]
        pending = [c for c in cands if c["path"] not in unresolved]
        if not pending:
            break
        progressed = False
        for batch in batches(pending, limit):
            res = strip_json_refs(root, batch)
            try:
                res_del = delete_batch(root, batch)
            except ValueError as exc:
                unresolved.update(batch)
                unresolved.add(str(exc))
                continue
            failed = set(res_del.get("failed", []))
            unresolved.update(failed)  # partial: the kept file is reported, the rest of the batch is already gone
            deleted.extend(p for p in batch if p not in failed)
            progressed = True
        if not progressed:
            break
    return {"deleted": deleted, "blocked": sorted(unresolved)}


def ratchet(root: Path) -> dict[str, Any]:
    """Lower max/target toward measured values (never raise): target = measured rounded up,
    max = measured + headroom rounded up (policy.ratchet)."""
    cfg = load_policy(root)["ratchet"]
    unit, headroom = cfg["round_to"], cfg["headroom"]
    up = lambda n: -(-int(n) // unit) * unit  # noqa: E731
    f = root / BUDGET_PATH
    data = _load(f)
    sizes = measure(root, _files(root))
    for b in data["budgets"]:
        cur = sizes[b["path"]]
        b["target_bytes"] = min(b["target_bytes"], up(cur))
        b["max_bytes"] = min(b["max_bytes"], up(cur * (1 + headroom)))
    f.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return sizes


# ---------------------------------------------------------------- U-ISSUE records
def _today(today: date | None) -> date:
    return today or date.today()


def load_register(path: Path) -> dict[str, Any]:
    return _load(path)


def save_register(path: Path, register: dict[str, Any]) -> None:
    path.write_text(json.dumps(register, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def record_issue(register: dict[str, Any], signature: str, how: str, handling: str,
                 today: date | None = None, ttl_days: int = 14) -> dict[str, Any]:
    """New signature -> TRANSIENT; same signature -> count+1, last_seen updated, deadline extended."""
    now = _today(today)
    for e in register["entries"]:
        if e["signature"] == signature:
            e["count"] += 1
            e["last_seen"] = now.isoformat()
            if e["class"] == "TRANSIENT":
                e["expires_on"] = (now + timedelta(days=ttl_days)).isoformat()
            return e
    n = 1 + max([int(e["issue_id"][2:]) for e in register["entries"]
                 if e["issue_id"].startswith("T-")] or [0])
    entry = {"issue_id": f"T-{n:03d}", "signature": signature, "class": "TRANSIENT",
             "first_seen": now.isoformat(), "last_seen": now.isoformat(), "count": 1,
             "how": how, "handling": handling, "status": "OPEN",
             "expires_on": (now + timedelta(days=ttl_days)).isoformat()}
    register["entries"].append(entry)
    return entry


def classify_issue(register: dict[str, Any], issue_id: str, *, rationale: str, owner_layer: str,
                   prevention: str) -> dict[str, Any]:
    """Promote to MECHANISM; refuse without rationale / owner_layer / prevention."""
    layers = register["policy"]["owner_layer_values"]
    if not (rationale or "").strip() or not (prevention or "").strip():
        raise ValueError("MECHANISM_REQUIRES_RATIONALE_AND_PREVENTION")
    if owner_layer not in layers:
        raise ValueError("OWNER_LAYER_NOT_ALLOWED")
    for e in register["entries"]:
        if e["issue_id"] == issue_id:
            e.update({"class": "MECHANISM", "rationale": rationale, "owner_layer": owner_layer,
                      "prevention": prevention})
            e.pop("expires_on", None)
            return e
    raise ValueError("UNKNOWN_ISSUE")


def sweep_records(register: dict[str, Any], ledger: dict[str, Any], root: Path,
                  today: date | None = None, promote_count: int = 2) -> dict[str, list[str]]:
    now = _today(today)
    ledger_ids = {e["lesson_id"] for e in ledger["entries"]}
    out: dict[str, list[str]] = {"expired": [], "review_promotion": [], "invalid": [], "distillable": []}
    for e in register["entries"]:
        if e["class"] == "TRANSIENT":
            if date.fromisoformat(e["expires_on"]) < now:
                out["expired"].append(e["issue_id"])
            elif e["count"] >= promote_count:
                out["review_promotion"].append(e["issue_id"])
        else:
            if not all((e.get(k) or "").strip() for k in ("rationale", "owner_layer", "prevention")):
                out["invalid"].append(e["issue_id"])
            elif e["owner_layer"] not in register["policy"]["owner_layer_values"]:
                out["invalid"].append(e["issue_id"])
            if e.get("status") == "RESOLVED":
                test_ok = (root / e.get("regression_test", "")).is_file() if e.get("regression_test") else False
                if test_ok and e.get("ledger_ref") in ledger_ids:
                    out["distillable"].append(e["issue_id"])
                else:
                    out["invalid"].append(e["issue_id"])
    return out


def record_failure(root: Path, signature: str, how: str, handling: str,
                   today: date | None = None) -> dict[str, Any]:
    """Persist one failure signature (Runtime hook: gate stage FAIL, Role result with issue_signature)."""
    path = root / CTRL / "canonical/issue_register.json"
    register = load_register(path)
    ttl = load_policy(root)["records"]["transient_ttl_days"]
    entry = record_issue(register, signature, how, handling, today, ttl)
    save_register(path, register)
    return entry


def records_for_control_research(root: Path, today: date | None = None) -> dict[str, list[str]]:
    """Items a Work Unit close hands to CONTROL_RESEARCH (judgment stays with it); empty lists dropped."""
    register = load_register(root / CTRL / "canonical/issue_register.json")
    ledger = _load(root / CTRL / "canonical/update_learning_ledger.json")
    rep = sweep_records(register, ledger, root, today, load_policy(root)["records"]["promote_count"])
    return {k: v for k, v in rep.items() if v and k != "distillable"}


def execute_retire(root: Path, role_id: str, paths: list[str]) -> dict[str, Any]:
    """CAP-RETIRE execution: the role must be bound to it (runtime check), then delete_batch's own guards apply."""
    from task_set import assert_role_capability

    assert_role_capability(role_id, "CAP-RETIRE")
    return delete_batch(root, paths)


def apply_records(root: Path, today: date | None = None) -> dict[str, list[str]]:
    reg_path = root / CTRL / "canonical/issue_register.json"
    ledger = _load(root / CTRL / "canonical/update_learning_ledger.json")
    register = load_register(reg_path)
    rep = sweep_records(register, ledger, root, today)
    drop = set(rep["expired"]) | set(rep["distillable"])
    register["entries"] = [e for e in register["entries"] if e["issue_id"] not in drop]
    save_register(reg_path, register)
    return {"removed": sorted(drop)}


# ---------------------------------------------------------------- gate
def run_sweep(root: Path, today: date | None = None) -> dict[str, Any]:
    now = _today(today)
    policy = load_policy(root)
    found = find_candidates(root, now)
    register = load_register(root / CTRL / "canonical/issue_register.json")
    ledger = _load(root / CTRL / "canonical/update_learning_ledger.json")
    rec = sweep_records(register, ledger, root, now, policy["records"]["promote_count"])
    reasons = []
    for p in expired_declared(policy, now):
        reasons.append(f"DECLARED_ENTRY_EXPIRED:{p}")
    reasons += [f"RECORD_INVALID:{i}" for i in rec["invalid"]]
    reasons += [f"RECORD_EXPIRED:{i}" for i in rec["expired"]]
    return {"status": "BLOCK" if reasons else "PASS", "reason_codes": reasons,
            "candidates": found["candidates"], "test_owned": found["test_owned"],
            "records": {"entries": len(register["entries"]), **rec},
            "files": found["files"], "roots": found["roots"]}


# ---------------------------------------------------------------- R4R-S2: data classes, quarantine, ephemeral, budget
def classify_path(rel: str, policy: dict[str, Any]) -> dict[str, Any]:
    """Longest-prefix match over policy data_classes; no match -> UNCLASSIFIED (reported, never swept)."""
    best: tuple[int, str, str] | None = None
    for name, spec in policy.get("data_classes", {}).items():
        if name.startswith("_"):
            continue
        for pre in spec["paths"]:
            if (rel == pre or rel.startswith(pre)) and (best is None or len(pre) > best[0]):
                best = (len(pre), name, spec["disposition"])
    if best is None:
        return {"path": rel, "class": "UNCLASSIFIED", "disposition": None}
    return {"path": rel, "class": best[1], "disposition": best[2]}


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def batches_done_count(root: Path) -> int:
    p = root / (CTRL + "policy/batch_acceptance.v1.0.json")
    return sum(1 for b in _load(p).get("batches", []) if b.get("status") == "DONE") if p.exists() else 0


def _refs(root: Path, rel: str, exclude: set[str]) -> dict[str, list[str]]:
    """Who still mentions rel (path text, or a Python import of its stem), by evidence category."""
    needles = {rel, rel[len(CTRL):] if rel.startswith(CTRL) else rel}
    imp = re.compile(r"^\s*(?:import|from)\s+%s\b" % re.escape(Path(rel).stem), re.M) if rel.endswith(".py") else None
    out: dict[str, list[str]] = {"ENTRY": [], "REGISTRY": [], "WORKFLOW": [], "REGRESSION": []}
    for f in _files(root):
        if f in exclude or Path(f).suffix not in TEXT_SUFFIXES:
            continue
        try:
            txt = _text(root, f)
        except OSError:
            continue
        if not (any(n in txt for n in needles) or (imp is not None and f.endswith(".py") and imp.search(txt))):
            continue
        if f.startswith(".github/"):
            out["WORKFLOW"].append(f)
        elif _is_test(f):
            out["REGRESSION"].append(f)
        elif f.endswith(".json"):
            out["REGISTRY"].append(f)
        else:
            out["ENTRY"].append(f)
    return out


def removal_evidence(root: Path, rels: list[str], exclude: set[str] | None = None) -> list[str]:
    """Empty list = evidence complete (no entry, registry, workflow or regression reference remains)."""
    ex = set(rels) | set(exclude or ())
    return [f"{cat}:{rel}<-{f}" for rel in rels for cat, fs in _refs(root, rel, ex).items() for f in fs]


def _qroot(root: Path) -> Path:
    return root / load_policy(root)["quarantine"]["dir"]


def _runs(root: Path) -> list[Path]:
    q = _qroot(root)
    return sorted(d for d in q.iterdir() if d.is_dir()) if q.is_dir() else []


def _save_manifest(d: Path, m: dict[str, Any]) -> None:
    (d / "manifest.json").write_text(json.dumps(m, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def _prune_empty(root: Path, rels: list[str]) -> None:
    for p in sorted({str((root / r).parent) for r in rels}, reverse=True):
        d = Path(p)
        while d != root and d.is_dir() and not any(d.iterdir()):
            d.rmdir()
            d = d.parent


def quarantine_batch(root: Path, paths: list[str], run_id: str | None = None, batches_done: int | None = None) -> dict[str, Any]:
    """QUARANTINED: move fresh candidates (evidence complete) to quarantine/<run-id>/files/<path> with a sha256 manifest."""
    policy = load_policy(root)
    if not paths:
        raise ValueError("EMPTY_BATCH")
    if len(paths) > policy["batch_max_files"]:
        raise ValueError("BATCH_TOO_LARGE")
    current = {c["path"] for c in find_candidates(root)["candidates"]}
    for p in paths:
        if _is_protected(p, policy):
            raise ValueError(f"PROTECTED:{p}")
        if p not in current:
            raise ValueError(f"NOT_A_CANDIDATE:{p}")
    missing = removal_evidence(root, paths)
    if missing:
        raise ValueError("EVIDENCE_INCOMPLETE:" + ";".join(missing[:5]))
    q = policy["quarantine"]
    run_id = run_id or f"Q{len(_runs(root)) + 1:04d}"
    rd = _qroot(root) / run_id
    if rd.exists():
        raise ValueError(f"RUN_EXISTS:{run_id}")
    files = [{"path": p, "sha256": _sha(root / p), "size": (root / p).stat().st_size} for p in sorted(paths)]
    for f in files:
        dst = rd / "files" / f["path"]
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(root / f["path"]), str(dst))
    _prune_empty(root, paths)
    m = {"run_id": run_id, "state": "QUARANTINED", "unit": q["unit"], "observation_batches": q["observation_batches"],
         "batches_done_at": batches_done_count(root) if batches_done is None else batches_done, "files": files,
         "restore": f"python3 P1-Central-Control/scripts/lifecycle_sweep.py --restore {run_id}"}
    _save_manifest(rd, m)
    return m


def restore_batch(root: Path, run_id: str) -> dict[str, Any]:
    """Put files back byte-identical; verify every hash and refuse any overwrite before moving anything."""
    rd = _qroot(root) / run_id
    if not (rd / "manifest.json").is_file():
        raise ValueError(f"UNKNOWN_RUN:{run_id}")
    m = _load(rd / "manifest.json")
    if m["state"] == "REMOVED":
        raise ValueError(f"ALREADY_REMOVED:{run_id}")
    for f in m["files"]:
        src = rd / "files" / f["path"]
        if not src.is_file():
            raise ValueError(f"MISSING_IN_QUARANTINE:{f['path']}")
        if _sha(src) != f["sha256"]:
            raise ValueError(f"HASH_MISMATCH:{f['path']}")
        if (root / f["path"]).exists():
            raise ValueError(f"RESTORE_CONFLICT:{f['path']}")
    for f in m["files"]:
        (root / f["path"]).parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(rd / "files" / f["path"]), str(root / f["path"]))
    shutil.rmtree(rd)
    return {"restored": len(m["files"]), "run_id": run_id}


def advance_quarantine(root: Path, batches_done: int | None = None) -> list[dict[str, Any]]:
    """One step per run per call: QUARANTINED -(observed, re-check clear)-> VERIFIED_UNUSED -(re-check clear)-> REMOVED."""
    done = batches_done_count(root) if batches_done is None else batches_done
    out: list[dict[str, Any]] = []
    for d in _runs(root):
        m = _load(d / "manifest.json")
        st = m["state"]
        if st == "REMOVED":
            continue
        rels = [f["path"] for f in m["files"]]
        remaining = m["observation_batches"] - (done - m["batches_done_at"])
        if st in ("QUARANTINED", "REFERENCED_AGAIN") and remaining > 0:
            out.append({"run_id": m["run_id"], "state": st, "action": "OBSERVING", "remaining_batches": remaining})
            continue
        missing = removal_evidence(root, rels)  # re-check before every transition
        if missing:
            m["state"], m["blocked_by"] = "REFERENCED_AGAIN", missing[:5]
            _save_manifest(d, m)
            out.append({"run_id": m["run_id"], "state": m["state"], "action": "BLOCKED", "blocked_by": m["blocked_by"]})
            continue
        m.pop("blocked_by", None)
        if st == "VERIFIED_UNUSED":
            shutil.rmtree(d / "files", ignore_errors=True)
            m["state"], m["removed_at_batches"] = "REMOVED", done
        else:
            m["state"], m["verified_at_batches"] = "VERIFIED_UNUSED", done
        _save_manifest(d, m)
        out.append({"run_id": m["run_id"], "state": m["state"], "action": "ADVANCED"})
    return out


def sweep_ephemeral(root: Path, now: datetime | None = None) -> dict[str, list[str]]:
    """EPHEMERAL classes: remove expired files; active files and files without expires_at are kept."""
    now = now or datetime.now(timezone.utc)
    res: dict[str, list[str]] = {"removed": [], "kept_active": [], "no_expiry": [], "unreadable": []}
    for name, spec in load_policy(root).get("data_classes", {}).items():
        if name.startswith("_") or spec["disposition"] != "EPHEMERAL":
            continue
        for pre in spec["paths"]:
            d = root / pre
            if not d.is_dir():
                continue
            for f in sorted(d.rglob("*.json")):
                rel = f.relative_to(root).as_posix()
                try:
                    data = _load(f)
                    exp = data.get("expires_at")
                    when = datetime.fromisoformat(exp.replace("Z", "+00:00")) if exp else None
                except (OSError, ValueError, AttributeError):
                    res["unreadable"].append(rel)
                    continue
                if data.get("active") is True:
                    res["kept_active"].append(rel)
                elif when is None:
                    res["no_expiry"].append(rel)
                else:
                    if when.tzinfo is None:
                        when = when.replace(tzinfo=timezone.utc)
                    if when <= now:
                        f.unlink()
                        res["removed"].append(rel)
    return res


def suggest_budget(root: Path) -> list[dict[str, Any]]:
    """Classes with budget_bytes over budget: list the largest files and a disposition hint (suggestion only)."""
    out = []
    for name, spec in load_policy(root).get("data_classes", {}).items():
        if name.startswith("_") or "budget_bytes" not in spec:
            continue
        sizes = []
        for f in _files(root):
            if any(f.startswith(p) for p in spec["paths"]):
                try:
                    sizes.append((f, (root / f).stat().st_size))
                except OSError:
                    pass
        total = sum(n for _, n in sizes)
        if total > spec["budget_bytes"]:
            out.append({"class": name, "bytes": total, "budget_bytes": spec["budget_bytes"], "over_by": total - spec["budget_bytes"],
                        "largest": [{"path": p, "bytes": n} for p, n in sorted(sizes, key=lambda x: -x[1])[:5]],
                        "advice": f"disposition {spec['disposition']}：拆檔或交 archive_governance.archive_assets，再回頭降到預算內（只建議，不處置）"})
    return out


def sim_repo(base: Path) -> Path:
    """Mini repo for the quarantine closed loop (used by --simulate-quarantine and the tests)."""
    real = Path(__file__).resolve().parents[2]
    root = base
    def w(rel: str, text: str) -> None:
        p = root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text, encoding="utf-8")
    pol = _load(real / POLICY_PATH)
    pol["declared_entries"] = []
    w(POLICY_PATH, json.dumps(pol, ensure_ascii=False))
    w(CTRL + "policy/repo_budget.json", json.dumps({"version": "1.0", "budgets": [{"path": "", "max_bytes": 10**9, "target_bytes": 10**9}]}))
    for name in ("issue_register.json", "update_learning_ledger.json"):
        w(CTRL + "canonical/" + name, (real / CTRL / "canonical" / name).read_text(encoding="utf-8"))
    w("README.md", "入口 P1-Central-Control/scripts/live.py")
    w("P1-CURRENT.json", "{}")
    w(".github/workflows/ci.yml", "run: python P1-Central-Control/scripts/live.py")
    w(CTRL + "scripts/live.py", "import live_dep\n")
    w(CTRL + "scripts/live_dep.py", "x = 1\n")
    w(CTRL + "scripts/dead.py", "import dead_dep\n")
    w(CTRL + "scripts/dead_dep.py", "x = 1\n")
    w(CTRL + "tests/test_live.py", "import live\n")
    return root


def simulate_quarantine() -> dict[str, Any]:
    """Closed loop on a temp mini repo: candidate -> quarantine -> observe -> restore | re-check block -> purge."""
    steps: list[str] = []
    ok = True
    def check(name: str, cond: bool) -> None:
        nonlocal ok
        steps.append(("PASS " if cond else "FAIL ") + name)
        ok = ok and cond
    with tempfile.TemporaryDirectory(prefix="p1-s2-sim-") as t:
        root = sim_repo(Path(t))
        grp = [CTRL + "scripts/dead.py", CTRL + "scripts/dead_dep.py"]
        before = {p: (root / p).read_bytes() for p in grp}
        check("候選含 dead／dead_dep", set(grp) <= {c["path"] for c in find_candidates(root)["candidates"]})
        m = quarantine_batch(root, grp, batches_done=0)
        check("隔離：原路徑消失且有 sha256 清單", not any((root / p).exists() for p in grp) and len(m["files"]) == 2)
        check("掃描忽略隔離區", not any(c["path"].startswith(QUARANTINE_REL) for c in find_candidates(root)["candidates"]))
        restore_batch(root, m["run_id"])
        check("還原位元組相同", all((root / p).read_bytes() == before[p] for p in grp))
        m = quarantine_batch(root, grp, batches_done=0)
        check("觀察期內不推進（以批次數計）", advance_quarantine(root, batches_done=1)[0]["action"] == "OBSERVING")
        check("觀察滿→VERIFIED_UNUSED", advance_quarantine(root, batches_done=2)[0]["state"] == "VERIFIED_UNUSED")
        wf = root / ".github/workflows/ci.yml"
        wf.write_text(wf.read_text(encoding="utf-8") + "\nrun: python P1-Central-Control/scripts/dead.py\n", encoding="utf-8")
        check("清除前重查：新引用擋下", advance_quarantine(root, batches_done=2)[0]["action"] == "BLOCKED")
        wf.write_text("run: python P1-Central-Control/scripts/live.py", encoding="utf-8")
        advance_quarantine(root, batches_done=2)
        final = advance_quarantine(root, batches_done=2)[0]
        check("引用清除後 VERIFIED_UNUSED→REMOVED 且檔案已清", final["state"] == "REMOVED" and not (_qroot(root) / m["run_id"] / "files").exists())
    return {"status": "SIMULATED_PASS" if ok else "FAIL", "steps": steps}


def main() -> int:
    ap = argparse.ArgumentParser(description="P1 lifecycle sweep")
    ap.add_argument("root", nargs="?", default=".")
    ap.add_argument("--output")
    ap.add_argument("--apply-records", action="store_true")
    ap.add_argument("--ratchet", action="store_true")
    ap.add_argument("--retire", action="store_true", help="run candidates->delete fixpoint")
    ap.add_argument("--classify", nargs="+", metavar="PATH")
    ap.add_argument("--quarantine", nargs="+", metavar="PATH")
    ap.add_argument("--restore", metavar="RUN_ID")
    ap.add_argument("--advance", action="store_true")
    ap.add_argument("--ephemeral", action="store_true")
    ap.add_argument("--budget", action="store_true")
    ap.add_argument("--simulate-quarantine", action="store_true")
    a = ap.parse_args()
    root = Path(a.root).resolve()
    if a.simulate_quarantine:
        res = simulate_quarantine()
        print(json.dumps(res, ensure_ascii=False, indent=2))
        return 0 if res["status"] == "SIMULATED_PASS" else 1
    if any((a.classify, a.quarantine, a.restore, a.advance, a.ephemeral, a.budget)):
        try:
            if a.classify:
                pol = load_policy(root)
                out: Any = [classify_path(x, pol) for x in a.classify]
            elif a.quarantine:
                out = quarantine_batch(root, a.quarantine)
            elif a.restore:
                out = restore_batch(root, a.restore)
            elif a.advance:
                out = advance_quarantine(root)
            elif a.ephemeral:
                out = sweep_ephemeral(root)
            else:
                out = suggest_budget(root)
        except ValueError as exc:
            print(json.dumps({"status": "REFUSED", "reason": str(exc)}, ensure_ascii=False))
            return 1
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0
    if a.retire:
        print(json.dumps(run_retirement(root), ensure_ascii=False, indent=2))
    if a.apply_records:
        print(json.dumps(apply_records(root), ensure_ascii=False))
    if a.ratchet:
        print(json.dumps(ratchet(root), ensure_ascii=False))
    rep = run_sweep(root)
    if a.output:
        Path(a.output).write_text(json.dumps(rep, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    brief = {k: rep[k] for k in ("status", "reason_codes", "files", "roots")}
    brief["candidate_count"] = len(rep["candidates"])
    brief["records"] = rep["records"]
    print(json.dumps(brief, ensure_ascii=False, indent=2))
    return 0 if rep["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
