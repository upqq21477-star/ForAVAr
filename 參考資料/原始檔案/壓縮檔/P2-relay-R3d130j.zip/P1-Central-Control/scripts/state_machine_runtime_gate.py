#!/usr/bin/env python3
from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
from typing import Any

from event_log import EventLog, make_transition_event

from state_transition import (
    ACCEPTED,
    REPLAY,
    apply_transition,
    transition_event,
)


TERMINAL_WORKFLOW_STATES = {"COMPLETED", "FAILED", "CANCELLED"}


def initialize_workflow_control(workflow_id: str) -> dict[str, Any]:
    """建立唯一的 Workflow runtime control state。"""
    return {
        "status": "READY",
        "state_revision": 0,
        "last_command_id": None,
        "last_idempotency_key": None,
        "last_command_fingerprint": None,
        "last_transition": None,
        "terminal_state": None,
    }


def _command(
    state: dict[str, Any],
    command_type: str,
    *,
    command_id: str | None = None,
    idempotency_key: str | None = None,
) -> dict[str, Any]:
    workflow_id = state["workflow_id"]
    revision = state["state_revision"]
    deterministic_id = command_id or f"{workflow_id}:r{revision}:{command_type}"
    return {
        "command_id": deterministic_id,
        "aggregate_type": "WORKFLOW",
        "aggregate_id": workflow_id,
        "command_type": command_type,
        "expected_state_revision": revision,
        "idempotency_key": idempotency_key or deterministic_id,
    }


def transition_workflow(
    state: dict[str, Any],
    command_type: str,
    *,
    command_id: str | None = None,
    idempotency_key: str | None = None,
    event_log: EventLog | None = None,
    correlation_id: str | None = None,
    actor_id: str = "COMMANDER",
    causation_id: str | None = None,
    occurred_at: str | None = None,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """所有正式 Workflow 狀態變更唯一入口。"""
    if "workflow_id" not in state:
        raise ValueError("Central State 缺少 workflow_id")
    if "status" not in state or "state_revision" not in state:
        raise ValueError("Central State 缺少 runtime state control fields")

    command = _command(
        state,
        command_type,
        command_id=command_id,
        idempotency_key=idempotency_key,
    )

    reducer_state = deepcopy(state)
    reducer_state["aggregate_type"] = "WORKFLOW"
    reducer_state["aggregate_id"] = state["workflow_id"]
    result = apply_transition(reducer_state, command)

    for state_key in ("state_before", "state_after"):
        result[state_key].pop("aggregate_type", None)
        result[state_key].pop("aggregate_id", None)

    if result["status"] not in {ACCEPTED, REPLAY}:
        raise ValueError(
            f"Workflow transition 被 Runtime Gate 拒絕: {result['reason']}"
        )

    if result["status"] == REPLAY:
        return deepcopy(result["state_after"]), result

    updated = deepcopy(result["state_after"])
    legacy_event = transition_event(result)

    if event_log is not None:
        event = make_transition_event(
            result,
            correlation_id=correlation_id or f"CORR:{state['workflow_id']}",
            actor_id=actor_id,
            causation_id=causation_id,
            occurred_at=occurred_at or datetime.now(timezone.utc).isoformat(),
        )
        append_status = event_log.append(event)
        if append_status not in {"APPENDED", "IDEMPOTENT_REPLAY"}:
            raise ValueError(
                f"Event Log append 失敗: {append_status}"
            )
        updated["last_transition"] = event
    else:
        updated["last_transition"] = legacy_event

    return updated, result




def transition_workflow_command(
    state: dict[str, Any],
    command: dict[str, Any],
    *,
    event_log: EventLog,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """接收已通過 Command Layer 的正式 Command，執行唯一 Workflow transition。"""
    required = (
        "command_id",
        "command_type",
        "aggregate_type",
        "workflow_id",
        "target_id",
        "expected_state_revision",
        "idempotency_key",
        "caused_by",
        "issued_at",
    )
    missing = [key for key in required if key not in command]
    if missing:
        raise ValueError("正式 Command 缺少必要欄位: " + ", ".join(missing))

    if command["aggregate_type"] != "WORKFLOW":
        raise ValueError("Runtime Gate 目前只接受 WORKFLOW Command")
    if command["workflow_id"] != state.get("workflow_id"):
        raise ValueError("Command workflow_id 與 Central State 不一致")
    if command["target_id"] != state.get("workflow_id"):
        raise ValueError("Command target_id 與 Workflow 不一致")

    low_level_command = {
        "command_id": command["command_id"],
        "aggregate_type": command["aggregate_type"],
        "aggregate_id": command["target_id"],
        "command_type": command["command_type"],
        "expected_state_revision": command["expected_state_revision"],
        "idempotency_key": command["idempotency_key"],
        "caused_by": command["caused_by"],
        "issued_at": command["issued_at"],
    }

    reducer_state = deepcopy(state)
    reducer_state["aggregate_type"] = "WORKFLOW"
    reducer_state["aggregate_id"] = state["workflow_id"]
    result = apply_transition(reducer_state, low_level_command)

    for state_key in ("state_before", "state_after"):
        result[state_key].pop("aggregate_type", None)
        result[state_key].pop("aggregate_id", None)

    if result["status"] not in {ACCEPTED, REPLAY}:
        return deepcopy(result["state_after"]), result

    if result["status"] == REPLAY:
        return deepcopy(result["state_after"]), result

    updated = deepcopy(result["state_after"])
    event = make_transition_event(
        result,
        correlation_id=command["correlation_id"],
        actor_id=command.get("actor_id", "COMMANDER"),
        causation_id=command["caused_by"],
        occurred_at=command["issued_at"],
    )
    append_status = event_log.append(event)
    if append_status not in {"APPENDED", "IDEMPOTENT_REPLAY"}:
        raise ValueError(f"Event Log append 失敗: {append_status}")
    updated["last_transition"] = event
    return updated, result

def require_non_terminal(state: dict[str, Any]) -> None:
    if state.get("status") in TERMINAL_WORKFLOW_STATES:
        raise ValueError(
            f"Workflow 已進入 terminal state {state['status']}；禁止直接修改"
        )


def transition_for_result(
    state: dict[str, Any],
    result_status: str,
    *,
    has_queued_work: bool,
    event_log: EventLog | None = None,
    correlation_id: str | None = None,
    actor_id: str = "COMMANDER",
    causation_id: str | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """將 System Result 映射成正式 Workflow state transitions。"""
    current = deepcopy(state)
    events: list[dict[str, Any]] = []

    if current["status"] != "WAITING":
        raise ValueError(
            f"只有 WAITING Workflow 可以接收 System Result；目前為 {current['status']}"
        )

    if result_status == "WORK_COMPLETE":
        current, applied = transition_workflow(
            current,
            "RESUME",
            event_log=event_log,
            correlation_id=correlation_id,
            actor_id=actor_id,
            causation_id=causation_id,
        )
        if applied["status"] == ACCEPTED:
            events.append(current["last_transition"])
        if not has_queued_work:
            current, applied = transition_workflow(
                current,
                "COMPLETE",
                event_log=event_log,
                correlation_id=correlation_id,
                actor_id=actor_id,
                causation_id=causation_id,
            )
            if applied["status"] == ACCEPTED:
                events.append(current["last_transition"])
        return current, events

    if result_status == "FAIL":
        if has_queued_work:
            current, applied = transition_workflow(
                current,
                "RESUME",
                event_log=event_log,
                correlation_id=correlation_id,
                actor_id=actor_id,
                causation_id=causation_id,
            )
            if applied["status"] == ACCEPTED:
                events.append(current["last_transition"])
            return current, events

        current, applied = transition_workflow(
            current,
            "FAIL",
            event_log=event_log,
            correlation_id=correlation_id,
            actor_id=actor_id,
            causation_id=causation_id,
        )
        if applied["status"] == ACCEPTED:
            events.append(current["last_transition"])
        return current, events

    if result_status == "BLOCK":
        current, applied = transition_workflow(
            current,
            "BLOCK",
            event_log=event_log,
            correlation_id=correlation_id,
            actor_id=actor_id,
            causation_id=causation_id,
        )
        if applied["status"] == ACCEPTED:
            events.append(current["last_transition"])
        return current, events

    if result_status == "UNRESOLVED":
        if has_queued_work:
            current, applied = transition_workflow(
                current,
                "RESUME",
                event_log=event_log,
                correlation_id=correlation_id,
                actor_id=actor_id,
                causation_id=causation_id,
            )
            if applied["status"] == ACCEPTED:
                events.append(current["last_transition"])
            return current, events

        current, applied = transition_workflow(
            current,
            "BLOCK",
            event_log=event_log,
            correlation_id=correlation_id,
            actor_id=actor_id,
            causation_id=causation_id,
        )
        if applied["status"] == ACCEPTED:
            events.append(current["last_transition"])
        return current, events

    raise ValueError(f"未知 System Result status: {result_status}")
