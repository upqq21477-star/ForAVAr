"""pattern_guard -- deterministic guard around model-made patterns (CAP-PATTERN, R3d12zx S6 batch 2).  Finding patterns stays with the model; output is always CANDIDATE, never fact.
build_patterns(observations[{id, source_id}], dataset_hash, question, model(question, observations, attempt) -> [{type, scope, evidence_refs, n}], out_dir, n_min).
Guard: type in TYPES, scope non-empty, evidence_refs non-empty and all resolve to an observation id, n_min <= n <= len(observations); structure only, meaning is not judged.
End: PATTERN_FOUND | NO_SUFFICIENT_DATA (too few observations / n<n_min / nothing found; never forced) | REJECTED (all patterns failed, or bad format after 2 retries)
| INCOMPLETE (model or guard error) | FAILED (bad input).  Key = dataset_hash + question hash; raw model output is written first, a rerun reads it and re-runs only the guard.
DEFAULT_N_MIN=2 is HYPOTHESIS (plan: UNKNOWN).  Evidence ceiling: SIMULATED_PASS."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Callable

from atomic_write import atomic_write

TYPES = ("共同", "差異", "條件", "例外", "反常")
DEFAULT_N_MIN = 2


def _refs_ok(refs: Any, ids: set[str]) -> bool:
    return isinstance(refs, list) and bool(refs) and all(isinstance(r, str) and r in ids for r in refs)


def _check(p: Any, ids: set[str], n_min: int) -> tuple[str, str]:
    if not isinstance(p, dict) or p.get("type") not in TYPES:
        return "REJECTED", "TYPE"
    if not (isinstance(p.get("scope"), str) and p["scope"].strip()):
        return "REJECTED", "SCOPE"
    if not _refs_ok(p.get("evidence_refs"), ids):
        return "REJECTED", "EVIDENCE_REFS"
    n = p.get("n")
    if not isinstance(n, int) or isinstance(n, bool) or n > len(ids):
        return "REJECTED", "N"
    return ("NO_SUFFICIENT_DATA", "N_BELOW_MIN") if n < n_min else ("OK", "")


def _load(p: Path) -> Any:
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return raw if isinstance(raw, list) else None


def build_patterns(observations: Any, dataset_hash: Any, question: Any, model: Callable[..., Any], out_dir: str | Path, n_min: int = DEFAULT_N_MIN) -> dict[str, Any]:
    res: dict[str, Any] = {"status": "FAILED", "patterns": [], "rejected": [], "rejected_ratio": None}
    if (not isinstance(observations, list) or not all(isinstance(o, dict) and isinstance(o.get("id"), str) and isinstance(o.get("source_id"), str) for o in observations)
            or not all(isinstance(x, str) and x for x in (dataset_hash, question))):
        return res
    ids = {o["id"] for o in observations}
    if len(ids) < n_min:
        return {**res, "status": "NO_SUFFICIENT_DATA"}
    key = hashlib.sha256((dataset_hash + "|" + hashlib.sha256(question.encode("utf-8")).hexdigest()).encode("utf-8")).hexdigest()[:12]
    p = Path(out_dir) / (key + ".json")
    raw = _load(p)
    if raw is None:
        try:
            for attempt in range(3):  # first try + 2 retries on a bad format
                raw = model(question, observations, attempt)
                if isinstance(raw, list):
                    break
        except Exception:
            return {**res, "status": "INCOMPLETE"}
        if not isinstance(raw, list):
            return {**res, "status": "REJECTED", "rejected": [{"index": None, "reason": "INVALID_FORMAT"}]}
        Path(out_dir).mkdir(parents=True, exist_ok=True)
        atomic_write(p, json.dumps(raw, ensure_ascii=False, sort_keys=True))
    try:
        checked = [_check(x, ids, n_min) for x in raw]
    except Exception:  # guard failed: never release
        return {**res, "status": "INCOMPLETE"}
    good = [dict(x, status="CANDIDATE") for x, (s, _) in zip(raw, checked) if s == "OK"]
    rej = [{"index": i, "reason": r} for i, (s, r) in enumerate(checked) if s == "REJECTED"]
    return {"status": "PATTERN_FOUND" if good else "REJECTED" if rej else "NO_SUFFICIENT_DATA", "patterns": good, "rejected": rej,
            "rejected_ratio": len(rej) / len(raw) if raw else 0.0}
