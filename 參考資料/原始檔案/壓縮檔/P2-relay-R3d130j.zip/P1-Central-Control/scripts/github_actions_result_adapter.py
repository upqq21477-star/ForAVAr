#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

import regression_selection


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/github_actions_regression_observation.schema.json"
REGISTRY = ROOT / "P1-Central-Control/regression_selection_registry.json"


class GithubActionsAdapterError(ValueError):
    pass


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise GithubActionsAdapterError(f"{path} 必須是 JSON object")
    return value


def validate_observation(observation: dict[str, Any]) -> None:
    schema = load_json(SCHEMA)
    Draft202012Validator(schema).validate(observation)


def classify_job(job: dict[str, Any], workflow: dict[str, Any]) -> tuple[str, str]:
    if workflow.get("status") != "completed":
        return "INCOMPLETE", "WORKFLOW_NOT_COMPLETED"

    steps = job.get("steps")
    conclusion = job.get("conclusion")
    status = job.get("status")

    if status != "completed":
        return "INCOMPLETE", "JOB_NOT_COMPLETED"

    if conclusion == "success":
        return "PASS", "JOB_SUCCESS"

    # GitHub Actions can report a job-level failure before any step exists.
    # That is runner / job-start evidence failure, not a failed regression test.
    if steps in (None, []) and conclusion == "failure":
        return "INCOMPLETE", "RUNNER_STARTUP_FAILURE"

    if steps is None:
        return "INCOMPLETE", "NO_STEP_EVIDENCE"

    if conclusion in {"failure", "cancelled", "timed_out"}:
        return "FAIL", "JOB_FAILED_AFTER_STEP_ALLOCATION"

    if workflow.get("status") != "completed":
        return "INCOMPLETE", "WORKFLOW_NOT_COMPLETED"

    return "INCOMPLETE", "UNRESOLVED_WORKFLOW_RESULT"


def build_external_result(
    selection: dict[str, Any],
    observation: dict[str, Any],
    registry: dict[str, dict[str, Any]],
    *,
    expected_head_sha: str | None = None,
) -> dict[str, Any]:
    selection_id = selection.get("selection_id")
    if selection.get("kind") != "REGRESSION_SELECTION" or not selection_id:
        raise GithubActionsAdapterError("只接受有效 REGRESSION_SELECTION")
    regression_selection.validate_report(selection)

    validate_observation(observation)
    workflow = observation["workflow_run"]
    workflow_name = workflow["name"]
    if expected_head_sha and workflow["head_sha"] != expected_head_sha:
        raise GithubActionsAdapterError("GITHUB_ACTIONS_HEAD_SHA_MISMATCH")

    selected = set(selection.get("selected_regression_sets", []))
    external_sets = [
        set_id
        for set_id in sorted(selected)
        if registry.get(set_id, {}).get("runner") == "GITHUB_ACTIONS"
    ]
    if not external_sets:
        raise GithubActionsAdapterError("選擇中沒有 GITHUB_ACTIONS regression set")

    results: list[dict[str, str]] = []
    incomplete = False
    failed = False

    for set_id in external_sets:
        definition = registry[set_id]
        expected_workflow = definition.get("workflow")
        if expected_workflow != workflow_name:
            raise GithubActionsAdapterError(
                f"WORKFLOW_MISMATCH:{set_id}:{expected_workflow}!={workflow_name}"
            )
        expected_job = definition.get("job")
        jobs = observation["jobs"]
        matches = [
            job for job in jobs
            if not expected_job or job.get("name") == expected_job
        ]
        if not matches:
            incomplete = True
            continue

        status, _reason = classify_job(matches[0], workflow)
        if status == "PASS":
            results.append({"regression_set_id": set_id, "status": "PASS"})
        elif status == "FAIL":
            results.append({"regression_set_id": set_id, "status": "FAIL"})
            failed = True
        else:
            incomplete = True

    overall = "FAIL" if failed else "INCOMPLETE" if incomplete else "PASS"
    return {
        "result_id": f"GHA-{selection_id}",
        "selection_id": selection_id,
        "status": overall,
        "results": results,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 GitHub Actions regression result adapter")
    parser.add_argument("selection")
    parser.add_argument("observation")
    parser.add_argument("output")
    parser.add_argument("--registry", default=str(REGISTRY))
    parser.add_argument("--expected-head-sha")
    args = parser.parse_args()

    selection = load_json(Path(args.selection))
    observation = load_json(Path(args.observation))
    registry_doc = load_json(Path(args.registry))
    registry = {
        item["regression_set_id"]: item
        for item in registry_doc.get("sets", [])
        if isinstance(item, dict) and item.get("regression_set_id")
    }
    result = build_external_result(
        selection,
        observation,
        registry,
        expected_head_sha=args.expected_head_sha,
    )
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] in {"PASS", "FAIL"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
