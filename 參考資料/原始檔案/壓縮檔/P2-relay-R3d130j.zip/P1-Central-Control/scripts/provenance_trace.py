"""provenance_trace -- multi-hop provenance walk (CAP-PROVENANCE F38/F48, R3d12zy S6 batch 3).  Pure, stateless, rerun = same result.
records [{id, activity, input_refs[], output_refs[], started, ended}] (times: number or ISO string); start = entity ref; originals = declared raw sources.
Walks output -> input until an entity nobody generated.  Break = {at, reason}: UNDECLARED_ROOT (root not in originals) | BAD_RECORD (missing/invalid field; not raised).
Violations (PROV-CONSTRAINTS, two of four): DUP_GENERATION (same entity+activity generated twice), USE_BEFORE_GENERATION (use started before generation ended).
Cycle check via graph_check (a cycle = contradiction).  End: COMPLETE (ok) | PARTIAL (breaks/violations) | FAILED (cycle, witness closed) | INCOMPLETE (unreadable input,
hops > max_depth, guard error; never truncated).  provenance_input() -> {ok, breaks} for synthesis_guard, None when INCOMPLETE.  max_depth 64 is HYPOTHESIS.  Ceiling: SIMULATED_PASS."""
from __future__ import annotations

from datetime import datetime
from typing import Any

import graph_check

MAX_DEPTH = 64


def _ts(x: Any) -> float:
    if isinstance(x, (int, float)) and not isinstance(x, bool):
        return float(x)
    if isinstance(x, str) and x:
        return datetime.fromisoformat(x.replace("Z", "+00:00")).timestamp()
    raise ValueError("time")


def _strs(x: Any) -> bool:
    return isinstance(x, list) and bool(x) and all(isinstance(s, str) and s for s in x)


def _valid(r: Any) -> bool:
    try:
        return (isinstance(r, dict) and all(isinstance(r.get(k), str) and r[k] for k in ("id", "activity")) and _strs(r.get("input_refs"))
                and _strs(r.get("output_refs")) and _ts(r.get("started")) <= _ts(r.get("ended")))
    except (ValueError, TypeError):
        return False


def _res(status: str, reason: str = "", **kw: Any) -> dict[str, Any]:
    base = {"ok": status == "COMPLETE", "status": status, "reason": reason, "chain": [], "roots": [], "breaks": [], "violations": [], "cycle": None}
    return {**base, **kw}


def trace(records: Any, start: Any, originals: Any = (), max_depth: int = MAX_DEPTH) -> dict[str, Any]:
    if not isinstance(records, list) or not isinstance(start, str) or not start:
        return _res("INCOMPLETE", "INPUT_UNREADABLE")
    try:
        orig, gen = set(originals), {}
        for i, r in enumerate(records):
            rid = r.get("id") if isinstance(r, dict) and isinstance(r.get("id"), str) else f"#{i}"
            outs = r.get("output_refs") if isinstance(r, dict) and isinstance(r.get("output_refs"), list) else []
            for e in outs:
                if isinstance(e, str):
                    gen.setdefault(e, []).append((rid, r, _valid(r)))
        seen, chain, roots, breaks, depth, level, edges = {start}, [], set(), set(), 0, [start], []
        recs: dict[str, dict[str, Any]] = {}
        while level:
            if depth > max_depth:
                return _res("INCOMPLETE", "DEPTH_LIMIT")
            nxt = []
            for e in level:
                prods = gen.get(e, [])
                if not prods:
                    (roots.add(e) if e in orig else breaks.add((e, "UNDECLARED_ROOT")))
                for rid, r, good in prods:
                    if not good:
                        breaks.add((rid, "BAD_RECORD"))
                        continue
                    if rid not in recs:
                        recs[rid] = r
                        chain.append(rid)
                        edges += [{"from": i, "to": o, "source": rid} for i in r["input_refs"] for o in r["output_refs"]]
                        nxt += [i for i in r["input_refs"] if i not in seen and not seen.add(i)]
            level, depth = nxt, depth + 1
        viol, acts = [], {}
        for rid in chain:
            r = recs[rid]
            for e in r["output_refs"]:
                if acts.setdefault((e, r["activity"]), rid) != rid:
                    viol.append({"at": rid, "reason": "DUP_GENERATION", "entity": e})
            for i in r["input_refs"]:
                for pid, p, good in gen.get(i, []):
                    if good and pid in recs and _ts(r["started"]) < _ts(p["ended"]):
                        viol.append({"at": rid, "reason": "USE_BEFORE_GENERATION", "entity": i, "generated_by": pid})
        g = graph_check.check(edges)
        kw = {"chain": chain, "roots": sorted(roots), "breaks": [{"at": a, "reason": b} for a, b in sorted(breaks)], "violations": viol}
        if g["status"] == "PARTIAL":
            return _res("FAILED", "CYCLE", **{**kw, "cycle": g["cycle"]})
        if g["status"] != "OK":
            return _res("INCOMPLETE", "GRAPH_" + g["status"])
        if kw["breaks"] or viol:
            return _res("PARTIAL", "BREAKS" if kw["breaks"] else "VIOLATIONS", **kw)
        return _res("COMPLETE", **kw)
    except Exception:  # guard failed: not a verdict on the provenance
        return _res("INCOMPLETE", "GUARD_ERROR")


def provenance_input(result: Any) -> dict[str, Any] | None:
    if not isinstance(result, dict) or result.get("status") not in ("COMPLETE", "PARTIAL", "FAILED"):
        return None
    return {"ok": bool(result["ok"]), "breaks": list(result.get("breaks", []))}
