#!/usr/bin/env python3
"""Select bounded reverse-engineering context from structural evidence."""

from __future__ import annotations

import argparse
import json
from collections import deque
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator


ROOT = Path(__file__).resolve().parents[2]
REVERSE_SCHEMA = ROOT / "P1-Central-Control/schemas/reverse_reconstruction_result.schema.json"
RESULT_SCHEMA = ROOT / "P1-Central-Control/schemas/reverse_context_selection.schema.json"


def _load(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate(value: dict[str, Any], path: Path) -> None:
    schema = _load(path)
    errors = sorted(Draft202012Validator(schema).iter_errors(value), key=lambda e: list(e.path))
    if errors:
        raise ValueError("; ".join(e.message for e in errors))


def execute(
    reverse_result: dict[str, Any],
    *,
    focus_paths: list[str] | None = None,
    max_files: int = 8,
    max_bytes: int = 50000,
) -> dict[str, Any]:
    _validate(reverse_result, REVERSE_SCHEMA)

    focus = set(focus_paths or [])
    inventory = {row["path"]: row for row in reverse_result["inventory"] if row["kind"] == "SOURCE"}
    graph: dict[str, set[str]] = {path: set() for path in inventory}
    for edge in reverse_result["dependencies"]["edges"]:
        source = edge["source"]
        target = edge["target"]
        if source in graph and target in graph:
            graph[source].add(target)
            graph[target].add(source)

    candidates = set(focus) & set(inventory)
    if not candidates:
        candidates.update(reverse_result["structure"]["entrypoint_candidates"][:2])

    distances: dict[str, int] = {}
    queue = deque((p, 0) for p in candidates)
    seen = set(candidates)
    while queue:
        node, distance = queue.popleft()
        distances[node] = min(distance, distances.get(node, distance))
        for neighbor in sorted(graph.get(node, ())):
            if neighbor not in seen:
                seen.add(neighbor)
                queue.append((neighbor, distance + 1))

    rows = []
    for path, row in inventory.items():
        reasons = []
        score = 0.0
        if path in focus:
            score += 100
            reasons.append("explicit_focus")
        if path in candidates:
            score += 60
            reasons.append("seed")
        if path in distances:
            score += max(0, 40 - distances[path] * 8)
            reasons.append(f"dependency_distance={distances[path]}")
        if path in reverse_result["structure"]["entrypoint_candidates"]:
            score += 25
            reasons.append("entrypoint")
        if row["language"] == "python":
            score += 5
            reasons.append("structured_language")
        rows.append((score, path, reasons, row["bytes"]))

    rows.sort(key=lambda x: (-x[0], x[1]))

    selected = []
    selected_bytes = 0
    selected_set = set()
    for score, path, reasons, size in rows:
        if len(selected) >= max_files:
            break
        if selected_bytes + size > max_bytes:
            continue
        selected.append({"path": path, "score": score, "reasons": reasons})
        selected_bytes += size
        selected_set.add(path)

    deferred = sorted(set(inventory) - selected_set)
    result = {
        "schema_version": "1.0",
        "request_id": reverse_result["request_id"],
        "selected_paths": selected,
        "deferred_paths": deferred,
        "budget": {
            "max_files": max_files,
            "selected_files": len(selected),
            "max_bytes": max_bytes,
            "selected_bytes": selected_bytes
        }
    }
    _validate(result, RESULT_SCHEMA)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Select bounded reverse context")
    parser.add_argument("reverse_result")
    parser.add_argument("--focus", action="append", default=[])
    parser.add_argument("--max-files", type=int, default=8)
    parser.add_argument("--max-bytes", type=int, default=50000)
    args = parser.parse_args()
    result = execute(_load(Path(args.reverse_result).resolve()), focus_paths=args.focus,
                     max_files=args.max_files, max_bytes=args.max_bytes)
    print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
