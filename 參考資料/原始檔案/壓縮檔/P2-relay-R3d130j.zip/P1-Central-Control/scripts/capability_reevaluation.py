#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
from copy import deepcopy
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

import native_replacement_eval


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCHEMA_PATH = SCHEMA_DIR / "capability_reevaluation.schema.json"
CAPABILITY_REGISTRY_PATH = ROOT / "P1-Central-Control" / "capability_registry.json"
IMPACT_SCHEMA_PATH = SCHEMA_DIR / "impact_scan.schema.json"


def canonical_json(value: dict[str, Any]) -> bytes:
    return json.dumps(
        value,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")


def content_hash(value: dict[str, Any]) -> str:
    material = deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(canonical_json(material)).hexdigest()


def identity(kind: str, object_id: str, value: dict[str, Any]) -> dict[str, Any]:
    result = deepcopy(value)
    result["object_id"] = f"{kind}:{object_id}"
    result["kind"] = kind
    result["schema_version"] = "1.0"
    result["content_hash"] = ""
    result["content_hash"] = content_hash(result)
    return result


def _registry() -> Registry:
    registry = Registry()
    for filename in (
        "canonical_identity.schema.json",
        "canonical_common.schema.json",
        "capability_reevaluation.schema.json",
    ):
        schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
        registry = registry.with_resource(
            schema["$id"],
            Resource.from_contents(schema),
        )
    return registry


def validate_report(report: dict[str, Any]) -> None:
    schema = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
    errors = sorted(
        Draft202012Validator(
            schema,
            registry=_registry(),
            format_checker=FormatChecker(),
        ).iter_errors(report),
        key=lambda error: list(error.path),
    )
    if errors:
        raise ValueError(
            "capability_reevaluation.schema.json 驗證失敗: "
            + "; ".join(error.message for error in errors)
        )
    if report.get("content_hash") != content_hash(report):
        raise ValueError("Capability Reevaluation content_hash 不正確")


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} 必須是 JSON object")
    return value


def load_capabilities(path: Path) -> dict[str, dict[str, Any]]:
    registry = load_json(path)
    result: dict[str, dict[str, Any]] = {}
    for capability in registry.get("capabilities", []):
        if not isinstance(capability, dict):
            continue
        capability_id = capability.get("capability_id")
        if isinstance(capability_id, str):
            result[capability_id] = capability
    return result


def validate_impact_scan(impact: dict[str, Any]) -> None:
    schema = json.loads(IMPACT_SCHEMA_PATH.read_text(encoding="utf-8"))
    Draft202012Validator(schema, format_checker=FormatChecker()).validate(impact)
    if impact.get("status") != "PASS" or impact.get("decision") != "PROCEED":
        raise ValueError(
            "M2 禁止使用未通過 IMPACT_SCAN 的輸入；必須先得到 PROCEED"
        )
    if impact.get("unknown_paths"):
        raise ValueError("M2 禁止含 unknown_paths 的 IMPACT_SCAN")
    if impact.get("change_id", "").startswith("CHANGE:") is False:
        raise ValueError("M2 source change_id 無效")


def measurement_for(
    measurements: dict[str, Any] | None,
    capability_id: str,
) -> dict[str, Any] | None:
    if not measurements:
        return None
    value = measurements.get(capability_id)
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"measurement[{capability_id}] 必須是 object")
    return value


def required_measurement_inputs(capability: dict[str, Any]) -> list[str]:
    required = [
        "evaluation_id",
        "capability_id",
        "baseline_mode",
        "candidate_mode",
        "sample_size",
        "schema_compatibility",
        "behavior_compatibility",
        "acceptance",
        "reliability",
        "cost",
        "regression_count",
        "evidence_refs",
    ]
    if capability.get("kind") == "MODEL_NATIVE":
        required.append("candidate_model_ref")
    return required


def build_pending(capability_id: str, reason_code: str, required_inputs: list[str]) -> dict[str, Any]:
    return {
        "capability_id": capability_id,
        "reason_code": reason_code,
        "required_inputs": sorted(set(required_inputs)),
    }


def reevaluate(
    impact_scan: dict[str, Any],
    *,
    capability_registry: dict[str, Any],
    measurements: dict[str, Any] | None = None,
    reevaluation_id: str | None = None,
) -> dict[str, Any]:
    validate_impact_scan(impact_scan)
    capability_map = load_capabilities(Path(capability_registry["_path"])) if "_path" in capability_registry else {
        c["capability_id"]: c
        for c in capability_registry.get("capabilities", [])
        if isinstance(c, dict) and isinstance(c.get("capability_id"), str)
    }

    affected = sorted(set(impact_scan.get("affected_capabilities", [])))
    missing_registry = [cap for cap in affected if cap not in capability_map]
    if missing_registry:
        raise ValueError(
            "IMPACT_SCAN 指向不存在的 capability: " + ", ".join(missing_registry)
        )

    evaluations: list[dict[str, Any]] = []
    pending: list[dict[str, Any]] = []
    block_count = 0

    for capability_id in affected:
        capability = capability_map[capability_id]
        measurement = measurement_for(measurements, capability_id)

        if measurement is None:
            pending.append(
                build_pending(
                    capability_id,
                    "MEASUREMENT_MISSING",
                    required_measurement_inputs(capability),
                )
            )
            continue

        if measurement.get("capability_id") != capability_id:
            raise ValueError(
                f"{capability_id} measurement capability_id 不一致"
            )

        evaluation = native_replacement_eval.evaluate(measurement)
        evaluation_ref = evaluation["object_id"]
        status = evaluation["status"]
        if status == "BLOCK":
            block_count += 1
        evaluations.append(
            {
                "capability_id": capability_id,
                "evaluation_ref": evaluation_ref,
                "status": status,
                "baseline_mode": evaluation["baseline_mode"],
                "candidate_mode": evaluation["candidate_mode"],
                "evaluation_state": evaluation["evaluation_state"],
            }
        )

    if pending:
        status = "INSUFFICIENT_DATA" if not block_count else "BLOCK"
    elif block_count:
        status = "BLOCK"
    else:
        status = "PASS"

    report = identity(
        "CAPABILITY_REEVALUATION",
        reevaluation_id or impact_scan["change_id"].replace("CHANGE:", "M2-"),
        {
            "reevaluation_id": reevaluation_id
            or impact_scan["change_id"].replace("CHANGE:", "M2-"),
            "source_change_id": impact_scan["change_id"],
            "source_impact_status": impact_scan["status"],
            "affected_capabilities": affected,
            "evaluations": evaluations,
            "pending": pending,
            "status": status,
        },
    )
    validate_report(report)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(
        description="P1 M2 Capability Reevaluation"
    )
    parser.add_argument("impact_scan")
    parser.add_argument("output")
    parser.add_argument("--measurements")
    parser.add_argument(
        "--capability-registry",
        default=str(CAPABILITY_REGISTRY_PATH),
    )
    args = parser.parse_args()

    impact_document = load_json(Path(args.impact_scan))
    impact_scan = impact_document.get("impact_scan", impact_document)
    if not isinstance(impact_scan, dict):
        raise ValueError("M1 IMPACT_SCAN 輸出封包缺少 impact_scan object")
    registry = load_json(Path(args.capability_registry))
    measurements = (
        load_json(Path(args.measurements)) if args.measurements else None
    )

    report = reevaluate(
        impact_scan,
        capability_registry=registry,
        measurements=measurements,
    )
    Path(args.output).write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 3


if __name__ == "__main__":
    raise SystemExit(main())
