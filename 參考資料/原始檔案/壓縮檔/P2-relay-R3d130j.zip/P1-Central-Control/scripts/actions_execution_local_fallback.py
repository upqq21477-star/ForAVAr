#!/usr/bin/env python3
"""Bridge Actions recovery diagnostics to the existing local acceptance runtime."""

from __future__ import annotations

import argparse
import json
import subprocess
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/actions_execution_local_fallback.schema.json"


def _load(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"{path} must contain a JSON object")
    return value


def _validate(value: dict[str, Any]) -> None:
    Draft202012Validator(_load(SCHEMA)).validate(value)


def build_command(
    head_sha: str,
    output: Path,
    acceptance_output: Path,
    base_sha: str | None = None,
) -> list[str]:
    command = [
        "python3",
        str(ROOT / "P1-Central-Control/scripts/local_acceptance.py"),
        "--output",
        str(output),
        "--acceptance-output",
        str(acceptance_output),
        "--head",
        head_sha,
    ]
    if base_sha:
        command.extend(["--base", base_sha])
    return command


def execute(
    diagnostic: dict[str, Any],
    *,
    head_sha: str,
    output: Path,
    acceptance_output: Path,
    attempt_index: int,
    max_external_retries: int = 2,
    base_sha: str | None = None,
    mode: str = "PLAN",
) -> dict[str, Any]:
    classification = diagnostic.get("classification", "UNKNOWN")
    eligible = classification in {
        "WORKFLOW_EXECUTION_FAILURE",
        "RUNNER_STARTUP_FAILURE",
    }

    decision = "REPLAY_LOCAL" if eligible else (
        "BLOCK" if classification == "UNKNOWN" else "NOOP"
    )
    command = build_command(head_sha, output, acceptance_output, base_sha)

    result = {
        "fallback_id": (
            f"ACTIONS_FALLBACK:"
            f"{diagnostic.get('diagnostic_id', 'UNKNOWN').split(':', 1)[-1]}:"
            f"{attempt_index}"
        ),
        "source_classification": classification,
        "decision": decision,
        "status": "SKIPPED" if decision != "REPLAY_LOCAL" else "PLANNED",
        "head_sha": head_sha,
        "attempt_index": attempt_index,
        "command": command,
        "return_code": None,
        "output_path": str(output),
        "acceptance_output_path": str(acceptance_output),
        "error": None,
    }

    if decision == "REPLAY_LOCAL" and mode == "EXECUTE":
        try:
            completed = subprocess.run(command, cwd=ROOT, check=False)
            result["return_code"] = completed.returncode
            result["status"] = (
                "EXECUTED"
                if completed.returncode in {0, 1, 2}
                else "ERROR"
            )
            if result["status"] == "ERROR":
                result["error"] = (
                    f"LOCAL_ACCEPTANCE_EXIT_CODE:{completed.returncode}"
                )
        except Exception as exc:  # pragma: no cover
            result["status"] = "ERROR"
            result["error"] = str(exc)

    _validate(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(
        description="P1 Actions execution local fallback"
    )
    parser.add_argument("diagnostic")
    parser.add_argument("--head-sha", required=True)
    parser.add_argument("--output", required=True)
    parser.add_argument("--acceptance-output", required=True)
    parser.add_argument("--attempt-index", type=int, default=0)
    parser.add_argument("--max-external-retries", type=int, default=2)
    parser.add_argument("--base-sha")
    parser.add_argument("--mode", choices=["PLAN", "EXECUTE"], default="PLAN")
    args = parser.parse_args()

    result = execute(
        _load(Path(args.diagnostic).resolve()),
        head_sha=args.head_sha,
        output=Path(args.output).resolve(),
        acceptance_output=Path(args.acceptance_output).resolve(),
        attempt_index=args.attempt_index,
        max_external_retries=args.max_external_retries,
        base_sha=args.base_sha,
        mode=args.mode,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["status"] != "ERROR" else 1


if __name__ == "__main__":
    raise SystemExit(main())
