#!/usr/bin/env python3
"""On-demand P2 construction-efficiency retrospective; never a routine monitor."""
from __future__ import annotations
import argparse
import json
import subprocess
from pathlib import Path
from typing import Any
from brain_mode_controller import build_construction_health_review

ROOT = Path(__file__).resolve().parents[2]
# The Current-bound operational reference pack declares 91 distinct source refs
# at this revision. Keep a hard ceiling while accepting that bounded source list.
MAX_COMMITS, MAX_FILES_PER_COMMIT, MAX_SOURCE_REFS = 3, 20, 100
MAX_CURRENT_BYTES = MAX_REQUEST_BYTES = 200_000
TRIGGERS = ("user_requested", "slowdown", "stalled", "repeated_rework", "recurring_failure", "budget_exceeded", "anomaly_reported")


def _safe_repo_file(root: Path, relative: str) -> Path:
    candidate = Path(relative)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError("REVIEW_PATH_FORBIDDEN")
    cursor = root
    for part in candidate.parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("REVIEW_SYMLINK_FORBIDDEN")
    resolved = cursor.resolve()
    if not resolved.is_relative_to(root.resolve()):
        raise ValueError("REVIEW_PATH_FORBIDDEN")
    return resolved


def _bounded_json(path: Path, limit: int, code: str) -> tuple[dict[str, Any], int]:
    size = path.stat().st_size
    if size > limit:
        raise ValueError(code + "_SIZE_LIMIT")
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(code + "_OBJECT_REQUIRED")
    return value, size


def _commits(root: Path) -> list[dict[str, str]]:
    result = subprocess.run(
        ["git", "log", f"-{MAX_COMMITS}", "--format=%H%x09%cs%x09%s"],
        cwd=root, capture_output=True, text=True, timeout=5, check=False,
    )
    if result.returncode:
        raise ValueError("REVIEW_GIT_LOG_FAILED")
    items = []
    for line in result.stdout.splitlines()[:MAX_COMMITS]:
        fields = line.split("\t", 2)
        if len(fields) == 3 and len(fields[0]) == 40:
            items.append({"sha": fields[0], "date": fields[1], "subject": fields[2][:180]})
    return items


def _numstat(root: Path, sha: str) -> tuple[list[dict[str, Any]], bool]:
    proc = subprocess.Popen(
        ["git", "diff-tree", "--root", "--no-commit-id", "--numstat", "--no-renames", "-r", sha],
        cwd=root, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
    )
    assert proc.stdout is not None
    files, truncated = [], False
    try:
        for line in proc.stdout:
            fields = line.rstrip("\n").split("\t", 2)
            if len(fields) != 3:
                continue
            files.append({"path": fields[2][:300],
                "additions": int(fields[0]) if fields[0].isdigit() else None,
                "deletions": int(fields[1]) if fields[1].isdigit() else None})
            if len(files) == MAX_FILES_PER_COMMIT:
                # Stop immediately at row 20; do not consume row 21 to test whether
                # more data exists. "truncated" is conservative: the remainder is
                # unknown whenever the hard cap is reached.
                truncated = True
                try:
                    proc.terminate()
                except ProcessLookupError:
                    # The child may finish naturally just as the row cap is hit.
                    pass
                break
    finally:
        proc.stdout.close()
    if truncated:
        try:
            proc.wait(timeout=1)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait(timeout=1)
    else:
        if proc.stderr is not None:
            proc.stderr.read()
        if proc.wait(timeout=2):
            raise ValueError("REVIEW_GIT_NUMSTAT_FAILED")
    if truncated and proc.stderr is not None:
        # The process was deliberately stopped at the row cap; close diagnostics
        # without reading another stream of commit metadata or retaining history.
        proc.stderr.close()
    return files, truncated


def _source_budget(root: Path) -> dict[str, Any]:
    current_path = _safe_repo_file(root, "P1-CURRENT.json")
    current, current_bytes = _bounded_json(current_path, MAX_CURRENT_BYTES, "REVIEW_CURRENT")
    request_ref = "P1-Central-Control/examples/operational_reference_pack.request.example.json"
    request, _ = _bounded_json(_safe_repo_file(root, request_ref), MAX_REQUEST_BYTES, "REVIEW_REQUEST")
    # Match the Operational Reference Pack builder's byte accounting:
    # canonical request bytes + Current + separately-read Blueprint + every
    # explicit source ref (the Blueprint may also occur in source_refs).
    canonical_request_bytes = len(
        json.dumps(request, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    )
    blueprint_ref = request.get("blueprint_ref")
    if not isinstance(blueprint_ref, str) or not blueprint_ref.strip():
        raise ValueError("REVIEW_BLUEPRINT_REF_INVALID")
    blueprint_path = _safe_repo_file(root, blueprint_ref)
    if not blueprint_path.is_file():
        raise ValueError("REVIEW_BLUEPRINT_REF_MISSING")
    blueprint_bytes = blueprint_path.stat().st_size
    controls = current.get("implementation_control")
    if not isinstance(controls, dict):
        raise ValueError("REVIEW_CURRENT_CONTROL_INVALID")
    active = controls.get("active_work_packet")
    if not isinstance(active, str) or not active.strip() or request.get("active_work_ref") != active:
        raise ValueError("REVIEW_ACTIVE_WORK_POINTER_MISMATCH")
    if request.get("current_ref") != "P1-CURRENT.json":
        raise ValueError("REVIEW_CURRENT_REF_MISMATCH")
    refs = request.get("source_refs")
    if not isinstance(refs, list) or not refs or len(refs) > MAX_SOURCE_REFS:
        raise ValueError("REVIEW_SOURCE_MANIFEST_INVALID")
    seen, sizes, missing, invalid = set(), [], [], []
    for ref in refs:
        if not isinstance(ref, dict) or not isinstance(ref.get("path"), str):
            raise ValueError("REVIEW_SOURCE_REF_INVALID")
        rel = ref["path"]
        if not rel.strip() or rel == ".":
            raise ValueError("REVIEW_SOURCE_REF_INVALID")
        if rel in seen:
            raise ValueError("REVIEW_DUPLICATE_SOURCE_REF")
        seen.add(rel)
        source_path = _safe_repo_file(root, rel)
        if not source_path.exists():
            missing.append(rel)
            continue
        if not source_path.is_file():
            invalid.append(rel)
            continue
        sizes.append({"path": rel, "bytes": source_path.stat().st_size})
    resource_budget = request.get("resource_budget")
    if not isinstance(resource_budget, dict):
        raise ValueError("REVIEW_INPUT_BUDGET_INVALID")
    budget = resource_budget.get("max_explicit_input_bytes")
    if not isinstance(budget, int) or isinstance(budget, bool) or budget <= 0:
        raise ValueError("REVIEW_INPUT_BUDGET_INVALID")
    source_bytes = sum(x["bytes"] for x in sizes)
    return {"declared_source_count": len(refs), "existing_source_count": len(sizes),
        "missing_source_refs": missing[:8], "invalid_source_refs": invalid[:8],
        "source_ref_bytes": source_bytes,
        "current_bytes": current_bytes,
        "blueprint_bytes": blueprint_bytes,
        "canonical_request_bytes": canonical_request_bytes,
        "source_input_bytes_estimate": source_bytes + current_bytes + blueprint_bytes + canonical_request_bytes,
        "source_input_budget_bytes": budget,
        "largest_source_files": sorted(sizes, key=lambda x: x["bytes"], reverse=True)[:8],
        "current_bytes": current_bytes, "budget_source": request_ref}


def generate_review(*, trigger: str, root: Path = ROOT, construction_units: float | None = None,
                    maintenance_units: float | None = None, resource_unit: str | None = None) -> dict[str, Any]:
    if trigger not in TRIGGERS:
        raise ValueError("REVIEW_TRIGGER_REQUIRED")
    root = root.resolve()
    if not (root / ".git").exists() and not (root / ".git").is_file():
        raise ValueError("REVIEW_GIT_REPOSITORY_REQUIRED")
    records = []
    for commit in _commits(root):
        files, cut = _numstat(root, commit["sha"])
        records.append({**commit, "files": files, "file_rows_truncated": cut})
    evidence = _source_budget(root)
    report = build_construction_health_review(trigger=trigger, samples=records,
        source_input_bytes=evidence["source_input_bytes_estimate"],
        source_input_budget_bytes=evidence["source_input_budget_bytes"],
        construction_units=construction_units, maintenance_units=maintenance_units, resource_unit=resource_unit)
    report["status"] = "BLOCKED" if evidence["missing_source_refs"] or evidence["invalid_source_refs"] else "REVIEW_GENERATED"
    report["source_budget_evidence"] = evidence
    report["limits"] = {"mode": "ON_DEMAND_ONLY", "trigger": trigger,
        "max_recent_commits": MAX_COMMITS, "max_file_rows_per_commit": MAX_FILES_PER_COMMIT,
        "max_declared_source_refs": MAX_SOURCE_REFS,
        "invalid_source_ref_count": len(evidence["invalid_source_refs"]),
        "missing_source_ref_count": len(evidence["missing_source_refs"]),
        "full_diff_content_loaded": False, "audit_history_written": False,
        "external_model_or_metered_service_called": False}
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a bounded retrospective only when triggered.")
    parser.add_argument("--trigger", required=True, choices=TRIGGERS)
    parser.add_argument("--construction-units", type=float)
    parser.add_argument("--maintenance-units", type=float)
    parser.add_argument("--resource-unit", help="Same measurement unit for both usage values.")
    args = parser.parse_args()
    if (args.construction_units is None) != (args.maintenance_units is None):
        parser.error("provide both usage values or neither")
    if args.construction_units is not None and not args.resource_unit:
        parser.error("--resource-unit is required when usage values are provided")
    try:
        report = generate_review(trigger=args.trigger, construction_units=args.construction_units,
            maintenance_units=args.maintenance_units, resource_unit=args.resource_unit)
    except (OSError, ValueError, TypeError, json.JSONDecodeError, subprocess.TimeoutExpired) as exc:
        print(json.dumps({"status": "BLOCKED", "reason_code": str(exc).split(":")[0],
            "trigger": args.trigger, "audit_history_written": False}, indent=2))
        return 2
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "REVIEW_GENERATED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
