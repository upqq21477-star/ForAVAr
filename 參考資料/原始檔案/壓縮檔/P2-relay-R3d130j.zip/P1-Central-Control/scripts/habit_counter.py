"""habit_counter -- deterministic habit-word state + instruction routing outcome (CAP-INSTRUCTION-ROUTING, R3d12zr S3c).

Start: input begins with ! / ！ (USER_DIRECT), or text holding exactly one habit word confirmed THRESHOLD times by the user.
End: ROUTED (event written, then config activated) | UNRESOLVED (cannot decide, nothing activated, ask the user) |
REFUSED (not in the command table or LLM_PROPOSED: fail closed).  Order: append-only event first, activation second.
Resume: event without activation -> only activate; activation without event -> inconsistent, drop it and rewrite both.
Idempotency key = hash of (conversation_id, normalized command).  Confirmation counts are added only on USER_DIRECT input.
State file {habits, activations, suppressed} is written with atomic_write.  Evidence ceiling: SIMULATED_PASS."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import event_log as el
import role_command_router as router
from atomic_write import atomic_write

THRESHOLD = 3
SOURCES = ("USER_DIRECT", "LLM_PROPOSED")


def load_state(path: str | Path) -> dict[str, Any]:
    p = Path(path)
    if not p.exists():
        return {"habits": {}, "activations": {}, "suppressed": []}
    try:
        st = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(st, dict) or not isinstance(st.get("habits"), dict) or not isinstance(st.get("activations"), dict):
            raise ValueError("shape")
    except (ValueError, OSError):
        raise ValueError("STATE_CORRUPT") from None
    st.setdefault("suppressed", [])
    return st


def save_state(path: str | Path, st: dict[str, Any]) -> None:
    atomic_write(path, json.dumps(st, ensure_ascii=False, sort_keys=True, indent=1))


def _user_only(source: str) -> None:
    if source != "USER_DIRECT":
        raise ValueError("USER_DIRECT_REQUIRED")


def register(st: dict[str, Any], term: str, shortcut: str, source: str) -> None:
    _user_only(source)
    st["habits"].setdefault(term, {"shortcut": shortcut, "confirmations": 0})


def confirm(st: dict[str, Any], term: str, source: str) -> int:
    _user_only(source)  # the count is the user's reply, never the model's
    st["habits"][term]["confirmations"] += 1
    return st["habits"][term]["confirmations"]


def suppress(st: dict[str, Any], term: str) -> None:
    if term not in st["suppressed"]:
        st["suppressed"].append(term)


def detect(st: dict[str, Any], text: str) -> dict[str, Any]:
    hits = [t for t, h in sorted(st["habits"].items()) if t in text and t not in st["suppressed"]]
    ready = [t for t in hits if st["habits"][t]["confirmations"] >= THRESHOLD]
    if len(ready) == 1 and len(hits) == 1:
        return {"status": "MATCH", "term": ready[0], "shortcut": st["habits"][ready[0]]["shortcut"]}
    return {"status": "AMBIGUOUS" if len(hits) > 1 else "PENDING" if hits else "NONE", "hits": hits}


def input_key(conversation_id: str, normalized: str) -> str:
    return hashlib.sha256(f"{conversation_id}|{normalized}".encode("utf-8")).hexdigest()[:16]


def _event_exists(log: Any, workflow_id: str, conversation_id: str, normalized: str) -> bool:
    digest = el.dialogue_content_hash(normalized)
    rows = el.read_dialogue(log.events_for("SEGMENT", workflow_id), conversation_id)
    return any(r.get("content_hash") == digest and str(r.get("ref", "")).startswith("ROLE_ROUTE:") for r in rows)


def _out(outcome: str, reason: str = "", **extra: Any) -> dict[str, Any]:
    return {"outcome": outcome, "reason": reason, **extra}


def route_instruction(text: str, *, source: str, conversation_id: str, event_log_path: str | Path, workflow_id: str,
                      occurred_at: str, state_path: str | Path) -> dict[str, Any]:
    if source != "USER_DIRECT":  # LLM_PROPOSED (or anything unknown) never activates a configuration
        return _out("REFUSED", "LLM_PROPOSED_NOT_ACTIVATABLE" if source == "LLM_PROPOSED" else "SOURCE_UNKNOWN")
    try:
        st = load_state(state_path)
    except ValueError as exc:
        return _out("UNRESOLVED", str(exc))  # unreadable state: do not guess, activate nothing
    cmd = (text or "").strip()
    if not cmd.startswith(("!", "\uff01")):
        d = detect(st, cmd)
        if d["status"] != "MATCH":
            return _out("UNRESOLVED", f"HABIT_{d['status']}")  # ask the user; no configuration is activated
        cmd = d["shortcut"]
    norm = router.normalize_command(cmd)
    key = input_key(conversation_id, norm)
    log = el.EventLog(event_log_path)
    has_event = _event_exists(log, workflow_id, conversation_id, norm)
    act = st["activations"].get(key)
    if has_event and act:
        return _out("ROUTED", role_id=act["role_id"], reused=True)
    if act and not has_event:  # activation without an event is inconsistent: deactivate, then rewrite below
        del st["activations"][key]
        save_state(state_path, st)
    try:
        result = router.resolve(norm) if has_event else router.resolve_and_record(
            norm, event_log_path=event_log_path, workflow_id=workflow_id, conversation_id=conversation_id, occurred_at=occurred_at)
    except (ValueError, FileNotFoundError) as exc:
        return _out("REFUSED", str(exc).split(":", 1)[0])  # fail closed; the router already left a trace
    st["activations"][key] = {"role_id": result["role_id"], "profile_id": result["profile_id"], "command": norm}
    save_state(state_path, st)
    return _out("ROUTED", role_id=result["role_id"], reused=False)
