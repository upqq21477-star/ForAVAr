#!/usr/bin/env python3
"""Generic four-stage feature lifecycle (stdlib only). Not tied to any batch name.

Stage 1 blueprint: outline nodes (id, title, summary, depends_on, priority), acyclic todo order.
Stage 2 runs:      every leaf has an entry file and exit_code 0.
Stage 3 loop:      every leaf was called, ended, retired (temp data/docs) and distilled into code.
Stage 4 real run:  `final.status` PROGRAM_EXECUTED_PASS; anything else can never claim done.
Policy data: policy/feature_lifecycle.v1.0.json.  CLI: check <file> | selftest
"""
import json
import sys
from pathlib import Path

MIN_SUMMARY = 10
LOOP_KEYS = ("called", "ended", "retired", "distilled")


class LifecycleError(Exception):
    pass


def new_checklist(change_id, title):
    return {"change_id": change_id, "title": title, "stage": 1, "outline": [], "runs": {}, "loop": {}, "final": {}}


def _leaves(cl):
    parents = {n.get("parent") for n in cl["outline"]}
    return [n["id"] for n in cl["outline"] if n["id"] not in parents]


def _cycle(nodes):
    deps = {n["id"]: [d for d in n.get("depends_on", []) if d in {m["id"] for m in nodes}] for n in nodes}
    state = {}

    def visit(x):
        if state.get(x) == 1:
            return True
        if state.get(x) == 2:
            return False
        state[x] = 1
        if any(visit(d) for d in deps[x]):
            return True
        state[x] = 2
        return False
    return any(visit(x) for x in deps)


def check_stage1(cl):
    nodes, out = cl.get("outline", []), []
    if not nodes:
        return ["NO_OUTLINE: add outline nodes"]
    ids = [n.get("id") for n in nodes]
    for i in {x for x in ids if ids.count(x) > 1}:
        out.append(f"DUP_ID {i}")
    prios = [n.get("priority") for n in nodes]
    for p in {x for x in prios if prios.count(x) > 1}:
        out.append(f"DUP_PRIORITY {p}")
    byid = {n.get("id"): n for n in nodes}
    for n in nodes:
        nid = n.get("id")
        if not n.get("title"):
            out.append(f"NO_TITLE {nid}")
        if len((n.get("summary") or "").strip()) < MIN_SUMMARY:
            out.append(f"SUMMARY_MISSING {nid}")
        if not isinstance(n.get("priority"), int):
            out.append(f"PRIORITY_MISSING {nid}")
        if n.get("parent") is not None and n["parent"] not in byid:
            out.append(f"UNKNOWN_PARENT {nid}->{n['parent']}")
        for d in n.get("depends_on", []):
            if d not in byid:
                out.append(f"UNKNOWN_DEP {nid}->{d}")
            elif isinstance(n.get("priority"), int) and isinstance(byid[d].get("priority"), int) \
                    and byid[d]["priority"] >= n["priority"]:
                out.append(f"ORDER {nid} is ranked before its dependency {d}")
    if _cycle(nodes):
        out.append("CYCLE in depends_on")
    return out


def todo_order(cl):
    leaves = set(_leaves(cl))
    return [n["id"] for n in sorted(cl["outline"], key=lambda n: n["priority"]) if n["id"] in leaves]


def check_stage2(cl):
    r = cl.get("runs", {})
    return [f"NO_RUN {n}" if n not in r else f"BAD_RUN {n}" for n in _leaves(cl)
            if n not in r or not r[n].get("entry") or r[n].get("exit_code") != 0]


def check_stage3(cl):
    lp = cl.get("loop", {})
    return [f"LOOP_OPEN {n}: {k}" for n in _leaves(cl) for k in LOOP_KEYS if lp.get(n, {}).get(k) is not True]


def check_stage4(cl):
    s = cl.get("final", {}).get("status")
    return [] if s == "PROGRAM_EXECUTED_PASS" else [f"NOT_REAL_RUN status={s or 'NOT_EXECUTED'}"]


CHECKS = {1: check_stage1, 2: check_stage2, 3: check_stage3, 4: check_stage4}


def blockers(cl):
    return CHECKS[cl["stage"]](cl)


def advance(cl):
    st = cl["stage"]
    blockers = CHECKS[st](cl)
    if blockers:
        raise LifecycleError(f"stage {st} exit condition not met: " + "; ".join(blockers[:5]))
    if st < 4:
        cl["stage"] = st + 1
    return cl["stage"]


def can_claim_done(cl):
    return cl.get("stage") == 4 and not any(CHECKS[s](cl) for s in (1, 2, 3, 4))


def main(argv):
    if len(argv) >= 3 and argv[1] == "check":
        cl = json.loads(Path(argv[2]).read_text(encoding="utf-8"))
        b = [x for s in range(1, cl["stage"] + 1) for x in CHECKS[s](cl)] if cl["stage"] > 1 else check_stage1(cl)
        print("\n".join(b) or f"STAGE {cl['stage']} OK")
        return 1 if b else 0
    print(__doc__)
    return 2


if __name__ == "__main__":
    sys.exit(main(sys.argv))
