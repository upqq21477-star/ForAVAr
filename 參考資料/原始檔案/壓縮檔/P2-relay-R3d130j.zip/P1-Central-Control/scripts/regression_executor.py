#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Callable

from jsonschema import Draft202012Validator

import regression_selection


ROOT = Path(__file__).resolve().parents[2]
SCHEMA = ROOT / "P1-Central-Control/schemas/regression_execution_result.schema.json"
REGISTRY = ROOT / "P1-Central-Control/regression_selection_registry.json"


class RegressionExecutionError(ValueError):
    pass


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise RegressionExecutionError(f"{path} 必須是 JSON object")
    return value


def validate_result(result: dict[str, Any]) -> None:
    schema = load_json(SCHEMA)
    Draft202012Validator(schema).validate(result)


def _safe_test_paths(test_paths: list[str]) -> list[str]:
    if not test_paths:
        raise RegressionExecutionError("PYTHON_UNITTEST 缺少 test_paths")
    resolved: list[str] = []
    for raw in test_paths:
        if not isinstance(raw, str) or not raw:
            raise RegressionExecutionError("test_paths 必須全部是非空字串")
        path = (ROOT / raw).resolve()
        try:
            path.relative_to(ROOT.resolve())
        except ValueError as exc:
            raise RegressionExecutionError(f"禁止執行 ROOT 外部測試: {raw}") from exc
        if not path.is_file():
            raise RegressionExecutionError(f"找不到回歸測試: {raw}")
        resolved.append(str(path.relative_to(ROOT)))
    return resolved


def run_python_unittest_set(
    regression_set: dict[str, Any],
    *,
    timeout_seconds: int = 900,
    runner: Callable[..., subprocess.CompletedProcess[str]] | None = None,
) -> str:
    if regression_set.get("runner") != "PYTHON_UNITTEST":
        raise RegressionExecutionError(
            "run_python_unittest_set 只接受 PYTHON_UNITTEST"
        )
    if timeout_seconds < 1:
        raise RegressionExecutionError("timeout_seconds 必須 >= 1")

    test_paths = _safe_test_paths(regression_set.get("test_paths", []))
    command = [sys.executable, "-m", "unittest", "-v", *test_paths]
    execute = runner or subprocess.run

    try:
        completed = execute(
            command,
            cwd=ROOT,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return "FAIL"
    except OSError:
        # The runner could not be started; this is missing execution evidence,
        # not evidence that the program itself failed.
        return "NOT_EXECUTED"
    return "PASS" if completed.returncode == 0 else "FAIL"


def execute_selection(
    selection: dict[str, Any],
    *,
    registry: dict[str, dict[str, Any]] | None = None,
    timeout_seconds: int = 900,
    run_set: Callable[[dict[str, Any]], str] | None = None,
    external_result: dict[str, Any] | None = None,
) -> dict[str, Any]:
    regression_selection.validate_report(selection)

    if selection.get("kind") != "REGRESSION_SELECTION":
        raise RegressionExecutionError("M7 只接受 REGRESSION_SELECTION")
    if selection.get("status") != "PASS":
        return {
            "result_id": "M7-" + selection["selection_id"],
            "selection_id": selection["selection_id"],
            "status": "INCOMPLETE",
            "results": [],
        }

    set_registry = registry if registry is not None else regression_selection.load_set_registry(REGISTRY)
    external_map: dict[str, str] = {}
    if external_result is not None:
        validate_result(external_result)
        if external_result.get("selection_id") != selection["selection_id"]:
            raise RegressionExecutionError("external regression result selection_id 不一致")
        for item in external_result.get("results", []):
            set_id = item["regression_set_id"]
            if set_id in external_map:
                raise RegressionExecutionError("external regression result contains duplicate set")
            external_map[set_id] = item["status"]
        unknown_external = sorted(set(external_map) - set(selection.get("selected_regression_sets", [])))
        if unknown_external:
            raise RegressionExecutionError(
                "external regression result contains unselected set: " + ", ".join(unknown_external)
            )

    selected = sorted(set(selection.get("selected_regression_sets", [])))
    if not selected:
        raise RegressionExecutionError("PASS 的 REGRESSION_SELECTION 不得沒有 selected_regression_sets")

    executor = run_set
    results: list[dict[str, str]] = []
    incomplete = False
    failed = False

    for set_id in selected:
        if set_id not in set_registry:
            raise RegressionExecutionError("未知 regression set: " + set_id)
        definition = set_registry[set_id]
        runner_name = definition.get("runner")
        if runner_name == "PYTHON_UNITTEST":
            status = (
                executor(definition)
                if executor is not None
                else run_python_unittest_set(
                    definition,
                    timeout_seconds=timeout_seconds,
                )
            )
            if status not in {"PASS", "FAIL", "NOT_EXECUTED"}:
                raise RegressionExecutionError("回歸執行器回傳非法狀態: " + status)
            if status == "NOT_EXECUTED":
                incomplete = True
                continue
            results.append({
                "regression_set_id": set_id,
                "status": status,
            })
            failed = failed or status == "FAIL"
        elif runner_name == "GITHUB_ACTIONS":
            status = external_map.get(set_id)
            if status in {"PASS", "FAIL"}:
                results.append({
                    "regression_set_id": set_id,
                    "status": status,
                })
                failed = failed or status == "FAIL"
            else:
                incomplete = True
        else:
            raise RegressionExecutionError(
                f"不支援的 regression runner: {runner_name}"
            )

    status = "FAIL" if failed else "INCOMPLETE" if incomplete else "PASS"
    result = {
        "result_id": "M7-" + selection["selection_id"],
        "selection_id": selection["selection_id"],
        "status": status,
        "results": results,
    }
    validate_result(result)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="P1 M7 Regression Executor")
    parser.add_argument("selection")
    parser.add_argument("output")
    parser.add_argument("--registry", default=str(REGISTRY))
    parser.add_argument("--timeout-seconds", type=int, default=900)
    parser.add_argument("--external-result")
    args = parser.parse_args()

    selection = load_json(Path(args.selection))
    result = execute_selection(
        selection,
        registry=regression_selection.load_set_registry(Path(args.registry)),
        timeout_seconds=args.timeout_seconds,
        external_result=load_json(Path(args.external_result)) if args.external_result else None,
    )
    Path(args.output).write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    if result["status"] == "PASS":
        return 0
    if result["status"] == "INCOMPLETE":
        return 2
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
