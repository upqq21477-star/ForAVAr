#!/usr/bin/env python3
"""R-1 垂直切片驅動：！討論 → TASK_SET_ISSUED → canonical Task → 施工 → ResultPacket →
ingestion/Central → ！驗收 → Result → 回到 ！討論；全程寫 hash-chained trace。

只呼叫既有函式（central_controller、packet_layer、repository_result_ingestion、
central_role_interface、event_reducer）；驅動本身不持有 state 規則。
Evidence level: shim jsonschema。Brain Provider = 檔案（見 brain/reply-001.json）。
Run（從 P1-Central-Control）：python3 -B evidence/r1-vertical-slice/run_slice.py ; echo exit=$?
"""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]  # P1-Central-Control
sys.path[:0] = [str(ROOT / "scripts")]

import central_controller  # noqa: E402
import central_role_interface  # noqa: E402
import event_reducer  # noqa: E402
import packet_layer  # noqa: E402
import repository_result_ingestion  # noqa: E402
from event_log import EventLog  # noqa: E402

OUT = HERE / "runs" / "run-001"
WF, TASK = "WF-R1-001", "TASK-R1-001"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha(data: bytes) -> str:
    return "sha256:" + hashlib.sha256(data).hexdigest()


def dump(path: Path, value) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True).encode()
    path.write_bytes(raw + b"\n")
    return sha(raw + b"\n")


class Trace:
    """hash-chained、append-only 的 canonical trace。"""

    def __init__(self, path: Path):
        self.path, self.prev, self.seq = path, "sha256:" + "0" * 64, 0
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")

    def emit(self, event_type: str, actor: str, refs: dict, note: str = "") -> None:
        self.seq += 1
        body = {"seq": self.seq, "ts": now(), "event_type": event_type, "actor": actor,
                "refs": refs, "note": note, "prev_hash": self.prev}
        body["hash"] = sha(json.dumps(body, ensure_ascii=False, sort_keys=True).encode())
        self.prev = body["hash"]
        with self.path.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(body, ensure_ascii=False, sort_keys=True) + "\n")


def verify_chain(path: Path) -> list[dict]:
    prev, events = "sha256:" + "0" * 64, []
    for line in path.read_text(encoding="utf-8").splitlines():
        ev = json.loads(line)
        claimed = ev.pop("hash")
        assert ev["prev_hash"] == prev, f"trace chain broken at seq {ev['seq']}"
        assert sha(json.dumps(ev, ensure_ascii=False, sort_keys=True).encode()) == claimed, "trace hash mismatch"
        prev = claimed
        ev["hash"] = claimed
        events.append(ev)
    return events


def probe_replay() -> dict:
    """真實觀察：D10 情境下，replay 重建了什麼（只用既有 EventLog／reducer）。"""
    sys.path.insert(0, str(ROOT / "tests"))
    import test_parallel_scheduler as fx
    t = fx.ParallelSchedulerTests()
    a, c = t.make_segment("A"), t.make_segment("C", dependencies=["A"])
    store, ex, di = {"A": a, "C": c}, {}, {}
    state = central_controller.init_state("WF-P5", "TASK-P5")
    state = central_controller.queue_segment(central_controller.queue_segment(state, a), c)
    with tempfile.TemporaryDirectory() as tmp:
        log = EventLog(Path(tmp) / "events.jsonl")
        state, packets = central_controller.dispatch(state, event_log=log, execution_store=ex, max_concurrency=2)
        state = central_controller.receive_result(
            state, t.make_result(packets[0], "FAIL"), event_log=log, execution_store=ex,
            distillation_store=di, segment_store=store)
        events, _ = log.read_recoverable()
        replayed = event_reducer.replay_workflow(event_reducer.initial_workflow_projection("WF-P5"), events)
    seg_replayed = event_reducer.replay_segments(event_reducer.initial_segment_projection(), events, workflow_id="WF-P5")
    seg_view_live = event_reducer.segment_control_view(state)
    seg_view_replayed = event_reducer.segment_control_view(seg_replayed)
    return {
        "scenario": "A=FAIL, C depends on A (D10)",
        "event_count": len(events),
        "control_view_fields": sorted(event_reducer.projection_control_view(state)),
        "control_view_matches": event_reducer.projection_control_view(state) == event_reducer.projection_control_view(replayed),
        "live_state_has_blocked_segments": bool(state.get("blocked_segments")),
        "live_completed_segment_count": len(state.get("completed_segments", [])),
        "segment_tables": sorted(k for k, v in seg_view_replayed.items() if isinstance(v, list)),
        "segment_view_matches": seg_view_live == seg_view_replayed,
        "segment_tables_replayable": seg_view_live == seg_view_replayed,
    }


def main() -> int:
    if OUT.exists():
        shutil.rmtree(OUT)
    trace = Trace(OUT / "trace.jsonl")
    errors: list[str] = []

    # 1. BRAIN（！討論）：檔案 Provider
    reply_path = HERE / "brain" / "reply-001.json"
    reply = json.loads(reply_path.read_text(encoding="utf-8"))
    act = central_role_interface.activate(
        {"request_id": "R1-REQ-DISCUSS", "operation": "ROLE_ACTIVATE",
         "role_id": "ROLE:CONTROL_RESEARCH", "activation_command": "！討論"})
    trace.emit("BRAIN_REPLY_RECEIVED", "ROLE:CONTROL_RESEARCH",
               {"reply_hash": sha(reply_path.read_bytes()), "provider": reply["provider"],
                "role_admission": act.get("status")})
    # TASK_SET_ISSUED 的最小驗證（BP-4 尚未把它放進角色契約；此處是驅動內的暫行檢查）
    assert reply["status"] == "TASK_SET_ISSUED" and reply["tasks"] and reply["correlation_id"]
    trace.emit("TASK_SET_ISSUED", "ROLE:CONTROL_RESEARCH",
               {"task_set_ref": reply["task_set_ref"], "task_refs": [t["segment_id"] for t in reply["tasks"]],
                "revision": reply["revision"], "correlation_id": reply["correlation_id"]})

    # 2. canonical Task：Work Segment → queue → dispatch（既有 Central）
    spec = reply["tasks"][0]
    segment = {
        "segment_id": spec["segment_id"], "workflow_id": WF, "system_id": "SYSTEM-P1",
        "skill_id": "r1-replay-probe", "skill_version": "1.0.0", "objective": spec["objective"],
        "input_scope": "r1-vertical-slice", "input_refs": ["ARTIFACT:" + reply["task_set_ref"].replace(":", "-").lower()],
        "requested_outputs": spec["requested_outputs"], "constraints": [],
        "stop_condition": ["observation_written"], "failure_condition": ["probe_error"],
        "dependency_refs": [],
        "completion_contract": {"required_outputs": spec["requested_outputs"], "handoff_allowed": True},
        "execution_record_ref": f"ARTIFACT:execution-{spec['segment_id']}",
        "context_cohort_id": "COHORT-R1",
        "context_budget": {"estimated_total_context": 100, "target_context_budget": 1000,
                           "hard_context_ceiling": 2000, "risk": "LOW"},
        "retry_policy": {"max_attempts": 1, "retry_on": []}, "timeout_ms": 60000,
    }
    state = central_controller.init_state(WF, TASK)
    state = central_controller.queue_segment(state, segment)
    trace.emit("TASK_QUEUED", "CENTRAL", {"segment_id": segment["segment_id"]})
    execution_store: dict = {}
    log_path = OUT / "central-events.jsonl"
    state, packets = central_controller.dispatch(
        state, event_log=EventLog(log_path), execution_store=execution_store, max_concurrency=1)
    task_packet = packets[0]
    persist = {
        "state": dump(OUT / "state" / "central_state.dispatched.json", state),
        "task_packet": dump(OUT / "state" / "task_packet.json", task_packet),
        "envelopes": dump(OUT / "state" / "execution_envelopes.json", list(execution_store.values())),
        "segment_store": dump(OUT / "state" / "segment_store.json", {segment["segment_id"]: segment}),
    }
    trace.emit("TASK_DISPATCHED", "CENTRAL", {"attempt_id": task_packet["attempt_id"], **persist})

    # 3. 施工：先照實問角色層是否准許 ！施工（真實 repo 狀態），再以 segment 路徑執行
    build_gate = central_role_interface.activate(
        {"request_id": "R1-REQ-BUILD", "operation": "ROLE_ACTIVATE",
         "role_id": "ROLE:EXECUTOR", "activation_command": "！施工"})
    trace.emit("ROLE_ADMISSION_CHECKED", "ROLE:EXECUTOR",
               {"command": "！施工", "status": build_gate.get("status"), "admitted": build_gate.get("admitted"),
                "reason_codes": build_gate.get("reason_codes")},
               "角色層以真實 P1-CURRENT 判斷；本任務走 segment 路徑，角色層結果僅作紀錄（D3）")
    observation = probe_replay()
    obs_hash = dump(OUT / "artifacts" / "replay-observation-001.json", observation)
    result_in = {
        "decision_code": "WORK_COMPLETE", "output_refs": ["ARTIFACT:replay-observation-001"],
        "unresolved": [], "evidence_refs": ["EVIDENCE:r1-001"], "provenance_refs": ["PROVENANCE:r1-001"],
        "observed_usage": {"model_calls": 0, "tool_calls": 1, "wall_time_ms": 1}, "usage_observed": True,
    }
    result = packet_layer.build_result_packet(task_packet, result_in)
    env = execution_store[task_packet["execution_record_ref"]]
    evidence = [{"object_id": "EVIDENCE:r1-001", "kind": "EVIDENCE", "schema_version": "1.0",
                 "content_hash": obs_hash, "source_ref": task_packet["input_refs"][0],
                 "claim_ref": result["object_id"], "relation": "SUPPORTS",
                 "captured_at": env["execution_record"]["start_time"]}]
    provenance = [{"object_id": "PROVENANCE:r1-001", "kind": "PROVENANCE", "schema_version": "1.0",
                   "content_hash": obs_hash, "subject_ref": result["object_id"],
                   "activity_ref": env["execution_record"]["execution_record_ref"],
                   "agent_ref": f"SKILL:{result['skill_id']}-{result['skill_version']}",
                   "input_refs": list(task_packet["input_refs"]), "output_refs": list(result["output_refs"]),
                   "relation": "WAS_GENERATED_BY"}]
    r_hash = dump(OUT / "state" / "result_packet.json", result)
    dump(OUT / "state" / "evidence.json", evidence)
    dump(OUT / "state" / "provenance.json", provenance)
    trace.emit("EXECUTOR_RESULT_PRODUCED", "SKILL:r1-replay-probe",
               {"result_id": result["result_id"], "result_hash": r_hash, "artifact_hash": obs_hash})

    # 4. ingestion → Central（從檔案重新載入，模擬 repository 持久化邊界）
    load = lambda name: json.loads((OUT / "state" / name).read_text(encoding="utf-8"))
    ingested = repository_result_ingestion.ingest(
        result_packet=load("result_packet.json"), task_packet=load("task_packet.json"),
        current_state=load("central_state.dispatched.json"),
        execution_envelopes=load("execution_envelopes.json"),
        event_log_path=log_path, segment_store=load("segment_store.json"),
        evidence_records=load("evidence.json"), provenance_records=load("provenance.json"))
    final = ingested["central_state"]
    s_hash = dump(OUT / "state" / "central_state.final.json", final)
    trace.emit("RESULT_INGESTED", "CENTRAL",
               {"result_id": result["result_id"], "terminal_state": final.get("terminal_state"),
                "status": final.get("status"), "state_hash": s_hash,
                "boundary": ingested["ingestion"]["boundary"]})

    # 5. ！驗收：機械檢查（Brain 在 reply 中定義的 acceptance_checks）；判決是獨立紀錄，不進 scheduler retry 路徑（D4）
    verify_gate = central_role_interface.activate(
        {"request_id": "R1-REQ-VERIFY", "operation": "ROLE_ACTIVATE",
         "role_id": "ROLE:VERIFIER", "activation_command": "！驗收"})
    rerun = probe_replay()
    checks = {
        "ARTIFACT_EXISTS_AND_HASH_MATCHES_EVIDENCE":
            sha((OUT / "artifacts" / "replay-observation-001.json").read_bytes()) == load("evidence.json")[0]["content_hash"],
        "OBSERVATION_REPRODUCIBLE_BY_INDEPENDENT_RERUN": rerun == observation,
        "OBSERVATION_STATES_SEGMENT_TABLE_REPLAYABILITY": "segment_tables_replayable" in observation,
    }
    missing = [c for c in spec["acceptance_checks"] if c not in checks]
    verdict = {"verdict": "PASS" if all(checks.values()) and not missing else "FAIL",
               "checks": checks, "unknown_checks": missing, "verifier_kind": "MECHANICAL_SCRIPT",
               "semantic_review": "NOT_PERFORMED（交回 Brain）", "role_admission": verify_gate.get("status"),
               "result_ref": result["result_id"]}
    v_hash = dump(OUT / "verdicts" / "verdict-001.json", verdict)
    trace.emit("VERDICT_RECORDED", "ROLE:VERIFIER", {"verdict": verdict["verdict"], "verdict_hash": v_hash})

    # 6. 回到 ！討論：機械投影（不含語意詮釋）
    inbox = {"status": "NEEDS_BRAIN", "correlation_id": reply["correlation_id"],
             "task_set_ref": reply["task_set_ref"], "result_ref": result["result_id"],
             "verdict_ref": "verdicts/verdict-001.json", "verdict": verdict["verdict"],
             "central_terminal_state": final.get("terminal_state"),
             "observation": observation,
             "needs_decision": "觀察顯示的 replay 覆蓋範圍是否構成要處理的缺口，由 Brain 判讀。"}
    i_hash = dump(OUT / "brain" / "inbox-001.json", inbox)
    trace.emit("RETURNED_TO_BRAIN", "CENTRAL", {"inbox_hash": i_hash, "correlation_id": inbox["correlation_id"]})

    # 7. 閉環不變量
    events = verify_chain(OUT / "trace.jsonl")
    order = [e["event_type"] for e in events]
    expected = ["BRAIN_REPLY_RECEIVED", "TASK_SET_ISSUED", "TASK_QUEUED", "TASK_DISPATCHED",
                "ROLE_ADMISSION_CHECKED", "EXECUTOR_RESULT_PRODUCED", "RESULT_INGESTED",
                "VERDICT_RECORDED", "RETURNED_TO_BRAIN"]
    if order != expected:
        errors.append(f"trace order mismatch: {order}")
    if final.get("terminal_state") != "WORKFLOW_COMPLETE":
        errors.append(f"terminal_state={final.get('terminal_state')}")
    pairs = [(c["segment_id"], c["decision_code"]) for c in final["completed_segments"]]
    if len(pairs) != len(set(pairs)):
        errors.append("completed_segments duplicated")
    if verdict["verdict"] != "PASS":
        errors.append("verdict != PASS")
    if inbox["correlation_id"] != next(e for e in events if e["event_type"] == "TASK_SET_ISSUED")["refs"]["correlation_id"]:
        errors.append("correlation_id not preserved")
    summary = {"closed_loop": not errors, "errors": errors, "trace_events": len(events),
               "verdict": verdict["verdict"], "terminal_state": final.get("terminal_state"),
               "brain_provider": reply["provider"],
               "role_admission": {"！討論": act.get("status"), "！施工": build_gate.get("status"),
                                  "！驗收": verify_gate.get("status")},
               "build_reason_codes": build_gate.get("reason_codes"), "observation": observation}
    dump(OUT / "run-summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == "__main__":
    raise SystemExit(main())
