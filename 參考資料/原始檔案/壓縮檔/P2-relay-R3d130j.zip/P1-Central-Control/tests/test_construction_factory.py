import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from construction_factory import execute


class ConstructionFactoryTests(unittest.TestCase):
    def _request(self, work: Path, target_id: str = "CAP-FACTORY"):
        control = work / "P1-Central-Control"
        control.mkdir(parents=True)
        (control / "capability_registry.json").write_text(
            json.dumps({
                "version": "1.0",
                "capabilities": [
                    {
                        "capability_id": "CAP-OLD",
                        "class": "CONTROL",
                        "implementation": "CANONICAL",
                        "levels": [0],
                        "kind": "CONTROL",
                        "context_tier": "C1",
                        "dependencies": [],
                        "retirement_state": "ACTIVE"
                    }
                ]
            }),
            encoding="utf-8",
        )
        (work / "semantic.json").write_text(
            json.dumps({
                "status": "PASS",
                "architecture_validated": True,
                "invariants": ["registry_identity_is_unique", "construction_is_reproducible"]
            }),
            encoding="utf-8",
        )
        (work / "candidate.json").write_text(
            json.dumps({
                "capability_id": target_id,
                "class": "CONTROL",
                "implementation": "CANONICAL",
                "levels": [0, 1],
                "kind": "CONTROL",
                "context_tier": "C1",
                "dependencies": [],
                "retirement_state": "ACTIVE"
            }),
            encoding="utf-8",
        )
        contract = {
            "schema_version": "1.0",
            "lifecycle_id": "FACTORY-TEST",
            "applies_to": "CAPABILITY",
            "stage_order": [
                "SEMANTIC_SPEC",
                "SEMANTIC_SIMULATION",
                "DISTILL",
                "DISTILLED_VALIDATION",
                "CODE_COMPILE",
                "CODE_ACCEPTANCE",
                "FINALIZE"
            ],
            "stages": [
                {
                    "stage_id": "SEMANTIC_SPEC",
                    "op": "VALIDATE_SEMANTIC_SPEC",
                    "inputs": ["semantic.json"]
                },
                {
                    "stage_id": "SEMANTIC_SIMULATION",
                    "op": "RUN_COMMAND",
                    "outputs": ["simulation.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('simulation.json').write_text('{\"status\":\"PASS\"}', encoding='utf-8')"
                    ]
                },
                {
                    "stage_id": "DISTILL",
                    "op": "RUN_COMMAND",
                    "inputs": ["simulation.json"],
                    "outputs": ["distilled.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('distilled.json').write_text('{\"status\":\"PASS\",\"rules\":[1]}', encoding='utf-8')"
                    ]
                },
                {
                    "stage_id": "DISTILLED_VALIDATION",
                    "op": "RUN_COMMAND",
                    "inputs": ["distilled.json"],
                    "outputs": ["validated.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('validated.json').write_text('{\"status\":\"PASS\"}', encoding='utf-8')"
                    ]
                },
                {
                    "stage_id": "CODE_COMPILE",
                    "op": "RUN_COMMAND",
                    "inputs": ["validated.json"],
                    "outputs": ["generated.py"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('generated.py').write_text('VALUE = 42\\n', encoding='utf-8')"
                    ]
                },
                {
                    "stage_id": "CODE_ACCEPTANCE",
                    "op": "RUN_COMMAND",
                    "inputs": ["generated.py"],
                    "command": [sys.executable, "-m", "py_compile", "generated.py"]
                },
                {
                    "stage_id": "FINALIZE",
                    "op": "FINALIZE"
                }
            ]
        }
        (work / "construction.json").write_text(
            json.dumps(contract), encoding="utf-8"
        )
        return {
            "request_id": "REQ-FACTORY-001",
            "target_type": "CAPABILITY",
            "target_id": target_id,
            "semantic_spec": "semantic.json",
            "lifecycle_contract": "construction.json",
            "registration": {
                "target_type": "CAPABILITY",
                "target_id": target_id,
                "mode": "CREATE_NEW",
                "artifact_path": "candidate.json"
            }
        }

    def test_factory_dry_run_does_not_modify_registry(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._request(work)
            before = (work / "P1-Central-Control/capability_registry.json").read_text()
            result = execute(request, base_dir=work, apply=False)
            after = (work / "P1-Central-Control/capability_registry.json").read_text()
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["applied"])
        self.assertEqual(before, after)
        self.assertEqual(result["before_sha256"], result["after_sha256"])

    def test_factory_apply_updates_registry_atomically(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._request(work)
            result = execute(request, base_dir=work, apply=True)
            document = json.loads(
                (work / "P1-Central-Control/capability_registry.json").read_text()
            )
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["applied"])
        self.assertNotEqual(result["before_sha256"], result["after_sha256"])
        ids = {row["capability_id"] for row in document["capabilities"]}
        self.assertIn("CAP-FACTORY", ids)

    def test_factory_blocks_without_finalized_construction(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._request(work)
            (work / "semantic.json").write_text(
                json.dumps({
                    "status": "PASS",
                    "architecture_validated": False,
                    "invariants": ["registry_identity_is_unique"]
                }),
                encoding="utf-8",
            )
            result = execute(request, base_dir=work, apply=True)
        self.assertEqual(result["status"], "BLOCK")
        self.assertFalse(result["applied"])


if __name__ == "__main__":
    unittest.main()
