import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from construction_lifecycle import execute


class ConstructionLifecycleTests(unittest.TestCase):
    def _base_contract(self, work: Path):
        work.joinpath("semantic.json").write_text(
            json.dumps(
                {
                    "status": "PASS",
                    "architecture_validated": True,
                    "invariants": ["state_is_deterministic", "handoff_is_explicit"],
                }
            ),
            encoding="utf-8",
        )
        return {
            "schema_version": "1.0",
            "lifecycle_id": "TEST-CONS-01",
            "applies_to": "FUNCTION",
            "stage_order": [
                "SEMANTIC_SPEC",
                "SEMANTIC_SIMULATION",
                "DISTILL",
                "DISTILLED_VALIDATION",
                "CODE_COMPILE",
                "CODE_ACCEPTANCE",
                "FINALIZE",
            ],
            "stages": [
                {
                    "stage_id": "SEMANTIC_SPEC",
                    "op": "VALIDATE_SEMANTIC_SPEC",
                    "inputs": ["semantic.json"],
                },
                {
                    "stage_id": "SEMANTIC_SIMULATION",
                    "op": "RUN_COMMAND",
                    "outputs": ["simulation.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('simulation.json').write_text('{\"status\":\"PASS\"}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "DISTILL",
                    "op": "RUN_COMMAND",
                    "inputs": ["simulation.json"],
                    "outputs": ["distilled.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('distilled.json').write_text('{\"status\":\"PASS\",\"rules\":[1]}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "DISTILLED_VALIDATION",
                    "op": "RUN_COMMAND",
                    "inputs": ["distilled.json"],
                    "outputs": ["distilled_validation.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('distilled_validation.json').write_text('{\"status\":\"PASS\"}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "CODE_COMPILE",
                    "op": "RUN_COMMAND",
                    "inputs": ["distilled_validation.json"],
                    "outputs": ["generated.py"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('generated.py').write_text('VALUE = 1\\n', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "CODE_ACCEPTANCE",
                    "op": "RUN_COMMAND",
                    "inputs": ["generated.py"],
                    "command": [sys.executable, "-m", "py_compile", "generated.py"],
                },
                {
                    "stage_id": "FINALIZE",
                    "op": "FINALIZE",
                },
            ],
        }

    def test_full_lifecycle_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = execute(self._base_contract(Path(tmp)), tmp)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["finalized"])
        self.assertEqual(result["completed_stage"], "FINALIZE")
        self.assertEqual(len(result["stage_results"]), 7)

    def test_semantic_failure_blocks_before_distill(self):
        with tempfile.TemporaryDirectory() as tmp:
            contract = self._base_contract(Path(tmp))
            Path(tmp, "semantic.json").write_text(
                json.dumps(
                    {
                        "status": "PASS",
                        "architecture_validated": False,
                        "invariants": ["state_is_deterministic"],
                    }
                ),
                encoding="utf-8",
            )
            result = execute(contract, tmp)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["completed_stage"], "SEMANTIC_SPEC")
        self.assertEqual(len(result["stage_results"]), 1)
        self.assertEqual(result["stage_results"][0]["status"], "FAIL")

    def test_simulation_failure_never_reaches_distill(self):
        with tempfile.TemporaryDirectory() as tmp:
            contract = self._base_contract(Path(tmp))
            contract["stages"][1]["command"] = [
                sys.executable,
                "-c",
                "raise SystemExit(7)",
            ]
            result = execute(contract, tmp)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["completed_stage"], "SEMANTIC_SIMULATION")
        self.assertEqual(len(result["stage_results"]), 2)

    def test_stage_order_is_mandatory(self):
        with tempfile.TemporaryDirectory() as tmp:
            contract = self._base_contract(Path(tmp))
            contract["stage_order"][1] = "DISTILL"
            with self.assertRaises(ValueError):
                execute(contract, tmp)


if __name__ == "__main__":
    unittest.main()
