#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import control_gate_runtime as gate


class M23P14ControlGateIntegrationTests(unittest.TestCase):
    def test_semantic_impact_block_is_incomplete(self):
        self.assertEqual(gate.classify_semantic_impact(3, "BLOCK"), "INCOMPLETE")

    def test_semantic_impact_unexpected_failure_is_fail(self):
        self.assertEqual(gate.classify_semantic_impact(1, "FAIL"), "FAIL")

    def test_repository_independence_unknown_is_incomplete(self):
        self.assertEqual(gate.classify_repository_independence("UNKNOWN"), "INCOMPLETE")

    def test_repository_independence_violation_is_fail(self):
        self.assertEqual(gate.classify_repository_independence("VIOLATION"), "FAIL")

    def test_repository_independence_pass_is_pass(self):
        self.assertEqual(gate.classify_repository_independence("INDEPENDENT"), "PASS")


if __name__ == "__main__":
    unittest.main()
