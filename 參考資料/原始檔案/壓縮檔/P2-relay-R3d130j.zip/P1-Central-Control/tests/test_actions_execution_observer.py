#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _quarantine import quarantined  # noqa: E402

ROOT = Path(__file__).resolve().parents[2]
WORKFLOW = ROOT / ".github/workflows/p1-actions-execution-observer.yml"


class ActionsExecutionObserverWorkflowTests(unittest.TestCase):
    @quarantined("test_actions_execution_observer.ActionsExecutionObserverWorkflowTests.test_observer_targets_control_gate_completion", "LEGACY_ACTIONS_CARRIER")
    def test_observer_targets_control_gate_completion(self):
        workflow = WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("workflow_run:", workflow)
        self.assertIn("P1 Control Gate", workflow)
        self.assertIn("types:", workflow)
        self.assertIn("- completed", workflow)

    @quarantined("test_actions_execution_observer.ActionsExecutionObserverWorkflowTests.test_observer_uses_execution_probe_and_m9_observation", "LEGACY_ACTIONS_CARRIER")
    def test_observer_uses_execution_probe_and_m9_observation(self):
        workflow = WORKFLOW.read_text(encoding="utf-8")
        self.assertIn(
            "P1-Central-Control/scripts/actions_execution_probe.py",
            workflow,
        )
        self.assertIn("--observation-output", workflow)
        self.assertIn("github_actions_regression_observation.schema.json", workflow)
        self.assertIn("actions: read", workflow)

    @quarantined("test_actions_execution_observer.ActionsExecutionObserverWorkflowTests.test_observer_persists_diagnostic_and_observation_artifacts", "LEGACY_ACTIONS_CARRIER")
    def test_observer_persists_diagnostic_and_observation_artifacts(self):
        workflow = WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("actions/upload-artifact@v4", workflow)
        self.assertIn("p1-actions-execution-observation", workflow)
        self.assertIn("p1-actions-execution-diagnostic.json", workflow)
        self.assertIn("p1-github-actions-observation.json", workflow)
        self.assertIn("p1-actions-execution-current-truth.json", workflow)
        self.assertIn("P1-Central-Control/scripts/actions_execution_truth_adapter.py", workflow)
        self.assertIn("if: always()", workflow)


if __name__ == "__main__":
    unittest.main()
