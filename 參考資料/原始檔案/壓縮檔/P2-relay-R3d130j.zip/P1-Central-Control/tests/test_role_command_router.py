from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from role_command_router import resolve  # noqa: E402


def test_construction_command_locks_executor():
    result = resolve("！施工")
    assert result["status"] == "PASS"
    assert result["role_id"] == "ROLE:EXECUTOR"
    assert result["profile_id"] == "IP:CONSTRUCTION-EXECUTOR"
    assert result["mode"] == "CONSTRUCTION"
    assert result["session_state"] == "LOCKED"
    assert result["amnesia_required"] is True


def test_acceptance_command_locks_verifier():
    result = resolve("！驗收")
    assert result["role_id"] == "ROLE:VERIFIER"
    assert result["profile_id"] == "IP:ACCEPTANCE-VERIFIER"
    assert result["mode"] == "ACCEPTANCE"


def test_discussion_command_uses_control_role():
    result = resolve("！討論")
    assert result["role_id"] == "ROLE:CONTROL_RESEARCH"
    assert result["profile_id"] == "IP:CONTROL-DISCUSSION"
    assert result["mode"] == "DISCUSSION"
    assert result["amnesia_required"] is False


def test_guidance_is_not_a_fourth_canonical_role():
    result = resolve("！指導")
    assert result["role_id"] == "ROLE:CONTROL_RESEARCH"
    assert result["profile_id"] == "IP:GUIDANCE-REVIEW"
    assert result["mode"] == "GUIDANCE"


def test_unknown_command_blocks():
    try:
        resolve("！不存在")
    except ValueError as exc:
        assert str(exc).startswith("UNKNOWN_ROLE_COMMAND:")
    else:
        raise AssertionError("unknown command must block")


def _unknown(cmd):
    try:
        resolve(cmd)
    except ValueError as exc:
        return str(exc).startswith("UNKNOWN_ROLE_COMMAND:")
    return False


def test_ascii_bang_maps_to_fullwidth_for_registered_roles():
    for ascii_cmd, full, role in (("!施工", "！施工", "ROLE:EXECUTOR"), ("!驗收", "！驗收", "ROLE:VERIFIER"),
                                  ("!討論", "！討論", "ROLE:CONTROL_RESEARCH"), ("!指導", "！指導", "ROLE:CONTROL_RESEARCH")):
        a, f = resolve(ascii_cmd), resolve(full)
        assert a == f and a["role_id"] == role and a["activation_command"] == full


def test_ascii_bang_does_not_reach_skill_layer_commands():
    for cmd in ("!備料", "！備料", "!研究", "!"):
        assert _unknown(cmd), cmd


def test_only_a_leading_ascii_bang_is_mapped():
    for cmd in ("施工!", "！施工!", " !施工", "!!施工", "!！施工"):
        assert _unknown(cmd), cmd


def test_mutation_identity_normalizer_breaks_ascii_route():
    import role_command_router as router
    real = router.normalize_command
    router.normalize_command = lambda c: c
    try:
        assert _unknown("!施工")
    finally:
        router.normalize_command = real
    assert resolve("!施工")["role_id"] == "ROLE:EXECUTOR"


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)
