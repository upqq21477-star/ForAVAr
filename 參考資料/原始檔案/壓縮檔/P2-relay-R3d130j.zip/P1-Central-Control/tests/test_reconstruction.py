#!/usr/bin/env python3
"""CS-1 B5：Blueprint／Reconstruction Input Set／Clean Build gate（SIMULATION_ONLY）。"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import reconstruction as rc  # noqa: E402

CC = "P1-Central-Control/"
NAMES = ["blueprint", "reconstruction_input_set", "canonical_identity", "canonical_common"]


def _mini_blueprint() -> dict:
    t = CC + "tests/test_ok.py"
    return {
        "object_id": "BLUEPRINT:9.0", "kind": "BLUEPRINT", "schema_version": "1.0", "blueprint_version": "9.0", "status": "CURRENT",
        "supersedes": "BASELINE:NONE", "architecture": [{"layer": "L", "owns": "x"}], "responsibilities": {"R": "x"},
        "contracts": [{"contract_id": "C", "ref": CC + "policy/p.json"}],
        "invariants": [{"invariant_id": "I", "statement": "s", "test_ref": t}],
        "components": [
            {"component_id": "C-CODE", "class": "REQUIRED", "include": [CC + "scripts/**", CC + "policy/**", CC + "tests/**", CC + "*.json",
                                                                          CC + "canonical/**", CC + "schemas/**"], "responsibility": "x"},
            {"component_id": "C-DOCS", "class": "OPTIONAL", "include": ["docs/**"], "responsibility": "x"}],
        "reconstruction_rules": ["r"], "acceptance_rules": ["a"], "lifecycle_rules": ["l"], "external_dependency_rules": ["stdlib"],
        "security_boundaries": ["s"],
        "acceptance_requirements": [{"requirement_id": "AR-T", "kind": "UNITTEST", "start_dir": CC + "tests", "pattern": "test_*.py",
                                     "min_tests": 1, "timeout_sec": 60}]}


class MiniRepo(unittest.TestCase):
    """合成小 repo：只用本模組的 schema 與一個必過測試，不碰真實 repo。"""

    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.root = Path(tmp.name) / "repo"
        self.dest = Path(tmp.name) / "build"
        for rel in [CC + "policy/reconstruction.v1.0.json"] + [f"{CC}schemas/{n}.schema.json" for n in NAMES]:
            (self.root / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / rel, self.root / rel)
        reg = {"objects": [{"kind": n.upper(), "schema": f"{CC}schemas/{n}.schema.json"} for n in NAMES[:2]]}
        self.write(CC + "canonical/canonical_object_registry.json", reg)
        self.write(CC + "capability_registry.json", {"capabilities": [{"capability_id": "CAP-X"}]})
        self.write(CC + "policy/p.json", {"a": 1})
        self.text(CC + "tests/test_ok.py", "import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.assertTrue(True)\n")
        self.text(CC + "scripts/m.py", "X = 1\n")
        self.text("docs/old.md", "舊歷史")
        self.bp_path = self.root / rc.policy()["blueprint_path"]
        self.set_blueprint(_mini_blueprint())

    def write(self, rel: str, obj: object) -> None:
        self.text(rel, json.dumps(obj, ensure_ascii=False))

    def text(self, rel: str, s: str) -> None:
        p = self.root / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(s, encoding="utf-8")

    def set_blueprint(self, bp: dict) -> None:
        rc.seal(bp, "blueprint")
        self.bp_path.write_text(json.dumps(bp, ensure_ascii=False), encoding="utf-8")

    def gate(self, **kw):
        return rc.reconstruct(self.root, self.dest, **kw)

    def test_full_gate_passes_and_omits_optional(self) -> None:
        rc.write_input_set(self.root)
        rep = self.gate()
        self.assertEqual((rep["status"], rep["tests_ran"]), ("RECONSTRUCTED", 1), rep)
        self.assertFalse((self.dest / "docs").exists())  # OPTIONAL 不進 Clean Build
        self.assertTrue((self.dest / CC / "scripts" / "m.py").is_file())

    def test_no_behavioral_is_not_accepted(self) -> None:
        rc.write_input_set(self.root)
        self.assertEqual(self.gate(run_behavioral=False)["status"], "PARTIAL_NOT_ACCEPTED")

    def test_missing_input_set_blocks(self) -> None:
        rep = self.gate()
        self.assertEqual((rep["status"], rep["stage"], rep["reasons"]), ("RECONSTRUCTION_BLOCKED", "INPUT_SET", ["INPUT_SET_MISSING"]))

    def test_stale_input_set_names_component(self) -> None:
        rc.write_input_set(self.root)
        self.text(CC + "scripts/m.py", "X = 2\n")
        rep = self.gate()
        self.assertEqual(rep["reasons"], ["INPUT_SET_STALE:C-CODE"])

    def test_optional_change_does_not_stale(self) -> None:
        rc.write_input_set(self.root)
        self.text("docs/old.md", "改過的舊歷史")
        self.assertEqual(self.gate()["status"], "RECONSTRUCTED")

    def test_unowned_and_overlap_blocked(self) -> None:
        rc.write_input_set(self.root)
        self.text("stray.txt", "x")
        self.assertIn("UNOWNED_FILE:stray.txt", self.gate()["reasons"])
        bp = _mini_blueprint()
        bp["components"].append({"component_id": "C-DUP", "class": "OPTIONAL", "include": [CC + "scripts/**"], "responsibility": "x"})
        (self.root / "stray.txt").unlink()
        self.set_blueprint(bp)
        self.assertTrue(any(r.startswith("OVERLAPPING_OWNERSHIP:") for r in self.gate()["reasons"]))

    def test_tampered_blueprint_blocked(self) -> None:
        rc.write_input_set(self.root)
        bp = json.loads(self.bp_path.read_text(encoding="utf-8"))
        bp["responsibilities"]["R"] = "改過"
        self.bp_path.write_text(json.dumps(bp, ensure_ascii=False), encoding="utf-8")
        self.assertTrue(self.gate()["reasons"][0].startswith("BLUEPRINT_INVALID"))

    def test_failing_test_blocks_behavioral(self) -> None:
        self.text(CC + "tests/test_ok.py", "import unittest\nclass T(unittest.TestCase):\n    def test_a(self):\n        self.fail('x')\n")
        rc.write_input_set(self.root)
        rep = self.gate()
        self.assertEqual((rep["status"], rep["stage"]), ("RECONSTRUCTION_BLOCKED", "BEHAVIORAL"))
        self.assertTrue(rep["reasons"][0].startswith("BEHAVIOR_FAILED"))

    def test_zero_tests_is_not_a_pass(self) -> None:
        bp = _mini_blueprint()
        bp["acceptance_requirements"][0]["min_tests"] = 5
        self.set_blueprint(bp)
        rc.write_input_set(self.root)
        self.assertTrue(self.gate()["reasons"][0].startswith("NO_TESTS_RAN"))

    def test_hidden_dependency_on_non_input_fails(self) -> None:
        """測試偷讀 OPTIONAL 檔 → 乾淨建置中該檔不存在 → BEHAVIOR_FAILED（舊資料不能成為必要輸入）。"""
        self.text(CC + "tests/test_ok.py", "import unittest, pathlib\nclass T(unittest.TestCase):\n    def test_a(self):\n"
                  "        pathlib.Path('docs/old.md').read_text()\n")
        rc.write_input_set(self.root)
        self.assertEqual(self.gate()["stage"], "BEHAVIORAL")

    def test_syntax_error_and_bad_json_blocked(self) -> None:
        self.text(CC + "scripts/bad.py", "def (:\n")
        rc.write_input_set(self.root)
        self.assertEqual(self.gate()["stage"], "STRUCTURAL")
        (self.root / CC / "scripts" / "bad.py").unlink()
        self.text(CC + "policy/p.json", "{not json")
        rc.write_input_set(self.root)
        rep = self.gate()
        self.assertEqual(rep["stage"], "SCHEMA_CONTRACT")
        self.assertTrue(rep["reasons"][0].startswith("JSON_INVALID"))

    def test_missing_contract_and_invariant_test_give_rescue_targets(self) -> None:
        (self.root / CC / "policy" / "p.json").unlink()
        (self.root / CC / "tests" / "test_ok.py").unlink()
        self.text(CC + "tests/test_other.py", "x = 1\n")
        rc.write_input_set(self.root)
        rep = self.gate()
        self.assertEqual(rep["stage"], "SCHEMA_CONTRACT")
        self.assertEqual(rc.rescue_targets(rep), [{"origin_path": CC + "policy/p.json"}, {"origin_path": CC + "tests/test_ok.py"}])

    def test_dest_must_be_empty(self) -> None:
        rc.write_input_set(self.root)
        self.dest.mkdir()
        (self.dest / "x").write_text("y", encoding="utf-8")
        self.assertTrue(self.gate()["reasons"][0].startswith("DEST_NOT_EMPTY"))

    def test_archive_derived_requires_rescue_ref(self) -> None:
        bp = _mini_blueprint()
        bp["components"].append({"component_id": "C-ARC", "class": "ARCHIVE_DERIVED", "include": ["arc/**"], "responsibility": "x"})
        self.set_blueprint(bp)
        rc.write_input_set(self.root)
        self.assertIn("ARCHIVE_INPUT_UNBOUND:C-ARC", self.gate()["reasons"])


class LiveRepo(unittest.TestCase):
    """真實 repo：Blueprint 有效、歸屬完整（不檢查輸入集新鮮度——那是重大更新的 `reconstruction.py check`）。"""

    def test_path_pattern_matching_is_repo_root_anchored(self) -> None:
        root_readme = rc._rx("README.md")
        self.assertIsNotNone(root_readme.match("README.md"))
        self.assertIsNone(root_readme.match("docs/README.md"))
        self.assertIsNone(root_readme.match("P1-Central-Control/integrations/25d/README.md"))


    def test_blueprint_valid_and_every_file_owned_once(self) -> None:
        bp = rc.load_blueprint(ROOT)
        self.assertEqual(rc.ownership(ROOT, bp)[1], [])
        self.assertEqual(bp["status"], "CURRENT")

    def test_blueprint_refs_exist(self) -> None:
        bp = rc.load_blueprint(ROOT)
        refs = [c["ref"] for c in bp["contracts"]] + [i["test_ref"] for i in bp["invariants"]]
        self.assertEqual([r for r in refs if not (ROOT / r).is_file()], [])

    def test_input_set_when_present_matches_blueprint(self) -> None:
        path = ROOT / rc.policy()["input_set_path"]
        if path.is_file():
            stored = json.loads(path.read_text(encoding="utf-8"))
            self.assertEqual(stored["blueprint_hash"], rc.load_blueprint(ROOT)["content_hash"])

    def test_docs_reference_is_not_a_build_input(self) -> None:
        classes = {c["component_id"]: c["class"] for c in rc.load_blueprint(ROOT)["components"]}
        self.assertEqual(classes["C-DOCS-REFERENCE"], "OPTIONAL")


if __name__ == "__main__":
    unittest.main()
