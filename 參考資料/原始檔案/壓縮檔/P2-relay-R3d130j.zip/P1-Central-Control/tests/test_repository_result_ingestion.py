#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import central_controller
from _brain_fixture import brain_start_proposal
from event_log import EventLog
from packet_layer import content_hash
from repository_result_ingestion import ingest
from repository_result_writer import persist
from system_result_adapter import adapt as adapt_system_result


class RepositoryResultIngestionTests(unittest.TestCase):
    def make_segment(self) -> dict:
        return {
            "segment_id": "SEG-INGEST",
            "workflow_id": "WF-INGEST",
            "system_id": "SYSTEM-INGEST",
            "skill_id": "demo-skill",
            "skill_version": "1.0.0",
            "objective": "repository result ingestion",
            "input_scope": "test",
            "input_refs": ["ARTIFACT:INPUT"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "EXECUTION:placeholder",
            "context_cohort_id": "COHORT-INGEST",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }

    def prepare(self, root: Path):
        state = central_controller.init_state("WF-INGEST", "TASK-INGEST")
        state = central_controller.queue_segment(state, self.make_segment())

        proposal = brain_start_proposal(state)
        log = EventLog(root / "events.jsonl")
        state, applied = central_controller.commit_brain_proposal(
            state,
            proposal,
            event_log=log,
        )
        self.assertEqual(applied["status"], "APPLIED")

        execution_store: dict = {}
        state, packets = central_controller.dispatch(
            state,
            event_log=log,
            execution_store=execution_store,
            max_concurrency=1,
        )
        envelope = execution_store[packets[0]["execution_record_ref"]]

        system_result = {
            "segment_id": packets[0]["segment_id"],
            "system_id": "SYSTEM-INGEST",
            "status": "WORK_COMPLETE",
            "outputs": {"result": {"status": "complete"}},
            "evidence_refs": [],
            "provenance_refs": [],
            "gaps": [],
            "unresolved": [],
            "trace": [{"step": "ingest-test"}],
            "completion": {
                "segment_complete": True,
                "handoff_ready": False,
                "summary": "ingest test",
            },
            "observed_usage": {
                "model_calls": 1,
                "tool_calls": 1,
                "wall_time_ms": 1,
                "usage_observed": True,
            },
        }
        result, evidence_payload, provenance_payload = adapt_system_result(
            envelope["task_packet"],
            system_result,
            envelope["execution_record"],
        )
        # adapt() returns {"records": [...]} payloads (same unwrap as test_m32_close_vertical_slice).
        evidence = evidence_payload["records"]
        provenance = provenance_payload["records"]
        result_root = root / "repo"
        persisted = persist(result, root=result_root)
        result_path = result_root / persisted["path"]

        (root / "state.json").write_text(
            json.dumps(state, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        (root / "execution.json").write_text(
            json.dumps(list(execution_store.values()), ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        (root / "evidence.json").write_text(
            json.dumps(evidence, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        (root / "provenance.json").write_text(
            json.dumps(provenance, ensure_ascii=False, indent=2) + "\n",
            encoding="utf-8",
        )
        return state, envelope["task_packet"], result, result_path, log.path, evidence, provenance

    def test_persisted_result_reenters_existing_central_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state, task, result, result_path, log_path, evidence, provenance = self.prepare(root)
            outcome = ingest(
                result_packet=result,
                task_packet=task,
                current_state=state,
                execution_envelopes=json.loads((root / "execution.json").read_text()),
                event_log_path=log_path,
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(outcome["status"], "PASS")
            self.assertEqual(outcome["central_state"]["status"], "COMPLETED")
            self.assertEqual(
                outcome["central_state"]["result_refs"],
                [result["result_id"]],
            )
            self.assertEqual(outcome["ingestion"]["state_owner"], "EXISTING_CENTRAL_CONTROLLER")
            self.assertTrue(result_path.exists())

    def test_identity_mismatch_blocks_before_central(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state, task, result, result_path, log_path, evidence, provenance = self.prepare(root)
            bad = dict(result)
            bad["attempt_id"] = "att-WRONG"
            bad["content_hash"] = content_hash(bad)
            with self.assertRaisesRegex(ValueError, "RESULT_TASK_IDENTITY_MISMATCH:attempt_id"):
                ingest(
                    result_packet=bad,
                    task_packet=task,
                    current_state=state,
                    execution_envelopes=json.loads((root / "execution.json").read_text()),
                    event_log_path=log_path,
                    evidence_records=evidence,
                    provenance_records=provenance,
                )

    def test_duplicate_result_uses_existing_late_result_path(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            state, task, result, _result_path, log_path, evidence, provenance = self.prepare(root)
            first = ingest(
                result_packet=result,
                task_packet=task,
                current_state=state,
                execution_envelopes=json.loads((root / "execution.json").read_text()),
                event_log_path=log_path,
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(first["central_state"]["status"], "COMPLETED")

            duplicate_envelopes = first["execution_envelopes"]
            second = ingest(
                result_packet=result,
                task_packet=task,
                current_state=first["central_state"],
                execution_envelopes=duplicate_envelopes,
                event_log_path=log_path,
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(second["central_state"]["late_result_count"], 1)


if __name__ == "__main__":
    unittest.main(verbosity=2)
