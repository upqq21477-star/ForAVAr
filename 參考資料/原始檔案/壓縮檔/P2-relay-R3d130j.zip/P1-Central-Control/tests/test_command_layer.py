#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(TESTS_DIR))

import central_controller  # noqa: E402
from command_layer import (  # noqa: E402
    build_command,
    execute_command,
    execute_command_sequence,
    result_command_types,
    validate_command,
    validate_result,
)
from event_log import EventLog  # noqa: E402
from packet_layer import build_result_packet  # noqa: E402
from p7_test_records import records_for  # noqa: E402


class CommandLayerTests(unittest.TestCase):
    def make_state(self) -> dict:
        return central_controller.init_state("WF-CMD", "TASK-CMD")

    def make_segment(self, workflow_id: str, segment_id: str) -> dict:
        return {
            "segment_id": segment_id,
            "workflow_id": workflow_id,
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "P3 command test",
            "input_scope": "test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 300000,
            "completion_contract": {
                "status": "WORK_COMPLETE",
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "ARTIFACT:execution-001",
            "context_cohort_id": "COHORT-CMD",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
        }

    def make_result(self, task_packet: dict, decision_code: str) -> dict:
        return build_result_packet(
            task_packet,
            {
                "decision_code": decision_code,
                "output_refs": ["ARTIFACT:result-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "evidence_refs": ["EVIDENCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "provenance_refs": ["PROVENANCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 1,
                },
                "usage_observed": True,
            },
        )

    def test_command_schema_is_valid(self) -> None:
        schema = json.loads(
            (SCHEMA_DIR / "command.schema.json").read_text(encoding="utf-8")
        )
        Draft202012Validator.check_schema(schema)

        registry = Registry()
        for path in (
            SCHEMA_DIR / "canonical_identity.schema.json",
            SCHEMA_DIR / "canonical_common.schema.json",
            SCHEMA_DIR / "command.schema.json",
            SCHEMA_DIR / "command_result.schema.json",
        ):
            loaded = json.loads(path.read_text(encoding="utf-8"))
            registry = registry.with_resource(
                loaded["$id"],
                Resource.from_contents(loaded),
            )

        validator = Draft202012Validator(
            schema,
            registry=registry,
            format_checker=FormatChecker(),
        )
        state = self.make_state()
        command = build_command(state, "START")
        self.assertEqual(list(validator.iter_errors(command)), [])

    def test_execute_follows_input_check_action_event_output_next(self) -> None:
        state = self.make_state()

        with tempfile.TemporaryDirectory() as temp:
            updated, result = execute_command(
                state,
                build_command(state, "START"),
                event_log=EventLog(Path(temp) / "events.jsonl"),
            )

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(result["check"]["status"], "PASS")
        self.assertEqual(result["action"]["status"], "APPLIED")
        self.assertIsNotNone(result["event"])
        self.assertEqual(result["event"]["event_type"], "STATE_TRANSITION_APPLIED")
        self.assertEqual(result["output"]["status"], "RUNNING")
        self.assertEqual(result["output"]["state_revision"], 1)
        self.assertEqual(result["next"], "NONE")
        self.assertEqual(updated["status"], "RUNNING")
        validate_result(result)

    def test_workflow_target_and_revision_checks_block_before_action(self) -> None:
        state = self.make_state()

        bad_target = build_command(state, "START")
        bad_target["target_id"] = "WF-OTHER"

        with tempfile.TemporaryDirectory() as temp:
            _, result = execute_command(
                state,
                bad_target,
                event_log=EventLog(Path(temp) / "events.jsonl"),
            )

        self.assertEqual(result["status"], "REJECTED")
        self.assertEqual(result["check"]["status"], "BLOCK")
        self.assertIn("TARGET_ID_MISMATCH", result["check"]["errors"])

        stale = build_command(state, "START")
        stale["expected_state_revision"] = 99
        validate_command(stale)

        with tempfile.TemporaryDirectory() as temp:
            _, result = execute_command(
                state,
                stale,
                event_log=EventLog(Path(temp) / "events.jsonl"),
            )

        self.assertEqual(result["status"], "REJECTED")
        self.assertEqual(result["check"]["status"], "BLOCK")
        self.assertIn("EXPECTED_REVISION_MISMATCH", result["check"]["errors"])

    def test_idempotency_replay_does_not_append_second_event(self) -> None:
        state = self.make_state()

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            command = build_command(state, "START", idempotency_key="IK:CMD-001")
            first_state, first = execute_command(
                state,
                command,
                event_log=log,
            )

            retry = dict(command)
            retry["command_id"] = "CMD:retry"
            retry["issued_at"] = "2026-10-03T10:00:00+00:00"
            retry_state, second = execute_command(
                first_state,
                retry,
                event_log=log,
            )
            events = log.read_all("WORKFLOW")

        self.assertEqual(first["status"], "APPLIED")
        self.assertEqual(second["status"], "IDEMPOTENT_REPLAY")
        self.assertEqual(first_state, retry_state)
        self.assertEqual(len(events), 1)

    def test_illegal_transition_is_rejected_by_action_and_no_event_is_written(self) -> None:
        state = self.make_state()

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            command = build_command(state, "WAIT")
            updated, result = execute_command(
                state,
                command,
                event_log=log,
            )

            self.assertEqual(result["status"], "REJECTED")
            self.assertEqual(result["check"]["status"], "PASS")
            self.assertEqual(result["action"]["status"], "REJECTED")
            self.assertEqual(updated, state)
            self.assertFalse(log.path.exists())

    def test_sequence_generates_command_per_transition(self) -> None:
        state = self.make_state()

        with tempfile.TemporaryDirectory() as temp:
            state, results = execute_command_sequence(
                state,
                ["START", "WAIT"],
                event_log=EventLog(Path(temp) / "events.jsonl"),
                caused_by="SEGMENT:SEG-001",
            )

        self.assertEqual(state["status"], "WAITING")
        self.assertEqual(state["state_revision"], 2)
        self.assertEqual([item["status"] for item in results], ["APPLIED", "APPLIED"])

    def test_result_routes_are_deterministic(self) -> None:
        state = self.make_state()
        state["status"] = "WAITING"

        self.assertEqual(
            result_command_types(
                state, "WORK_COMPLETE", has_queued_work=False
            ),
            ["RESUME", "COMPLETE"],
        )
        self.assertEqual(
            result_command_types(
                state, "FAIL", has_queued_work=True
            ),
            [],
        )
        self.assertEqual(
            result_command_types(
                state, "BLOCK", has_queued_work=False
            ),
            ["BLOCK"],
        )
        self.assertEqual(
            result_command_types(
                state, "UNRESOLVED", has_queued_work=False
            ),
            ["BLOCK"],
        )

    def test_central_controller_no_longer_calls_runtime_transition_directly(self) -> None:
        source = (
            SCRIPTS_DIR / "central_controller.py"
        ).read_text(encoding="utf-8")
        self.assertNotIn("transition_workflow(", source)
        self.assertNotIn("transition_for_result(", source)
        self.assertNotIn("from state_machine_runtime_gate import (", source)

    def test_central_dispatch_uses_command_layer_and_event_log(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = self.make_state()
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-CMD", "SEG-CMD-001"),
        )

        with tempfile.TemporaryDirectory() as temp:
            state, _ = central_controller.dispatch(
                state,
                event_log=EventLog(Path(temp) / "events.jsonl"),
                execution_store=execution_store,
            )
            events = EventLog(Path(temp) / "events.jsonl").read_all("WORKFLOW")

        self.assertEqual(state["status"], "RUNNING")
        self.assertEqual([event["command_type"] for event in events], ["START"])

    def test_central_receive_uses_command_layer(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = self.make_state()
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-CMD", "SEG-CMD-001"),
        )

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, task_packets = central_controller.dispatch(
                state, event_log=log, execution_store=execution_store
            )
            result_packet = self.make_result(task_packets[0], "WORK_COMPLETE")
            envelope = execution_store[result_packet["execution_record_ref"]]
            evidence_records, provenance_records = records_for(
                envelope["task_packet"], result_packet, envelope["execution_record"]
            )
            state = central_controller.receive_result(
                state,
                result_packet,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                evidence_records=evidence_records,
                provenance_records=provenance_records,
            )
            events = log.read_all("WORKFLOW")

        self.assertEqual(state["status"], "COMPLETED")
        self.assertEqual(
            [event["command_type"] for event in events],
            ["START", "COMPLETE"],
        )


if __name__ == "__main__":
    unittest.main()
