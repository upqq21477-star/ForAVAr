#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import minimal_closed_loop_runner as runner  # noqa: E402


import sys as _sys
from pathlib import Path as _Path

_sys.path.insert(0, str(_Path(__file__).resolve().parent))
from _quarantine import quarantined  # noqa: E402


class MinimalClosedLoopRunnerTests(unittest.TestCase):
    def make_packet(
        self,
        root: Path,
        *,
        next_command: list[str] | None = None,
        acceptance_command: list[str] | None = None,
    ) -> dict:
        artifact = root / "artifact.txt"
        artifact.write_text("artifact\n", encoding="utf-8")
        packet = {
            "work_id": "M32-C01-TEST",
            "phase": "M32",
            "completion_reason": "implementation",
            "outputs": [{"path": "artifact.txt"}],
            "acceptance": {
                "command": acceptance_command
                or ["python3", "-c", "print('acceptance-pass')"]
            },
            "next_command": next_command
            or ["python3", "-c", "open('continued.txt', 'w', encoding='utf-8').write('continued')"],
            "execution_contract": {
                "version": "1.0",
                "steps": [
                    {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                    {"step_id": "ACCEPTANCE", "op": "RUN_ACCEPTANCE_COMMAND"},
                    {"step_id": "HANDOFF", "op": "EMIT_NEXT_COMMAND"},
                ],
            },
        }
        return packet

    @quarantined("test_minimal_closed_loop_runner.MinimalClosedLoopRunnerTests.test_next_command_is_really_consumed")
    def test_next_command_is_really_consumed(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = runner.run_once(root, self.make_packet(root))

            self.assertEqual(result["status"], "PASS")
            self.assertTrue(result["continued"])
            self.assertEqual(result["next_command_execution"]["returncode"], 0)
            self.assertTrue((root / "continued.txt").is_file())

    @quarantined("test_minimal_closed_loop_runner.MinimalClosedLoopRunnerTests.test_next_command_failure_blocks_without_false_success")
    def test_next_command_failure_blocks_without_false_success(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(
                root,
                next_command=["python3", "-c", "raise SystemExit(7)"],
            )

            result = runner.run_once(root, packet)

            self.assertEqual(result["status"], "BLOCK")
            self.assertFalse(result["continued"])
            self.assertEqual(result["next_command_execution"]["returncode"], 7)

    @quarantined("test_minimal_closed_loop_runner.MinimalClosedLoopRunnerTests.test_contract_failure_does_not_consume_next_command")
    def test_contract_failure_does_not_consume_next_command(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            marker = root / "continued.txt"
            packet = self.make_packet(
                root,
                acceptance_command=["python3", "-c", "raise SystemExit(9)"],
                next_command=[
                    "python3",
                    "-c",
                    "open('continued.txt', 'w', encoding='utf-8').write('bad')",
                ],
            )

            result = runner.run_once(root, packet)

            self.assertEqual(result["status"], "BLOCK")
            self.assertFalse(result["continued"])
            self.assertIsNone(result["next_command"])
            self.assertFalse(marker.exists())

    @quarantined("test_minimal_closed_loop_runner.MinimalClosedLoopRunnerTests.test_missing_next_command_blocks")
    def test_missing_next_command_blocks(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(root)
            packet.pop("next_command")

            result = runner.run_once(root, packet)

            self.assertEqual(result["status"], "BLOCK")
            self.assertFalse(result["continued"])
            self.assertIsNone(result["next_command"])

    @quarantined("test_minimal_closed_loop_runner.MinimalClosedLoopRunnerTests.test_timeout_is_block_not_retry")
    def test_timeout_is_block_not_retry(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(
                root,
                next_command=[
                    "python3",
                    "-c",
                    "import time; time.sleep(2)",
                ],
            )

            result = runner.run_once(root, packet, timeout_seconds=1)

            self.assertEqual(result["status"], "BLOCK")
            self.assertFalse(result["continued"])
            self.assertTrue(result["next_command_execution"]["timed_out"])
            self.assertIsNone(result["next_command_execution"]["returncode"])


if __name__ == "__main__":
    unittest.main()
