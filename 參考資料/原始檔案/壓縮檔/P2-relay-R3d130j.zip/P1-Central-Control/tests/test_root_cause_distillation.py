from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from root_cause_distillation import distill_root_cause


def _request(**overrides):
    request = {
        "request_id": "F22-NORMAL",
        "failure_id": "FAILURE-42",
        "failure_statement": "The repeated planner handoff fails when a required capability binding is missing.",
        "target_scope_ref": "P1-Central-Control/scripts/planner_library.py",
        "affected_scope": "MULTI_DOMAIN",
        "target_paths": [
            "P1-Central-Control/scripts/planner_library.py",
            "P1-Central-Control/scripts/central_role_interface.py",
        ],
        "source_revision": "0123456789abcdef0123456789abcdef01234567",
        "recurrence_count": 3,
        "explicit_one_off": False,
        "evidence": [
            {
                "evidence_id": "E-SUPPORT",
                "kind": "OBSERVED",
                "statement": "A reproduced request failed after required binding resolution returned empty.",
                "source_ref": "evidence/failure-reproduction.json",
            },
            {
                "evidence_id": "E-CONTRADICT",
                "kind": "CONFIRMED",
                "statement": "A contrasting run with the same input and a valid binding completes the handoff.",
                "source_ref": "evidence/contrasting-run.json",
            },
        ],
        "hypotheses": [
            {
                "hypothesis_id": "H-BINDING",
                "statement": "The failure is caused by a required role-capability binding absent from the active map.",
                "supporting_evidence_ids": ["E-SUPPORT"],
                "contradicting_evidence_ids": ["E-CONTRADICT"],
                "discriminating_test_ref": "tests/test_binding_gate.py::test_missing_binding_blocks",
                "test_result": "CONFIRMS",
                "test_output_ref": "evidence/discriminating-test-output.json",
            }
        ],
        "prior_scope_fingerprint": None,
        "prior_downstream_evidence_refs": [],
        "repair_outcome": "NOT_RUN",
        "governance_approval": False,
    }
    request.update(overrides)
    return request


class RootCauseDistillationTests(unittest.TestCase):
    def test_confirmed_unique_root_cause_maps_to_scoped_reusable_rule_without_writing(self):
        result = distill_root_cause(_request())
        self.assertEqual(result["status"], "CONFIRMED")
        self.assertEqual(result["root_cause_status"], "CONFIRMED")
        self.assertEqual(result["chosen_hypothesis_id"], "H-BINDING")
        self.assertEqual(result["classification_hint"], "SYSTEMIC_CAPABILITY")
        self.assertTrue(result["blueprint_update_eligible"])
        self.assertFalse(result["persistent_write"])
        self.assertFalse(result["execution_authorized"])

    def test_unrun_discriminating_test_cannot_promote_hypothesis(self):
        request = _request()
        request["hypotheses"][0]["test_result"] = "NOT_RUN"
        request["hypotheses"][0]["test_output_ref"] = None
        result = distill_root_cause(request)
        self.assertEqual(result["status"], "HYPOTHESIS_ONLY")
        self.assertEqual(result["root_cause_status"], "HYPOTHESIS")
        self.assertIsNone(result["chosen_hypothesis_id"])
        self.assertFalse(result["blueprint_update_eligible"])

    def test_scope_drift_or_failed_repair_invalidates_downstream_evidence_and_requires_retest(self):
        request = _request(
            prior_scope_fingerprint="sha256:" + "0" * 64,
            prior_downstream_evidence_refs=[
                "acceptance/old-simulation.json",
                "acceptance/old-integration.json",
            ],
            repair_outcome="FAIL",
        )
        result = distill_root_cause(request)
        self.assertTrue(result["scope_changed"])
        self.assertTrue(result["retest_required"])
        self.assertEqual(set(result["invalidated_prior_evidence_refs"]), set(request["prior_downstream_evidence_refs"]))
        self.assertIn("REPAIR_FAILED", " ".join(result["warnings"]))


if __name__ == "__main__":
    unittest.main()
