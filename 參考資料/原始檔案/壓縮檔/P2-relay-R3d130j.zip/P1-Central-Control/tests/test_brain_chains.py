#!/usr/bin/env python3
"""R3d12x：scripts/brain_chains.py（CH-PLAN-TASK-COMMAND、CH-KNOWLEDGE-BRAIN 實跑）；含 3 個突變，須被情境抓到。SIMULATION_ONLY。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

import brain_chains as bc  # noqa: E402
import brain_input  # noqa: E402
import command_layer  # noqa: E402


def _failed(rows: list[dict]) -> set[str]:
    return {r["scenario"] for r in rows if not r["ok"]}


class BrainChainsTests(unittest.TestCase):
    def test_real_run_all_scenarios_pass_and_links_are_measured(self) -> None:
        chains, rows = bc.scenarios()
        self.assertEqual(_failed(rows), set())
        for cid, rec in chains.items():
            self.assertEqual(rec["exit_code"], 0)
            self.assertEqual(rec["links_exercised"], sorted(bc.LINKS[cid]))

    def test_mutation_stale_guard_noop_is_caught(self) -> None:
        with mock.patch.object(command_layer, "task_admission_errors", lambda *_a, **_k: []):
            chains, rows = bc.scenarios()
        self.assertIn(f"{bc.CHAIN_PLAN}:positive", _failed(rows))
        self.assertEqual(chains[bc.CHAIN_PLAN]["exit_code"], 1)

    def test_mutation_semantic_refs_ignores_promotion_is_caught(self) -> None:
        with mock.patch.object(brain_input, "semantic_refs_from", lambda retriever, needle, limit=5: sorted(retriever.s.claims)[:limit]):
            _chains, rows = bc.scenarios()
        self.assertIn("knowledge:unpromoted_claim_not_given_to_brain", _failed(rows))

    def test_mutation_packet_validator_noop_is_caught(self) -> None:
        with mock.patch.object(brain_input, "validate_packet", lambda _p: None):
            _chains, rows = bc.scenarios()
        self.assertIn("knowledge:packet_with_extra_field_refused", _failed(rows))


if __name__ == "__main__":
    unittest.main()
