import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from runtime_evidence_probe import execute


class RuntimeEvidenceProbeTests(unittest.TestCase):
    def test_positive_probe(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = execute({
                "schema_version": "1.0",
                "probe_id": "PROBE:POS",
                "root_path": tmp,
                "command": [sys.executable, "-c", "print('ok')"],
                "expected_exit_code": 0
            })
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["evidence_class"], "OBSERVED_RUNTIME")

    def test_negative_probe_is_observed_fail(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = execute({
                "schema_version": "1.0",
                "probe_id": "PROBE:NEG",
                "root_path": tmp,
                "command": [sys.executable, "-c", "raise SystemExit(3)"],
                "expected_exit_code": 0
            })
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["return_code"], 3)

    def test_timeout_is_distinct(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = execute({
                "schema_version": "1.0",
                "probe_id": "PROBE:TIMEOUT",
                "root_path": tmp,
                "command": [sys.executable, "-c", "import time; time.sleep(2)"],
                "timeout_seconds": 1,
                "expected_exit_code": 0
            })
        self.assertEqual(result["status"], "TIMEOUT")


if __name__ == "__main__":
    unittest.main()
