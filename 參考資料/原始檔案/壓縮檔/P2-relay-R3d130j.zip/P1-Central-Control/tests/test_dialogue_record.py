#!/usr/bin/env python3
"""R4R-S4 (FR-10): DIALOGUE_TURN in event_log, `!` command route record, dialogue_loop closed loop, registry alignment."""
from __future__ import annotations

import io
import json
import sys
import tempfile
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import dialogue_loop as dl  # noqa: E402
import event_log as el  # noqa: E402
import role_command_router as router  # noqa: E402

WF, CID = "work-test-0001", "conv-test-0001"


def _ts(n: int) -> str:
    return f"2026-10-15T10:00:{n:02d}+00:00"


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.addCleanup(self._td.cleanup)
        self.path = Path(self._td.name) / "events.jsonl"
        self.log = el.EventLog(self.path)
        self.n = 0

    def rec(self, role="USER", content="hello", cid=CID, ref=None):
        self.n += 1
        return el.record_dialogue_turn(self.log, workflow_id=WF, conversation_id=cid, role=role, content=content,
                                       ref=ref, occurred_at=_ts(self.n))


class EventLogDialogueTests(Base):
    def test_type_registered_in_segment_event_types(self):
        self.assertIn("DIALOGUE_TURN", el.SEGMENT_EVENT_TYPES)

    def test_make_event_rejects_bad_fields(self):
        good = dict(workflow_id=WF, revision=1, conversation_id=CID, turn=1, role="USER",
                    content_hash=el.dialogue_content_hash("x"), occurred_at=_ts(1))
        el.make_dialogue_turn_event(**good)
        for patch in ({"conversation_id": ""}, {"conversation_id": "  "}, {"turn": 0}, {"turn": True}, {"turn": "1"},
                      {"role": "SYSTEM"}, {"content_hash": "abc"}, {"content_hash": "G" * 64}):
            with self.subTest(patch=patch), self.assertRaises(ValueError):
                el.make_dialogue_turn_event(**{**good, **patch})

    def test_record_keeps_hash_only_never_text(self):
        self.rec(content="SECRET-MARK full text 你好")
        raw = self.path.read_text(encoding="utf-8")
        self.assertNotIn("SECRET-MARK", raw)
        self.assertIn(el.dialogue_content_hash("SECRET-MARK full text 你好"), raw)

    def test_non_text_content_refused(self):
        with self.assertRaises(ValueError):
            self.rec(content=b"bytes")  # type: ignore[arg-type]

    def test_two_conversations_number_independently_on_one_revision_line(self):
        for cid in (CID, "conv-other", CID, "conv-other", CID):
            self.rec(cid=cid)
        events = self.log.read_all()  # full history validation: SEGMENT revisions 1..5 contiguous
        self.assertEqual([e["revision"] for e in events], [1, 2, 3, 4, 5])
        self.assertEqual([t["turn"] for t in el.read_dialogue(events, CID)], [1, 2, 3])
        self.assertEqual([t["turn"] for t in el.read_dialogue(events, "conv-other")], [1, 2])

    def test_read_dialogue_fails_closed_on_gap_and_duplicate(self):
        for _ in range(3):
            self.rec()
        events = self.log.read_all()
        gapped = [e for e in events if e["segment_delta"]["turn"] != 2]
        with self.assertRaisesRegex(ValueError, "DIALOGUE_TURN_GAP"):
            el.read_dialogue(gapped, CID)
        dup = events + [events[1]]
        with self.assertRaisesRegex(ValueError, "DIALOGUE_DUPLICATE_TURN"):
            el.read_dialogue(dup, CID)

    def test_read_dialogue_ignores_other_event_types_and_empty(self):
        self.assertEqual(el.read_dialogue([], CID), [])
        self.rec()
        self.assertEqual(el.read_dialogue(self.log.read_all(), "nobody"), [])

    def test_recent_refs_bounded_oldest_first_with_ref(self):
        for i in range(12):
            self.rec(role="COMMAND" if i == 11 else "USER", content=f"t{i}", ref="ROLE_ROUTE:X/Y" if i == 11 else None)
        refs = el.dialogue_recent_refs(self.log.read_all(), CID)
        self.assertEqual(len(refs), el.MAX_DIALOGUE_RECENT)
        self.assertTrue(refs[0].startswith(f"DIALOGUE:{CID}#3 USER sha256:"))
        self.assertTrue(refs[-1].endswith("ref=ROLE_ROUTE:X/Y"))
        self.assertEqual(len(el.dialogue_recent_refs(self.log.read_all(), CID, limit=2)), 2)

    def test_same_event_appended_twice_is_idempotent(self):
        ev = self.rec()
        self.assertEqual(self.log.append(ev), "IDEMPOTENT_REPLAY")
        self.assertEqual(len(self.log.read_all()), 1)


class RouterRecordTests(Base):
    def route(self, command):
        self.n += 1
        return router.resolve_and_record(command, event_log_path=self.path, workflow_id=WF, conversation_id=CID,
                                         occurred_at=_ts(self.n))

    def test_success_records_command_with_role_route_ref(self):
        result = self.route("！施工")
        last = el.read_dialogue(self.log.read_all(), CID)[-1]
        self.assertEqual(last["role"], "COMMAND")
        self.assertEqual(last["ref"], f"ROLE_ROUTE:{result['role_id']}/{result['profile_id']}")

    def test_ascii_bang_and_fullwidth_bang_hash_the_same(self):
        self.route("!施工")
        self.route("！施工")
        a, b = el.read_dialogue(self.log.read_all(), CID)
        self.assertEqual(a["content_hash"], b["content_hash"])
        self.assertEqual(a["content_hash"], el.dialogue_content_hash("！施工"))

    def test_unknown_command_raises_and_is_recorded_as_blocked(self):
        with self.assertRaises(ValueError):
            self.route("！不存在")
        last = el.read_dialogue(self.log.read_all(), CID)[-1]
        self.assertEqual(last["ref"], "ROLE_ROUTE_BLOCKED:UNKNOWN_ROLE_COMMAND")

    def test_registered_non_role_shortcut_is_marked_unhandled_not_unknown(self):
        with self.assertRaises(ValueError):
            self.route("！討論紀錄")
        last = el.read_dialogue(self.log.read_all(), CID)[-1]
        self.assertEqual(last["ref"], "ROUTE_UNHANDLED:conversation.record.create")

    def test_plain_resolve_writes_nothing(self):
        router.resolve("！施工")
        self.assertFalse(self.path.exists())

    def test_cli_event_log_needs_workflow_and_conversation(self):
        buf = io.StringIO()
        with mock.patch.object(sys, "argv", ["x", "！施工", "--event-log", str(self.path)]), redirect_stdout(buf):
            code = router.main()
        self.assertEqual(code, 2)
        self.assertIn("EVENT_LOG_NEEDS_WORKFLOW_AND_CONVERSATION", buf.getvalue())
        self.assertFalse(self.path.exists())

    def test_cli_with_event_log_records_one_turn(self):
        buf = io.StringIO()
        argv = ["x", "！施工", "--event-log", str(self.path), "--workflow", WF, "--conversation", CID]
        with mock.patch.object(sys, "argv", argv), redirect_stdout(buf):
            code = router.main()
        self.assertEqual(code, 0)
        self.assertEqual(len(el.read_dialogue(self.log.read_all(), CID)), 1)


class ConsumerVerifierTests(Base):
    def brief(self, events):
        return {"recent": el.dialogue_recent_refs(events, CID)}

    def test_resume_statuses(self):
        self.assertEqual(dl.resume_from_brief({"recent": []}, [], CID)["status"], "NO_DIALOGUE")
        self.rec(content="a")
        self.rec(content="b")
        events = self.log.read_all()
        ok = dl.resume_from_brief(self.brief(events), events, CID)
        self.assertEqual((ok["status"], ok["next_turn"]), ("OK", 3))
        old = self.brief(events)
        self.rec(content="c")
        events = self.log.read_all()
        behind = dl.resume_from_brief(old, events, CID)
        self.assertEqual((behind["status"], behind["next_action"]), ("BRIEF_BEHIND", "REBUILD_BRIEF"))
        self.assertEqual(dl.resume_from_brief({"recent": []}, events, CID)["status"], "BRIEF_BEHIND")

    def test_resume_rejects_ahead_disagreeing_and_gapped(self):
        self.rec(content="a")
        events = self.log.read_all()
        ahead = {"recent": [f"DIALOGUE:{CID}#4 USER sha256:{'0' * 12}"]}
        self.assertIn("BRIEF_AHEAD_OF_LOG", dl.resume_from_brief(ahead, events, CID)["reasons"][0])
        wrong_hash = {"recent": [f"DIALOGUE:{CID}#1 USER sha256:{'f' * 12}"]}
        self.assertIn("RECENT_DISAGREES_WITH_LOG", dl.resume_from_brief(wrong_hash, events, CID)["reasons"][0])
        wrong_role = {"recent": [r.replace(" USER ", " ASSISTANT ") for r in self.brief(events)["recent"]]}
        self.assertEqual(dl.resume_from_brief(wrong_role, events, CID)["status"], "REJECTED")
        self.rec(content="b")
        self.rec(content="c")
        gapped = [e for e in self.log.read_all() if e["segment_delta"]["turn"] != 2]
        self.assertEqual(dl.resume_from_brief({"recent": []}, gapped, CID)["status"], "REJECTED")

    def test_resume_ignores_other_conversations_in_recent(self):
        self.rec(content="a")
        events = self.log.read_all()
        mixed = {"recent": [f"DIALOGUE:conv-other#9 USER sha256:{'a' * 12}"] + self.brief(events)["recent"]}
        self.assertEqual(dl.resume_from_brief(mixed, events, CID)["status"], "OK")

    def test_verify_dialogue(self):
        self.rec(content="a")
        self.rec(content="b")
        events = self.log.read_all()
        self.assertEqual(dl.verify_dialogue(events, CID, {1: "a", 2: "b"})["status"], "OK")
        self.assertEqual(dl.verify_dialogue(events, CID, {2: "b!"})["reasons"], ["DIALOGUE_HASH_MISMATCH:2"])
        self.assertEqual(dl.verify_dialogue(events, CID, {3: "x"})["reasons"], ["NO_SUCH_TURN:3"])
        self.assertEqual(dl.verify_dialogue(events, CID)["status"], "OK")


class ClosedLoopTests(unittest.TestCase):
    def run_sim(self):
        return dl.simulate()

    def test_simulation_all_pass(self):
        results = self.run_sim()
        self.assertGreaterEqual(len(results), 12)
        self.assertEqual([n for n, ok, _ in results if not ok], [])

    def failed(self):
        return [n for n, ok, _ in self.run_sim() if not ok]

    def test_mutation_constant_hash_is_caught(self):
        with mock.patch.object(el, "dialogue_content_hash", lambda text: "0" * 64):
            self.assertTrue(any("edited text" in n for n in self.failed()))

    def test_mutation_text_leaking_into_the_log_is_caught(self):
        orig = el.record_dialogue_turn

        def leaking(log, **kw):
            return orig(log, **{**kw, "ref": kw["content"]})  # the text sneaks in through ref

        with mock.patch.object(el, "record_dialogue_turn", leaking):
            self.assertTrue(any("hashes, not text" in n for n in self.failed()))

    def test_mutation_gap_check_removed_is_caught(self):
        def sloppy(events, conversation_id):
            return sorted((dict(e["segment_delta"]) for e in events
                           if e.get("event_type") == "DIALOGUE_TURN" and e["segment_delta"]["conversation_id"] == conversation_id),
                          key=lambda r: r["turn"])
        with mock.patch.object(el, "read_dialogue", sloppy):
            self.assertTrue(any("missing turn" in n for n in self.failed()))

    def test_mutation_resume_always_ok_is_caught(self):
        with mock.patch.object(dl, "resume_from_brief", lambda brief, events, cid: {"status": "OK", "next_turn": 5,
                                                                                    "reasons": [], "next_action": "CONTINUE"}):
            self.assertTrue(any("BRIEF_BEHIND" in n or "rebuilt" in n for n in self.failed()))

    def test_mutation_blocked_command_not_recorded_is_caught(self):
        def no_trace(command, **kw):
            return router.resolve(command)
        with mock.patch.object(router, "resolve_and_record", no_trace):
            try:
                names = self.failed()
            except IndexError:
                names = ["no trace"]
        self.assertTrue(names)

    def test_mutation_recent_projection_dropped_is_caught(self):
        with mock.patch.object(el, "dialogue_recent_refs", lambda events, cid, limit=10: []):
            self.assertTrue(any("Brief.recent" in n for n in self.failed()))

    def test_entry_point_exit_codes(self):
        with mock.patch.object(sys, "argv", ["x", "--simulate-dialogue"]), redirect_stdout(io.StringIO()) as buf:
            self.assertEqual(dl.main(), 0)
        self.assertIn("SIMULATED_PASS", buf.getvalue())
        with mock.patch.object(sys, "argv", ["x"]), redirect_stdout(io.StringIO()):
            self.assertEqual(dl.main(), 2)


class RegistryAlignmentTests(unittest.TestCase):
    """DEFECT-015: the registry must not claim more than the code does."""

    def entry(self):
        reg = json.loads((ROOT / "P1-Central-Control/capability_registry.json").read_text(encoding="utf-8"))
        return next(c for c in reg["capabilities"] if c["capability_id"] == "CAP-CONVERSATION-RECORD")

    def test_purpose_names_what_exists_and_not_what_does_not(self):
        claimed, _, limits = self.entry()["purpose"].partition("；")  # "what exists；what is not implemented"
        self.assertIn("DIALOGUE_TURN", claimed)
        self.assertIn("event_log", claimed)
        for unbuilt in ("反向回溯", "迭代合併", "生命週期管理"):
            self.assertNotIn(unbuilt, claimed)
        self.assertIn("尚未實作", limits)

    def test_claimed_code_exists(self):
        self.assertIn("DIALOGUE_TURN", (SCRIPTS / "event_log.py").read_text(encoding="utf-8"))
        self.assertTrue((SCRIPTS / "dialogue_loop.py").is_file())


if __name__ == "__main__":
    unittest.main()
