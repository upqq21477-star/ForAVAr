#!/usr/bin/env python3
"""U-7：Brain 輸入封包（由 Central State 產生）、提案對 allowed_* 驗證、NEEDS_BRAIN 的 WAITING 由 Brain 提案推進。"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import central_controller  # noqa: E402
import test_repository_result_ingestion as base  # noqa: E402
from brain_input import allowed_sets, build_brain_input_packet, validate_packet  # noqa: E402
from brain_proposal import validate_proposal_against_state  # noqa: E402
from event_log import EventLog  # noqa: E402
from parallel_scheduler import start_available  # noqa: E402
from repository_result_ingestion import ingest_role_result  # noqa: E402
from test_role_result_ingestion import _role_result  # noqa: E402


def _proposal(state, command_type, decision, route, tag):
    return {
        "object_id": f"BRAIN_PROPOSAL:{tag}", "kind": "BRAIN_PROPOSAL", "schema_version": "1.0",
        "content_hash": "sha256:" + "b" * 64, "proposal_id": tag,
        "workflow_id": state["workflow_id"], "aggregate_type": "WORKFLOW", "target_id": state["workflow_id"],
        "command_type": command_type, "expected_state_revision": state["state_revision"],
        "idempotency_key": f"{tag}:{command_type}", "route_mode": route, "decision_code": decision,
        "capability_refs": [], "required_controls": ["STATE_VALIDATION", "IDEMPOTENCY", "EVENT_LOG"],
        "evidence_refs": [], "contract_gap_refs": [], "semantic_explanation_ref": None,
    }


class BrainInputTests(unittest.TestCase):
    def _waiting(self, root: Path):
        """Verifier FAIL → NEEDS_BRAIN → Workflow WAITING；回 (state, segment_store, EventLog)。"""
        helper = base.RepositoryResultIngestionTests()
        state, task, _r, _p, log_path, _e, _pv = helper.prepare(root)
        envelopes = json.loads((root / "execution.json").read_text())
        out = ingest_role_result(
            role_result=_role_result("ROLE:VERIFIER", "FAIL", reason="CHECK_FAILED", verdict_fields=True),
            task_packet=task, current_state=state, execution_envelopes=envelopes, event_log_path=log_path,
        )
        waiting = out["central_state"]
        self.assertEqual(waiting["status"], "WAITING")
        return waiting, {"SEG-INGEST": helper.make_segment()}, EventLog(log_path)

    def test_packet_from_waiting_state_is_code_only_and_schema_valid(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, _store, _log = self._waiting(Path(tmp))
            packet = build_brain_input_packet(state)
            validate_packet(packet)
            self.assertEqual(packet["trigger"], "NEEDS_BRAIN")
            self.assertEqual(packet["state_revision"], state["state_revision"])
            [seg] = packet["segments"]
            self.assertEqual((seg["state"], seg["last_decision_code"], seg["attempt_count"]), ("NEEDS_BRAIN", "NEEDS_BRAIN", 1))
            self.assertEqual(packet["diagnostics"][0]["code"], "NEEDS_BRAIN_SEGMENT")
            self.assertEqual(sorted(packet["allowed_decisions"]), ["ASK_INPUT", "BLOCK", "CANCEL", "EXECUTE"])
            self.assertEqual(sorted(packet["allowed_route_modes"]), ["BLOCK", "CANCEL", "DIRECT_COMMAND", "DISPATCH"])
            self.assertEqual(packet["task_set"], {"task_set_id": None, "tasks": []})
            bad = copy.deepcopy(packet)
            bad["note"] = "free text"
            with self.assertRaises(ValueError):
                validate_packet(bad)

    def test_allowed_sets_follow_state_contract(self) -> None:
        ready = central_controller.init_state("WF-U7", "TASK-U7")
        self.assertEqual(allowed_sets(ready), (["CANCEL", "EXECUTE"], ["CANCEL", "DIRECT_COMMAND", "DISPATCH"]))
        done = {**ready, "status": "COMPLETED"}
        self.assertEqual(allowed_sets(done), ([], []))

    def test_proposals_outside_allowed_are_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, _store, _log = self._waiting(Path(tmp))
            packet = build_brain_input_packet(state)
            ok = _proposal(state, "RESUME", "EXECUTE", "DISPATCH", "ok")
            validate_proposal_against_state(state, ok, packet=packet)
            cases = {
                "PROPOSAL_COMMAND_NOT_ALLOWED_FOR_STATE": _proposal(state, "COMPLETE", "EXECUTE", "CLOSE", "c1"),
                "PROPOSAL_DECISION_NOT_ALLOWED": _proposal(state, "RESUME", "WAIT", "DISPATCH", "c2"),
                "PROPOSAL_ROUTE_NOT_ALLOWED": _proposal(state, "RESUME", "EXECUTE", "CLOSE", "c3"),
                "PROPOSAL_EXPECTED_REVISION_MISMATCH": {**ok, "expected_state_revision": state["state_revision"] + 1},
            }
            for code, proposal in cases.items():
                with self.assertRaisesRegex(ValueError, code):
                    validate_proposal_against_state(state, proposal, packet=packet)
            stale = {**packet, "state_revision": packet["state_revision"] - 1}
            with self.assertRaisesRegex(ValueError, "PROPOSAL_PACKET_REVISION_MISMATCH"):
                validate_proposal_against_state(state, ok, packet=stale)
            narrow = {**packet, "allowed_decisions": ["BLOCK"]}
            with self.assertRaisesRegex(ValueError, "PROPOSAL_OUTSIDE_PACKET_ALLOWED_DECISIONS"):
                validate_proposal_against_state(state, ok, packet=narrow)

    def test_ask_input_keeps_state_and_log_and_is_waiting_only(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, _store, log = self._waiting(Path(tmp))
            before_events = len(log.read_all())
            ask = _proposal(state, "ASK_INPUT", "ASK_INPUT", "DIRECT_COMMAND", "ask")
            new_state, result = central_controller.commit_brain_proposal(state, ask, event_log=log)
            self.assertEqual(new_state, state)
            self.assertEqual(result["status"], "INPUT_REQUESTED")
            self.assertEqual(len(log.read_all()), before_events)
            running = {**state, "status": "RUNNING"}
            with self.assertRaisesRegex(ValueError, "PROPOSAL_COMMAND_NOT_ALLOWED_FOR_STATE"):
                validate_proposal_against_state(running, _proposal(running, "ASK_INPUT", "ASK_INPUT", "DIRECT_COMMAND", "a2"))

    def test_brain_resume_requeues_needs_brain_segment_with_one_more_attempt(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._waiting(Path(tmp))
            resume = _proposal(state, "RESUME", "EXECUTE", "DISPATCH", "resume")
            with self.assertRaisesRegex(ValueError, "BRAIN_RESUME_REQUIRES_RULINGS"):
                central_controller.commit_brain_proposal(state, resume, event_log=log)
            resume["segment_rulings"] = [{"segment_id": "SEG-INGEST", "ruling": "REQUEUE"}]
            with self.assertRaisesRegex(ValueError, "BRAIN_RESUME_REQUIRES_SEGMENT_STORE"):
                central_controller.commit_brain_proposal(state, resume, event_log=log)
            new_state, result = central_controller.commit_brain_proposal(
                state, resume, event_log=log, segment_store=store, packet=build_brain_input_packet(state),
            )
            self.assertEqual(result["status"], "APPLIED")
            self.assertEqual(result["next"], "DISPATCH_READY")
            self.assertEqual(new_state["status"], "RUNNING")
            [queued] = new_state["queued_segments"]
            self.assertEqual(queued["segment_id"], "SEG-INGEST")
            self.assertEqual(queued["retry_policy"]["max_attempts"], 2)
            queued_events = [e for e in log.read_all("SEGMENT") if e.get("causation_id") == "BRAIN_PROPOSAL:resume"]
            self.assertEqual(len(queued_events), 1)
            started, _packets = start_available(new_state, max_concurrency=1)
            self.assertEqual(started["active_segments"][0]["attempt_number"], 2)
            self.assertEqual(build_brain_input_packet(started, trigger="EXTERNAL_INPUT")["segments"][0]["state"], "ACTIVE")

    def test_brain_block_and_cancel_from_waiting(self) -> None:
        for command, decision, route, status in (("BLOCK", "BLOCK", "BLOCK", "BLOCKED"), ("CANCEL", "CANCEL", "CANCEL", "CANCELLED")):
            with tempfile.TemporaryDirectory() as tmp:
                state, _store, log = self._waiting(Path(tmp))
                new_state, result = central_controller.commit_brain_proposal(
                    state, _proposal(state, command, decision, route, command.lower()), event_log=log,
                )
                self.assertEqual((result["status"], new_state["status"]), ("APPLIED", status))


if __name__ == "__main__":
    unittest.main()
