#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))

import actions_execution_recovery_dispatch as dispatch


class ActionsExecutionRecoveryDispatchTests(unittest.TestCase):
    def diagnostic(self, classification: str):
        return {"diagnostic_id": "ACTIONS_DIAGNOSTIC:123", "classification": classification}

    def test_plan_runner_startup_is_diagnose(self):
        result = dispatch.dispatch(
            {**self.diagnostic("RUNNER_STARTUP_FAILURE"), "head_sha": "abc1234567890"},
            mode="PLAN",
            output=Path("/tmp/diagnostic-result.json"),
            acceptance_output=Path("/tmp/diagnostic-acceptance.json"),
            local_head_sha="abc1234567890",
            attempt_index=0,
        )
        self.assertEqual(result["status"], "PLANNED")
        self.assertEqual(result["decision"], "DIAGNOSE")
        self.assertTrue(result["local_command"])

    def test_execute_runner_startup_diagnosis(self):
        # Local diagnostic PASS -> bounded redispatch (M32 v1.2 section 9.1).
        with patch.object(
            dispatch.subprocess,
            "run",
            return_value=type("P", (), {"returncode": 0})(),
        ) as run, patch.object(
            dispatch,
            "_dispatch_workflow",
            return_value={"status": 204, "body": ""},
        ) as redispatch:
            result = dispatch.dispatch(
                {**self.diagnostic("RUNNER_STARTUP_FAILURE"), "head_sha": "abc1234567890"},
                mode="EXECUTE",
                repo="upqq21477-star/P1",
                token="token",
                workflow_file=".github/workflows/m32-close-acceptance.yml",
                workflow_ref="main",
                output=Path("/tmp/diagnostic-result.json"),
                acceptance_output=Path("/tmp/diagnostic-acceptance.json"),
                local_head_sha="abc1234567890",
                attempt_index=0,
            )
        run.assert_called_once()
        redispatch.assert_called_once()
        self.assertEqual(result["status"], "EXECUTED")
        self.assertEqual(result["decision"], "DIAGNOSE")
        self.assertEqual(result["action"], "github_actions.workflow_dispatch_after_local_diagnosis")

    def test_execute_runner_startup_without_redispatch_credentials_is_error(self):
        with patch.object(
            dispatch.subprocess,
            "run",
            return_value=type("P", (), {"returncode": 0})(),
        ):
            result = dispatch.dispatch(
                {**self.diagnostic("RUNNER_STARTUP_FAILURE"), "head_sha": "abc1234567890"},
                mode="EXECUTE",
                output=Path("/tmp/diagnostic-result.json"),
                acceptance_output=Path("/tmp/diagnostic-acceptance.json"),
                local_head_sha="abc1234567890",
                attempt_index=0,
            )
        self.assertEqual(result["status"], "ERROR")
        self.assertEqual(result["error"], "WORKFLOW_REDISPATCH_REQUIRES_REPO_WORKFLOW_TOKEN_REF")

    def test_plan_local_replay(self):
        root = Path("/tmp/p1-dispatch")
        # REPLAY_LOCAL belongs to WORKFLOW_EXECUTION_FAILURE; RUNNER_STARTUP_FAILURE always DIAGNOSEs.
        result = dispatch.dispatch(
            self.diagnostic("WORKFLOW_EXECUTION_FAILURE"),
            mode="PLAN",
            selection=root / "selection.json",
            observation=root / "observation.json",
            output=root / "result.json",
            acceptance_output=root / "acceptance.json",
            attempt_index=2,
            max_external_retries=2,
        )
        self.assertEqual(result["decision"], "REPLAY_LOCAL")
        self.assertEqual(result["status"], "PLANNED")
        self.assertTrue(result["local_command"])

    def test_not_dispatched_dispatches_workflow(self):
        with patch.object(
            dispatch,
            "_dispatch_workflow",
            return_value={"status": 204, "body": ""},
        ) as redispatch:
            result = dispatch.dispatch(
                {**self.diagnostic("NOT_DISPATCHED"), "head_sha": "abc1234567890"},
                mode="EXECUTE",
                repo="upqq21477-star/P1",
                token="token",
                workflow_file=".github/workflows/m32-close-acceptance.yml",
                workflow_ref="main",
            )
        redispatch.assert_called_once()
        self.assertEqual(result["status"], "EXECUTED")
        self.assertEqual(result["decision"], "RETRY_EXTERNAL")

    def test_startup_failure_budget_exhaustion_blocks(self):
        with patch.object(
            dispatch.subprocess,
            "run",
            return_value=type("P", (), {"returncode": 0})(),
        ):
            result = dispatch.dispatch(
                {**self.diagnostic("RUNNER_STARTUP_FAILURE"), "head_sha": "abc1234567890"},
                mode="EXECUTE",
                repo="upqq21477-star/P1",
                token="token",
                workflow_file=".github/workflows/m32-close-acceptance.yml",
                workflow_ref="main",
                attempt_index=1,
                max_external_retries=1,
                output=Path("/tmp/diagnostic-result.json"),
                acceptance_output=Path("/tmp/diagnostic-acceptance.json"),
            )
        self.assertEqual(result["status"], "BLOCKED")
        self.assertEqual(result["error"], "RECOVERY_RETRY_BUDGET_EXHAUSTED")

    def test_block_never_executes(self):
        with patch.object(dispatch, "_rerun_failed_jobs") as rerun:
            result = dispatch.dispatch(self.diagnostic("UNKNOWN"), mode="EXECUTE")
        rerun.assert_not_called()
        self.assertEqual(result["status"], "BLOCKED")

    def test_local_replay_process_result(self):
        root = Path("/tmp/p1-dispatch")
        with patch.object(dispatch.subprocess, "run", return_value=type("P", (), {"returncode": 2})()) as run:
            result = dispatch.dispatch(
                self.diagnostic("WORKFLOW_EXECUTION_FAILURE"),
                mode="EXECUTE",
                selection=root / "selection.json",
                observation=root / "observation.json",
                output=root / "result.json",
                acceptance_output=root / "acceptance.json",
            )
        run.assert_called_once()
        self.assertEqual(result["status"], "EXECUTED")
        self.assertEqual(result["local_return_code"], 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
