#!/usr/bin/env python3
from __future__ import annotations

import json
import re
import sys
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[2]
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
SCHEMA_DIR = ROOT / "P1-Central-Control/schemas"
SCRIPTS_DIR = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(TESTS_DIR))

import central_controller  # noqa: E402
import state_machine_runtime_gate as runtime_gate  # noqa: E402
from event_log import EventLog  # noqa: E402
from packet_layer import build_result_packet  # noqa: E402
from p7_test_records import records_for  # noqa: E402


class StateMachineRuntimeGateTests(unittest.TestCase):
    def make_segment(self, workflow_id: str, segment_id: str) -> dict:
        return {
            "segment_id": segment_id,
            "workflow_id": workflow_id,
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "完成一個可驗收的工作段",
            "input_scope": "test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 300000,
            "completion_contract": {
                "status": "WORK_COMPLETE",
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "ARTIFACT:execution-001",
            "context_cohort_id": "COHORT-TEST",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
        }

    def make_result(self, task_packet: dict, decision_code: str) -> dict:
        return build_result_packet(
            task_packet,
            {
                "decision_code": decision_code,
                "output_refs": ["ARTIFACT:result-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "unresolved": ["unresolved"] if decision_code == "UNRESOLVED" else [],
                "evidence_refs": ["EVIDENCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "provenance_refs": ["PROVENANCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 1,
                },
                "usage_observed": True,
            },
        )

    def test_initialize_uses_canonical_workflow_state(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        self.assertEqual(state["status"], "READY")
        self.assertEqual(state["state_revision"], 0)
        self.assertIsNone(state["last_command_id"])
        self.assertIsNone(state["last_idempotency_key"])

    def test_runtime_control_schema_accepts_state_control_fields(self) -> None:
        schema = json.loads(
            (SCHEMA_DIR / "workflow_runtime_control.schema.json").read_text(
                encoding="utf-8"
            )
        )
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(
            schema,
            format_checker=FormatChecker(),
        )
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        errors = list(validator.iter_errors(state))
        self.assertEqual(errors, [])

    def test_dispatch_is_forced_through_state_machine(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-TEST", "SEG-001"),
        )
        self.assertEqual(state["status"], "READY")
        self.assertEqual(state["state_revision"], 0)

        with tempfile.TemporaryDirectory() as temp:
            state, task_packets = central_controller.dispatch(
                state,
                event_log=EventLog(Path(temp) / "events.jsonl"),
                execution_store=execution_store,
            )

        self.assertEqual(task_packets[0]["segment_id"], "SEG-001")
        self.assertEqual(state["status"], "RUNNING")
        self.assertEqual(state["state_revision"], 1)
        self.assertEqual(
            state["last_transition"]["to_status"],
            "RUNNING",
        )

    def test_work_complete_reaches_terminal_state_via_gate(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-TEST", "SEG-001"),
        )
        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, task_packets = central_controller.dispatch(
                state, event_log=log, execution_store=execution_store
            )
            result_packet = self.make_result(task_packets[0], "WORK_COMPLETE")
            envelope = execution_store[result_packet["execution_record_ref"]]
            evidence_records, provenance_records = records_for(
                envelope["task_packet"], result_packet, envelope["execution_record"]
            )
            state = central_controller.receive_result(
                state,
                result_packet,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                evidence_records=evidence_records,
                provenance_records=provenance_records,
            )

        self.assertEqual(state["status"], "COMPLETED")
        self.assertEqual(state["state_revision"], 2)
        self.assertEqual(state["terminal_state"], "WORKFLOW_COMPLETE")

        with self.assertRaises(ValueError):
            central_controller.queue_segment(
                state,
                self.make_segment("WF-TEST", "SEG-002"),
            )

    def test_fail_with_queued_work_resumes_without_terminal_state(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-TEST", "SEG-001"),
        )
        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, task_packets = central_controller.dispatch(state, event_log=log, execution_store=execution_store)
            state = central_controller.queue_segment(
                state,
                self.make_segment("WF-TEST", "SEG-002"),
            )
            state = central_controller.receive_result(
                state,
                self.make_result(task_packets[0], "FAIL"),
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
            )

        self.assertEqual(state["status"], "RUNNING")
        self.assertIsNone(state["terminal_state"])
        self.assertEqual(state["state_revision"], 1)

    def test_block_result_is_terminal_and_gate_owned(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-TEST", "SEG-001"),
        )
        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, task_packets = central_controller.dispatch(state, event_log=log, execution_store=execution_store)
            state = central_controller.receive_result(
                state,
                self.make_result(task_packets[0], "BLOCK"),
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
            )

        self.assertEqual(state["status"], "BLOCKED")
        self.assertEqual(state["terminal_state"], "BLOCK")
        self.assertEqual(state["state_revision"], 2)

    def test_unresolved_without_queued_work_blocks_workflow(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-TEST", "SEG-001"),
        )
        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, task_packets = central_controller.dispatch(state, event_log=log, execution_store=execution_store)
            state = central_controller.receive_result(
                state,
                self.make_result(task_packets[0], "UNRESOLVED"),
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
            )

        self.assertEqual(state["status"], "BLOCKED")
        self.assertEqual(state["terminal_state"], "UNRESOLVED")

    def test_invalid_workflow_transition_is_blocked(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        state["status"] = "WAITING"
        with self.assertRaises(ValueError):
            runtime_gate.transition_workflow(state, "START")

    def test_central_controller_has_no_direct_status_or_revision_assignment(self) -> None:
        source = (
            SCRIPTS_DIR / "central_controller.py"
        ).read_text(encoding="utf-8")
        direct_status = re.compile(
            r'state\[\s*["\']status["\']\s*\](?<![=!])\s*=(?!=)'
        )
        direct_revision = re.compile(
            r'state\[\s*["\']state_revision["\']\s*\](?<![=!])\s*=(?!=)'
        )
        self.assertEqual(direct_status.findall(source), [])
        self.assertEqual(direct_revision.findall(source), [])

    def test_invalid_direct_status_write_does_not_change_runtime_revision_contract(self) -> None:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-TEST", "TASK-TEST")
        original_revision = state["state_revision"]
        state["status"] = "COMPLETED"
        self.assertEqual(state["state_revision"], original_revision)
        with self.assertRaises(ValueError):
            runtime_gate.transition_workflow(state, "START")


if __name__ == "__main__":
    unittest.main()
