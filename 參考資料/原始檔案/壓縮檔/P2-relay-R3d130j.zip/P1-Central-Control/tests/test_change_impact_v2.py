#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPT_DIR))

import change_impact_v2


class ChangeImpactV2Tests(unittest.TestCase):
    def test_transitive_dependents_are_bounded_and_deterministic(self) -> None:
        edges = [
            {"source": "a.py", "target": "b.py"},
            {"source": "b.py", "target": "c.py"},
            {"source": "d.py", "target": "b.py"},
        ]
        direct, transitive = change_impact_v2.transitive_dependents(edges, {"c.py"})
        self.assertEqual(direct, ["b.py"])
        self.assertEqual(transitive, ["a.py", "d.py"])

    def test_git_rename_is_classified_semantically(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            import subprocess
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.email", "p1@test.invalid"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.name", "P1 Test"], cwd=root, check=True)
            target = root / "old.py"
            target.write_text("x = 1\n", encoding="utf-8")
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-qm", "base"], cwd=root, check=True)
            base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
            target.rename(root / "new.py")
            subprocess.run(["git", "add", "-A"], cwd=root, check=True)
            subprocess.run(["git", "commit", "-qm", "rename"], cwd=root, check=True)
            head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
            rows = change_impact_v2.git_change_entries(root, base, head)
            self.assertEqual(rows[0]["status"], "RENAMED")
            self.assertEqual(rows[0]["old_path"], "old.py")
            self.assertEqual(rows[0]["path"], "new.py")


if __name__ == "__main__":
    unittest.main()
