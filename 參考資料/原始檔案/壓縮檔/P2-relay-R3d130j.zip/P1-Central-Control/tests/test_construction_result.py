import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from construction_entrypoint import validate_result


class ConstructionResultTests(unittest.TestCase):
    def test_pass_result_has_machine_record_shape(self):
        result = {
            "schema_version": "1.0",
            "request_id": "REQ-1",
            "target_type": "CAPABILITY",
            "target_id": "CAP-X",
            "status": "PASS",
            "phase": "FINALIZE",
            "finalized": True,
            "registration": {"status": "PASS", "registration": "READY"},
            "construction_fingerprint": "a" * 64,
        }
        self.assertTrue(validate_result(result))

    def test_block_result_has_machine_record_shape(self):
        result = {
            "schema_version": "1.0",
            "request_id": "REQ-2",
            "target_type": "SKILL",
            "target_id": "SKILL-X",
            "status": "BLOCK",
            "phase": "CONSTRUCTION_LIFECYCLE",
            "finalized": False,
            "registration": {"status": "BLOCK", "reason": "SEMANTIC_SPEC_MISSING"},
            "reason": "SEMANTIC_SPEC_MISSING",
        }
        self.assertTrue(validate_result(result))


if __name__ == "__main__":
    unittest.main()
