"""S2b: Run.step boundary (G1), FP3 error path, ladder, resume (G3), outcome_class. SIMULATED_PASS."""
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import atomic_write as aw  # noqa: E402
import p2_run  # noqa: E402
import run_journal as rj  # noqa: E402

EDIT = {"path": "calc.py", "old": "a - b", "new": "a + b"}
CTOR = dict(write_scope=["calc.py"], protected=[], budget=12, goal_confirmed=True, run_id="RUN-T")
SCRIPT = [("read", {"path": "calc.py"}), ("edit", EDIT), ("run_tests", {}), ("search", {"pattern": "add"})]


class Died(BaseException):
    pass


def state(r):
    return (r.trace[-1]["hash"], r.attempts, r.diffs, r.budget, r.mode)


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())

    def mk(self, name="w", **kw):
        r = p2_run.Run(p2_run._toy(self.d / name), **CTOR, **kw)
        self.assertTrue(p2_run._build_mode(r))
        return r

    def resume(self, name, jp):
        return p2_run.Run.resume(self.d / name, jp, **CTOR)


class StepBoundary(Base):
    def test_decode_error(self):
        r = self.mk()
        (r.work / "bad.txt").write_bytes(b"\xff\xfe\x00")
        b = r.budget
        out = r.step("read", {"path": "bad.txt"})
        self.assertEqual((out["ok"], out["code"]), (False, "DECODE_ERROR"))
        self.assertEqual((r.trace[-1]["verdict"], r.budget), ("ERROR", b - 1))

    def test_timeout_and_launch_failure_fast_equals_legacy(self):
        for exc, code in ((subprocess.TimeoutExpired("x", 30), "TIMEOUT"), (FileNotFoundError("x"), "LAUNCH_FAILED")):
            seen = []
            for fast in (True, False):
                r = self.mk(f"w{code}{fast}", use_fast=fast)
                b = r.budget
                with mock.patch("subprocess.run", side_effect=exc):
                    out = r.step("run_tests", {})
                self.assertEqual(out["code"], code)
                self.assertEqual((r.trace[-1]["verdict"], r.budget), ("ERROR", b - 1))
                a = r.attempts[-1]
                seen.append((a["outcome"], a["error_code"]))
            self.assertEqual(seen[0], seen[1])
            self.assertEqual(seen[0], ("incomplete", code))

    def test_interrupt_logged_and_reraised(self):
        r = self.mk()
        with mock.patch.object(p2_run.Run, "_read", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                r.step("read", {"path": "calc.py"})
        self.assertEqual(r.trace[-1]["verdict"], "INTERRUPTED")

    def test_unexpected_fail_closed_no_message(self):
        r = self.mk()
        with mock.patch.object(p2_run.Run, "_search", side_effect=RuntimeError("secret-token")):
            out = r.step("search", {"pattern": "x"})
        self.assertEqual(out["code"], "UNEXPECTED")
        self.assertNotIn("secret-token", json.dumps(r.trace) + json.dumps(out))

    def test_reject_shape_unchanged(self):
        self.assertEqual(self.mk().step("bogus", {}), {"ok": False, "code": "TOOL_UNKNOWN"})

    def test_edit_io_error_not_retryable_and_file_intact(self):
        with mock.patch("p2_run.atomic_write", side_effect=OSError("disk")):
            r = self.mk()
            out = r.step("edit", EDIT)
        self.assertEqual((out["code"], out["retryable"]), ("IO_ERROR", False))
        self.assertIn("a - b", (r.work / "calc.py").read_text(encoding="utf-8"))

    def test_default_write_is_atomic(self):
        r = self.mk()
        orig = Path.write_text

        def boom(self, *a, **k):
            orig(self, "", encoding="utf-8")
            raise OSError("disk")
        with mock.patch.object(Path, "write_text", boom):
            out = r.step("edit", EDIT)
        self.assertTrue(out["ok"])  # atomic path never goes through write_text, so no truncated target
        self.assertEqual((r.work / "calc.py").read_text(encoding="utf-8"), "def add(a, b):\n    return a + b\n")


class LadderAndClose(Base):
    def inc(self, r, code):
        r.attempts.append({"step": "run_tests", "outcome": "incomplete", "error_code": code, "head_sha": "x", "t": len(r.attempts)})

    def test_incomplete_retry_once_then_stop(self):
        r = self.mk()
        self.inc(r, "TIMEOUT")
        self.assertEqual(r.ladder("run_tests")["action"], "RETRY")
        self.inc(r, "TIMEOUT")
        d = r.ladder("run_tests")
        self.assertEqual((d["action"], d["reason"]), ("STOP_WAITING", "INCOMPLETE_LIMIT_REACHED"))

    def test_launch_failed_not_retryable(self):
        r = self.mk()
        self.inc(r, "LAUNCH_FAILED")
        d = r.ladder("run_tests")
        self.assertEqual((d["action"], d["reason"]), ("STOP_FAILED", "NOT_RETRYABLE"))

    def test_ladder_error_fails_closed(self):
        r = self.mk()
        with mock.patch.object(p2_run.dep, "retry_decision", side_effect=RuntimeError):
            d = r.ladder("run_tests")
        self.assertEqual((d["action"], d["reason"]), ("STOP_WAITING", "LADDER_ERROR"))

    def test_outcome_class(self):
        for outcome, want in (("success", "PASSED"), ("failure", "FAILED"), ("incomplete", "INCOMPLETE")):
            r = self.mk(f"c{outcome}")
            r.attempts.append({"step": "run_tests", "outcome": outcome, "head_sha": "x", "t": 0})
            self.assertEqual(r.close(self.d / f"{outcome}.log", "c1")["outcome_class"], want)

    def test_close_write_failure_not_raised(self):
        r = self.mk()
        with mock.patch.object(p2_run.el, "EventLog", side_effect=OSError("disk")):
            res = r.close(self.d / "x.log", "c1")
        self.assertEqual((res["outcome_class"], res["close_error"]), ("INCOMPLETE", "CLOSE_WRITE_FAILED"))


class JournalAndResume(Base):
    def test_unwritable_dir_rejects_construction(self):
        with mock.patch("run_journal.os.access", return_value=False):
            with self.assertRaises(rj.JournalError):
                self.mk(journal_path=self.d / "j.jsonl")

    def test_journal_write_failure_stops_run(self):
        r = self.mk(journal_path=self.d / "j.jsonl")
        with mock.patch("run_journal.os.fsync", side_effect=OSError("disk")):
            out = r.step("read", {"path": "calc.py"})
        self.assertEqual((out["code"], out["reason"]), ("INCOMPLETE", "journal_write_failed"))
        b = r.budget
        self.assertEqual(r.step("read", {"path": "calc.py"})["code"], "INCOMPLETE")
        self.assertEqual(r.budget, b)

    def test_resume_equivalence_at_every_boundary(self):
        ref = self.mk("ref", journal_path=self.d / "ref.jl")
        for t, a in SCRIPT:
            ref.step(t, a)
        want = state(ref)
        ref.release()
        for k in range(len(SCRIPT) + 1):
            jp = self.d / f"k{k}.jl"
            r = self.mk(f"k{k}", journal_path=jp)
            for t, a in SCRIPT[:k]:
                r.step(t, a)
            r.release()
            res = self.resume(f"k{k}", jp)
            self.assertEqual(res.status, "RESUMED", res.reason)
            for t, a in SCRIPT[k:]:
                res.run.step(t, a)
            self.assertEqual(state(res.run), want, k)
            res.run.release()

    def died_edit(self, name, write_fn):
        jp = self.d / f"{name}.jl"
        r = self.mk(name, journal_path=jp, write_fn=write_fn)
        with self.assertRaises(Died):
            r.step("edit", EDIT)
        r.release()
        return jp

    def test_resume_edit_applied_is_recovered(self):
        def dead(p, t):
            aw.atomic_write(p, t)
            raise Died()
        jp = self.died_edit("ap", dead)
        res = self.resume("ap", jp)
        self.assertEqual(res.status, "RESUMED")
        self.assertEqual((len(res.run.diffs), res.run.budget, res.run.trace[-1]["code"]), (1, 11, "RECOVERED"))

    def test_resume_edit_not_applied_redoable(self):
        def dead(p, t):
            raise Died()
        jp = self.died_edit("na", dead)
        res = self.resume("na", jp)
        self.assertEqual((res.status, res.run.diffs, res.run.budget), ("RESUMED", [], 12))
        self.assertTrue(res.run.step("edit", EDIT)["ok"])

    def test_resume_edit_undecidable_changes_nothing(self):
        def dead(p, t):
            raise Died()
        jp = self.died_edit("ud", dead)
        (self.d / "ud" / "calc.py").write_text("zzz\n", encoding="utf-8")
        res = self.resume("ud", jp)
        self.assertEqual((res.status, res.reason), ("INCOMPLETE", "INTENT_UNDECIDABLE"))
        self.assertEqual((self.d / "ud" / "calc.py").read_text(encoding="utf-8"), "zzz\n")

    def test_resume_twice_same_state_and_closed_and_mismatch(self):
        jp = self.d / "t.jl"
        r = self.mk("t", journal_path=jp)
        for t, a in SCRIPT[:2]:
            r.step(t, a)
        r.release()
        a1 = self.resume("t", jp)
        s1 = state(a1.run)
        a1.run.release()
        a2 = self.resume("t", jp)
        self.assertEqual(state(a2.run), s1)
        a2.run.release()
        bad = p2_run.Run.resume(self.d / "t", jp, **{**CTOR, "write_scope": ["other.py"]})
        self.assertEqual(bad.status, "FAILED")
        a3 = self.resume("t", jp)
        a3.run.close(self.d / "t.log", "c1")
        self.assertEqual(self.resume("t", jp).status, "NOTHING_TO_RESUME")

    def test_resume_corrupt_middle_line(self):
        jp = self.d / "c.jl"
        r = self.mk("c", journal_path=jp)
        r.step("read", {"path": "calc.py"})
        r.release()
        lines = jp.read_text(encoding="utf-8").splitlines()
        lines[2] = lines[2].replace("ALLOW", "REJECT")
        jp.write_text("\n".join(lines) + "\n", encoding="utf-8")
        before = jp.read_bytes()
        res = self.resume("c", jp)
        self.assertEqual(res.status, "INCOMPLETE")
        self.assertTrue(res.reason.startswith("JOURNAL_CORRUPT:"))
        self.assertEqual(jp.read_bytes(), before)

    def test_ladder_after_resume_uses_rebuilt_attempts(self):
        jp = self.d / "l.jl"
        r = self.mk("l", journal_path=jp)
        with mock.patch("subprocess.run", side_effect=subprocess.TimeoutExpired("x", 30)):
            r.step("run_tests", {})
        r.release()
        self.assertEqual(self.mk("fresh").ladder("run_tests")["action"], "PROCEED")  # gap: no journal
        res = self.resume("l", jp)
        self.assertEqual(res.run.ladder("run_tests")["action"], "RETRY")
        res.run.release()


if __name__ == "__main__":
    unittest.main()
