#!/usr/bin/env python3
from __future__ import annotations

from typing import Any


def records_for(
    task_packet: dict[str, Any],
    result_packet: dict[str, Any],
    execution_record: dict[str, Any],
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    evidence = [{
        "object_id": result_packet["evidence_refs"][0],
        "kind": "EVIDENCE",
        "schema_version": "1.0",
        "content_hash": "sha256:" + "0" * 64,
        "source_ref": task_packet["input_refs"][0],
        "claim_ref": result_packet["object_id"],
        "relation": "SUPPORTS",
        "captured_at": execution_record["start_time"],
    }]
    provenance = [{
        "object_id": result_packet["provenance_refs"][0],
        "kind": "PROVENANCE",
        "schema_version": "1.0",
        "content_hash": "sha256:" + "0" * 64,
        "subject_ref": result_packet["object_id"],
        "activity_ref": execution_record["execution_record_ref"],
        "agent_ref": (
            f"SKILL:{result_packet['skill_id']}-{result_packet['skill_version']}"
        ),
        "input_refs": list(task_packet["input_refs"]),
        "output_refs": list(result_packet["output_refs"]),
        "relation": "WAS_GENERATED_BY",
    }]
    return evidence, provenance
