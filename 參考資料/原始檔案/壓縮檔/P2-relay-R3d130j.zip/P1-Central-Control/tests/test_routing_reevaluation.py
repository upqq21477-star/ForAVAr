#!/usr/bin/env python3
from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from routing_reevaluation import reevaluate, validate_report  # noqa: E402


class RoutingReevaluationTests(unittest.TestCase):
    def m2_report(self, status="INSUFFICIENT_DATA") -> dict:
        return {
            "object_id": "CAPABILITY_REEVALUATION:M2-TEST",
            "kind": "CAPABILITY_REEVALUATION",
            "schema_version": "1.0",
            "content_hash": "sha256:" + ("a" * 64),
            "reevaluation_id": "M2-TEST",
            "source_change_id": "CHANGE:M3-TEST",
            "source_impact_status": "PASS",
            "affected_capabilities": ["CAP-EXTRACT", "CAP-CLASSIFY"],
            "evaluations": [
                {
                    "capability_id": "CAP-EXTRACT",
                    "evaluation_ref": "NATIVE_REPLACEMENT_EVAL:EVAL-1",
                    "status": "PASS",
                    "baseline_mode": "MODEL_PLUS_GUARD",
                    "candidate_mode": "MODEL_ONLY",
                    "evaluation_state": "FINALIZED",
                }
            ],
            "pending": [
                {
                    "capability_id": "CAP-CLASSIFY",
                    "reason_code": "MEASUREMENT_MISSING",
                    "required_inputs": ["sample_size"],
                }
            ],
            "status": status,
        }

    def valid_m2_report(self) -> dict:
        report = self.m2_report()
        capability_reevaluation = __import__("capability_reevaluation")
        report["content_hash"] = capability_reevaluation.content_hash(report)
        return report

    def test_pass_evaluation_becomes_routing_candidate(self):
        report = reevaluate(self.valid_m2_report(), routing_reevaluation_id="M3-TEST-001")
        self.assertEqual(report["status"], "INSUFFICIENT_DATA")
        self.assertEqual(len(report["routes"]), 1)
        route = report["routes"][0]
        self.assertEqual(route["route_mode"], "MODEL_ONLY")
        self.assertEqual(route["decision_code"], "CANDIDATE_READY")
        self.assertEqual(route["evaluation_state"], "FINALIZED")
        self.assertEqual(len(report["pending"]), 1)
        validate_report(report)

    def test_blocked_source_cannot_produce_adoptable_route(self):
        report = self.m2_report(status="BLOCK")
        report["evaluations"][0]["status"] = "BLOCK"
        capability_reevaluation = __import__("capability_reevaluation")
        report["content_hash"] = capability_reevaluation.content_hash(report)
        result = reevaluate(report, routing_reevaluation_id="M3-TEST-002")
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["routes"][0]["decision_code"], "BLOCK")
        self.assertIsNone(result["routes"][0]["route_mode"])

    def test_old_m2_shape_is_rejected(self):
        report = self.valid_m2_report()
        del report["evaluations"][0]["candidate_mode"]
        report["content_hash"] = __import__("capability_reevaluation").content_hash(report)
        with self.assertRaises(ValueError):
            reevaluate(report)

    def test_m3_does_not_accept_raw_measurement_or_registry(self):
        report = self.valid_m2_report()
        report["raw_measurement"] = {"sample_size": 100}
        report["content_hash"] = __import__("capability_reevaluation").content_hash(report)
        with self.assertRaises(ValueError):
            reevaluate(report)


if __name__ == "__main__":
    unittest.main()
