#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from capability_reevaluation import reevaluate, validate_report  # noqa: E402


class CapabilityReevaluationTests(unittest.TestCase):
    def impact_scan(self) -> dict:
        return {
            "scan_id": "IMPACT:M2-001",
            "change_id": "CHANGE:M2-001",
            "status": "PASS",
            "decision": "PROCEED",
            "unknown_paths": [],
            "affected_capabilities": [
                "CAP-EXTRACT",
                "CAP-CLASSIFY",
            ],
            "required_regression_sets": [
                "e2e",
            ],
            "path_results": [
                {
                    "path": "P1-Central-Control/scripts/capability_reevaluation.py",
                    "matched_rule_ids": ["CONTROL_SCRIPTS"],
                    "change_type": "RUNTIME",
                    "known": True,
                }
            ],
            "rule_registry": "M1_IMPACT_MAP_V1",
            "reason_codes": ["IMPACT_RESOLVED"]
        }

    def registry(self) -> dict:
        return {
            "version": "1.2",
            "capabilities": [
                {
                    "capability_id": "CAP-EXTRACT",
                    "kind": "MODEL_NATIVE",
                    "retirement_state": "ACTIVE"
                },
                {
                    "capability_id": "CAP-CLASSIFY",
                    "kind": "MODEL_NATIVE",
                    "retirement_state": "ACTIVE"
                }
            ]
        }

    def measurement(self) -> dict:
        return {
            "CAP-EXTRACT": {
                "evaluation_id": "EVAL-M2-TEST-001",
                "capability_id": "CAP-EXTRACT",
                "baseline_mode": "MODEL_PLUS_GUARD",
                "candidate_mode": "MODEL_ONLY",
                "candidate_model_ref": "TEST-CANDIDATE",
                "sample_size": 100,
                "schema_compatibility": {"checked": True, "passed": True},
                "behavior_compatibility": {
                    "passed": 98,
                    "total": 100,
                    "rate": 0
                },
                "acceptance": {
                    "passed": 100,
                    "total": 100,
                    "rate": 0
                },
                "reliability": {
                    "successes": 99,
                    "total": 100,
                    "rate": 0
                },
                "cost": {
                    "baseline_unit_cost": 1.0,
                    "candidate_unit_cost": 0.8,
                    "ratio": 0
                },
                "regression_count": 0,
                "evidence_refs": ["EVIDENCE:M2-TEST"]
            }
        }

    def test_accepts_m1_change_event_and_impact_scan_envelope(self):
        document = {
            "change_event": {
                "change_id": "CHANGE:M2-ENVELOPE",
                "change_type": "MODEL",
                "base_ref": "BASE",
                "head_ref": "HEAD",
                "changed_paths": ["model/update"],
                "created_at": "2026-10-03T11:00:00Z",
                "detector": "P1_CHANGE_EVENT",
            },
            "impact_scan": self.impact_scan(),
        }
        document["impact_scan"]["change_id"] = document["change_event"]["change_id"]
        report = reevaluate(
            document["impact_scan"],
            capability_registry=self.registry(),
            measurements=self.measurement(),
            reevaluation_id="M2-ENVELOPE-001",
        )
        self.assertEqual(report["source_change_id"], "CHANGE:M2-ENVELOPE")

    def test_uses_impact_scan_capabilities_only(self):
        report = reevaluate(
            self.impact_scan(),
            capability_registry=self.registry(),
            measurements=self.measurement(),
            reevaluation_id="M2-TEST-001"
        )
        self.assertEqual(
            report["affected_capabilities"],
            ["CAP-CLASSIFY", "CAP-EXTRACT"]
        )
        self.assertEqual(report["status"], "INSUFFICIENT_DATA")
        self.assertEqual(len(report["evaluations"]), 1)
        self.assertEqual(report["evaluations"][0]["baseline_mode"], "MODEL_PLUS_GUARD")
        self.assertEqual(report["evaluations"][0]["candidate_mode"], "MODEL_ONLY")
        self.assertEqual(report["evaluations"][0]["evaluation_state"], "FINALIZED")
        self.assertEqual(len(report["pending"]), 1)
        self.assertEqual(
            report["pending"][0]["capability_id"],
            "CAP-CLASSIFY"
        )
        validate_report(report)

    def test_passes_when_all_affected_capabilities_have_passing_measurements(self):
        measurements = self.measurement()
        measurements["CAP-CLASSIFY"] = {
            **measurements["CAP-EXTRACT"],
            "evaluation_id": "EVAL-M2-TEST-002",
            "capability_id": "CAP-CLASSIFY"
        }
        report = reevaluate(
            self.impact_scan(),
            capability_registry=self.registry(),
            measurements=measurements,
            reevaluation_id="M2-TEST-002"
        )
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(len(report["pending"]), 0)
        self.assertEqual(
            {item["status"] for item in report["evaluations"]},
            {"PASS"}
        )

    def test_blocks_when_impact_scan_is_blocked(self):
        impact = self.impact_scan()
        impact["status"] = "BLOCK"
        impact["decision"] = "BLOCK"
        with self.assertRaises(ValueError):
            reevaluate(
                impact,
                capability_registry=self.registry(),
                measurements=self.measurement(),
            )

    def test_blocks_unknown_capability_reference(self):
        impact = self.impact_scan()
        impact["affected_capabilities"] = ["CAP-UNKNOWN"]
        with self.assertRaises(ValueError):
            reevaluate(
                impact,
                capability_registry=self.registry(),
                measurements=self.measurement(),
            )

    def test_does_not_change_registry_or_routing(self):
        registry = self.registry()
        original = json.dumps(registry, sort_keys=True)
        reevaluate(
            self.impact_scan(),
            capability_registry=registry,
            measurements=self.measurement(),
        )
        self.assertEqual(json.dumps(registry, sort_keys=True), original)


if __name__ == "__main__":
    unittest.main()
