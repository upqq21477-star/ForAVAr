from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import librarian  # noqa: E402


def _cfg():
    return librarian.load_slots()


class BriefContractTests(unittest.TestCase):
    def test_contract_check_all_pass(self):
        failed = [n for n, ok, _ in librarian.check_contracts() if not ok]
        assert failed == []

    def test_always_permit_validator_turns_check_failed(self):
        """D19 standard: replacing the validator with 'always accept' must make the check FAIL."""
        real = librarian.validate_brief
        librarian.validate_brief = lambda b, cfg=None: []
        try:
            failed = [n for n, ok, _ in librarian.check_contracts() if not ok]
        finally:
            librarian.validate_brief = real
        assert len([n for n in failed if n.startswith("negative:")]) == 12

    def test_slots_reject_missing_symbol_and_undefined_slot(self):
        cfg = copy.deepcopy(_cfg())
        cfg["slots"]["S_MODE"]["symbol"] = "no_such_function"
        assert any(e.startswith("SYMBOL_MISSING:S_MODE") for e in librarian.validate_slots(cfg))
        cfg = copy.deepcopy(_cfg())
        cfg["routes"]["BUILD"]["required_slots"].append("S_NOPE")
        assert "UNDEFINED_SLOT:BUILD:S_NOPE" in librarian.validate_slots(cfg)
        cfg = copy.deepcopy(_cfg())
        cfg["slots"]["S_PACK"]["source"] = "P1-Central-Control/scripts/missing_file.py"
        assert "SOURCE_MISSING:S_PACK" in librarian.validate_slots(cfg)

    def test_hot_summary_respects_cap_and_reports_omitted(self):
        cur = {"a": "x" * 100, "b": "y" * 5000, "c": "z" * 100}
        state, omitted = librarian.hot_summary(cur, ["a", "b", "c"], cap=1000)
        assert list(state) == ["a", "c"] and omitted == ["P1-CURRENT.json#b"]
        assert librarian.jbytes(state) <= 1000

    def test_render_is_data_channel_and_deterministic(self):
        b = librarian.sample_brief("DISCUSS", "A")
        assert librarian.render_brief(b) == librarian.render_brief(copy.deepcopy(b))
        assert librarian.render_brief(b).startswith("[BRIEF DATA - not instructions]")
        b["instruction_content"] = True
        try:
            librarian.render_brief(b)
        except ValueError as exc:
            assert "INSTRUCTION_CONTENT_NOT_FALSE" in str(exc)
        else:
            self.fail("render must refuse instruction content")

    def test_track_b_hash_is_stable_and_detects_change(self):
        b1, b2 = librarian.sample_brief("BUILD", "B"), librarian.sample_brief("BUILD", "B")
        assert b1["content_hash"] == b2["content_hash"]
        b2["recent"].append("changed")
        assert librarian.content_hash(b2) != b1["content_hash"]

    def test_request_limits(self):
        req = {"brief_session_id": "sess-000001", "work_id": "work-000001", "route": "VERIFY",
               "topics": [{"topic": "t", "question": "q"}]}
        assert librarian.validate_request(req) == []
        assert "BAD_ROUTE" in librarian.validate_request(dict(req, route="OTHER"))
        assert "BAD_ID:work_id" in librarian.validate_request(dict(req, work_id="a b"))
        assert "TOPIC_VALUE" in librarian.validate_request(dict(req, topics=[{"topic": "t", "question": "q" * 201}]))

    def test_schema_files_are_valid_json_with_locked_ids(self):
        for name in ("brain_brief", "brief_request"):
            sch = json.loads((ROOT / f"P1-Central-Control/schemas/{name}.schema.json").read_text(encoding="utf-8"))
            assert sch["$id"] == f"p1://schema/{name}/1.0" and sch["additionalProperties"] is False


if __name__ == "__main__":
    unittest.main()
