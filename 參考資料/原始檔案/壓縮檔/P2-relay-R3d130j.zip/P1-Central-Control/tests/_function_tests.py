"""Make module-level ``test_*`` functions visible to ``unittest discover``.

The M33 role-isolation tests are written as plain functions (pytest style). The
gate workflow (``p1-role-isolation-gate.yml``) and the local acceptance run them with
``python3 -m unittest discover``, which previously collected **0 tests** from these
modules (a silent pass). A module opts in with two lines at the bottom::

    from _function_tests import as_unittest
    load_tests = as_unittest(__name__)

The test bodies are untouched and still run under pytest (which ignores load_tests).
"""
from __future__ import annotations

import inspect
import sys
import unittest


def as_unittest(module_name: str):
    def load_tests(loader, standard_tests, pattern):
        module = sys.modules[module_name]
        suite = unittest.TestSuite()
        suite.addTests(standard_tests)  # keep any real TestCase classes
        namespace = {}
        for name, func in sorted(vars(module).items()):
            if (
                name.startswith("test_")
                and inspect.isfunction(func)
                and func.__module__ == module.__name__
            ):
                if inspect.signature(func).parameters:
                    raise TypeError(f"{module_name}.{name}: fixtures are not supported by the bridge")
                namespace[name] = (lambda f: lambda self: f())(func)
        if namespace:
            # A real TestCase per module so failures are reported as module.Class.test_name.
            case = type("FunctionTests", (unittest.TestCase,), namespace)
            case.__module__ = module_name
            case.__qualname__ = "FunctionTests"
            suite.addTests(loader.loadTestsFromTestCase(case))
        return suite

    return load_tests
