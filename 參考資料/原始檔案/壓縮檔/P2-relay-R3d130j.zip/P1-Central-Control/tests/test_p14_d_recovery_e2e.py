#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
FIXTURES = ROOT / "P1-Central-Control/fixtures"
sys.path.insert(0, str(SCRIPTS))

from p14_d_recovery_entrypoint import execute


class P14DRecoveryE2ETests(unittest.TestCase):
    def test_runner_startup_failure_plus_simulated_local_pass_is_scenario_only(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "result.json"
            result = execute(
                run_path=FIXTURES / "p14-d-recovery-run-37185662542.json",
                jobs_path=FIXTURES / "p14-d-recovery-jobs-37185662542.json",
                local_bundle_path=FIXTURES / "p14-d-local-acceptance-pass-3b1fec8b94bdcc78f4ae6c31eef42bac1237dbb5.json",
                head_sha="3b1fec8b94bdcc78f4ae6c31eef42bac1237dbb5",
                output_path=output,
                allow_simulated=True,
            )
            # M32 v1.2: runner startup failure + local PASS must NOT become PROGRAM_VERIFIED.
            self.assertEqual(result["status"], "INCOMPLETE")
            self.assertEqual(result["diagnostic"]["classification"], "RUNNER_STARTUP_FAILURE")
            self.assertEqual(result["diagnostic"]["head_sha"], "3b1fec8b94bdcc78f4ae6c31eef42bac1237dbb5")
            self.assertEqual(result["closure"]["closure_status"], "INCOMPLETE")
            self.assertEqual(result["closure"]["program_truth"], "PROGRAM_UNRESOLVED")
            self.assertEqual(result["closure"]["reason_code"], "LOCAL_PASS_DOES_NOT_VERIFY_EXTERNAL_EXECUTION")
            self.assertEqual(result["truth_record"]["status"], "INCOMPLETE")
            self.assertEqual(result["local_acceptance"]["evidence_class"], "SIMULATED_SCENARIO")
            self.assertEqual(result["truth_boundary"], "EXISTING_P1_DIAGNOSTIC_CLOSURE_TRUTH_CHAIN")
            json.loads(output.read_text(encoding="utf-8"))

    def test_head_mismatch_is_rejected_before_closure(self):
        with tempfile.TemporaryDirectory() as tmp:
            output = Path(tmp) / "result.json"
            with self.assertRaisesRegex(ValueError, "ACTIONS_RUN_HEAD_SHA_MISMATCH"):
                execute(
                    run_path=FIXTURES / "p14-d-recovery-run-37185662542.json",
                    jobs_path=FIXTURES / "p14-d-recovery-jobs-37185662542.json",
                    local_bundle_path=FIXTURES / "p14-d-local-acceptance-pass-3b1fec8b94bdcc78f4ae6c31eef42bac1237dbb5.json",
                    head_sha="deadbeef",
                    output_path=output,
                    allow_simulated=True,
                )


if __name__ == "__main__":
    unittest.main()
