import json
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
P1 = ROOT / 'P1-Central-Control'
sys.path.insert(0, str(ROOT / 'tools'))
sys.path.insert(0, str(ROOT / 'tools'))
import capability_gate as cg
import caller_audit
DORMANT = ('CAP-CLUSTER', 'CAP-TREND', 'CAP-ANOMALY')
KINDS = {'FP4': 'scenario', 'FP5': 'integration_scenario', 'FP6': 'invariant_scenario', 'FP7': 'prototype', 'FP8': 'prototype'}

def _tasks():
    reg = json.loads((P1 / 'policy' / 'batch_acceptance.v1.0.json').read_text(encoding='utf-8'))
    return [t for b in reg['batches'] for t in b.get('tasks', [])]

class RegistryTests(unittest.TestCase):

    def test_fp4_to_fp8_reclassified(self):
        seen = {}
        for t in _tasks():
            d = t.get('distilled')
            if d and d.get('fast_path_id') in KINDS:
                seen[d['fast_path_id']] = d
        self.assertEqual(set(seen), set(KINDS))
        for fp, d in seen.items():
            self.assertEqual(d.get('kind'), KINDS[fp], fp)
            self.assertIn('mirrors', d)
            self.assertIsNone(d['mirrors'])

    def test_fp9_fp10_contract_prototypes(self):
        found = {}
        for t in _tasks():
            for c in t.get('contract_prototypes', []):
                found[c['fast_path_id']] = c
        self.assertEqual(set(found), {'FP9', 'FP10'})
        for c in found.values():
            self.assertEqual(c['kind'], 'prototype')
            self.assertIsNone(c['mirrors'])

    def test_t4_specs_only_real_distilled(self):
        self.assertEqual(caller_audit.registry_specs(ROOT), ['path_distill:fp_path_gate', 'path_distill:fp_test_outcome', 'path_distill:fp_tool_gate'])

    def test_registry_specs_skips_non_distilled_kind(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / caller_audit.REGISTRY
            p.parent.mkdir(parents=True, exist_ok=True)
            reg = {'batches': [{'tasks': [{'status': 'DONE', 'distilled': {'function': 'm:a'}}, {'status': 'DONE', 'distilled': {'function': 'm:b', 'kind': 'prototype'}}, {'status': 'DONE', 'distilled': {'function': 'm:c', 'kind': 'distilled'}}]}]}
            p.write_text(json.dumps(reg), encoding='utf-8')
            self.assertEqual(caller_audit.registry_specs(Path(d)), ['m:a', 'm:c'])

    def test_baseline_waivers_reduced(self):
        b = json.loads((ROOT / 'tools' / 'baseline_callers.json').read_text(encoding='utf-8'))
        self.assertLess(len(b['waivers']), 5)
        self.assertEqual(b.get('waivers_max'), len(b['waivers']))

class StateFileTests(unittest.TestCase):

    def setUp(self):
        self.sd = P1 / 'state' / 'capabilities'
        reg = json.loads((P1 / 'capability_registry.json').read_text(encoding='utf-8'))['capabilities']
        items = reg.values() if isinstance(reg, dict) else reg
        self.kinds = {c['capability_id']: c['kind'] for c in items}
        self.modes = json.loads((P1 / 'evolution_policy.json').read_text(encoding='utf-8'))['allowed_modes']

    def test_23_files_same_fields(self):
        files = sorted(self.sd.glob('CAP-*.json'))
        self.assertEqual(len(files), 23)
        ref = set(json.loads((self.sd / 'CAP-SEARCH.json').read_text(encoding='utf-8')))
        for f in files:
            d = json.loads(f.read_text(encoding='utf-8'))
            self.assertEqual(set(d), ref, f.name)
            self.assertEqual(d['capability_id'], f.stem)
            self.assertIn(d['operating_mode'], self.modes)

    def test_initial_modes_follow_10_3(self):
        for cid, kind in self.kinds.items():
            if cid == 'CAP-SEARCH':
                continue
            d = json.loads((self.sd / (cid + '.json')).read_text(encoding='utf-8'))
            exp = 'DORMANT' if cid in DORMANT else 'MODEL_PLUS_GUARD' if kind == 'MODEL_NATIVE' else 'SKILL'
            self.assertEqual(d['operating_mode'], exp, cid)
            self.assertEqual(d['state_revision'], 0)

class DeclarationTests(unittest.TestCase):

    def _decl(self):
        return json.loads((P1 / 'policy' / 'capability_declarations.v1.0.json').read_text(encoding='utf-8'))

    def test_dormant_declared_with_adr(self):
        dec = self._decl()['dormant']
        self.assertEqual(set(dec), set(DORMANT))
        for cid, v in dec.items():
            self.assertEqual((v['state'], v['consumers']), ('DORMANT', 0))
            self.assertTrue((ROOT / v['adr']).is_file(), v['adr'])

    def test_verify_declarations_clean(self):
        self.assertEqual(cg.verify_declarations(ROOT), [])

    def test_consumers_positive_but_dormant_is_inconsistent(self):
        dec = self._decl()
        dec['dormant']['CAP-CLUSTER']['consumers'] = 1
        probs = cg.verify_declarations(ROOT, dec)
        self.assertTrue(any(('CAP-CLUSTER' in p for p in probs)))

    def test_missing_adr_is_inconsistent(self):
        dec = self._decl()
        dec['dormant']['CAP-TREND']['adr'] = 'docs/adr/nope.md'
        self.assertTrue(any(('CAP-TREND' in p for p in cg.verify_declarations(ROOT, dec))))

    def test_conversation_record_read_write_split(self):
        cr = self._decl()['conversation_record']
        self.assertIn('role_command_router', cr['write']['provider'])
        self.assertIn('dialogue_loop', cr['read_verify']['provider'])
        self.assertEqual(cr['read_verify']['production_callers'], 0)
        self.assertTrue(any(('全文保存' in g for g in cr['gaps'])))
if __name__ == '__main__':
    unittest.main()
