import json
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

from packet_layer import build_result_packet
from repository_result_writer import persist


def sample_packet():
    task = {
        "packet_id": "pkt-test",
        "workflow_id": "WF:test",
        "segment_id": "SEG:test",
        "attempt_id": "att-test-1",
        "skill_id": "skill-test",
        "skill_version": "1.0.0",
        "objective": "test",
        "input_refs": ["AUTHORITY:P1-CURRENT"],
        "requested_outputs": ["output"],
        "constraints": ["CENTRAL_ONLY"],
        "stop_condition": ["done"],
        "failure_condition": ["fail"],
        "scope": {"input_scope": "tests", "handoff_allowed": False},
        "acceptance_ref": "TEST",
        "context_budget": {"target": 100, "hard_ceiling": 200, "estimated": 80},
        "execution_record_ref": "EXECUTION:test",
        "retry_policy": {"max_attempts": 1, "retry_on": []},
        "timeout_ms": 1000,
        "dependency_refs": [],
        "object_id": "TASK_PACKET:pkt-test",
        "kind": "TASK_PACKET",
        "schema_version": "1.0",
        "content_hash": "",
    }
    from packet_layer import content_hash, validate_task_packet
    task["content_hash"] = content_hash(task)
    validate_task_packet(task)
    return build_result_packet(
        task,
        {
            "decision_code": "WORK_COMPLETE",
            "output_refs": ["ARTIFACT:test-output"],
            "unresolved": [],
            "evidence_refs": ["EVIDENCE:test"],
            "provenance_refs": ["PROVENANCE:test"],
            "observed_usage": {
                "model_calls": 0,
                "tool_calls": 1,
                "wall_time_ms": 1,
            },
            "usage_observed": True,
        },
        result_id="res-test-1",
    )


class RepositoryResultWriterTest(unittest.TestCase):
    def test_creates_canonical_result_packet(self):
        packet = sample_packet()
        with TemporaryDirectory() as tmp:
            result = persist(packet, root=Path(tmp))
            self.assertEqual(result["status"], "CREATED")
            path = Path(tmp) / result["path"]
            self.assertTrue(path.is_file())
            self.assertEqual(json.loads(path.read_text()), packet)

    def test_replay_is_idempotent(self):
        packet = sample_packet()
        with TemporaryDirectory() as tmp:
            first = persist(packet, root=Path(tmp))
            second = persist(packet, root=Path(tmp))
            self.assertEqual(first["status"], "CREATED")
            self.assertEqual(second["status"], "IDEMPOTENT_REPLAY")

    def test_same_result_id_with_different_payload_is_blocked(self):
        packet = sample_packet()
        changed = dict(packet)
        changed["unresolved"] = ["conflict"]
        from packet_layer import content_hash
        changed["content_hash"] = content_hash(changed)
        with TemporaryDirectory() as tmp:
            persist(packet, root=Path(tmp))
            with self.assertRaisesRegex(ValueError, "RESULT_ID_CONFLICT"):
                persist(changed, root=Path(tmp))


if __name__ == "__main__":
    unittest.main()
