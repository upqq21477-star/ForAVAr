"""caller_audit tests (SIMULATED_PASS: fixtures in tmp dirs; no real dependencies)."""
import contextlib, io, os, sys, tempfile, unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
import caller_audit as ca  # noqa: E402

SC, TL, TS = "P1-Central-Control/scripts", "tools", "P1-Central-Control/tests"
MOD = "def f():\n    return 1\n"


def mk(files):
    d = tempfile.TemporaryDirectory()
    for rel, txt in files.items():
        p = Path(d.name) / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(txt, encoding="utf-8")
    return d


def cls(files, spec="m:f"):
    with mk(files) as root:
        r = ca.audit(Path(root), [spec])
    return r, r["results"][0]["classification"]


def run_cli(argv):
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(io.StringIO()):
        rc = ca.main(argv)
    return rc, buf.getvalue()


class CallerAuditTest(unittest.TestCase):
    def test_a_test_only(self):
        _, c = cls({f"{SC}/m.py": MOD, f"{TS}/test_m.py": "from m import f\n"})
        self.assertEqual(c, "TEST_ONLY")

    def test_b_tool_import_is_production(self):
        r, c = cls({f"{SC}/m.py": MOD, f"{TL}/t.py": "from m import f\nf()\n"})
        self.assertEqual(c, "PRODUCTION")
        self.assertEqual(r["results"][0]["callers"][0]["kind"], "tool")

    def test_c_dynamic_import_unresolved(self):
        _, c = cls({f"{SC}/m.py": MOD, f"{TL}/t.py": "import importlib\nn = input()\nimportlib.import_module(n)\n"})
        self.assertEqual(c, "UNRESOLVED")

    def test_d_syntax_error_marks_incomplete(self):
        with mk({f"{SC}/m.py": MOD, f"{SC}/bad.py": "def (:\n"}) as root:
            r = ca.audit(Path(root), ["m:f"])
            rc, _ = run_cli(["--root", root, "--functions", "m:f"])
        self.assertEqual(r["status"], "INCOMPLETE")
        self.assertEqual(r["unparsed"], [f"{SC}/bad.py"])
        self.assertEqual(rc, 1)

    def test_e_interrupted_write_leaves_no_half_file(self):
        with tempfile.TemporaryDirectory() as d:
            out = Path(d) / "out.json"
            def boom():
                raise RuntimeError("killed mid-write")
            with self.assertRaises(RuntimeError):
                ca.write_atomic(out, '{"a": 1}', _fault=boom)
            self.assertFalse(out.exists())
            self.assertEqual(os.listdir(d), [])
            out.write_text("OLD", encoding="utf-8")
            with self.assertRaises(RuntimeError):
                ca.write_atomic(out, "NEW", _fault=boom)
            self.assertEqual(out.read_text(encoding="utf-8"), "OLD")
            self.assertEqual(os.listdir(d), ["out.json"])

    def test_f_import_forms(self):
        for body in ("import m as mm\nmm.f()\n", "from pkg.m import f as g\ng()\n", "import m\nm.f()\n"):
            _, c = cls({f"{SC}/m.py": MOD, f"{TL}/t.py": body})
            self.assertEqual(c, "PRODUCTION", body)

    def test_g_missing_root_exit_2(self):
        rc, _ = run_cli(["--root", "/nonexistent-root-xyz", "--functions", "m:f"])
        self.assertEqual(rc, 2)

    def test_h_chained_dead(self):
        _, c = cls({f"{SC}/m.py": MOD, f"{SC}/a.py": "from m import f\n"})
        self.assertEqual(c, "CHAINED_DEAD")

    def test_i_no_caller_none_and_exit_1(self):
        with mk({f"{SC}/m.py": MOD}) as root:
            rc, out = run_cli(["--root", root, "--functions", "m:f"])
        self.assertEqual(rc, 1)
        self.assertIn('"classification": "NONE"', out)

    def test_j_idempotent_sorted_output(self):
        files = {f"{SC}/m.py": MOD, f"{TL}/b.py": "from m import f\n", f"{TL}/a.py": "from m import f\n"}
        with mk(files) as root:
            r1, r2 = run_cli(["--root", root, "--functions", "m:f"]), run_cli(["--root", root, "--functions", "m:f"])
        self.assertEqual(r1, r2)
        self.assertEqual(r1[0], 0)
        self.assertLess(r1[1].index("tools/a.py"), r1[1].index("tools/b.py"))


if __name__ == "__main__":
    unittest.main()
