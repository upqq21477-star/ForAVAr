#!/usr/bin/env python3
from __future__ import annotations

import json
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker, ValidationError
from referencing import Registry, Resource


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
FIXTURE_PATH = ROOT / "P1-Central-Control" / "fixtures" / "p0-02-canonical-objects.json"

SCHEMAS = {
    "WORKFLOW": "workflow.schema.json",
    "SEGMENT": "segment.schema.json",
    "ATTEMPT": "attempt.schema.json",
    "TASK_PACKET": "task_packet.schema.json",
    "RESULT_PACKET": "result_packet.schema.json",
    "EVENT": "event.schema.json",
    "STATE_PROJECTION": "state_projection.schema.json",
    "ARTIFACT": "artifact.schema.json",
    "EVIDENCE": "evidence.schema.json",
    "PROVENANCE": "provenance.schema.json",
    "DISTILLATION_RECORD": "distillation_record.schema.json",
    "BRAIN_PROPOSAL": "brain_proposal.schema.json",
    "SKILL_MANIFEST": "skill_manifest.schema.json",
}

ALL_SCHEMA_FILES = (
    "canonical_identity.schema.json",
    "canonical_common.schema.json",
    *SCHEMAS.values(),
)


class P0CanonicalObjectSchemaTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.fixtures = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))

    def _registry(self) -> Registry:
        registry = Registry()
        for filename in ALL_SCHEMA_FILES:
            path = SCHEMA_DIR / filename
            schema = json.loads(path.read_text(encoding="utf-8"))
            registry = registry.with_resource(
                schema["$id"],
                Resource.from_contents(schema),
            )
        return registry

    def _validator(self, path: Path) -> Draft202012Validator:
        schema = json.loads(path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        return Draft202012Validator(
            schema,
            registry=self._registry(),
            format_checker=FormatChecker(),
        )

    def test_all_canonical_schema_files_exist(self) -> None:
        self.assertEqual(set(SCHEMAS), set(self.fixtures))
        for filename in SCHEMAS.values():
            self.assertTrue((SCHEMA_DIR / filename).is_file(), filename)

    def test_every_schema_has_stable_id_and_identity_ref(self) -> None:
        for kind, filename in SCHEMAS.items():
            schema = json.loads((SCHEMA_DIR / filename).read_text(encoding="utf-8"))
            self.assertEqual(schema["$id"], f"p1://schema/{filename[:-len('.schema.json')]}/1.0")
            self.assertIn(
                {"$ref": "p1://schema/canonical-identity/1.0"},
                schema["allOf"],
                kind,
            )
            self.assertIs(schema.get("unevaluatedProperties"), False, kind)
            self.assertTrue(schema.get("required"), kind)

    def test_all_valid_fixtures_validate(self) -> None:
        for kind, filename in SCHEMAS.items():
            validator = self._validator(SCHEMA_DIR / filename)
            validator.validate(self.fixtures[kind])

    def test_unknown_property_is_rejected_for_every_object(self) -> None:
        for kind, filename in SCHEMAS.items():
            validator = self._validator(SCHEMA_DIR / filename)
            instance = dict(self.fixtures[kind])
            instance["__unexpected_control_field__"] = True
            with self.subTest(kind=kind):
                with self.assertRaises(ValidationError):
                    validator.validate(instance)

    def test_schema_sizes_remain_bounded(self) -> None:
        for filename in SCHEMAS.values():
            size = (SCHEMA_DIR / filename).stat().st_size
            self.assertLessEqual(size, 8192, filename)


if __name__ == "__main__":
    unittest.main()
