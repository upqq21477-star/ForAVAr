"""R-1 垂直切片的回歸測試：閉環要成立、trace 要防竄改、Brain 回覆缺欄位要被擋。"""
from __future__ import annotations

import importlib.util
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SLICE = ROOT / "evidence" / "r1-vertical-slice"


def load_driver():
    spec = importlib.util.spec_from_file_location("r1_run_slice", SLICE / "run_slice.py")
    module = importlib.util.module_from_spec(spec)
    sys.modules["r1_run_slice"] = module
    spec.loader.exec_module(module)
    return module


class R1VerticalSliceTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, ignore_errors=True)
        self.driver = load_driver()
        self.driver.OUT = self.tmp / "run"

    def test_loop_closes_with_ordered_trace_and_pass_verdict(self):
        self.assertEqual(self.driver.main(), 0)
        summary = json.loads((self.driver.OUT / "run-summary.json").read_text(encoding="utf-8"))
        self.assertTrue(summary["closed_loop"])
        self.assertEqual(summary["terminal_state"], "WORKFLOW_COMPLETE")
        self.assertEqual(summary["verdict"], "PASS")
        self.assertEqual(summary["trace_events"], 9)

    def test_loop_reports_the_construction_role_gate_instead_of_hiding_it(self):
        self.driver.main()
        summary = json.loads((self.driver.OUT / "run-summary.json").read_text(encoding="utf-8"))
        # 真實 repo 狀態下角色層不准 ！施工；驅動必須如實記錄，而非假裝通過。
        self.assertIn(summary["role_admission"]["！施工"], {"BLOCK", "PASS"})
        events = self.driver.verify_chain(self.driver.OUT / "trace.jsonl")
        gate = next(e for e in events if e["event_type"] == "ROLE_ADMISSION_CHECKED")
        self.assertEqual(gate["refs"]["status"], summary["role_admission"]["！施工"])

    def test_tampered_trace_is_detected(self):
        self.driver.main()
        path = self.driver.OUT / "trace.jsonl"
        lines = path.read_text(encoding="utf-8").splitlines()
        event = json.loads(lines[2])
        event["actor"] = "TAMPERED"
        lines[2] = json.dumps(event, ensure_ascii=False, sort_keys=True)
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(AssertionError):
            self.driver.verify_chain(path)

    def test_removed_trace_event_is_detected(self):
        self.driver.main()
        path = self.driver.OUT / "trace.jsonl"
        lines = path.read_text(encoding="utf-8").splitlines()
        del lines[3]
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(AssertionError):
            self.driver.verify_chain(path)


if __name__ == "__main__":
    unittest.main()
