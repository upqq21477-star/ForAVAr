
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPT_DIR))

from self_evolution_adversarial_simulation import build_report

class SelfEvolutionAdversarialSimulationTests(unittest.TestCase):
    def test_controlled_path_preserves_safety_under_all_attacks(self):
        report = build_report(1000)
        controlled = report["controlled"]
        self.assertEqual(controlled["status"], "PASS")
        self.assertEqual(controlled["metrics"]["unsafe_promotions"], 0)
        self.assertEqual(controlled["metrics"]["invariant_violations"], 0)
        self.assertEqual(controlled["metrics"]["corrupted_recovery_uses"], 0)
        self.assertEqual(controlled["metrics"]["validator_unavailable_promotions"], 1)

    def test_naive_path_accepts_unsafe_attacks(self):
        report = build_report(1000)
        naive = report["naive"]
        self.assertEqual(naive["status"], "BLOCK")
        self.assertGreater(naive["metrics"]["unsafe_promotions"], 0)
        self.assertGreater(naive["metrics"]["invariant_violations"], 0)

    def test_constitution_tamper_is_detected_by_anchor(self):
        report = build_report(1000)
        event = next(x for x in report["controlled"]["attack_results"] if x["cycle"] == 211)
        self.assertIn("CONSTITUTION_ANCHOR_MISMATCH", event["controlled_violations"])

    def test_unavailable_validator_does_not_break_valid_quorum(self):
        report = build_report(1000)
        event = next(x for x in report["controlled"]["attack_results"] if x["cycle"] == 333)
        self.assertEqual(event["controlled_decision"], "PASS")

    def test_conflict_and_quorum_failure_fail_closed(self):
        report = build_report(1000)
        conflict = next(x for x in report["controlled"]["attack_results"] if x["cycle"] == 666)
        quorum = next(x for x in report["controlled"]["attack_results"] if x["cycle"] == 999)
        self.assertIn("VALIDATOR_RESULT_CONFLICT", conflict["controlled_violations"])
        self.assertIn("VALIDATOR_QUORUM_INSUFFICIENT", quorum["controlled_violations"])

if __name__ == "__main__":
    unittest.main()
