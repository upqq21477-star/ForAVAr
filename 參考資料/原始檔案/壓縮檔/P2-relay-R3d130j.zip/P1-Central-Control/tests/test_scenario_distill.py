import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import brain_input  # noqa: E402
import knowledge_versioning as kv  # noqa: E402
import p2_run  # noqa: E402
import scenario_distill as sd  # noqa: E402


def failed(r):
    return {n for n, ok in r["assertions"] if not ok}


def caught(fn, name):
    """A mutant is caught when the named assertion fails or the scenario itself breaks on it."""
    try:
        return name in failed(fn())
    except Exception:  # noqa: BLE001
        return True


class Scenarios(unittest.TestCase):
    def test_all_pass_and_digest_is_deterministic(self):
        for key, (_fp, fn) in sd.SCENARIOS.items():
            a, b = fn(), fn()
            self.assertTrue(a["ok"], (key, failed(a)))
            self.assertEqual(a["digest"], b["digest"], key)

    def test_replay_writes_evidence_with_rate_one(self):
        with tempfile.TemporaryDirectory() as td:
            rep = sd.replay(n=2, evid=Path(td))
            self.assertEqual(rep["equivalence_rate"], 1.0)
            self.assertTrue((Path(td) / "replay.json").exists())
            self.assertEqual(sorted(rep["per_fast_path"]), ["FP4", "FP5", "FP6", "FP7"])

    def test_mutation_trace_verifier_always_ok_is_caught_by_amnesia(self):
        with mock.patch.object(p2_run, "verify_trace", lambda t: []):
            self.assertTrue(caught(sd.fp_amnesia_resume, "tampered_snapshot_refused"))

    def test_mutation_archived_terminal_is_caught_by_knowledge(self):
        with mock.patch.dict(kv.MANUAL, {"ARCHIVED": {"ACTIVE"}}):
            self.assertTrue(caught(sd.fp_knowledge_lifecycle, "archived_is_terminal"))

    def test_mutation_brain_gets_every_claim_is_caught_by_archive(self):
        with mock.patch.object(brain_input, "semantic_refs_from", lambda r, n, limit=5: sorted(r.s.claims)[:limit]):
            self.assertTrue(caught(sd.fp_archive_isolation, "archived_claim_not_in_semantic_refs"))

    def test_mutation_admit_ignores_state_is_caught_by_promotion(self):
        def lax(store, cand, seg, quote):
            return sd._mk(store, cand.cid, seg, quote, cand.content, valid_from=sd.T3)
        with mock.patch.object(sd, "admit", lax):
            self.assertTrue(caught(sd.fp_candidate_promotion, "unverified_cannot_enter_knowledge"))

    def test_mutation_any_transition_is_caught_by_promotion(self):
        with mock.patch.dict(sd.TRANSITIONS, {"UNTRUSTED_CANDIDATE": {"VERIFIED", "EXPIRED", "ACCEPTED"}}):
            self.assertTrue(caught(sd.fp_candidate_promotion, "cannot_skip_verified"))


class RebuildCheck(unittest.TestCase):
    def test_diff_integrity_lists_only_differences(self):
        sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
        import rebuild_check as rb
        d = rb.diff_integrity({"integrity_hashes": {"A": "1", "B": "2"}}, {"integrity_hashes": {"A": "1", "B": "3", "C": "4"}})
        self.assertEqual([x["component"] for x in d], ["B", "C"])
        self.assertEqual(rb.diff_integrity({"integrity_hashes": {"A": "1"}}, {"integrity_hashes": {"A": "1"}}), [])


if __name__ == "__main__":
    unittest.main()
