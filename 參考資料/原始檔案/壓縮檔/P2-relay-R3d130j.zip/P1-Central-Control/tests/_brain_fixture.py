"""Test-only Brain START proposal (STAND-IN; not a real Brain)."""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from brain_proposal import accept_proposal, materialize_command  # noqa: E402
from packet_layer import content_hash  # noqa: E402


def brain_start_proposal(state: dict[str, Any]) -> dict[str, Any]:
    proposal = {
        "object_id": "BRAIN_PROPOSAL:e2e-start",
        "kind": "BRAIN_PROPOSAL",
        "schema_version": "1.0",
        "content_hash": "sha256:" + "b" * 64,
        "proposal_id": "e2e-start",
        "workflow_id": state["workflow_id"],
        "aggregate_type": "WORKFLOW",
        "target_id": state["workflow_id"],
        "command_type": "START",
        "expected_state_revision": state["state_revision"],
        "idempotency_key": "e2e-start:START",
        "route_mode": "DIRECT_COMMAND",
        "decision_code": "EXECUTE",
        "capability_refs": ["CAPABILITY:CAP-SEARCH"],
        "required_controls": [
            "STATE_VALIDATION",
            "IDEMPOTENCY",
            "EVENT_LOG",
            "SCHEDULER",
            "EXECUTION_TRUTH",
            "EVIDENCE_GUARD",
            "PROVENANCE_GUARD",
            "DISTILLATION",
        ],
        "evidence_refs": [],
        "contract_gap_refs": [],
        "semantic_explanation_ref": None,
    }
    proposal["content_hash"] = content_hash(proposal)
    accept_proposal(state, proposal)
    materialize_command(state, proposal, actor_id="COMMANDER")
    return proposal
