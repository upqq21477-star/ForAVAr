"""S6 batch 2: pattern_guard (CAP-PATTERN) + synthesis_guard (CAP-SYNTHESIS).  SIMULATED_PASS (death = BaseException; the model is a stub)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

R = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(R / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(R / "tools"))
import capability_run as cr  # noqa: E402
import pattern_guard as pg  # noqa: E402
import synthesis_guard as sg  # noqa: E402

OBS = [{"id": f"o{i}", "source_id": "s1", "trust": "T"} for i in range(1, 5)]
GOOD = {"type": "共同", "scope": "全體", "evidence_refs": ["o1", "o2"], "n": 2}


class Died(BaseException):
    pass


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp(prefix="s6b2-"))
        self.addCleanup(shutil.rmtree, self.d, True)
        self.calls = 0


class Pattern(Base):
    def run_(self, out=(GOOD,), obs=OBS, q="問題", **kw):
        def m(question, observations, attempt):
            self.calls += 1
            if isinstance(out, Exception):
                raise out
            return list(out) if isinstance(out, (list, tuple)) else out
        return pg.build_patterns(obs, "dh1", q, m, self.d / "p", **kw)

    def test_found_is_candidate_only(self):
        r = self.run_()
        self.assertEqual((r["status"], [p["status"] for p in r["patterns"]]), ("PATTERN_FOUND", ["CANDIDATE"]))

    def test_rejected_cases_never_released(self):
        for bad in (dict(GOOD, evidence_refs=[]), dict(GOOD, evidence_refs=["ghost"]), dict(GOOD, type="亂"), dict(GOOD, scope=""), dict(GOOD, n=99)):
            shutil.rmtree(self.d / "p", True)
            r = self.run_(out=[bad])
            self.assertEqual((r["status"], r["patterns"]), ("REJECTED", []), bad)

    def test_insufficient_data(self):
        self.assertEqual((self.run_(obs=OBS[:1])["status"], self.calls), ("NO_SUFFICIENT_DATA", 0))
        self.assertEqual(self.run_(out=[dict(GOOD, n=1)], q="另一題")["status"], "NO_SUFFICIENT_DATA")

    def test_same_hash_not_regenerated(self):
        self.run_()
        self.run_()
        self.run_(q="新問題")
        self.assertEqual(self.calls, 2)

    def test_death_in_guard_reruns_guard_only(self):
        with mock.patch.object(pg, "_check", side_effect=Died):
            with self.assertRaises(Died):
                self.run_()
        self.assertEqual((self.run_()["status"], self.calls), ("PATTERN_FOUND", 1))

    def test_format_error_retries_then_rejected(self):
        r = self.run_(out="bad")
        self.assertEqual((r["status"], self.calls, r["patterns"], (self.d / "p").exists()), ("REJECTED", 3, [], False))

    def test_model_or_guard_error_is_incomplete(self):
        self.assertEqual(self.run_(out=RuntimeError("down"))["status"], "INCOMPLETE")
        with mock.patch.object(pg, "_check", side_effect=RuntimeError):
            self.assertEqual(self.run_(q="q3")["status"], "INCOMPLETE")

    def test_bad_input_failed_writes_nothing(self):
        self.assertEqual(self.run_(obs="x")["status"], "FAILED")
        self.assertFalse((self.d / "p").exists())


V = lambda v: {"verdict": v, "key": "k"}  # noqa: E731
GAP = {"id": "g1", "task": "t", "desc": "d", "priority": "FAIL", "evidence_ref": "k"}


def inputs(c2="PASS", gaps=(), prov=True):
    return {"claims": [{"id": "c1", "verdict": V("PASS"), "evidence_refs": ["e"]}, {"id": "c2", "verdict": V(c2), "evidence_refs": ["e"]}],
            "hypotheses": [{"id": "h1", "version": 1, "state": "ACCEPTABLE"}, {"id": "h2", "version": 1, "state": "PROVISIONAL"}],
            "gaps": list(gaps), "provenance": {"ok": prov} if prov is not None else None}


def draft(**kw):
    return {"text": "結論", "claim_refs": ["c1", "c2"], "hypothesis_main": ["h1"], "hypothesis_pending": ["h2"], "status": "COMPLETE", "gaps": [], **kw}


class Synthesis(Base):
    def test_complete_and_partial(self):
        self.assertEqual(sg.check(inputs(), draft())["status"], "COMPLETE")
        r = sg.check(inputs(gaps=[GAP]), draft(status="PARTIAL", gaps=["g1"]))
        self.assertEqual(r["status"], "PARTIAL")
        self.assertEqual(sg.check(inputs("FAIL"), draft(claim_refs=["c1"], status="PARTIAL"))["status"], "PARTIAL")

    def test_rejected_cases(self):
        cases = [(inputs("FAIL"), draft()), (inputs(), draft(claim_refs=["c1", "zz"])), (inputs(), draft(claim_refs=[])),
                 (inputs(gaps=[GAP]), draft()), (inputs(gaps=[GAP]), draft(status="PARTIAL", gaps=[])), (inputs(), draft(hypothesis_main=["h1", "h2"])),
                 (inputs(prov=False), draft()), (inputs("FAIL"), draft(claim_refs=["c1"]))]
        for i, (inp, dr) in enumerate(cases):
            self.assertEqual(sg.check(inp, dr)["status"], "REJECTED", i)

    def test_unreadable_input_is_incomplete(self):
        self.assertEqual(sg.check(inputs(prov=None), draft())["status"], "INCOMPLETE")
        self.assertEqual(sg.check(dict(inputs(), claims="x"), draft())["status"], "INCOMPLETE")
        with mock.patch.object(sg, "_claim_verified", side_effect=RuntimeError):
            self.assertEqual(sg.check(inputs(), draft())["reason"], "GUARD_ERROR")

    def test_death_resume_guard_only_and_journal(self):
        with mock.patch.object(sg, "check", side_effect=Died):
            with self.assertRaises(Died):
                sg.submit(inputs(), draft(), self.d)
        self.assertEqual(sg.submit(inputs(), None, self.d)["status"], "COMPLETE")  # saved draft, guard only
        with mock.patch.object(sg, "check", side_effect=AssertionError):
            again = sg.submit(inputs(), draft(), self.d)
        self.assertEqual((again["status"], again["cached"]), ("COMPLETE", True))

    def test_only_passed_results_are_journaled_and_old_kept(self):
        self.assertEqual(sg.submit(inputs("FAIL"), draft(), self.d)["status"], "REJECTED")
        self.assertEqual(list(self.d.glob("*.done.json")), [])
        sg.submit(inputs(), draft(), self.d)
        sg.submit(inputs(gaps=[GAP]), draft(status="PARTIAL", gaps=["g1"]), self.d)  # input set changed -> new hash, old kept
        self.assertEqual(len(list(self.d.glob("*.done.json"))), 2)
        self.assertEqual(sg.submit(inputs(), None, self.d / "none")["status"], "INCOMPLETE")


class Measured(unittest.TestCase):
    def test_measured_and_mutation_caught(self):
        for cap, prov, runner, mod, name, fake in (("CAP-PATTERN", "pattern_guard", "pattern", pg, "_refs_ok", lambda refs, ids: True),
                                                   ("CAP-SYNTHESIS", "synthesis_guard", "synthesis", sg, "_claim_verified", lambda c: True)):
            self.assertEqual(cr.check(cap), {"capability": cap, "ok": True, "runner_ok": True, "providers_missing": []})
            self.assertEqual(cr.check(cap, {runner: lambda: True})["providers_missing"], [prov])
            with mock.patch.object(mod, name, fake):
                try:
                    caught = not cr.check(cap)["runner_ok"]
                except Exception:
                    caught = True
            self.assertTrue(caught, name)


if __name__ == "__main__":
    unittest.main()
