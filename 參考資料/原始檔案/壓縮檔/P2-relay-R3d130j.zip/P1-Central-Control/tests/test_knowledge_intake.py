#!/usr/bin/env python3
"""CS-1 B1：Source Manifest／KnowledgeSegment／Reading Ledger／Coverage Gate（SIMULATION_ONLY）。"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import knowledge_intake as ki  # noqa: E402

TS = "2026-10-08T00:00:00Z"
RAW = ("第一段 alpha\n第二行\n\n" + "B" * 30 + "\n\n" + "C" * 30 + "\n\n尾段\n").encode("utf-8")


def _build(raw: bytes = RAW, max_chars: int = 40):
    return ki.build_source("doc1", raw, location="mem://doc1", version="v1", max_chars=max_chars)


def _contract(segments, required=None, optional=()):
    refs = [s["object_id"] for s in segments]
    req = list(required if required is not None else refs)
    return {"required": req, "optional": list(optional), "derived": [],
            "required_basis": "TASK:t1", "declared_by": "CONTROL_RESEARCH"}


class KnowledgeIntakeTests(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "ledger.jsonl"
        self.manifest, self.segs = _build()
        self.ledger = ki.ReadingLedger(self.path, self.segs)

    def _read_all(self, refs, final="PROCESSED"):
        for ref in refs:
            self.ledger.append(ref, "READ", reader="R1", timestamp=TS)
            self.ledger.append(ref, final, reader="R1", timestamp=TS, checkpoint_ref="ARTIFACT:ck1", observation_refs=["OBSERVATION:x.O0001"])

    def test_same_input_same_hash(self) -> None:
        m2, s2 = _build()
        self.assertEqual(self.manifest, m2)
        self.assertEqual(self.segs, s2)
        self.assertGreaterEqual(len(self.segs), 3)

    def test_normalizer_makes_crlf_equal_but_hashes_differ_at_source(self) -> None:
        m2, s2 = _build(RAW.replace(b"\n", b"\r\n"))
        self.assertEqual(self.manifest["representation_hash"], m2["representation_hash"])
        self.assertNotEqual(self.manifest["source_hash"], m2["source_hash"])
        self.assertEqual([s["segment_text_hash"] for s in self.segs], [s["segment_text_hash"] for s in s2])

    def test_source_change_gives_new_hashes(self) -> None:
        m2, _ = _build(RAW + b"extra")
        self.assertNotEqual(self.manifest["source_hash"], m2["source_hash"])
        self.assertNotEqual(self.manifest["segments_digest"], m2["segments_digest"])

    def test_segments_cover_text_without_overflow(self) -> None:
        self.assertTrue(all(s["location"]["end"] - s["location"]["start"] <= 40 for s in self.segs))
        ki.verify_segments(self.manifest, self.segs)
        with self.assertRaises(ValueError):
            ki.verify_segments(self.manifest, self.segs[:-1])

    def test_missing_required_is_incomplete_and_claim_fails(self) -> None:
        refs = [s["object_id"] for s in self.segs]
        contract = _contract(self.segs)
        self._read_all(refs[:-1])
        report = ki.coverage(self.ledger, contract)
        self.assertEqual(report["status"], "INCOMPLETE")
        self.assertEqual(report["missing_required"], [refs[-1]])
        self.assertFalse(ki.full_read_claim_holds(report, self.ledger, contract))

    def test_failed_or_blocked_required_blocks(self) -> None:
        refs = [s["object_id"] for s in self.segs]
        self._read_all(refs[:-1])
        self.ledger.append(refs[-1], "BLOCKED", reader="R1", timestamp=TS)
        self.assertEqual(ki.coverage(self.ledger, _contract(self.segs))["status"], "BLOCK")

    def test_optional_unread_does_not_block(self) -> None:
        refs = [s["object_id"] for s in self.segs]
        contract = _contract(self.segs, required=refs[:-1], optional=refs[-1:])
        self._read_all(refs[:-1])
        report = ki.coverage(self.ledger, contract)
        self.assertEqual(report["status"], "COMPLETE")
        self.assertTrue(ki.full_read_claim_holds(report, self.ledger, contract))

    def test_dependency_on_failed_segment_blocks(self) -> None:
        refs = [s["object_id"] for s in self.segs]
        segs = [dict(s) for s in self.segs]
        segs[1]["depends_on"] = [refs[0]]
        ledger = ki.ReadingLedger(Path(self.tmp.name) / "dep.jsonl", segs)
        ledger.append(refs[0], "FAILED", reader="R1", timestamp=TS)
        contract = _contract(segs, required=[refs[1]], optional=[refs[0]])
        report = ki.coverage(ledger, contract)
        self.assertEqual((report["status"], report["blocked_by_dependency"]), ("BLOCK", [refs[1]]))

    def test_empty_ledger_claim_does_not_hold(self) -> None:
        contract = _contract(self.segs)
        report = ki.coverage(self.ledger, contract)
        self.assertEqual((report["status"], report["coverage_ratio"]), ("INCOMPLETE", 0.0))
        self.assertFalse(ki.full_read_claim_holds(report, self.ledger, contract))

    def test_forged_complete_report_rejected(self) -> None:
        contract = _contract(self.segs)
        report = dict(ki.coverage(self.ledger, contract))
        report["status"] = "COMPLETE"
        self.assertFalse(ki.full_read_claim_holds(report, self.ledger, contract))

    def test_contract_needs_basis_and_required(self) -> None:
        for bad in ({**_contract(self.segs), "required_basis": ""}, {**_contract(self.segs), "required": []},
                    {**_contract(self.segs), "optional": [self.segs[0]["object_id"]]}):
            with self.assertRaises(ValueError):
                ki.coverage(self.ledger, bad)

    def test_ledger_rejects_unknown_illegal_and_tampered(self) -> None:
        ref = self.segs[0]["object_id"]
        with self.assertRaises(ValueError):
            self.ledger.append("KNOWLEDGE_SEGMENT:doc1.S9999", "READ", reader="R1", timestamp=TS)
        with self.assertRaises(ValueError):
            self.ledger.append(ref, "PROCESSED", reader="R1", timestamp=TS)  # NOT_READ → PROCESSED
        self._read_all([ref])
        with self.assertRaises(ValueError):
            self.ledger.append(ref, "READ", reader="R1", timestamp=TS)  # PROCESSED 為終態
        lines = self.path.read_text(encoding="utf-8").splitlines()
        forged = json.loads(lines[0])
        forged["reader"] = "X"
        self.path.write_text(json.dumps(forged) + "\n" + "\n".join(lines[1:]) + "\n", encoding="utf-8")
        with self.assertRaises(ValueError):
            ki.ReadingLedger(self.path, self.segs)

    def test_ledger_reload_and_retry_after_failure(self) -> None:
        ref = self.segs[0]["object_id"]
        self.ledger.append(ref, "FAILED", reader="R1", timestamp=TS)
        self.ledger.append(ref, "READ", reader="R2", timestamp=TS)
        again = ki.ReadingLedger(self.path, self.segs)
        self.assertEqual((again.state(ref), again.head()), ("READ", self.ledger.head()))

    def test_processed_requires_observation_refs(self) -> None:
        ref = self.segs[0]["object_id"]
        self.ledger.append(ref, "READ", reader="R1", timestamp=TS)
        with self.assertRaises(ValueError):
            self.ledger.append(ref, "PROCESSED", reader="R1", timestamp=TS)

    def test_closed_loop_raw_to_coverage(self) -> None:
        manifest, segs = _build()
        ki.verify_segments(manifest, segs)
        ledger = ki.ReadingLedger(Path(self.tmp.name) / "loop.jsonl", segs)
        for s in segs:
            ledger.append(s["object_id"], "READ", reader="R1", timestamp=TS)
            ledger.append(s["object_id"], "PROCESSED", reader="R1", timestamp=TS, observation_refs=["OBSERVATION:x.O0001"])
        contract = _contract(segs)
        report = ki.coverage(ledger, contract)
        self.assertEqual((report["status"], report["coverage_ratio"]), ("COMPLETE", 1.0))
        self.assertTrue(ki.full_read_claim_holds(report, ledger, contract))

    def test_constitution_has_b1_invariants(self) -> None:
        path = ROOT / "P1-Central-Control" / "canonical" / "self_evolution_constitution.json"
        ids = {i["id"] for i in json.loads(path.read_text(encoding="utf-8"))["invariants"]}
        self.assertLessEqual({"THREE_TRUTHS_NOT_INFERRED", "DATA_IS_NOT_INSTRUCTION", "DURABILITY_IS_NOT_TRUTH"}, ids)


if __name__ == "__main__":
    unittest.main()
