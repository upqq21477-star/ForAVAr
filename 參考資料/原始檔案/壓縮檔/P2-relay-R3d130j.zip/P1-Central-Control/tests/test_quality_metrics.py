#!/usr/bin/env python3
"""CS-1 B8：Q1 品質指標的模擬量測（取代實測）。SIMULATION_ONLY：數值是基準與回歸門檻，不是 OBSERVED_RUNTIME。"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import archive_governance as ag  # noqa: E402
import knowledge_context as kc  # noqa: E402
import knowledge_retrieval as kr  # noqa: E402
import quality_metrics as qm  # noqa: E402
from _knowledge_fixture import J, KB, POISON, T3, TS  # noqa: E402

CT, TASK = {"stage": "B8"}, {"task_id": "T-1"}
NOW, LATER = "2026-10-08T00:00:00Z", "2027-10-08T00:00:00Z"


class QualityMetricsSimulation(unittest.TestCase):
    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = Path(tmp.name)
        self.kb = KB(self.tmp)

    def _false_promotion_flags(self) -> list[bool]:
        """故意注入四種錯誤；回傳各自是否成功進 CANONICAL。"""
        kb, s = self.kb, self.kb.store
        flags: list[bool] = []
        for fn in (  # 引文不在該 Segment／Segment 未讀
            lambda: s.add_observation("OBSERVED", "x", kb.segs[0], producer="R1", captured_at=TS, quote="不存在的引文"),
            lambda: s.add_observation("OBSERVED", "x", kb.segs[-1] if not kb.poison else "SEG:none", producer="R1", captured_at=TS, quote="x"),
        ):
            try:
                fn()
                flags.append(True)
            except ValueError:
                flags.append(False)
        o = s.add_observation("OBSERVED", "obs", kb.segs[2], producer="R1", captured_at=TS, quote="JSON")["object_id"]
        e = s.add_evidence(o, "CLAIM:bad", "SUPPORTS", producer="R1", scope="TASK:t", captured_at=TS)["object_id"]
        ref = s.propose_claim("bad", "FACT", "錯誤宣稱", [o], [e])["object_id"]
        for by, why in (("", ""), ("CONTROL_RESEARCH", "")):  # 無 adjudication
            flags.append(s.promote(ref, by=by, rationale=why).get("status") == "PROMOTED")
        flags.append(s.claims[ref]["promotion"] == "CANONICAL")
        return flags

    def test_baseline_meets_targets(self) -> None:
        kb = self.kb
        ctx = kc.assemble_context(kb.store, current_truth=CT, active_task=TASK, at=T3)
        v = kb.store.valid_at(T3)
        needed = v["valid"] + v["disputed"]
        r = kr.Retriever(kb.store)
        reached = []
        for fn in (lambda: r.text("SQLite", scope="ARCHIVE"), lambda: r.exact(source_ref="SOURCE:d", scope=("ACTIVE", "ARCHIVE"))):
            try:
                fn()
                reached.append(True)
            except ValueError as exc:
                reached.append("ARCHIVE_VIA_PROTOCOL_ONLY" not in str(exc))
        snap, fresh = kb.reload()  # Amnesia：丟棄記憶體，僅由磁碟 ledger、原文、快照恢復
        restored = kr.restore(snap, fresh.ledger, fresh.texts)
        recovered = kc.status_report(restored, kb.contract, T3) == kc.status_report(kb.store, kb.contract, T3)
        (self.tmp / "old").mkdir()
        for n in ("a", "b"):
            (self.tmp / "old" / f"{n}.md").write_text(f"舊研究{n}：" + POISON, encoding="utf-8")
        dec = ag.decide("RESEARCH", reconstruction_required=False, impact="NONE", disposition="ARCHIVE", distilled=POISON, by=J[0], rationale="研究結案")
        plans = [{"path": f"old/{n}.md", "decision": dec, "reason": "研究結案", "allowed_purposes": ["HISTORICAL_RESEARCH"], "review_after": LATER} for n in ("a", "b")]
        recs = ag.archive_assets(self.tmp, plans, self.tmp / "ar.zip", archive_ref="release:ar1", now=NOW)
        relevant = {r["object_id"] for r in recs if r["origin_path"] == "old/a.md"}
        acc = ag.ArchiveAccess(ag.ArchiveManifest(recs), ag.AccessLog(self.tmp / "acc.jsonl"))
        req = {"agent_id": "A1", "role": "ROLE:CONTROL_RESEARCH", "capability_id": ag.policy()["archive_capability"]}
        got = acc.retrieve(req, "HISTORICAL_RESEARCH", "ARCHIVE", {"origin_path": "old/a.md"}, now=NOW)
        returned = got["source_refs"]
        metrics = {
            "context_load": qm.context_load(ctx),
            "memory_contamination_rate": qm.memory_contamination_rate(ctx, needed),
            "coverage_completeness": qm.coverage_completeness(kb.ledger, kb.contract),
            "provenance_completeness": qm.provenance_completeness(kb.store),
            "conflict_preservation_rate": qm.conflict_preservation_rate(kb.store, list(kb.store.conflicts)),
            "unknown_preservation_rate": qm.unknown_preservation_rate(kb.store, [kb.unk]),
            "false_promotion_rate": qm.false_promotion_rate(self._false_promotion_flags()),
            "archive_leakage_rate": qm.archive_leakage_rate(reached),
            "archive_retrieval_precision": qm.retrieval_precision(returned, relevant),
            "recovery_success_rate": qm.recovery_success_rate([recovered]),
        }
        self.assertEqual(qm.violations(metrics), [], metrics)
        self.assertEqual(set(qm.TARGETS) - set(metrics), set())

    def test_metrics_detect_degradation(self) -> None:
        """指標必須能抓到壞情況，否則 PASS 沒有意義。"""
        kb = self.kb
        ctx = kc.assemble_context(kb.store, current_truth=CT, active_task=TASK, at=T3)
        v = kb.store.valid_at(T3)
        stale = {"claim_ref": kb.c1, "content": kb.store.claims[kb.c1]["content"]}  # 已被取代的歷史進入 Context
        bad = {**ctx, "data": {**ctx["data"], "claims": ctx["data"]["claims"] + [stale]}}
        self.assertGreater(qm.memory_contamination_rate(bad, v["valid"] + v["disputed"]), 0)
        ok = {k: (0.0 if t[0] == "MAX" else 1.0) for k, t in qm.TARGETS.items()}
        self.assertEqual(qm.violations({**ok, "memory_contamination_rate": 0.2}), ["METRIC_OUT_OF_TARGET:memory_contamination_rate=0.2"])
        (self.tmp / "p").mkdir()
        partial = KB(self.tmp / "p", process_all=False)  # 故意漏處理 → Coverage 不得 1.0
        self.assertLess(qm.coverage_completeness(partial.ledger, partial.contract), 1.0)
        self.assertEqual(qm.false_promotion_rate([False, True]), 0.5)
        self.assertEqual(qm.archive_leakage_rate([True, False]), 0.5)
        self.assertEqual(qm.violations({}), [f"METRIC_MISSING:{k}" for k in qm.TARGETS])

    def test_empty_samples_are_unmeasured_not_success(self) -> None:
        empty_store = type("EmptyStore", (), {"claims": {}, "conflicts": {}, "obs": {}})()
        metrics = {
            "provenance_completeness": qm.provenance_completeness(empty_store),
            "conflict_preservation_rate": qm.conflict_preservation_rate(self.kb.store, []),
            "unknown_preservation_rate": qm.unknown_preservation_rate(self.kb.store, []),
            "false_promotion_rate": qm.false_promotion_rate([]),
            "archive_leakage_rate": qm.archive_leakage_rate([]),
            "recovery_success_rate": qm.recovery_success_rate([]),
        }
        self.assertEqual(set(metrics.values()), {None})
        violations = qm.violations(metrics)
        for name in metrics:
            self.assertIn(f"METRIC_UNMEASURED:{name}", violations)

    def test_unmeasurable_metrics_are_declared_external(self) -> None:
        self.assertFalse(set(qm.EXTERNAL) & set(qm.TARGETS))
        self.assertEqual(len(qm.EXTERNAL), 6)


if __name__ == "__main__":
    unittest.main()
