from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from construction_session_record import append, create  # noqa: E402


def test_reuses_same_record_and_allows_one_repair():
    record = create("CS:TEST", "WORK:M33", "TASK:M33")
    record = append(
        record,
        event_type="EXECUTION_ERROR",
        summary="simulated error",
        error_id="ERR:1",
    )
    record = append(
        record,
        event_type="REPAIR_ATTEMPT",
        summary="one repair",
        error_id="ERR:1",
    )
    assert record["record_id"] == "CS:TEST"
    assert len(record["events"]) == 3


def test_second_repair_for_same_error_is_blocked():
    record = create("CS:TEST", "WORK:M33", "TASK:M33")
    record = append(record,event_type="EXECUTION_ERROR",summary="error",error_id="ERR:1")
    record = append(record,event_type="REPAIR_ATTEMPT",summary="repair",error_id="ERR:1")
    try:
        append(record,event_type="REPAIR_ATTEMPT",summary="repair again",error_id="ERR:1")
    except ValueError as exc:
        assert str(exc) == "REPAIR_ATTEMPT_LIMIT_REACHED:ERR:1"
    else:
        raise AssertionError("second repair must be blocked")


def test_report_required_uses_same_record():
    record = create("CS:TEST", "WORK:M33", "TASK:M33")
    record = append(
        record,
        event_type="REPORT_REQUIRED",
        summary="repair failed",
        error_id="ERR:1",
    )
    assert record["status"] == "REPORT_REQUIRED"
    assert record["record_id"] == "CS:TEST"


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)
