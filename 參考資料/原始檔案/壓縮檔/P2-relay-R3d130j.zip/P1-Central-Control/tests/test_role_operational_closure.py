"""M33 Phase E: operational closure simulations.

Every scenario drives the real Central interface (``central_role_interface.execute``)
or the real role gate (``role_session_gate.admission``) against a throw-away
sandbox repository; the real ``P1-CURRENT.json`` is never touched.

Plan scenario -> test
  direct Executor -> Verifier handoff attempt   test_direct_role_to_role_activation_is_blocked
  direct Verifier -> Executor activation        test_direct_role_to_role_activation_is_blocked
  unauthorized Acceptance Request creation      test_unauthorized_acceptance_request_creation_is_blocked
  next-stage admission without PASS             test_next_stage_admission_without_pass_is_blocked
  PASS with stale head_sha                      test_pass_with_stale_head_sha_opens_nothing
  transcript leakage                            test_transcript_leakage_is_blocked
  unauthorized source mutation                  test_unauthorized_write_targets_are_blocked
  Executor self-verification                    test_executor_self_verification_is_blocked
  Verifier self-repair                           test_verifier_self_repair_is_blocked
  no Current mutation bypass                    test_no_current_mutation_bypass_for_any_role_operation_status
"""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from acceptance_context import create_acceptance_context  # noqa: E402
from central_role_interface import compute_next_stage_admission, execute  # noqa: E402
from role_session_gate import admission  # noqa: E402

HEAD = "a" * 40
WORK_UNIT = "WU-SANDBOX"
ACCEPTANCE_REF = f"P1-Central-Control/acceptance/{WORK_UNIT}.acceptance.json"
PENDING = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE"

ROLES = ("ROLE:EXECUTOR", "ROLE:VERIFIER", "ROLE:CONTROL_RESEARCH")
COMMAND = {
    "ROLE:EXECUTOR": "！施工",
    "ROLE:VERIFIER": "！驗收",
    "ROLE:CONTROL_RESEARCH": "！討論",
}
STATUSES = (None, "PASS", "FAIL", "BLOCK", "INCOMPLETE", "WORK_COMPLETE", "UNRESOLVED")

EXEC_GATE = dict(command="！施工", profile_id="IP:CONSTRUCTION-EXECUTOR", mode="CONSTRUCTION")
VER_GATE = dict(command="！驗收", profile_id="IP:ACCEPTANCE-VERIFIER", mode="ACCEPTANCE")
CTRL_GATE = dict(command="！討論", profile_id="IP:CONTROL-DISCUSSION", mode="DISCUSSION")


# ---------------------------------------------------------------- sandbox

def _write(root: Path, rel: str, value: dict) -> None:
    path = root / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def sandbox(state: str) -> Path:
    """OPEN (construction running) | PENDING (close boundary, no context yet)
    | BOUND (acceptance context exists) | VERIFIED (BOUND + stage VERIFIED, next unit defined)."""
    assert state in {"OPEN", "PENDING", "BOUND", "VERIFIED"}
    root = Path(tempfile.mkdtemp(prefix=f"p1-role-closure-{state.lower()}-"))
    status = "BUILDING" if state == "OPEN" else PENDING
    work_ref = "P1-Central-Control/progress/WU-SANDBOX.work.json"
    task_ref = "P1-Central-Control/tasks/WU-SANDBOX.task.json"
    construction_ref = "P1-Central-Control/progress/construction/WU-SANDBOX.construction.json"
    _write(root, "P1-CURRENT.json", {
        "current_stage": {
            "id": WORK_UNIT,
            "work_unit_id": WORK_UNIT,
            "status": status,
            "validated_head_sha": HEAD,
        },
        "implementation_control": {"active_work_packet": work_ref},
    })
    _write(root, work_ref, {
        "work_id": "WU-SANDBOX-WORK",
        "work_unit": WORK_UNIT,
        "status": status,
        "task_packet_ref": task_ref,
        "construction_packet_ref": construction_ref,
    })
    _write(root, task_ref, {"packet_id": "pkt-sandbox", "object_id": "TASK_PACKET:pkt-sandbox"})
    _write(root, construction_ref, {"work_unit": WORK_UNIT, "status": status})

    if state in {"BOUND", "VERIFIED"}:
        # The Verifier gate validates the legacy ACCEPTANCE_CONTEXT against the schema
        # under the sandbox root (central_role_interface.py:1926); copy the real one.
        schema_rel = "P1-Central-Control/schemas/acceptance_context.schema.json"
        (root / schema_rel).parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / schema_rel, root / schema_rel)
        created = create_acceptance_context(root=root)  # Central's own path, not a role
        assert created["status"] == "CREATED" and created["acceptance_ref"] == ACCEPTANCE_REF
    if state == "VERIFIED":
        current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
        current["current_stage"]["status"] = "VERIFIED"
        current["current_stage"]["next_slice_id"] = "WU-NEXT"
        _write(root, "P1-CURRENT.json", current)
    return root


def _construction_mode(root: Path) -> None:
    """Authorize CONSTRUCTION in the sandbox Brain control (same shape as the real one)."""
    work_path = root / "P1-Central-Control/progress/WU-SANDBOX.work.json"
    work = json.loads(work_path.read_text(encoding="utf-8"))
    gates = ("objective", "scope", "change_set", "acceptance_criteria", "risk_recovery",
             "cost_authority", "stop_conditions")
    work["brain_mode_control"] = {
        "mode": "CONSTRUCTION", "plan_approved": True,
        "plan_gates": {g: True for g in gates},
        "plan_evidence": {g: f"sandbox {g}" for g in gates},
        "feature_batch_complete": False, "simulation_batch_passed": False,
        "integration_batch_passed": False, "final_batch_report_ref": None,
        "acceptance_policy": "FINAL_BATCH_ONLY", "last_transition": None,
    }
    _write(root, "P1-Central-Control/progress/WU-SANDBOX.work.json", work)


def snapshot(root: Path) -> dict[str, str]:
    return {
        path.relative_to(root).as_posix(): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in sorted(root.rglob("*"))
        if path.is_file()
    }


def current_of(root: Path) -> dict:
    return json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))


def req(operation: str, role_id: str, **kwargs) -> dict:
    base = {
        "request_id": f"SIM:{operation}",
        "operation": operation,
        "role_id": role_id,
        "activation_command": kwargs.get("activation_command"),
        "profile_id": None,
        "mode": None,
        "work_unit_ref": None,
        "summary": kwargs.get("summary"),
        "result_ref": kwargs.get("result_ref"),
        "result_status": kwargs.get("result_status"),
        "acceptance_ref": kwargs.get("acceptance_ref"),
        "head_sha": kwargs.get("head_sha"),
    }
    return base


def submit(root: Path, role_id: str, status, **kwargs) -> dict:
    return execute(
        req("SUBMIT_ROLE_RESULT", role_id, result_ref="RESULT:SIM", result_status=status, **kwargs),
        root,
    )


def gate_request(role_id: str, operation: str, *, command: str, profile_id: str, mode: str, **over) -> dict:
    value = {
        "request_id": f"SIM:{role_id}:{operation}",
        "role_id": role_id,
        "operation": operation,
        "activation_command": command,
        "profile_id": profile_id,
        "mode": mode,
        "task_packet_ref": "TASK_PACKET:pkt-sandbox" if role_id == "ROLE:EXECUTOR" else None,
        "verification_target_ref": WORK_UNIT if role_id == "ROLE:VERIFIER" else None,
        "verification_target_refs": [WORK_UNIT] if role_id == "ROLE:VERIFIER" else [],
        "construction_record_ref": None,
        "acceptance_mode": "SIMULATION_FIRST" if role_id == "ROLE:VERIFIER" else "NONE",
        "requested_write_targets": [],
        "external_research": False,
        "history_loaded": 0,
        "transient_context_loaded": False,
        "targeted_retrieval_only": role_id != "ROLE:CONTROL_RESEARCH",
    }
    value.update(over)
    return value


def reasons(result: dict) -> list[str]:
    return result.get("reason_codes", [])


# ------------------------------------------------------------- scenarios

def test_direct_role_to_role_activation_is_blocked():
    root = sandbox("PENDING")
    before = snapshot(root)
    for role_id in ROLES:
        for other, command in COMMAND.items():
            if other == role_id or (role_id == "ROLE:CONTROL_RESEARCH" and other == role_id):
                continue
            result = execute(req("ROLE_ACTIVATE", role_id, activation_command=command), root)
            assert result["status"] == "BLOCK", (role_id, command)
            assert "ROLE_COMMAND_MISMATCH" in reasons(result), (role_id, command)
            assert result.get("admitted") is False
    assert snapshot(root) == before  # nothing was written by any refused handoff


def test_unauthorized_acceptance_request_creation_is_blocked():
    # Only an Executor may claim WORK_COMPLETE, and only Central creates the context.
    for role_id in ("ROLE:VERIFIER", "ROLE:CONTROL_RESEARCH"):
        root = sandbox("PENDING")
        before = snapshot(root)
        result = submit(root, role_id, "WORK_COMPLETE")
        assert result["status"] == "BLOCK", role_id
        assert "RESULT_STATUS_NOT_ALLOWED_FOR_ROLE" in reasons(result)
        assert "acceptance_ref" not in result
        assert snapshot(root) == before, role_id

    # Executor in authorized CONSTRUCTION mode, work unit still open. The original
    # expectation (BLOCK / WORK_UNIT_CLOSE_BOUNDARY_NOT_REACHED) belonged to the retired
    # flow where WORK_COMPLETE went straight to the close-boundary check. Today it is a
    # construction-step report (PASS / LOCAL_CASE_SIMULATION_REQUIRED, only the work
    # packet is touched) and Central still creates no acceptance context. The invariant
    # this test guards -- no acceptance request without Central's close path -- is kept.
    root = sandbox("OPEN")
    _construction_mode(root)
    before = snapshot(root)
    result = submit(root, "ROLE:EXECUTOR", "WORK_COMPLETE")
    assert "acceptance_ref" not in result
    assert result.get("formal_acceptance_created") is not True
    assert not (root / ACCEPTANCE_REF).exists()
    changed = {k for k, v in snapshot(root).items() if before.get(k) != v}
    assert changed <= {"P1-Central-Control/progress/WU-SANDBOX.work.json"}, changed
    assert "acceptance_ref" not in current_of(root)["current_stage"]

    # Executor with the unit already pending acceptance: refused at entry (the legacy
    # "Central creates the context on WORK_COMPLETE" path is no longer reachable here;
    # the original PASS / CENTRAL_ACCEPTANCE_CONTEXT_READY expectation is retired --
    # see R1-S3e handoff, HYPOTHESIS: confirm that retirement is intended).
    root = sandbox("PENDING")
    _construction_mode(root)
    before = snapshot(root)
    result = submit(root, "ROLE:EXECUTOR", "WORK_COMPLETE")
    assert result["status"] == "BLOCK"
    assert "WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION" in reasons(result)
    assert "acceptance_ref" not in result
    assert snapshot(root) == before


def test_next_stage_admission_without_pass_is_blocked():
    for verdict in ("FAIL", "BLOCK", "INCOMPLETE"):
        root = sandbox("BOUND")
        before = snapshot(root)
        result = submit(root, "ROLE:VERIFIER", verdict, acceptance_ref=ACCEPTANCE_REF, head_sha=HEAD)
        assert result["status"] == "PASS" and result["accepted"] is True
        assert result["next_action"] == "RETURN_TO_CONTROL_RESEARCH", verdict
        assert "admission" not in result, verdict
        assert snapshot(root) == before, verdict

    # A PASS verdict alone does not unlock anything: the stage is not VERIFIED in Current.
    root = sandbox("BOUND")
    before = snapshot(root)
    result = submit(root, "ROLE:VERIFIER", "PASS", acceptance_ref=ACCEPTANCE_REF, head_sha=HEAD)
    assert result["admission"]["status"] == "BLOCK"
    assert result["admission"]["admitted"] is False
    assert "ACCEPTANCE_NOT_VERIFIED" in result["admission"]["reason_codes"]
    assert result["next_action"] != "CENTRAL_NEXT_STAGE_ADMITTED"
    assert snapshot(root) == before


def test_pass_with_stale_head_sha_opens_nothing():
    # Original fixture was a VERIFIED stage; the entry gate now refuses a Verifier there
    # (WORK_UNIT_NOT_READY_FOR_ACCEPTANCE) before the head check runs. Same invariant,
    # reachable fixture: a pending stage whose Current already names a next unit.
    root = sandbox("BOUND")
    current = current_of(root)
    current["current_stage"]["next_slice_id"] = "WU-NEXT"
    _write(root, "P1-CURRENT.json", current)
    before = snapshot(root)
    result = submit(root, "ROLE:VERIFIER", "PASS", acceptance_ref=ACCEPTANCE_REF, head_sha="b" * 40)
    assert result["status"] == "BLOCK"
    assert "STALE_ACCEPTANCE_HEAD_SHA" in reasons(result)
    assert "admission" not in result  # a stale PASS opens nothing, next unit or not
    assert snapshot(root) == before


def test_pass_on_verified_stage_derives_admission_without_unlock_state():
    # Admission is derived from Current alone. Through `execute` this is unreachable
    # today (a Verifier on a VERIFIED stage is refused at entry), so assert both halves:
    # the derivation itself, and the entry refusal that guards it.
    root = sandbox("VERIFIED")
    before = snapshot(root)
    admission = compute_next_stage_admission(current=current_of(root))
    assert admission["status"] == "PASS" and admission["admitted"] is True
    assert admission["admission_mode"] == "DERIVED_NO_UNLOCK_STATE"
    assert admission["next_work_unit_ref"] == "WU-NEXT"
    assert snapshot(root) == before  # derived from Current; no unlock/role/acceptance state persisted
    result = submit(root, "ROLE:VERIFIER", "PASS", acceptance_ref=ACCEPTANCE_REF, head_sha=HEAD)
    assert result["status"] == "BLOCK"
    assert "WORK_UNIT_NOT_READY_FOR_ACCEPTANCE" in reasons(result)
    assert "admission" not in result
    assert snapshot(root) == before


def test_transcript_leakage_is_blocked():
    # Executor and Verifier must be amnesiac; every leakage form is refused by the gate.
    for role_id, operation, base in (
        ("ROLE:EXECUTOR", "EXECUTE_TASK", EXEC_GATE),
        ("ROLE:VERIFIER", "VERIFY_TASK", VER_GATE),
    ):
        for over, code in (
            ({"history_loaded": 3}, "AMNESIA_HISTORY_LOADED"),
            ({"transient_context_loaded": True}, "TRANSIENT_CONTEXT_LOADED"),
            ({"targeted_retrieval_only": False}, "TARGETED_RETRIEVAL_REQUIRED"),
        ):
            result = admission(gate_request(role_id, operation, **base, **over))
            assert result["status"] == "BLOCK", (role_id, over)
            assert code in reasons(result), (role_id, over)

    # The Central interface cannot be told a session is clean: such fields are not part of
    # its request contract, so a request that smuggles them in is refused outright.
    root = sandbox("OPEN")
    smuggled = req("ROLE_ACTIVATE", "ROLE:EXECUTOR", activation_command="！施工")
    smuggled["history_loaded"] = 0
    try:
        execute(smuggled, root)
    except Exception:
        pass
    else:
        raise AssertionError("interface accepted a self-attested context field")


def test_unauthorized_write_targets_are_blocked():
    # Source mutation is never open to the Verifier; Executor stays inside its task scope;
    # Control reaches source only through the construction entrypoint.
    cases = (
        (EXEC_GATE, "ROLE:EXECUTOR", "EXECUTE_TASK", ["SOURCE"], "WRITE_TARGET_NOT_ALLOWED"),
        (EXEC_GATE, "ROLE:EXECUTOR", "EXECUTE_TASK", ["BLUEPRINT"], "WRITE_TARGET_DENIED"),
        (EXEC_GATE, "ROLE:EXECUTOR", "EXECUTE_TASK", ["TASK_CONTRACT"], "WRITE_TARGET_DENIED"),
        (VER_GATE, "ROLE:VERIFIER", "WRITE_EVIDENCE", ["SOURCE"], "WRITE_TARGET_DENIED"),
        (VER_GATE, "ROLE:VERIFIER", "WRITE_EVIDENCE", ["TASK_SCOPE"], "WRITE_TARGET_DENIED"),
        (CTRL_GATE, "ROLE:CONTROL_RESEARCH", "READ_CURRENT", ["SOURCE"], "WRITE_TARGET_NOT_ALLOWED"),
        (CTRL_GATE, "ROLE:CONTROL_RESEARCH", "READ_CURRENT", ["VERIFICATION_RESULT"], "WRITE_TARGET_DENIED"),
    )
    for base, role_id, operation, targets, code in cases:
        result = admission(gate_request(role_id, operation, requested_write_targets=targets, **base))
        assert result["status"] == "BLOCK", (role_id, targets)
        assert code in reasons(result), (role_id, targets, reasons(result))

    # No role may ever target Current or canonical state, alone or mixed with a legal target.
    for base, role_id, operation, legal in (
        (EXEC_GATE, "ROLE:EXECUTOR", "EXECUTE_TASK", "TASK_SCOPE"),
        (VER_GATE, "ROLE:VERIFIER", "WRITE_EVIDENCE", "EVIDENCE"),
        (CTRL_GATE, "ROLE:CONTROL_RESEARCH", "READ_CURRENT", "PLANNING_ARTIFACTS"),
    ):
        for forbidden in ("P1_CURRENT", "CANONICAL_STATE"):
            for targets in ([forbidden], [legal, forbidden]):
                result = admission(gate_request(role_id, operation, requested_write_targets=targets, **base))
                assert result["status"] == "BLOCK", (role_id, targets)


def test_executor_self_verification_is_blocked():
    # Operation level (gate)
    for operation in ("VERIFY_TASK", "ACCEPT_RESULT", "RUN_ACCEPTANCE"):
        result = admission(gate_request("ROLE:EXECUTOR", operation, **EXEC_GATE))
        assert result["status"] == "BLOCK", operation
    # Result level (Central): a verdict from the Executor is refused and changes nothing.
    for verdict in ("PASS", "FAIL"):
        root = sandbox("BOUND")
        before = snapshot(root)
        result = submit(root, "ROLE:EXECUTOR", verdict, acceptance_ref=ACCEPTANCE_REF, head_sha=HEAD)
        assert result["status"] == "BLOCK", verdict
        assert "RESULT_STATUS_NOT_ALLOWED_FOR_ROLE" in reasons(result)
        assert "admission" not in result
        assert snapshot(root) == before


def test_verifier_self_repair_is_blocked():
    for operation in ("EXECUTE_TASK", "REPAIR_IN_SCOPE", "MODIFY_SOURCE", "MODIFY_PLAN", "REPLAN"):
        result = admission(gate_request("ROLE:VERIFIER", operation, **VER_GATE))
        assert result["status"] == "BLOCK", operation
    # A Verifier cannot report "I fixed it and it is complete".
    root = sandbox("BOUND")
    before = snapshot(root)
    result = submit(root, "ROLE:VERIFIER", "WORK_COMPLETE", acceptance_ref=ACCEPTANCE_REF, head_sha=HEAD)
    assert result["status"] == "BLOCK"
    assert "RESULT_STATUS_NOT_ALLOWED_FOR_ROLE" in reasons(result)
    assert snapshot(root) == before


def test_control_cannot_emit_a_verdict():
    for verdict in ("PASS", "FAIL", "WORK_COMPLETE"):
        root = sandbox("VERIFIED")
        before = snapshot(root)
        result = submit(root, "ROLE:CONTROL_RESEARCH", verdict)
        assert result["status"] == "BLOCK", verdict
        assert "RESULT_STATUS_NOT_ALLOWED_FOR_ROLE" in reasons(result)
        assert snapshot(root) == before


def test_no_current_mutation_bypass_for_any_role_operation_status():
    """Sweep every role x operation x status over every lifecycle state.

    The only legitimate write is Central creating the acceptance context when an
    Executor reports WORK_COMPLETE at the close boundary; it may only add the
    acceptance pointer to Current. Everything else must leave the tree byte-identical,
    and no result may name another role (Role -> Role is not expressible).
    """
    other_markers = {
        role_id: [role_id, COMMAND[role_id]] for role_id in ROLES
    }
    legit = ("PENDING", "ROLE:EXECUTOR", "SUBMIT_ROLE_RESULT", "WORK_COMPLETE")
    audited = ("OPEN", "ROLE:EXECUTOR", "SUBMIT_ROLE_RESULT", "WORK_COMPLETE")
    WORK_REF = "P1-Central-Control/progress/WU-SANDBOX.work.json"
    cases = 0
    for state in ("OPEN", "PENDING", "BOUND", "VERIFIED"):
        for role_id in ROLES:
            requests = [
                ("ROLE_ACTIVATE", req("ROLE_ACTIVATE", role_id, activation_command=COMMAND[role_id]), None),
                ("GET_ROLE_CONTEXT", req("GET_ROLE_CONTEXT", role_id), None),
                ("REPORT_PROGRESS", req("REPORT_PROGRESS", role_id, summary="sim"), None),
            ]
            for status in STATUSES:
                for head in (HEAD, "c" * 40):
                    requests.append((
                        "SUBMIT_ROLE_RESULT",
                        req("SUBMIT_ROLE_RESULT", role_id, result_ref="RESULT:SIM",
                            result_status=status, acceptance_ref=ACCEPTANCE_REF, head_sha=head),
                        status,
                    ))
            for operation, request, status in requests:
                root = sandbox(state)
                before = snapshot(root)
                before_current = current_of(root)
                before_work = (root / WORK_REF).read_text(encoding="utf-8")
                try:
                    result = execute(request, root)
                except Exception:
                    result = None  # raising is also fail-closed
                after = snapshot(root)
                cases += 1
                if (state, role_id, operation, status) == legit and result and result["status"] == "PASS":
                    changed = {k for k in after if before.get(k) != after[k]}
                    assert changed == {"P1-CURRENT.json", ACCEPTANCE_REF}, changed
                    now = current_of(root)
                    stage_before = dict(before_current["current_stage"])
                    stage_now = dict(now["current_stage"])
                    assert stage_now.pop("acceptance_ref") == ACCEPTANCE_REF
                    stage_now.pop("acceptance_mode")
                    assert stage_now == stage_before
                    assert {k: v for k, v in now.items() if k != "current_stage"} == {
                        k: v for k, v in before_current.items() if k != "current_stage"
                    }
                elif (state, role_id, operation, status) == audited:
                    # A refused construction step is audited: Central initialises the work
                    # packet's brain_mode_control and stamps last_transition (event, reason
                    # code, timestamp). The original "byte-identical" expectation predates
                    # that audit write. Kept strict for everything that matters: Current and
                    # every other file stay byte-identical, no acceptance context appears,
                    # and the work packet differs only in brain_mode_control.
                    # HYPOTHESIS: if a BLOCK must never write, this is a program defect.
                    changed = {k for k in set(after) | set(before) if before.get(k) != after.get(k)}
                    assert changed <= {WORK_REF}, (state, role_id, operation, status, changed)
                    assert current_of(root) == before_current
                    assert not (root / ACCEPTANCE_REF).exists()
                    if changed:
                        old_work = json.loads(before_work)
                        new_work = json.loads((root / WORK_REF).read_text(encoding="utf-8"))
                        assert {k: v for k, v in new_work.items() if k != "brain_mode_control"} == {
                            k: v for k, v in old_work.items() if k != "brain_mode_control"
                        }
                else:
                    assert after == before, (state, role_id, operation, status)
                if result is not None:
                    text = json.dumps(result, ensure_ascii=False)
                    for other, markers in other_markers.items():
                        if other == role_id:
                            continue
                        for marker in markers:
                            assert marker not in text, (state, role_id, operation, status, marker)
    assert cases == 4 * len(ROLES) * (3 + 2 * len(STATUSES))  # the sweep really ran


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)
