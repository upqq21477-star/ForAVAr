#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
INTEGRATION = ROOT / "P1-Central-Control/integrations/25d"
sys.path.insert(0, str(INTEGRATION))

from adapter import (  # noqa: E402
    build_task_packet,
    invoke_25d,
    load_projection,
    normalize_25d_result,
    normalize_objective,
    to_25d_transport_task,
    validate_projection,
)
from external_skill_adapter import validate_manifest  # noqa: E402


class P25DIntegrationTests(unittest.TestCase):
    def projection(self) -> dict:
        return {
            "system_id": "25D",
            "projection_version": "1.0",
            "controller_version": "0.1.0",
            "projection_scope": "DOMAIN",
            "p1_bridge": {
                "skill_id": "25D.DOMAIN_CONTROLLER",
                "skill_version": "1.0",
            },
            "capabilities": [{"id": "P1_TASK_BRIDGE"}],
            "domain_boundary": {"owns": [], "does_not_own": []},
        }

    def manifest(self) -> dict:
        return load_projection(INTEGRATION / "skill_manifest.json")

    def response(self) -> dict:
        return load_projection(INTEGRATION / "25d-result.fixture.json")

    def test_committed_projection_is_valid(self) -> None:
        projection = load_projection(INTEGRATION / "25d-current.fixture.json")
        self.assertEqual(validate_projection(projection), [])

    def test_manifest_is_canonical_and_strict(self) -> None:
        validate_manifest(self.manifest())

    def test_only_supported_25d_operations_are_buildable(self) -> None:
        self.assertEqual(normalize_objective("REPORT_STATE"), "REPORT_STATE")
        self.assertEqual(normalize_objective("25d get capabilities"), "GET_CAPABILITIES")
        with self.assertRaises(ValueError):
            normalize_objective("DELETE_PROJECT")

    def test_builds_canonical_task_packet(self) -> None:
        packet = build_task_packet(
            objective="REPORT_STATE",
        )
        self.assertEqual(packet["kind"], "TASK_PACKET")
        self.assertEqual(packet["skill_id"], "25D.DOMAIN_CONTROLLER")
        self.assertNotEqual(packet["content_hash"], "sha256:" + "0" * 64)

    def test_transport_view_matches_25d_contract_shape(self) -> None:
        packet = build_task_packet(objective="REPORT_STATE")
        self.assertEqual(packet["packet_id"], "pkt-25d-domain-control-1")
        transport = to_25d_transport_task(packet)
        self.assertEqual(transport["input_refs"], [])
        self.assertEqual(
            transport["execution_record_ref"],
            {"ref": packet["execution_record_ref"]},
        )
        self.assertEqual(transport["dependency_refs"], [])

    def test_normalizes_25d_refs_and_returns_p1_result(self) -> None:
        packet = build_task_packet(objective="REPORT_STATE")
        self.assertEqual(packet["packet_id"], "pkt-25d-domain-control-1")
        result, invocation = invoke_25d(
            packet,
            self.manifest(),
            self.response(),
        )
        self.assertEqual(result["kind"], "RESULT_PACKET")
        self.assertEqual(result["decision_code"], "WORK_COMPLETE")
        self.assertEqual(
            result["output_refs"],
            ["ARTIFACT:25d.state-001"],
        )
        self.assertEqual(invocation["status"], "RETURNED")

    def test_result_correlation_mismatch_is_rejected(self) -> None:
        packet = build_task_packet(objective="REPORT_STATE")
        response = self.response()
        response["attempt_id"] = "other-attempt"
        with self.assertRaises(ValueError):
            invoke_25d(packet, self.manifest(), response)

    def test_invalid_projection_is_rejected(self) -> None:
        errors = validate_projection({
            "system_id": "OTHER",
            "projection_version": "9.0",
            "projection_scope": "GLOBAL",
            "p1_bridge": {},
            "capabilities": [],
            "domain_boundary": {},
        })
        self.assertIn("invalid:system_id", errors)
        self.assertIn("invalid:projection_version", errors)

    def test_unknown_result_field_is_rejected(self) -> None:
        response = self.response()
        response["state"] = {"status": "COMPLETED"}
        with self.assertRaises(ValueError):
            normalize_25d_result(response)


if __name__ == "__main__":
    unittest.main()
