#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SCRIPTS=ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0,str(SCRIPTS))

import evolution_cycle as m6  # noqa: E402


class EvolutionCycleTests(unittest.TestCase):
    def impact(self, status="PASS"):
        value={
            "scan_id":"IMPACT:M6-TEST",
            "change_id":"CHANGE:M6-TEST",
            "status":status,
            "decision":"PROCEED" if status=="PASS" else "BLOCK",
            "unknown_paths":[] if status=="PASS" else ["unknown"],
            "affected_capabilities":["CAP-EXTRACT","CAP-CLASSIFY"],
            "required_regression_sets":["routing","e2e"],
            "path_results":[{
                "path":"P1-Central-Control/scripts/test.py",
                "matched_rule_ids":["CONTROL_SCRIPTS"],
                "change_type":"RUNTIME",
                "known":True
            }],
            "rule_registry":"M1_IMPACT_MAP_V1",
            "reason_codes":["IMPACT_RESOLVED"] if status=="PASS" else ["IMPACT_UNRESOLVED_PATH"]
        }
        return value

    def registry(self):
        return {
            "version":"1.2",
            "capabilities":[
                {"capability_id":"CAP-EXTRACT","kind":"MODEL_NATIVE","retirement_state":"ACTIVE"},
                {"capability_id":"CAP-CLASSIFY","kind":"MODEL_NATIVE","retirement_state":"ACTIVE"}
            ]
        }

    def measurements(self):
        return {
            "CAP-EXTRACT":{
                "evaluation_id":"EVAL-M6-001","capability_id":"CAP-EXTRACT",
                "baseline_mode":"MODEL_PLUS_GUARD","candidate_mode":"MODEL_ONLY",
                "candidate_model_ref":"TEST","sample_size":100,
                "schema_compatibility":{"checked":True,"passed":True},
                "behavior_compatibility":{"passed":98,"total":100,"rate":0},
                "acceptance":{"passed":100,"total":100,"rate":0},
                "reliability":{"successes":99,"total":100,"rate":0},
                "cost":{"baseline_unit_cost":1.0,"candidate_unit_cost":0.8,"ratio":0},
                "regression_count":0,"evidence_refs":["EVIDENCE:M6"]
            },
            "CAP-CLASSIFY":{
                "evaluation_id":"EVAL-M6-002","capability_id":"CAP-CLASSIFY",
                "baseline_mode":"MODEL_PLUS_GUARD","candidate_mode":"MODEL_ONLY",
                "candidate_model_ref":"TEST","sample_size":100,
                "schema_compatibility":{"checked":True,"passed":True},
                "behavior_compatibility":{"passed":98,"total":100,"rate":0},
                "acceptance":{"passed":100,"total":100,"rate":0},
                "reliability":{"successes":99,"total":100,"rate":0},
                "cost":{"baseline_unit_cost":1.0,"candidate_unit_cost":0.8,"ratio":0},
                "regression_count":0,"evidence_refs":["EVIDENCE:M6"]
            }
        }

    def test_without_actual_regression_result_stops_at_defer(self):
        result=m6.cycle(self.impact(),measurements=self.measurements(),capability_registry=self.registry(),cycle_id="M6-001")
        self.assertEqual(result["status"],"INSUFFICIENT_DATA")
        self.assertEqual(result["stages"][-1]["stage_id"],"ADOPTION_ROLLBACK")
        self.assertEqual(result["stages"][-1]["status"],"INSUFFICIENT_DATA")

    def test_impact_block_stops_cycle(self):
        result=m6.cycle(self.impact("BLOCK"),measurements=self.measurements(),capability_registry=self.registry(),cycle_id="M6-002")
        self.assertEqual(result["status"],"BLOCK")
        self.assertEqual(result["stages"][0]["status"],"BLOCK")

    def route_state(self):
        return {
            "route_state_id": "ROUTE-STATE-M6-TEST",
            "routes": [
                {
                    "capability_id": "CAP-EXTRACT",
                    "current_mode": "MODEL_PLUS_GUARD",
                    "rollback_mode": "MODEL_PLUS_GUARD",
                },
                {
                    "capability_id": "CAP-CLASSIFY",
                    "current_mode": "MODEL_PLUS_GUARD",
                    "rollback_mode": "MODEL_PLUS_GUARD",
                },
            ],
        }

    def test_can_execute_selected_regressions_before_adoption(self):
        def fake_execute(selection):
            return {
                "result_id": "M7-" + selection["selection_id"],
                "selection_id": selection["selection_id"],
                "status": "PASS",
                "results": [
                    {"regression_set_id": set_id, "status": "PASS"}
                    for set_id in selection["selected_regression_sets"]
                ],
            }

        with patch.object(m6.evolution_cycle_execution.regression_executor, "execute_selection", side_effect=fake_execute) as execute:
            result = m6.cycle(
                self.impact(),
                measurements=self.measurements(),
                capability_registry=self.registry(),
                route_state=self.route_state(),
                execute_regressions=True,
                cycle_id="M6-004",
            )

        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["stages"][-1]["stage_id"], "ADOPTION_ROLLBACK")
        execution_stage = [stage for stage in result["stages"] if stage["stage_id"] == "REGRESSION_EXECUTION"][0]
        self.assertEqual(execution_stage["status"], "PASS")
        self.assertTrue(execution_stage["object_ref"].startswith("REGRESSION_EXECUTION_RESULT:"))
        self.assertEqual(result["stages"][-1]["status"], "PASS")
        execute.assert_called_once()

    def test_failed_regression_is_recorded_and_passes_to_rollback(self):
        def fake_execute(selection):
            return {
                "result_id": "M7-" + selection["selection_id"],
                "selection_id": selection["selection_id"],
                "status": "FAIL",
                "results": [
                    {"regression_set_id": set_id, "status": "FAIL"}
                    for set_id in selection["selected_regression_sets"]
                ],
            }

        with patch.object(m6.evolution_cycle_execution.regression_executor, "execute_selection", side_effect=fake_execute):
            result = m6.cycle(
                self.impact(),
                measurements=self.measurements(),
                capability_registry=self.registry(),
                route_state=self.route_state(),
                execute_regressions=True,
                cycle_id="M6-005",
            )

        execution_stage = [stage for stage in result["stages"] if stage["stage_id"] == "REGRESSION_EXECUTION"][0]
        self.assertEqual(execution_stage["status"], "FAIL")
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["stages"][-1]["stage_id"], "ADOPTION_ROLLBACK")
        self.assertEqual(result["stages"][-1]["status"], "PASS")

    def test_m5_requires_explicit_inputs(self):
        with self.assertRaises(ValueError):
            m6.cycle(
                self.impact(),
                measurements=self.measurements(),
                capability_registry=self.registry(),
                regression_result={"bad":1},
                route_state={"bad":1},
                cycle_id="M6-003",
            )

if __name__=="__main__":
    unittest.main()
