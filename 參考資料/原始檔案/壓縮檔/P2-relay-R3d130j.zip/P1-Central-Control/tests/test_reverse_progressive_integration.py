import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from progressive_repository_scanner import execute as scan


class ReverseProgressiveIntegrationTests(unittest.TestCase):
    def _request(self, root):
        return {
            "schema_version": "1.0",
            "request_id": "SCAN:CHAIN-001",
            "root_path": str(root),
            "focus_paths": ["app.py"],
            "max_inventory_files": 20,
            "max_inventory_bytes": 20000,
            "max_deep_read_files": 4,
            "max_deep_read_bytes": 4000,
            "target_context_budget": 3000,
            "hard_context_ceiling": 6000,
        }

    def test_progressive_chain_emits_projection_state_and_lifecycle(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text(
                "def main():\n    return 7\n",
                encoding="utf-8",
            )
            result = scan(self._request(root))
        self.assertEqual(result["status"], "PASS")
        self.assertIn("reverse_reconstruction", result)
        self.assertIn("partial_system_state", result)
        self.assertEqual(result["artifact_lifecycle"]["status"], "USED")
        self.assertEqual(
            [item["level"] for item in result["levels"]],
            ["L0", "L1", "L2", "L3", "L4", "L5", "L6"],
        )

    def test_explicit_runtime_and_oracle_can_verify_reconstruction_artifact(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text(
                "print('ok')\n",
                encoding="utf-8",
            )
            request = self._request(root)
            request["runtime_probes"] = [{
                "probe_id": "PROBE:CHAIN",
                "command": [sys.executable, "app.py"],
                "expected_exit_code": 0,
            }]
            request["oracle"] = {
                "oracle_id": "ORACLE:CHAIN",
                "minimum_classes": ["POSITIVE"],
                "scenarios": [{
                    "scenario_id": "POS",
                    "class": "POSITIVE",
                    "command": [sys.executable, "app.py"],
                    "expected_exit_code": 0,
                }],
            }
            result = scan(request)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["artifact_lifecycle"]["status"], "VERIFIED")
        self.assertEqual(result["levels"][5]["status"], "VERIFIED")
        self.assertEqual(result["levels"][6]["status"], "PASS")


if __name__ == "__main__":
    unittest.main()
