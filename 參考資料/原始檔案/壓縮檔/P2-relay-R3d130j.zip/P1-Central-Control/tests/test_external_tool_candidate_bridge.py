#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[2]
SCRIPTS=ROOT/"P1-Central-Control/scripts"
sys.path.insert(0,str(SCRIPTS))

import external_tool_candidate_bridge as bridge


class ExternalToolCandidateBridgeTests(unittest.TestCase):
    def review_fixture(self):
        return {
            "schema_version":"1.0",
            "run_id":"REVIEW-20261004",
            "observed_date":"2026-10-04",
            "source":"GITHUB_REPOSITORY_METADATA",
            "input_run_id":"RADAR-20261004",
            "summary":{
                "input_count":1,
                "reviewed_count":1,
                "review_ready_count":1,
                "blocked_count":0
            },
            "candidates":[{
                "repository":"example/tool",
                "url":"https://github.com/example/tool",
                "radar_classification":"ADOPT_CANDIDATE",
                "stars":2000,
                "forks":100,
                "archived":False,
                "default_branch":"main",
                "license_spdx_id":"MIT",
                "latest_release_tag":"v1.2.0",
                "latest_release_created_at":"2026-10-01T00:00:00Z",
                "latest_release_published_at":"2026-10-01T00:00:00Z",
                "review_status":"REVIEW_READY",
                "review_reasons":[],
                "matched_scopes":[{
                    "scope_type":"CORE_CAPABILITY",
                    "scope_id":"CORE-08",
                    "scope_name":"Architecture Fitness",
                    "query":"architecture fitness"
                }]
            }]
        }

    def test_bridge_emits_fit_and_research_sources(self):
        review=self.review_fixture()
        radar_candidate={
            "repository":"example/tool",
            "name":"tool",
            "url":"https://github.com/example/tool",
            "description":"x",
            "stars":2000,
            "forks":100,
            "created_at":"2026-01-01T00:00:00Z",
            "pushed_at":"2026-10-01T00:00:00Z",
            "updated_at":"2026-10-01T00:00:00Z",
            "archived":False,
            "topics":[],
            "popularity_score":80,
            "freshness_days":3,
            "is_new_tool":True,
            "classification":"ADOPT_CANDIDATE",
            "matched_scopes":[{
                "scope_type":"CORE_CAPABILITY",
                "scope_id":"CORE-08",
                "scope_name":"Architecture Fitness",
                "query":"architecture fitness"
            }]
        }
        with patch.object(bridge, "fit_request", side_effect=lambda c: {
            "schema_version":"1.0",
            "request_id":"FIT:EXT-example-tool",
            "goal":"test",
            "required_capabilities":["CORE-08"],
            "system_state":{
                "classification":"UNKNOWN",
                "system_id":None,
                "boundary_conflict":False,
                "split_required":False,
                "supports_extension":False,
                "owned_capabilities":[]
            },
            "merge_candidate_system_ids":[],
            "allow_new_system":False
        }):
            review["candidates"][0]["latest_release_tag"]="v1.2.0"
            with patch.object(bridge, "execute_fit", return_value={
                "schema_version":"1.0",
                "request_id":"FIT:EXT-example-tool",
                "status":"PASS",
                "decision":"DEFER",
                "reason_codes":["SYSTEM_STATE_NOT_SUFFICIENT"],
                "target_system_id":None,
                "missing_capabilities":[],
                "evidence":{
                    "observed":["system.classification=UNKNOWN"],
                    "confirmed":[],
                    "inferred":[],
                    "unknown":["architecture_fit_requires_more_reconstruction_evidence"],
                    "conflict":[]
                }
            }):
                result=bridge.bridge(review,"2026-10-04T01:00:00+00:00")

        self.assertEqual(result["status"],"PASS")
        self.assertEqual(result["summary"]["bridged_count"],1)
        self.assertEqual(result["summary"]["research_source_count"],2)
        self.assertEqual(result["candidates"][0]["native_replacement_gate"]["status"],"DEFERRED")

    def test_blocked_metadata_still_transfers_as_evidence_boundary(self):
        review=self.review_fixture()
        review["candidates"][0]["review_status"]="BLOCKED"
        result=bridge.bridge(review,"2026-10-04T01:00:00+00:00")
        self.assertEqual(result["status"],"PASS")
        self.assertEqual(result["summary"]["bridged_count"],1)
        self.assertEqual(result["candidates"][0]["review_status"],"BLOCKED")


if __name__=="__main__":
    unittest.main()
