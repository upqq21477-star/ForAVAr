import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from context_sufficiency import execute


class ContextSufficiencyTests(unittest.TestCase):
    def test_sufficient(self):
        r = execute(
            gate_id="CTXGATE:1",
            required_refs=["A", "B"],
            available_refs=["A", "B", "C"],
            estimated_total_context=50,
            target_context_budget=100,
            hard_context_ceiling=120
        )
        self.assertEqual(r["status"], "SUFFICIENT")
        self.assertEqual(r["action"], "EXECUTE")

    def test_missing_requires_targeted_retrieval(self):
        r = execute(
            gate_id="CTXGATE:2",
            required_refs=["A", "B"],
            available_refs=["A"],
            estimated_total_context=50,
            target_context_budget=100,
            hard_context_ceiling=120
        )
        self.assertEqual(r["status"], "INSUFFICIENT")
        self.assertEqual(r["action"], "TARGETED_RETRIEVAL")
        self.assertEqual(r["missing_refs"], ["B"])

    def test_oversized_splits(self):
        r = execute(
            gate_id="CTXGATE:3",
            required_refs=["A"],
            available_refs=["A"],
            estimated_total_context=150,
            target_context_budget=100,
            hard_context_ceiling=120
        )
        self.assertEqual(r["status"], "OVERSIZED")
        self.assertEqual(r["action"], "TRIM_OR_SPLIT")

    def test_conflict_blocks(self):
        r = execute(
            gate_id="CTXGATE:4",
            required_refs=["A"],
            available_refs=["A"],
            stale_refs=["A"],
            estimated_total_context=50,
            target_context_budget=100,
            hard_context_ceiling=120
        )
        self.assertEqual(r["status"], "CORRUPTED")
        self.assertEqual(r["action"], "RECONCILE_OR_BLOCK")


if __name__ == "__main__":
    unittest.main()
