#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import actions_regression_replay as replay  # noqa: E402
import github_actions_result_adapter as adapter  # noqa: E402


class ActionsRegressionReplayTests(unittest.TestCase):
    SELECTION = ROOT / "P1-Central-Control/fixtures/m9-regression-selection-ci.json"
    OBSERVATION = ROOT / "P1-Central-Control/fixtures/m9-github-actions-observation-37167693193.json"

    def test_real_runner_failure_observation_reaches_m7_incomplete(self):
        selection = replay.load_json(self.SELECTION)
        observation = replay.load_json(self.OBSERVATION)
        registry_doc = replay.load_json(replay.REGISTRY)
        registry = {
            item["regression_set_id"]: item
            for item in registry_doc["sets"]
            if item.get("regression_set_id")
        }

        external = adapter.build_external_result(
            selection,
            observation,
            registry,
            expected_head_sha=observation["workflow_run"]["head_sha"],
        )

        self.assertEqual(external["status"], "INCOMPLETE")
        self.assertEqual(external["results"], [])

    def test_main_delegates_to_local_acceptance(self):
        with tempfile.TemporaryDirectory() as temp:
            output = Path(temp) / "report.json"
            acceptance = Path(temp) / "acceptance.json"

            fake = type("Completed", (), {"returncode": 2})()
            with patch.object(replay.subprocess, "run", return_value=fake) as run:
                rc = replay.main_from_args if hasattr(replay, "main_from_args") else None

                if rc is not None:
                    self.fail("unexpected helper")

                with patch.object(
                    sys,
                    "argv",
                    [
                        "actions_regression_replay.py",
                        str(self.SELECTION),
                        str(self.OBSERVATION),
                        "--output",
                        str(output),
                        "--acceptance-output",
                        str(acceptance),
                    ],
                ):
                    result = replay.main()

            self.assertEqual(result, 2)
            command = run.call_args.args[0]
            self.assertIn("P1-Central-Control/scripts/local_acceptance.py", command)
            self.assertIn("--external-result", command)
            self.assertNotIn("--head", command)


if __name__ == "__main__":
    unittest.main()
