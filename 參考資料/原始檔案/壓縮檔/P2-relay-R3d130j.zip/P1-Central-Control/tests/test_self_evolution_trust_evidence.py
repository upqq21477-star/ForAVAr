import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPT_DIR))

from self_evolution_boundary_guard import canonical_sha256
from self_evolution_trust_evidence import (
    build_attestation,
    build_rollback_evidence,
    canonical_sha256 as evidence_sha256,
    evaluate_validator_quorum,
    validate_rollback_evidence,
)

CONSTITUTION = {
    "constitution_id": "P1.SELF_EVOLUTION_CONSTITUTION",
    "version": "1.0",
    "invariants": [{"id": "ONE_CANONICAL_AUTHORITY", "rule": "exactly one"}],
}
CONSTITUTION_DIGEST = canonical_sha256(CONSTITUTION)
CANDIDATE_DIGEST = evidence_sha256({"candidate_id": "CANDIDATE-1"})

VALIDATOR_REGISTRY = {
    "registry_id": "P1.VALIDATORS",
    "version": "1.0",
    "validators": {
        "VAL-A": {"trust_domain": "DOMAIN-A", "active": True, "min_epoch": 1},
        "VAL-B": {"trust_domain": "DOMAIN-B", "active": True, "min_epoch": 1},
        "VAL-C": {"trust_domain": "DOMAIN-C", "active": True, "min_epoch": 1},
    },
}

ROLLBACK_DIGEST = evidence_sha256({"snapshot": "LAST-KNOWN-GOOD"})
ROLLBACK_REGISTRY = {
    "registry_id": "P1.ROLLBACK",
    "version": "1.0",
    "snapshots": {"SNAP-1": {"snapshot_digest": ROLLBACK_DIGEST, "legal": True}},
}


def attest(validator_id, domain, decision="PASS", epoch=1):
    return build_attestation(
        validator_id=validator_id,
        trust_domain=domain,
        candidate_digest=CANDIDATE_DIGEST,
        constitution_digest=CONSTITUTION_DIGEST,
        decision=decision,
        epoch=epoch,
        attestation_id=f"ATTEST-{validator_id}-{epoch}",
    )


class SelfEvolutionTrustEvidenceTests(unittest.TestCase):
    def test_two_independent_domains_promote(self):
        result = evaluate_validator_quorum(
            [attest("VAL-A", "DOMAIN-A"), attest("VAL-B", "DOMAIN-B")],
            validator_registry=VALIDATOR_REGISTRY,
            candidate_digest=CANDIDATE_DIGEST,
            constitution_digest=CONSTITUTION_DIGEST,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["decision"], "PROMOTE")

    def test_same_domain_does_not_count_as_independent_quorum(self):
        registry = dict(VALIDATOR_REGISTRY)
        registry["validators"] = {
            **VALIDATOR_REGISTRY["validators"],
            "VAL-C": {"trust_domain": "DOMAIN-A", "active": True, "min_epoch": 1},
        }
        result = evaluate_validator_quorum(
            [attest("VAL-A", "DOMAIN-A"), attest("VAL-C", "DOMAIN-A")],
            validator_registry=registry,
            candidate_digest=CANDIDATE_DIGEST,
            constitution_digest=CONSTITUTION_DIGEST,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("TRUST_DOMAIN_QUORUM_INSUFFICIENT", result["violations"])

    def test_conflict_is_safe_hold_not_majority_vote(self):
        result = evaluate_validator_quorum(
            [
                attest("VAL-A", "DOMAIN-A", "PASS"),
                attest("VAL-B", "DOMAIN-B", "FAIL"),
                attest("VAL-C", "DOMAIN-C", "PASS"),
            ],
            validator_registry=VALIDATOR_REGISTRY,
            candidate_digest=CANDIDATE_DIGEST,
            constitution_digest=CONSTITUTION_DIGEST,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("VALIDATOR_RESULT_CONFLICT", result["violations"])

    def test_equivocation_is_blocked(self):
        result = evaluate_validator_quorum(
            [
                attest("VAL-A", "DOMAIN-A", "PASS", epoch=2),
                attest("VAL-A", "DOMAIN-A", "FAIL", epoch=2),
                attest("VAL-B", "DOMAIN-B", "PASS", epoch=2),
            ],
            validator_registry=VALIDATOR_REGISTRY,
            candidate_digest=CANDIDATE_DIGEST,
            constitution_digest=CONSTITUTION_DIGEST,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("VALIDATOR_EQUIVOCATION", result["violations"])

    def test_replayed_old_epoch_is_blocked(self):
        result = evaluate_validator_quorum(
            [
                attest("VAL-A", "DOMAIN-A", "PASS", epoch=0),
                attest("VAL-B", "DOMAIN-B", "PASS", epoch=1),
            ],
            validator_registry=VALIDATOR_REGISTRY,
            candidate_digest=CANDIDATE_DIGEST,
            constitution_digest=CONSTITUTION_DIGEST,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("ATTESTATION_EPOCH_INVALID", result["violations"])

    def test_rollback_evidence_is_digest_bound(self):
        evidence = build_rollback_evidence(
            snapshot_id="SNAP-1",
            snapshot_digest=ROLLBACK_DIGEST,
            constitution_digest=CONSTITUTION_DIGEST,
            verification_epoch=1,
        )
        self.assertEqual(
            validate_rollback_evidence(
                evidence,
                rollback_registry=ROLLBACK_REGISTRY,
                constitution_digest=CONSTITUTION_DIGEST,
            ),
            [],
        )

    def test_corrupted_rollback_is_blocked(self):
        evidence = build_rollback_evidence(
            snapshot_id="SNAP-1",
            snapshot_digest="0" * 64,
            constitution_digest=CONSTITUTION_DIGEST,
            verification_epoch=1,
        )
        violations = validate_rollback_evidence(
            evidence,
            rollback_registry=ROLLBACK_REGISTRY,
            constitution_digest=CONSTITUTION_DIGEST,
        )
        self.assertIn("ROLLBACK_SNAPSHOT_DIGEST_MISMATCH", violations)


if __name__ == "__main__":
    unittest.main()
