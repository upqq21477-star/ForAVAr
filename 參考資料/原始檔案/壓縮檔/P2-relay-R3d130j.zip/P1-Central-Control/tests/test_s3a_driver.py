"""S3a: CONVERSATION-RECORD wiring (Run.close verifies, Run.resume checks brief) + session_driver as the host of
Run.resume / Run.close.  SIMULATED_PASS (no real process death; death = release without close)."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(ROOT / "tools"))
import caller_audit  # noqa: E402
import event_log as el  # noqa: E402
import p2_run  # noqa: E402
import run_journal as rj  # noqa: E402
import session_driver as sd  # noqa: E402

CTOR = dict(write_scope=["calc.py"], protected=[], budget=12, goal_confirmed=True, run_id="RUN-T")
CID = "C1"
READ = {"path": "calc.py"}


class Died(BaseException):
    pass


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())
        self.wd, self.jp, self.lp = p2_run._toy(self.d / "w"), self.d / "j.jsonl", self.d / "ev.jsonl"

    def dead_run(self):  # a run that wrote a journal, did one step, then "died" (lock released, never closed)
        r = p2_run.Run(self.wd, **CTOR, journal_path=self.jp)
        p2_run._build_mode(r)
        r.step("read", READ)
        r.release()

    def turns(self, n=2):
        log = el.EventLog(self.lp)
        for i in range(n):
            el.record_dialogue_turn(log, workflow_id="RUN-T", conversation_id=CID, role=("USER", "ASSISTANT")[i % 2],
                                    content=f"t{i}", occurred_at="2026-10-16T00:00:00Z")
        return log

    def resume(self, brief):
        return p2_run.Run.resume(self.wd, self.jp, **CTOR, brief=brief, log_path=self.lp, conversation_id=CID)


class CloseVerifies(Base):
    def test_recorded(self):
        r = p2_run.Run(self.wd, **CTOR)
        res = r.close(self.lp, CID)
        self.assertEqual(res["dialogue_status"], "RECORDED")

    def test_verify_rejected_is_unverified_outcome_unchanged(self):
        r = p2_run.Run(self.wd, **CTOR)
        with mock.patch.object(p2_run.dl, "verify_dialogue", return_value={"status": "REJECTED", "reasons": ["GAP:2"]}):
            res = r.close(self.lp, CID)
        self.assertEqual((res["dialogue_status"], res["dialogue_reasons"]), ("UNVERIFIED", ["GAP:2"]))
        self.assertEqual(res["outcome_class"], "INCOMPLETE")

    def test_write_failure_is_unrecorded_and_close_does_not_raise(self):
        r = p2_run.Run(self.wd, **CTOR)
        with mock.patch.object(p2_run.el, "EventLog", side_effect=OSError("disk")):
            res = r.close(self.lp, CID)
        self.assertEqual((res["dialogue_status"], res["close_error"]), ("UNRECORDED", "CLOSE_WRITE_FAILED"))


class ResumeChecksBrief(Base):
    def test_matching_brief_gives_next_turn(self):
        self.dead_run()
        log = self.turns(2)
        res = self.resume({"recent": el.dialogue_recent_refs(log.events_for("SEGMENT", "RUN-T"), CID)})
        self.assertEqual(res.status, "RESUMED")
        self.assertEqual(res.run.dialogue_next_turn, 3)

    def test_brief_ahead_of_log_is_rejected_and_lock_released(self):
        self.dead_run()
        self.turns(1)
        res = self.resume({"recent": [f"DIALOGUE:{CID}#9 USER sha256:{'0' * 12}"]})
        self.assertEqual(res.status, "INCOMPLETE")
        self.assertTrue(res.reason.startswith("DIALOGUE_REJECTED"))
        self.assertEqual(p2_run.Run.resume(self.wd, self.jp, **CTOR).status, "RESUMED")  # not locked, not consumed

    def test_stale_brief_resumes_with_warning(self):
        self.dead_run()
        self.turns(2)
        res = self.resume({"recent": []})
        self.assertEqual(res.status, "RESUMED")
        self.assertTrue(any(w.startswith("BRIEF_BEHIND") for w in res.warnings))

    def test_unreadable_log_fails_closed(self):
        self.dead_run()
        with mock.patch.object(p2_run.el, "EventLog", side_effect=OSError("x")):
            res = self.resume({"recent": []})
        self.assertEqual((res.status, res.reason), ("INCOMPLETE", "DIALOGUE_UNREADABLE"))


class Driver(Base):
    def drive(self, work, **kw):
        return sd.drive(self.wd, self.jp, self.lp, CID, work, **{**CTOR, **kw})

    def test_start_then_close(self):
        out = self.drive(lambda r: r.step("read", READ))
        self.assertEqual((out["status"], out["resumed"]), ("CLOSED", False))
        self.assertEqual(out["close"]["dialogue_status"], "RECORDED")
        self.assertTrue(rj.Journal(self.jp).closed)

    def test_interrupt_leaves_journal_resumable_then_driver_resumes(self):
        def die(r):
            r.step("read", READ)
            raise Died()
        with self.assertRaises(Died):
            self.drive(die)
        seen = []
        out = self.drive(lambda r: seen.append(len(r.trace)))
        self.assertEqual((out["status"], out["resumed"]), ("CLOSED", True))
        self.assertGreater(seen[0], 0)  # continued from the journal, not from scratch

    def test_error_in_work_closes_as_incomplete_error(self):
        def boom(r):
            raise RuntimeError("x")
        out = self.drive(boom)
        self.assertEqual((out["status"], out["error"], out["close"]["outcome_class"]), ("ERROR", "RuntimeError", "INCOMPLETE"))
        self.assertTrue(rj.Journal(self.jp).closed)

    def test_closed_journal_is_not_restarted(self):
        self.drive(lambda r: None)
        called = []
        out = self.drive(lambda r: called.append(1))
        self.assertEqual((out["status"], called), ("NOTHING_TO_RESUME", []))

    def test_resume_failure_does_not_call_work(self):
        self.dead_run()
        called = []
        out = self.drive(lambda r: called.append(1), brief={"recent": [f"DIALOGUE:{CID}#9 USER sha256:{'0' * 12}"]})
        self.assertEqual((out["status"], called), ("INCOMPLETE", []))

    def test_cli_recover_closes_interrupted_run(self):
        self.dead_run()
        argv = ["recover", "--workdir", str(self.wd), "--journal", str(self.jp), "--log", str(self.lp), "--cid", CID]
        self.assertEqual(sd.main(argv), 0)
        self.assertTrue(rj.Journal(self.jp).closed)
        self.assertEqual(sd.main(argv), 1)  # already closed: nothing to recover

    def test_cli_recover_without_journal_is_usage_error(self):
        self.assertEqual(sd.main(["recover", "--workdir", str(self.wd), "--journal", str(self.jp), "--log", str(self.lp),
                                  "--cid", CID]), 2)


class ProductionCallers(unittest.TestCase):
    def test_dialogue_loop_and_run_class_have_production_callers(self):
        specs = ["dialogue_loop:resume_from_brief", "dialogue_loop:verify_dialogue", "p2_run:Run"]
        rows = {f"{r['module']}:{r['function']}": r["classification"] for r in caller_audit.audit(ROOT, specs)["results"]}
        self.assertEqual(rows, {s: "PRODUCTION" for s in specs})

    def test_session_driver_calls_run_resume_and_close(self):  # caller_audit resolves module functions, not methods
        import ast
        tree = ast.parse((ROOT / "P1-Central-Control" / "scripts" / "session_driver.py").read_text(encoding="utf-8"))
        names = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute):
                v, parts = n.func, []
                while isinstance(v, ast.Attribute):
                    parts.append(v.attr)
                    v = v.value
                if isinstance(v, ast.Name):
                    names.add(".".join([v.id] + parts[::-1]))
        self.assertLessEqual({"p2_run.Run.resume", "p2_run.Run.close"}, names)


if __name__ == "__main__":
    unittest.main()
