import json
import sys
import tempfile
import textwrap
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from progressive_repository_scanner import DEFAULT_EXCLUDES, _inventory, execute


class ProgressiveRepositoryScannerTests(unittest.TestCase):
    def _request(self, root):
        return {
            "schema_version": "1.0",
            "request_id": "SCAN:TEST",
            "root_path": str(root),
            "focus_paths": ["app.py"],
            "max_inventory_files": 50,
            "max_inventory_bytes": 50000,
            "max_deep_read_files": 4,
            "max_deep_read_bytes": 8000,
            "target_context_budget": 6000,
            "hard_context_ceiling": 12000,
            "runtime_probes": [
                {
                    "probe_id": "PROBE:TEST",
                    "command": [sys.executable, "app.py"],
                    "expected_exit_code": 0,
                }
            ],
            "oracle": {
                "oracle_id": "ORACLE:TEST",
                "minimum_classes": ["POSITIVE", "NEGATIVE", "RECOVERY"],
                "scenarios": [
                    {"scenario_id": "P", "class": "POSITIVE", "command": [sys.executable, "app.py"], "expected_exit_code": 0},
                    {"scenario_id": "N", "class": "NEGATIVE", "command": [sys.executable, "-c", "raise SystemExit(1)"], "expected_exit_code": 1},
                    {"scenario_id": "R", "class": "RECOVERY", "command": [sys.executable, "-c", "print('recovery')"], "expected_exit_code": 0},
                ],
            },
        }

    def test_runs_all_levels(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("import helper\nprint(helper.VALUE)\n", encoding="utf-8")
            (root / "helper.py").write_text("VALUE = 7\n", encoding="utf-8")
            result = execute(self._request(root))
            self.assertEqual(result["status"], "PASS")
            self.assertEqual([x["level"] for x in result["levels"]], ["L0","L1","L2","L3","L4","L5","L6"])
            self.assertEqual(result["levels"][4]["status"], "SCANNED")
            self.assertEqual(result["levels"][5]["status"], "VERIFIED")
            self.assertEqual(result["levels"][6]["status"], "PASS")
            self.assertTrue(result["selected_context"]["deep_reads"])
            self.assertEqual(len(result["runtime_evidence"]), 1)

    def test_hard_context_ceiling_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            # 檔案本身要真的超過 hard_context_ceiling（原寫法只有 19 bytes，永遠不會觸發）
            (root / "app.py").write_text("print('" + "x" * 10000 + "')\n", encoding="utf-8")
            req = self._request(root)
            req["max_deep_read_bytes"] = 12000
            req["target_context_budget"] = 100
            req["hard_context_ceiling"] = 200
            result = execute(req)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["levels"][4]["status"], "DEFERRED")
            self.assertEqual(result["selected_context"]["context_gate"]["action"], "TRIM_OR_SPLIT")

    def test_inventory_byte_limit_cannot_be_marked_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            # 內容須是可執行的 Python：_request 內的 runtime probe／oracle 會真的執行 app.py，
            # 原寫法 "x"*100 會 NameError，使 L5／L6 為 FAIL，FAIL 優先於 INCOMPLETE，測不到 byte 上限語意。
            (root / "app.py").write_text("print('ok')\n" + "# " + "x" * 100 + "\n", encoding="utf-8")
            req = self._request(root)
            req["max_inventory_bytes"] = 10
            result = execute(req)
            self.assertFalse(result["inventory"]["complete_under_limits"])
            self.assertEqual(result["levels"][1]["status"], "DEFERRED")
            self.assertIn("BYTE_LIMIT_REACHED", {x["code"] for x in result["levels"][1]["facts"]["issues"]})
            self.assertEqual(result["status"], "INCOMPLETE")

    def test_missing_root_is_blocked(self):
        req = self._request(Path("/definitely/missing/root"))
        result = execute(req)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["coverage_ledger"][0]["status"], "UNAVAILABLE")


    def test_targeted_inventory_follows_local_imports_but_ignores_unrelated_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("import helper\nprint(helper.VALUE)\n", encoding="utf-8")
            (root / "helper.py").write_text("VALUE = 7\n", encoding="utf-8")
            (root / "unrelated.py").write_text("UNRELATED = True\n", encoding="utf-8")
            rows, consumed, complete, issues = _inventory(
                root, set(DEFAULT_EXCLUDES), 50, 50000,
                focus_paths=["app.py"], mode="TARGETED",
            )
            paths = {row["path"] for row in rows}
            self.assertEqual(paths, {"app.py", "helper.py"})
            self.assertNotIn("unrelated.py", paths)
            self.assertTrue(complete)
            self.assertEqual(issues, [])
            self.assertGreater(consumed, 0)

    def test_targeted_scan_with_missing_explicit_path_stays_incomplete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "present.py").write_text("VALUE = 1\n", encoding="utf-8")
            rows, _consumed, complete, issues = _inventory(
                root, set(DEFAULT_EXCLUDES), 50, 50000,
                focus_paths=["present.py", "not-there.py"], mode="TARGETED",
            )
            self.assertEqual({row["path"] for row in rows}, {"present.py"})
            self.assertFalse(complete)
            self.assertIn("TARGET_PATH_NOT_FOUND", {item["code"] for item in issues})
            # The missing observation is scoped to one explicit path only;
            # the scanner does not infer anything about unrelated paths.
            self.assertNotIn("unrelated.py", {item.get("path") for item in issues})

    def test_targeted_scan_rejects_path_traversal_without_reading_outside_root(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp) / "repo"
            root.mkdir()
            outside = Path(tmp) / "outside.py"
            outside.write_text("SECRET = True\n", encoding="utf-8")
            rows, _consumed, complete, issues = _inventory(
                root, set(DEFAULT_EXCLUDES), 50, 50000,
                focus_paths=["../outside.py"], mode="TARGETED",
            )
            self.assertEqual(rows, [])
            self.assertFalse(complete)
            self.assertIn("TARGET_PATH_FORBIDDEN", {item["code"] for item in issues})
            outside.unlink(missing_ok=True)

    def test_targeted_mode_requires_scope_instead_of_falling_back_to_full_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text("VALUE = 1\n", encoding="utf-8")
            (root / "unrelated.py").write_text("VALUE = 2\n", encoding="utf-8")
            rows, _consumed, complete, issues = _inventory(
                root, set(DEFAULT_EXCLUDES), 50, 50000,
                focus_paths=[], mode="TARGETED",
            )
            self.assertEqual(rows, [])
            self.assertFalse(complete)
            self.assertEqual([item["code"] for item in issues], ["FOCUS_PATHS_REQUIRED_FOR_TARGETED_SCAN"])


if __name__ == "__main__":
    unittest.main()
