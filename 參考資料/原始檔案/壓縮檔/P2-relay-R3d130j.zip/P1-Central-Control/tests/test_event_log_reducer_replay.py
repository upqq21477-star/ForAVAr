#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from copy import deepcopy
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(TESTS_DIR))

import central_controller  # noqa: E402
from packet_layer import build_result_packet  # noqa: E402
from p7_test_records import records_for  # noqa: E402
from event_log import EventLog, content_hash, validate_event  # noqa: E402
from event_reducer import (  # noqa: E402
    initial_workflow_projection,
    projection_control_view,
    replay_workflow,
    recover_workflow,
)


class EventLogReducerReplayTests(unittest.TestCase):
    def make_segment(self, workflow_id: str, segment_id: str) -> dict:
        return {
            "segment_id": segment_id,
            "workflow_id": workflow_id,
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "P2 event log test segment",
            "input_scope": "test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 300000,
            "completion_contract": {
                "status": "WORK_COMPLETE",
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "ARTIFACT:execution-001",
            "context_cohort_id": "COHORT-TEST",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
        }

    def make_result(self, task_packet: dict, decision_code: str) -> dict:
        return build_result_packet(
            task_packet,
            {
                "decision_code": decision_code,
                "output_refs": ["ARTIFACT:result-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "unresolved": ["unresolved"] if decision_code == "UNRESOLVED" else [],
                "evidence_refs": ["EVIDENCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "provenance_refs": ["PROVENANCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 1,
                },
                "usage_observed": True,
            },
        )

    def run_completed_workflow(self, event_path: Path) -> tuple[dict, list[dict]]:
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-P2", "TASK-P2")
        state = central_controller.queue_segment(
            state,
            self.make_segment("WF-P2", "SEG-P2-001"),
        )
        log = EventLog(event_path)
        state, task_packets = central_controller.dispatch(
            state, event_log=log, execution_store=execution_store
        )
        result_packet = self.make_result(task_packets[0], "WORK_COMPLETE")
        envelope = execution_store[result_packet["execution_record_ref"]]
        evidence_records, provenance_records = records_for(
            envelope["task_packet"], result_packet, envelope["execution_record"]
        )
        state = central_controller.receive_result(
            state,
            result_packet,
            event_log=log,
            execution_store=execution_store,
            distillation_store=distillation_store,
            evidence_records=evidence_records,
            provenance_records=provenance_records,
        )
        return state, log.read_all("WORKFLOW")

    def test_event_schema_accepts_runtime_transition_control_data(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            state, events = self.run_completed_workflow(
                Path(temp) / "WF-P2.events.jsonl"
            )

        self.assertEqual(state["status"], "COMPLETED")
        for event in events:
            validate_event(event)

    def test_runtime_gate_persists_every_accepted_transition(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            state, events = self.run_completed_workflow(
                Path(temp) / "WF-P2.events.jsonl"
            )

        self.assertEqual(len(events), 2)
        self.assertEqual(
            [event["revision"] for event in events],
            [1, 2],
        )
        self.assertEqual(
            [event["to_status"] for event in events],
            ["RUNNING", "COMPLETED"],
        )
        self.assertEqual(
            all(event["event_type"] == "STATE_TRANSITION_APPLIED" for event in events),
            True,
        )

    def test_replay_reconstructs_same_runtime_projection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            state, events = self.run_completed_workflow(
                Path(temp) / "WF-P2.events.jsonl"
            )

        initial = initial_workflow_projection("WF-P2")
        replayed = replay_workflow(initial, events)

        self.assertEqual(
            projection_control_view(state),
            projection_control_view(replayed),
        )
        self.assertEqual(replayed["status"], "COMPLETED")
        self.assertEqual(replayed["state_revision"], 2)

    def test_replay_is_deterministic_across_multiple_runs(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            _, events = self.run_completed_workflow(
                Path(temp) / "WF-P2.events.jsonl"
            )

        initial = initial_workflow_projection("WF-P2")
        first = replay_workflow(initial, events)
        second = replay_workflow(initial, events)

        self.assertEqual(first, second)

    def test_tampered_event_is_rejected_before_replay(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            _, events = self.run_completed_workflow(path)
            events[1]["to_status"] = "RUNNING"
            path.write_text(
                "\n".join(
                    json.dumps(event, ensure_ascii=False, sort_keys=True)
                    for event in events
                ) + "\n",
                encoding="utf-8",
            )

            with self.assertRaises(ValueError):
                EventLog(path).read_all("WORKFLOW")

    def test_revision_gap_is_rejected_on_append(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            execution_store = {}
            distillation_store = {}
            state = central_controller.init_state("WF-P2", "TASK-P2")
            state = central_controller.queue_segment(
                state,
                self.make_segment("WF-P2", "SEG-P2-001"),
            )
            log = EventLog(path)
            state, _ = central_controller.dispatch(state, event_log=log, execution_store=execution_store)
            event = deepcopy(log.read_all("WORKFLOW")[-1])
            event["event_id"] = "evt-gap"
            event["object_id"] = "EVENT:evt-gap"
            event["revision"] = 4
            event["content_hash"] = content_hash(event)

            with self.assertRaises(ValueError):
                log.append(event)

    def test_log_rejects_multiple_aggregates(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            execution_store = {}
            distillation_store = {}
            state = central_controller.init_state("WF-P2", "TASK-P2")
            state = central_controller.queue_segment(
                state,
                self.make_segment("WF-P2", "SEG-P2-001"),
            )
            log = EventLog(path)
            state, _ = central_controller.dispatch(state, event_log=log, execution_store=execution_store)
            event = deepcopy(log.read_all("WORKFLOW")[-1])
            event["aggregate_id"] = "WF-OTHER"
            event["event_id"] = "evt-other"
            event["object_id"] = "EVENT:evt-other"
            event["content_hash"] = content_hash(event)

            with self.assertRaises(ValueError):
                log.append(event)

    def test_queued_fail_also_creates_replayable_event(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            log = EventLog(path)
            execution_store = {}
            distillation_store = {}
            state = central_controller.init_state("WF-P2", "TASK-P2")
            state = central_controller.queue_segment(
                state,
                self.make_segment("WF-P2", "SEG-P2-001"),
            )
            state, task_packets = central_controller.dispatch(state, event_log=log, execution_store=execution_store)
            state = central_controller.queue_segment(
                state,
                self.make_segment("WF-P2", "SEG-P2-002"),
            )
            state = central_controller.receive_result(
                state,
                self.make_result(task_packets[0], "FAIL"),
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
            )
            events = log.read_all("WORKFLOW")

        replayed = replay_workflow(
            initial_workflow_projection("WF-P2"),
            events,
        )
        self.assertEqual(state["status"], "RUNNING")
        self.assertEqual(
            projection_control_view(state),
            projection_control_view(replayed),
        )

    def test_recovery_classifies_committed_command_and_rebuilds_projection(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            state, events = self.run_completed_workflow(path)
            candidate = {
                "command_id": events[0]["command_id"],
                "idempotency_key": events[0]["idempotency_key"],
            }

            recovered = recover_workflow(
                state,
                EventLog(path),
                candidate_command=candidate,
            )

        self.assertEqual(recovered["status"], "RECOVERED")
        self.assertEqual(recovered["execution_status"], "COMMITTED")
        self.assertEqual(recovered["next_action"], "CONTINUE")
        self.assertTrue(recovered["projection_matches"])
        self.assertEqual(
            recovered["matched_event_id"],
            events[0]["event_id"],
        )

    def test_recovery_classifies_clean_missing_command_as_uncommitted(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            state, _ = self.run_completed_workflow(path)

            recovered = recover_workflow(
                state,
                EventLog(path),
                candidate_command={
                    "command_id": "CMD:missing",
                    "idempotency_key": "IK:missing",
                },
            )

        self.assertEqual(recovered["status"], "RECOVERED")
        self.assertEqual(recovered["execution_status"], "UNCOMMITTED")
        self.assertEqual(
            recovered["next_action"],
            "REISSUE_THROUGH_COMMAND_LAYER",
        )

    def test_recovery_marks_partial_final_line_unknown_without_mutating_log(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            path = Path(temp) / "WF-P2.events.jsonl"
            state, events = self.run_completed_workflow(path)
            with path.open("a", encoding="utf-8") as handle:
                handle.write('{"event_type":"STATE_TRANSITION_APPLIED"')

            recovered = recover_workflow(
                state,
                EventLog(path),
                candidate_command={
                    "command_id": "CMD:unknown-after-tail",
                    "idempotency_key": "IK:unknown-after-tail",
                },
            )
            raw = path.read_text(encoding="utf-8")

        self.assertEqual(recovered["status"], "RECONCILIATION_REQUIRED")
        self.assertEqual(recovered["execution_status"], "UNKNOWN")
        self.assertEqual(
            recovered["next_action"],
            "RECONCILIATION_REQUIRED",
        )
        self.assertTrue(recovered["projection_matches"])
        self.assertEqual(len(recovered["projection"]["last_transition"]), len(events[-1]))
        self.assertIn('{"event_type":"STATE_TRANSITION_APPLIED"', raw)

    def test_event_log_is_external_to_source_tree(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            runtime_path = Path(temp) / "events" / "WF-P2.events.jsonl"
            state, _ = self.run_completed_workflow(runtime_path)
            self.assertTrue(runtime_path.is_file())
            self.assertEqual(state["status"], "COMPLETED")

        self.assertFalse((ROOT / "events").exists())


if __name__ == "__main__":
    unittest.main()
