"""S2a: G4 atomic_write + G2 run_journal. All failure injection is simulated (SIMULATED_PASS)."""
import os
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import atomic_write as aw  # noqa: E402
import run_journal as rj  # noqa: E402


class AtomicWriteTests(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())
        self.f = self.d / "a.txt"
        self.f.write_text("old", encoding="utf-8")

    def tmps(self):
        return [p.name for p in self.d.iterdir() if p.name.endswith(".tmp")]

    def test_write_and_idempotent(self):
        aw.atomic_write(self.f, "new")
        aw.atomic_write(self.f, "new")
        self.assertEqual(self.f.read_text(encoding="utf-8"), "new")
        self.assertEqual(self.tmps(), [])

    def test_replace_failure_keeps_old(self):
        with mock.patch("atomic_write.os.replace", side_effect=OSError("x")):
            with self.assertRaises(OSError):
                aw.atomic_write(self.f, "new")
        self.assertEqual(self.f.read_bytes(), b"old")
        self.assertEqual(self.tmps(), [])

    def test_fsync_failure_cleans_tmp(self):
        with mock.patch("atomic_write.os.fsync", side_effect=OSError("x")):
            with self.assertRaises(OSError):
                aw.atomic_write(self.f, "new")
        self.assertEqual((self.f.read_bytes(), self.tmps()), (b"old", []))

    def test_interrupt_before_replace_keeps_old(self):
        with mock.patch("atomic_write.os.replace", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                aw.atomic_write(self.f, "new")
        self.assertEqual((self.f.read_bytes(), self.tmps()), (b"old", []))

    def test_dir_unwritable_refuses(self):
        with mock.patch("atomic_write.tempfile.mkstemp", side_effect=PermissionError):
            with self.assertRaises(PermissionError):
                aw.atomic_write(self.f, "new")
        self.assertEqual(self.f.read_bytes(), b"old")

    def test_stale_temps_reported(self):
        (self.d / "b.txt.zz.tmp").write_text("", encoding="utf-8")
        self.assertEqual(aw.stale_temps(self.d), ["b.txt.zz.tmp"])


class JournalTests(unittest.TestCase):
    def setUp(self):
        self.p = Path(tempfile.mkdtemp()) / "j.jsonl"

    def fill(self, n=3):
        j = rj.Journal(self.p)
        for i in range(n):
            j.append("trace", {"i": i})
        j.close()

    def test_roundtrip_and_chain(self):
        self.fill()
        recs, warns, _ = rj.read_journal(self.p)
        self.assertEqual([r["seq"] for r in recs], [1, 2, 3])
        self.assertEqual(warns, [])

    def test_truncated_tail_dropped_with_warning_and_read_is_pure(self):
        self.fill()
        raw = self.p.read_bytes()
        self.p.write_bytes(raw[:-9])
        before = self.p.read_bytes()
        recs, warns, _ = rj.read_journal(self.p)
        self.assertEqual(len(recs), 2)
        self.assertTrue(any(w.startswith("TAIL_TRUNCATED") for w in warns))
        self.assertEqual(self.p.read_bytes(), before)

    def test_reopen_repairs_tail_then_appends(self):
        self.fill()
        self.p.write_bytes(self.p.read_bytes()[:-9])
        j = rj.Journal(self.p)
        j.append("trace", {"i": 9})
        j.close()
        recs, warns, _ = rj.read_journal(self.p)
        self.assertEqual([r["seq"] for r in recs], [1, 2, 3])
        self.assertEqual(warns, [])

    def test_middle_tamper_is_corrupt(self):
        self.fill()
        lines = self.p.read_text(encoding="utf-8").splitlines()
        lines[1] = lines[1].replace('"i": 1', '"i": 7')
        self.p.write_text("\n".join(lines) + "\n", encoding="utf-8")
        with self.assertRaises(rj.JournalCorrupt) as cm:
            rj.read_journal(self.p)
        self.assertEqual(cm.exception.line, 2)

    def test_write_failure_raises(self):
        j = rj.Journal(self.p)
        with mock.patch("run_journal.os.fsync", side_effect=OSError("disk")):
            with self.assertRaises(rj.JournalWriteError):
                j.append("trace", {})
        j.close()

    def test_second_opener_rejected(self):
        j = rj.Journal(self.p)
        with self.assertRaises(rj.JournalLocked):
            rj.Journal(self.p)
        j.close()
        rj.Journal(self.p).close()

    def test_unwritable_dir_refused(self):
        with mock.patch("run_journal.os.access", return_value=False):
            with self.assertRaises(rj.JournalError):
                rj.Journal(self.p)


if __name__ == "__main__":
    unittest.main()
