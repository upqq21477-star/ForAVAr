#!/usr/bin/env python3
"""U-5a／U-5b：result_command_types、result_terminal_state 只查 policy/result_routing.v1.0.json；行為與原 if 鏈等價。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import command_layer  # noqa: E402

# 原 if 鏈的完整真值（遷移前行為，逐格固定）
EXPECTED = {
    ("WORK_COMPLETE", "RUNNING", False): ["COMPLETE"],
    ("WORK_COMPLETE", "WAITING", False): ["RESUME", "COMPLETE"],
    ("FAIL", "RUNNING", False): ["FAIL"],
    ("FAIL", "WAITING", False): ["FAIL"],
    ("BLOCK", "RUNNING", False): ["BLOCK"],
    ("BLOCK", "WAITING", False): ["BLOCK"],
    ("UNRESOLVED", "RUNNING", False): ["BLOCK"],
    ("UNRESOLVED", "WAITING", False): ["BLOCK"],
    ("NEEDS_BRAIN", "RUNNING", False): ["WAIT"],
    ("NEEDS_BRAIN", "WAITING", False): [],
}
TERMINAL = {"WORK_COMPLETE": "WORKFLOW_COMPLETE", "FAIL": "BLOCK", "BLOCK": "BLOCK",
            "UNRESOLVED": "UNRESOLVED", "NEEDS_BRAIN": None}


class ResultRoutingTableTests(unittest.TestCase):
    def test_table_matches_legacy_behaviour(self) -> None:
        for (decision, status, work), expected in EXPECTED.items():
            got = command_layer.result_command_types(
                {"status": status}, decision, has_queued_work=work)
            self.assertEqual(got, expected, (decision, status, work))
        for decision in TERMINAL:
            for status in ("RUNNING", "WAITING"):
                for kw in ({"has_queued_work": True}, {"has_queued_work": False, "has_active_work": True}):
                    self.assertEqual(
                        command_layer.result_command_types({"status": status}, decision, **kw), [])

    def test_terminal_state_from_table(self) -> None:
        for decision, expected in TERMINAL.items():
            self.assertEqual(command_layer.result_terminal_state(decision), expected, decision)

    def test_unknown_decision_and_bad_status_rejected(self) -> None:
        with self.assertRaises(ValueError):
            command_layer.result_command_types({"status": "RUNNING"}, "BOGUS", has_queued_work=False)
        with self.assertRaises(ValueError):
            command_layer.result_terminal_state("BOGUS")
        with self.assertRaises(ValueError):
            command_layer.result_command_types({"status": "READY"}, "FAIL", has_queued_work=False)


if __name__ == "__main__":
    unittest.main()
