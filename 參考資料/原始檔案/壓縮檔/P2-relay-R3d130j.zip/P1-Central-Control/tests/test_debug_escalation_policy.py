#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from debug_escalation_policy import decide, failure_signature


class DebugEscalationPolicyTests(unittest.TestCase):
    def diagnostic(self, classification: str = "RUNNER_STARTUP_FAILURE"):
        return {
            "head_sha": "abc1234567890",
            "classification": classification,
            "reason_code": "RUNNER_STARTUP_FAILURE_NO_STEP_EVIDENCE",
            "run_conclusion": "failure",
        }

    def current(self):
        return {
            "latest_runtime_observation": {
                "classification": "RUNNER_STARTUP_FAILURE",
                "head_sha": "abc1234567890",
                "program_regression_status": "INCOMPLETE",
            }
        }

    def run_rec(self, conclusion="failure", created_at="2026-10-05T12:00:00Z"):
        return {
            "head_sha": "abc1234567890",
            "conclusion": conclusion,
            "created_at": created_at,
            "status": "completed",
        }

    def test_first_failure_uses_existing_recovery(self):
        result = decide(
            current=self.current(),
            runs=[],
            diagnostic=self.diagnostic(),
        )
        self.assertEqual(result["level"], 1)
        self.assertEqual(result["next_action"], "USE_EXISTING_RECOVERY_PATH")
        self.assertTrue(result["auto_recovery_allowed"])

    def test_second_failure_allows_one_minimal_escalation(self):
        result = decide(
            current=self.current(),
            runs=[
                self.run_rec(created_at="2026-10-05T12:02:00Z"),
                self.run_rec(created_at="2026-10-05T12:00:00Z"),
            ],
            diagnostic=self.diagnostic(),
        )
        self.assertEqual(result["level"], 2)
        self.assertEqual(result["next_action"], "ALLOW_ONE_MINIMAL_ADDITIONAL_CAPABILITY")

    def test_third_failure_requires_deep_research(self):
        result = decide(
            current=self.current(),
            runs=[
                self.run_rec(created_at="2026-10-05T12:04:00Z"),
                self.run_rec(created_at="2026-10-05T12:02:00Z"),
                self.run_rec(created_at="2026-10-05T12:00:00Z"),
            ],
            diagnostic=self.diagnostic(),
        )
        self.assertEqual(result["level"], 3)
        self.assertEqual(
            result["next_action"],
            "REQUIRE_EXTERNAL_COMPARISON_BEFORE_FURTHER_REPAIR",
        )
        self.assertFalse(result["auto_recovery_allowed"])

    def test_amnesia_reconstruction_from_runs_only(self):
        current = {"latest_runtime_observation": {}}
        runs = [
            self.run_rec(created_at="2026-10-05T12:04:00Z"),
            self.run_rec(created_at="2026-10-05T12:02:00Z"),
            self.run_rec(created_at="2026-10-05T12:00:00Z"),
        ]
        result = decide(
            current=current,
            runs=runs,
            diagnostic=self.diagnostic(),
        )
        self.assertEqual(result["level"], 3)
        self.assertEqual(result["mode"], "DEEP_RESEARCH")

    def test_raw_github_run_shape_is_sufficient(self):
        raw = {
            "head_sha": "abc1234567890",
            "conclusion": "failure",
            "created_at": "2026-10-05T12:00:00Z",
        }
        result = decide(
            current=self.current(),
            runs=[raw],
            diagnostic=self.diagnostic(),
        )
        # consecutive_failures counts failures inside `runs` only; current's earlier
        # observation is not accumulated, so one raw failing run is level 1.
        self.assertEqual(result["level"], 1)

    def test_success_breaks_failure_chain(self):
        result = decide(
            current=self.current(),
            runs=[
                self.run_rec(conclusion="failure", created_at="2026-10-05T12:02:00Z"),
                self.run_rec(conclusion="success", created_at="2026-10-05T12:01:00Z"),
            ],
            diagnostic=self.diagnostic(),
        )
        self.assertEqual(result["level"], 1)

    def test_signature_is_stateless_and_hash_free(self):
        signature = failure_signature(self.diagnostic())
        self.assertEqual(signature[0], "abc1234567890")
        self.assertEqual(signature[1], "M32-CLOSE acceptance")
        self.assertEqual(signature[2], "RUNNER_STARTUP_FAILURE")


if __name__ == "__main__":
    unittest.main()
