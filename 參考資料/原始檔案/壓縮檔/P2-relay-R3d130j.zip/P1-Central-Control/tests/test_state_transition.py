#!/usr/bin/env python3
from __future__ import annotations

import copy
import json
import sys
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control/schemas"
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import state_transition as reducer  # noqa: E402


class StateTransitionContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.contract = reducer.load_contract()
        cls.command_schema = json.loads(
            (SCHEMA_DIR / "state_transition_command.schema.json").read_text(
                encoding="utf-8"
            )
        )

    def make_state(self, aggregate_type: str, status: str, revision: int = 0) -> dict:
        return {
            "aggregate_type": aggregate_type,
            "aggregate_id": f"{aggregate_type}:demo",
            "status": status,
            "state_revision": revision,
            "last_command_id": None,
            "last_idempotency_key": None,
            "last_command_fingerprint": None,
        }

    def make_command(
        self,
        aggregate_type: str,
        command_type: str,
        revision: int,
        command_id: str = "cmd-001",
    ) -> dict:
        return {
            "command_id": command_id,
            "aggregate_type": aggregate_type,
            "aggregate_id": f"{aggregate_type}:demo",
            "command_type": command_type,
            "expected_state_revision": revision,
            "idempotency_key": command_id,
            "caused_by": None,
            "issued_at": "2026-10-03T09:00:00Z",
        }

    def test_contract_is_valid_and_complete(self) -> None:
        errors = reducer.validate_contract(self.contract)
        self.assertEqual(errors, [])
        self.assertEqual(len(self.contract["transitions"]), 32)
        self.assertEqual(
            set(self.contract["states"]),
            {"WORKFLOW", "SEGMENT", "ATTEMPT"},
        )

    def test_command_schema_accepts_valid_command(self) -> None:
        Draft202012Validator.check_schema(self.command_schema)
        validator = Draft202012Validator(
            self.command_schema,
            format_checker=FormatChecker(),
        )
        command = self.make_command("WORKFLOW", "START", 0)
        errors = list(validator.iter_errors(command))
        self.assertEqual(errors, [])

    def test_workflow_happy_path(self) -> None:
        state = self.make_state("WORKFLOW", "READY")
        result = reducer.apply_transition(
            state,
            self.make_command("WORKFLOW", "START", 0),
            self.contract,
        )
        self.assertEqual(result["status"], reducer.ACCEPTED)
        self.assertEqual(result["state_after"]["status"], "RUNNING")
        self.assertEqual(result["state_after"]["state_revision"], 1)
        self.assertEqual(
            reducer.transition_event(result)["revision"],
            1,
        )

    def test_segment_happy_path(self) -> None:
        state = self.make_state("SEGMENT", "QUEUED")
        sequence = [
            ("DISPATCH", "DISPATCHED"),
            ("EXECUTE", "RUNNING"),
            ("VERIFY", "VERIFYING"),
            ("COMPLETE", "COMPLETED"),
        ]
        for revision, (command_type, expected_status) in enumerate(sequence):
            result = reducer.apply_transition(
                state,
                self.make_command("SEGMENT", command_type, revision, f"seg-{revision}"),
                self.contract,
            )
            self.assertEqual(result["status"], reducer.ACCEPTED)
            self.assertEqual(result["state_after"]["status"], expected_status)
            state = result["state_after"]

    def test_attempt_terminal_path(self) -> None:
        state = self.make_state("ATTEMPT", "PENDING")
        start = reducer.apply_transition(
            state,
            self.make_command("ATTEMPT", "START", 0),
            self.contract,
        )
        timeout = reducer.apply_transition(
            start["state_after"],
            self.make_command("ATTEMPT", "TIMEOUT", 1, "cmd-timeout"),
            self.contract,
        )
        self.assertEqual(timeout["state_after"]["status"], "TIMEOUT")
        self.assertEqual(timeout["state_after"]["state_revision"], 2)

        terminal_retry = reducer.apply_transition(
            timeout["state_after"],
            self.make_command("ATTEMPT", "START", 2, "cmd-terminal"),
            self.contract,
        )
        self.assertEqual(terminal_retry["status"], reducer.REJECTED)
        self.assertEqual(terminal_retry["reason"], "TERMINAL_STATE")
        self.assertEqual(terminal_retry["state_after"], timeout["state_after"])

    def test_illegal_transition_is_rejected_without_mutation(self) -> None:
        state = self.make_state("WORKFLOW", "READY")
        original = copy.deepcopy(state)
        result = reducer.apply_transition(
            state,
            self.make_command("WORKFLOW", "WAIT", 0),
            self.contract,
        )
        self.assertEqual(result["status"], reducer.REJECTED)
        self.assertEqual(result["reason"], "INVALID_TRANSITION")
        self.assertEqual(result["state_after"], original)

    def test_revision_conflict_is_rejected(self) -> None:
        state = self.make_state("WORKFLOW", "READY", revision=4)
        result = reducer.apply_transition(
            state,
            self.make_command("WORKFLOW", "START", 3),
            self.contract,
        )
        self.assertEqual(result["reason"], "STATE_REVISION_CONFLICT")
        self.assertEqual(result["state_after"], state)

    def test_duplicate_idempotency_key_is_idempotent(self) -> None:
        state = self.make_state("WORKFLOW", "READY")
        first_command = self.make_command("WORKFLOW", "START", 0, "cmd-001")
        first = reducer.apply_transition(state, first_command, self.contract)

        retry = self.make_command("WORKFLOW", "START", 0, "cmd-002")
        retry["idempotency_key"] = first_command["idempotency_key"]
        second = reducer.apply_transition(
            first["state_after"],
            retry,
            self.contract,
        )
        self.assertEqual(first["status"], reducer.ACCEPTED)
        self.assertEqual(second["status"], reducer.REPLAY)
        self.assertEqual(second["reason"], "DUPLICATE_IDEMPOTENCY_KEY")
        self.assertEqual(second["state_after"], first["state_after"])

    def test_idempotency_conflict_is_rejected(self) -> None:
        state = self.make_state("WORKFLOW", "READY")
        first_command = self.make_command("WORKFLOW", "START", 0, "first")
        first = reducer.apply_transition(state, first_command, self.contract)

        conflicting = self.make_command("WORKFLOW", "CANCEL", 1, "second")
        conflicting["idempotency_key"] = first_command["idempotency_key"]
        second = reducer.apply_transition(
            first["state_after"],
            conflicting,
            self.contract,
        )
        self.assertEqual(second["reason"], "IDEMPOTENCY_KEY_CONFLICT")

    def test_command_id_conflict_is_rejected(self) -> None:
        state = self.make_state("WORKFLOW", "READY")
        first_command = self.make_command("WORKFLOW", "START", 0, "same-id")
        first = reducer.apply_transition(state, first_command, self.contract)

        conflicting = self.make_command("WORKFLOW", "CANCEL", 1, "same-id")
        conflicting["idempotency_key"] = "different-key"
        second = reducer.apply_transition(
            first["state_after"],
            conflicting,
            self.contract,
        )
        self.assertEqual(second["reason"], "COMMAND_ID_CONFLICT")

    def test_deterministic_replay(self) -> None:
        state = self.make_state("SEGMENT", "QUEUED")
        command = self.make_command("SEGMENT", "DISPATCH", 0)
        first = reducer.apply_transition(state, command, self.contract)
        replay = reducer.apply_transition(state, command, self.contract)
        self.assertEqual(first, replay)

    def test_blocked_segment_can_return_to_queue(self) -> None:
        state = self.make_state("SEGMENT", "QUEUED")
        blocked = reducer.apply_transition(
            state,
            self.make_command("SEGMENT", "BLOCK", 0),
            self.contract,
        )
        self.assertEqual(blocked["state_after"]["status"], "BLOCKED")
        unblocked = reducer.apply_transition(
            blocked["state_after"],
            self.make_command("SEGMENT", "UNBLOCK", 1, "seg-unblock"),
            self.contract,
        )
        self.assertEqual(unblocked["state_after"]["status"], "QUEUED")

    def test_contract_duplicate_transition_is_detected(self) -> None:
        bad_contract = copy.deepcopy(self.contract)
        bad_contract["transitions"].append(
            {
                "aggregate_type": "WORKFLOW",
                "from_status": "READY",
                "command_type": "START",
                "to_status": "RUNNING",
            }
        )
        errors = reducer.validate_contract(bad_contract)
        self.assertTrue(any("duplicate transition" in error for error in errors))


if __name__ == "__main__":
    unittest.main()
