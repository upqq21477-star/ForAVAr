#!/usr/bin/env python3
"""Acceptance must bind to content and run on the stdlib alone (no git, no pip, no network)."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import code_digest as cd  # noqa: E402
import local_acceptance as la  # noqa: E402


def make_tree(root: Path) -> None:
    for scope in cd.SCOPE:
        (root / "P1-Central-Control" / scope).mkdir(parents=True)
        (root / "P1-Central-Control" / scope / "a.txt").write_text(scope, encoding="utf-8")


class CodeDigestTest(unittest.TestCase):
    def test_digest_tracks_code_and_ignores_noise_and_state(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            make_tree(root)
            first = cd.code_digest(root)
            self.assertRegex(first, r"^code:[0-9a-f]{40}$")
            (root / "P1-Central-Control/scripts/__pycache__").mkdir()
            (root / "P1-Central-Control/scripts/__pycache__/x.pyc").write_bytes(b"x")
            (root / "P1-CURRENT.json").write_text("{}", encoding="utf-8")
            (root / "P1-Central-Control/progress").mkdir()
            (root / "P1-Central-Control/progress/w.json").write_text("{}", encoding="utf-8")
            self.assertEqual(cd.code_digest(root), first)
            (root / "P1-Central-Control/tests/a.txt").write_text("changed", encoding="utf-8")
            self.assertNotEqual(cd.code_digest(root), first)

    def test_no_git_is_needed_for_the_head(self):
        source = (SCRIPTS / "local_acceptance.py").read_text(encoding="utf-8")
        simulated = source.split("if not args.live:", 1)[1].split("with tempfile", 1)[0]
        self.assertNotIn("git_sha", simulated)
        self.assertNotIn("default_base_sha", simulated)


class BindContextTest(unittest.TestCase):
    def test_bind_rewrites_head_and_hash_together(self):
        from acceptance_context import sha256_payload

        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            context = {"context_id": "C", "status": "OPEN", "head_sha": "old1234567"}
            (root / "ctx.json").write_text(json.dumps(context), encoding="utf-8")
            (root / "P1-CURRENT.json").write_text(
                json.dumps({"current_stage": {"acceptance_ref": "ctx.json"}}), encoding="utf-8"
            )
            la.bind_context("code:abc1234", root)
            bound = json.loads((root / "ctx.json").read_text(encoding="utf-8"))
            self.assertEqual(bound["head_sha"], "code:abc1234")
            base = {k: v for k, v in bound.items() if k != "content_sha256"}
            self.assertEqual(bound["content_sha256"], sha256_payload(base))
            bound["status"] = "CLOSED"
            (root / "ctx.json").write_text(json.dumps(bound), encoding="utf-8")
            with self.assertRaises(ValueError):
                la.bind_context("code:def1234", root)


class StdlibFallbackTest(unittest.TestCase):
    def test_validators_import_without_installed_packages(self):
        probe = (
            "import sys; sys.path.insert(0, %r);"
            "import jsonschema, referencing;"
            "from jsonschema import Draft202012Validator;"
            "from referencing import Registry, Resource;"
            "Draft202012Validator({'type':'string'}).validate('ok');"
            "print(getattr(jsonschema,'FALLBACK',False))" % str(SCRIPTS)
        )
        done = subprocess.run([sys.executable, "-S", "-c", probe], capture_output=True, text=True)
        self.assertEqual(done.returncode, 0, done.stderr)
        self.assertEqual(done.stdout.strip(), "True")

    def test_record_names_the_validator_that_ran(self):
        import local_acceptance_capture as cap

        self.assertTrue(cap.validator_kind())


if __name__ == "__main__":
    unittest.main()
