#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import actions_execution_diagnostic as m11  # noqa: E402


class ActionsExecutionDiagnosticTests(unittest.TestCase):
    def run_data(self, status="completed", conclusion="failure", run_id=37163917422):
        return {
            "id": run_id,
            "status": status,
            "conclusion": conclusion,
        }

    def jobs(self, steps=None, conclusion="failure", status="completed", **extra):
        return {
            "jobs": [{
                "id": 111322840675,
                "name": "control-gate",
                "status": status,
                "conclusion": conclusion,
                "steps": steps,
                "logs_url": None,
                **extra,
            }]
        }

    def test_real_zero_step_case_is_runner_startup_failure(self):
        result = m11.build(
            self.run_data(),
            self.jobs(steps=[], runner_id=0, runner_name="", runner_group_id=0),
        )
        self.assertEqual(result["classification"], "RUNNER_STARTUP_FAILURE")
        self.assertFalse(result["evidence"]["step_execution_observed"])
        self.assertFalse(result["evidence"]["runner_assigned"])
        self.assertEqual(result["jobs"][0]["step_count"], 0)

    def test_empty_steps_with_assigned_runner_is_still_startup_failure_when_job_failed(self):
        result = m11.build(
            self.run_data(),
            self.jobs(steps=[], runner_id=123, runner_name="runner-1", runner_group_id=0),
        )
        self.assertEqual(result["classification"], "RUNNER_STARTUP_FAILURE")

    def test_failure_with_steps_is_workflow_execution_failure(self):
        result = m11.build(
            self.run_data(),
            self.jobs(
                steps=[{"name": "test", "conclusion": "failure"}],
                runner_id=123,
                runner_name="runner-1",
                runner_group_id=0,
            ),
        )
        self.assertEqual(result["classification"], "WORKFLOW_EXECUTION_FAILURE")
        self.assertTrue(result["evidence"]["step_execution_observed"])
        self.assertTrue(result["evidence"]["runner_assigned"])
        self.assertEqual(result["jobs"][0]["step_count"], 1)

    def test_success_with_steps_is_pass(self):
        result = m11.build(
            self.run_data(conclusion="success"),
            self.jobs(
                steps=[{"name": "test", "conclusion": "success"}],
                conclusion="success",
                runner_id=123,
                runner_name="runner-1",
                runner_group_id=0,
            ),
        )
        self.assertEqual(result["classification"], "PASS")

    def test_no_jobs_is_not_dispatched(self):
        result = m11.build(self.run_data(), {"jobs": []})
        self.assertEqual(result["classification"], "NOT_DISPATCHED")

    def test_active_run_is_incomplete(self):
        result = m11.build(
            self.run_data(status="in_progress", conclusion=None),
            self.jobs(
                steps=None,
                status="in_progress",
                conclusion=None,
                runner_id=0,
                runner_name="",
                runner_group_id=0,
            ),
        )
        self.assertEqual(result["classification"], "INCOMPLETE")

    def test_elapsed_seconds_is_captured(self):
        result = m11.build(
            self.run_data(),
            self.jobs(
                steps=[],
                runner_id=0,
                runner_name="",
                runner_group_id=0,
                started_at="2026-10-04T00:57:00Z",
                completed_at="2026-10-04T00:57:03Z",
            ),
        )
        self.assertEqual(result["jobs"][0]["elapsed_seconds"], 3.0)


if __name__ == "__main__":
    unittest.main()
