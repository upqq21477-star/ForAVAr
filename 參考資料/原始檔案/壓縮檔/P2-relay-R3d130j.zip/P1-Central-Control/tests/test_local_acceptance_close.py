#!/usr/bin/env python3
"""Acceptance must not depend on an external deployment.

Closing a Work Unit has to work with no network, no CI and no hosted runner, so that a
hosted-service outage or an exhausted quota can never stall acceptance. These tests close a
sandbox Work Unit with the network disabled and with every CI environment variable removed.
"""
from __future__ import annotations

import json
import os
import socket
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import local_acceptance as la  # noqa: E402
import local_acceptance_capture as cap  # noqa: E402

HEAD = "fedcba7654321"
PENDING = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE"


def write(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def make_sandbox(root: Path, status: str = "PASS") -> tuple[Path, Path]:
    work_ref = "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json"
    construction_ref = "P1-Central-Control/progress/construction/M32-CLOSE.construction.json"
    write(root / "P1-CURRENT.json", {
        "current_stage": {
            "id": "M32-CLOSE",
            "work_unit_id": "M32-CLOSE",
            "status": PENDING,
            "validated_control_gate_run": None,
            "validated_head_sha": None,
            "acceptance_ref": "acceptance.json",
        },
        "latest_runtime_observation": {},
        "implementation_control": {"active_work_packet": work_ref},
    })
    write(root / work_ref, {
        "status": PENDING,
        "acceptance": {"mode": "SIMULATION_ONLY"},
        "completion": {},
        "construction_packet_ref": construction_ref,
    })
    write(root / construction_ref, {"work_unit": "M32-CLOSE", "status": PENDING})
    write(root / "acceptance.json", {
        "context_id": "ACCEPTANCE_CONTEXT:M32-CLOSE",
        "kind": "ACCEPTANCE_CONTEXT",
        "status": "OPEN",
        "authority": "P1-CURRENT",
        "lifecycle_owner": "CENTRAL",
        "mode": "SIMULATION_ONLY",
        "head_sha": HEAD,
        "work_unit_ref": "M32-CLOSE",
        "work_id": "M32-CLOSE-VERTICAL-SLICE",
        "task_packet_ref": "TASK_PACKET:pkt-M32-CLOSE",
        "construction_packet_ref": "CONSTRUCTION:M32-CLOSE",
        "required_checks": ["repository_result_reentry"],
        "source_refs": ["P1-CURRENT.json"],
        "content_sha256": "sha256:" + ("0" * 64),
    })
    report = {
        "report_id": f"SIMULATED_CONTROL_GATE:{HEAD}",
        "base_sha": "abcdef1234567",
        "head_sha": HEAD,
        "status": status,
        "mode": "SIMULATION_ONLY",
        "simulated": True,
        "work_unit": "M32-CLOSE",
        "stages": [{
            "stage_id": "UNIT_TEST",
            "status": status,
            "object_ref": None,
            "reason_code": None if status == "PASS" else "TEST",
        }],
    }
    report_path = root / "report.json"
    write(report_path, report)
    record_path = root / "record.json"
    write(record_path, cap.build(report, report_path))
    return report_path, record_path


def tree(root: Path) -> dict[str, bytes]:
    return {p.relative_to(root).as_posix(): p.read_bytes() for p in sorted(root.rglob("*")) if p.is_file()}


class LocalCloseTests(unittest.TestCase):
    def test_close_needs_no_network_and_no_ci_environment(self):
        ci_free_env = {k: v for k, v in os.environ.items() if not k.startswith(("GITHUB_", "GH_", "CI", "RUNNER_"))}

        def no_network(*args, **kwargs):
            raise AssertionError("acceptance close attempted network access")

        with tempfile.TemporaryDirectory() as temp, \
                mock.patch.dict(os.environ, ci_free_env, clear=True), \
                mock.patch.object(socket.socket, "connect", no_network), \
                mock.patch.object(socket, "create_connection", no_network):
            root = Path(temp)
            report_path, record_path = make_sandbox(root)
            result = la.close_locally(report_path, record_path, root=root)
            current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
            work = json.loads((root / "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json").read_text(encoding="utf-8"))
            construction = json.loads((root / "P1-Central-Control/progress/construction/M32-CLOSE.construction.json").read_text(encoding="utf-8"))
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["execution_source"], "LOCAL")
        self.assertEqual(current["current_stage"]["status"], "VERIFIED")
        self.assertIsNone(current["current_stage"]["validated_control_gate_run"])  # no CI run id involved
        self.assertEqual(current["current_stage"]["validated_head_sha"], HEAD)
        self.assertEqual(work["status"], "VERIFIED")
        self.assertEqual(construction["status"], "VERIFIED")
        self.assertIs(current["latest_runtime_observation"]["evidence"], False)  # honest: simulation, not external evidence

    def test_failed_acceptance_never_closes(self):
        for status in ("FAIL", "INCOMPLETE"):
            with tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                report_path, record_path = make_sandbox(root, status)
                before = tree(root)
                with self.assertRaises(ValueError):
                    la.close_locally(report_path, record_path, root=root)
                self.assertEqual(tree(root), before, status)

    def test_close_is_all_or_nothing_when_a_write_fails_midway(self):
        real_replace = os.replace
        calls = {"n": 0}

        def flaky_replace(src, dst):
            calls["n"] += 1
            if calls["n"] == 3:  # Current and Work are swapped in, Construction fails
                raise OSError("disk full")
            return real_replace(src, dst)

        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            report_path, record_path = make_sandbox(root)
            before = tree(root)
            with mock.patch.object(cap.os, "replace", flaky_replace):
                with self.assertRaises(OSError):
                    la.close_locally(report_path, record_path, root=root)
            self.assertEqual(calls["n"], 3)
            self.assertEqual(tree(root), before)  # nothing half-closed, no stray .tmp files

    def test_close_flag_is_rejected_with_live_mode(self):
        result = subprocess.run(
            [sys.executable, "-B", str(SCRIPTS / "local_acceptance.py"),
             "--output", "/dev/null", "--acceptance-output", "/dev/null", "--live", "--close"],
            capture_output=True, text=True, cwd=ROOT, check=False,
        )
        self.assertEqual(result.returncode, 2)
        self.assertIn("--close", result.stderr)


class HostedWorkflowIsOptionalTests(unittest.TestCase):
    """The hosted workflow may only be a manual cross-check, never the way a Work Unit closes."""

    WORKFLOW = ROOT / ".github/workflows/m32-close-acceptance.yml"

    def trigger_block(self) -> str:
        text = self.WORKFLOW.read_text(encoding="utf-8")
        return text[text.index("\non:\n"):text.index("\njobs:\n")]

    def test_never_runs_automatically_on_push(self):
        block = self.trigger_block()
        self.assertIn("workflow_dispatch:", block)
        for automatic in ("push:", "pull_request:", "schedule:", "workflow_run:"):
            self.assertNotIn(automatic, block)

    def test_hosted_finalizer_writes_state_only_when_explicitly_asked(self):
        text = self.WORKFLOW.read_text(encoding="utf-8")
        finalize = text[text.index("\n  finalize:\n"):]
        self.assertIn("inputs.apply_state", finalize.split("steps:")[0])
        self.assertIn("default: false", self.trigger_block())


if __name__ == "__main__":
    unittest.main()
