"""r16 R-0 regression tests: D1 (order-dependent terminal), D2 (double write), D10 (stranded dependents)."""
from __future__ import annotations

import sys
import tempfile
import unittest
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "scripts"), str(ROOT / "tests")]

import central_controller  # noqa: E402
import test_parallel_scheduler as fx  # noqa: E402
from event_log import EventLog  # noqa: E402
from p7_test_records import records_for  # noqa: E402


def run_workflow(segments: dict, order: list[str], codes: dict[str, str]) -> dict:
    """segments: {id: [dependency ids]}; results are fed in `order`; only dispatched ids may report."""
    t = fx.ParallelSchedulerTests()
    built = {sid: t.make_segment(sid, dependencies=deps) for sid, deps in segments.items()}
    execution_store, distillation_store = {}, {}
    state = central_controller.init_state("WF-P5", "TASK-P5")
    for seg in built.values():
        state = central_controller.queue_segment(state, seg)
    with tempfile.TemporaryDirectory() as tmp:
        log = EventLog(Path(tmp) / "events.jsonl")
        state, packets = central_controller.dispatch(
            state, event_log=log, execution_store=execution_store, max_concurrency=4
        )
        pending = {p["segment_id"]: p for p in packets}
        for sid in order:
            result = t.make_result(pending.pop(sid), codes[sid])
            env = execution_store[result["execution_record_ref"]]
            if codes[sid] == "WORK_COMPLETE":
                evidence, provenance = records_for(env["task_packet"], result, env["execution_record"])
            else:
                evidence = provenance = None
            state = central_controller.receive_result(
                state, result, event_log=log, execution_store=execution_store,
                distillation_store=distillation_store, segment_store=built,
                evidence_records=evidence, provenance_records=provenance,
            )
    return state


class R16RuntimeFixTests(unittest.TestCase):
    def test_d1_terminal_state_is_independent_of_arrival_order(self):
        codes = {"A": "FAIL", "B": "WORK_COMPLETE"}
        outcomes = {
            "".join(order): run_workflow({"A": [], "B": []}, order, codes)
            for order in (["A", "B"], ["B", "A"])
        }
        self.assertEqual(outcomes["AB"]["terminal_state"], outcomes["BA"]["terminal_state"])
        self.assertEqual(outcomes["AB"]["status"], outcomes["BA"]["status"])
        for state in outcomes.values():
            self.assertNotEqual(state["terminal_state"], "WORKFLOW_COMPLETE")

    def test_d1_all_success_still_completes(self):
        codes = {"A": "WORK_COMPLETE", "B": "WORK_COMPLETE"}
        for order in (["A", "B"], ["B", "A"]):
            state = run_workflow({"A": [], "B": []}, order, codes)
            self.assertEqual(state["terminal_state"], "WORKFLOW_COMPLETE")

    def test_d2_completed_segments_has_single_writer(self):
        state = run_workflow({"A": [], "B": []}, ["A", "B"], {"A": "FAIL", "B": "WORK_COMPLETE"})
        pairs = [(c["segment_id"], c["decision_code"]) for c in state["completed_segments"]]
        self.assertEqual(max(Counter(pairs).values()), 1, pairs)

    def test_d10_failed_dependency_does_not_strand_dependents(self):
        state = run_workflow({"A": [], "C": ["A"]}, ["A"], {"A": "FAIL"})
        self.assertEqual(state["queued_segments"], [])
        self.assertIsNotNone(state["terminal_state"])
        self.assertEqual(state["blocked_segments"][0]["segment_id"], "C")
        self.assertEqual(state["blocked_segments"][0]["blocked_by"], ["A"])

    def test_d10_transitive_dependents_are_blocked(self):
        state = run_workflow({"A": [], "B": ["A"], "C": ["B"]}, ["A"], {"A": "FAIL"})
        self.assertEqual(state["queued_segments"], [])
        self.assertEqual({b["segment_id"] for b in state["blocked_segments"]}, {"B", "C"})
        self.assertIsNotNone(state["terminal_state"])


class FailurePrecedencePolicyTests(unittest.TestCase):
    """嚴重度順序是 canonical policy（ADOPTED，非由既有規則推導），不是只存在交接檔。"""

    def _state(self, *codes):
        return {"completed_segments": [
            {"segment_id": f"S{i}", "decision_code": c} for i, c in enumerate(codes)
        ]}

    def test_default_policy_pins_the_adopted_order(self):
        from parallel_scheduler import load_policy
        self.assertEqual(load_policy()["failure_precedence"], ["FAIL", "TIMEOUT", "BLOCK", "UNRESOLVED"])

    def test_schema_declares_and_requires_the_policy_field(self):
        import json
        schema = json.loads((ROOT / "schemas" / "scheduler_policy.schema.json").read_text(encoding="utf-8"))
        self.assertIn("failure_precedence", schema["required"])
        self.assertIn("failure_precedence", schema["properties"])

    def test_aggregation_follows_default_order_for_every_pair(self):
        from parallel_scheduler import aggregate_decision, load_policy
        order = load_policy()["failure_precedence"]
        for i, hi in enumerate(order):
            for lo in order[i + 1:]:
                for seq in ((hi, lo), (lo, hi)):
                    expected = "FAIL" if hi == "TIMEOUT" else hi
                    self.assertEqual(aggregate_decision(self._state(*seq)), expected, seq)

    def test_changing_the_policy_changes_the_outcome(self):
        from parallel_scheduler import aggregate_decision
        flipped = {"failure_precedence": ["BLOCK", "FAIL", "TIMEOUT", "UNRESOLVED"]}
        self.assertEqual(aggregate_decision(self._state("FAIL", "BLOCK"), flipped), "BLOCK")
        self.assertEqual(aggregate_decision(self._state("FAIL", "BLOCK")), "FAIL")

    def test_invalid_precedence_is_rejected(self):
        from parallel_scheduler import load_policy
        with self.assertRaises(ValueError):
            load_policy({"failure_precedence": ["FAIL", "BLOCK"]})
        with self.assertRaises(ValueError):
            load_policy({"failure_precedence": ["FAIL", "FAIL", "BLOCK", "UNRESOLVED"]})

    def test_all_success_ignores_precedence(self):
        from parallel_scheduler import aggregate_decision
        self.assertEqual(aggregate_decision(self._state("WORK_COMPLETE", "WORK_COMPLETE")), "WORK_COMPLETE")


if __name__ == "__main__":
    unittest.main()
