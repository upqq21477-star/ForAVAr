#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import control_gate_runtime as gate  # noqa: E402


class LocalControlGateTests(unittest.TestCase):
    def test_return_code_classification(self):
        self.assertEqual(gate.classify_return(0, {0}), "PASS")
        self.assertEqual(gate.classify_return(2, {0, 2}), "PASS")
        self.assertEqual(gate.classify_return(1, {0}), "FAIL")

    def test_report_status_propagates_failure_over_incomplete(self):
        self.assertEqual(
            gate.report_status([
                {"status": "INCOMPLETE"},
                {"status": "FAIL"},
            ]),
            "FAIL",
        )

    def test_report_status_marks_incomplete_without_failure(self):
        self.assertEqual(
            gate.report_status([
                {"status": "PASS"},
                {"status": "INCOMPLETE"},
            ]),
            "INCOMPLETE",
        )

    def test_research_memory_box_close_gate_executes_real_close_path(self):
        box_id, decision_id = gate.run_research_memory_box_close_gate()
        self.assertTrue(box_id.startswith("RESEARCH_BOX:"))
        self.assertEqual(decision_id, "DECISION:M20-P5-CLOSE-GATE")

    def test_workflow_delegates_to_full_local_acceptance(self):
        workflow = (ROOT / ".github/workflows/p1-control-gate.yml").read_text(encoding="utf-8")
        self.assertIn("P1-Central-Control/scripts/local_acceptance.py", workflow)
        self.assertIn("p1-local-acceptance-record.json", workflow)
        self.assertRegex(workflow, r"actions/upload-artifact@[0-9a-f]{40}")
        self.assertNotIn("執行 M1 CHANGE_EVENT → IMPACT_SCAN", workflow)
        self.assertNotIn("執行 M4 REGRESSION_SELECTION", workflow)

    def test_registry_exists_and_contains_m9(self):
        registry = gate.load_json(ROOT / "P1-Central-Control/control_gate_registry.json")
        self.assertIn(
            "P1-Central-Control/tests/test_github_actions_result_adapter.py",
            registry["tests"],
        )
        self.assertIn(
            "P1-Central-Control/tests/test_regression_executor.py",
            registry["tests"],
        )


if __name__ == "__main__":
    unittest.main()
