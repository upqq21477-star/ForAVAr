import datetime as dt
import importlib.util
import pathlib
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]
MODULE_PATH = ROOT / "P1-Central-Control/scripts/external_tool_radar.py"

spec = importlib.util.spec_from_file_location("external_tool_radar", MODULE_PATH)
mod = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mod)


class ExternalToolRadarTests(unittest.TestCase):
    def test_popularity_prefers_active_popular_repository(self):
        weights = {"stars": 0.55, "activity": 0.30, "forks": 0.15}
        score = mod.popularity_score(10000, 1000, 7, weights)
        self.assertGreaterEqual(score, 90)

    def test_recentness_decays(self):
        self.assertGreater(mod.component_activity(10), mod.component_activity(200))
        self.assertEqual(mod.component_activity(400), 0.0)

    def test_classification_requires_both_popularity_and_activity(self):
        policy = {
            "min_stars": 500,
            "min_popularity_score": 55,
            "candidate_score_threshold": 70,
        }
        self.assertEqual(
            mod.classify(
                archived=False,
                stars=5000,
                score=80,
                freshness_days=20,
                policy=policy,
            ),
            "ADOPT_CANDIDATE",
        )
        self.assertEqual(
            mod.classify(
                archived=False,
                stars=5000,
                score=60,
                freshness_days=20,
                policy=policy,
            ),
            "WATCH",
        )

    def test_query_contains_native_github_search_qualifiers(self):
        query = mod.build_query("architecture test", dt.date(2026, 10, 4), 500)
        self.assertIn("in:name,description,readme", query)
        self.assertIn("stars:>=500", query)
        self.assertIn("pushed:>=2026-10-04", query)


if __name__ == "__main__":
    unittest.main()
