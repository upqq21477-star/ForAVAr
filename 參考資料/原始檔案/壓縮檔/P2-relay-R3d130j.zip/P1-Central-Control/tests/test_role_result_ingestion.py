#!/usr/bin/env python3
"""U-9a：角色結果映射（D4）＋正式 ingestion 入口。Verifier FAIL ≠ ResultPacket FAIL，不進 retry。"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import role_result  # noqa: E402
import test_repository_result_ingestion as base  # noqa: E402
from central_role_interface import ALLOWED_RESULT_STATUS  # noqa: E402
from repository_result_ingestion import ingest_role_result  # noqa: E402


DEFAULT_CAPABILITY = {"ROLE:EXECUTOR": "CAP-EVIDENCE", "ROLE:VERIFIER": "CAP-VERIFY", "ROLE:CONTROL_RESEARCH": "CAP-SYNTHESIS"}


def _role_result(role, status, *, reason=None, evidence=(), provenance=(), verdict_fields=False, capability=None):
    value = {
        "capability_id": capability or DEFAULT_CAPABILITY[role],
        "result_id": f"res-{role[5:]}-{status}".replace(":", "-"),
        "role_id": role,
        "result_status": status,
        "reason_code": reason,
        "output_refs": [],
        "unresolved": [],
        "evidence_refs": list(evidence),
        "provenance_refs": list(provenance),
        "observed_usage": {"model_calls": 1, "tool_calls": 0, "wall_time_ms": 1},
        "usage_observed": True,
    }
    if verdict_fields:
        value.update({"acceptance_ref": "ACCEPTANCE:A-1", "head_sha": "a" * 40})
    return value


class MappingTableTests(unittest.TestCase):
    def test_mapping_keys_equal_role_interface_vocabulary(self) -> None:
        table = role_result.load_mapping()["mapping"]
        self.assertEqual(set(table), set(ALLOWED_RESULT_STATUS))
        for role, allowed in ALLOWED_RESULT_STATUS.items():
            self.assertEqual(set(table[role]), allowed - {None}, role)  # 值可為 null（規劃輸出）

    def test_verifier_fail_never_maps_to_fail(self) -> None:
        table = role_result.load_mapping()["mapping"]
        self.assertEqual(table["ROLE:VERIFIER"]["FAIL"], "NEEDS_BRAIN")
        self.assertNotIn("FAIL", {d for row in table.values() for d in row.values()})

    def test_out_of_table_combination_rejected(self) -> None:
        with self.assertRaisesRegex(ValueError, "ROLE_RESULT_STATUS_NOT_ALLOWED"):
            role_result.decision_for("ROLE:CONTROL_RESEARCH", "PASS")
        with self.assertRaisesRegex(ValueError, "ROLE_RESULT_STATUS_NOT_ALLOWED"):
            role_result.decision_for("ROLE:EXECUTOR", "FAIL")

    def test_schema_requires_codes_and_verdict_fields(self) -> None:
        with self.assertRaises(ValueError):  # FAIL 必須有 reason_code
            role_result.validate_role_result(_role_result("ROLE:VERIFIER", "FAIL", verdict_fields=True))
        with self.assertRaises(ValueError):  # Verifier 判決必須有 acceptance_ref／head_sha
            role_result.validate_role_result(_role_result("ROLE:VERIFIER", "PASS"))
        with self.assertRaises(ValueError):  # reason_code 不得是自由文字
            role_result.validate_role_result(_role_result("ROLE:EXECUTOR", "BLOCK", reason="has spaces"))


class RoleResultIngestionTests(unittest.TestCase):
    def _prepare(self, root: Path, *, retry: bool):
        helper = base.RepositoryResultIngestionTests()
        if retry:
            orig = helper.make_segment
            helper.make_segment = lambda: {**orig(), "retry_policy": {"max_attempts": 3, "retry_on": ["FAIL"]}}
        state, task, result, _path, log_path, evidence, provenance = helper.prepare(root)
        envelopes = json.loads((root / "execution.json").read_text())
        return state, task, result, log_path, evidence, provenance, envelopes

    def test_verifier_fail_records_verdict_waits_for_brain_and_never_retries(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, task, _r, log_path, _e, _p, envelopes = self._prepare(Path(tmp), retry=True)
            rr = _role_result("ROLE:VERIFIER", "FAIL", reason="CHECK_FAILED", verdict_fields=True)
            out = ingest_role_result(
                role_result=rr, task_packet=task, current_state=state,
                execution_envelopes=envelopes, event_log_path=log_path,
            )
            packet = out["result_packet"]
            self.assertEqual(packet["decision_code"], "NEEDS_BRAIN")
            self.assertEqual(packet["status"], "UNRESOLVED")
            self.assertIn("CHECK_FAILED", packet["unresolved"])
            [verdict] = out["verifier_verdicts"]
            self.assertEqual(verdict["verdict"], "FAIL")
            self.assertEqual(verdict["decision_code"], "NEEDS_BRAIN")
            self.assertEqual(verdict["result_id"], packet["result_id"])
            self.assertNotIn(verdict["verdict_id"], packet["output_refs"])
            central = out["central_state"]
            self.assertEqual(central["status"], "WAITING")
            self.assertEqual(central.get("retry_count", 0), 0)
            self.assertEqual(out["next_task_packets"], [])
            self.assertNotIn("terminal_state", {k for k, v in central.items() if v})
            self.assertEqual(out["ingestion"]["role_mapping"], "policy/role_result_mapping.v1.0.json")

    def test_verifier_pass_completes_workflow_and_records_verdict(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, task, result, log_path, evidence, provenance, envelopes = self._prepare(Path(tmp), retry=False)
            rr = _role_result(
                "ROLE:VERIFIER", "PASS", verdict_fields=True,
                evidence=result["evidence_refs"], provenance=result["provenance_refs"],
            )
            rr["result_id"] = result["result_id"]  # Evidence claim_ref 綁定 result_id
            rr["output_refs"] = list(result["output_refs"])  # Execution Truth：WORK_COMPLETE 須綁定輸出
            out = ingest_role_result(
                role_result=rr, task_packet=task, current_state=state,
                execution_envelopes=envelopes, event_log_path=log_path,
                evidence_records=evidence, provenance_records=provenance,
            )
            self.assertEqual(out["result_packet"]["decision_code"], "WORK_COMPLETE")
            self.assertEqual(out["central_state"]["status"], "COMPLETED")
            self.assertEqual(out["central_state"]["terminal_state"], "WORKFLOW_COMPLETE")
            self.assertEqual(out["verifier_verdicts"][0]["verdict"], "PASS")

    def test_executor_block_has_no_verdict(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, task, _r, log_path, _e, _p, envelopes = self._prepare(Path(tmp), retry=False)
            out = ingest_role_result(
                role_result=_role_result("ROLE:EXECUTOR", "BLOCK", reason="DEPENDENCY_MISSING"),
                task_packet=task, current_state=state,
                execution_envelopes=envelopes, event_log_path=log_path,
            )
            self.assertEqual(out["verifier_verdicts"], [])
            self.assertEqual(out["central_state"]["status"], "BLOCKED")
            self.assertEqual(out["central_state"]["terminal_state"], "BLOCK")


class RuntimeCapabilityTests(unittest.TestCase):
    """U-8 執行期：結果入口以同一份綁定表檢查 role 的 capability（fail closed）。"""

    def test_unbound_capability_is_rejected_at_result_entry(self) -> None:
        task = {"workflow_id": "WF:x", "segment_id": "SEG:x", "attempt_id": "ATT:x"}
        for role, cap in (("ROLE:VERIFIER", "CAP-RETIRE"), ("ROLE:EXECUTOR", "CAP-VERIFY"),
                          ("ROLE:CONTROL_RESEARCH", "CAP-RETIRE")):
            with self.assertRaisesRegex(ValueError, f"CAPABILITY_NOT_BOUND:{role}:{cap}"):
                role_result.to_result_packet(task, _role_result(role, "BLOCK" if role != "ROLE:CONTROL_RESEARCH" else "BLOCKED",
                                                                reason="X_CODE", capability=cap))

    def test_capability_id_is_required_by_schema(self) -> None:
        value = _role_result("ROLE:EXECUTOR", "WORK_COMPLETE")
        del value["capability_id"]
        with self.assertRaises(ValueError):
            role_result.validate_role_result(value)

    def _record_root(self, tmp: str) -> Path:
        import lifecycle_sweep as ls

        root = Path(tmp) / "rec"
        for rel in (ls.POLICY_PATH, "P1-Central-Control/canonical/issue_register.json",
                    "P1-Central-Control/canonical/update_learning_ledger.json"):
            (root / rel).parent.mkdir(parents=True, exist_ok=True)
            (root / rel).write_text((ROOT / rel).read_text(encoding="utf-8"), encoding="utf-8")
        return root

    def _ingest(self, tmp: str, status: str, signature, record_root):
        helper = RoleResultIngestionTests()
        state, task, _r, log_path, _e, _p, envelopes = helper._prepare(Path(tmp), retry=False)
        value = _role_result("ROLE:EXECUTOR", status, reason="DEPENDENCY_MISSING" if status == "BLOCK" else None)
        value["issue_signature"] = signature
        return ingest_role_result(role_result=value, task_packet=task, current_state=state,
                                  execution_envelopes=envelopes, event_log_path=log_path, record_root=record_root)

    def test_failed_result_with_signature_is_recorded_through_ingest(self) -> None:
        import lifecycle_sweep as ls

        with tempfile.TemporaryDirectory() as tmp:
            root = self._record_root(tmp)
            out = self._ingest(tmp, "BLOCK", "executor:dependency_missing", root)
            reg = ls.load_register(root / "P1-Central-Control/canonical/issue_register.json")
            entry = [e for e in reg["entries"] if e["signature"] == "executor:dependency_missing"]
            self.assertEqual(len(entry), 1)
            self.assertEqual((entry[0]["class"], out["issue_recorded"]), ("TRANSIENT", entry[0]["issue_id"]))

    def test_no_record_without_root_or_without_signature_and_success_is_not_an_issue(self) -> None:
        import lifecycle_sweep as ls

        with tempfile.TemporaryDirectory() as tmp:
            root = self._record_root(tmp)
            path = root / "P1-Central-Control/canonical/issue_register.json"
            before = path.read_text(encoding="utf-8")
            self.assertNotIn("issue_recorded", self._ingest(tmp + "/a", "BLOCK", "executor:x", None))
            from repository_result_ingestion import ISSUE_STATUSES
            self.assertFalse({"WORK_COMPLETE", "PASS", "TASK_SET_ISSUED", "NO_ACTION_REQUIRED"} & ISSUE_STATUSES)
            self.assertNotIn("issue_recorded", self._ingest(tmp + "/c", "BLOCK", None, root))
            self.assertEqual(path.read_text(encoding="utf-8"), before)
            self.assertTrue(ls.load_register(path)["entries"])


if __name__ == "__main__":
    unittest.main()
