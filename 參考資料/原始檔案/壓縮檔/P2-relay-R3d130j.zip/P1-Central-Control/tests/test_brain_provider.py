"""R4 brain_provider：標準庫測試（不需 jsonschema、不連網）。模擬證據，非真實 API 運行。"""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import brain_provider as bp  # noqa: E402


class BrainProviderSimulation(unittest.TestCase):
    def test_every_group_passes(self):
        rep = bp.run_simulation()
        bad = [(g, c["case"], c["detail"]) for g, v in rep["groups"].items() for c in v if not c["pass"]]
        self.assertEqual(bad, [])

    def test_default_cost_gate_blocks(self):
        self.assertEqual(bp.CostGate().check(0.0)["decision"], "BLOCK")

    def test_guard_is_load_bearing(self):
        orig = bp.brain_guard.check_cycle
        bp.brain_guard.check_cycle = lambda c: {"status": "ACCEPT", "codes": []}
        try:
            self.assertFalse(bp.run_simulation("S7")["ok"])
        finally:
            bp.brain_guard.check_cycle = orig


if __name__ == "__main__":
    unittest.main()
