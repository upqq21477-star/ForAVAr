#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import research_memory_box_provenance as provenance


def sample_box():
    return {
        "box_id": "BOX-1",
        "objective_baseline": {
            "facts": [{"claim_id": "F1", "kind": "CONFIRMED", "claim": "fact", "source_refs": ["s1"]}],
            "constraints": [{"claim_id": "C1", "kind": "OBSERVED", "claim": "constraint", "source_refs": ["s2"]}],
            "capabilities": [{"claim_id": "K1", "kind": "CONFIRMED", "claim": "capability", "source_refs": ["s3"]}],
        },
        "external_evidence": [],
        "alternatives": [],
        "decision": None,
    }


class ResearchMemoryBoxProvenanceTests(unittest.TestCase):
    def test_every_claim_gets_source_provenance(self):
        result = provenance.validate(sample_box())
        self.assertEqual(result["status"], provenance.PASS)
        self.assertEqual(result["claim_count"], 3)
        self.assertEqual({item["claim_id"] for item in result["provenance"]}, {"F1", "C1", "K1"})

    def test_missing_claim_source_blocks(self):
        value = sample_box()
        value["objective_baseline"]["facts"][0].pop("source_refs")
        result = provenance.validate(value)
        self.assertEqual(result["status"], provenance.BLOCK)
        self.assertIn("SOURCE_REFS_MISSING", {item["code"] for item in result["errors"]})

    def test_duplicate_claim_id_blocks(self):
        value = sample_box()
        value["objective_baseline"]["constraints"][0]["claim_id"] = "F1"
        result = provenance.validate(value)
        self.assertEqual(result["status"], provenance.BLOCK)
        self.assertIn("CLAIM_ID_DUPLICATE", {item["code"] for item in result["errors"]})

    def test_decision_evidence_reference_must_resolve(self):
        value = sample_box()
        value["external_evidence"] = [{
            "evidence_id": "E1",
            "kind": "EVIDENCE",
            "claim": "evidence",
            "source_refs": ["s4"],
        }]
        value["alternatives"] = [{
            "option_id": "A1",
            "name": "A",
            "tradeoffs": "tradeoff",
            "source_refs": ["s4"],
        }]
        value["decision"] = {
            "decision_id": "D1",
            "evidence_refs": ["UNKNOWN-EVIDENCE"],
            "alternative_refs": ["A1"],
        }
        result = provenance.validate(value)
        self.assertEqual(result["status"], provenance.BLOCK)
        self.assertIn("DECISION_EVIDENCE_REF_UNKNOWN", {item["code"] for item in result["errors"]})

    def test_decision_alternative_reference_must_resolve(self):
        value = sample_box()
        value["alternatives"] = [{
            "option_id": "A1",
            "name": "A",
            "tradeoffs": "tradeoff",
            "source_refs": ["s4"],
        }]
        value["decision"] = {
            "decision_id": "D1",
            "evidence_refs": ["s5"],
            "alternative_refs": ["UNKNOWN"],
        }
        result = provenance.validate(value)
        self.assertEqual(result["status"], provenance.BLOCK)
        self.assertIn("DECISION_ALTERNATIVE_REF_UNKNOWN", {item["code"] for item in result["errors"]})


if __name__ == "__main__":
    unittest.main()
