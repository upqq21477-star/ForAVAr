#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import central_controller  # noqa: E402
from event_log import EventLog  # noqa: E402
from evidence_provenance_guard import guard_success  # noqa: E402
from execution_truth import build_execution_record, finalize_execution  # noqa: E402
from packet_layer import build_attempt, build_result_packet, build_task_packet  # noqa: E402


class EvidenceProvenanceGuardTests(unittest.TestCase):
    def make_segment(self) -> dict:
        return {
            "segment_id": "SEG-P7-001",
            "workflow_id": "WF-P7",
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "驗收 evidence provenance",
            "input_scope": "p7-test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "EXECUTION:exec-att-SEG-P7-001-1",
            "context_cohort_id": "COHORT-P7",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }

    def make_success_bundle(self):
        segment = self.make_segment()
        attempt = build_attempt(
            segment,
            attempt_number=1,
            started_at="2026-10-03T10:00:00+00:00",
        )
        task = build_task_packet(segment, attempt)
        result = build_result_packet(
            task,
            {
                "decision_code": "WORK_COMPLETE",
                "output_refs": ["ARTIFACT:result-001"],
                "evidence_refs": ["EVIDENCE:ev-001"],
                "provenance_refs": ["PROVENANCE:prov-001"],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 10,
                },
                "usage_observed": True,
            },
        )
        execution = build_execution_record(
            task,
            started_at=attempt["started_at"],
        )
        evidence = {
            "object_id": "EVIDENCE:ev-001",
            "kind": "EVIDENCE",
            "schema_version": "1.0",
            "content_hash": "sha256:" + "0" * 64,
            "source_ref": "ARTIFACT:input-001",
            "claim_ref": result["object_id"],
            "relation": "SUPPORTS",
            "captured_at": "2026-10-03T10:00:00+00:00",
        }
        provenance = {
            "object_id": "PROVENANCE:prov-001",
            "kind": "PROVENANCE",
            "schema_version": "1.0",
            "content_hash": "sha256:" + "0" * 64,
            "subject_ref": result["object_id"],
            "activity_ref": execution["execution_record_ref"],
            "agent_ref": "SKILL:schema-builder-1.0.0",
            "input_refs": ["ARTIFACT:input-001"],
            "output_refs": ["ARTIFACT:result-001"],
            "relation": "WAS_GENERATED_BY",
        }
        return segment, attempt, task, result, execution, [evidence], [provenance]

    def test_valid_structured_evidence_and_provenance_pass(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        finalized = finalize_execution(
            execution,
            task,
            result,
            ended_at="2026-10-03T10:00:00.010000+00:00",
            evidence_records=evidence,
            provenance_records=provenance,
        )
        report = guard_success(
            task_packet=task,
            result_packet=result,
            execution_record=finalized,
            evidence_records=evidence,
            provenance_records=provenance,
        )
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["evidence_count"], 1)
        self.assertEqual(report["provenance_count"], 1)

    def test_missing_evidence_ref_is_rejected(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=execution,
                evidence_records=[],
                provenance_records=provenance,
            )

    def test_wrong_evidence_claim_is_rejected(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        evidence[0]["claim_ref"] = "RESULT_PACKET:other-result"
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=execution,
                evidence_records=evidence,
                provenance_records=provenance,
            )

    def test_external_evidence_requires_locator(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        finalized = finalize_execution(
            execution,
            task,
            result,
            ended_at="2026-10-03T10:00:00.010000+00:00",
            evidence_records=evidence,
            provenance_records=provenance,
        )
        evidence[0]["source_ref"] = "ARTIFACT:external-source"
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=finalized,
                evidence_records=evidence,
                provenance_records=provenance,
            )
        evidence[0]["locator"] = "https://example.invalid/source"
        report = guard_success(
            task_packet=task,
            result_packet=result,
            execution_record=finalized,
            evidence_records=evidence,
            provenance_records=provenance,
        )
        self.assertEqual(report["status"], "PASS")

    def test_late_evidence_is_rejected(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        evidence[0]["captured_at"] = "2026-10-03T10:00:00.020000+00:00"
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=execution,
                evidence_records=evidence,
                provenance_records=provenance,
            )

    def test_wrong_provenance_activity_is_rejected(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        provenance[0]["activity_ref"] = "EXECUTION:exec-other"
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=execution,
                evidence_records=evidence,
                provenance_records=provenance,
            )

    def test_provenance_input_output_completeness_is_enforced(self):
        _, _, task, result, execution, evidence, provenance = self.make_success_bundle()
        provenance[0]["input_refs"] = []
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=execution,
                evidence_records=evidence,
                provenance_records=provenance,
            )
        provenance[0]["input_refs"] = list(task["input_refs"])
        provenance[0]["output_refs"] = []
        with self.assertRaises(ValueError):
            guard_success(
                task_packet=task,
                result_packet=result,
                execution_record=execution,
                evidence_records=evidence,
                provenance_records=provenance,
            )

    def test_central_success_requires_structured_evidence_provenance(self):
        segment = self.make_segment()
        state = central_controller.init_state("WF-P7", "TASK-P7")
        state = central_controller.queue_segment(state, segment)
        store = {}
        distillation_store = {}

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=store,
            )
            result = self.make_success_bundle()[3]
            result["execution_record_ref"] = packets[0]["execution_record_ref"]
            with self.assertRaises(ValueError):
                central_controller.receive_result(
                    state,
                    result,
                    event_log=log,
                    execution_store=store,
                    distillation_store=distillation_store,
                    evidence_records=[],
                    provenance_records=[],
                )

    def test_central_success_accepts_structured_records(self):
        segment = self.make_segment()
        state = central_controller.init_state("WF-P7", "TASK-P7")
        state = central_controller.queue_segment(state, segment)
        store = {}
        distillation_store = {}

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=store,
            )
            task = store[packets[0]["execution_record_ref"]]["task_packet"]
            attempt = store[packets[0]["execution_record_ref"]]["attempt"]
            result = build_result_packet(
                task,
                {
                    "decision_code": "WORK_COMPLETE",
                    "output_refs": ["ARTIFACT:result-001"],
                    "evidence_refs": ["EVIDENCE:ev-001"],
                    "provenance_refs": ["PROVENANCE:prov-001"],
                    "observed_usage": {
                        "model_calls": 1,
                        "tool_calls": 1,
                        "wall_time_ms": 10,
                    },
                    "usage_observed": True,
                },
            )
            evidence = [{
                "object_id": "EVIDENCE:ev-001",
                "kind": "EVIDENCE",
                "schema_version": "1.0",
                "content_hash": "sha256:" + "0" * 64,
                "source_ref": "ARTIFACT:input-001",
                "claim_ref": result["object_id"],
                "relation": "SUPPORTS",
                "captured_at": attempt["started_at"],
            }]
            provenance = [{
                "object_id": "PROVENANCE:prov-001",
                "kind": "PROVENANCE",
                "schema_version": "1.0",
                "content_hash": "sha256:" + "0" * 64,
                "subject_ref": result["object_id"],
                "activity_ref": task["execution_record_ref"],
                "agent_ref": "SKILL:schema-builder-1.0.0",
                "input_refs": ["ARTIFACT:input-001"],
                "output_refs": ["ARTIFACT:result-001"],
                "relation": "WAS_GENERATED_BY",
            }]
            final_state = central_controller.receive_result(
                state,
                result,
                event_log=log,
                execution_store=store,
                distillation_store=distillation_store,
                evidence_records=evidence,
                provenance_records=provenance,
            )

        self.assertEqual(final_state["status"], "COMPLETED")


if __name__ == "__main__":
    unittest.main()
