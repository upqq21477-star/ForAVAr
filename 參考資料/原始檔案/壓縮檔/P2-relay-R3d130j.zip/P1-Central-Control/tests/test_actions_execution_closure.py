#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import actions_execution_closure as closure


class ActionsExecutionClosureTests(unittest.TestCase):
    def diagnostic(self, classification):
        return {
            "diagnostic_id": "ACTIONS_DIAGNOSTIC:123",
            "classification": classification,
            "head_sha": "abc1234567890",
        }

    def acceptance(self, status):
        return {
            "acceptance_id": "LOCAL_ACCEPTANCE:abc1234567890",
            "head_sha": "abc1234567890",
            "status": status,
        }

    def test_runner_failure_plus_local_pass_remains_unresolved(self):
        result = closure.close(
            self.diagnostic("RUNNER_STARTUP_FAILURE"),
            self.acceptance("PASS"),
        )
        self.assertEqual(result["closure_status"], "INCOMPLETE")
        self.assertEqual(result["program_truth"], "PROGRAM_UNRESOLVED")

    def test_local_fail_is_program_regression(self):
        result = closure.close(
            self.diagnostic("RUNNER_STARTUP_FAILURE"),
            self.acceptance("FAIL"),
        )
        self.assertEqual(result["closure_status"], "PROGRAM_REGRESSION_FAIL")

    def test_no_local_acceptance_remains_incomplete(self):
        result = closure.close(self.diagnostic("RUNNER_STARTUP_FAILURE"))
        self.assertEqual(result["closure_status"], "INCOMPLETE")
        self.assertEqual(result["program_truth"], "PROGRAM_UNRESOLVED")

    def test_head_mismatch_is_conflict(self):
        acceptance = self.acceptance("PASS")
        acceptance["head_sha"] = "different123456"
        result = closure.close(self.diagnostic("RUNNER_STARTUP_FAILURE"), acceptance)
        self.assertEqual(result["closure_status"], "CONFLICT")

    def test_unknown_is_blocked_without_local_evidence(self):
        result = closure.close(self.diagnostic("UNKNOWN"))
        self.assertEqual(result["closure_status"], "INCOMPLETE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
