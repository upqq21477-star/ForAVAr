#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(TESTS_DIR))

import central_controller  # noqa: E402
from event_log import EventLog  # noqa: E402
from packet_layer import build_result_packet  # noqa: E402
from p7_test_records import records_for  # noqa: E402
from parallel_scheduler import (  # noqa: E402
    accept_result,
    cancel_segment,
    load_policy,
    start_available,
    timeout_due,
)


class ParallelSchedulerTests(unittest.TestCase):
    def make_segment(
        self,
        segment_id: str,
        *,
        dependencies: list[str] | None = None,
        max_attempts: int = 1,
        retry_on: list[str] | None = None,
        timeout_ms: int = 1000,
    ) -> dict:
        return {
            "segment_id": segment_id,
            "workflow_id": "WF-P5",
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": f"完成 {segment_id}",
            "input_scope": "p5-test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [f"SEGMENT:{x}" for x in (dependencies or [])],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": f"ARTIFACT:execution-{segment_id}",
            "context_cohort_id": "COHORT-P5",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {
                "max_attempts": max_attempts,
                "retry_on": retry_on or [],
            },
            "timeout_ms": timeout_ms,
        }

    def make_result(self, task_packet: dict, decision_code: str) -> dict:
        return build_result_packet(
            task_packet,
            {
                "decision_code": decision_code,
                "output_refs": ["ARTIFACT:result-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "unresolved": ["unresolved"]
                if decision_code == "UNRESOLVED"
                else [],
                "evidence_refs": ["EVIDENCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "provenance_refs": ["PROVENANCE:test-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 1,
                },
                "usage_observed": True,
            },
        )

    def make_state(self, segments: list[dict]) -> dict:
        return {
            "workflow_id": "WF-P5",
            "status": "READY",
            "state_revision": 0,
            "queued_segments": segments,
            "active_segments": [],
            "attempt_counters": {},
            "scheduler_max_concurrency": 2,
            "completed_segments": [],
            "retry_count": 0,
            "timeout_count": 0,
            "late_result_count": 0,
            "cancel_count": 0,
            "result_refs": [],
            "evidence_refs": [],
            "provenance_refs": [],
            "unresolved": [],
        }

    def test_scheduler_policy_schema_is_strict_and_bounded(self):
        schema = json.loads(
            (SCHEMA_DIR / "scheduler_policy.schema.json").read_text(
                encoding="utf-8"
            )
        )
        Draft202012Validator.check_schema(schema)
        self.assertLessEqual(
            (SCHEMA_DIR / "scheduler_policy.schema.json").stat().st_size,
            8192,
        )
        load_policy()

    def test_two_independent_segments_run_in_parallel_up_to_limit(self):
        segments = [
            self.make_segment("A"),
            self.make_segment("B"),
            self.make_segment("C"),
        ]
        state, packets = start_available(
            self.make_state(segments),
            max_concurrency=2,
            now="2026-10-03T10:00:00+00:00",
        )

        self.assertEqual(len(packets), 2)
        self.assertEqual(
            [x["segment_id"] for x in state["active_segments"]],
            ["A", "B"],
        )
        self.assertEqual(
            [x["segment_id"] for x in state["queued_segments"]],
            ["C"],
        )
        self.assertEqual(
            [p["segment_id"] for p in packets],
            ["A", "B"],
        )

    def test_dependency_join_waits_until_all_dependencies_complete(self):
        segments = [
            self.make_segment("A"),
            self.make_segment("B"),
            self.make_segment("C", dependencies=["A", "B"]),
        ]
        state, packets = start_available(
            self.make_state(segments),
            max_concurrency=3,
            now="2026-10-03T10:00:00+00:00",
        )

        self.assertEqual({p["segment_id"] for p in packets}, {"A", "B"})
        state["active_segments"] = []
        state["queued_segments"] = [
            self.make_segment("C", dependencies=["A", "B"])
        ]
        state["completed_segments"] = [
            {"segment_id": "A", "status": "VALID"},
        ]
        state, packets = start_available(state, max_concurrency=3)

        self.assertEqual(packets, [])
        state["completed_segments"].append(
            {"segment_id": "B", "status": "VALID"}
        )
        state, packets = start_available(state, max_concurrency=3)
        self.assertEqual([p["segment_id"] for p in packets], ["C"])

    def test_retry_precondition_failure_does_not_partially_commit_stores(self):
        segment = self.make_segment("A", max_attempts=2, retry_on=["FAIL"])
        with tempfile.TemporaryDirectory() as tmp:
            log = EventLog(Path(tmp) / "events.jsonl")
            execution_store = {}
            distillation_store = {}
            state = central_controller.init_state("WF-P5", "TASK")
            state = central_controller.queue_segment(state, segment, event_log=log)
            state, packets = central_controller.dispatch(
                state, event_log=log, execution_store=execution_store, max_concurrency=1
            )
            result = self.make_result(packets[0], "FAIL")
            before_execution = json.dumps(execution_store, sort_keys=True)
            before_distillation = json.dumps(distillation_store, sort_keys=True)
            with self.assertRaisesRegex(ValueError, "Retry"):
                central_controller.receive_result_and_schedule(
                    state, result, event_log=log, segment_store=None,
                    execution_store=execution_store, distillation_store=distillation_store
                )
            self.assertEqual(json.dumps(execution_store, sort_keys=True), before_execution)
            self.assertEqual(json.dumps(distillation_store, sort_keys=True), before_distillation)

    def test_dispatch_persists_attempt_limit_block_to_event_log(self):
        segment = self.make_segment("A", max_attempts=1)
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "events.jsonl"
            log = EventLog(path)
            state = central_controller.init_state("WF-P5", "TASK")
            state = central_controller.queue_segment(state, segment, event_log=log)
            before_counter_change = state
            state = {**state, "attempt_counters": {"A": 1}}
            central_controller._log_segments(
                log, before_counter_change, state, "SEGMENT_STARTED", "TEST:RESTORED_COUNTER"
            )
            blocked_state, packets = central_controller.dispatch(
                state, event_log=log, execution_store={}, max_concurrency=1
            )
            self.assertEqual(packets, [])
            self.assertEqual(blocked_state["queued_segments"], [])
            self.assertEqual(blocked_state["completed_segments"][0]["reason_code"], "ATTEMPT_LIMIT_EXCEEDED")
            events = EventLog(path).read_all("SEGMENT")
            self.assertEqual(events[-1]["event_type"], "SEGMENT_ATTEMPT_LIMIT_BLOCKED")

    def test_queued_segment_over_attempt_limit_is_blocked_not_requeued(self):
        segment = self.make_segment("A", max_attempts=1, retry_on=["FAIL"])
        state = self.make_state([segment])
        state["attempt_counters"] = {"A": 1}
        next_state, packets = start_available(state, max_concurrency=1)
        self.assertEqual(packets, [])
        self.assertEqual(next_state["queued_segments"], [])
        self.assertEqual(next_state["completed_segments"][0]["status"], "BLOCKED")
        self.assertEqual(next_state["completed_segments"][0]["reason_code"], "ATTEMPT_LIMIT_EXCEEDED")

    def test_attempt_number_increments_for_retry(self):
        segment = self.make_segment(
            "A",
            max_attempts=2,
            retry_on=["FAIL"],
        )
        store = {"A": segment}
        state, packets = start_available(
            self.make_state([segment]),
            max_concurrency=1,
            now="2026-10-03T10:00:00+00:00",
        )
        result = self.make_result(packets[0], "FAIL")

        state, outcome = accept_result(
            state,
            result,
            segment_store=store,
        )
        self.assertEqual(outcome, "RETRY_PENDING")
        self.assertEqual(state["retry_count"], 1)
        self.assertEqual(
            [x["segment_id"] for x in state["queued_segments"]],
            ["A"],
        )

        state, retry_packets = start_available(
            state,
            max_concurrency=1,
            now="2026-10-03T10:00:01+00:00",
        )
        self.assertEqual(
            retry_packets[0]["attempt_id"],
            "att-A-2",
        )
        self.assertEqual(retry_packets[0]["attempt_id"], state["active_segments"][0]["attempt_id"])

    def test_timeout_requeues_when_retry_budget_remains(self):
        segment = self.make_segment(
            "A",
            max_attempts=2,
            retry_on=["TIMEOUT"],
            timeout_ms=1,
        )
        store = {"A": segment}
        state, packets = start_available(
            self.make_state([segment]),
            max_concurrency=1,
            now="2026-10-03T10:00:00+00:00",
        )
        state, timed_out = timeout_due(
            state,
            segment_store=store,
            now="2026-10-03T10:00:00.002000+00:00",
        )

        self.assertEqual(len(timed_out), 1)
        self.assertEqual(state["timeout_count"], 1)
        self.assertEqual(state["retry_count"], 1)
        self.assertEqual(len(state["queued_segments"]), 1)

    def test_timeout_becomes_terminal_when_retry_budget_exhausted(self):
        segment = self.make_segment("A", max_attempts=1, retry_on=["TIMEOUT"], timeout_ms=1)
        state, _ = start_available(
            self.make_state([segment]),
            max_concurrency=1,
            now="2026-10-03T10:00:00+00:00",
        )
        state, timed_out = timeout_due(
            state,
            now="2026-10-03T10:00:00.002000+00:00",
        )

        self.assertEqual(len(timed_out), 1)
        self.assertEqual(state["active_segments"], [])
        self.assertEqual(state["completed_segments"][0]["status"], "TIMEOUT")

    def test_late_result_is_recorded_and_does_not_mutate_active_work(self):
        segment = self.make_segment("A")
        state, packets = start_available(
            self.make_state([segment]),
            max_concurrency=1,
        )
        late = self.make_result(packets[0], "WORK_COMPLETE")
        state, outcome = accept_result(state, late)

        self.assertEqual(outcome, "COMPLETED")
        self.assertEqual(state["active_segments"], [])

        state, outcome = accept_result(state, late)
        self.assertEqual(outcome, "LATE_RESULT")
        self.assertEqual(state["late_result_count"], 1)

    def test_cancel_removes_queued_or_active_segment(self):
        a = self.make_segment("A")
        b = self.make_segment("B")
        state, _ = start_available(
            self.make_state([a, b]),
            max_concurrency=1,
        )

        state, outcome = cancel_segment(state, "A")
        self.assertEqual(outcome, "CANCELLED")
        self.assertEqual(state["active_segments"], [])
        self.assertEqual(state["cancel_count"], 1)

        state, _ = cancel_segment(state, "B")
        self.assertEqual(state["queued_segments"], [])

    def test_result_packet_attempt_must_match_active_attempt(self):
        a = self.make_segment("A")
        state, packets = start_available(
            self.make_state([a]),
            max_concurrency=1,
        )
        result = self.make_result(packets[0], "WORK_COMPLETE")
        result["attempt_id"] = "att-A-999"
        with self.assertRaises(ValueError):
            accept_result(state, result)

    def test_central_dispatch_creates_parallel_task_packets(self):
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-P5", "TASK-P5")
        segments = [
            self.make_segment("A"),
            self.make_segment("B"),
            self.make_segment("C"),
        ]
        for segment in segments:
            state = central_controller.queue_segment(state, segment)

        with tempfile.TemporaryDirectory() as temp:
            state, packets = central_controller.dispatch(
                state,
                event_log=EventLog(Path(temp) / "events.jsonl"),
                execution_store=execution_store,
                max_concurrency=2,
            )

        self.assertEqual(state["status"], "RUNNING")
        self.assertEqual(len(state["active_segments"]), 2)
        self.assertEqual(len(packets), 2)
        self.assertEqual(
            {p["segment_id"] for p in packets},
            {"A", "B"},
        )

    def test_central_result_completes_workflow_only_after_all_parallel_work_finishes(self):
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-P5", "TASK-P5")
        a = self.make_segment("A")
        b = self.make_segment("B")
        store = {a["segment_id"]: a, b["segment_id"]: b}
        state = central_controller.queue_segment(state, a)
        state = central_controller.queue_segment(state, b)

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
                max_concurrency=2,
            )
            result_1 = self.make_result(packets[0], "WORK_COMPLETE")
            envelope_1 = execution_store[result_1["execution_record_ref"]]
            evidence_1, provenance_1 = records_for(
                envelope_1["task_packet"], result_1, envelope_1["execution_record"]
            )
            state = central_controller.receive_result(
                state,
                result_1,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                segment_store=store,
                evidence_records=evidence_1,
                provenance_records=provenance_1,
            )
            self.assertEqual(state["status"], "RUNNING")
            self.assertEqual(len(state["active_segments"]), 1)

            result_2 = self.make_result(packets[1], "WORK_COMPLETE")
            envelope_2 = execution_store[result_2["execution_record_ref"]]
            evidence_2, provenance_2 = records_for(
                envelope_2["task_packet"], result_2, envelope_2["execution_record"]
            )
            state = central_controller.receive_result(
                state,
                result_2,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                segment_store=store,
                evidence_records=evidence_2,
                provenance_records=provenance_2,
            )

        self.assertEqual(state["status"], "COMPLETED")
        self.assertEqual(state["active_segments"], [])

    def test_scheduler_runtime_schema_accepts_runtime_projection(self):
        schema = json.loads(
            (SCHEMA_DIR / "scheduler_runtime.schema.json").read_text(
                encoding="utf-8"
            )
        )
        Draft202012Validator.check_schema(schema)
        validator = Draft202012Validator(
            schema,
            format_checker=FormatChecker(),
        )
        state, _ = start_available(
            self.make_state([self.make_segment("A")]),
            max_concurrency=1,
            now="2026-10-03T10:00:00+00:00",
        )
        errors = list(
            validator.iter_errors(
                {
                    "active_segments": state["active_segments"],
                    "attempt_counters": state["attempt_counters"],
                    "scheduler_max_concurrency": state["scheduler_max_concurrency"],
                    "retry_count": state["retry_count"],
                    "timeout_count": state["timeout_count"],
                    "late_result_count": state["late_result_count"],
                    "cancel_count": state["cancel_count"],
                }
            )
        )
        self.assertEqual(errors, [])


if __name__ == "__main__":
    unittest.main()
