#!/usr/bin/env python3
"""XM1: executor_mode policy, batch_gate `executor` evidence checks, tools/task_card.py (negatives and mutations)."""
from __future__ import annotations

import contextlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))

import batch_gate as bg  # noqa: E402
import task_card as tc  # noqa: E402

POL = {"mode": "CHAT", "allowed": ["CHAT", "ACTIONS", "CODEX"], "baseline": "CHAT"}


def _quiet(fn, *a):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a)


class PolicyTests(unittest.TestCase):
    def test_real_policy_is_valid_and_baseline_is_chat(self):
        pol = json.loads((ROOT / bg.EXEC_POLICY).read_text(encoding="utf-8"))
        self.assertEqual(pol["baseline"], "CHAT")
        self.assertEqual(pol["mode"], "CHAT")
        self.assertEqual(sorted(pol["allowed"]), ["ACTIONS", "CHAT", "CODEX"])
        self.assertEqual(bg.executor_policy_findings(bg.RealFS(ROOT)), [])

    def test_bad_policies_are_rejected(self):
        for name, pol in {"baseline_codex": {**POL, "baseline": "CODEX"}, "mode_unknown": {**POL, "mode": "GPT"},
                          "chat_not_allowed": {**POL, "allowed": ["ACTIONS", "CODEX"]}, "duplicates": {**POL, "allowed": ["CHAT", "CHAT"]}}.items():
            with self.subTest(name):
                self.assertTrue(bg.executor_policy_findings(bg.FakeFS({bg.EXEC_POLICY: pol})))

    def test_missing_policy_is_flagged(self):
        self.assertEqual(bg.executor_policy_findings(bg.FakeFS({}))[0]["rule"], "X0")


class BatchGateExecutorTests(unittest.TestCase):
    fs = bg.FakeFS({bg.EXEC_POLICY: POL})
    task = {"task_id": "T"}

    def test_legacy_and_allowed_executors_pass(self):
        for rec in ({}, {"executor": "CHAT"}, {"executor": "ACTIONS"}, {"executor": "CODEX"}):
            self.assertEqual(bg.executor_findings(rec, self.task, self.fs), [], rec)

    def test_unknown_executor_and_non_baseline_requirement_fail(self):
        self.assertEqual(bg.executor_findings({"executor": "GPT"}, self.task, self.fs)[0]["rule"], "X1")
        self.assertEqual(bg.executor_findings({}, {**self.task, "requires_executor": "CODEX"}, self.fs)[0]["rule"], "X2")
        self.assertEqual(bg.executor_findings({}, {**self.task, "requires_executor": "CHAT"}, self.fs), [])

    def test_without_policy_nothing_is_checked(self):
        self.assertEqual(bg.executor_findings({"executor": "GPT"}, self.task, bg.FakeFS({})), [])

    def test_record_writes_executor_and_refuses_unknown(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / bg.EXEC_POLICY).parent.mkdir(parents=True)
            (root / bg.EXEC_POLICY).write_text(json.dumps(POL), encoding="utf-8")
            (root / "e.py").write_text("print(1)\n", encoding="utf-8")
            self.assertEqual(_quiet(bg.record, root, "T1", "e.py", "true"), 0)
            rec = json.loads((root / bg.EVIDENCE / "T1.json").read_text(encoding="utf-8"))
            self.assertEqual(rec["executor"], "CHAT")
            self.assertEqual(_quiet(bg.record, root, "T2", "e.py", "true", "ACTIONS"), 0)
            self.assertEqual(json.loads((root / bg.EVIDENCE / "T2.json").read_text(encoding="utf-8"))["executor"], "ACTIONS")
            self.assertEqual(_quiet(bg.record, root, "T3", "e.py", "true", "GPT"), 2)
            self.assertFalse((root / bg.EVIDENCE / "T3.json").exists())

    def test_every_recorded_real_evidence_executor_is_allowed(self):
        allowed = json.loads((ROOT / bg.EXEC_POLICY).read_text(encoding="utf-8"))["allowed"]
        for p in (ROOT / bg.EVIDENCE).glob("*.json"):
            self.assertIn(json.loads(p.read_text(encoding="utf-8")).get("executor", "CHAT"), allowed, p.name)

    def test_mutation_executor_check_always_pass_turns_selftest_red(self):
        self.assertEqual(_quiet(bg.selftest), 0)
        with mock.patch.object(bg, "executor_findings", lambda rec, t, fs: []):
            self.assertEqual(_quiet(bg.selftest), 1)

    def test_mutation_policy_check_always_pass_turns_selftest_red(self):
        with mock.patch.object(bg, "executor_policy_findings", lambda fs: []):
            self.assertEqual(_quiet(bg.selftest), 1)


class TaskCardTests(unittest.TestCase):
    def test_selftest_passes_and_real_checker_has_no_wrong_verdicts(self):
        self.assertEqual(_quiet(tc.main, ["x", "--selftest"]), 0)
        self.assertEqual(tc.run_negatives(), [])

    def test_each_bad_card_gets_a_specific_code(self):
        expect = {"overlap": "OVERLAP:", "requires_codex": "REQUIRES_NON_BASELINE_EXECUTOR", "unknown_executor": "EXECUTOR_NOT_ALLOWED",
                  "vendor_key": "EXTRA_KEY:agents_md", "evidence_outside": "BAD_EVIDENCE_PATH", "blocker_no_tried": "BLOCKER_TRIED_REQUIRED",
                  "blocker_unlabeled_guess": "BLOCKER_HYPOTHESIS_UNLABELED", "dotdot_path": "BAD_PATH:files_to_change"}
        bad = tc._bad_cards()
        for name, code in expect.items():
            with self.subTest(name):
                self.assertTrue(any(e.startswith(code) for e in tc.check_card(bad[name])), tc.check_card(bad[name]))

    def test_status_ok_blocked_invalid(self):
        self.assertEqual(tc.status_of(tc.GOOD), ("OK", []))
        blocked = {**tc.GOOD, "blocker": {"phenomenon": "tests fail", "tried": ["rerun"], "hypothesis": "HYPOTHESIS: env"}}
        self.assertEqual(tc.status_of(blocked)[0], "BLOCKED_TO_CHAT")
        self.assertEqual(tc.status_of({"task_id": "x"})[0], "INVALID")

    def test_cli_check_exit_codes(self):
        with tempfile.TemporaryDirectory() as tmp:
            def run(card):
                p = Path(tmp) / "c.json"
                p.write_text(json.dumps(card), encoding="utf-8")
                return _quiet(tc.main, ["x", "--check", str(p)])
            self.assertEqual(run(tc.GOOD), 0)
            self.assertEqual(run({**tc.GOOD, "blocker": {"phenomenon": "p", "tried": ["a"]}}), 3)
            self.assertEqual(run({**tc.GOOD, "files_to_change": []}), 1)
        self.assertEqual(_quiet(tc.main, ["x"]), 2)

    def test_mutation_always_permit_checker_is_caught(self):
        self.assertTrue(tc.run_negatives(lambda card, pol: []))
        with mock.patch.object(tc, "check_card", lambda card, policy=None: []):
            self.assertEqual(_quiet(tc.main, ["x", "--selftest"]), 1)

    def test_mutation_always_reject_checker_is_caught(self):
        self.assertTrue(any(n.startswith("good_") for n in tc.run_negatives(lambda card, pol: ["X"])))

    def test_mutation_overlap_rule_removed_is_caught(self):
        real = tc.check_card

        def no_overlap(card, policy=None):
            return [e for e in real(card, policy) if not e.startswith("OVERLAP:")]
        self.assertIn("overlap", tc.run_negatives(no_overlap))

    def test_mutation_baseline_rule_removed_is_caught(self):
        real = tc.check_card

        def lax(card, policy=None):
            return [e for e in real(card, policy) if e != "REQUIRES_NON_BASELINE_EXECUTOR"]
        self.assertIn("requires_codex", tc.run_negatives(lax))


if __name__ == "__main__":
    unittest.main()
