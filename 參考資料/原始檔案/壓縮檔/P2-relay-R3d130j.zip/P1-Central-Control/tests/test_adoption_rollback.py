#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

import adoption_rollback as m5  # noqa: E402


class AdoptionRollbackTests(unittest.TestCase):
    def selection(self, status="PASS"):
        value = {
            "object_id":"REGRESSION_SELECTION:M4-TEST",
            "kind":"REGRESSION_SELECTION",
            "schema_version":"1.0",
            "content_hash":"sha256:" + "0"*64,
            "selection_id":"M4-TEST",
            "source_routing_reevaluation_id":"M3-TEST",
            "source_impact_scan_id":"IMPACT:M4",
            "source_routing_status":"PASS",
            "required_regression_sets":["routing","e2e"],
            "selected_regression_sets":["e2e","routing"],
            "selections":[{
                "capability_id":"CAP-EXTRACT",
                "evaluation_ref":"NATIVE_REPLACEMENT_EVAL:EVAL-1",
                "route_mode":"MODEL_ONLY",
                "decision_code":"CANDIDATE_READY",
                "regression_sets":["e2e","routing"]
            }],
            "pending":[],
            "status":status
        }
        value["content_hash"] = m5.content_hash(value)
        return value

    def regression(self, statuses):
        value={
            "result_id":"REGRESULT:M5-TEST",
            "selection_id":"M4-TEST",
            "status":"PASS" if all(v=="PASS" for v in statuses.values()) else "FAIL",
            "results":[{"regression_set_id":k,"status":v} for k,v in statuses.items()]
        }
        return value

    def route_state(self):
        return {
            "route_state_id":"ROUTE-STATE:TEST",
            "routes":[{
                "capability_id":"CAP-EXTRACT",
                "current_mode":"MODEL_PLUS_GUARD",
                "rollback_mode":"MODEL_PLUS_GUARD"
            }]
        }

    def test_all_regressions_pass_ready_for_adoption(self):
        report=m5.decide(self.selection(),self.regression({"routing":"PASS","e2e":"PASS"}),self.route_state(),decision_id="M5-001")
        self.assertEqual(report["status"],"PASS")
        self.assertEqual(report["decisions"][0]["action"],"ADOPT")
        self.assertEqual(report["decisions"][0]["status"],"READY")
        m5.validate(m5.SCHEMA_PATH,report)

    def test_any_failed_regression_ready_for_rollback(self):
        report=m5.decide(self.selection(),self.regression({"routing":"FAIL","e2e":"PASS"}),self.route_state(),decision_id="M5-002")
        self.assertEqual(report["status"],"PASS")
        decision=report["decisions"][0]
        self.assertEqual(decision["action"],"ROLLBACK")
        self.assertEqual(decision["rollback_mode"],"MODEL_PLUS_GUARD")

    def test_missing_regression_result_defers(self):
        report=m5.decide(self.selection(),self.regression({"routing":"PASS"}),self.route_state(),decision_id="M5-003")
        self.assertEqual(report["status"],"INSUFFICIENT_DATA")
        self.assertEqual(report["decisions"][0]["action"],"DEFER")

    def test_missing_explicit_route_state_blocks(self):
        state=self.route_state()
        state["routes"]=[]
        report=m5.decide(
            self.selection(),
            self.regression({"routing":"PASS","e2e":"PASS"}),
            state,
            decision_id="M5-004",
        )
        self.assertEqual(report["status"],"BLOCK")
        self.assertEqual(report["decisions"][0]["action"],"BLOCK")

    def test_blocked_selection_is_rejected(self):
        selection=self.selection()
        selection["status"]="BLOCK"
        selection["content_hash"]=m5.content_hash(selection)
        with self.assertRaises(ValueError):
            m5.decide(selection,self.regression({"routing":"PASS","e2e":"PASS"}),self.route_state())

    def test_raw_unknown_fields_are_rejected(self):
        result=self.regression({"routing":"PASS","e2e":"PASS"})
        result["raw_trace"]={"anything":True}
        with self.assertRaises(ValueError):
            m5.decide(self.selection(),result,self.route_state(),decision_id="M5-005")


if __name__=="__main__":
    unittest.main()
