"""Method-level quarantine marker (M32).

A quarantined test is reported as *skipped* with an explicit reason, never as PASS.
Classes are markers only (no manifest; the lifecycle sweep replaced the manifest cross-check).

Classes:
  LEGACY_COMMAND_PATH   decision 2026-10-06: removed argv next_command path.
  LEGACY_ACTIONS_CARRIER decision 2026-10-06: retired GitHub Actions observer workflow carrier.
"""
from __future__ import annotations

import unittest

QUARANTINE_CLASS = "LEGACY_COMMAND_PATH"  # default class (kept for backward compatibility)


def reason_prefix(quarantine_class: str = QUARANTINE_CLASS) -> str:
    return f"QUARANTINED:{quarantine_class}:"


REASON_PREFIX = reason_prefix()


def quarantined(asset_id: str, quarantine_class: str = QUARANTINE_CLASS):
    return unittest.skip(f"{reason_prefix(quarantine_class)}{asset_id}")
