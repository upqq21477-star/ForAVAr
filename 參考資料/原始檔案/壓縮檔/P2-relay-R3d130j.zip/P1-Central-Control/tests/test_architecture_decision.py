"""R4R-S1 (FR-02) ADR validator tests: rules, transitions, Brief selection, closure scenario, librarian wiring."""
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
sys.path.insert(0, str(ROOT / "P1-Central-Control/tests"))

import architecture_decision as ad  # noqa: E402
import librarian  # noqa: E402
import test_librarian as tl  # noqa: E402


def mini_root(td: Path) -> Path:
    """Copy of the real docs/adr + brief_slots + placeholder link targets, so a baseline validates clean."""
    shutil.copytree(ROOT / ad.ADR_DIR, td / ad.ADR_DIR)
    (td / ad.SLOTS).parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / ad.SLOTS, td / ad.SLOTS)
    for p in (td / ad.ADR_DIR).glob("*.md"):
        fm, _ = ad.parse_frontmatter(p.read_text(encoding="utf-8"))
        for link in fm["links"]:
            if not link.startswith(("http", "ADR-")):
                (td / link).parent.mkdir(parents=True, exist_ok=True)
                (td / link).touch()
    return td


class AdrTests(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.td = mini_root(Path(self._td.name))

    def tearDown(self):
        self._td.cleanup()

    def edit(self, name_prefix, old, new):
        p = next((self.td / ad.ADR_DIR).glob(f"{name_prefix}-*.md"))
        t = p.read_text(encoding="utf-8")
        self.assertIn(old, t)
        p.write_text(t.replace(old, new, 1), encoding="utf-8")

    def codes(self):
        return [e.split(":")[0] for e in ad.validate(self.td)]

    def test_real_repo_and_baseline_copy_validate_clean(self):
        self.assertEqual(ad.validate(ROOT), [])
        self.assertEqual(ad.validate(self.td), [])

    def test_at_least_three_retroactive_records_plus_start(self):
        adrs, errs = ad.load_adrs(ROOT)
        self.assertEqual(errs, [])
        self.assertTrue({"0000", "0001", "0002", "0003"} <= set(adrs))

    def test_mutation_each_field_rule_is_caught(self):
        cases = [
            ("0001", "status: accepted", "status: maybe", "ADR_BAD_STATUS"),
            ("0001", "date: 2026-10-15", "date: yesterday", "ADR_BAD_DATE"),
            ("0001", "scope: [DISCUSS, BUILD]", "scope: [NOWHERE]", "ADR_SCOPE_UNKNOWN"),
            ("0001", "links: [docs/plans/P2-Relay-Update-Plan.md]", "links: [docs/nope.md]", "ADR_LINK_DANGLING"),
            ("0001", "links: [docs/plans/P2-Relay-Update-Plan.md]", "links: [ADR-9999]", "ADR_LINK_DANGLING"),
            ("0001", "supersedes: null", "supersedes: 9999", "ADR_SUPERSEDES_DANGLING"),
            ("0001", "supersedes: null", "supersedes: 0001", "ADR_SELF_SUPERSEDE"),
            ("0001", "status: accepted", "status: superseded", "ADR_SUPERSEDED_NO_SUCCESSOR"),
            ("0001", "superseded-by: null", "superseded-by: 0002", "ADR_SUPERSEDED_BY_STATUS_MISMATCH"),
            ("0001", "decision-makers: [P2-relay（事後補登，原決策者 UNKNOWN）]", "decision-makers: []", "ADR_NO_DECISION_MAKERS"),
            ("0001", "id: 0001", "id: 0007", "ADR_ID_FILENAME_MISMATCH"),
        ]
        for prefix, old, new, code in cases:
            with self.subTest(code=code, new=new):
                self.edit(prefix, old, new)
                self.assertIn(code, self.codes())
                self.edit(prefix, new, old)
                self.assertEqual(ad.validate(self.td), [])

    def test_mutation_reversal_condition_required(self):
        p = next((self.td / ad.ADR_DIR).glob("0002-*.md"))
        t = re.sub(r"reversal-condition: .*", "reversal-condition: ", p.read_text(encoding="utf-8"))
        p.write_text(t, encoding="utf-8")
        self.assertIn("ADR_EMPTY_REVERSAL", self.codes())

    def test_mutation_missing_field_start_record_and_bad_lines(self):
        self.edit("0002", "basis:", "basisX:")
        self.assertIn("ADR_MISSING_FIELD", self.codes())
        self.edit("0002", "basisX:", "basis:")
        self.edit("0003", "title:", "title no colon here\ntitle:")
        self.assertIn("ADR_BAD_FRONTMATTER_LINE", self.codes())
        self.edit("0003", "title no colon here\n", "")
        next((self.td / ad.ADR_DIR).glob("0000-*.md")).unlink()
        self.assertIn("ADR_NO_START", self.codes())

    def test_supersession_must_be_reciprocal_single_parent_and_acyclic(self):
        shutil.copy(self.td / ad.ADR_DIR / "0002-model-era-split.md", self.td / ad.ADR_DIR / "0004-x.md")
        self.edit("0004", "id: 0002", "id: 0004")
        self.edit("0004", "supersedes: null", "supersedes: 0001")
        self.assertIn("ADR_SUPERSEDES_NOT_RECIPROCAL", self.codes())
        shutil.copy(self.td / ad.ADR_DIR / "0004-x.md", self.td / ad.ADR_DIR / "0005-y.md")
        self.edit("0005", "id: 0004", "id: 0005")
        self.assertIn("ADR_MULTIPLE_SUPERSEDERS", self.codes())
        for n in ("0004-x.md", "0005-y.md"):
            (self.td / ad.ADR_DIR / n).unlink()
        self.edit("0001", "supersedes: null", "supersedes: 0002")
        self.edit("0002", "supersedes: null", "supersedes: 0001")
        self.assertIn("ADR_SUPERSEDES_CYCLE", self.codes())

    def test_successor_must_not_be_proposed(self):
        self.edit("0001", "status: accepted", "status: superseded")
        self.edit("0001", "superseded-by: null", "superseded-by: 0002")
        self.edit("0002", "supersedes: null", "supersedes: 0001")
        self.assertEqual(ad.validate(self.td), [])
        self.edit("0002", "status: accepted", "status: proposed")
        self.assertIn("ADR_SUCCESSOR_NOT_ACCEPTED", self.codes())

    def test_transition_table_is_exactly_the_declared_lifecycle(self):
        ok = {(a, b) for a in ad.STATUSES for b in ad.STATUSES if ad.transition_error(a, b) is None}
        self.assertEqual(ok, {("proposed", "accepted"), ("accepted", "deprecated"), ("accepted", "superseded")})
        self.assertEqual(ad.transition_error("accepted", "rejected"), "ADR_BAD_STATUS:accepted->rejected")

    def test_render_parse_round_trip(self):
        fm = ad._fm("0042", "accepted", "t", sup="0001")
        back, body = ad.parse_frontmatter(ad.render(fm, "x\n"))
        self.assertEqual(back, fm)
        self.assertEqual(body, "x\n")

    def test_brief_decisions_only_accepted_and_in_scope(self):
        build = ad.brief_decisions(self.td, "BUILD")
        self.assertEqual([x[:8] for x in build], ["ADR-0003", "ADR-0002", "ADR-0001"])
        self.assertEqual([x[:8] for x in ad.brief_decisions(self.td, "STARTUP")], ["ADR-0003"])
        self.assertEqual(ad.brief_decisions(self.td, "NO_SUCH_ROUTE"), [])
        self.assertTrue(all(len(x) <= 160 for x in build))
        self.assertEqual(len(ad.brief_decisions(self.td, "BUILD", limit=1)), 1)
        for status in ("proposed", "deprecated", "superseded"):
            with self.subTest(status=status):
                self.edit("0003", "status: accepted", f"status: {status}")
                self.assertNotIn("ADR-0003", " ".join(ad.brief_decisions(self.td, "BUILD")))
                self.edit("0003", f"status: {status}", "status: accepted")

    def test_closure_scenario_and_cli(self):
        self.assertEqual(ad.simulate(), [])
        r = subprocess.run([sys.executable, str(ROOT / "P1-Central-Control/scripts/architecture_decision.py"), "--simulate"],
                           capture_output=True, text=True)
        self.assertEqual((r.returncode, r.stdout.strip()), (0, "SIMULATED_PASS"))
        bad = subprocess.run([sys.executable, str(ROOT / "P1-Central-Control/scripts/architecture_decision.py"),
                              "--transition", "superseded", "accepted"], capture_output=True, text=True)
        self.assertEqual(bad.returncode, 1)


class LibrarianWiringTests(tl.Base):
    def test_brief_carries_scoped_accepted_decisions(self):
        shutil.copytree(ROOT / ad.ADR_DIR, self.mini / ad.ADR_DIR)
        b = self.collect()
        b = b[0] if isinstance(b, tuple) else b
        self.assertTrue(b["decisions"] and all(isinstance(x, str) for x in b["decisions"]))
        self.assertTrue(all(x.startswith("ADR-") for x in b["decisions"]))

    def test_brief_without_adr_dir_has_no_decisions(self):
        b = self.collect()
        b = b[0] if isinstance(b, tuple) else b
        self.assertEqual(b["decisions"], [])


if __name__ == "__main__":
    unittest.main()
