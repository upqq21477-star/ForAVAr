#!/usr/bin/env python3
"""CS-1 B3：四維狀態、Conflict、Temporal／Version、Rollback（SIMULATION_ONLY）。"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import knowledge_intake as ki  # noqa: E402
import knowledge_versioning as kv  # noqa: E402

TS = "2026-10-08T00:00:00Z"
T1, T2, T3 = "2026-01-01T00:00:00Z", "2026-06-01T00:00:00Z", "2026-09-01T00:00:00Z"
RAW = "系統 A 使用 SQLite 儲存。\n\n系統 A 不使用網路。\n\n系統 B 使用 JSON 檔。".encode("utf-8")
J = ("CONTROL_RESEARCH", "引文直接支持")


class VersioningTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        _, segs = ki.build_source("d", RAW, location="mem://d", version="v1", max_chars=20)
        self.segs = [s["object_id"] for s in segs]
        ledger = ki.ReadingLedger(Path(tmp.name) / "l.jsonl", segs)
        self.s = kv.TemporalKnowledgeStore(ledger, {"SOURCE:d": ki.normalize(RAW)})
        for ref in self.segs:
            ledger.append(ref, "READ", reader="R1", timestamp=TS)
        self.q = ["SQLite", "不使用網路", "JSON"]

    def mk(self, cid, seg=0, content=None, promote=True, **kw):
        o = self.s.add_observation("OBSERVED", "obs", self.segs[seg], producer="R1", captured_at=TS, quote=self.q[seg])["object_id"]
        e = self.s.add_evidence(o, f"CLAIM:{cid}", "SUPPORTS", producer="R1", scope="TASK:t", captured_at=TS)["object_id"]
        ref = self.s.propose_claim(cid, "FACT", content or f"內容 {cid}", [o], [e], **kw)["object_id"]
        if promote:
            self.assertEqual(self.s.promote(ref, by=J[0], rationale=J[1])["status"], "PROMOTED")
        return ref

    def gate(self):
        self.assertEqual(self.s.integrity_gate(), {"status": "PASS", "errors": []})

    # ---- V1→SUPERSEDED→V2 ----
    def test_revision_supersedes_and_temporal_query(self) -> None:
        v1 = self.mk("c1", valid_from=T1)
        v2 = self.mk("c2", 2, supersedes=[v1], valid_from=T2)
        self.assertEqual(self.s.claims[v2]["revision"], 2)
        c1 = self.s.claims[v1]
        self.assertEqual((c1["lifecycle"], c1["valid_to"]), ("SUPERSEDED", T2))
        self.assertEqual(self.s.valid_at("2026-03-01T00:00:00Z")["valid"], [v1])
        self.assertEqual(self.s.valid_at(T3)["valid"], [v2])
        self.assertEqual(self.s.valid_at("2025-01-01T00:00:00Z")["valid"], [])
        v = self.s.state_vector(v1)
        self.assertEqual((v["adjudication"], v["lifecycle"], v["epistemic"]), ("CONFIRMED", "SUPERSEDED", "OBSERVED"))
        self.gate()

    def test_supersede_guards(self) -> None:
        v1 = self.mk("c1", valid_from=T2)
        for kw, code in (({}, "SUPERSEDER_VALID_FROM_REQUIRED"), ({"valid_from": T1}, "SUPERSEDE_NOT_LATER")):
            ref = self.mk(f"x{len(kw)}{kw.get('valid_from', '')[:4]}", 2, promote=False, supersedes=[v1], **kw)
            r = self.s.promote(ref, by=J[0], rationale=J[1])
            self.assertEqual(r["status"], "BLOCK")
            self.assertTrue(any(e.startswith(code) for e in r["reason_codes"]), r)
            self.assertEqual(self.s.claims[v1]["lifecycle"], "ACTIVE")
        with self.assertRaises(ValueError):
            self.s.propose_claim("bad", "FACT", "x", [], [], supersedes=["CLAIM:nope"])
        with self.assertRaises(ValueError):
            self.mk("rng", valid_from=T3, valid_to=T1)

    # ---- Conflict：保留、不抹平 ----
    def _conflict(self):
        a = self.mk("a", 0, valid_from=T1)
        b = self.mk("b", 1, valid_from=T2)
        c = self.s.open_conflict("k1", a, b, "A 與 B 對儲存方式說法不同", by="CONTROL_RESEARCH", opened_at=TS)["object_id"]
        return a, b, c

    def test_conflict_preserved_and_disputed(self) -> None:
        a, b, c = self._conflict()
        rec = self.s.conflicts[c]
        self.assertEqual((rec["status"], rec["revision_a"], rec["source_refs_a"], rec["source_refs_b"]), ("UNRESOLVED", 1, ["SOURCE:d"], ["SOURCE:d"]))
        self.assertEqual(rec["observed_at_a"], TS)
        v = self.s.state_vector(a)
        self.assertEqual((v["epistemic"], v["adjudication"], v["open_conflicts"]), ("CONFLICTED", "DISPUTED", [c]))
        q = self.s.valid_at(T3)
        self.assertEqual((q["valid"], q["disputed"]), ([], [a, b]))  # 兩側都在，不被抹平
        with self.assertRaises(ValueError):
            self.s.open_conflict("k2", a, b, "dup", by="X", opened_at=TS)
        self.gate()

    def test_resolution_needs_evidence_and_adjudication(self) -> None:
        a, b, c = self._conflict()
        r = self.s.resolve_conflict(c, "SUPERSEDES", by="", rationale="", winner=b, evidence_refs=[])
        self.assertEqual(r["status"], "BLOCK")
        self.assertTrue({"ADJUDICATION_REQUIRED", "RESOLUTION_EVIDENCE_INSUFFICIENT"} <= set(r["reason_codes"]))
        wrong = self.s.claims[a]["evidence_refs"]  # 支持的是 a，不是 winner b
        self.assertIn("RESOLUTION_EVIDENCE_INSUFFICIENT", self.s.resolve_conflict(c, "SUPERSEDES", by=J[0], rationale=J[1], winner=b, evidence_refs=wrong)["reason_codes"])
        self.assertEqual(self.s.conflicts[c]["status"], "UNRESOLVED")
        ok = self.s.resolve_conflict(c, "SUPERSEDES", by=J[0], rationale="B 為較新來源", winner=b, evidence_refs=self.s.claims[b]["evidence_refs"])
        self.assertEqual(ok["status"], "RESOLVED")
        self.assertEqual((self.s.claims[a]["lifecycle"], self.s.claims[a]["valid_to"], self.s.claims[b]["supersedes"]), ("SUPERSEDED", T2, [a]))
        self.assertEqual(self.s.valid_at(T3)["valid"], [b])
        self.assertIn("NOT_UNRESOLVED", self.s.resolve_conflict(c, "SUPERSEDES", by=J[0], rationale=J[1], winner=b, evidence_refs=self.s.claims[b]["evidence_refs"])["reason_codes"])
        self.gate()

    def test_coexist_requires_disjoint_time_and_reject_one(self) -> None:
        a, b, c = self._conflict()
        self.assertIn("INTERVALS_NOT_DISJOINT", self.s.resolve_conflict(c, "COEXIST_DISJOINT_TIME", by=J[0], rationale=J[1])["reason_codes"])
        a2 = self.mk("a2", 0, content="A 舊期", valid_from=T1, valid_to=T2)
        b2 = self.mk("b2", 1, content="B 新期", valid_from=T2)
        c2 = self.s.open_conflict("k2", a2, b2, "期間不同", by=J[0], opened_at=TS)["object_id"]
        self.assertEqual(self.s.resolve_conflict(c2, "COEXIST_DISJOINT_TIME", by=J[0], rationale="各自有效期不重疊")["status"], "RESOLVED")
        q = self.s.valid_at("2026-03-01T00:00:00Z")
        self.assertEqual((q["valid"], q["disputed"]), ([a2], [a]))  # a 仍在未解 Conflict；a2 已解，屬舊期
        self.assertIn("CLAIM_NOT_REJECTED", self.s.resolve_conflict(c, "REJECTED_ONE", by=J[0], rationale=J[1], rejected=a)["reason_codes"])
        self.s.reject(self.mk("p", 2, promote=False), by=J[0], rationale="無依據")
        self.gate()

    # ---- Rollback：V1/V2/V3 可回退、lineage 可追溯 ----
    def test_rollback_chain_and_lineage(self) -> None:
        v1 = self.mk("v1", 0, valid_from=T1)
        v2 = self.mk("v2", 1, supersedes=[v1], valid_from=T2)
        v3 = self.mk("v3", 2, supersedes=[v2], valid_from=T3)
        self.assertEqual(self.s.rollback(v2, by=J[0], rationale="x")["reason_codes"], ["ROLLBACK_NOT_APPLICABLE"])  # 須先退最新版
        self.assertEqual(self.s.rollback(v3, by=J[0], rationale="V3 有誤")["status"], "ROLLED_BACK")
        self.assertEqual((self.s.claims[v2]["lifecycle"], self.s.claims[v2].get("valid_to")), ("ACTIVE", None))
        self.assertEqual(self.s.claims[v3]["lifecycle"], "ARCHIVED")
        self.assertEqual(self.s.valid_at("2026-12-01T00:00:00Z")["valid"], [v2])
        self.assertEqual(self.s.rollback(v2, by=J[0], rationale="V2 亦誤")["status"], "ROLLED_BACK")
        self.assertEqual(self.s.valid_at("2026-12-01T00:00:00Z")["valid"], [v1])
        self.assertIsNone(self.s.claims[v1].get("valid_to"))
        hist = self.s.history(v1)
        self.assertEqual([h["claim"] for h in hist], [v1, v2, v3])
        for h in hist:  # 證據鏈在回退後仍完整
            self.assertEqual(self.s.chain_errors(self.s.claims[h["claim"]]), [])
            self.assertTrue(h["evidence_refs"] and h["source_refs"])
        self.assertEqual(self.s.rollback(v1, by=J[0], rationale="x")["status"], "BLOCK")
        self.gate()

    def test_rollback_reopens_resolved_conflict(self) -> None:
        a, b, c = self._conflict()
        self.s.resolve_conflict(c, "SUPERSEDES", by=J[0], rationale=J[1], winner=b, evidence_refs=self.s.claims[b]["evidence_refs"])
        self.assertEqual(self.s.rollback(b, by=J[0], rationale="取代依據撤回")["status"], "ROLLED_BACK")
        self.assertEqual((self.s.conflicts[c]["status"], len(self.s.conflicts[c]["reopened"])), ("UNRESOLVED", 1))
        self.assertEqual(self.s.claims[a]["lifecycle"], "ACTIVE")
        self.gate()

    # ---- Lifecycle ----
    def test_lifecycle_transitions_and_ttl(self) -> None:
        r = self.mk("t1", valid_from=T1)
        for to, kw in (("ACTIVE", {}), ("SUPERSEDED", {}), ("TEMPORARY", {})):
            with self.assertRaises(ValueError):
                self.s.set_lifecycle(r, to, by=J[0], rationale=J[1], **kw)
        self.s.set_lifecycle(r, "TEMPORARY", by=J[0], rationale="暫用", expires_at=T2)
        self.assertEqual(self.s.valid_at("2026-03-01T00:00:00Z")["valid"], [r])
        self.assertEqual(self.s.valid_at(T3)["valid"], [])
        self.assertEqual(self.s.sweep_expired(T3), [r])
        self.assertEqual(self.s.claims[r]["lifecycle"], "ARCHIVED")
        with self.assertRaises(ValueError):
            self.s.set_lifecycle(r, "ACTIVE", by=J[0], rationale=J[1])
        e = self.mk("e1", 1)
        self.s.set_lifecycle(e, "EXPERIMENTAL", by=J[0], rationale="試驗")
        self.assertEqual(self.s.valid_at(T3)["valid"], [])
        self.gate()

    # ---- Gate 抓竄改 ----
    def test_gate_catches_tampering(self) -> None:
        v1 = self.mk("g1", valid_from=T1)
        self.mk("g2", 1, supersedes=[v1], valid_from=T2)
        self.s.claims[v1]["lifecycle"] = "ARCHIVED"
        errs = self.s.integrity_gate()["errors"]
        self.assertTrue(any(e.startswith("HASH_MISMATCH") for e in errs) and any(e.startswith("LIFECYCLE_LOG_MISMATCH") for e in errs))
        self.setUp()
        a, b, c = self._conflict()
        self.s.conflicts[c]["status"] = "RESOLVED"
        self.assertTrue(any(e.startswith("RESOLUTION_STATE_MISMATCH") for e in self.s.integrity_gate()["errors"]))


if __name__ == "__main__":
    unittest.main()
