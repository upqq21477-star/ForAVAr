"""S4a: segment_ingest (CAP-INGEST) and extract_guard (CAP-EXTRACT).  SIMULATED_PASS (death = BaseException mid-run)."""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "P1-Central-Control" / "scripts"))
import extract_guard as eg  # noqa: E402
import segment_ingest as si  # noqa: E402

TEXT = "第一段內容。\n\n第二段內容比較長一點。\n\n第三段。"
SRC = {"id": "S-1", "trust": "UNTRUSTED", "text": TEXT}
SCHEMA = {"version": "1", "fields": {"name": "str", "count": "int"}}


class Died(BaseException):
    pass


class Ingest(unittest.TestCase):
    def setUp(self) -> None:
        self.d = Path(tempfile.mkdtemp(prefix="s4a-"))
        self.addCleanup(shutil.rmtree, self.d, True)

    def files(self):
        return sorted(p.name for p in self.d.glob("*.json"))

    def test_ok_and_rerun_keeps_segment_ids_and_one_file_each(self) -> None:
        a = si.ingest(SRC, self.d, max_chars=12)
        self.assertEqual((a["status"], a["split_mode"]), ("OK", "DETERMINISTIC"))
        self.assertGreater(len(a["segments"]), 1)
        n = len(self.files())
        b = si.ingest(SRC, self.d, max_chars=12)
        self.assertEqual([s["segment_id"] for s in a["segments"]], [s["segment_id"] for s in b["segments"]])
        self.assertEqual((len(self.files()), b["written"]), (n, 0))

    def test_coverage_is_contiguous_non_overlapping_and_hashes_recompute(self) -> None:
        r = si.ingest(SRC, self.d, max_chars=12)
        self.assertEqual(si.check_coverage(TEXT, r["segments"]), [])
        bad = [dict(s) for s in r["segments"]]
        bad[1]["offset"] += 1
        self.assertTrue(si.check_coverage(TEXT, bad))
        bad2 = [dict(s) for s in r["segments"]]
        bad2[0]["text_hash"] = "0" * 64
        self.assertTrue(si.check_coverage(TEXT, bad2))
        self.assertTrue(si.check_coverage(TEXT, r["segments"][:-1]))  # a dropped tail is a coverage gap

    def test_missing_or_unknown_trust_and_unreadable_source_are_refused(self) -> None:
        for src in ({"id": "S-1", "text": TEXT}, {**SRC, "trust": "WHATEVER"}, {**SRC, "text": 5}, {**SRC, "id": ""}):
            with self.subTest(src):
                self.assertEqual(si.ingest(src, self.d)["status"], "FAILED")
        self.assertEqual(self.files(), [])

    def test_interrupt_then_rerun_only_writes_missing_segments(self) -> None:
        real, calls = si.atomic_write, []

        def dying(path, text):
            calls.append(path)
            if len(calls) == 3:
                raise Died
            return real(path, text)

        with mock.patch.object(si, "atomic_write", dying):
            with self.assertRaises(Died):
                si.ingest(SRC, self.d, max_chars=12)
        done = len(self.files())
        total = len(si.ingest(SRC, Path(tempfile.mkdtemp(prefix="s4a-x-")), max_chars=12)["segments"])
        r = si.ingest(SRC, self.d, max_chars=12)
        self.assertEqual((r["status"], r["skipped"], r["written"]), ("OK", done, total - done))

    def test_parser_failure_falls_back_and_is_marked(self) -> None:
        def boom(text, max_chars):
            raise ValueError("parser")

        r = si.ingest(SRC, self.d, splitter=boom, max_chars=12)
        self.assertEqual((r["status"], r["split_mode"]), ("OK", "FALLBACK_SPLIT"))
        self.assertEqual(si.check_coverage(TEXT, r["segments"]), [])

    def test_single_segment_write_failure_is_incomplete_not_a_whole_batch_failure(self) -> None:
        real = si.atomic_write
        state = {"n": 0}

        def flaky(path, text):
            state["n"] += 1
            if state["n"] == 2:
                raise OSError("disk")
            return real(path, text)

        with mock.patch.object(si, "atomic_write", flaky):
            r = si.ingest(SRC, self.d, max_chars=12)
        self.assertEqual(r["status"], "INCOMPLETE")
        self.assertEqual(len(r["missing"]), 1)
        self.assertEqual(len(self.files()), len(r["segments"]) - 1)  # nothing silently dropped: the miss is listed


def seg(i, text="abcdef"):
    return {"segment_id": f"seg{i}", "text": text, "trust": "UNTRUSTED"}


def good(segment, schema, attempt):
    return {"name": {"value": "x", "locator": {"segment_id": segment["segment_id"], "start": 0, "end": 3}},
            "count": {"value": 2, "locator": {"segment_id": segment["segment_id"], "start": 3, "end": 4}}}


class Extract(unittest.TestCase):
    def setUp(self) -> None:
        self.d = Path(tempfile.mkdtemp(prefix="s4a-e-"))
        self.addCleanup(shutil.rmtree, self.d, True)
        self.res = self.d / "results.json"

    def test_valid_fields_pass_and_keep_trust(self) -> None:
        r = eg.extract_segment(seg(1), SCHEMA, good)
        self.assertEqual(r["status"], "OK")
        self.assertEqual(r["fields"]["name"]["trust"], "UNTRUSTED")

    def test_schema_mismatch_reextracts_twice_then_field_is_unknown_never_filled(self) -> None:
        calls = []

        def bad(segment, schema, attempt):
            calls.append(attempt)
            rec = good(segment, schema, attempt)
            rec["count"]["value"] = "two"  # wrong type, every time
            return rec

        r = eg.extract_segment(seg(1), SCHEMA, bad)
        self.assertEqual((r["status"], len(calls)), ("PARTIAL", 3))
        self.assertEqual(r["fields"]["count"], {"value": None, "status": "UNKNOWN"})
        self.assertEqual(r["fields"]["name"]["value"], "x")

    def test_field_without_locator_is_refused(self) -> None:
        def nolocator(segment, schema, attempt):
            rec = good(segment, schema, attempt)
            del rec["name"]["locator"]
            return rec

        r = eg.extract_segment(seg(1), SCHEMA, nolocator)
        self.assertEqual(r["fields"]["name"]["status"], "UNKNOWN")
        self.assertEqual(eg.check_fields(SCHEMA, nolocator(seg(1), SCHEMA, 0), seg(1))["name"], "NO_LOCATOR")

    def test_locator_outside_the_segment_is_refused(self) -> None:
        rec = good(seg(1), SCHEMA, 0)
        rec["name"]["locator"]["end"] = 99
        self.assertEqual(eg.check_fields(SCHEMA, rec, seg(1))["name"], "BAD_LOCATOR")

    def test_model_failure_is_incomplete_without_retry_or_filling(self) -> None:
        calls = []

        def down(segment, schema, attempt):
            calls.append(attempt)
            raise RuntimeError("model down")

        r = eg.extract_segment(seg(1), SCHEMA, down)
        self.assertEqual((r["status"], len(calls), r["fields"]), ("INCOMPLETE", 1, {}))

    def test_interrupt_then_rerun_skips_completed_segments(self) -> None:
        segs, seen = [seg(1), seg(2), seg(3)], []

        def dying(segment, schema, attempt):
            seen.append(segment["segment_id"])
            if segment["segment_id"] == "seg2":
                raise Died
            return good(segment, schema, attempt)

        with self.assertRaises(Died):
            eg.run_extraction(segs, SCHEMA, dying, self.res)
        seen.clear()
        out = eg.run_extraction(segs, SCHEMA, good if False else (lambda s, sc, a: (seen.append(s["segment_id"]), good(s, sc, a))[1]), self.res)
        self.assertEqual(seen, ["seg2", "seg3"])  # seg1 was done before the death
        self.assertEqual({k: v["status"] for k, v in out["results"].items()}, {"seg1:1": "OK", "seg2:1": "OK", "seg3:1": "OK"})

    def test_unknown_rate_is_reported(self) -> None:
        def half(segment, schema, attempt):
            rec = good(segment, schema, attempt)
            rec["count"]["value"] = "x"
            return rec

        out = eg.run_extraction([seg(1)], SCHEMA, half, self.res)
        self.assertEqual(out["unknown_rate"], 0.5)
        self.assertEqual(json.loads(self.res.read_text(encoding="utf-8"))["seg1:1"]["status"], "PARTIAL")


if __name__ == "__main__":
    unittest.main()
