#!/usr/bin/env python3
from __future__ import annotations

import importlib.util
import json
import tempfile
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "P1-Central-Control/scripts/change_scope_gate.py"
SCHEMA = ROOT / "P1-Central-Control/schemas/change_scope.schema.json"


class ChangeScopeGateTests(unittest.TestCase):
    def _load(self):
        spec = importlib.util.spec_from_file_location("change_scope_gate", SCRIPT)
        module = importlib.util.module_from_spec(spec)
        assert spec.loader is not None
        spec.loader.exec_module(module)
        return module

    def test_schema_is_valid(self) -> None:
        from jsonschema import Draft202012Validator

        schema = json.loads(SCHEMA.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema)
        self.assertLessEqual(SCHEMA.stat().st_size, 12000)

    def test_single_system_change_proceeds(self) -> None:
        mod = self._load()
        self.assertIsNotNone(mod)
        self.assertTrue(True)

    def test_policy_is_bounded(self) -> None:
        policy = json.loads((ROOT / "P1-Central-Control/change_scope_policy.json").read_text(encoding="utf-8"))
        self.assertLess(policy["thresholds"]["context_target_units"], policy["thresholds"]["context_hard_units"])
        self.assertTrue(policy["rules"]["one_domain_system_per_work_slice"])
        self.assertEqual(policy["rules"]["cross_system_write_default"], "BLOCK")


if __name__ == "__main__":
    unittest.main()
