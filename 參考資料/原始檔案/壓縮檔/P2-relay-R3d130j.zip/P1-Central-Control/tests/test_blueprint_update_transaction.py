from __future__ import annotations
import hashlib, json, sys, tempfile, unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
import blueprint_update_transaction as tx

def write_json(root, ref, value):
    p = root / ref
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def sha_file(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def base_manifest():
    m = {
        "batch_id": "P2-B1-B8-CODE-FIRST", "batch_phase": "REALIZATION", "scope_frozen": True,
        "workstreams": [
            {"section_id": "P2-B1.3", "feature_ids": ["P2-F28"]},
            {"section_id": "P2-B2.3", "feature_ids": ["P2-F30"]},
        ],
        "features": [
            {"feature_id":"P2-F28","name":"Change classification and blueprint evolution","roadmap_sections":["P2-B1.3"],"depends_on":[],"implementation_refs":[],"test_refs":[],"local_case_sim_status":"NOT_RUN","local_case_sim_evidence_refs":[]},
            {"feature_id":"P2-F30","name":"Four-phase batch and blueprint update transaction","roadmap_sections":["P2-B2.3"],"depends_on":["P2-F21","P2-F25"],"implementation_refs":[],"test_refs":[],"local_case_sim_status":"NOT_RUN","local_case_sim_evidence_refs":[]},
        ],
        "official_test_roster": [], "closure_evidence_ref": None,
    }
    m["scope_fingerprint"] = tx._scope_fingerprint(m)
    return m

def fixture_root(root):
    (root / "docs/architecture").mkdir(parents=True, exist_ok=True)
    (root / "docs/plans").mkdir(parents=True, exist_ok=True)
    (root / tx.MATRIX_REF).write_text("# Test matrix fixture\\n", encoding="utf-8")
    (root / tx.TEST_STRATEGY_REF).write_text("# Test strategy fixture\\n", encoding="utf-8")
    policy_ref="P1-Central-Control/policy/user_redline_policy.v1.0.json"
    policy_schema_ref="P1-Central-Control/schemas/user_redline_policy.schema.json"
    (root / tx.BLUEPRINT_REF).write_text("# Canonical blueprint v3.2\n", encoding="utf-8")
    (root / tx.ROADMAP_REF).write_text("# Roadmap v1.15\n", encoding="utf-8")
    write_json(root, policy_ref, {
        "policy_id":"P2-USER-REDLINE-POLICY","policy_version":"1.1","status":"ACTIVE",
        "classification_rule":"EXPLICIT_CATEGORY_MATCH; UNKNOWN_OR_AMBIGUOUS_BLOCKS",
        "known_operation_ids":["assess_and_rank_requirements","read_current_and_canonical_sources","update_canonical_blueprint","synchronize_derived_views","update_work_construction_status","approved_batch_scope_change","run_synthetic_local_test","execute_protected_sandbox_gate","read_back_written_sources","rollback_partial_write","read_or_export_protected_production_data","modify_or_delete_protected_production_data","expose_credentials_or_identity_secrets","weaken_security_or_permission_controls","disable_audit_or_backup_recovery","perform_irreversible_action_without_recovery_plan","trigger_unapproved_external_transaction"],
        "default_protected_categories":["company_customer_financial_legal_data","credentials_identity_and_access","permissions_and_security_configuration","audit_backup_and_recovery_records","irreversible_deletion_or_modification","external_transactions_and_side_effects"],
        "forbidden_operations_without_explicit_authorization":["read_or_export_protected_production_data","modify_or_delete_protected_production_data","expose_credentials_or_identity_secrets","weaken_security_or_permission_controls","disable_audit_or_backup_recovery","perform_irreversible_action_without_recovery_plan","trigger_unapproved_external_transaction"],
        "required_sandbox_conditions":["ISOLATED_FROM_PRODUCTION","REVERSIBLE_OR_DISPOSABLE","SYNTHETIC_SANITIZED_OR_DEDICATED_TEST_DATA","OBSERVABLE_EXIT_CODE_AND_RESULT","SOURCE_POLICY_TEST_AND_SCOPE_FINGERPRINTS_BOUND"],
        "decision_rules":{"known_redline_match":"BLOCK","unknown_or_ambiguous_classification":"BLOCK","missing_or_stale_execution_receipt":"BLOCK","non_applicable_disposition":"REQUIRES_EXPLICIT_USER_CONFIRMATION_AND_RATIONALE","policy_hash_change":"INVALIDATE_PRIOR_RECEIPTS"},
        "non_applicability_requires_explicit_confirmation":True,
        "configuration_change_authority":"USER_EXPLICIT_APPROVAL",
        "storage_restrictions":["DO_NOT_STORE_PRODUCTION_OR_CUSTOMER_RECORDS","DO_NOT_STORE_CREDENTIALS_OR_SECRETS","STORE_ONLY_NON_SENSITIVE_CATEGORY_LABELS_AND_OPAQUE_REFERENCES"]
    })
    write_json(root, policy_schema_ref, {
        "type":"object",
        "required":["policy_id","policy_version","status","classification_rule","known_operation_ids","default_protected_categories","forbidden_operations_without_explicit_authorization","required_sandbox_conditions","decision_rules","non_applicability_requires_explicit_confirmation","configuration_change_authority","storage_restrictions"],
        "properties":{
            "policy_id":{"const":"P2-USER-REDLINE-POLICY"},
            "policy_version":{"type":"string","minLength":1},
            "status":{"enum":["ACTIVE","SUSPENDED"]},
            "classification_rule":{"const":"EXPLICIT_CATEGORY_MATCH; UNKNOWN_OR_AMBIGUOUS_BLOCKS"},
            "known_operation_ids":{"type":"array","minItems":1,"uniqueItems":True,"items":{"type":"string","minLength":1}},
            "default_protected_categories":{"type":"array","minItems":1,"uniqueItems":True,"items":{"type":"string","minLength":1}},
            "forbidden_operations_without_explicit_authorization":{"type":"array","minItems":1,"uniqueItems":True,"items":{"type":"string","minLength":1}},
            "required_sandbox_conditions":{"type":"array","minItems":1,"uniqueItems":True,"items":{"type":"string","minLength":1}},
            "decision_rules":{"type":"object","required":["known_redline_match","unknown_or_ambiguous_classification","missing_or_stale_execution_receipt","non_applicable_disposition","policy_hash_change"],"properties":{
                "known_redline_match":{"const":"BLOCK"},"unknown_or_ambiguous_classification":{"const":"BLOCK"},
                "missing_or_stale_execution_receipt":{"const":"BLOCK"},"non_applicable_disposition":{"const":"REQUIRES_EXPLICIT_USER_CONFIRMATION_AND_RATIONALE"},
                "policy_hash_change":{"const":"INVALIDATE_PRIOR_RECEIPTS"}},"unevaluatedProperties":False},
            "non_applicability_requires_explicit_confirmation":{"const":True},
            "configuration_change_authority":{"const":"USER_EXPLICIT_APPROVAL"},
            "storage_restrictions":{"type":"array","minItems":1,"uniqueItems":True,"items":{"type":"string","minLength":1}}
        },
        "unevaluatedProperties":False
    })
    write_json(root, tx.CURRENT_REF, {
        "p2_target_blueprint_ref":tx.BLUEPRINT_REF,"p2_current_roadmap_ref":tx.ROADMAP_REF,
        "p2_blueprint_pointer_policy":{"redline_policy_ref":policy_ref,"redline_policy_schema_ref":policy_schema_ref},
        "implementation_control":{"active_work_packet":tx.WORK_REF},"active_construction_packet":tx.CONSTRUCTION_REF,
    })
    write_json(root, tx.WORK_REF, {"operational_contract":{"feature_batch_manifest_ref":tx.MANIFEST_REF}})
    write_json(root, tx.CONSTRUCTION_REF, {"handoff":{"notes":[]}})
    write_json(root, tx.MANIFEST_REF, base_manifest())

def impact_row(path, disposition):
    action={
        "NO_REWORK_REQUIRED":"No rework is required in this isolated fixture.",
        "DOC_SYNC_REQUIRED":"Synchronize the affected derived view before commit.",
        "REVALIDATION_REQUIRED":"Revalidate the scope and invalidate dependent receipts.",
        "REWORK_REQUIRED":"Update this source and read back its digest.",
        "BLOCKED_UNKNOWN":"Resolve the unknown impact before writing.",
    }[disposition]
    return {
        "path":path,"disposition":disposition,"owner":"ROLE:CONTROL_RESEARCH",
        "current_evidence":"Read-back of the current synthetic fixture source.",
        "reason":"Explicit bounded disposition for this transaction test.",
        "required_action":action,"evidence_invalidation":["LOCAL_CASE_RECEIPTS"] if disposition=="REVALIDATION_REQUIRED" else [],
        "unlock_condition":"Source hash is current and the declared action is satisfied."
    }

def impact_matrix(root):
    paths=[tx.CURRENT_REF,tx.BLUEPRINT_REF,tx.ROADMAP_REF,tx.WORK_REF,tx.CONSTRUCTION_REF,tx.MANIFEST_REF,
           "P1-Central-Control/policy/user_redline_policy.v1.0.json",
           "P1-Central-Control/schemas/user_redline_policy.schema.json",tx.MATRIX_REF,tx.TEST_STRATEGY_REF]
    # R3d8: ROADMAP_REF and TEST_STRATEGY_REF now name the same file (Relay Plan); the old list had 10 distinct
    # paths and was only valid while those were two documents, so duplicates must not become two impact rows
    return [impact_row(p,"NO_REWORK_REQUIRED") for p in dict.fromkeys(paths)]

def candidates():
    return [
        {"requirement_id":"R-BASE","title":"Implement change classification","redline_status":"CLEAR","classification_complete":True,"protected_categories":[],"requested_operations":["read_current_and_canonical_sources"],"impact_score":3,"urgency_score":3,"rework_risk_score":2,"effort_score":2,"dependency_foundation":True},
        {"requirement_id":"R-TRANSACTION","title":"Implement guarded blueprint transaction","redline_status":"CLEAR","classification_complete":True,"protected_categories":[],"requested_operations":["read_current_and_canonical_sources"],"depends_on":["R-BASE"],"impact_score":5,"urgency_score":5,"rework_risk_score":5,"effort_score":3,"authority_conflict":True,"blocking_downstream_count":5},
    ]

def scope_record(old_fp,new_fp):
    return {
        "change_id":"SC-2026-10-11-BLUEPRINT-F28-F30","status":"APPROVED","approval_ref":"user-instruction:2026-10-11",
        "previous_scope_fingerprint":old_fp,"new_scope_fingerprint":new_fp,"affected_feature_ids":["P2-F28","P2-F30"],
        "dependency_graph_recomputed":True,"downstream_evidence_invalidated":True,"reopened_to_planning":True,"refrozen_after_review":True,
        "phase_transition":["REALIZATION","PLANNING","REALIZATION"],
        "evidence_invalidated":["LOCAL_CASE_RECEIPTS","CLOSURE_EVIDENCE","OFFICIAL_TEST_ROSTER","FINAL_TEST_ADMISSION"],
        "rationale":"F28/F30 update adds the explicit dependency and invalidates previous downstream evidence.",
    }

def make_apply_request(root, authorized=True, unknown_impact=False):
    ctx=tx._load_context(root)
    m=json.loads(json.dumps(ctx["manifest"]))
    f30=next(f for f in m["features"] if f["feature_id"]=="P2-F30")
    if "P2-F28" not in f30["depends_on"]: f30["depends_on"].append("P2-F28")
    for f in m["features"]:
        f["local_case_sim_status"]="NOT_RUN"; f["local_case_sim_evidence_refs"]=[]
    m["official_test_roster"]=[]; m["closure_evidence_ref"]=None
    new_fp=tx._scope_fingerprint(m); m["scope_fingerprint"]=new_fp
    m.setdefault("scope_change_history",[]).append(scope_record(ctx["scope_fingerprint"],new_fp))
    bp=root/tx.BLUEPRINT_REF; mf=root/tx.MANIFEST_REF
    impact=[impact_row(p,"NO_REWORK_REQUIRED") for p in dict.fromkeys([tx.CURRENT_REF,tx.ROADMAP_REF,tx.WORK_REF,tx.CONSTRUCTION_REF,"P1-Central-Control/policy/user_redline_policy.v1.0.json","P1-Central-Control/schemas/user_redline_policy.schema.json",tx.MATRIX_REF,tx.TEST_STRATEGY_REF])]
    impact.extend([impact_row(tx.BLUEPRINT_REF,"REWORK_REQUIRED"),impact_row(tx.MANIFEST_REF,"REVALIDATION_REQUIRED")])
    if unknown_impact: impact.append(impact_row("docs/unknown.md","BLOCKED_UNKNOWN"))
    return {
        "request_id":"TEST-BLUEPRINT-TXN","mode":"APPLY",
        "scope_change_required":True,
        "expected_snapshot":{"blueprint_sha256":sha_file(bp),"manifest_scope_fingerprint":ctx["scope_fingerprint"],
          "current_sha256":sha_file(root/tx.CURRENT_REF),"work_sha256":sha_file(root/tx.WORK_REF),
          "construction_sha256":sha_file(root/tx.CONSTRUCTION_REF),"manifest_sha256":sha_file(mf),"roadmap_sha256":sha_file(root/tx.ROADMAP_REF),"redline_policy_sha256":sha_file(root/"P1-Central-Control/policy/user_redline_policy.v1.0.json"),"redline_policy_schema_sha256":sha_file(root/"P1-Central-Control/schemas/user_redline_policy.schema.json"),"matrix_sha256":sha_file(root/tx.MATRIX_REF),"test_strategy_sha256":sha_file(root/tx.TEST_STRATEGY_REF)},
        "candidate_requirements":candidates(),"scope_change":scope_record(ctx["scope_fingerprint"],new_fp),
        "authorization":{"blueprint_write_approved":authorized,"approval_ref":"user-instruction:2026-10-11"},
        "protected_gate":{"required":False,"disposition":"NOT_APPLICABLE","user_confirmed_not_applicable":True,"approval_ref":"user-instruction:2026-10-11","rationale":"This isolated synthetic transaction only updates blueprint repository code and does not access protected production records.","policy_sha256":sha_file(root/"P1-Central-Control/policy/user_redline_policy.v1.0.json")},"core_principle_change":False,"impact_matrix":impact,
        "proposed_writes":[
          {"path":tx.BLUEPRINT_REF,"owner":"BLUEPRINT_ENGINEERING","expected_sha256":sha_file(bp),"content":"# Canonical blueprint v3.3\n"},
          {"path":tx.MANIFEST_REF,"owner":"CENTRAL","expected_sha256":sha_file(mf),"content":json.dumps(m,ensure_ascii=False,indent=2)+"\n"},
        ],
    }

class BlueprintUpdateFeatureTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name); fixture_root(self.root)
    def tearDown(self): self.tmp.cleanup()

    def test_F28_normal_deterministic_priority_and_dependency_order(self):
        ranked=tx.rank_requirements(candidates(), tx._load_context(self.root)["redline_policy"])
        self.assertEqual([r["requirement_id"] for r in ranked],["R-BASE","R-TRANSACTION"])
        self.assertEqual(ranked[1]["priority_tier"],"P1_CORE")
        self.assertEqual(tx.assess_update(self.root,{"request_id":"R","candidate_requirements":candidates(),"impact_matrix":impact_matrix(self.root)})["status"],"ASSESSMENT_READY")

    def test_F28_negative_redline_and_unknown_dependency_fail_closed(self):
        with self.assertRaisesRegex(tx.BlueprintUpdateError,"DEPENDENCY_UNKNOWN"):
            tx.rank_requirements([{"requirement_id":"A","title":"A","redline_status":"CLEAR","classification_complete":True,"protected_categories":[],"requested_operations":["read_current_and_canonical_sources"],"depends_on":["MISSING"]}], tx._load_context(self.root)["redline_policy"])
        req=candidates()+[{"requirement_id":"R-REDLINE","title":"Protected operation","redline_status":"UNRESOLVED","classification_complete":False,"protected_categories":[],"requested_operations":["read_current_and_canonical_sources"]}]
        result=tx.assess_update(self.root,{"request_id":"R","candidate_requirements":req})
        self.assertEqual(result["status"],"BLOCKED")
        self.assertIn("BLUEPRINT_PROTECTED_REDLINE_BLOCKS_TRANSACTION",result["blockers"])
        unknown=candidates()
        unknown[0]["requested_operations"]=["unregistered_operation"]
        result=tx.assess_update(self.root,{"request_id":"R-UNKNOWN-OP","candidate_requirements":unknown,"impact_matrix":impact_matrix(self.root)})
        self.assertEqual(result["status"],"BLOCKED")
        self.assertIn("UNKNOWN_REQUESTED_OPERATION",str(result["priority_order"]))

    def test_F28_boundary_stale_snapshot_and_unapproved_core_principle_revision_block(self):
        req={"request_id":"R","candidate_requirements":candidates(),"expected_snapshot":{"blueprint_sha256":"0"*64}}
        result=tx.assess_update(self.root,req)
        self.assertEqual(result["status"],"BLOCKED")
        self.assertIn("BLUEPRINT_EXPECTED_BLUEPRINT_DRIFT",result["blockers"])
        req["expected_snapshot"]={}; req["core_principle_change"]=True
        req["core_principle_review"]={"evidence_refs":["e"],"counterexamples":["c"],"alternatives":["a"],"retaining_consequences":"r","revision_consequences":"n","migration_plan":"m","rollback_plan":"b"}
        result=tx.assess_update(self.root,req)
        self.assertIn("CORE_PRINCIPLE_REVISION_APPROVAL_REQUIRED",result["blockers"])

    def test_F30_normal_scope_change_commit_readback(self):
        req=make_apply_request(self.root); result=tx.apply_update_transaction(self.root,req)
        self.assertEqual(result["status"],"COMMITTED",result.get("blockers"))
        self.assertTrue(result["write_performed"]); self.assertEqual(len(result["readback"]),2)
        self.assertIn("v3.3",(self.root/tx.BLUEPRINT_REF).read_text())
        m=tx._json(self.root,tx.MANIFEST_REF,"X")
        self.assertNotEqual(m["scope_fingerprint"],req["scope_change"]["previous_scope_fingerprint"])
        self.assertEqual(m["features"][1]["local_case_sim_status"],"NOT_RUN")

    def test_F30_negative_frozen_scope_change_requires_approval_owner_and_known_impact(self):
        req=make_apply_request(self.root)
        manifest=json.loads(req["proposed_writes"][1]["content"])
        f30=next(f for f in manifest["features"] if f["feature_id"]=="P2-F30")
        f30["depends_on"]=["P2-F21","P2-F25"]
        f28=next(f for f in manifest["features"] if f["feature_id"]=="P2-F28")
        f28["name"] += " (name-only edit)"
        new_fp=tx._scope_fingerprint(manifest)
        manifest["scope_fingerprint"]=new_fp
        manifest["scope_change_history"][-1]["new_scope_fingerprint"]=new_fp
        req["scope_change"]["new_scope_fingerprint"]=new_fp
        req["proposed_writes"][1]["content"]=json.dumps(manifest,ensure_ascii=False,indent=2)+"\n"
        result=tx.apply_update_transaction(self.root,req)
        self.assertIn("BLUEPRINT_SCOPE_CHANGE_DEPENDENCY_GRAPH_UNCHANGED",result["blockers"])
        req=make_apply_request(self.root); req["scope_change"]["status"]="PENDING"
        result=tx.apply_update_transaction(self.root,req)
        self.assertEqual(result["status"],"BLOCKED"); self.assertFalse(result["write_performed"])
        req=make_apply_request(self.root); req["proposed_writes"][0]["owner"]="CENTRAL"
        result=tx.apply_update_transaction(self.root,req)
        self.assertTrue(any(x.startswith("BLUEPRINT_WRITE_OWNER_FORBIDDEN:") for x in result["blockers"]))
        self.assertNotIn("v3.3",(self.root/tx.BLUEPRINT_REF).read_text())
        req=make_apply_request(self.root,unknown_impact=True); result=tx.apply_update_transaction(self.root,req)
        self.assertIn("BLUEPRINT_IMPACT_UNKNOWN_BLOCKS_WRITE",result["blockers"])

    def test_F30_boundary_scope_change_invalidates_old_evidence_and_rolls_back_partial_write(self):
        req=make_apply_request(self.root); m=json.loads(req["proposed_writes"][1]["content"])
        m["features"][0]["local_case_sim_status"]="PASS"
        req["proposed_writes"][1]["content"]=json.dumps(m,ensure_ascii=False,indent=2)+"\n"
        result=tx.apply_update_transaction(self.root,req)
        self.assertIn("BLUEPRINT_OLD_RECEIPT_NOT_INVALIDATED",result["blockers"])
        self.assertNotIn("v3.3",(self.root/tx.BLUEPRINT_REF).read_text())
        req=make_apply_request(self.root); original_bp=(self.root/tx.BLUEPRINT_REF).read_bytes(); original_manifest=(self.root/tx.MANIFEST_REF).read_bytes()
        replace=tx.os.replace; count={"n":0}
        def fail_second(src,dst):
            count["n"]+=1
            if count["n"]==2: raise OSError("injected second-write failure")
            return replace(src,dst)
        with patch.object(tx.os,"replace",side_effect=fail_second):
            with self.assertRaisesRegex(tx.BlueprintUpdateError,"TRANSACTION_FAILED"):
                tx._atomic_write_set(self.root,req["proposed_writes"])
        self.assertEqual((self.root/tx.BLUEPRINT_REF).read_bytes(),original_bp)
        self.assertEqual((self.root/tx.MANIFEST_REF).read_bytes(),original_manifest)

if __name__=="__main__": unittest.main(verbosity=2)
