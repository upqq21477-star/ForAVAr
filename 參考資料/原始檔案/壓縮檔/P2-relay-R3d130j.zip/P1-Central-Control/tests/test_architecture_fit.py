import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from architecture_fit import execute


class ArchitectureFitTests(unittest.TestCase):
    def _request(self, classification="IMPLEMENTED", **overrides):
        state = {
            "classification": classification,
            "system_id": "SYS-01",
            "boundary_conflict": False,
            "split_required": False,
            "supports_extension": False,
            "owned_capabilities": ["CAP-SEARCH", "CAP-GRAPH"]
        }
        state.update(overrides)
        return {
            "schema_version": "1.0",
            "request_id": "FIT:001",
            "goal": "relationship analysis",
            "required_capabilities": ["CAP-SEARCH"],
            "system_state": state,
            "allow_new_system": True
        }

    def test_reuse(self):
        self.assertEqual(execute(self._request())["decision"], "REUSE")

    def test_extend(self):
        # EXTEND only when a required capability is missing and the system can be extended.
        request = self._request(supports_extension=True, owned_capabilities=["CAP-SEARCH"])
        request["required_capabilities"] = ["CAP-SEARCH", "CAP-NEW"]
        result = execute(request)
        self.assertEqual(result["decision"], "EXTEND")
        self.assertEqual(result["missing_capabilities"], ["CAP-NEW"])

    def test_fully_covered_reuses_even_if_extension_is_supported(self):
        # Minimal sufficient option: nothing missing means REUSE, not EXTEND.
        result = execute(self._request(supports_extension=True, owned_capabilities=["CAP-SEARCH"]))
        self.assertEqual(result["decision"], "REUSE")
        self.assertEqual(result["missing_capabilities"], [])

    def test_broken_refactors(self):
        self.assertEqual(execute(self._request("BROKEN"))["decision"], "REFACTOR")

    def test_unknown_defers(self):
        self.assertEqual(execute(self._request("UNKNOWN"))["decision"], "DEFER")

    def test_new_system_requires_explicit_permission(self):
        req = self._request(owned_capabilities=[])
        req["allow_new_system"] = True
        self.assertEqual(execute(req)["decision"], "NEW_SYSTEM")


if __name__ == "__main__":
    unittest.main()
