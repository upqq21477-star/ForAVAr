#!/usr/bin/env python3
"""CS-1 B4：Archive scope、存取協定、處置、manifest、bundle（SIMULATION_ONLY）。"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import archive_governance as ag  # noqa: E402
import knowledge_intake as ki  # noqa: E402
import knowledge_canon as kc  # noqa: E402

NOW = "2026-10-08T00:00:00Z"
LATER, MUCH_LATER = "2026-12-01T00:00:00Z", "2027-06-01T00:00:00Z"
CR = {"agent_id": "A1", "role": "ROLE:CONTROL_RESEARCH", "capability_id": "CAP-SEARCH"}
J = {"by": "CONTROL_RESEARCH", "rationale": "已蒸餾，重建不需原文"}


def codes(testcase, fn, *a, **kw):
    with testcase.assertRaises(ValueError) as cm:
        fn(*a, **kw)
    return str(cm.exception).split(":", 1)[0]


class ArchiveTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.tmp = Path(tmp.name)
        (self.tmp / "old").mkdir()
        (self.tmp / "old" / "a.md").write_text("舊研究 A：方案 X 失敗，因為 Y。", encoding="utf-8")
        (self.tmp / "old" / "b.md").write_text("舊驗證 B。", encoding="utf-8")

    def decision(self, cls="RESEARCH", **kw):
        base = dict(reconstruction_required=False, impact="NONE", disposition="ARCHIVE", distilled="方案 X 因 Y 失敗；不採用。", **J)
        return ag.decide(cls, **{**base, **kw})

    def plan(self, path="old/a.md", purposes=("HISTORICAL_RESEARCH", "FORENSICS"), cls="RESEARCH", **kw):
        return {"path": path, "decision": self.decision(cls, **kw), "reason": "研究結案", "allowed_purposes": list(purposes), "review_after": LATER}

    def manifest(self):
        recs = ag.archive_assets(self.tmp, [self.plan(), self.plan("old/b.md", ("RECOVERY",), "VALIDATION")], self.tmp / "ar.zip", archive_ref="release:ar1", now=NOW)
        return ag.ArchiveManifest(recs), recs

    # ---- scope ----
    def test_scope_rules(self):
        for bad, code in (("ALL", "SCOPE_ALL_FORBIDDEN"), ("all", "SCOPE_ALL_FORBIDDEN"), ("", "SCOPE_REQUIRED"), ("HOT2", "SCOPE_UNKNOWN"),
                          ("EXTERNAL", "EXTERNAL_NOT_SERVED"), ("COLD", "COLD_REASON_REQUIRED"), ("ARCHIVE", "ARCHIVE_PURPOSE_REQUIRED")):
            self.assertEqual(codes(self, ag.check_scope, bad), code)
        self.assertEqual(codes(self, ag.check_scope, "ARCHIVE", purpose="CURIOSITY"), "PURPOSE_UNKNOWN")
        self.assertEqual(ag.check_scope("ARCHIVE", purpose="RECOVERY"), "ARCHIVE")
        self.assertEqual(ag.check_scope("COLD", reason="歷史對照"), "COLD")

    def test_normal_search_never_returns_archive(self):
        m, _ = self.manifest()
        items = [{"id": "x", "scope": "ACTIVE"}, {"id": "y", "scope": "WARM"}, {"id": "z", "scope": "COLD"}, {"id": "n"}, *m.records.values()]
        got = ag.scoped_search(items, lambda i: True)
        self.assertEqual([i["id"] for i in got], ["x", "y"])
        self.assertEqual(sum(i.get("scope") == "ARCHIVE" for i in got), 0)  # archive_leakage = 0
        self.assertEqual(codes(self, ag.scoped_search, items, lambda i: True, "ARCHIVE"), "ARCHIVE_VIA_PROTOCOL_ONLY")
        self.assertEqual(codes(self, ag.scoped_search, items, lambda i: True, ["ACTIVE", "ALL"]), "SCOPE_ALL_FORBIDDEN")
        self.assertEqual(codes(self, ag.scoped_search, items, lambda i: True, "COLD"), "COLD_REASON_REQUIRED")
        self.assertEqual([i["id"] for i in ag.scoped_search(items, lambda i: True, "COLD", reason="對照")], ["z"])

    # ---- 處置 ----
    def test_decide_rules(self):
        d = self.decision()
        self.assertEqual((d["disposition"], d["by"]), ("ARCHIVE", "CONTROL_RESEARCH"))
        cases = [
            ((), dict(by=" "), "ADJUDICATION_REQUIRED"), ((), dict(rationale=""), "ADJUDICATION_REQUIRED"),
            (("MISC",), {}, "ASSET_CLASS_UNKNOWN"), ((), dict(disposition="LOAD"), "DISPOSITION_INVALID"),
            ((), dict(impact="HUGE"), "DISPOSITION_INVALID"), ((), dict(reconstruction_required=True), "RECONSTRUCTION_INPUT_MUST_BE_KEPT"),
            ((), dict(disposition="KEEP"), "KEEP_REQUIRES_RECONSTRUCTION_NEED"),
            ((), dict(disposition="KEEP", reconstruction_required=True), "TEMPORARY_CLASS_NOT_KEEPABLE"),
            ((), dict(impact="SYSTEM"), "BLUEPRINT_REF_REQUIRED"), ((), dict(distilled=" "), "DISTILLED_REQUIRED"),
        ]
        for args, kw, code in cases:
            self.assertEqual(codes(self, self.decision, *args, **kw), code, (args, kw))
        self.assertEqual(self.decision(impact="SYSTEM", blueprint_ref="BLUEPRINT:v2")["blueprint_ref"], "BLUEPRINT:v2")
        keep = self.decision("DOCUMENT", disposition="KEEP", reconstruction_required=True, distilled=None)
        self.assertEqual(keep["disposition"], "KEEP")
        dispose = self.decision(disposition="DISPOSE", distilled=None)
        self.assertEqual(codes(self, ag.make_record, b"x", dispose, archive_ref="r", origin_path="p", allowed_purposes=["RECOVERY"], reason="r", archived_at=NOW, review_after=LATER), "NOT_ARCHIVE_DISPOSITION")

    # ---- manifest／bundle ----
    def test_bundle_manifest_roundtrip_and_tamper(self):
        m, recs = self.manifest()
        self.assertEqual(m.verify(), [])
        self.assertEqual(ag.verify_bundle(self.tmp / "ar.zip", recs, "release:ar1"), [])
        again = ag.archive_assets(self.tmp, [self.plan(), self.plan("old/b.md", ("RECOVERY",), "VALIDATION")], self.tmp / "ar2.zip", archive_ref="release:ar1", now=NOW)
        self.assertEqual(again, recs)
        self.assertEqual((self.tmp / "ar.zip").read_bytes(), (self.tmp / "ar2.zip").read_bytes())  # 決定性
        with zipfile.ZipFile(self.tmp / "ar.zip") as z:
            self.assertIn(ag.INDEX_NAME, z.namelist())
            files = {n: z.read(n) for n in z.namelist()}
        files["old/a.md"] = "被改過".encode("utf-8")
        with zipfile.ZipFile(self.tmp / "bad.zip", "w") as z:
            for n, b in files.items():
                z.writestr(n, b)
        self.assertEqual([e.split(":")[0] for e in ag.verify_bundle(self.tmp / "bad.zip", recs, "release:ar1")], ["MEMBER_HASH_MISMATCH"])
        p = self.tmp / "m.json"
        m.save(p)
        self.assertEqual(ag.ArchiveManifest.load(p).records, m.records)
        self.assertEqual(codes(self, m.add, recs[0]), "RECORD_DUPLICATE")
        forged = {**recs[0], "object_id": "ARCHIVE_RECORD:forged0000000000", "distilled": "偷改"}
        self.assertEqual(codes(self, ag.ArchiveManifest().add, forged), "RECORD_HASH_MISMATCH")
        self.assertEqual(codes(self, ag.archive_assets, self.tmp, [self.plan("../x.md")], self.tmp / "z.zip", archive_ref="r", now=NOW), "PATH_OUTSIDE_ROOT_OR_MISSING")
        self.assertEqual(codes(self, ag.archive_assets, self.tmp, [{**self.plan(), "review_after": NOW}], self.tmp / "z.zip", archive_ref="r", now=NOW), "REVIEW_AFTER_NOT_LATER")

    def test_manifest_save_failure_preserves_previous_bytes(self):
        manifest, _ = self.manifest()
        path = self.tmp / "manifest-atomic.json"
        manifest.save(path)
        before = path.read_bytes()
        with mock.patch.object(Path, "open", side_effect=OSError("simulated write failure")):
            with self.assertRaises(OSError):
                manifest.save(path)
        self.assertEqual(path.read_bytes(), before)
        self.assertFalse(path.with_name(path.name + ".tmp").exists())

    def test_archive_lifecycle(self):
        m, recs = self.manifest()
        ref = recs[0]["object_id"]
        self.assertEqual(m.mark_due("2026-11-01T00:00:00Z"), [])
        self.assertEqual(m.mark_due(MUCH_LATER), sorted(r["object_id"] for r in recs))
        self.assertEqual(m.records[ref]["lifecycle"], "REVIEW")
        self.assertEqual(codes(self, m.set_lifecycle, ref, "COMPRESS", by="", rationale="x", at=MUCH_LATER), "ADJUDICATION_REQUIRED")
        self.assertEqual(codes(self, m.set_lifecycle, ref, "RETAIN", by="CR", rationale="還要", at=MUCH_LATER), "REVIEW_AFTER_REQUIRED_LATER")
        m.set_lifecycle(ref, "RETAIN", by="CR", rationale="仍有鑑識價值", at=MUCH_LATER, review_after="2028-01-01T00:00:00Z")
        m.set_lifecycle(ref, "COMPRESS", by="CR", rationale="壓縮", at=MUCH_LATER)
        m.set_lifecycle(ref, "DELETE", by="CR", rationale="已無價值", at=MUCH_LATER)
        self.assertEqual(codes(self, m.set_lifecycle, ref, "RETAIN", by="CR", rationale="復活", at=MUCH_LATER, review_after="2029-01-01T00:00:00Z"), "LIFECYCLE_TRANSITION_INVALID")
        self.assertEqual(m.verify(), [])
        m.records[ref] = {**m.records[ref], "lifecycle": "RETAIN"}
        self.assertTrue(m.verify())

    # ---- 存取協定 ----
    def access(self):
        m, recs = self.manifest()
        return ag.ArchiveAccess(m, ag.AccessLog(self.tmp / "access.jsonl")), recs

    def test_access_log_write_failure_does_not_advance_memory(self):
        log_path = self.tmp / "access-failure.jsonl"
        access_log = ag.AccessLog(log_path)
        before = list(access_log.entries)
        with mock.patch.object(Path, "open", side_effect=OSError("simulated write failure")):
            with self.assertRaises(OSError):
                access_log.append(CR, "FORENSICS", "ARCHIVE", {"origin_path":"old/a.md"}, "GRANTED", None, [], NOW)
        self.assertEqual(access_log.entries, before)
        self.assertIsNone(access_log.head())
        self.assertFalse(log_path.exists())

    def test_retrieve_minimal_and_logged(self):
        acc, recs = self.access()
        r = acc.retrieve(CR, "HISTORICAL_RESEARCH", "ARCHIVE", {"origin_path": "old/a.md"}, now=NOW)
        self.assertEqual(r["source_refs"], [recs[0]["object_id"]])
        self.assertEqual((r["truth_status"], r["instruction_content"]), ("UNTRUSTED_CANDIDATE", False))
        self.assertEqual(r["distilled_result"][0]["distilled"], "方案 X 因 Y 失敗；不採用。")
        self.assertNotIn("舊研究 A", json.dumps(r, ensure_ascii=False))  # 不回原文
        self.assertTrue(r["evidence_refs"][0].startswith("release:ar1#old/a.md@sha256:"))
        self.assertEqual(r["access_record"], "ARCHIVE_ACCESS_RECORD:A00001")
        self.assertEqual(acc.log.verify(), [])
        self.assertEqual(ag.ArchiveAccess(acc.manifest, ag.AccessLog(self.tmp / "access.jsonl")).log.head(), acc.log.head())

    def test_retrieve_denials_are_logged(self):
        acc, recs = self.access()
        ex = {**CR, "role": "ROLE:EXECUTOR"}
        ver = {**CR, "role": "ROLE:VERIFIER"}
        T = {"origin_path": "old/a.md"}
        cases = [
            (ex, "FORENSICS", "ARCHIVE", T, "CAPABILITY_NOT_BOUND"), (ver, "FORENSICS", "ARCHIVE", T, "CAPABILITY_NOT_BOUND"),
            (CR, "FORENSICS", "ALL", T, "SCOPE_ALL_FORBIDDEN"), (CR, "FORENSICS", "ACTIVE", T, "NOT_ARCHIVE_SCOPE"),
            (CR, "", "ARCHIVE", T, "ARCHIVE_PURPOSE_REQUIRED"), (CR, "CURIOSITY", "ARCHIVE", T, "PURPOSE_UNKNOWN"),
            ({**CR, "agent_id": ""}, "FORENSICS", "ARCHIVE", T, "AGENT_AND_CAPABILITY_REQUIRED"),
            ({**CR, "capability_id": "CAP-VERIFY"}, "FORENSICS", "ARCHIVE", T, "CAPABILITY_NOT_BOUND"),
            ({**CR, "capability_id": "CAP-EXTRACT"}, "FORENSICS", "ARCHIVE", T, "CAPABILITY_NOT_ARCHIVE_QUERY"),
            (CR, "FORENSICS", "ARCHIVE", {}, "TARGET_REQUIRED"), (CR, "FORENSICS", "ARCHIVE", {"keyword": "X"}, "TARGET_REQUIRED"),
            (CR, "RECOVERY", "ARCHIVE", T, "NO_ELIGIBLE_RECORD"),  # a.md 不允許 RECOVERY（resource 維度）
            (CR, "FORENSICS", "ARCHIVE", {"object_id": "ARCHIVE_RECORD:none"}, "NO_ELIGIBLE_RECORD"),
        ]
        for req, purpose, scope, target, code in cases:
            self.assertEqual(codes(self, acc.retrieve, req, purpose, scope, target, now=NOW), code, (purpose, scope, target))
        stats = ag.access_stats(acc.log)
        self.assertEqual(stats["granted"], 0)
        self.assertEqual(sum(stats["denied"].values()), len(cases))
        self.assertEqual(stats["denied"]["CAPABILITY_NOT_BOUND"], 3)
        self.assertEqual(acc.log.verify(), [])

    def test_scope_grant_too_broad_and_deleted(self):
        acc, recs = self.access()
        pol = ag.policy()
        revoked = {**pol, "role_scope_grants": {**pol["role_scope_grants"], "ROLE:CONTROL_RESEARCH": ["ACTIVE", "WARM"]}}
        with mock.patch.object(ag, "policy", return_value=revoked):
            self.assertEqual(codes(self, acc.retrieve, CR, "FORENSICS", "ARCHIVE", {"origin_path": "old/a.md"}, now=NOW), "SCOPE_NOT_GRANTED")
        both = [self.plan("old/a.md", ("FORENSICS",)), self.plan("old/b.md", ("FORENSICS",))]
        m = ag.ArchiveManifest(ag.archive_assets(self.tmp, both, self.tmp / "b.zip", archive_ref="release:ar2", now=NOW))
        acc2 = ag.ArchiveAccess(m, ag.AccessLog())
        self.assertEqual(codes(self, acc2.retrieve, CR, "FORENSICS", "ARCHIVE", {"asset_class": "RESEARCH"}, now=NOW, max_records=1), "TARGET_TOO_BROAD")
        ref = next(iter(m.records))
        m.set_lifecycle(ref, "DELETE", by="CR", rationale="清", at=NOW)
        self.assertEqual(codes(self, acc2.retrieve, CR, "FORENSICS", "ARCHIVE", {"object_id": ref}, now=NOW), "NO_ELIGIBLE_RECORD")

    def test_archive_result_is_not_truth_until_chain(self):
        acc, recs = self.access()
        r = acc.retrieve(CR, "HISTORICAL_RESEARCH", "ARCHIVE", {"origin_path": "old/a.md"}, now=NOW)
        sid, raw = ag.result_as_source(r)
        _, segs = ki.build_source(sid, raw, location="archive://result", version="v1")
        ledger = ki.ReadingLedger(self.tmp / "l.jsonl", segs)
        store = kc.KnowledgeStore(ledger, {f"SOURCE:{sid}": ki.normalize(raw)})
        seg = segs[0]["object_id"]
        with self.assertRaises(ValueError):  # 未讀 Segment 不能產生 Observation
            store.add_observation("OBSERVED", "o", seg, producer="R", captured_at=NOW, quote="方案 X")
        ledger.append(seg, "READ", reader="R", timestamp=NOW)
        obs = store.add_observation("OBSERVED", "o", seg, producer="R", captured_at=NOW, quote="方案 X 因 Y 失敗")
        self.assertEqual(obs["object_id"].split(":")[0], "OBSERVATION")
        with self.assertRaises(ValueError):
            ag.result_as_source({**r, "truth_status": "CANONICAL"})

    def test_metrics_and_policy_consistency(self):
        self.assertEqual(ag.retrieval_precision(["a", "b"], {"a"}), 0.5)
        self.assertEqual(ag.retrieval_precision([], {"a"}), 1.0)
        p = ag.policy()
        binding = json.loads((ROOT / "P1-Central-Control/policy/role_capability_binding.v1.0.json").read_text(encoding="utf-8"))["roles"]
        self.assertEqual(set(p["role_scope_grants"]), set(binding))
        self.assertEqual([r for r, caps in binding.items() if p["archive_capability"] in caps], ["ROLE:CONTROL_RESEARCH"])
        self.assertEqual([r for r, s in p["role_scope_grants"].items() if "ARCHIVE" in s], ["ROLE:CONTROL_RESEARCH"])
        enum = json.loads((ROOT / "P1-Central-Control/schemas/archive_record.schema.json").read_text(encoding="utf-8"))["properties"]["allowed_purposes"]["items"]["enum"]
        self.assertEqual(enum, p["purposes"])
        self.assertTrue(set(p["normal_read"]) <= set(p["scopes"]) - {"ARCHIVE", "EXTERNAL"})
        self.assertEqual(ag.ArchiveManifest.load().verify(), [])


if __name__ == "__main__":
    unittest.main()
