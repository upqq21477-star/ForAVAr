import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "scripts"))
import hands_adapter as H  # noqa: E402


class HandsAdapterTest(unittest.TestCase):
    def test_scenarios_pass_and_are_deterministic(self):
        for key, (fp, fn) in H.SCENARIOS.items():
            a, b = fn(), fn()
            self.assertTrue(a["ok"], (key, [x for x in a["assertions"] if not x[1]]))
            self.assertEqual(a["digest"], b["digest"])

    def test_distinct_fast_path_ids(self):
        ids = [fp for fp, _ in H.SCENARIOS.values()]
        self.assertEqual(len(ids), len(set(ids)))

    def test_replay_equivalence(self):
        with tempfile.TemporaryDirectory() as d:
            rep = H.replay(2, Path(d))
        self.assertEqual(rep["equivalence_rate"], 1.0)

    def test_schema_rejects_extra_field(self):
        r = H._req("r1")
        r["surprise"] = 1
        self.assertIn("$.surprise:EXTRA", H.validate(r, "request"))

    def test_incomplete_is_not_failure(self):
        r = H.StubHands().execute(H._req("r2", params={"simulate": "incomplete"}))
        self.assertEqual((r["status"], r["evidence"]), ("INCOMPLETE", []))
        self.assertFalse(H.is_failure(r))
        self.assertTrue(H.is_failure(H.StubHands().execute(H._req("r3", params={"simulate": "fail"}))))

    def test_exchange_rejects_other_requests_result(self):
        req = H._req("r4")
        res = H.StubHands().execute(H._req("r5"))
        self.assertIn("REQUEST_ID_MISMATCH", H.check_exchange(req, res))


if __name__ == "__main__":
    unittest.main()
