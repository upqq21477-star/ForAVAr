#!/usr/bin/env python3
from __future__ import annotations

import os
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import command_layer  # noqa: E402
import minimal_closed_loop_runner as runner  # noqa: E402


import sys as _sys
from pathlib import Path as _Path

_sys.path.insert(0, str(_Path(__file__).resolve().parent))
from _quarantine import quarantined  # noqa: E402


class CommandExecutionBoundaryTests(unittest.TestCase):
    def make_packet(self, root: Path, *, next_command=None, next_action=None):
        artifact = root / "artifact.txt"
        artifact.write_text("artifact\n", encoding="utf-8")
        packet = {
            "work_id": "M32-C01-A-TEST",
            "phase": "M32",
            "completion_reason": "implementation",
            "outputs": [{"path": "artifact.txt"}],
            "acceptance": {
                "profile": "TEST_PRINT_PASS"
            },
            "execution_contract": {
                "version": "1.0",
                "steps": [
                    {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                    {"step_id": "ACCEPTANCE", "op": "RUN_ACCEPTANCE_COMMAND"},
                ],
            },
        }
        if next_command is not None:
            packet["next_command"] = next_command
        if next_action is not None:
            packet["next_action"] = next_action
        return packet

    def valid_action(self):
        return {
            "command_type": "RUN_REPOSITORY_TESTS",
            "args": {
                "tests": [
                    "P1-Central-Control/tests/test_progress_execution_contract.py",
                ]
            },
        }


    def test_command_layer_admits_typed_action(self):
        action = {
            "command_type": "RUN_REPOSITORY_TESTS",
            "args": {
                "tests": [
                    "P1-Central-Control/tests/test_actions_execution_closure.py",
                ]
            },
        }
        admitted = command_layer.admit_executable_action(action)
        self.assertEqual(admitted, action)

    def test_command_layer_rejects_arbitrary_argv(self):
        with self.assertRaisesRegex(ValueError, "ARBITRARY_ARGV_BLOCKED"):
            command_layer.admit_executable_action(
                {
                    "command_type": "RUN_REPOSITORY_TESTS",
                    "args": {},
                    "argv": [sys.executable, "-c", "print('unsafe')"],
                }
            )


    @quarantined("test_command_execution_boundary.CommandExecutionBoundaryTests.test_arbitrary_acceptance_command_is_blocked")
    def test_arbitrary_acceptance_command_is_blocked(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(root, next_action=self.valid_action())
            packet["acceptance"] = {
                "command": [
                    sys.executable,
                    "-c",
                    "open('escaped.txt', 'w').write('bad')",
                ]
            }
            result = runner.run_once(root, packet)
            self.assertEqual(result["status"], "BLOCK")
            self.assertEqual(
                result["contract_execution"]["step_results"][-1]["error"],
                "ARBITRARY_ACCEPTANCE_COMMAND_BLOCKED",
            )
            self.assertFalse((root / "escaped.txt").exists())

    @quarantined("test_command_execution_boundary.CommandExecutionBoundaryTests.test_output_path_traversal_is_blocked")
    def test_output_path_traversal_is_blocked(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(root, next_action=self.valid_action())
            packet["outputs"] = [{"path": "../escaped.txt"}]
            result = runner.run_once(root, packet)
            self.assertEqual(result["status"], "BLOCK")
            self.assertEqual(
                result["contract_execution"]["step_results"][-1]["error"],
                "OUTPUT_PATH_TRAVERSAL_BLOCKED",
            )

    def test_arbitrary_argv_is_blocked(self):
        action = {
            "command_type": "RUN_REPOSITORY_TESTS",
            "args": {"tests": ["P1-Central-Control/tests/test_actions_execution_closure.py"]},
            "argv": [sys.executable, "-c", "open('escaped.txt', 'w').write('bad')"],
        }
        result = runner.execute_typed_action(ROOT, action)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "ARBITRARY_ARGV_BLOCKED")

    def test_unknown_command_is_blocked(self):
        result = runner.execute_typed_action(
            ROOT,
            {
                "command_type": "RUN_SHELL",
                "args": {},
            },
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "UNKNOWN_COMMAND_TYPE")

    def test_valid_typed_action_really_executes(self):
        result = runner.execute_typed_action(ROOT, self.valid_action())
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["returncode"], 0)
        self.assertFalse(result["timed_out"])

    def test_invalid_typed_args_are_blocked(self):
        result = runner.execute_typed_action(
            ROOT,
            {
                "command_type": "RUN_REPOSITORY_TESTS",
                "args": {"tests": "P1-Central-Control/tests/test_actions_execution_closure.py"},
            },
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "TYPED_ARGS_INVALID")

    def test_path_traversal_is_blocked(self):
        result = runner.execute_typed_action(
            ROOT,
            {
                "command_type": "RUN_REPOSITORY_TESTS",
                "args": {"tests": ["P1-Central-Control/tests/../README.md"]},
            },
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "PATH_TRAVERSAL_BLOCKED")

    def test_symlink_escape_is_blocked(self):
        with tempfile.TemporaryDirectory() as temp:
            temp_root = Path(temp)
            test_root = temp_root / "P1-Central-Control/tests"
            test_root.mkdir(parents=True)
            outside = temp_root / "outside.py"
            outside.write_text("print('outside')\n", encoding="utf-8")
            link = test_root / "escape.py"
            link.symlink_to(outside)
            result = runner.execute_typed_action(
                temp_root,
                {
                    "command_type": "RUN_REPOSITORY_TESTS",
                    "args": {"tests": ["P1-Central-Control/tests/escape.py"]},
                },
            )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn(result["reason"], {"SYMLINK_ESCAPE_BLOCKED", "SYMLINK_OUTSIDE_TEST_SCOPE"})

    def test_credential_environment_is_not_forwarded(self):
        old = os.environ.get("AWS_SECRET_ACCESS_KEY")
        os.environ["AWS_SECRET_ACCESS_KEY"] = "should-not-forward"
        try:
            env = runner._minimal_environment()
        finally:
            if old is None:
                os.environ.pop("AWS_SECRET_ACCESS_KEY", None)
            else:
                os.environ["AWS_SECRET_ACCESS_KEY"] = old
        self.assertNotIn("AWS_SECRET_ACCESS_KEY", env)
        self.assertIn("PATH", env)

    def test_runner_never_executes_legacy_next_command(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(
                root,
                next_command=[
                    sys.executable,
                    "-c",
                    "(root := __import__('pathlib').Path('.')).joinpath('escaped.txt').write_text('bad')",
                ],
            )
            result = runner.run_once(root, packet)
            self.assertEqual(result["status"], "BLOCK")
            self.assertEqual(result["next_action_execution"]["reason"], "TRUSTED_TYPED_ACTION_REQUIRED")
            self.assertFalse((root / "escaped.txt").exists())

    def test_runner_consumes_typed_action(self):
        leaked = ROOT / "artifact.txt"  # 此測試以真 repo 根為工作目錄；結束時移除自己寫出的檔
        if not leaked.exists():
            self.addCleanup(lambda: leaked.unlink(missing_ok=True))
        packet = self.make_packet(ROOT, next_action=self.valid_action())
        result = runner.run_once(ROOT, packet)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["next_action"]["command_type"], "RUN_REPOSITORY_TESTS")
        self.assertEqual(result["next_action_execution"]["returncode"], 0)


if __name__ == "__main__":
    unittest.main(verbosity=2)
