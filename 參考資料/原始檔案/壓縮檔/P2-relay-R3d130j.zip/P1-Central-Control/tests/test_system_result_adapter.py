#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

from packet_layer import build_attempt, build_task_packet  # noqa: E402
from system_result_adapter import adapt  # noqa: E402


class SystemResultAdapterTests(unittest.TestCase):
    def task_packet(self) -> dict:
        segment = {
            "segment_id": "SEG-S01-001",
            "workflow_id": "WF-001",
            "system_id": "A1-S01",
            "skill_id": "A1-S01",
            "skill_version": "1.0",
            "objective": "test",
            "input_scope": "test",
            "input_refs": ["INPUT:TEST-001"],
            "requested_outputs": ["units", "elements"],
            "constraints": [],
            "stop_condition": ["done"],
            "failure_condition": ["fail"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["units", "elements"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "EXECUTION:exec-att-SEG-S01-001-1",
            "context_cohort_id": "COHORT-TEST",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }
        attempt = build_attempt(
            segment,
            attempt_number=1,
            started_at="2026-10-03T10:00:00+00:00",
        )
        return build_task_packet(segment, attempt)

    def execution(self) -> dict:
        return {
            "execution_record_ref": "EXECUTION:exec-att-SEG-S01-001-1",
            "start_time": "2026-10-03T10:00:00+00:00",
        }

    def test_complete_system_result_becomes_canonical_packet_with_bound_outputs(self):
        task = self.task_packet()
        result, evidence, provenance = adapt(
            task,
            {
                "segment_id": "SEG-S01-001",
                "system_id": "A1-S01",
                "status": "WORK_COMPLETE",
                "outputs": {
                    "units": [],
                    "elements": [],
                },
                "evidence_refs": [],
                "provenance_refs": [],
                "gaps": [],
                "unresolved": [],
                "trace": ["F01", "F02"],
                "completion": {"segment_complete": True, "handoff_ready": True},
                "observed_usage": {
                    "model_calls": 0,
                    "tool_calls": 0,
                    "wall_time_ms": 3,
                    "usage_observed": True,
                },
            },
            self.execution(),
        )
        self.assertEqual(result["decision_code"], "WORK_COMPLETE")
        self.assertEqual(len(result["output_refs"]), 2)
        self.assertEqual(len(evidence["records"]), 1)
        self.assertEqual(len(provenance["records"]), 1)

    def test_output_refs_are_deterministic_for_same_task_and_outputs(self):
        task = self.task_packet()
        payload = {
            "segment_id": "SEG-S01-001",
            "system_id": "A1-S01",
            "status": "WORK_COMPLETE",
            "outputs": {"units": [], "elements": []},
            "evidence_refs": [],
            "provenance_refs": [],
            "gaps": [],
            "unresolved": [],
            "trace": ["F01", "F02"],
            "completion": {"segment_complete": True, "handoff_ready": True},
            "observed_usage": {
                "model_calls": 0,
                "tool_calls": 0,
                "wall_time_ms": 3,
                "usage_observed": True,
            },
        }
        first = adapt(task, payload, self.execution())[0]
        second = adapt(task, payload, self.execution())[0]
        self.assertEqual(first["output_refs"], second["output_refs"])
        self.assertEqual(first["result_id"], second["result_id"])

    def test_complete_result_rejects_missing_requested_output(self):
        task = self.task_packet()
        with self.assertRaises(ValueError):
            adapt(
                task,
                {
                    "segment_id": "SEG-S01-001",
                    "system_id": "A1-S01",
                    "status": "WORK_COMPLETE",
                    "outputs": {"units": []},
                    "evidence_refs": [],
                    "provenance_refs": [],
                    "gaps": [],
                    "unresolved": [],
                    "trace": [],
                    "completion": {"segment_complete": True, "handoff_ready": True},
                    "observed_usage": {
                        "model_calls": 0,
                        "tool_calls": 0,
                        "wall_time_ms": 1,
                        "usage_observed": True,
                    },
                },
                self.execution(),
            )

    def test_schema_requires_observed_usage(self):
        task = self.task_packet()
        payload = {
            "segment_id": "SEG-S01-001",
            "system_id": "A1-S01",
            "status": "WORK_COMPLETE",
            "outputs": {"units": [], "elements": []},
            "evidence_refs": [],
            "provenance_refs": [],
            "gaps": [],
            "unresolved": [],
            "trace": [],
            "completion": {"segment_complete": True, "handoff_ready": True},
        }
        with self.assertRaises(ValueError):
            adapt(task, payload, self.execution())

    def test_missing_usage_observation_blocks_execution_truth(self):
        task = self.task_packet()
        with self.assertRaises(ValueError):
            adapt(
                task,
                {
                    "segment_id": "SEG-S01-001",
                    "system_id": "A1-S01",
                    "status": "WORK_COMPLETE",
                    "outputs": {
                        "units": [],
                        "elements": [],
                    },
                    "evidence_refs": [],
                    "provenance_refs": [],
                    "gaps": [],
                    "unresolved": [],
                    "trace": [],
                    "completion": {"segment_complete": True, "handoff_ready": True},
                    "observed_usage": {
                        "model_calls": 0,
                        "tool_calls": 0,
                        "wall_time_ms": 1,
                        "usage_observed": False,
                    },
                },
                self.execution(),
            )


if __name__ == "__main__":
    unittest.main()
