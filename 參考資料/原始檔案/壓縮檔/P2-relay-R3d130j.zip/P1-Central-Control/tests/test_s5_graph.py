"""S5 batch 2: graph_check (CAP-GRAPH).  SIMULATED_PASS.  Pure function; interruption = rerun."""
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
import capability_run as cr  # noqa: E402
import graph_check as gc  # noqa: E402


def e(a, b, src="S1"):
    return {"from": a, "to": b, "relation": "depends", "source": src}


DAG = [e("a", "b"), e("b", "c"), e("a", "c")]
NODES = ["a", "b", "c"]


class Check(unittest.TestCase):
    def test_acyclic_ok_and_topo_valid(self):
        r = gc.check(DAG, NODES)
        self.assertEqual((r["status"], r["cycle"]), ("OK", None))
        pos = {n: i for i, n in enumerate(r["topo_order"])}
        self.assertTrue(all(pos[x["from"]] < pos[x["to"]] for x in DAG))

    def test_cycle_returns_one_closed_witness(self):
        r = gc.check(DAG + [e("c", "a")], NODES)
        w = r["cycle"]
        self.assertEqual((r["status"], w[0] == w[-1], len(w) >= 3), ("PARTIAL", True, True))
        self.assertTrue(all({"from": a, "to": b} in [{"from": x["from"], "to": x["to"]} for x in DAG + [e("c", "a")]] for a, b in zip(w, w[1:])))
        self.assertEqual(gc.check([e("a", "a")], ["a"])["cycle"], ["a", "a"])  # self loop

    def test_missing_endpoint_rejected_before_graphlib(self):
        with mock.patch.object(gc.graphlib, "TopologicalSorter", side_effect=AssertionError("graphlib reached")):
            r = gc.check(DAG + [e("c", "ghost")], NODES)
        self.assertEqual((r["status"], r["graph"], r["bad"]), ("REJECTED", None, [{"index": 3, "reason": "ENDPOINT_NOT_IN_NODES", "node": "ghost"}]))

    def test_bad_shape_whole_batch_rejected(self):
        r = gc.check([e("a", "b"), "x", {"from": "a", "to": "b"}, e("", "b")], NODES)
        self.assertEqual((r["status"], [b["index"] for b in r["bad"]], r["graph"]), ("REJECTED", [1, 2, 3], None))

    def test_limit_incomplete_no_truncation(self):
        r = gc.check([e("a", "b")] * 5, NODES, max_edges=4)
        self.assertEqual((r["status"], r["reason"], r["graph"]), ("INCOMPLETE", "TOO_MANY_EDGES", None))

    def test_path_query(self):
        self.assertEqual(gc.path(DAG, "a", "c"), ["a", "c"])
        self.assertEqual(gc.path(DAG, "c", "a"), None)
        self.assertEqual(gc.path(DAG, "a", "a"), ["a"])

    def test_rerun_same_and_no_state_after_interrupt(self):
        with mock.patch.object(gc.graphlib, "TopologicalSorter", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                gc.check(DAG, NODES)
        self.assertEqual(gc.check(DAG, NODES), gc.check(DAG, NODES))


class Measured(unittest.TestCase):
    def test_measured_and_mutation_caught(self):
        self.assertEqual(cr.check("CAP-GRAPH"), {"capability": "CAP-GRAPH", "ok": True, "runner_ok": True, "providers_missing": []})
        self.assertEqual(cr.check("CAP-GRAPH", {"graph": lambda: True})["providers_missing"], ["graph_check"])
        with mock.patch.object(gc, "_edge_errors", lambda edges, nodes: []):  # endpoint guard removed
            try:
                caught = not cr.check("CAP-GRAPH")["runner_ok"]
            except Exception:
                caught = True
        self.assertTrue(caught)


if __name__ == "__main__":
    unittest.main()
