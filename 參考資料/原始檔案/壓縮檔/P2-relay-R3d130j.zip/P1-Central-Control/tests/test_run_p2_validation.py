from __future__ import annotations

import ast
import contextlib
import io
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import run_p2_validation as runner


# 這兩個案例的暫存根目錄沒有 P1-CURRENT.json／批次清單；批次閘門加入後會先拋 BATCH_FILE_MISSING，
# 蓋掉案例要測的 reason_code／退出碼。閘門本身由 test_feature_batch_orchestrator 驗證，這裡以
# 「無批次清單」的相容回傳隔離（同 validate_final_test_gate 對舊夾具的 NOT_REQUIRED 形狀）。
NO_BATCH_GATE = {"status": "NOT_REQUIRED", "required": False, "test_roster": [], "expected_test_method_count": None}


class ValidationRunnerContractTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "P1-Central-Control").mkdir()

    def test_count_parser_reads_unittest_summary(self):
        step = {
            "stdout_tail": "",
            "stderr_tail": "....................\nRan 27 tests in 0.120s\n\nOK\n",
        }
        self.assertEqual(runner.test_count_from_output(step), 27)

    def test_declared_suite_counts_match_source_methods(self):
        for test_ref, expected_count in runner.EXPECTED_TEST_COUNTS.items():
            with self.subTest(test_ref=test_ref):
                source_path = runner.path_ref(ROOT, test_ref)
                tree = ast.parse(source_path.read_text(encoding="utf-8"), filename=test_ref)
                actual_count = sum(
                    1 for node in ast.walk(tree)
                    if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                    and node.name.startswith("test_")
                )
                self.assertEqual(actual_count, expected_count, test_ref)

        self.assertEqual(runner._current_stage_work_unit_id({"id": "STAGE-ID"}), "STAGE-ID")
        self.assertEqual(
            runner._current_stage_work_unit_id({"id": "STAGE-ID", "slice_id": "SLICE-ID"}),
            "SLICE-ID",
        )
        self.assertEqual(
            runner._current_stage_work_unit_id(
                {"id": "STAGE-ID", "slice_id": "SLICE-ID", "work_unit_id": ""}
            ),
            "SLICE-ID",
        )
        self.assertIsNone(
            runner._current_stage_work_unit_id(
                {"id": "STAGE-ID", "slice_id": "SLICE-ID", "work_unit_id": "   "}
            )
        )
        self.assertEqual(
            runner._current_stage_work_unit_id(
                {"id": "STAGE-ID", "slice_id": "SLICE-ID", "work_unit_id": "WORK-UNIT"}
            ),
            "WORK-UNIT",
        )
        self.assertIsNone(runner._current_stage_work_unit_id({}))
        self.assertIsNone(
            runner._current_stage_work_unit_id(
                {"work_unit_id": ["MALFORMED"], "slice_id": "SLICE-ID", "id": "STAGE-ID"}
            )
        )

    def test_count_parser_requires_a_summary(self):
        step = {"stdout_tail": "OK", "stderr_tail": ""}
        self.assertIsNone(runner.test_count_from_output(step))


    def test_current_schema_validation_rejects_missing_stage_observation(self):
        current = json.loads((ROOT / "P1-CURRENT.json").read_text(encoding="utf-8"))
        current["current_stage"].pop("latest_runtime_observation", None)
        with self.assertRaisesRegex(
            runner.ValidationBlocked, "VALIDATION_CURRENT_SCHEMA_INVALID"
        ):
            runner.validate_current_schema(ROOT, current)

        # The authoritative Current, selected Request, and Active Work schemas
        # must all be executed during preflight, before any regression subprocess.
        with mock.patch.object(
            runner, "validate_json_schema", wraps=runner.validate_json_schema
        ) as validate_schema:
            preflight_result = runner.preflight(ROOT)
        self.assertEqual(preflight_result["status"], "PREFLIGHT_PASS")
        validated_schema_refs = {call.args[2] for call in validate_schema.call_args_list}
        self.assertIn("P1-Central-Control/schemas/p1_current.schema.json", validated_schema_refs)
        self.assertIn("P1-Central-Control/schemas/operational_pack_request.schema.json", validated_schema_refs)
        self.assertIn("P1-Central-Control/schemas/operational_work_unit.schema.json", validated_schema_refs)


    def test_pinned_dependencies_match_only_exact_versions(self):
        lock = self.root / "P1-Central-Control" / "requirements-runtime.txt"
        lock.write_text("jsonschema==4.26.0\nattrs==26.1.0\n", encoding="utf-8")

        def fake_version(name):
            return {"jsonschema": "4.26.0", "attrs": "26.1.0"}[name]

        with mock.patch.object(runner.importlib.metadata, "version", side_effect=fake_version):
            result = runner.check_pinned_dependencies(self.root)
        self.assertEqual(result["status"], "MATCH")
        self.assertTrue(all(item["matches"] for item in result["packages"]))

    def test_pinned_dependency_mismatch_is_not_silently_accepted(self):
        lock = self.root / "P1-Central-Control" / "requirements-runtime.txt"
        lock.write_text("jsonschema==4.26.0\n", encoding="utf-8")
        with mock.patch.object(runner.importlib.metadata, "version", return_value="4.25.0"):
            result = runner.check_pinned_dependencies(self.root)
        self.assertEqual(result["status"], "MISMATCH")
        self.assertFalse(result["packages"][0]["matches"])

    def test_missing_dependency_is_reported_as_mismatch(self):
        lock = self.root / "P1-Central-Control" / "requirements-runtime.txt"
        lock.write_text("jsonschema==4.26.0\n", encoding="utf-8")
        with mock.patch.object(
            runner.importlib.metadata,
            "version",
            side_effect=runner.importlib.metadata.PackageNotFoundError,
        ):
            result = runner.check_pinned_dependencies(self.root)
        self.assertEqual(result["status"], "MISMATCH")
        self.assertFalse(result["packages"][0]["present"] if "present" in result["packages"][0] else result["packages"][0]["matches"])

    def test_dependency_mismatch_blocks_before_schema_preflight(self):
        output = io.StringIO()
        with (
            mock.patch.object(runner, "ROOT", self.root),
            mock.patch.object(runner, "validate_final_test_gate", return_value=NO_BATCH_GATE),
            mock.patch.object(runner.sys, "argv", ["run_p2_validation.py", "--mode", "simulation"]),
            mock.patch.object(runner.sys, "version_info", (3, 11, 0)),
            mock.patch.object(runner.sys, "version", "3.11.0"),
            mock.patch.object(
                runner.subprocess,
                "run",
                return_value=mock.Mock(returncode=128, stdout="", stderr="not a git checkout"),
            ),
            mock.patch.object(
                runner,
                "check_pinned_dependencies",
                return_value={
                    "status": "MISMATCH",
                    "packages": [{"name": "jsonschema", "expected_version": "4.26.0", "actual_version": None, "matches": False}],
                    "detail": "jsonschema missing",
                },
            ),
            mock.patch.object(runner, "preflight", side_effect=AssertionError("preflight must not import missing dependencies")) as preflight,
            contextlib.redirect_stdout(output),
        ):
            exit_code = runner.main()

        report = json.loads(output.getvalue())
        self.assertEqual(exit_code, 2)
        self.assertEqual(report["reason_code"], "PINNED_DEPENDENCY_MISMATCH")
        preflight.assert_not_called()

    def test_path_ref_rejects_parent_traversal(self):
        with self.assertRaisesRegex(runner.ValidationBlocked, "VALIDATION_PATH_FORBIDDEN"):
            runner.path_ref(self.root, "../outside.txt")

    def test_report_writer_requires_reports_subtree(self):
        with self.assertRaisesRegex(runner.ValidationBlocked, "VALIDATION_REPORT_PATH_FORBIDDEN"):
            runner.write_report(self.root, "README.md", {"status": "PASS"})
        self.assertFalse((self.root / "README.md").exists())


    def test_invalid_report_path_blocks_before_any_execution(self):
        output = io.StringIO()
        with (
            mock.patch.object(
                runner.sys, "argv",
                ["run_p2_validation.py", "--mode", "integration", "--report", "README.md"],
            ),
            mock.patch.object(runner, "run_step") as run_step,
            contextlib.redirect_stdout(output),
        ):
            exit_code = runner.main()
        report = json.loads(output.getvalue())
        self.assertEqual(exit_code, 2)
        self.assertEqual(report["reason_code"], "VALIDATION_REPORT_PATH_FORBIDDEN")
        run_step.assert_not_called()


    def test_report_writer_rejects_symlink_redirect(self):
        report_root = self.root / "P1-Central-Control" / "acceptance" / "reports"
        report_root.mkdir(parents=True)
        readme = self.root / "README.md"
        readme.write_text("must not be overwritten\\n", encoding="utf-8")
        (report_root / "redirect.json").symlink_to(readme)
        with self.assertRaisesRegex(runner.ValidationBlocked, "VALIDATION_REPORT_PATH_FORBIDDEN"):
            runner.write_report(
                self.root,
                "P1-Central-Control/acceptance/reports/redirect.json",
                {"status": "INTRUSION"},
            )
        self.assertEqual(readme.read_text(encoding="utf-8"), "must not be overwritten\\n")

        outside = self.root / "outside-reports-subtree"
        outside.mkdir()
        (report_root / "redirect-parent").symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(runner.ValidationBlocked, "VALIDATION_REPORT_PATH_FORBIDDEN"):
            runner.write_report(
                self.root,
                "P1-Central-Control/acceptance/reports/redirect-parent/child.json",
                {"status": "INTRUSION"},
            )
        self.assertFalse((outside / "child.json").exists())


    def test_report_directory_or_non_directory_ancestor_blocks_before_execution(self):
        report_root = self.root / "P1-Central-Control" / "acceptance" / "reports"
        report_root.mkdir(parents=True)
        (report_root / "existing-dir").mkdir()
        (report_root / "not-a-directory").write_text("not a directory", encoding="utf-8")

        invalid_report_refs = [
            "P1-Central-Control/acceptance/reports/existing-dir",
            "P1-Central-Control/acceptance/reports/not-a-directory/child.json",
        ]
        for report_ref in invalid_report_refs:
            with self.subTest(report_ref=report_ref):
                output = io.StringIO()
                with (
                    mock.patch.object(runner, "ROOT", self.root),
                    mock.patch.object(
                        runner.sys, "argv",
                        ["run_p2_validation.py", "--mode", "integration", "--report", report_ref],
                    ),
                    mock.patch.object(runner, "run_step") as run_step,
                    contextlib.redirect_stdout(output),
                ):
                    exit_code = runner.main()
                report = json.loads(output.getvalue())
                self.assertEqual(exit_code, 2)
                self.assertEqual(report["reason_code"], "VALIDATION_REPORT_PATH_FORBIDDEN")
                run_step.assert_not_called()

    def test_report_writer_accepts_report_inside_reports_subtree(self):
        report_ref = "P1-Central-Control/acceptance/reports/result.json"
        report = {"status": "INCOMPLETE", "reason_code": "TEST_FIXTURE"}
        runner.write_report(self.root, report_ref, report)
        written = json.loads((self.root / report_ref).read_text(encoding="utf-8"))
        self.assertEqual(written, report)

    def test_runner_requires_zero_exit_and_expected_semantic_status(self):
        result = runner.run_step(
            self.root,
            "intentional-negative-control",
            [sys.executable, "-c", "print('controlled failure'); raise SystemExit(7)"],
        )
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["return_code"], 7)
        self.assertIn("controlled failure", result["stdout_tail"])

        valid_output = {
            "name": "valid-check-only-result",
            "status": "PASS",
            "stdout_tail": '{"status":"READY","write_performed":false}',
            "stderr_tail": "",
        }
        self.assertEqual(
            runner.parse_json_result(valid_output, expected_status="READY")["write_performed"],
            False,
        )
        wrong_semantic_status = {
            **valid_output,
            "name": "unexpected-semantic-status",
            "stdout_tail": '{"status":"READY"}',
        }
        with self.assertRaisesRegex(
            runner.ValidationBlocked, "VALIDATION_UNEXPECTED_RESULT_STATUS"
        ):
            runner.parse_json_result(wrong_semantic_status, expected_status="VERIFIED")

        blocked_but_zero_exit = {
            "name": "operational-pack-verify-temporary",
            "status": "PASS",
            "return_code": 0,
            "stdout_tail": '{"status":"BLOCKED","reason_code":"PACK_SOURCE_STALE","detail":"manifest mismatch"}',
            "stderr_tail": "",
        }
        with self.assertRaisesRegex(
            runner.ValidationBlocked, "VALIDATION_UNEXPECTED_RESULT_STATUS"
        ) as blocked_error:
            runner.parse_json_result(
                blocked_but_zero_exit, expected_status="VERIFIED"
            )
        self.assertEqual(blocked_but_zero_exit["result_status"], "BLOCKED")
        self.assertEqual(
            blocked_but_zero_exit["cli_reason_code"], "PACK_SOURCE_STALE"
        )
        self.assertEqual(
            runner.classify_validation_block(blocked_error.exception),
            ("INTEGRATION_FAIL", "operational-pack-verify-temporary"),
        )
        blocked_report = {"steps": [blocked_but_zero_exit]}
        runner.mark_failed_result_step(
            blocked_report,
            "operational-pack-verify-temporary",
            blocked_error.exception,
            "INTEGRATION_FAIL",
        )
        self.assertEqual(
            blocked_report["steps"][0]["status"], "RESULT_CONTRACT_FAIL"
        )
        self.assertEqual(
            blocked_report["steps"][0]["process_status"], "PASS"
        )

        # Even a caller that omits expected_status must not accept a
        # zero-exit BLOCKED object as a successful result.
        blocked_without_expected_status = {
            "name": "operational-pack-verify-temporary",
            "status": "PASS",
            "return_code": 0,
            "stdout_tail": '{"status":"BLOCKED","reason_code":"PACK_STALE_CURRENT","detail":"fingerprint mismatch"}',
            "stderr_tail": "",
        }
        with self.assertRaisesRegex(
            runner.ValidationBlocked, "VALIDATION_UNEXPECTED_RESULT_STATUS"
        ) as unchecked_block:
            runner.parse_json_result(blocked_without_expected_status)
        self.assertIn("PACK_STALE_CURRENT", unchecked_block.exception.detail)
        self.assertEqual(
            runner.classify_validation_block(unchecked_block.exception),
            ("INTEGRATION_FAIL", "operational-pack-verify-temporary"),
        )

        # A present status must be a non-empty string; non-hashable values
        # such as lists/dicts must not escape into generic TypeError handling.
        for payload, expected_value in (
            ('{"status":["BLOCKED"],"reason_code":"CLI_STATUS_TYPE_ERROR","detail":"status must be string"}', ["BLOCKED"]),
            ('{"status":{"kind":"BLOCKED"}}', {"kind": "BLOCKED"}),
            ('{"status":""}', ""),
            ('{"status":"   "}', "   "),
            ('{"detail":"status omitted"}', None),
        ):
            with self.subTest(invalid_status=payload):
                invalid_status_step = {
                    "name": "operational-pack-verify-temporary",
                    "status": "PASS",
                    "return_code": 0,
                    "stdout_tail": payload,
                    "stderr_tail": "",
                }
                with self.assertRaisesRegex(
                    runner.ValidationBlocked, "VALIDATION_UNEXPECTED_RESULT_STATUS"
                ) as status_error:
                    runner.parse_json_result(
                        invalid_status_step, expected_status="VERIFIED"
                    )
                self.assertEqual(
                    invalid_status_step["result_status"], expected_value
                )
                if expected_value == ["BLOCKED"]:
                    self.assertEqual(
                        invalid_status_step["cli_reason_code"], "CLI_STATUS_TYPE_ERROR"
                    )
                    self.assertEqual(
                        invalid_status_step["cli_detail"], "status must be string"
                    )
                self.assertEqual(
                    runner.classify_validation_block(status_error.exception),
                    ("INTEGRATION_FAIL", "operational-pack-verify-temporary"),
                )
                status_report = {"steps": [invalid_status_step]}
                runner.mark_failed_result_step(
                    status_report,
                    "operational-pack-verify-temporary",
                    status_error.exception,
                    "INTEGRATION_FAIL",
                )
                self.assertEqual(
                    status_report["steps"][0]["status"], "RESULT_CONTRACT_FAIL"
                )
                self.assertEqual(
                    status_report["steps"][0]["process_status"], "PASS"
                )

        # A zero-exit process with malformed or non-object JSON also violates
        # the CLI contract; its step must not be left marked PASS.
        for payload, expected_code in (
            ("not-json", "VALIDATION_COMMAND_OUTPUT_NOT_JSON"),
            ('["not", "an", "object"]', "VALIDATION_COMMAND_OUTPUT_NOT_OBJECT"),
        ):
            with self.subTest(expected_code=expected_code):
                invalid_output_step = {
                    "name": "operational-pack-verify-temporary",
                    "status": "PASS",
                    "return_code": 0,
                    "stdout_tail": payload,
                    "stderr_tail": "",
                }
                with self.assertRaises(runner.ValidationBlocked) as output_error:
                    runner.parse_json_result(
                        invalid_output_step, expected_status="VERIFIED"
                    )
                self.assertEqual(output_error.exception.code, expected_code)
                classified, failed_step = runner.classify_validation_block(
                    output_error.exception
                )
                self.assertEqual(
                    (classified, failed_step),
                    ("INTEGRATION_FAIL", "operational-pack-verify-temporary"),
                )
                invalid_report = {"steps": [invalid_output_step]}
                runner.mark_failed_result_step(
                    invalid_report,
                    failed_step,
                    output_error.exception,
                    classified,
                )
                self.assertEqual(
                    invalid_report["steps"][0]["status"], "RESULT_CONTRACT_FAIL"
                )
                self.assertEqual(
                    invalid_report["steps"][0]["process_status"], "PASS"
                )

        self.assertEqual(
            runner.classify_validation_block(
                runner.ValidationBlocked(
                    "VALIDATION_UNEXPECTED_RESULT_STATUS",
                    "operational-pack-check-only: expected=[READY] actual='OTHER'",
                )
            ),
            ("SIMULATION_FAIL", "operational-pack-check-only"),
        )
        self.assertEqual(
            runner.classify_validation_block(
                runner.ValidationBlocked(
                    "VALIDATION_UNEXPECTED_RESULT_STATUS",
                    "operational-pack-verify-temporary: expected=[VERIFIED] actual='OTHER'",
                )
            ),
            ("INTEGRATION_FAIL", "operational-pack-verify-temporary"),
        )
        report = {
            "steps": [{
                "name": "operational-pack-check-only",
                "status": "PASS",
                "return_code": 0,
                "stdout_tail": '{"status":"OTHER"}',
            }]
        }
        failure = runner.ValidationBlocked(
            "VALIDATION_UNEXPECTED_RESULT_STATUS",
            "operational-pack-check-only: expected=[READY] actual='OTHER'",
        )
        runner.mark_failed_result_step(
            report, "operational-pack-check-only", failure, "SIMULATION_FAIL"
        )
        self.assertEqual(report["steps"][0]["process_status"], "PASS")
        self.assertEqual(report["steps"][0]["status"], "RESULT_CONTRACT_FAIL")
        self.assertEqual(report["steps"][0]["failure_class"], "SIMULATION_FAIL")
        self.assertEqual(
            report["steps"][0]["reason_code"],
            "VALIDATION_UNEXPECTED_RESULT_STATUS",
        )

        # Canonical write evidence is tri-state: invoking the writer does not
        # prove it wrote (or did not write) when its output contract fails.
        write_report = {
            "canonical_pack_write_attempted": False,
            "canonical_pack_write_occurred": None,
            "canonical_pack_write_outcome": "NOT_ATTEMPTED",
        }
        self.assertEqual(runner.REPORT_SCHEMA_VERSION, "2.1")
        runner.mark_canonical_write_started(write_report)
        self.assertTrue(write_report["canonical_pack_write_attempted"])
        self.assertIsNone(write_report["canonical_pack_write_occurred"])
        self.assertEqual(write_report["canonical_pack_write_outcome"], "UNKNOWN")

        runner.record_canonical_write_result(write_report, {"status": "WRITTEN"})
        self.assertTrue(write_report["canonical_pack_write_occurred"])
        self.assertEqual(write_report["canonical_pack_write_outcome"], "WRITTEN")

        unchanged_report = {
            "canonical_pack_write_attempted": False,
            "canonical_pack_write_occurred": None,
            "canonical_pack_write_outcome": "NOT_ATTEMPTED",
        }
        runner.mark_canonical_write_started(unchanged_report)
        runner.record_canonical_write_result(unchanged_report, {"status": "UNCHANGED"})
        self.assertFalse(unchanged_report["canonical_pack_write_occurred"])
        self.assertEqual(unchanged_report["canonical_pack_write_outcome"], "UNCHANGED")

        unknown_report = {
            "canonical_pack_write_attempted": False,
            "canonical_pack_write_occurred": None,
            "canonical_pack_write_outcome": "NOT_ATTEMPTED",
        }
        runner.mark_canonical_write_started(unknown_report)
        with self.assertRaisesRegex(
            runner.ValidationBlocked, "VALIDATION_UNEXPECTED_RESULT_STATUS"
        ):
            runner.record_canonical_write_result(unknown_report, {"status": "BLOCKED"})
        self.assertIsNone(unknown_report["canonical_pack_write_occurred"])
        self.assertEqual(unknown_report["canonical_pack_write_outcome"], "UNKNOWN")
        with self.assertRaisesRegex(
            runner.ValidationBlocked, "VALIDATION_UNEXPECTED_RESULT_STATUS"
        ):
            runner.record_canonical_write_result(unknown_report, {"status": ["WRITTEN"]})
        self.assertIsNone(unknown_report["canonical_pack_write_occurred"])
        self.assertEqual(unknown_report["canonical_pack_write_outcome"], "UNKNOWN")

        # A successful validation must not be emitted as PASS if the requested
        # evidence report cannot be persisted.
        report_ref = "P1-Central-Control/acceptance/reports/result.json"
        for test_ref in runner.TEST_FILES:
            test_path = runner.path_ref(self.root, test_ref)
            test_path.parent.mkdir(parents=True, exist_ok=True)
            test_path.write_text("# test fixture path\n", encoding="utf-8")
        (self.root / "P1-Central-Control/acceptance/reports").mkdir(
            parents=True, exist_ok=True
        )
        simulated_steps = []
        for test_ref, expected_count in runner.EXPECTED_TEST_COUNTS.items():
            simulated_steps.append({
                "name": test_ref,
                "status": "PASS",
                "return_code": 0,
                "elapsed_seconds": 0.001,
                "stdout_tail": f"Ran {expected_count} tests in 0.001s\nOK\n",
                "stderr_tail": "",
            })
        simulated_steps.append({
            "name": "operational-pack-check-only",
            "status": "PASS",
            "return_code": 0,
            "elapsed_seconds": 0.001,
            "stdout_tail": '{"status":"BLOCKED","reason_code":"CHECK_ONLY_BLOCKED","detail":"invalid workspace"}',
            "stderr_tail": "",
        })
        output = io.StringIO()
        with (
            mock.patch.object(runner, "ROOT", self.root),
            mock.patch.object(runner, "validate_final_test_gate", return_value=NO_BATCH_GATE),
            mock.patch.object(
                runner.sys, "argv",
                ["run_p2_validation.py", "--mode", "simulation", "--report", report_ref],
            ),
            mock.patch.object(runner.sys, "version_info", (3, 11, 0)),
            mock.patch.object(runner.sys, "version", "3.11.0"),
            mock.patch.object(
                runner.subprocess, "run",
                return_value=mock.Mock(returncode=128, stdout="", stderr="not a checkout"),
            ),
            mock.patch.object(
                runner, "check_pinned_dependencies",
                return_value={"status": "MATCH", "packages": []},
            ),
            mock.patch.object(
                runner, "preflight", return_value={"status": "PREFLIGHT_PASS"}
            ),
            mock.patch.object(runner, "run_step", side_effect=simulated_steps),
            mock.patch.object(
                runner, "write_report", side_effect=OSError("disk full")
            ),
            contextlib.redirect_stdout(output),
        ):
            exit_code = runner.main()
        failed_report = json.loads(output.getvalue())
        self.assertEqual(exit_code, 3)
        self.assertEqual(failed_report["status"], "REPORT_WRITE_FAIL")
        self.assertEqual(
            failed_report["validation_status_before_report_write"], "SIMULATION_FAIL"
        )
        self.assertEqual(
            failed_report["validation_reason_code_before_report_write"],
            "VALIDATION_UNEXPECTED_RESULT_STATUS",
        )
        self.assertIn(
            "CHECK_ONLY_BLOCKED",
            failed_report["validation_detail_before_report_write"],
        )
        self.assertEqual(
            failed_report["reason_code"], "VALIDATION_REPORT_WRITE_FAILED"
        )
        self.assertEqual(failed_report["report_write_status"], "FAILED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
