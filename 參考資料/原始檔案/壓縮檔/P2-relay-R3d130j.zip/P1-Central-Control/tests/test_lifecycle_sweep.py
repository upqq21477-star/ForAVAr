#!/usr/bin/env python3
"""U-RETIRE / U-ISSUE：單一 lifecycle_sweep 引擎的反例、證據、批次、不動點、棘輪、問題登錄與真實 repo 回歸。"""
from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import lifecycle_sweep as ls  # noqa: E402

C = "P1-Central-Control/"
TODAY = date(2026, 10, 8)


def _w(root: Path, rel: str, text: str = "x") -> None:
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")


def make_repo(declared=None) -> Path:
    root = Path(tempfile.mkdtemp(prefix="p1-sweep-"))
    policy = json.loads((ROOT / ls.POLICY_PATH).read_text(encoding="utf-8"))
    policy["declared_entries"] = declared or []
    _w(root, ls.POLICY_PATH, json.dumps(policy))
    _w(root, C + "policy/repo_budget.json", json.dumps({"version": "1.0", "budgets": [
        {"path": "", "max_bytes": 10**9, "target_bytes": 10**9}]}))
    for name in ("issue_register.json", "update_learning_ledger.json"):
        _w(root, C + "canonical/" + name, (ROOT / C / "canonical" / name).read_text(encoding="utf-8"))
    _w(root, "README.md", "入口 P1-Central-Control/scripts/live.py")
    _w(root, "P1-CURRENT.json", "{}")
    _w(root, ".github/workflows/ci.yml", "run: python P1-Central-Control/scripts/live.py")
    _w(root, C + "scripts/live.py", "import live_dep\n")
    _w(root, C + "scripts/live_dep.py", "x = 1\n")
    _w(root, C + "scripts/dead.py", "import dead_dep\n")
    _w(root, C + "scripts/dead_dep.py", "x = 1\n")
    _w(root, C + "schemas/dead.schema.json", "{}")
    _w(root, C + "tests/test_live.py", "import live\nFIX = 'fixtures/live_fixture.json'\n")
    _w(root, C + "tests/test_dead.py", "import dead\n")
    _w(root, C + "tests/test_dead_dep.py", "import dead_dep\n")
    _w(root, C + "tests/_unused_helper.py", "pass\n")
    _w(root, C + "fixtures/live_fixture.json", "{}")
    return root


def cands(root: Path) -> dict[str, dict]:
    return {c["path"]: c for c in ls.find_candidates(root)["candidates"]}


class RetireCandidates(unittest.TestCase):
    def setUp(self) -> None:
        self.root = make_repo()
        self.addCleanup(shutil.rmtree, self.root, True)

    def test_unreachable_is_candidate_with_category_and_evidence(self) -> None:
        found = cands(self.root)
        for p in (C + "scripts/dead.py", C + "scripts/dead_dep.py", C + "schemas/dead.schema.json"):
            self.assertEqual(found[p]["category"], "a")
            self.assertTrue(found[p]["evidence"])
        self.assertTrue(all(c["category"] in {"a", "b", "c"} and c["evidence"] for c in found.values()))

    def test_reachable_protected_and_current_referenced_are_not_candidates(self) -> None:
        found = cands(self.root)
        self.assertNotIn(C + "scripts/live.py", found)
        self.assertNotIn(C + "scripts/live_dep.py", found)  # transitive via import
        for protected in (ls.POLICY_PATH, C + "canonical/issue_register.json"):
            self.assertNotIn(protected, found)
        _w(self.root, "P1-CURRENT.json", '{"ref": "P1-Central-Control/schemas/dead.schema.json"}')
        self.assertNotIn(C + "schemas/dead.schema.json", cands(self.root))

    def test_self_test_is_not_an_entry(self) -> None:
        self.assertIn(C + "scripts/dead.py", cands(self.root))  # test_dead.py imports it

    def test_derived_follow_parent_and_test_owned_is_kept(self) -> None:
        found = cands(self.root)
        self.assertEqual(found[C + "tests/test_dead.py"]["category"], "b")
        self.assertIn("TARGET_SCRIPT_RETIRED", found[C + "tests/test_dead.py"]["evidence"])
        self.assertEqual(found[C + "tests/_unused_helper.py"]["evidence"], "TEST_HELPER_WITHOUT_USER")
        self.assertNotIn(C + "tests/test_live.py", found)
        self.assertNotIn(C + "fixtures/live_fixture.json", found)  # owned by a live test
        self.assertIn(C + "fixtures/live_fixture.json", ls.find_candidates(self.root)["test_owned"])

    def test_docs_only_make_docs_reachable(self) -> None:
        _w(self.root, "README.md", "P1-Central-Control/scripts/live.py docs/a.md")
        _w(self.root, "docs/a.md", "see P1-Central-Control/scripts/dead.py and docs/b.md")
        _w(self.root, "docs/b.md", "doc")
        found = cands(self.root)
        self.assertIn(C + "scripts/dead.py", found)
        self.assertNotIn("docs/b.md", found)

    def test_declared_entry_is_a_root_until_it_expires(self) -> None:
        root = make_repo([{"path": C + "scripts/dead.py", "reason": "外部消費者", "review_after": "2026-11-08"}])
        self.addCleanup(shutil.rmtree, root, True)
        self.assertNotIn(C + "scripts/dead.py", cands(root))
        self.assertEqual(ls.run_sweep(root, TODAY)["status"], "PASS")
        late = ls.run_sweep(root, date(2026, 11, 9))
        self.assertEqual(late["status"], "BLOCK")
        self.assertIn("DECLARED_ENTRY_EXPIRED:" + C + "scripts/dead.py", late["reason_codes"])


class RetireFlow(unittest.TestCase):
    def setUp(self) -> None:
        self.root = make_repo()
        self.addCleanup(shutil.rmtree, self.root, True)

    def test_batches_respect_limit_and_never_split_groups(self) -> None:
        cs = [{"path": C + "scripts/x.py", "category": "a", "evidence": "e"},
              {"path": C + "tests/test_x.py", "category": "b", "evidence": "TARGET_SCRIPT_RETIRED:" + C + "scripts/x.py"},
              {"path": C + "scripts/y.py", "category": "a", "evidence": "e"}]
        out = ls.batches(cs, 2)
        self.assertEqual(sum(len(b) for b in out), 3)
        self.assertTrue(all(len(b) <= 2 for b in out))
        group = next(b for b in out if C + "scripts/x.py" in b)
        self.assertIn(C + "tests/test_x.py", group)

    def test_delete_batch_refuses_protected_stale_and_oversize(self) -> None:
        with self.assertRaises(ValueError):
            ls.delete_batch(self.root, [ls.POLICY_PATH])
        with self.assertRaises(ValueError):
            ls.delete_batch(self.root, [C + "scripts/live.py"])  # reachable: not a candidate
        with self.assertRaises(ValueError):
            ls.delete_batch(self.root, [f"x{i}" for i in range(21)])
        self.assertTrue((self.root / C / "scripts/live.py").is_file())

    def test_strip_json_refs_is_json_aware_and_reports_structural_refs(self) -> None:
        reg = {"tests": [C + "tests/test_dead.py", C + "tests/test_live.py"], "owner": {"script": C + "scripts/dead.py"}}
        _w(self.root, C + "registry.json", json.dumps(reg))
        res = ls.strip_json_refs(self.root, [C + "tests/test_dead.py"])
        data = json.loads((self.root / C / "registry.json").read_text(encoding="utf-8"))
        self.assertEqual(data["tests"], [C + "tests/test_live.py"])
        self.assertIn(C + "registry.json", res["changed"])
        res = ls.strip_json_refs(self.root, [C + "scripts/dead.py"])
        self.assertIn(C + "registry.json", res["unresolved"])  # structural: not auto-removed

    def test_delete_batch_refuses_pending_json_ref(self) -> None:
        _w(self.root, C + "registry.json", json.dumps({"s": C + "schemas/dead.schema.json"}))
        _w(self.root, "README.md", "P1-Central-Control/scripts/live.py P1-Central-Control/registry.json")
        with self.assertRaises(ValueError):
            ls.delete_batch(self.root, [C + "schemas/dead.schema.json"])

    def test_fixpoint_removes_chain_and_derived_then_scan_is_empty(self) -> None:
        res = ls.run_retirement(self.root)
        self.assertEqual(res["blocked"], [])
        for gone in ("scripts/dead.py", "scripts/dead_dep.py", "schemas/dead.schema.json",
                     "tests/test_dead.py", "tests/test_dead_dep.py", "tests/_unused_helper.py"):
            self.assertFalse((self.root / C / gone).exists(), gone)
        for kept in ("scripts/live.py", "scripts/live_dep.py", "tests/test_live.py", "fixtures/live_fixture.json"):
            self.assertTrue((self.root / C / kept).exists(), kept)
        self.assertEqual(ls.find_candidates(self.root)["candidates"], [])

    def test_ratchet_only_lowers(self) -> None:
        f = self.root / ls.BUDGET_PATH
        ls.ratchet(self.root)
        data = json.loads(f.read_text(encoding="utf-8"))
        measured = data["budgets"][0]["max_bytes"]
        self.assertLess(measured, 10**9)
        _w(self.root, C + "scripts/big.py", "#" * 5000)
        ls.ratchet(self.root)
        self.assertEqual(json.loads(f.read_text(encoding="utf-8"))["budgets"][0]["max_bytes"], measured)


class IssueRecords(unittest.TestCase):
    def reg(self) -> dict:
        return json.loads((ROOT / C / "canonical/issue_register.json").read_text(encoding="utf-8"))

    def ledger(self) -> dict:
        return json.loads((ROOT / C / "canonical/update_learning_ledger.json").read_text(encoding="utf-8"))

    def test_new_signature_is_transient_with_default_ttl_and_recurrence_extends(self) -> None:
        reg = {"policy": self.reg()["policy"], "entries": []}
        e = ls.record_issue(reg, "x:y", "how", "handled", TODAY)
        self.assertEqual((e["class"], e["count"]), ("TRANSIENT", 1))
        self.assertEqual(e["expires_on"], (TODAY + timedelta(days=14)).isoformat())
        later = TODAY + timedelta(days=5)
        e2 = ls.record_issue(reg, "x:y", "how", "handled", later)
        self.assertEqual((len(reg["entries"]), e2["count"]), (1, 2))
        self.assertEqual(e2["expires_on"], (later + timedelta(days=14)).isoformat())

    def test_mechanism_requires_rationale_owner_layer_and_prevention(self) -> None:
        reg = {"policy": self.reg()["policy"], "entries": []}
        e = ls.record_issue(reg, "a:b", "h", "p", TODAY)
        kw = dict(rationale="r", owner_layer="GATE", prevention="p")
        for bad in ({**kw, "rationale": ""}, {**kw, "prevention": " "}, {**kw, "owner_layer": "NOPE"}):
            with self.assertRaises(ValueError):
                ls.classify_issue(reg, e["issue_id"], **bad)
        self.assertEqual(reg["entries"][0]["class"], "TRANSIENT")
        self.assertEqual(ls.classify_issue(reg, e["issue_id"], **kw)["class"], "MECHANISM")

    def test_sweep_lists_expired_and_review_and_apply_deletes_expired_only(self) -> None:
        root = make_repo()
        self.addCleanup(shutil.rmtree, root, True)
        reg_path = root / C / "canonical/issue_register.json"
        reg = {"policy": self.reg()["policy"], "entries": []}
        ls.record_issue(reg, "old:one", "h", "p", TODAY - timedelta(days=30))
        ls.record_issue(reg, "hot:one", "h", "p", TODAY)
        ls.record_issue(reg, "hot:one", "h", "p", TODAY)
        ls.save_register(reg_path, reg)
        rep = ls.sweep_records(reg, self.ledger(), root, TODAY)
        self.assertEqual(rep["expired"], ["T-001"])
        self.assertEqual(rep["review_promotion"], ["T-002"])
        self.assertEqual(ls.apply_records(root, TODAY)["removed"], ["T-001"])
        self.assertEqual([e["issue_id"] for e in ls.load_register(reg_path)["entries"]], ["T-002"])

    def test_resolved_mechanism_needs_regression_test_and_ledger_ref(self) -> None:
        reg = {"policy": self.reg()["policy"], "entries": [{
            "issue_id": "I-009", "signature": "m:n", "class": "MECHANISM", "count": 2, "status": "RESOLVED",
            "rationale": "r", "owner_layer": "GATE", "prevention": "p",
            "regression_test": C + "tests/test_lifecycle_sweep.py", "ledger_ref": "UL-014"}]}
        ok = ls.sweep_records(reg, self.ledger(), ROOT, TODAY)
        self.assertEqual(ok["distillable"], ["I-009"])
        reg["entries"][0]["ledger_ref"] = "UL-999"
        self.assertEqual(ls.sweep_records(reg, self.ledger(), ROOT, TODAY)["invalid"], ["I-009"])
        reg["entries"][0].update(ledger_ref="UL-014", regression_test=C + "tests/test_missing.py")
        self.assertEqual(ls.sweep_records(reg, self.ledger(), ROOT, TODAY)["invalid"], ["I-009"])


class RuntimeWiring(unittest.TestCase):
    """U-8 執行期（CAP-RETIRE）與 U-ISSUE 接線：gate 失敗登錄、結案交接。"""

    def setUp(self) -> None:
        self.root = make_repo()
        self.addCleanup(shutil.rmtree, self.root, True)

    def test_execute_retire_requires_a_role_bound_to_cap_retire(self) -> None:
        for role in ("ROLE:VERIFIER", "ROLE:CONTROL_RESEARCH"):
            with self.assertRaisesRegex(ValueError, "CAPABILITY_NOT_BOUND"):
                ls.execute_retire(self.root, role, [C + "scripts/dead_dep.py"])
            self.assertTrue((self.root / C / "scripts/dead_dep.py").is_file())

    def test_execute_retire_by_executor_deletes_candidates_but_keeps_guards(self) -> None:
        with self.assertRaises(ValueError):
            ls.execute_retire(self.root, "ROLE:EXECUTOR", [ls.POLICY_PATH])  # protected
        with self.assertRaises(ValueError):
            ls.execute_retire(self.root, "ROLE:EXECUTOR", [C + "scripts/live.py"])  # not a candidate
        res = ls.execute_retire(self.root, "ROLE:EXECUTOR", [C + "schemas/dead.schema.json"])
        self.assertEqual(res["deleted"], 1)
        self.assertFalse((self.root / C / "schemas/dead.schema.json").exists())

    def test_gate_failure_is_recorded_pass_is_not_and_recording_never_masks(self) -> None:
        import control_gate_runtime as gate

        calls = []
        orig_root, orig_write = gate.ROOT, gate._write_report
        gate._write_report = lambda *a: calls.append(a) or 7
        self.addCleanup(setattr, gate, "ROOT", orig_root)
        self.addCleanup(setattr, gate, "_write_report", orig_write)
        gate.ROOT = self.root
        fail = [{"stage_id": "UNIT_TESTS", "status": "FAIL", "reason_code": "UNIT_TEST_FAILED"},
                {"stage_id": "OK_STAGE", "status": "PASS", "reason_code": None}]
        self.assertEqual(gate.write_report("o", "b", "h", "FAIL", fail), 7)
        reg = ls.load_register(self.root / C / "canonical/issue_register.json")
        sigs = [e["signature"] for e in reg["entries"]]
        self.assertIn("gate:UNIT_TESTS:UNIT_TEST_FAILED", sigs)
        self.assertFalse([x for x in sigs if "OK_STAGE" in x])
        n = len(sigs)
        gate.write_report("o", "b", "h", "PASS", fail)
        self.assertEqual(len(ls.load_register(self.root / C / "canonical/issue_register.json")["entries"]), n)
        gate.ROOT = self.root / "missing"  # recording fails -> gate result unchanged
        self.assertEqual(gate.write_report("o", "b", "h", "FAIL", fail), 7)

    def test_close_handoff_lists_expired_and_review_items_only(self) -> None:
        reg_path = self.root / C / "canonical/issue_register.json"
        reg = ls.load_register(reg_path)
        reg["entries"] = []
        ls.record_issue(reg, "old:one", "h", "p", TODAY - timedelta(days=30))
        ls.record_issue(reg, "hot:one", "h", "p", TODAY)
        ls.record_issue(reg, "hot:one", "h", "p", TODAY)
        ls.save_register(reg_path, reg)
        self.assertEqual(ls.records_for_control_research(self.root, TODAY),
                         {"expired": ["T-001"], "review_promotion": ["T-002"]})
        self.assertEqual(ls.records_for_control_research(ROOT, TODAY), {})


class RealRepo(unittest.TestCase):
    """UL-013～UL-018 的回歸：真實 repo 上機制成立。"""

    def test_sweep_passes_with_no_candidates_and_declared_entries_live(self) -> None:
        rep = ls.run_sweep(ROOT, TODAY)
        self.assertEqual(rep["candidates"], [])
        self.assertEqual(rep["status"], "PASS", rep["reason_codes"])
        for e in ls.load_policy(ROOT)["declared_entries"]:
            self.assertTrue((ROOT / e["path"]).is_file())
            self.assertTrue(e["reason"] and e["review_after"])

    def test_one_engine_only_old_mechanisms_are_gone(self) -> None:
        for name in ("retention_gate", "obsolete_asset_audit", "artifact_lifecycle_audit", "capability_retirement_gate"):
            self.assertFalse((ROOT / C / f"scripts/{name}.py").exists(), name)
        gate = (ROOT / C / "scripts/control_gate_runtime.py").read_text(encoding="utf-8")
        self.assertIn("LIFECYCLE_SWEEP", gate)
        self.assertNotIn("OBSOLETE_ASSET_AUDIT", gate)

    def test_cap_retire_binds_only_executor(self) -> None:
        roles = json.loads((ROOT / C / "policy/role_capability_binding.v1.0.json").read_text(encoding="utf-8"))["roles"]
        self.assertEqual([r for r, caps in roles.items() if "CAP-RETIRE" in caps], ["ROLE:EXECUTOR"])

    def test_register_and_ledger_are_consistent(self) -> None:
        reg = json.loads((ROOT / C / "canonical/issue_register.json").read_text(encoding="utf-8"))
        led = json.loads((ROOT / C / "canonical/update_learning_ledger.json").read_text(encoding="utf-8"))
        ids = {e["lesson_id"] for e in led["entries"]}
        self.assertTrue({f"UL-{n:03d}" for n in range(13, 19)} <= ids)
        self.assertEqual([e for e in reg["entries"] if e["class"] == "MECHANISM"], [])
        self.assertEqual(ls.sweep_records(reg, led, ROOT, TODAY)["invalid"], [])

    def test_reverify_is_one_step_flag(self) -> None:
        src = (ROOT / C / "scripts/local_acceptance.py").read_text(encoding="utf-8")
        self.assertIn("--reverify", src)
        self.assertIn("def reopen_active", src)


if __name__ == "__main__":
    unittest.main()
