"""The role-isolation workflow must be loadable by GitHub Actions.

r10 shipped ``p1-role-isolation-gate.yml`` with a heredoc body at column 0 under
``run: python3 - <<'PY'``; that is invalid YAML, so GitHub rejected the workflow and
the independent M33 verification (plan Phase C) never ran. This check needs no YAML
library (the CI job only installs jsonschema): in a workflow file every non-blank
line must be indented, a comment, or a top-level key.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WORKFLOW = ROOT / ".github/workflows/p1-role-isolation-gate.yml"
TOP_LEVEL_KEY = re.compile(r"^(name|run-name|on|permissions|env|concurrency|defaults|jobs):")


def column_zero_leaks(text: str) -> list[tuple[int, str]]:
    return [
        (number, line)
        for number, line in enumerate(text.splitlines(), start=1)
        if line.strip()
        and not line[0].isspace()
        and not line.startswith("#")
        and not TOP_LEVEL_KEY.match(line)
    ]


def test_role_isolation_workflow_has_no_column_zero_leak():
    assert column_zero_leaks(WORKFLOW.read_text(encoding="utf-8")) == []


def test_leak_detector_catches_the_r10_defect():
    broken = (
        "jobs:\n  a:\n    steps:\n      - run: python3 - <<'PY'\nimport json\nPY\n"
    )
    assert [line for _, line in column_zero_leaks(broken)] == ["import json", "PY"]


def test_every_workflow_test_command_targets_an_existing_test_file():
    text = WORKFLOW.read_text(encoding="utf-8")
    patterns = re.findall(r"-p '([^']+)'", text)
    assert patterns, "workflow no longer runs any test pattern"
    tests_dir = ROOT / "P1-Central-Control/tests"
    for pattern in patterns:
        assert list(tests_dir.glob(pattern)), pattern


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)
