from __future__ import annotations

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

import feature_batch_orchestrator as batch
import central_role_interface as central
from brain_mode_controller import PLAN_GATE_KEYS


def _manifest(phase: str = "FINAL_TEST") -> dict:
    features = []
    for number in range(1, 31):
        feature_id = f"P2-F{number:02d}"
        features.append({
            "feature_id": feature_id,
            "name": feature_id,
            "roadmap_sections": ["TEST-SCOPE"],
            "depends_on": [],
            "implementation_refs": [],
            "test_refs": [],
            "implementation_status": "IMPLEMENTED",
            "local_case_sim_status": "PASS",
            "local_case_sim_evidence_refs": ["receipt.json"],
            "local_case_plan": [
                {
                    "case_id": f"{feature_id}-NORMAL",
                    "kind": "NORMAL",
                    "scenario": "valid scenario",
                    "expected_behavior": "VALID_BEHAVIOR",
                    "test_ref": "P1-Central-Control/tests/test_feature_batch_orchestrator.py",
                    "test_method": "FeatureBatchOrchestratorTests.test_final_batch_gate_accepts_only_closed_batch",
                },
                {
                    "case_id": f"{feature_id}-NEGATIVE",
                    "kind": "NEGATIVE",
                    "scenario": "invalid phase",
                    "expected_behavior": "FAIL_CLOSED",
                    "test_ref": "P1-Central-Control/tests/test_feature_batch_orchestrator.py",
                    "test_method": "FeatureBatchOrchestratorTests.test_official_roster_cannot_be_prepared_before_closure",
                },
                {
                    "case_id": f"{feature_id}-BOUNDARY",
                    "kind": "BOUNDARY",
                    "scenario": "feature not implemented",
                    "expected_behavior": "BOUNDED_RECOVERY",
                    "test_ref": "P1-Central-Control/tests/test_feature_batch_orchestrator.py",
                    "test_method": "FeatureBatchOrchestratorTests.test_local_simulation_refuses_unimplemented_feature",
                },
            ],
        })
    return {
        "batch_id": batch.EXPECTED_BATCH_ID,
        "scope_fingerprint": "sha256:" + "a" * 64,
        "workstreams": [{"section_id": "TEST-SCOPE", "feature_ids": [f"P2-F{i:02d}" for i in range(1, 31)], "title": "test", "status": "IN_PROGRESS"}],
        "batch_phase": phase,
        "official_test_scope_status": "READY_FOR_BATCH",
        "features": features,
        "closure_checks": {key: True for key in batch.CLOSURE_CHECKS},
        "official_test_roster": [{
            "test_ref": "P1-Central-Control/tests/test_feature_batch_orchestrator.py",
            "expected_method_count": 3,
            "method_names": [
                "test_final_batch_gate_accepts_only_closed_batch",
                "test_local_simulation_refuses_unimplemented_feature",
                "test_official_roster_cannot_be_prepared_before_closure",
            ],
            "feature_ids": ["P2-F30"],
        }],
        "closure_evidence_ref": "P1-Central-Control/progress/closure.json",
    }


class FeatureBatchOrchestratorTests(unittest.TestCase):
    def test_final_batch_gate_accepts_only_closed_batch(self):
        manifest = _manifest("FINAL_TEST")
        # The final gate (and the schema) also require the roster-complete flag, which the
        # roster-preparation step sets; the shared fixture only carries CLOSURE_CHECKS.
        manifest["closure_checks"]["official_test_roster_complete"] = True
        with (
            patch.object(batch, "_current_and_work", return_value=({}, {"operational_contract": {"feature_batch_manifest_ref": "manifest.json"}}, "work.json")),
            patch.object(batch, "_load_manifest", return_value=("manifest.json", manifest)),
            patch.object(batch, "_safe_path", return_value=MagicMock(read_bytes=MagicMock(return_value=b"fixture"))),
            patch.object(batch, "evaluate_realization", return_value={"blockers": [], "ready_for_closure": True}),
            patch.object(batch, "_load_closure_evidence", return_value=({"status": "CLOSURE_PASS"}, [])),
            patch.object(batch, "_validate_official_roster", return_value=(manifest["official_test_roster"], 3, [])),
        ):
            result = batch.validate_final_test_gate(batch.ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["batch_phase"], "FINAL_TEST")
        self.assertEqual(result["expected_test_method_count"], 3)
        self.assertEqual(result["scope_fingerprint"], manifest["scope_fingerprint"])

    def test_official_roster_cannot_be_prepared_before_closure(self):
        manifest = _manifest("REALIZATION")
        with (
            patch.object(batch, "_current_and_work", return_value=({}, {"operational_contract": {"feature_batch_manifest_ref": "manifest.json"}}, "work.json")),
            patch.object(batch, "_load_manifest", return_value=("manifest.json", manifest)),
        ):
            with self.assertRaisesRegex(batch.BatchGateError, "OFFICIAL_ROSTER_CAN_ONLY_BE_PREPARED_AFTER_CLOSURE"):
                batch.prepare_official_test_roster(batch.ROOT)

    def test_local_simulation_refuses_unimplemented_feature(self):
        manifest = _manifest("REALIZATION")
        manifest["features"][0]["implementation_status"] = "PARTIAL"
        with (
            patch.object(batch, "_current_and_work", return_value=({}, {"operational_contract": {"feature_batch_manifest_ref": "manifest.json"}}, "work.json")),
            patch.object(batch, "_load_manifest", return_value=("manifest.json", manifest)),
        ):
            with self.assertRaisesRegex(batch.BatchGateError, "FEATURE_NOT_MARKED_IMPLEMENTED"):
                batch.run_local_case_sim(batch.ROOT, "P2-F01")


    def test_frozen_scope_fingerprint_changes_only_when_scope_or_dependencies_change(self):
        manifest = _manifest("REALIZATION")
        manifest["scope_fingerprint"] = batch._batch_scope_fingerprint(manifest)
        original = manifest["scope_fingerprint"]
        manifest["features"][0]["implementation_refs"].append("some/implementation.py")
        manifest["features"][0]["test_refs"].append("some/test_feature.py")
        self.assertEqual(batch._batch_scope_fingerprint(manifest), original)
        manifest["features"][1]["depends_on"] = ["P2-F30"]
        self.assertNotEqual(batch._batch_scope_fingerprint(manifest), original)

    def test_scope_fingerprint_ignores_implementation_evidence_updates(self):
        manifest = _manifest("REALIZATION")
        original = batch._batch_scope_fingerprint(manifest)
        manifest["features"][0]["implementation_refs"].append("new/module.py")
        manifest["features"][0]["test_refs"].append("new/test_module.py")
        manifest["features"][0]["notes"] = "new progress note"
        self.assertEqual(batch._batch_scope_fingerprint(manifest), original)

    def test_scope_fingerprint_detects_dependency_graph_drift(self):
        manifest = _manifest("REALIZATION")
        original = batch._batch_scope_fingerprint(manifest)
        manifest["features"][1]["depends_on"] = ["P2-F30"]
        self.assertNotEqual(batch._batch_scope_fingerprint(manifest), original)

    def test_final_test_gate_blocks_during_realization(self):
        manifest = _manifest("REALIZATION")
        with (
            patch.object(batch, "_current_and_work", return_value=({}, {"operational_contract": {"feature_batch_manifest_ref": "manifest.json"}}, "work.json")),
            patch.object(batch, "_load_manifest", return_value=("manifest.json", manifest)),
            patch.object(batch, "evaluate_realization", return_value={"blockers": [], "ready_for_closure": True}),
            patch.object(batch, "_load_closure_evidence", return_value=({"status": "CLOSURE_PASS"}, [])),
            patch.object(batch, "_validate_official_roster", return_value=(manifest["official_test_roster"], 3, [])),
        ):
            with self.assertRaisesRegex(batch.BatchGateError, "FEATURE_BATCH_CLOSURE_GATE_REQUIRED"):
                batch.validate_final_test_gate(batch.ROOT)

    def test_executor_cannot_advance_batch_to_closure(self):
        result = central.execute({
            "request_id": "TEST:BATCH:EXECUTOR",
            "operation": "FEATURE_BATCH_CONTROL",
            "role_id": "ROLE:EXECUTOR",
            "batch_action": "ADVANCE_CLOSURE",
        }, batch.ROOT)
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("FEATURE_BATCH_ACTION_ROLE_FORBIDDEN", result["reason_codes"])

    def test_central_batch_control_delegates_closure_to_single_phase_gate(self):
        expected = {"status": "CLOSURE_OPENED", "batch_id": batch.EXPECTED_BATCH_ID, "phase": "CLOSURE"}
        request = {
            "request_id": "TEST:BATCH:CLOSURE",
            "operation": "FEATURE_BATCH_CONTROL",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "batch_action": "ADVANCE_CLOSURE",
        }
        with patch.object(central, "advance_phase", return_value=expected) as advance:
            result = central.execute(request, batch.ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["batch_result"], expected)
        advance.assert_called_once_with(batch.ROOT, "CLOSURE")

    def test_scope_change_history_requires_approved_current_fingerprint(self):
        manifest = _manifest("REALIZATION")
        manifest["scope_fingerprint"] = batch._batch_scope_fingerprint(manifest)
        manifest["scope_change_history"] = [{
            "change_id": "SC-TEST", "status": "APPROVED", "approval_ref": "test-approval",
            "previous_scope_fingerprint": "sha256:" + "b" * 64,
            "new_scope_fingerprint": "sha256:" + "c" * 64,
            "affected_feature_ids": ["P2-F28", "P2-F30"],
            "dependency_graph_recomputed": True, "downstream_evidence_invalidated": True,
            "reopened_to_planning": True, "refrozen_after_review": True,
            "phase_transition": ["REALIZATION", "PLANNING", "REALIZATION"],
            "evidence_invalidated": ["LOCAL_CASE_RECEIPTS", "CLOSURE_EVIDENCE", "OFFICIAL_TEST_ROSTER", "FINAL_TEST_ADMISSION"],
            "rationale": "test fixture",
        }]
        with self.assertRaisesRegex(batch.BatchGateError, "SCOPE_CHANGE_FINGERPRINT_MISMATCH"):
            batch._validate_scope_change_history(manifest)
        manifest["scope_change_history"][0]["new_scope_fingerprint"] = manifest["scope_fingerprint"]
        batch._validate_scope_change_history(manifest)

    def test_local_simulation_requires_explicit_no_charge_gate(self):
        manifest = _manifest("REALIZATION")
        feature = manifest["features"][0]
        feature["implementation_status"] = "IMPLEMENTED"
        current = {"current_stage": {"status": "IN_PROGRESS"}}
        work = {
            "status": "IN_PROGRESS",
            "operational_contract": {"feature_batch_manifest_ref": "manifest.json"},
            "brain_mode_control": {
                "mode": "SIMULATION",
                "plan_approved": True,
                "plan_evidence": {
                    key: f"Approved evidence for {key} meets minimum length."
                    for key in PLAN_GATE_KEYS
                },
            },
        }
        with (
            patch.object(batch, "_current_and_work", return_value=(current, work, "work.json")),
            patch.object(batch, "_load_manifest", return_value=("manifest.json", manifest)),
            patch.object(batch.sys, "version_info", (3, 11, 0, "final", 0)),
            patch.dict(os.environ, {"P2_NO_CHARGE_QUOTA_CONFIRMED": "0"}),
        ):
            with self.assertRaisesRegex(batch.BatchGateError, "LOCAL_CASE_NO_CHARGE_GATE_UNCONFIRMED"):
                batch.run_local_case_sim(batch.ROOT, "P2-F01")

