#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import actions_execution_recovery as recovery


class ActionsExecutionRecoveryTests(unittest.TestCase):
    def diagnostic(self, classification: str):
        return {"diagnostic_id": "ACTIONS_DIAGNOSTIC:123", "classification": classification}

    def test_runner_startup_switches_to_diagnosis_without_retry(self):
        result = recovery.build(
            self.diagnostic("RUNNER_STARTUP_FAILURE"),
            attempt_index=0,
            max_external_retries=2,
        )
        self.assertEqual(result["decision"], "DIAGNOSE")
        self.assertFalse(result["retryable"])
        self.assertTrue(result["local_replay_allowed"])
        self.assertEqual(
            result["recommended_command"],
            "actions_execution_local_fallback.py",
        )

    def test_runner_startup_does_not_wait_for_retry_budget(self):
        result = recovery.build(
            self.diagnostic("RUNNER_STARTUP_FAILURE"),
            attempt_index=1,
            max_external_retries=2,
            local_replay_available=True,
        )
        self.assertEqual(result["decision"], "DIAGNOSE")
        self.assertTrue(result["local_replay_allowed"])
        self.assertFalse(result["retryable"])

    def test_workflow_execution_failure_routes_to_local_replay(self):
        result = recovery.build(self.diagnostic("WORKFLOW_EXECUTION_FAILURE"))
        self.assertEqual(result["decision"], "REPLAY_LOCAL")
        self.assertEqual(result["recommended_command"], "actions_regression_replay.py")

    def test_pass_completes(self):
        result = recovery.build(self.diagnostic("PASS"))
        self.assertEqual(result["decision"], "COMPLETE")

    def test_not_dispatched_automatically_redispatches(self):
        result = recovery.build(
            self.diagnostic("NOT_DISPATCHED"),
            attempt_index=0,
            max_external_retries=1,
        )
        self.assertEqual(result["decision"], "RETRY_EXTERNAL")
        self.assertEqual(
            result["recommended_command"],
            "github_actions.workflow_dispatch",
        )

    def test_unknown_blocks(self):
        result = recovery.build(self.diagnostic("UNKNOWN"))
        self.assertEqual(result["decision"], "BLOCK")

    def test_no_local_replay_requires_diagnosis_path(self):
        result = recovery.build(
            self.diagnostic("RUNNER_STARTUP_FAILURE"),
            attempt_index=0,
            max_external_retries=2,
            local_replay_available=False,
        )
        self.assertEqual(result["decision"], "REQUIRE_MANUAL_REVIEW")
        self.assertFalse(result["local_replay_allowed"])


if __name__ == "__main__":
    unittest.main()
