#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import github_actions_result_adapter as m9  # noqa: E402
import regression_executor as m7  # noqa: E402


class GithubActionsResultAdapterTests(unittest.TestCase):
    def observation(self, *, conclusion="failure", steps=None, status="completed"):
        return {
            "workflow_run": {
                "name": "P1 Control Gate",
                "status": status,
                "conclusion": conclusion,
                "head_sha": "abcdef1234567890",
            },
            "jobs": [{
                "name": "control-gate",
                "status": status,
                "conclusion": conclusion,
                "steps": steps,
            }],
        }

    def selection(self):
        return {
            "object_id": "REGRESSION_SELECTION:M4-001",
            "kind": "REGRESSION_SELECTION",
            "schema_version": "1.0",
            "content_hash": "sha256:89712641a3cb3f9e50520d38ee6a8f52bdfbd316b746657d15fccb018b8d4819",
            "selection_id": "M4-001",
            "source_routing_reevaluation_id": "M3-001",
            "source_impact_scan_id": "IMPACT-001",
            "source_routing_status": "PASS",
            "required_regression_sets": ["ci"],
            "selected_regression_sets": ["ci"],
            "selections": [{
                "capability_id": "CAP-EXTRACT",
                "evaluation_ref": "EVAL-001",
                "route_mode": "MODEL_ONLY",
                "decision_code": "CANDIDATE_READY",
                "regression_sets": ["ci"],
            }],
            "pending": [],
            "status": "PASS",
        }

    def registry(self):
        return {
            "ci": {
                "regression_set_id": "ci",
                "runner": "GITHUB_ACTIONS",
                "workflow": "P1 Control Gate",
                "job": "control-gate",
            }
        }

    def test_real_zero_step_runner_failure_fixture_is_incomplete(self):
        fixture = m9.load_json(
            ROOT / "P1-Central-Control/fixtures/m9-github-actions-runner-startup-failure.json"
        )
        result = m9.build_external_result(
            self.selection(),
            fixture,
            self.registry(),
            expected_head_sha=fixture["workflow_run"]["head_sha"],
        )
        self.assertEqual(result["status"], "INCOMPLETE")
        self.assertEqual(result["results"], [])

    def test_empty_step_list_failure_is_incomplete(self):
        result = m9.build_external_result(
            self.selection(),
            self.observation(conclusion="failure", steps=[]),
            self.registry(),
        )
        self.assertEqual(result["status"], "INCOMPLETE")

    def test_runner_startup_failure_is_incomplete(self):
        result = m9.build_external_result(
            self.selection(),
            self.observation(conclusion="failure", steps=None),
            self.registry(),
            expected_head_sha="abcdef1234567890",
        )
        self.assertEqual(result["status"], "INCOMPLETE")
        self.assertEqual(result["results"], [])

    def test_adapter_result_is_consumable_by_m7(self):
        observation = self.observation(conclusion="failure", steps=None)
        external = m9.build_external_result(
            self.selection(),
            observation,
            self.registry(),
        )
        result = m7.execute_selection(
            self.selection(),
            registry=self.registry(),
            external_result=external,
        )
        self.assertEqual(external["status"], "INCOMPLETE")
        self.assertEqual(result["status"], "INCOMPLETE")
        self.assertEqual(result["results"], [])

    def test_failure_after_steps_is_real_failure(self):
        result = m9.build_external_result(
            self.selection(),
            self.observation(
                conclusion="failure",
                steps=[{"name": "unit", "conclusion": "failure"}],
            ),
            self.registry(),
        )
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["results"], [{
            "regression_set_id": "ci",
            "status": "FAIL",
        }])

    def test_success_is_pass(self):
        result = m9.build_external_result(
            self.selection(),
            self.observation(
                conclusion="success",
                steps=[{"name": "unit", "conclusion": "success"}],
            ),
            self.registry(),
        )
        self.assertEqual(result["status"], "PASS")

    def test_completed_job_inside_active_workflow_is_incomplete(self):
        observation = self.observation(
            conclusion=None,
            steps=[{"name": "unit", "conclusion": "success"}],
            status="in_progress",
        )
        result = m9.build_external_result(
            self.selection(),
            observation,
            self.registry(),
        )
        self.assertEqual(result["status"], "INCOMPLETE")

    def test_in_progress_is_incomplete(self):
        result = m9.build_external_result(
            self.selection(),
            self.observation(
                conclusion=None,
                steps=None,
                status="in_progress",
            ),
            self.registry(),
        )
        self.assertEqual(result["status"], "INCOMPLETE")

    def test_head_sha_mismatch_is_rejected(self):
        with self.assertRaises(ValueError):
            m9.build_external_result(
                self.selection(),
                self.observation(),
                self.registry(),
                expected_head_sha="different",
            )

    def test_workflow_mismatch_is_rejected(self):
        registry = self.registry()
        registry["ci"]["workflow"] = "Other Workflow"
        with self.assertRaises(ValueError):
            m9.build_external_result(
                self.selection(),
                self.observation(),
                registry,
            )


if __name__ == "__main__":
    unittest.main()
