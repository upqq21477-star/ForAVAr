#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from datetime import datetime, timezone
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPT_DIR))

import external_architecture_evidence_adapter as adapter


class ExternalArchitectureEvidenceAdapterTests(unittest.TestCase):
    def test_normalizes_sarif_without_promoting_truth(self):
        now = datetime.now(timezone.utc).isoformat()
        sarif = {
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "CodeQL",
                        "version": "2.x",
                        "rules": [{
                            "id": "p1/no-cross-system-import",
                            "name": "No cross system import",
                            "helpUri": "https://example.invalid/rule"
                        }]
                    }
                },
                "results": [{
                    "ruleId": "p1/no-cross-system-import",
                    "level": "error",
                    "message": {"text": "cross-system import"},
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {"uri": "A1-S01/runner.py"},
                            "region": {"startLine": 12, "startColumn": 1}
                        }
                    }]
                }]
            }]
        }
        result = adapter.normalize(
            sarif,
            source_type="CODEQL",
            source_uri="external://codeql/run/1",
            source_revision="abc123",
            captured_at=now,
        )
        self.assertEqual(result["truth_boundary"], "EXTERNAL_EVIDENCE_ONLY")
        self.assertEqual(result["summary"]["finding_count"], 1)
        self.assertEqual(result["summary"]["error_count"], 1)
        self.assertEqual(result["findings"][0]["tool"]["rule_id"], "p1/no-cross-system-import")
        schema = json.loads(
            (ROOT / "P1-Central-Control/schemas/external_architecture_evidence.schema.json").read_text(encoding="utf-8")
        )
        Draft202012Validator(schema, format_checker=FormatChecker()).validate(result)

    def test_empty_sarif_is_valid_bounded_evidence(self):
        result = adapter.normalize(
            {"version":"2.1.0","runs":[]},
            source_type="SEMGREP",
            source_uri="external://semgrep/run/1",
            source_revision=None,
            captured_at="2026-10-04T00:00:00+00:00",
        )
        self.assertEqual(result["summary"]["finding_count"], 0)
        self.assertEqual(result["findings"], [])


if __name__ == "__main__":
    unittest.main()
