from __future__ import annotations

import copy
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
TESTS = ROOT / "P1-Central-Control/tests"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(TESTS))

import test_role_result_ingestion as role_result_helpers
import test_role_session_gate as role_gate_helpers
from packet_layer import content_hash
from repository_result_ingestion import ingest, ingest_role_result


class RoleSessionIsolationTests(unittest.TestCase):
    def test_normal_handoff_uses_gate_then_central_result_ingestion(self):
        admission = role_gate_helpers.admission(role_gate_helpers.request(
            "ROLE:EXECUTOR",
            "EXECUTE_TASK",
            write_targets=["TASK_SCOPE"],
            task_packet_ref="TASK_PACKET:pkt-test",
            **role_gate_helpers.EXEC,
        ))
        self.assertEqual(admission["status"], "PASS")

        with tempfile.TemporaryDirectory() as tmp:
            state, task, expected_result, log_path, evidence, provenance, envelopes = (
                role_result_helpers.RoleResultIngestionTests()._prepare(Path(tmp), retry=False)
            )
            role_result = role_result_helpers._role_result(
                "ROLE:EXECUTOR",
                "WORK_COMPLETE",
                evidence=expected_result["evidence_refs"],
                provenance=expected_result["provenance_refs"],
                capability="CAP-EVIDENCE",
            )
            role_result["result_id"] = expected_result["result_id"]
            role_result["output_refs"] = list(expected_result["output_refs"])
            out = ingest_role_result(
                role_result=role_result,
                task_packet=task,
                current_state=state,
                execution_envelopes=envelopes,
                event_log_path=log_path,
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(out["status"], "PASS")
            self.assertEqual(out["result_packet"]["workflow_id"], task["workflow_id"])
            self.assertEqual(out["result_packet"]["attempt_id"], task["attempt_id"])
            self.assertEqual(out["ingestion"]["state_owner"], "EXISTING_CENTRAL_CONTROLLER")
            self.assertEqual(out["verifier_verdicts"], [])

    def test_executor_cannot_self_verify_or_submit_verdict(self):
        denied = role_gate_helpers.admission(role_gate_helpers.request(
            "ROLE:EXECUTOR",
            "VERIFY_TASK",
            write_targets=[],
            task_packet_ref="TASK_PACKET:pkt-test",
            **role_gate_helpers.EXEC,
        ))
        self.assertEqual(denied["status"], "BLOCK")
        self.assertIn("OPERATION_DENIED", denied["reason_codes"])

        with tempfile.TemporaryDirectory() as tmp:
            state, task, _expected, log_path, _evidence, _provenance, envelopes = (
                role_result_helpers.RoleResultIngestionTests()._prepare(Path(tmp), retry=False)
            )
            before = copy.deepcopy(state)
            forged_verdict = role_result_helpers._role_result(
                "ROLE:EXECUTOR", "PASS", reason=None, verdict_fields=True, capability="CAP-EVIDENCE"
            )
            with self.assertRaisesRegex(ValueError, "ROLE_RESULT_STATUS_NOT_ALLOWED"):
                ingest_role_result(
                    role_result=forged_verdict,
                    task_packet=task,
                    current_state=state,
                    execution_envelopes=envelopes,
                    event_log_path=log_path,
                )
            self.assertEqual(state, before)

    def test_malformed_cross_session_result_is_blocked_before_state_transition(self):
        with tempfile.TemporaryDirectory() as tmp:
            state, task, result, log_path, _evidence, _provenance, envelopes = (
                role_result_helpers.RoleResultIngestionTests()._prepare(Path(tmp), retry=False)
            )
            before_state = copy.deepcopy(state)
            before_envelopes = copy.deepcopy(envelopes)
            forged = copy.deepcopy(result)
            forged["workflow_id"] = "WF:foreign-session"
            # 偽造者會重算雜湊；否則 packet_layer 先擋 content_hash，到不了身分檢查。期望維持原樣。
            forged["content_hash"] = content_hash(forged)
            with self.assertRaisesRegex(ValueError, "RESULT_TASK_IDENTITY_MISMATCH:workflow_id"):
                ingest(
                    result_packet=forged,
                    task_packet=task,
                    current_state=state,
                    execution_envelopes=envelopes,
                    event_log_path=log_path,
                )
            self.assertEqual(state, before_state)
            self.assertEqual(envelopes, before_envelopes)


if __name__ == "__main__":
    unittest.main()
