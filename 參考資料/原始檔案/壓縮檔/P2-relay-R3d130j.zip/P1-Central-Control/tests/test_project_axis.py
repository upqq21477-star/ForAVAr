import unittest

import project_axis as pa


class ProjectAxisTests(unittest.TestCase):
    def test_simulation_passes(self):
        self.assertTrue(pa.run_simulation()["ok"])

    def test_mutation_is_detected(self):
        r = pa.run_simulation(mutate=True)
        self.assertFalse(r["ok"])
        self.assertTrue(any("AI 自行確認" in n for n in r["failed"]))

    def test_flag_resets_after_mutation(self):
        pa.run_simulation(mutate=True)
        st = pa.new_axis("g", "a", ["x"])
        with self.assertRaises(pa.AxisError):
            pa.confirm(st, pa.propose(st, "收斂", "b"), "AI", "r")


if __name__ == "__main__":
    unittest.main()
