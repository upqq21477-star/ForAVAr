#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from jsonschema import ValidationError

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

from continuation_context_box import build, content_hash, locate, reconstruct, register_checkpoint, validate
from packet_layer import build_attempt, build_task_packet


class ContinuationContextBoxTests(unittest.TestCase):
    def segment(self) -> dict:
        return {
            "segment_id": "SEG-BOX",
            "workflow_id": "WF-BOX",
            "system_id": "SYSTEM-BOX",
            "skill_id": "skill-box",
            "skill_version": "1.0",
            "objective": "resume",
            "input_scope": "test",
            "input_refs": ["INPUT:BOX"],
            "requested_outputs": ["result"],
            "constraints": ["CENTRAL_ONLY"],
            "stop_condition": ["done"],
            "failure_condition": ["fail"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": False,
            },
            "context_cohort_id": "COHORT-BOX",
            "context_budget": {
                "estimated_total_context": 10,
                "target_context_budget": 20,
                "hard_context_ceiling": 40,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }

    def task(self) -> dict:
        return build_task_packet(
            self.segment(),
            build_attempt(
                self.segment(),
                attempt_number=1,
                started_at="2026-10-05T10:00:00+00:00",
            ),
        )

    def current(self) -> dict:
        return {
            "revision": 7,
            "state_revision": 3,
            "current_stage": {"id": "M-TEST", "status": "BUILDING"},
            "next_exact_action": "WAIT_EXTERNAL_RESULT",
        }

    def test_locate_uses_index_without_scanning_checkpoint_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            task = self.task()
            box = build(
                current=self.current(),
                task_packet=task,
                execution_record_ref=task["execution_record_ref"],
            )
            checkpoint_dir = root / "P1-Central-Control" / "checkpoints"
            target = checkpoint_dir / "CONTINUATION_BOX__pkt-BOX.json"
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(json.dumps(box, ensure_ascii=False), encoding="utf-8")
            register_checkpoint(root, target, box)

            unrelated = checkpoint_dir / "unrelated" / "broken.json"
            unrelated.parent.mkdir(parents=True, exist_ok=True)
            unrelated.write_text("{broken json", encoding="utf-8")

            with mock.patch.object(Path, "rglob", side_effect=AssertionError("full-tree scans are forbidden")):
                found_path, found_box = locate(root, box["box_id"])

            self.assertEqual(found_path, target)
            self.assertEqual(found_box["box_id"], box["box_id"])

    def test_locate_missing_index_fails_closed_without_scan(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "P1-Central-Control" / "checkpoints").mkdir(parents=True)
            with mock.patch.object(Path, "rglob", side_effect=AssertionError("full-tree scans are forbidden")):
                with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_INDEX_NOT_FOUND"):
                    locate(root, "CONTINUATION_BOX:WF:SEG:ATT")

    def test_unindexed_checkpoint_is_not_discovered_by_search(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            checkpoint_dir = root / "P1-Central-Control" / "checkpoints"
            checkpoint_dir.mkdir(parents=True)
            (checkpoint_dir / "continuation_box_index.json").write_text(
                json.dumps({"schema_version": "1.0", "entries": {}}, indent=2),
                encoding="utf-8",
            )
            old_path = checkpoint_dir / "legacy.json"
            old_path.write_text(json.dumps({"box_id": "CONTINUATION_BOX:WF:SEG:ATT"}), encoding="utf-8")

            with mock.patch.object(Path, "rglob", side_effect=AssertionError("full-tree scans are forbidden")):
                with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_NOT_FOUND"):
                    locate(root, "CONTINUATION_BOX:WF:SEG:ATT")

    def test_locate_rejects_corrupt_indexed_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            checkpoint_dir = root / "P1-Central-Control" / "checkpoints"
            checkpoint_dir.mkdir(parents=True)
            box_id = "CONTINUATION_BOX:WF:SEG:ATT"
            target = checkpoint_dir / "corrupt.json"
            target.write_text("{broken json", encoding="utf-8")
            index = {
                "schema_version": "1.0",
                "entries": {box_id: "P1-Central-Control/checkpoints/corrupt.json"},
            }
            (checkpoint_dir / "continuation_box_index.json").write_text(
                json.dumps(index), encoding="utf-8"
            )
            with mock.patch.object(Path, "rglob", side_effect=AssertionError("full-tree scans are forbidden")):
                with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_INDEX_TARGET_INVALID"):
                    locate(root, box_id)

    def test_locate_rejects_index_path_escape(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            checkpoint_dir = root / "P1-Central-Control" / "checkpoints"
            checkpoint_dir.mkdir(parents=True)
            box_id = "CONTINUATION_BOX:WF:SEG:ATT"
            index = {
                "schema_version": "1.0",
                "entries": {box_id: "P1-Central-Control/progress/not-a-checkpoint.json"},
            }
            (checkpoint_dir / "continuation_box_index.json").write_text(
                json.dumps(index), encoding="utf-8"
            )
            with mock.patch.object(Path, "rglob", side_effect=AssertionError("full-tree scans are forbidden")):
                with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_INDEX_PATH_INVALID"):
                    locate(root, box_id)

    def test_current_fingerprint_is_required_for_resumption(self):
        task = self.task()
        box = build(
            current=self.current(),
            task_packet=task,
            execution_record_ref=task["execution_record_ref"],
        )
        del box["canonical_inputs"]["current_fingerprint"]
        box["content_hash"] = content_hash(box)
        with self.assertRaises(ValidationError):
            validate(box)

    def test_box_is_bounded_and_hashed(self):
        task = self.task()
        box = build(
            current=self.current(),
            task_packet=task,
            execution_record_ref=task["execution_record_ref"],
        )
        validate(box)
        self.assertEqual(box["content_hash"], content_hash(box))
        self.assertEqual(box["context_policy"]["history_loaded"], 0)

    def test_reconstruct_uses_box_without_transient_history(self):
        task = self.task()
        box = build(
            current=self.current(),
            task_packet=task,
            execution_record_ref=task["execution_record_ref"],
        )
        result = reconstruct(current=self.current(), task_packet=task, box=box)
        self.assertEqual(result["mode"], "AMNESIA_RECONSTRUCTED_WITH_BOX")
        self.assertEqual(result["history_loaded"], 0)
        self.assertFalse(result["transient_context_loaded"])
        self.assertEqual(result["resume_point"], "WAITING_EXTERNAL_RESULT")

    def test_same_stage_current_change_blocks_stale_box(self):
        task = self.task()
        original = self.current()
        box = build(current=original, task_packet=task, execution_record_ref=task["execution_record_ref"])
        changed = dict(original)
        changed["state_revision"] = 4
        with self.assertRaisesRegex(ValueError, "STATE_REVISION_STALE"):
            reconstruct(current=changed, task_packet=task, box=box)

        changed = dict(original)
        changed["next_exact_action"] = "CANCEL"
        with self.assertRaisesRegex(ValueError, "NEXT_ACTION_STALE"):
            reconstruct(current=changed, task_packet=task, box=box)

    def test_used_box_cannot_be_replayed(self):
        task = self.task()
        box = build(current=self.current(), task_packet=task, execution_record_ref=task["execution_record_ref"])
        box["status"] = "USED"
        box["content_hash"] = content_hash(box)
        with self.assertRaisesRegex(ValueError, "NOT_READY"):
            reconstruct(current=self.current(), task_packet=task, box=box)

    def test_stale_current_stage_blocks(self):
        task = self.task()
        box = build(
            current=self.current(),
            task_packet=task,
            execution_record_ref=task["execution_record_ref"],
        )
        stale = dict(self.current())
        stale["current_stage"] = {"id": "M-OTHER", "status": "BUILDING"}
        with self.assertRaisesRegex(ValueError, "STAGE_ID_STALE"):
            reconstruct(current=stale, task_packet=task, box=box)


if __name__ == "__main__":
    unittest.main(verbosity=2)
