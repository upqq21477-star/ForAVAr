#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

from actions_execution_orchestrator import retry_attempt_index


class ActionsExecutionOrchestratorRetryBudgetTests(unittest.TestCase):
    def test_old_success_and_other_head_do_not_consume_retry_budget(self):
        runs = [
            {"name": "wf", "head_branch": "main", "head_sha": "oldsha", "status": "completed", "conclusion": "success"},
            {"name": "wf", "head_branch": "main", "head_sha": "newsha", "status": "completed", "conclusion": "failure"},
            {"name": "wf", "head_branch": "main", "head_sha": "newsha", "status": "completed", "conclusion": "failure"},
            {"name": "other", "head_branch": "main", "head_sha": "newsha", "status": "completed", "conclusion": "failure"},
        ]
        self.assertEqual(
            retry_attempt_index(runs, workflow_name="wf", workflow_ref="main", head_sha="newsha"),
            1,
        )

    def test_success_on_same_head_breaks_failure_streak(self):
        runs = [
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "failure", "created_at": "2026-10-09T10:00:00Z"},
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "success", "created_at": "2026-10-09T09:00:00Z"},
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "failure", "created_at": "2026-10-09T08:00:00Z"},
        ]
        self.assertEqual(
            retry_attempt_index(runs, workflow_name="wf", workflow_ref="main", head_sha="abc"),
            0,
        )

    def test_success_between_failures_resets_retry_budget(self):
        runs = [
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "failure", "created_at": "2026-10-01T00:00:00Z"},
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "success", "created_at": "2026-10-02T00:00:00Z"},
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "failure", "created_at": "2026-10-03T00:00:00Z"},
        ]
        self.assertEqual(
            retry_attempt_index(runs, workflow_name="wf", workflow_ref="main", head_sha="abc"),
            0,
        )

    def test_missing_head_does_not_exclude_same_workflow_branch(self):
        runs = [
            {"name": "wf", "head_branch": "main", "head_sha": "abc", "status": "completed", "conclusion": "failure"},
        ]
        self.assertEqual(
            retry_attempt_index(runs, workflow_name="wf", workflow_ref="main", head_sha=None),
            0,
        )


if __name__ == "__main__":
    unittest.main()
