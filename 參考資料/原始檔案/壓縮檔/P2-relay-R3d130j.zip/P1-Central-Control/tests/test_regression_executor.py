#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import regression_executor as m7  # noqa: E402


class RegressionExecutorTests(unittest.TestCase):
    def selection(self, set_ids=None, status="PASS"):
        sets = set_ids or ["routing"]
        return {
            "object_id": "REGRESSION_SELECTION:M4-001",
            "kind": "REGRESSION_SELECTION",
            "schema_version": "1.0",
            "content_hash": "sha256:0000000000000000000000000000000000000000000000000000000000000000",
            "selection_id": "M4-001",
            "source_routing_reevaluation_id": "M3-001",
            "source_impact_scan_id": "IMPACT-001",
            "source_routing_status": "PASS",
            "required_regression_sets": list(sets),
            "selected_regression_sets": list(sets),
            "selections": [{
                "capability_id": "CAP-EXTRACT",
                "evaluation_ref": "EVAL-001",
                "route_mode": "MODEL_ONLY",
                "decision_code": "CANDIDATE_READY",
                "regression_sets": list(sets),
            }],
            "pending": [],
            "status": status,
        }

    def registry(self, runner="PYTHON_UNITTEST"):
        return {
            "routing": {
                "regression_set_id": "routing",
                "runner": runner,
                "test_paths": ["P1-Central-Control/tests/test_routing_reevaluation.py"],
            },
            "ci": {
                "regression_set_id": "ci",
                "runner": "GITHUB_ACTIONS",
                "workflow": "P1 Control Gate",
            },
        }

    def test_all_executable_sets_pass(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(),
                registry=self.registry(),
                run_set=lambda _: "PASS",
            )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["results"], [{
            "regression_set_id": "routing",
            "status": "PASS",
        }])

    def test_any_failed_set_fails_result(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(["routing"]),
                registry=self.registry(),
                run_set=lambda _: "FAIL",
            )
        self.assertEqual(result["status"], "FAIL")

    def external_result(self, status="PASS", results=None):
        return {
            "result_id": "GHA-M4-001",
            "selection_id": "M4-001",
            "status": status,
            "results": results if results is not None else [{"regression_set_id": "ci", "status": status}],
        }

    def test_external_github_actions_pass_is_consumed(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(["ci"]),
                registry=self.registry(),
                external_result=self.external_result("PASS"),
            )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["results"], [{"regression_set_id": "ci", "status": "PASS"}])

    def test_external_github_actions_failure_is_real_failure(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(["ci"]),
                registry=self.registry(),
                external_result=self.external_result("FAIL"),
            )
        self.assertEqual(result["status"], "FAIL")

    def test_github_actions_set_is_explicitly_incomplete(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(["ci"]),
                registry=self.registry(),
            )
        self.assertEqual(result["status"], "INCOMPLETE")
        self.assertEqual(result["results"], [])

    def test_fail_plus_unexecuted_set_does_not_fake_pass(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(["routing", "ci"]),
                registry=self.registry(),
                run_set=lambda _: "FAIL",
            )
        self.assertEqual(result["status"], "FAIL")

    def test_empty_explicit_registry_does_not_fall_back_to_repository_registry(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            with self.assertRaisesRegex(ValueError, "未知 regression set"):
                m7.execute_selection(self.selection(), registry={}, run_set=lambda _: "PASS")

    def test_unknown_runner_is_rejected(self):
        registry = self.registry(runner="UNKNOWN")
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            with self.assertRaises(ValueError):
                m7.execute_selection(
                    self.selection(),
                    registry=registry,
                    run_set=lambda _: "PASS",
                )

    def test_non_pass_selection_is_incomplete(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None):
            result = m7.execute_selection(
                self.selection(status="INSUFFICIENT_DATA"),
                registry=self.registry(),
            )
        self.assertEqual(result["status"], "INCOMPLETE")

    def test_python_runner_startup_error_is_incomplete_not_program_fail(self):
        with patch.object(m7.regression_selection, "validate_report", return_value=None), patch.object(
            m7.subprocess, "run", side_effect=OSError("python runner unavailable")
        ):
            result = m7.execute_selection(
                self.selection(),
                registry=self.registry(),
            )
        self.assertEqual(result["status"], "INCOMPLETE")
        self.assertEqual(result["results"], [])

    def test_python_runner_uses_unittest_command(self):
        completed = type("Completed", (), {"returncode": 0})()
        seen = {}

        def fake_run(command, **kwargs):
            seen["command"] = command
            seen["kwargs"] = kwargs
            return completed

        result = m7.run_python_unittest_set(
            self.registry()["routing"],
            runner=fake_run,
        )
        self.assertEqual(result, "PASS")
        self.assertEqual(seen["command"][0], sys.executable)
        self.assertEqual(seen["command"][1:3], ["-m", "unittest"])
        self.assertEqual(seen["kwargs"]["cwd"], ROOT)


if __name__ == "__main__":
    unittest.main()
