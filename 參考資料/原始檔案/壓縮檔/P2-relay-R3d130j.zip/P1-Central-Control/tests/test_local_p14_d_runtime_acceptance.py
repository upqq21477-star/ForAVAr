#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import local_p14_d_runtime_acceptance as runner


class LocalP14DRuntimeAcceptanceTests(unittest.TestCase):
    def test_hash_is_stable(self):
        self.assertEqual(len(runner.sha256(Path(__file__))), 64)

    def test_git_sha_is_available_in_repository(self):
        self.assertGreaterEqual(len(runner.git_sha()), 7)
    
    def test_source_manifest_contains_execution_contract_hashes(self):
        manifest = runner.source_manifest()
        self.assertGreaterEqual(len(manifest), 5)
        self.assertTrue(all(len(item["sha256"]) == 64 for item in manifest))

    def test_local_acceptance_bundle_schema_is_part_of_runtime_contract(self):
        schema_path = ROOT / "P1-Central-Control/schemas/local_p14_d_runtime_acceptance.schema.json"
        self.assertTrue(schema_path.is_file())


if __name__ == "__main__":
    unittest.main()
