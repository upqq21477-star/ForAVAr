import pathlib
import unittest
import importlib.util

ROOT=pathlib.Path(__file__).resolve().parents[2]
PATH=ROOT/"P1-Central-Control/scripts/external_tool_candidate_review.py"
spec=importlib.util.spec_from_file_location("candidate_review",PATH)
mod=importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(mod)

class CandidateReviewTests(unittest.TestCase):
    def test_selects_only_candidate_classes(self):
        radar={
            "schema_version":"1.0",
            "run_id":"RADAR-20261004",
            "observed_date":"2026-10-04",
            "source":"GITHUB_REPOSITORY_SEARCH",
            "catalog_version":"1.0",
            "summary":{"scope_count":1,"query_count":1,"candidate_count":1,"watch_count":1,"below_threshold_count":0},
            "candidates":[
                {"repository":"a/b","name":"b","url":"https://github.com/a/b","description":"x","stars":1000,"forks":50,"created_at":"2026-01-01T00:00:00Z","pushed_at":"2026-10-01T00:00:00Z","updated_at":"2026-10-01T00:00:00Z","archived":False,"topics":[],"popularity_score":80,"freshness_days":3,"is_new_tool":True,"classification":"ADOPT_CANDIDATE","matched_scopes":[{"scope_type":"PAIN_POINT","scope_id":"PP-01","scope_name":"x","query":"x"}]},
                {"repository":"c/d","name":"d","url":"https://github.com/c/d","description":"x","stars":900,"forks":30,"created_at":"2026-01-01T00:00:00Z","pushed_at":"2026-10-01T00:00:00Z","updated_at":"2026-10-01T00:00:00Z","archived":False,"topics":[],"popularity_score":60,"freshness_days":3,"is_new_tool":True,"classification":"WATCH","matched_scopes":[{"scope_type":"CORE_CAPABILITY","scope_id":"CORE-01","scope_name":"x","query":"x"}]},
            ]
        }
        self.assertEqual(len([x for x in radar["candidates"] if x["classification"] in {"ADOPT_CANDIDATE","WATCH"}]),2)

if __name__=="__main__":
    unittest.main()
