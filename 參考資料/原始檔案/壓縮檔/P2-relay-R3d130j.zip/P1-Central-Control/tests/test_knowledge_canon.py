#!/usr/bin/env python3
"""CS-1 B2：Observation／Evidence／Claim 升格鏈、錯誤注入、Memory Integrity Gate（SIMULATION_ONLY）。"""
from __future__ import annotations

import sys
import tempfile
import unittest
from unittest import mock
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import knowledge_canon as kc  # noqa: E402
import knowledge_intake as ki  # noqa: E402

TS = "2026-10-08T00:00:00Z"
RAW = "系統 A 使用 SQLite 儲存。\n\n系統 A 不使用網路。\n\n系統 B 使用 JSON 檔。".encode("utf-8")


class KnowledgeCanonTests(unittest.TestCase):
    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        _, segs = ki.build_source("d", RAW, location="mem://d", version="v1", max_chars=20)
        self.segs = [s["object_id"] for s in segs]
        ledger = ki.ReadingLedger(Path(tmp.name) / "l.jsonl", segs)
        self.store = kc.KnowledgeStore(ledger, {"SOURCE:d": ki.normalize(RAW)})
        for ref in self.segs:
            ledger.append(ref, "READ", reader="R1", timestamp=TS)

    def _obs(self, seg=0, quote="SQLite", cls="OBSERVED", **kw):
        return self.store.add_observation(cls, "obs", self.segs[seg], producer="R1", captured_at=TS,
                                          quote=quote if cls == "OBSERVED" else None, **kw)["object_id"]

    def _evid(self, obs, claim="CLAIM:c1", rel="SUPPORTS"):
        return self.store.add_evidence(obs, claim, rel, producer="R1", scope="TASK:t1", captured_at=TS)["object_id"]

    def _claim(self, obs_refs, evid_refs, cid="c1", content="系統 A 使用 SQLite"):
        return self.store.propose_claim(cid, "FACT", content, obs_refs, evid_refs)["object_id"]

    def _ok_claim(self, cid="c1", content="系統 A 使用 SQLite"):
        o = self._obs()
        return self._claim([o], [self._evid(o, f"CLAIM:{cid}")], cid, content)

    def test_happy_path_promotes_and_gate_passes(self) -> None:
        ref = self._ok_claim()
        self.assertEqual(self.store.promote(ref, by="CONTROL_RESEARCH", rationale="引文直接支持")["status"], "PROMOTED")
        self.assertEqual(self.store.claims[ref]["promotion"], "CANONICAL")
        self.assertEqual(self.store.integrity_gate(), {"status": "PASS", "errors": []})

    def test_chain_claim_evidence_segment_source(self) -> None:
        ref = self._ok_claim()
        claim = self.store.claims[ref]
        ev = self.store.evid[claim["evidence_refs"][0]]
        self.assertEqual(ev["source_ref"], "SOURCE:d")
        self.assertIn(ev["segment_ref"], self.segs)
        self.assertEqual(claim["source_refs"], ["SOURCE:d"])
        start, end = (int(x) for x in ev["locator"].split()[1].split("-"))
        self.assertEqual(self.store.texts["SOURCE:d"][start:end], "SQLite")

    def test_error_injection_non_observed_cannot_promote(self) -> None:
        base = self._obs()
        bad = {
            "INFERENCE_NOT_FACT": self.store.add_observation("INFERENCE", "推論", self.segs[0], producer="R1", captured_at=TS, basis_refs=[base])["object_id"],
            "UNKNOWN_NOT_PROMOTABLE": self.store.add_observation("UNKNOWN", "不明", self.segs[0], producer="R1", captured_at=TS)["object_id"],
        }
        for n, (code, obs) in enumerate(bad.items()):
            ref = self._claim([obs], [], f"x{n}", f"內容{n}")
            result = self.store.promote(ref, by="CONTROL_RESEARCH", rationale="r")
            self.assertEqual(result["status"], "BLOCK")
            self.assertTrue(any(r.startswith(code) for r in result["reason_codes"]), result)

    def test_observation_rules(self) -> None:
        o = self._obs()
        with self.assertRaises(ValueError):  # 捏造引文
            self._obs(quote="Postgres")
        with self.assertRaises(ValueError):  # INFERENCE 無 basis
            self.store.add_observation("INFERENCE", "x", self.segs[0], producer="R1", captured_at=TS)
        with self.assertRaises(ValueError):  # CONFLICT 少於兩筆
            self.store.add_observation("CONFLICT", "x", self.segs[0], producer="R1", captured_at=TS, conflict_with=[o])
        with self.assertRaises(ValueError):  # 證據不能來自 UNKNOWN
            u = self.store.add_observation("UNKNOWN", "x", self.segs[0], producer="R1", captured_at=TS)["object_id"]
            self._evid(u)

    def test_unread_segment_cannot_be_observed(self) -> None:
        ledger = self.store.ledger
        ledger.append(self.segs[0], "FAILED", reader="R1", timestamp=TS)
        with self.assertRaises(ValueError):
            self._obs()

    def test_missing_or_contradicting_evidence_blocks(self) -> None:
        o = self._obs()
        ref = self._claim([o], [], "c1")
        self.assertIn(f"EVIDENCE_MISSING:{o}", self.store.promote(ref, by="a", rationale="r")["reason_codes"])
        o2 = self._obs(1, "不使用網路")
        ref2 = self._claim([o2], [self._evid(o2, "CLAIM:c2"), self._evid(o2, "CLAIM:c2", "CONTRADICTS")], "c2", "系統 A 使用網路")
        self.assertTrue(any(r.startswith("CONTRADICTED") for r in self.store.promote(ref2, by="a", rationale="r")["reason_codes"]))

    def test_adjudication_required(self) -> None:
        ref = self._ok_claim()
        self.assertIn("ADJUDICATION_REQUIRED", self.store.promote(ref, by="", rationale="")["reason_codes"])
        self.assertEqual(self.store.claims[ref]["promotion"], "PROPOSED")

    def test_duplicate_and_open_conflict_block(self) -> None:
        first = self._ok_claim("c1")
        self.store.promote(first, by="a", rationale="r")
        dup = self._ok_claim("c2", "系統 a 使用   sqlite")
        self.assertTrue(any(r.startswith("DUPLICATE_CLAIM") for r in self.store.promote(dup, by="a", rationale="r")["reason_codes"]))
        o3, o4 = self._obs(2, "JSON"), self._obs(1, "不使用網路")
        self.store.add_observation("CONFLICT", "矛盾", self.segs[1], producer="R1", captured_at=TS, conflict_with=[o3, o4])
        ref = self._claim([o3], [self._evid(o3, "CLAIM:c3")], "c3", "系統 B 使用 JSON 檔")
        self.assertTrue(any(r.startswith("CONFLICT_OPEN") for r in self.store.promote(ref, by="a", rationale="r")["reason_codes"]))

    def test_reject_keeps_record_out_of_canonical(self) -> None:
        ref = self._ok_claim()
        self.store.reject(ref, by="CONTROL_RESEARCH", rationale="範圍不符")
        self.assertEqual(self.store.claims[ref]["promotion"], "REJECTED")
        self.assertEqual(self.store.promote(ref, by="a", rationale="r")["status"], "BLOCK")

    def test_integrity_gate_blocks_forged_canonical_and_orphan_processed(self) -> None:
        o = self._obs(0, "SQLite")
        u = self.store.add_observation("UNKNOWN", "x", self.segs[0], producer="R1", captured_at=TS)["object_id"]
        ref = self._claim([u], [], "forged", "偽造")
        self.store.claims[ref] = kc._seal(dict(self.store.claims[ref], promotion="CANONICAL"), "claim")  # 繞過 promote
        report = self.store.integrity_gate()
        self.assertEqual(report["status"], "BLOCK")
        self.assertTrue(any("ADJUDICATION_MISSING" in e for e in report["errors"]))
        self.assertTrue(any("UNKNOWN_NOT_PROMOTABLE" in e for e in report["errors"]))
        self.store.ledger.append(self.segs[0], "PROCESSED", reader="R1", timestamp=TS, observation_refs=["OBSERVATION:nope.O0001"])
        self.assertTrue(any(e.startswith("PROCESSED_WITHOUT_OBSERVATION") for e in self.store.integrity_gate()["errors"]))
        self.assertIn(o, self.store.obs)

    def test_reading_ledger_write_failure_rolls_back_memory(self) -> None:
        path = self.store.ledger.path.with_name("failing-ledger.jsonl")
        ledger = ki.ReadingLedger(path, list(self.store.ledger.segments.values()))
        before_entries = list(ledger.entries)
        with mock.patch.object(Path, "open", side_effect=OSError("simulated write failure")):
            with self.assertRaises(OSError):
                ledger.append(self.segs[0], "FAILED", reader="R1", timestamp=TS)
        self.assertEqual(ledger.entries, before_entries)
        self.assertEqual(ledger.head(), before_entries[-1]["content_hash"] if before_entries else None)
        self.assertFalse(path.exists())

    def test_evidence_hash_tampering_is_detected(self) -> None:
        claim_ref = self._ok_claim()
        evidence_ref = self.store.claims[claim_ref]["evidence_refs"][0]
        self.store.evid[evidence_ref]["relation"] = "CONTRADICTS"
        report = self.store.integrity_gate()
        self.assertEqual(report["status"], "BLOCK")
        self.assertIn(f"HASH_MISMATCH:{evidence_ref}", report["errors"])

    def test_changed_source_text_is_refused(self) -> None:
        self.store.texts["SOURCE:d"] = ki.normalize(RAW.replace("SQLite".encode(), b"Redis"))
        with self.assertRaises(ValueError):
            self.store.segment_text(self.segs[0])


if __name__ == "__main__":
    unittest.main()
