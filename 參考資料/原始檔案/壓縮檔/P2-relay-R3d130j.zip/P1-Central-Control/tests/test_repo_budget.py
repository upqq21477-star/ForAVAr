#!/usr/bin/env python3
"""Repo size budget: measured on disk, BLOCK when a max is exceeded."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import repository_hygiene_gate as gate  # noqa: E402


class RepoBudgetTest(unittest.TestCase):
    def build(self, root: Path, max_bytes: int) -> list[str]:
        (root / "P1-Central-Control/policy").mkdir(parents=True)
        (root / "P1-Central-Control/policy/repo_budget.json").write_text(
            json.dumps({"budgets": [{"path": "docs/", "max_bytes": max_bytes, "target_bytes": 1}]}),
            encoding="utf-8",
        )
        (root / "docs").mkdir()
        (root / "docs/a.md").write_text("x" * 100, encoding="utf-8")
        return ["docs/a.md"]

    def test_within_budget_passes_and_over_budget_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            paths = self.build(root, 100)
            self.assertEqual(gate.validate(paths, root)["status"], "PASS")
            (root / "P1-Central-Control/policy/repo_budget.json").write_text(
                json.dumps({"budgets": [{"path": "docs/", "max_bytes": 99, "target_bytes": 1}]}),
                encoding="utf-8",
            )
            result = gate.validate(paths, root)
            self.assertEqual(result["status"], "BLOCK")
            self.assertIn("over budget: docs/ 100 > 99", result["errors"])

    def test_real_tree_is_within_its_budget(self):
        paths = gate.tracked_files(ROOT)
        self.assertEqual(gate.budget_errors(ROOT, paths), [])

    def test_max_never_below_target(self):
        budgets = json.loads(gate_budget_text())["budgets"]
        for b in budgets:
            self.assertGreaterEqual(b["max_bytes"], b["target_bytes"])


def gate_budget_text() -> str:
    return (ROOT / gate.BUDGET_PATH).read_text(encoding="utf-8")


if __name__ == "__main__":
    unittest.main()
