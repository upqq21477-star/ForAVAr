#!/usr/bin/env python3
"""U-5b：NEEDS_BRAIN 非終態；Central 路由只查表；NEEDS_BRAIN 不進 retry、不擋依賴。"""
from __future__ import annotations

import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

import parallel_scheduler as ps  # noqa: E402
from packet_layer import DECISION_TO_STATUS  # noqa: E402


def _state(*, completed=(), queued=(), active=()):
    return {
        "completed_segments": list(completed),
        "queued_segments": list(queued),
        "active_segments": list(active),
    }


def _done(seg, decision, status):
    return {"segment_id": seg, "attempt_id": f"att-{seg}", "status": status, "decision_code": decision}


class NeedsBrainSchedulerTests(unittest.TestCase):
    def test_aggregate_and_precedence(self) -> None:
        ok = _done("A", "WORK_COMPLETE", "VALID")
        nb = _done("B", "NEEDS_BRAIN", "UNRESOLVED")
        self.assertEqual(ps.aggregate_decision(_state(completed=[ok, nb])), "NEEDS_BRAIN")
        for failure in ("FAIL", "BLOCK", "UNRESOLVED"):
            bad = _done("C", failure, "INVALID")
            self.assertEqual(ps.aggregate_decision(_state(completed=[nb, bad])), failure)

    def test_dependents_stay_queued_and_state_is_brain_pending(self) -> None:
        nb = _done("A", "NEEDS_BRAIN", "UNRESOLVED")
        dep = {"segment_id": "B", "segment_dependencies": ["SEGMENT:A"]}
        state = _state(completed=[nb], queued=[dep])
        self.assertEqual(ps.propagate_dependency_failure(state)["queued_segments"], [dep])
        self.assertTrue(ps.brain_pending(state))

    def test_not_pending_while_work_can_still_run(self) -> None:
        nb = _done("A", "NEEDS_BRAIN", "UNRESOLVED")
        free = {"segment_id": "C", "segment_dependencies": []}
        self.assertFalse(ps.brain_pending(_state(completed=[nb], queued=[free])))
        self.assertFalse(ps.brain_pending(_state(completed=[nb], active=[{"segment_id": "D", "attempt_id": "x"}])))
        self.assertFalse(ps.brain_pending(_state(completed=[_done("A", "WORK_COMPLETE", "VALID")])))

    def test_never_retried(self) -> None:
        self.assertNotIn("NEEDS_BRAIN", ps.FAILED_DECISIONS)
        with self.assertRaises(ValueError):
            ps.load_policy({"default_retry_on": ["NEEDS_BRAIN"]})
        self.assertEqual(DECISION_TO_STATUS["NEEDS_BRAIN"], "UNRESOLVED")


class RoutingHasNoSemanticBranchTests(unittest.TestCase):
    def test_central_and_command_layer_do_not_branch_on_decision_codes(self) -> None:
        pattern = re.compile(r"(decision(_code)?\"?\]?|effective_decision)\s*[!=]=\s*\"[A-Z_]+\"")
        for name in ("central_controller.py", "command_layer.py"):
            hits = pattern.findall((SCRIPTS / name).read_text(encoding="utf-8"))
            # 唯一允許：WORK_COMPLETE 須附 Evidence/Provenance 的有效性規則（非路由）
            self.assertLessEqual(len(hits), 1 if name == "central_controller.py" else 0, name)


if __name__ == "__main__":
    unittest.main()
