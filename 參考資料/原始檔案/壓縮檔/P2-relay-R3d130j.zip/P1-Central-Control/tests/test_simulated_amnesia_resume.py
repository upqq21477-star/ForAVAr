import json
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / "P1-Central-Control/scripts/simulated_amnesia_resume.py"


class SimulatedAmnesiaResumeTests(unittest.TestCase):
    def test_all_ten_cases_pass(self):
        proc = subprocess.run(
            [sys.executable, str(SCRIPT)],
            cwd=ROOT,
            capture_output=True,
            text=True,
            check=True,
        )
        report = json.loads(proc.stdout)
        self.assertEqual(report["case_count"], 10)
        self.assertEqual(report["status"], "PASS")
        self.assertTrue(all(case["pass"] for case in report["cases"]))

    def test_task_context_rebuild(self):
        from runpy import run_path
        ns = run_path(str(SCRIPT))
        context = ns["reconstruct_task_context"](
            current={
                "implementation_control": {
                    "active_work_packet": "P1-Central-Control/progress/M-TEST.work.json"
                },
                "current_stage": {"id": "M-TEST", "status": "BUILDING"},
            },
            task_packet={
                "object_id": "TASK_PACKET:TEST",
                "objective": "update",
                "requested_outputs": ["result"],
                "constraints": ["CENTRAL_ONLY"],
                "stop_condition": ["done"],
                "failure_condition": ["blocked"],
                "acceptance_ref": "CONSTRUCTION:TEST",
                "context_budget": {"target": 10, "hard_ceiling": 20, "estimated": 5},
                "retry_policy": {"max_attempts": 1, "retry_on": []},
                "timeout_ms": 1000,
            },
        )
        self.assertEqual(context["mode"], "AMNESIA_RECONSTRUCTED")
        self.assertEqual(context["task_packet_ref"], "TASK_PACKET:TEST")
        self.assertEqual(context["history_loaded"], 0)
        self.assertFalse(context["transient_context_loaded"])


    def test_task_context_rebuild_with_continuation_box(self):
        from runpy import run_path

        box_module = run_path(
            str(ROOT / "P1-Central-Control/scripts/continuation_context_box.py")
        )
        packet_module = run_path(
            str(ROOT / "P1-Central-Control/scripts/packet_layer.py")
        )
        segment = {
            "segment_id": "SEG-AMNESIA-BOX",
            "workflow_id": "WF-AMNESIA-BOX",
            "system_id": "SYSTEM-AMNESIA-BOX",
            "skill_id": "skill-box",
            "skill_version": "1.0",
            "objective": "resume",
            "input_scope": "test",
            "input_refs": ["INPUT:BOX"],
            "requested_outputs": ["result"],
            "constraints": ["CENTRAL_ONLY"],
            "stop_condition": ["done"],
            "failure_condition": ["blocked"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": False,
            },
            "context_cohort_id": "COHORT-AMNESIA-BOX",
            "context_budget": {
                "estimated_total_context": 10,
                "target_context_budget": 20,
                "hard_context_ceiling": 40,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }
        task = packet_module["build_task_packet"](
            segment,
            packet_module["build_attempt"](
                segment,
                attempt_number=1,
                started_at="2026-10-05T10:00:00+00:00",
            ),
        )
        current = {
            "implementation_control": {
                "active_work_packet": "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json"
            },
            "current_stage": {"id": "M-TEST", "status": "BUILDING"},
            "revision": None,
            "state_revision": 3,
            "next_exact_action": "WAIT_EXTERNAL_RESULT",
        }
        box = box_module["build"](
            current=current,
            task_packet=task,
            execution_record_ref=task["execution_record_ref"],
        )
        context = run_path(str(SCRIPT))["reconstruct_task_context"](
            current=current,
            task_packet=task,
            continuation_box=box,
        )
        self.assertEqual(context["mode"], "AMNESIA_RECONSTRUCTED_WITH_BOX")
        self.assertEqual(context["continuation_box_ref"], box["box_id"])
        self.assertEqual(context["execution_record_ref"], task["execution_record_ref"])
        self.assertEqual(context["resume_point"], "WAITING_EXTERNAL_RESULT")
        self.assertEqual(context["history_loaded"], 0)
        self.assertFalse(context["transient_context_loaded"])
        self.assertTrue(context["targeted_retrieval_only"])

    def test_task_context_rebuild_with_stale_box_blocks(self):
        from runpy import run_path

        box_module = run_path(
            str(ROOT / "P1-Central-Control/scripts/continuation_context_box.py")
        )
        packet_module = run_path(
            str(ROOT / "P1-Central-Control/scripts/packet_layer.py")
        )
        segment = {
            "segment_id": "SEG-AMNESIA-STALE",
            "workflow_id": "WF-AMNESIA-STALE",
            "system_id": "SYSTEM-AMNESIA-STALE",
            "skill_id": "skill-box",
            "skill_version": "1.0",
            "objective": "resume",
            "input_scope": "test",
            "input_refs": ["INPUT:BOX"],
            "requested_outputs": ["result"],
            "constraints": ["CENTRAL_ONLY"],
            "stop_condition": ["done"],
            "failure_condition": ["blocked"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": False,
            },
            "context_cohort_id": "COHORT-AMNESIA-STALE",
            "context_budget": {
                "estimated_total_context": 10,
                "target_context_budget": 20,
                "hard_context_ceiling": 40,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }
        task = packet_module["build_task_packet"](
            segment,
            packet_module["build_attempt"](
                segment,
                attempt_number=1,
                started_at="2026-10-05T10:00:00+00:00",
            ),
        )
        current = {
            "implementation_control": {
                "active_work_packet": "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json"
            },
            "current_stage": {"id": "M-TEST", "status": "BUILDING"},
        }
        box = box_module["build"](
            current=current,
            task_packet=task,
            execution_record_ref=task["execution_record_ref"],
        )
        stale = dict(current)
        stale["current_stage"] = {"id": "M-OTHER", "status": "BUILDING"}
        with self.assertRaisesRegex(ValueError, "STAGE_ID_STALE"):
            run_path(str(SCRIPT))["reconstruct_task_context"](
                current=stale,
                task_packet=task,
                continuation_box=box,
            )

    def test_large_history_is_bounded(self):
        from runpy import run_path
        ns = run_path(str(SCRIPT))
        case = ns["run_cases"]()[7]
        self.assertEqual(case["case_id"], 8)
        self.assertEqual(case["loaded_history"], 50)
