#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

from jsonschema import Draft202012Validator, ValidationError

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import closure_chain as cc  # noqa: E402
import continuation_context_box as ccb  # noqa: E402
from packet_layer import build_attempt, build_task_packet  # noqa: E402


def _record(baseline=None, drop=None):
    steps = [{"step": n, "ref": f"ref/{n}", "evidence_level": "SIMULATED_PASS"} for n in cc.STEPS if n != drop]
    rec = {"steps": steps}
    if baseline is not None:
        rec["baseline"] = baseline
    return rec


class BaselineHashTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        (self.root / "d").mkdir()
        (self.root / "a.txt").write_text("a", encoding="utf-8")
        (self.root / "d" / "b.txt").write_text("b", encoding="utf-8")

    def tearDown(self):
        self._tmp.cleanup()

    def test_hash_is_stable_and_order_independent(self):
        h1 = ccb.semantic_baseline_hash(self.root, ["a.txt", "d"])
        h2 = ccb.semantic_baseline_hash(self.root, ["d", "a.txt", "a.txt"])
        self.assertEqual(h1, h2)
        self.assertRegex(h1, r"^sha256:[0-9a-f]{64}$")

    def test_hash_changes_on_edit_add_and_delete(self):
        base = ccb.semantic_baseline_hash(self.root, ["a.txt", "d"])
        (self.root / "a.txt").write_text("a2", encoding="utf-8")
        edited = ccb.semantic_baseline_hash(self.root, ["a.txt", "d"])
        (self.root / "d" / "c.txt").write_text("c", encoding="utf-8")
        added = ccb.semantic_baseline_hash(self.root, ["a.txt", "d"])
        (self.root / "d" / "b.txt").unlink()
        deleted = ccb.semantic_baseline_hash(self.root, ["a.txt", "d"])
        self.assertEqual(len({base, edited, added, deleted}), 4)

    def test_missing_path_hashes_differently_from_existing(self):
        self.assertNotEqual(ccb.semantic_baseline_hash(self.root, ["a.txt"]), ccb.semantic_baseline_hash(self.root, ["nope.txt"]))

    def test_unsafe_radius_paths_are_rejected(self):
        for bad in ("../x", "/etc/passwd", " "):
            with self.assertRaisesRegex(ValueError, "BASELINE_RADIUS_PATH_INVALID"):
                ccb.semantic_baseline_hash(self.root, [bad])
        with self.assertRaisesRegex(ValueError, "BASELINE_RADIUS_SIZE"):
            ccb.make_baseline(self.root, [], 1)

    def test_check_baseline_statuses(self):
        base = ccb.make_baseline(self.root, ["a.txt"], 7)
        self.assertEqual(ccb.check_baseline(base, self.root, current_revision=7)["status"], "OK")
        self.assertEqual(ccb.check_baseline(base, self.root, current_revision=8)["reasons"], ["BASELINE_REVISION_STALE"])
        self.assertEqual(ccb.check_baseline(None, self.root)["status"], "MISSING")
        self.assertEqual(ccb.check_baseline({"baseline_revision": 1}, self.root)["status"], "MISSING")
        (self.root / "a.txt").write_text("changed", encoding="utf-8")
        self.assertEqual(ccb.check_baseline(base, self.root)["reasons"], ["SEMANTIC_BASELINE_STALE"])
        bad = dict(base, change_radius=["../x"])
        self.assertEqual(ccb.check_baseline(bad, self.root)["status"], "REJECTED")


class BoxBaselineTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.root = Path(self._tmp.name)
        (self.root / "a.txt").write_text("a", encoding="utf-8")
        (self.root / "other.txt").write_text("o", encoding="utf-8")
        seg = cc._demo_segment()
        self.task = build_task_packet(seg, build_attempt(seg, attempt_number=1, started_at="2026-10-15T10:00:00+00:00"))
        self.current = {"revision": 7, "state_revision": 3, "current_stage": {"id": "M", "status": "BUILDING"},
                        "next_exact_action": "WAIT"}
        self.baseline = ccb.make_baseline(self.root, ["a.txt"], 7)

    def tearDown(self):
        self._tmp.cleanup()

    def box(self, baseline="default"):
        b = self.baseline if baseline == "default" else baseline
        return ccb.build(current=self.current, task_packet=self.task, execution_record_ref=self.task["execution_record_ref"], baseline=b)

    def test_build_without_baseline_is_unchanged(self):
        self.assertNotIn("baseline", self.box(None))

    def test_reconstruct_without_root_ignores_baseline_for_backward_compat(self):
        self.assertEqual(ccb.reconstruct(current=self.current, task_packet=self.task, box=self.box())["mode"], "AMNESIA_RECONSTRUCTED_WITH_BOX")

    def test_resume_ok_stale_and_outside_radius(self):
        box = self.box()
        ok = ccb.resume_check(current=self.current, task_packet=self.task, box=box, root=self.root)
        self.assertEqual(ok["status"], "OK")
        (self.root / "other.txt").write_text("changed", encoding="utf-8")
        self.assertEqual(ccb.resume_check(current=self.current, task_packet=self.task, box=box, root=self.root)["status"], "OK")
        (self.root / "a.txt").write_text("changed", encoding="utf-8")
        stale = ccb.resume_check(current=self.current, task_packet=self.task, box=box, root=self.root)
        self.assertEqual(stale["status"], "STALE")
        self.assertIn("SEMANTIC_BASELINE_STALE", stale["reason"])
        with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_BASELINE_STALE"):
            ccb.reconstruct(current=self.current, task_packet=self.task, box=box, root=self.root)

    def test_require_baseline_and_root_rules(self):
        with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_BASELINE_MISSING"):
            ccb.reconstruct(current=self.current, task_packet=self.task, box=self.box(None), require_baseline=True)
        with self.assertRaisesRegex(ValueError, "CONTINUATION_BOX_BASELINE_ROOT_REQUIRED"):
            ccb.reconstruct(current=self.current, task_packet=self.task, box=self.box(), require_baseline=True)
        self.assertEqual(ccb.resume_check(current=self.current, task_packet=self.task, box=self.box(None), require_baseline=True)["status"], "REJECTED")

    def test_baseline_revision_drift_is_stale(self):
        box = self.box(dict(self.baseline, baseline_revision=6))
        res = ccb.resume_check(current=self.current, task_packet=self.task, box=box, root=self.root)
        self.assertEqual(res["status"], "STALE")
        self.assertIn("BASELINE_REVISION_STALE", res["reason"])

    def test_schemas_carry_the_same_optional_baseline_definition(self):
        defs = []
        for name in ("continuation_context_box", "operational_work_unit"):
            sch = json.loads((ROOT / f"P1-Central-Control/schemas/{name}.schema.json").read_text(encoding="utf-8"))
            self.assertNotIn("baseline", sch["required"])
            defs.append(sch["properties"]["baseline"])
        self.assertEqual(defs[0], defs[1])
        self.assertEqual(set(defs[0]["required"]), set(ccb.BASELINE_KEYS))

    def test_bad_baseline_shapes_fail_schema_validation(self):
        for bad in (dict(self.baseline, semantic_baseline_hash="abc"), dict(self.baseline, change_radius=[]),
                    dict(self.baseline, change_radius=["a", "a"]), dict(self.baseline, extra=1)):
            with self.assertRaises(ValidationError):
                self.box(bad)
        sch = json.loads((ROOT / "P1-Central-Control/schemas/operational_work_unit.schema.json").read_text(encoding="utf-8"))
        sub = Draft202012Validator(sch["properties"]["baseline"])
        self.assertEqual(list(sub.iter_errors(self.baseline)), [])
        self.assertTrue(list(sub.iter_errors({"baseline_revision": 1})))


class ClosureChainTests(unittest.TestCase):
    def test_complete_chain(self):
        res = cc.evaluate(_record())
        self.assertEqual((res["status"], res["next_action"]), ("COMPLETE", "HANDOFF"))

    def test_each_missing_step_is_incomplete(self):
        for name in cc.STEPS:
            res = cc.evaluate(_record(drop=name))
            self.assertEqual(res["status"], "INCOMPLETE", name)
            self.assertIn(f"MISSING_STEP:{name}", res["reasons"])

    def test_order_duplicate_unknown_and_shape_are_rejected(self):
        rec = _record()
        rec["steps"][0], rec["steps"][1] = rec["steps"][1], rec["steps"][0]
        self.assertIn("ORDER_VIOLATION", cc.evaluate(rec)["reasons"])
        dup = _record()
        dup["steps"].append(dict(dup["steps"][0]))
        self.assertEqual(cc.evaluate(dup)["status"], "REJECTED")
        unk = _record()
        unk["steps"].append({"step": "EXTRA", "ref": "x", "evidence_level": "DOC_ONLY"})
        self.assertEqual(cc.evaluate(unk)["status"], "REJECTED")
        for bad in (None, {}, {"steps": "x"}, {"steps": ["x"]}):
            self.assertEqual(cc.evaluate(bad)["status"], "REJECTED")

    def test_missing_ref_and_weak_evidence_are_incomplete(self):
        for mutate, want in ((lambda s: s.update(ref=" "), "NO_REF:SCOPE"),
                             (lambda s: s.update(evidence_level="NOT_EXECUTED"), "NOT_EXECUTED:SCOPE"),
                             (lambda s: s.update(evidence_level="MADE_UP"), "BAD_LEVEL:SCOPE")):
            rec = _record()
            mutate(rec["steps"][0])
            res = cc.evaluate(rec)
            self.assertEqual(res["status"], "INCOMPLETE")
            self.assertIn(want, res["reasons"])

    def test_rejected_outranks_stale_and_incomplete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "a.txt").write_text("a", encoding="utf-8")
            base = ccb.make_baseline(root, ["a.txt"], 1)
            (root / "a.txt").write_text("b", encoding="utf-8")
            self.assertEqual(cc.evaluate(_record(base), root, 1)["status"], "STALE")
            self.assertEqual(cc.evaluate(_record(base, drop="IMPACT"), root, 1)["status"], "STALE")
            swapped = _record(base)
            swapped["steps"].reverse()
            self.assertEqual(cc.evaluate(swapped, root, 1)["status"], "REJECTED")
            self.assertEqual(cc.evaluate(_record(base), None)["reasons"], ["BASELINE_ROOT_REQUIRED"])

    def test_chain_does_not_own_current(self):
        src = (SCRIPTS / "closure_chain.py").read_text(encoding="utf-8")
        for forbidden in ("P1-CURRENT.json", "write_text", "write_bytes", ".unlink(", "shutil"):
            self.assertNotIn(forbidden, src.split("def simulate")[0].split('"""', 2)[2], forbidden)


class SimulationAndMutationTests(unittest.TestCase):
    def failed(self):
        return [n for n, ok, _ in cc.simulate() if not ok]

    def test_simulation_passes(self):
        self.assertEqual(self.failed(), [])

    def test_mutation_baseline_check_always_ok_is_caught(self):
        with mock.patch.object(ccb, "check_baseline", lambda *a, **k: {"status": "OK", "reasons": []}):
            self.assertTrue(self.failed())

    def test_mutation_constant_hash_is_caught(self):
        with mock.patch.object(ccb, "semantic_baseline_hash", lambda *a, **k: "sha256:" + "0" * 64):
            self.assertTrue(self.failed())

    def test_mutation_evaluate_always_complete_is_caught(self):
        with mock.patch.object(cc, "evaluate", lambda *a, **k: {"status": "COMPLETE", "reasons": [], "next_action": "HANDOFF"}):
            self.assertTrue(self.failed())

    def test_mutation_wrong_canonical_order_is_caught(self):
        with mock.patch.object(cc, "STEPS", tuple(reversed(cc.STEPS))):
            self.assertTrue(self.failed())


if __name__ == "__main__":
    unittest.main()
