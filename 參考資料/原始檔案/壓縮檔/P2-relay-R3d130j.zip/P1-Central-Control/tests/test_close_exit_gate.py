import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
import close_session as cs  # noqa: E402
import lifecycle_sweep as ls  # noqa: E402

SWEEP = ROOT / "P1-Central-Control" / "scripts" / "lifecycle_sweep.py"


def sweep_rc(root):
    cmd = cs.exit_steps(root=str(root), sweep=str(SWEEP))[0][1]
    return subprocess.run(cmd, capture_output=True, text=True).returncode


class ExitGateTests(unittest.TestCase):  # SIMULATED_PASS: temp mini repo only
    def test_close_session_runs_exit_gate_steps(self):
        self.assertEqual([lab for lab, _ in cs.exit_steps()],
                         ["exit gate: lifecycle sweep", "exit gate: budget ratchet (down only)"])

    def test_exit_gate_is_red_with_junk_and_green_after_removal(self):
        with tempfile.TemporaryDirectory() as t:
            root = ls.sim_repo(Path(t))
            self.assertNotEqual(sweep_rc(root), 0)
            for rel in ("scripts/dead.py", "scripts/dead_dep.py"):
                (root / ls.CTRL / rel).unlink()
            self.assertEqual(sweep_rc(root), 0)


if __name__ == "__main__":
    unittest.main()
