#!/usr/bin/env python3
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import command_layer  # noqa: E402
import minimal_closed_loop_runner as runner  # noqa: E402


class ThinContinuationTests(unittest.TestCase):
    def test_continuation_invokes_existing_command_layer(self):
        state = command_layer.initialize_command_state("WF:M32-C01-B")
        command = command_layer.build_command(state, "START")

        with tempfile.TemporaryDirectory() as temp:
            event_log = Path(temp) / "events.jsonl"
            result = runner.continue_once(
                state,
                command,
                event_log_path=event_log,
            )

            self.assertEqual(result["status"], "PASS")
            self.assertTrue(result["continued"])
            observation = result["observation"]
            self.assertEqual(observation["result_status"], command_layer.ACCEPTED)
            self.assertEqual(observation["state"]["status"], "RUNNING")
            self.assertEqual(observation["state"]["state_revision"], 1)
            self.assertEqual(len(command_layer.EventLog(event_log).read_all()), 1)

    def test_runtime_runner_does_not_execute_construction_acceptance(self):
        packet = {
            "acceptance": {
                "profile": "M32-C01-CLOSE"
            },
            "next_action": {
                "command_type": "RUN_REPOSITORY_TESTS",
                "args": {
                    "tests": ["P1-Central-Control/tests/test_thin_continuation.py"]
                },
            },
        }

        original = runner.execute_typed_action
        runner.execute_typed_action = lambda *args, **kwargs: {
            "status": "PASS",
            "command_type": "RUN_REPOSITORY_TESTS",
            "returncode": 0,
            "timed_out": False,
            "stdout": "",
            "stderr": "",
            "command": [],
        }
        try:
            with tempfile.TemporaryDirectory() as temp:
                result = runner.run_once(
                    ROOT,
                    packet,
                    timeout_seconds=30,
                )
        finally:
            runner.execute_typed_action = original

        self.assertEqual(result["status"], "PASS")
        self.assertNotIn("contract_execution", result)


    def test_continuation_does_not_execute_typed_action(self):
        state = command_layer.initialize_command_state("WF:M32-C01-B")
        command = command_layer.build_command(state, "START")

        original = runner.execute_typed_action
        runner.execute_typed_action = lambda *args, **kwargs: (_ for _ in ()).throw(
            AssertionError("thin continuation must not execute OS action")
        )
        try:
            with tempfile.TemporaryDirectory() as temp:
                result = runner.continue_once(
                    state,
                    command,
                    event_log_path=Path(temp) / "events.jsonl",
                )
        finally:
            runner.execute_typed_action = original

        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["continued"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
