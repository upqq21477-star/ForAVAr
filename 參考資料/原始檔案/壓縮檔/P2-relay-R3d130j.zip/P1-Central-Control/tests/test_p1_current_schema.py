#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import jsonschema


class P1CurrentSchemaTests(unittest.TestCase):
    def test_current_authority_matches_schema(self):
        schema = json.loads(
            (ROOT / "P1-Central-Control/schemas/p1_current.schema.json").read_text(encoding="utf-8")
        )
        current = json.loads((ROOT / "P1-CURRENT.json").read_text(encoding="utf-8"))
        jsonschema.validate(current, schema)


if __name__ == "__main__":
    unittest.main()
