import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import debug_escalation_policy as dep  # noqa: E402
import p2_run  # noqa: E402


def failed(rows):
    return [n for n, ok, _ in rows if not ok]


class P2RunTests(unittest.TestCase):
    def test_simulation_all_pass(self):
        rows = p2_run.simulate()
        self.assertGreaterEqual(len(rows), 30)
        self.assertEqual(failed(rows), [])

    def test_gate_negatives_cover_required_scenarios(self):
        self.assertGreaterEqual(sum(1 for n, _, _ in p2_run.simulate() if n.startswith("N")), 11)

    def test_mutant_no_path_check_is_caught(self):
        # R6: expectation unchanged (a mutant of the ORIGINAL path check must be caught). With fast paths on, FP1 also
        # rejects the escape (defence in depth), which would mask this mutant by design, so test the original route.
        orig, orig_fast = p2_run.Run._path, p2_run.DEFAULT_FAST
        p2_run.Run._path, p2_run.DEFAULT_FAST = (lambda self, rel: self.work / str(rel)), False
        try:
            try:
                bad = failed(p2_run.simulate())
            except Exception:  # an escaping path now crashes the run: also a caught mutant
                bad = ["N01"]
        finally:
            p2_run.Run._path, p2_run.DEFAULT_FAST = orig, orig_fast
        self.assertTrue(any(n.startswith(("N01", "N02")) for n in bad))

    def test_mutant_trace_verifier_always_ok_is_caught(self):
        orig = p2_run.verify_trace
        p2_run.verify_trace = lambda t: []
        try:
            bad = failed(p2_run.simulate())
        finally:
            p2_run.verify_trace = orig
        self.assertTrue(any(n.startswith("N11") for n in bad))

    def test_mutant_unbounded_retry_is_caught(self):
        orig = dep.RETRY_MAX
        dep.RETRY_MAX = 5
        try:
            bad = failed(p2_run.simulate())
        finally:
            dep.RETRY_MAX = orig
        self.assertTrue(any(n.startswith("S02") for n in bad))

    def test_mutant_loop_contract_always_ok_is_caught(self):
        orig = p2_run.loop_contract
        p2_run.loop_contract = lambda r, c=None: []
        try:
            bad = failed(p2_run.simulate())
        finally:
            p2_run.loop_contract = orig
        self.assertTrue(any(n.startswith("L0") for n in bad))

    def test_mutant_role_gate_allows_everything_is_caught(self):
        orig = p2_run.rsg.admission
        p2_run.rsg.admission = lambda req: {"status": "ALLOW", "reason_codes": []}
        try:
            bad = failed(p2_run.simulate())
        finally:
            p2_run.rsg.admission = orig
        self.assertTrue(any(n.startswith(("R02", "R03", "R04", "R05")) for n in bad))

    def test_mutant_baseline_check_always_ok_is_caught(self):
        orig = p2_run.ccb.check_baseline
        p2_run.ccb.check_baseline = lambda *a, **k: {"status": "OK", "reasons": []}
        try:
            bad = failed(p2_run.simulate())
        finally:
            p2_run.ccb.check_baseline = orig
        self.assertTrue(any(n.startswith("C09") for n in bad))

    def test_retry_decision_shapes(self):
        a = [{"step": "s", "outcome": "failure", "head_sha": "h", "t": 0}]
        self.assertEqual(dep.retry_decision(a, "s")["action"], "RETRY")
        a.append({"step": "s", "outcome": "failure", "head_sha": "h", "t": 1})
        self.assertEqual(dep.retry_decision(a, "s")["action"], "STOP_WAITING")
        a.append({"step": "s", "outcome": "success", "head_sha": "h", "t": 2})
        self.assertEqual(dep.retry_decision(a, "s")["action"], "PROCEED")
        self.assertEqual(dep.retry_decision([], "s")["action"], "PROCEED")

    def test_cli_exit_codes(self):
        self.assertEqual(p2_run.main.__module__, "p2_run")


if __name__ == "__main__":
    unittest.main()
