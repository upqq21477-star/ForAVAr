#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SCRIPTS=ROOT/"P1-Central-Control/scripts"
sys.path.insert(0,str(SCRIPTS))

import local_acceptance_capture as m13


class LocalAcceptanceCaptureTests(unittest.TestCase):
    def report(self,status="PASS"):
        return {
            "report_id":"LOCAL_CONTROL_GATE:abcdef1234567",
            "base_sha":"abcdef1234567",
            "head_sha":"fedcba7654321",
            "status":status,
            "stages":[{
                "stage_id":"UNIT_TEST",
                "status":status,
                "object_ref":None,
                "reason_code":None if status=="PASS" else "TEST",
            }],
        }

    def test_builds_hashed_acceptance_record(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"report.json"
            path.write_text("{}",encoding="utf-8")
            record=m13.build(self.report(),path)
        self.assertTrue(record["report_sha256"].startswith("sha256:"))
        self.assertEqual(record["status"],"PASS")
        self.assertEqual(record["execution_source"],"LOCAL")
        self.assertEqual(record["execution_id"],"LOCAL:fedcba7654321")

    def test_incomplete_propagates(self):
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"report.json"
            path.write_text("{}",encoding="utf-8")
            record=m13.build(self.report("INCOMPLETE"),path)
        self.assertEqual(record["status"],"INCOMPLETE")


    def test_close_simulation_pass_updates_canonical_close_state(self):
        import json

        report=self.report()
        report["mode"]="SIMULATION_ONLY"
        report["simulated"]=True
        report["work_unit"]="M32-CLOSE"
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            report_path=root/"report.json"
            report_path.write_text(json.dumps(report),encoding="utf-8")
            record=m13.build(report,report_path)

            current={
                "current_stage":{
                    "id":"M32-CLOSE",
                    "status":"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
                    "validated_control_gate_run":None,
                    "validated_head_sha":None,
                    "acceptance_ref":"acceptance.json",
                    "work_unit_id":"M32-CLOSE",
                },
                "latest_runtime_observation":{},
            }
            work={
                "status":"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
                "acceptance":{"mode":"SIMULATION_ONLY"},
                "completion":{},
            }
            construction={
                "work_unit":"M32-CLOSE",
                "status":"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            }
            current_path=root/"P1-CURRENT.json"
            acceptance_path=root/"acceptance.json"
            acceptance_path.write_text(json.dumps({
                "context_id":"ACCEPTANCE_CONTEXT:M32-CLOSE",
                "kind":"ACCEPTANCE_CONTEXT",
                "status":"OPEN",
                "authority":"P1-CURRENT",
                "lifecycle_owner":"CENTRAL",
                "mode":"SIMULATION_ONLY",
                "head_sha":"fedcba7654321",
                "work_unit_ref":"M32-CLOSE",
                "work_id":"M32-CLOSE-VERTICAL-SLICE",
                "task_packet_ref":"TASK_PACKET:pkt-M32-CLOSE",
                "construction_packet_ref":"CONSTRUCTION:M32-CLOSE",
                "required_checks":["repository_result_reentry"],
                "source_refs":["P1-CURRENT.json"],
                "content_sha256":"sha256:" + ("0"*64),
            }),encoding="utf-8")
            work_path=root/"work.json"
            construction_path=root/"construction.json"
            for path,value in (
                (current_path,current),
                (work_path,work),
                (construction_path,construction),
            ):
                path.write_text(json.dumps(value),encoding="utf-8")

            result=m13.close_simulation(
                report,
                record,
                current_path=current_path,
                work_packet_path=work_path,
                construction_packet_path=construction_path,
                execution_source="LOCAL",
                head_sha=report["head_sha"],
            )
            self.assertEqual(result["status"],"PASS")
            self.assertEqual(json.loads(current_path.read_text())["current_stage"]["status"],"VERIFIED")
            self.assertIsNone(json.loads(current_path.read_text())["current_stage"]["validated_control_gate_run"])
            self.assertEqual(result["execution_source"],"LOCAL")
            self.assertEqual(result["execution_id"],"LOCAL:fedcba7654321")
            self.assertEqual(json.loads(work_path.read_text())["status"],"VERIFIED")
            self.assertEqual(json.loads(construction_path.read_text())["status"],"VERIFIED")
            # Regression: canonical files must end with a real newline, never a literal backslash-n.
            for written in (current_path,work_path,construction_path):
                text=written.read_text(encoding="utf-8")
                self.assertTrue(text.endswith("}\n"),written.name)
                self.assertNotIn("\\n",text.replace('\\"',""),written.name)

    def test_raw_report_fields_are_not_copied(self):
        report=self.report()
        report["raw_stdout"]="secret"
        report["raw_stderr"]="secret"
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/"report.json"
            path.write_text("{}",encoding="utf-8")
            with self.assertRaises(Exception):
                m13.build(report,path)


if __name__=="__main__":
    unittest.main()
