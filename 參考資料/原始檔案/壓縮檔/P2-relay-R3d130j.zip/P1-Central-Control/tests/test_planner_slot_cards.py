import copy
import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import planner_library as pl  # noqa: E402


def code(fn, *a, **k):
    try:
        fn(*a, **k)
    except ValueError as e:
        return str(e).split(":")[0]
    return None


class SlotCardTests(unittest.TestCase):
    def setUp(self):
        self.cfg = json.loads(pl.SLOTS_PATH.read_text(encoding="utf-8"))

    def test_every_route_loads_valid_deterministic_cards(self):
        for route in self.cfg["routes"]:
            a, b = pl.cards_for_route(route), pl.cards_for_route(route)
            self.assertEqual(a, b)
            self.assertTrue(a["cards"], route)
            for c in a["cards"]:
                pl.check_card(c, "CAPABILITY")

    def test_one_card_per_capability_when_slots_share_a_function(self):
        # S_EVENTLOG, S_TRANSITION, S_CENTRAL all carry F05 -> exactly one card
        r = pl.cards_for_slots(["S_EVENTLOG", "S_TRANSITION", "S_CENTRAL"])
        self.assertEqual(len(r["cards"]), 1)

    def test_negative_unknown_slot_route_function(self):
        self.assertEqual(code(pl.cards_for_slots, ["S_NOPE"]), "SLOT_UNDEFINED")
        self.assertEqual(code(pl.cards_for_route, "NOPE"), "ROUTE_UNDEFINED")
        self.assertEqual(code(pl.cards_for_slots, ["S_MODE"], functions={}), "FUNCTION_UNMAPPED")

    def test_negative_capability_not_active_fails_closed(self):
        fx = {"F01": {"function_id": "F01", "canonical_capability": "CAP-DOES-NOT-EXIST"}}
        self.assertEqual(code(pl.cards_for_slots, ["S_MODE"], functions=fx), "CAPABILITY_NOT_ACTIVE")

    def test_slot_without_function_is_skipped_not_guessed(self):
        cfg = copy.deepcopy(self.cfg)
        cfg["slots"]["S_MODE"].pop("function_id")
        r = pl.cards_for_slots(["S_MODE"], cfg)
        self.assertEqual((r["cards"], r["skipped"]), ([], ["S_MODE"]))

    def test_mutation_card_limit_is_enforced(self):
        cfg = copy.deepcopy(self.cfg)
        fx, ids = {}, []
        caps = [c["capability_id"] for c in json.loads(pl.REGISTRY.read_text(encoding="utf-8"))["capabilities"]
                if c["retirement_state"] == "ACTIVE"]
        for i, cap in enumerate(caps[:5]):
            cfg["slots"][f"S_X{i}"] = {"source": "x", "symbol": "x", "function_id": f"FX{i}"}
            fx[f"FX{i}"] = {"function_id": f"FX{i}", "canonical_capability": cap}
            ids.append(f"S_X{i}")
        old = pl.MAX_SLOT_CARDS
        pl.MAX_SLOT_CARDS = 2
        try:
            self.assertEqual(code(pl.cards_for_slots, ids, cfg, fx), "SLOT_CARDS_OVER_LIMIT")
        finally:
            pl.MAX_SLOT_CARDS = old


if __name__ == "__main__":
    unittest.main()
