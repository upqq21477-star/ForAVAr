#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import p14_d_recovery_entrypoint as m


class P14DRecoveryEntrypointTests(unittest.TestCase):
    def test_observed_bundle_is_accepted(self):
        value = m.normalize_local_bundle({
            "evidence_id": "LOCAL_P14_D:abc1234",
            "status": "PASS",
            "head_sha": "abc1234",
            "evidence_class": "OBSERVED_LOCAL_RUNTIME",
            "truth_boundary": "LOCAL_RUNTIME_ONLY_NOT_GITHUB_ACTIONS",
        })
        self.assertEqual(value["acceptance_id"], "LOCAL_P14_D:abc1234")
        self.assertEqual(value["evidence_class"], "OBSERVED_LOCAL_RUNTIME")

    def test_simulated_bundle_is_rejected_by_production_normalizer(self):
        with self.assertRaisesRegex(ValueError, "LOCAL_BUNDLE_EVIDENCE_CLASS_INVALID"):
            m.normalize_local_bundle({
                "evidence_id": "SCENARIO:abc1234",
                "status": "PASS",
                "head_sha": "abc1234",
                "evidence_class": "SIMULATED_SCENARIO",
                "truth_boundary": "SIMULATED_SCENARIO_ONLY",
            })

    def test_runtime_fixture_uses_existing_diagnostic_id(self):
        diagnostic = {
            "diagnostic_id": "ACTIONS_DIAGNOSTIC:37185369048",
            "classification": "RUNNER_STARTUP_FAILURE",
            "head_sha": "abc1234",
        }
        result = m.runtime_fixture_from_diagnostic(diagnostic, head_sha="abc1234")
        self.assertEqual(result["run"]["id"], 37185369048)
        self.assertEqual(result["run"]["head_sha"], "abc1234")

    def test_run_head_mismatch_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "ACTIONS_RUN_HEAD_SHA_MISMATCH"):
            m.execute(
                run_path=ROOT / "P1-Central-Control/fixtures/p14-d-recovery-run-37185662542.json",
                jobs_path=ROOT / "P1-Central-Control/fixtures/p14-d-recovery-jobs-37185662542.json",
                local_bundle_path=ROOT / "P1-Central-Control/fixtures/p14-d-local-acceptance-pass-3b1fec8b94bdcc78f4ae6c31eef42bac1237dbb5.json",
                head_sha="deadbeef",
            )


if __name__ == "__main__":
    unittest.main()
