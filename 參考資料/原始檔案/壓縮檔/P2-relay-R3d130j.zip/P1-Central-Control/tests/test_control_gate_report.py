#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SCRIPTS=ROOT/"P1-Central-Control/scripts"
sys.path.insert(0,str(SCRIPTS))

import control_gate_report as report


class ControlGateReportTests(unittest.TestCase):
    def stage(self,status="PASS"):
        return {
            "stage_id":"UNIT_TEST",
            "status":status,
            "object_ref":None,
            "reason_code":None,
        }

    def report_data(self):
        return {
            "report_id":"LOCAL_CONTROL_GATE:abcdef1234567",
            "base_sha":"abcdef1234567",
            "head_sha":"fedcba7654321",
            "status":"PASS",
            "stages":[self.stage()],
        }

    def test_valid_report(self):
        report.validate(self.report_data())

    def test_unknown_stage_field_is_rejected(self):
        value=self.report_data()
        value["stages"][0]["raw"]="forbidden"
        with self.assertRaises(Exception):
            report.validate(value)

    def test_unknown_top_level_field_is_rejected(self):
        value=self.report_data()
        value["stderr"]="forbidden"
        with self.assertRaises(Exception):
            report.validate(value)

    def test_incomplete_is_valid(self):
        value=self.report_data()
        value["status"]="INCOMPLETE"
        value["stages"][0]["status"]="INCOMPLETE"
        value["stages"][0]["reason_code"]="RUNNER_STARTUP_FAILURE"
        report.validate(value)


if __name__=="__main__":
    unittest.main()
