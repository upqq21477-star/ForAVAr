#!/usr/bin/env python3
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"P1-Central-Control/scripts"))
import research_source_normalization as normalization

class ResearchSourceNormalizationTests(unittest.TestCase):
    def test_duplicate_url_deduplicates(self):
        result=normalization.normalize([
            {"source_title":"Example","source_url":"https://Example.com/x/","captured_at":"2026-10-04T00:00:00Z","claim_scope":["claim-a"]},
            {"source_title":"Example","source_url":"https://example.com/x","captured_at":"2026-10-04T00:01:00Z","claim_scope":["claim-a"]}
        ])
        self.assertEqual(result["status"],"PASS")
        self.assertEqual(result["unique_source_count"],1)
        self.assertEqual(result["mapping"][0]["source_id"],result["mapping"][1]["source_id"])

    def test_conflicting_metadata_blocks(self):
        result=normalization.normalize([
            {"source_title":"Example A","source_url":"https://example.com/x","captured_at":"2026-10-04T00:00:00Z","claim_scope":["claim-a"]},
            {"source_title":"Example B","source_url":"https://example.com/x","captured_at":"2026-10-04T00:01:00Z","claim_scope":["claim-a"]}
        ])
        self.assertEqual(result["status"],"BLOCK")
        self.assertEqual(result["errors"][0]["code"],"SOURCE_URL_METADATA_CONFLICT")

    def test_invalid_source_type_is_structured_block(self):
        result=normalization.normalize([
            {"source_title":"Example","source_url":"https://example.com/x","captured_at":"2026-10-04T00:00:00Z","claim_scope":["claim-a"],"source_type":"NOT_A_SOURCE_TYPE"}
        ])
        self.assertEqual(result["status"],"BLOCK")
        self.assertEqual(result["errors"][0]["code"],"SOURCE_SCHEMA_INVALID")

    def test_invalid_capture_time_is_structured_block(self):
        result=normalization.normalize([
            {"source_title":"Example","source_url":"https://example.com/x","captured_at":"not-a-date","claim_scope":["claim-a"]}
        ])
        self.assertEqual(result["status"],"BLOCK")
        self.assertEqual(result["errors"][0]["code"],"SOURCE_CAPTURED_AT_INVALID")

    def test_timezone_is_required_for_capture_time(self):
        result=normalization.normalize([
            {"source_title":"Example","source_url":"https://example.com/x","captured_at":"2026-10-04T00:00:00","claim_scope":["claim-a"]}
        ])
        self.assertEqual(result["status"],"BLOCK")
        self.assertEqual(result["errors"][0]["code"],"SOURCE_CAPTURED_AT_TIMEZONE_REQUIRED")

    def test_missing_claim_scope_blocks(self):
        result=normalization.normalize([
            {"source_title":"Example","source_url":"https://example.com/x","captured_at":"2026-10-04T00:00:00Z"}
        ])
        self.assertEqual(result["status"],"BLOCK")
        self.assertEqual(result["errors"][0]["code"],"CLAIM_SCOPE_MISSING")

if __name__=="__main__":
    unittest.main()
