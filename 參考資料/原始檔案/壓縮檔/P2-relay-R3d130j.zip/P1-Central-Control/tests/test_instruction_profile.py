import unittest

from instruction_profile import activate, compile_prompt, load_profile, resolve_shortcut


class InstructionProfileTests(unittest.TestCase):
    def test_research_shortcut_resolves(self):
        route = resolve_shortcut("啟用深度研究+外部研究")
        self.assertEqual(route["command"], "instruction.activate")
        self.assertEqual(route["profile_id"], "IP:RESEARCH-DEEP-EXTERNAL")

    def test_compiled_prompt_prioritizes_truth_evidence_precision(self):
        profile = load_profile("IP:RESEARCH-DEEP-EXTERNAL")
        prompt = compile_prompt(profile)
        self.assertLess(prompt.index("優先可驗證"), prompt.index("跨來源"))
        self.assertIn("不得虛構不存在的來源", prompt)

    def test_activate_returns_compact_semantic_tags(self):
        result = activate("啟用深度研究+外部研究")
        self.assertEqual(result["profile_id"], "IP:RESEARCH-DEEP-EXTERNAL")
        self.assertIn("TRUTH", result["semantic_tags"])
        self.assertIn("EVIDENCE", result["semantic_tags"])
        self.assertIn("EXTERNAL_VALIDATION", result["semantic_tags"])
        self.assertIn("P1_controlled", result["model_controls"])
        self.assertIn("provider_internal", result["model_controls"])


if __name__ == "__main__":
    unittest.main()
