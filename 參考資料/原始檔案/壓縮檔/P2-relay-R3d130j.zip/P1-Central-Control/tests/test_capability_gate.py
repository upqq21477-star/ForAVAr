import json
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import capability_gate as cg

def _maturity(d, caps, tree='h1'):
    p = Path(d) / 'm.json'
    p.write_text(json.dumps({'tree_hash': tree, 'generated_at': 't', 'capabilities': caps}), encoding='utf-8')
    return p

class GateWarnTests(unittest.TestCase):

    def setUp(self):
        self.t = tempfile.TemporaryDirectory()
        self.d = self.t.name
        self.m = _maturity(self.d, {'CAP-A': 'WIRED', 'CAP-B': 'UNWIRED'})

    def tearDown(self):
        self.t.cleanup()

    def test1_unwired_refuse(self):
        r = cg.check('CAP-B', self.m)
        self.assertEqual((r['decision'], r['error_code']), ('REFUSE', 'CAP_NOT_WIRED'))

    def test2_missing_file_refuse(self):
        self.assertEqual(cg.check('CAP-A', Path(self.d) / 'nope.json')['decision'], 'REFUSE')

    def test3_truncated_json_refuse(self):
        p = Path(self.d) / 't.json'
        p.write_text('{"tree_hash": "h1", "capab', encoding='utf-8')
        self.assertEqual(cg.check('CAP-A', p)['decision'], 'REFUSE')

    def test4_stale_tree_hash_refuse(self):
        r = cg.check('CAP-A', self.m, tree_hash='other')
        self.assertEqual((r['decision'], r['reason']), ('REFUSE', 'MATURITY_STALE'))

    def test5_wired_allow(self):
        self.assertEqual(cg.check('CAP-A', self.m, tree_hash='h1')['decision'], 'ALLOW')

    def test6_fallback_declared(self):
        self.assertEqual(cg.check('CAP-B', self.m, fallback_declared=True)['decision'], 'FALLBACK')

    def test7_unknown_capability_refuse(self):
        r = cg.check('CAP-ZZZ', self.m)
        self.assertEqual((r['decision'], r['reason']), ('REFUSE', 'UNKNOWN_CAPABILITY'))

    def test8_warn_never_blocks(self):
        for cid in ('CAP-A', 'CAP-B', 'CAP-ZZZ'):
            r = cg.check(cid, self.m)
            self.assertIs(r['blocked'], False)
            self.assertEqual(r['enforcement'], 'WARN_ONLY')

    def _repo(self):
        sd = Path(self.d) / 'repo' / 'P1-Central-Control' / 'state' / 'capabilities'
        sd.mkdir(parents=True)
        for c in ('CAP-A', 'CAP-B'):
            (sd / (c + '.json')).write_text(json.dumps({'capability_id': c}), encoding='utf-8')
        return Path(self.d) / 'repo'

    def test9_report_and_cli_exit_zero(self):
        repo = self._repo()
        rep = cg.report(repo, self.m)
        self.assertEqual((rep['total'], rep['allow'], rep['would_refuse']), (2, 1, 1))
        self.assertEqual(cg.main(['--root', str(repo), '--maturity', str(self.m)]), 0)

    def test10_report_corrupt_maturity_no_exception(self):
        repo = self._repo()
        bad = Path(self.d) / 'bad.json'
        bad.write_text('{', encoding='utf-8')
        rep = cg.report(repo, bad)
        self.assertEqual(rep['would_refuse'], 2)
        self.assertEqual(cg.main(['--root', str(repo), '--maturity', str(bad)]), 0)

    def test11_write_report_interrupt_keeps_old_file(self):
        out = Path(self.d) / 'r.json'
        out.write_text('{"old": 1}', encoding='utf-8')

        def boom():
            raise RuntimeError('interrupt')
        with self.assertRaises(RuntimeError):
            cg.write_report(out, {'new': 2}, _fault=boom)
        self.assertEqual(json.loads(out.read_text(encoding='utf-8')), {'old': 1})
        cg.write_report(out, {'new': 2})
        self.assertEqual(json.loads(out.read_text(encoding='utf-8')), {'new': 2})
if __name__ == '__main__':
    unittest.main()
