"""S5 batch 3: relation_guard (CAP-RELATION).  SIMULATED_PASS (death = BaseException; the model is always a stub)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
import capability_run as cr  # noqa: E402
import relation_guard as rg  # noqa: E402

ENT = {"E1": ["甲", "jia"], "E2": ["乙"], "E3": ["丙"]}
OBS = [{"obs_id": "o1", "entities": ["甲", "乙"]}, {"obs_id": "o2", "entities": ["乙", "jia"]}, {"obs_id": "o3", "entities": ["丙", "乙"]},
       {"obs_id": "o4", "entities": ["丙", "E2"]}, {"obs_id": "o5", "entities": ["甲", "丙"]}]  # 3 groups: {E1,E2} x2, {E2,E3} x2; o5 alone
D = "A→B"


def ans(a="甲", b="乙", ev=(("o1", "support"),), direction=D, typ="depends"):
    return {"a": a, "b": b, "type": typ, "direction": direction, "condition": None, "depends": None, "evidence": [{"ref": r, "stance": s} for r, s in ev]}


class Died(BaseException):
    pass


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp(prefix="s5r-"))
        self.addCleanup(shutil.rmtree, self.d, True)
        self.calls = []

    def run_(self, fn, obs=OBS, ent=ENT, **kw):
        def m(group, observations, attempt):
            self.calls.append((tuple(group["key"]), attempt))
            return fn(group, observations, attempt)
        return rg.build_relations(obs, ent, m, self.d, **kw)


def by_group(g, o, a):
    return ans("甲", "乙", (("o1", "support"),)) if "E1" in g["key"] else ans("乙", "丙", (("o3", "support"),))


class Guard(Base):
    def test_relation_with_alias_and_evidence(self):
        r = self.run_(by_group)
        recs = {tuple(x["pair"]): x for x in r["records"]}
        self.assertEqual((r["status"], sorted(recs), recs[("E1", "E2")]["status"], recs[("E1", "E2")]["from"], recs[("E2", "E3")]["to"]), ("OK", [("E1", "E2"), ("E2", "E3")], "RELATION", "E1", "E3"))
        self.assertEqual(len(self.calls), 2)  # o5 is a group of one observation -> not processed (E1)

    def test_no_or_unresolvable_evidence_is_candidate_not_in_graph(self):
        for ev in ((), (("ghost", "support"),)):
            shutil.rmtree(self.d)
            r = self.run_(lambda g, o, a, ev=ev: ans(ev=ev))
            self.assertEqual((r["status"], {x["reason"] for x in r["records"]}), ("PARTIAL", {"NO_EVIDENCE"}))
            self.assertEqual(rg.graph_edges(r["records"]), [])

    def test_unregistered_endpoint_asked_once_more_then_candidate(self):
        r = self.run_(lambda g, o, a: ans("鬼", "乙"))
        self.assertEqual({x["reason"] for x in r["records"]}, {"ENDPOINT_NOT_REGISTERED"})
        self.assertEqual((r["missing_entities"], len([c for c in self.calls if c[0] == ("E1", "E2")])), (["鬼"], 2))
        shutil.rmtree(self.d)
        r2 = self.run_(lambda g, o, a: ans("鬼", "乙") if a == 0 else ans())
        self.assertEqual(r2["status"], "OK")

    def test_schema_invalid_retried_twice_then_candidate(self):
        bad = ans()
        bad.pop("direction")
        r = self.run_(lambda g, o, a: bad, obs=OBS[:2])
        self.assertEqual(({x["reason"] for x in r["records"]}, len(self.calls)), ({"INVALID_SCHEMA"}, 3))

    def test_conflict_and_support_both_kept(self):
        r = self.run_(lambda g, o, a: ans(ev=(("o1", "support"), ("o2", "conflict"))), obs=OBS[:2])
        x = r["records"][0]
        self.assertEqual((x["supports"], x["conflicts"], r["conflict_count"]), (["o1"], ["o2"], 1))

    def test_same_pair_and_type_kept_once(self):
        obs = OBS[:2] + [{"obs_id": "o6", "entities": ["甲", "乙", "丙"]}, {"obs_id": "o7", "entities": ["丙", "乙", "甲"]}]
        r = self.run_(lambda g, o, a: ans(), obs=obs)
        self.assertEqual((len(self.calls), len(r["records"])), (2, 1))


class Interrupt(Base):
    def test_death_resume_skips_done(self):
        def die(g, o, a):
            if "E3" in g["key"]:
                raise Died
            return by_group(g, o, a)
        with self.assertRaises(Died):
            self.run_(die)
        self.calls.clear()
        r = self.run_(by_group)
        self.assertEqual(([c[0] for c in self.calls], r["status"]), ([("E2", "E3")], "OK"))
        n = len(list(self.d.glob("*.json")))
        self.run_(by_group)
        self.assertEqual(len(list(self.d.glob("*.json"))), n)

    def test_model_failure_incomplete_keeps_finished(self):
        def boom(g, o, a):
            if "E3" in g["key"]:
                raise RuntimeError("down")
            return by_group(g, o, a)
        r = self.run_(boom)
        self.assertEqual((r["status"], len(r["records"]), r["missing"]), ("INCOMPLETE", 1, [["E2", "E3"]]))

    def test_bad_input_failed_writes_nothing(self):
        self.assertEqual(rg.build_relations("x", ENT, lambda *a: {}, self.d)["status"], "FAILED")
        self.assertEqual(list(self.d.iterdir()), [])


class Downstream(Base):
    def test_graph_check_and_strength(self):
        r = self.run_(by_group)
        self.assertEqual(rg.check_graph(r["records"], ENT)["status"], "OK")
        cyc = [dict(x, **{"from": x["to"], "to": x["from"]}) for x in r["records"]] + r["records"]
        self.assertEqual(rg.check_graph(cyc, ENT)["status"], "PARTIAL")
        self.assertEqual(rg.strength([], "W41")["value"], "UNKNOWN")
        self.assertEqual(rg.strength([2, 4], "W41")["value"], 3.0)


class Measured(unittest.TestCase):
    def test_measured_and_mutation_caught(self):
        self.assertEqual(cr.check("CAP-RELATION"), {"capability": "CAP-RELATION", "ok": True, "runner_ok": True, "providers_missing": []})
        self.assertEqual(cr.check("CAP-RELATION", {"relation": lambda: True})["providers_missing"], ["relation_guard"])
        with mock.patch.object(rg, "_resolvable", lambda refs, ids: list(refs)):  # evidence binding removed
            try:
                caught = not cr.check("CAP-RELATION")["runner_ok"]
            except Exception:
                caught = True
        self.assertTrue(caught)


if __name__ == "__main__":
    unittest.main()
