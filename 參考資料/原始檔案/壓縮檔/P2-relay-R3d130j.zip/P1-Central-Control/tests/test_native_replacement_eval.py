#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from copy import deepcopy
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

from native_replacement_eval import (  # noqa: E402
    apply_command,
    build_command,
    evaluate,
    initial_state,
    load_policy,
    validate_eval,
    validate_eval_command,
    validate_eval_state,
)


class NativeReplacementEvalTests(unittest.TestCase):
    def base_measurement(self) -> dict:
        return {
            "evaluation_id": "EVAL-P11-001",
            "capability_id": "CAP-EXTRACT",
            "baseline_mode": "MODEL_PLUS_GUARD",
            "candidate_mode": "MODEL_ONLY",
            "sample_size": 100,
            "schema_compatibility": {
                "checked": True,
                "passed": True,
            },
            "behavior_compatibility": {
                "passed": 98,
                "total": 100,
                "rate": 0,
            },
            "acceptance": {
                "passed": 100,
                "total": 100,
                "rate": 0,
            },
            "reliability": {
                "successes": 99,
                "total": 100,
                "rate": 0,
            },
            "cost": {
                "baseline_unit_cost": 1.0,
                "candidate_unit_cost": 0.8,
                "ratio": 0,
            },
            "regression_count": 0,
            "evidence_refs": ["EVIDENCE:p11-001"],
        }

    def test_full_compatibility_passes(self):
        record = evaluate(self.base_measurement())
        self.assertEqual(record["status"], "PASS")
        self.assertEqual(record["failed_checks"], [])
        self.assertEqual(record["kind"], "NATIVE_REPLACEMENT_EVAL")
        self.assertTrue(record["object_id"].startswith("NATIVE_REPLACEMENT_EVAL:"))
        self.assertTrue(record["content_hash"].startswith("sha256:"))
        validate_eval(record)

    def test_behavior_regression_blocks(self):
        measurement = self.base_measurement()
        measurement["behavior_compatibility"]["passed"] = 90
        record = evaluate(measurement)
        self.assertEqual(record["status"], "BLOCK")
        self.assertIn(
            "BEHAVIOR_COMPATIBILITY_BELOW_THRESHOLD",
            record["failed_checks"],
        )

    def test_low_sample_is_insufficient_not_failure_of_behavior(self):
        measurement = self.base_measurement()
        measurement["sample_size"] = 5
        record = evaluate(measurement)
        self.assertEqual(record["status"], "INSUFFICIENT_DATA")
        self.assertIn("SAMPLE_SIZE_BELOW_MINIMUM", record["failed_checks"])

    def test_schema_failure_blocks_even_with_high_behavior(self):
        measurement = self.base_measurement()
        measurement["schema_compatibility"]["passed"] = False
        record = evaluate(measurement)
        self.assertEqual(record["status"], "BLOCK")
        self.assertIn("SCHEMA_COMPATIBILITY_FAILED", record["failed_checks"])

    def test_cost_and_regression_are_measured(self):
        measurement = self.base_measurement()
        measurement["cost"]["candidate_unit_cost"] = 3.0
        measurement["regression_count"] = 1
        record = evaluate(measurement)
        self.assertIn("COST_RATIO_ABOVE_THRESHOLD", record["failed_checks"])
        self.assertIn("REGRESSION_DETECTED", record["failed_checks"])

    def test_missing_evidence_blocks(self):
        measurement = self.base_measurement()
        measurement["evidence_refs"] = []
        record = evaluate(measurement)
        self.assertEqual(record["status"], "BLOCK")
        self.assertIn("EVIDENCE_REFS_MISSING", record["failed_checks"])

    def test_policy_thresholds_are_externalized(self):
        policy = load_policy()
        measurement = self.base_measurement()
        policy["min_behavior_rate"] = 0.999
        record = evaluate(measurement, policy=policy)
        self.assertIn(
            "BEHAVIOR_COMPATIBILITY_BELOW_THRESHOLD",
            record["failed_checks"],
        )

    def test_eval_state_and_commands_are_deterministic(self):
        state = initial_state("EVAL-P11-001")
        validate_eval_state(state)
        start = build_command(
            state,
            "START_EVALUATION",
            command_id="CMD-P11-START",
            idempotency_key="IK-P11-START",
            issued_at="2026-10-03T11:00:00Z",
        )
        validate_eval_command(start)
        state, status = apply_command(state, start)
        self.assertEqual(status, "APPLIED")
        self.assertEqual(state["status"], "RUNNING")
        self.assertEqual(state["state_revision"], 1)

        record = evaluate(self.base_measurement())
        finalize = build_command(
            state,
            "FINALIZE_EVALUATION",
            command_id="CMD-P11-FINALIZE",
            idempotency_key="IK-P11-FINALIZE",
            issued_at="2026-10-03T11:00:01Z",
        )
        state, status = apply_command(state, finalize, evaluation=record)
        self.assertEqual(status, "APPLIED")
        self.assertEqual(state["status"], "FINALIZED")
        self.assertEqual(state["state_revision"], 2)

    def test_stale_eval_command_is_rejected(self):
        state = initial_state("EVAL-P11-STATE")
        start = build_command(
            state,
            "START_EVALUATION",
            command_id="CMD-P11-START",
            idempotency_key="IK-P11-START",
        )
        state, _ = apply_command(state, start)
        stale = deepcopy(start)
        stale["command_id"] = "CMD-P11-STALE"
        stale["idempotency_key"] = "IK-P11-STALE"
        stale["expected_state_revision"] = 0
        with self.assertRaises(ValueError):
            apply_command(state, stale)


if __name__ == "__main__":
    unittest.main()
