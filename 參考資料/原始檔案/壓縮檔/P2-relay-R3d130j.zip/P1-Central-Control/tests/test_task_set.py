#!/usr/bin/env python3
"""U-6：TASK_SET_ISSUED 契約、Task Set 生命週期（衍生）、作廢任務不可排程、Brain 逐 segment 裁決。"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import central_controller  # noqa: E402
import task_set  # noqa: E402
import test_repository_result_ingestion as base  # noqa: E402
from brain_input import build_brain_input_packet, validate_packet  # noqa: E402
from event_log import EventLog  # noqa: E402
from event_reducer import initial_segment_projection, recover_workflow, replay_segments, segment_control_view  # noqa: E402
from parallel_scheduler import runnable_segments, start_available  # noqa: E402
from repository_result_ingestion import ingest_role_result  # noqa: E402
from test_brain_input import _proposal  # noqa: E402
from test_role_result_ingestion import _role_result  # noqa: E402

REF = "DIAGNOSIS:d-1"


def _out(set_id="TASKSET:ts1", revision=1, tasks=("SEG-N1",), supersedes=None, code="TASK_SET_ISSUED"):
    out = {"decision_code": code, "diagnosis_ref": REF, "evidence_refs": [], "changed_plan_refs": []}
    if code == "TASK_SET_ISSUED":
        out.update({
            "task_set_ref": set_id, "revision": revision, "correlation_id": "CORR:c1", "supersedes": supersedes,
            "task_refs": [{"task_id": t, "role": "ROLE:EXECUTOR", "capability_id": "CAP-EXTRACT",
                           "input_ref": "INPUT:i1", "output_contract_id": "OC-1"} for t in tasks],
        })
    return out


class ControlOutputContractTests(unittest.TestCase):
    def test_every_code_valid_and_task_set_issued_requires_fields(self) -> None:
        for code in ("NEEDS_INPUT", "NO_ACTION_REQUIRED", "BLOCKED", "UNRESOLVED"):
            task_set.validate_control_output(_out(code=code))
        task_set.validate_control_output(_out())
        for missing in ("task_set_ref", "task_refs", "revision", "correlation_id"):
            bad = _out()
            del bad[missing]
            with self.assertRaises(ValueError, msg=missing):
                task_set.validate_control_output(bad)

    def test_other_codes_must_not_carry_task_set_fields_and_no_or_value(self) -> None:
        bad = _out(code="NEEDS_INPUT")
        bad["task_set_ref"] = "TASKSET:x"
        with self.assertRaises(ValueError):
            task_set.validate_control_output(bad)
        with self.assertRaises(ValueError):
            task_set.validate_control_output(_out(code="next_task_packet_or_next_question"))
        profile = json.loads((ROOT / "P1-Central-Control/canonical/instruction_profiles/control-discussion.json").read_text())
        contract = profile["output_contract"]
        self.assertNotIn("next_task_packet_or_next_question", json.dumps(contract))
        schema = json.loads((ROOT / "P1-Central-Control/schemas/control_output.schema.json").read_text())
        self.assertEqual(contract["decision_codes"], schema["properties"]["decision_code"]["enum"])


class _Fixture(unittest.TestCase):
    def _workflow(self, root: Path):
        """WAITING 的 Workflow（SEG-INGEST 為 NEEDS_BRAIN）＋可發行的新 segment 定義。"""
        helper = base.RepositoryResultIngestionTests()
        state, task, _r, _p, log_path, _e, _pv = helper.prepare(root)
        envelopes = json.loads((root / "execution.json").read_text())
        out = ingest_role_result(
            role_result=_role_result("ROLE:VERIFIER", "FAIL", reason="CHECK_FAILED", verdict_fields=True),
            task_packet=task, current_state=state, execution_envelopes=envelopes, event_log_path=log_path,
        )
        store = {"SEG-INGEST": helper.make_segment()}
        for sid in ("SEG-N1", "SEG-N2", "SEG-N3"):
            seg = copy.deepcopy(store["SEG-INGEST"])
            seg["segment_id"] = sid
            seg["execution_record_ref"] = f"EXECUTION:exec-{sid}"
            store[sid] = seg
        return out["central_state"], store, EventLog(log_path)


class VerifierIndependenceTests(_Fixture):
    def _issue(self, state, store, refs):
        out = _out(tasks=("SEG-N1", "SEG-N2"))
        out["task_refs"] = refs
        return task_set.plan_issue(state, out, store)

    def test_verifier_must_be_separate_dependent_task_never_self(self) -> None:
        def ref(tid, role, verifies=None):
            r = {"task_id": tid, "role": role, "capability_id": "CAP-VERIFY" if role == "ROLE:VERIFIER" else "CAP-EXTRACT", "input_ref": "INPUT:i1", "output_contract_id": "OC-1"}
            if verifies is not None:
                r["verifies"] = verifies
            return r
        with tempfile.TemporaryDirectory() as tmp:
            state, store, _log = self._workflow(Path(tmp))
            ex, ve = "ROLE:EXECUTOR", "ROLE:VERIFIER"
            with self.assertRaisesRegex(ValueError, "TASK_VERIFIER_REQUIRES_VERIFIES"):
                self._issue(state, store, [ref("SEG-N1", ex), ref("SEG-N2", ve)])
            with self.assertRaisesRegex(ValueError, "TASK_VERIFIES_ONLY_FOR_VERIFIER"):
                self._issue(state, store, [ref("SEG-N1", ex, ["SEG-N2"]), ref("SEG-N2", ex)])
            with self.assertRaisesRegex(ValueError, "TASK_SELF_VERIFICATION"):
                self._issue(state, store, [ref("SEG-N1", ex), ref("SEG-N2", ve, ["SEG-N2"])])
            with self.assertRaisesRegex(ValueError, "TASK_VERIFIES_TARGET_INVALID"):
                self._issue(state, store, [ref("SEG-N1", ex), ref("SEG-N2", ve, ["SEG-NX"])])
            with self.assertRaisesRegex(ValueError, "TASK_VERIFIER_MISSING_DEPENDENCY"):  # 驗收 segment 未依賴被驗收者
                self._issue(state, store, [ref("SEG-N1", ex), ref("SEG-N2", ve, ["SEG-N1"])])
            store["SEG-N2"]["dependency_refs"] = ["SEG-N1"]
            plan = self._issue(state, store, [ref("SEG-N1", ex), ref("SEG-N2", ve, ["SEG-N1"])])
            self.assertEqual(plan["record"]["task_refs"][1]["verifies"], ["SEG-N1"])


class RoleCapabilityBindingTests(_Fixture):
    """U-8：capability 只能指派給綁定它的 role（fail closed），綁定與 role contract／registry 一致。"""

    BINDING = json.loads((ROOT / "P1-Central-Control/policy/role_capability_binding.v1.0.json").read_text(encoding="utf-8"))["roles"]

    def test_binding_matches_registries_and_role_contracts(self) -> None:
        caps = {c["capability_id"] for c in json.loads((ROOT / "P1-Central-Control/capability_registry.json").read_text())["capabilities"]
                if c["retirement_state"] == "ACTIVE"}
        roles = {r["role_id"]: r for r in json.loads((ROOT / "P1-Central-Control/canonical/role_contract_registry.json").read_text())["roles"]}
        self.assertEqual(set(self.BINDING), set(roles))
        for role, bound in self.BINDING.items():
            self.assertTrue(bound and set(bound) <= caps, role)
            denied = set(roles[role]["denied_operations"])
            if "EXTERNAL_RESEARCH" in denied:
                self.assertFalse(set(bound) & {"CAP-SEARCH", "CAP-COUNTEREXAMPLE"}, role)
            self.assertEqual("CAP-VERIFY" in bound, "VERIFY_TASK" not in denied, role)

    def test_unbound_capability_is_rejected_and_bound_passes(self) -> None:
        cases = [("ROLE:EXECUTOR", "CAP-VERIFY"), ("ROLE:EXECUTOR", "CAP-SEARCH"), ("ROLE:VERIFIER", "CAP-EXTRACT"),
                 ("ROLE:CONTROL_RESEARCH", "CAP-VERIFY"), ("ROLE:EXECUTOR", "CAP-UNKNOWN")]
        with tempfile.TemporaryDirectory() as tmp:
            state, store, _log = self._workflow(Path(tmp))
            for role, cap in cases:
                out = _out()
                out["task_refs"][0].update(role=role, capability_id=cap)
                with self.assertRaisesRegex(ValueError, "TASK_CAPABILITY_NOT_BOUND", msg=f"{role} {cap}"):
                    task_set.plan_issue(state, out, store)
            out = _out()
            out["task_refs"][0].update(role="ROLE:CONTROL_RESEARCH", capability_id="CAP-SEARCH")
            task_set.plan_issue(state, out, store)


class TaskSetLifecycleTests(_Fixture):
    def test_issue_supersede_voids_old_tasks_and_blocks_scheduling(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            state = central_controller.issue_task_set(state, _out(tasks=("SEG-N1", "SEG-N2")), segment_store=store, event_log=log)
            self.assertEqual([r["status"] for r in task_set.task_set_view(state)], ["ACTIVE"])
            with self.assertRaisesRegex(ValueError, "TASK_SET_SUPERSEDES_REQUIRED"):
                task_set.plan_issue(state, _out("TASKSET:ts2", 2, ("SEG-N3",)), store)
            with self.assertRaisesRegex(ValueError, "TASK_SET_REVISION_CONFLICT"):
                task_set.plan_issue(state, _out("TASKSET:ts2", 3, ("SEG-N3",), supersedes="TASKSET:ts1"), store)
            with self.assertRaisesRegex(ValueError, "TASK_SET_ALREADY_ISSUED"):
                task_set.plan_issue(state, _out(), store)
            state = central_controller.issue_task_set(
                state, _out("TASKSET:ts2", 2, ("SEG-N3",), supersedes="TASKSET:ts1"), segment_store=store, event_log=log)
            view = {r["task_set_id"]: r for r in task_set.task_set_view(state)}
            self.assertEqual((view["TASKSET:ts1"]["status"], view["TASKSET:ts2"]["status"]), ("SUPERSEDED", "ACTIVE"))
            self.assertEqual({t["state"] for t in view["TASKSET:ts1"]["tasks"]}, {"SUPERSEDED"})
            self.assertEqual([s["segment_id"] for s in runnable_segments(state)], ["SEG-N3"])
            self.assertEqual(task_set.stale_task_ids(state), ["SEG-N1", "SEG-N2"])
            with self.assertRaisesRegex(ValueError, "TASK_SEGMENT_ID_REUSED"):  # 作廢任務不可再被排入
                task_set.plan_issue(state, _out("TASKSET:ts3", 3, ("SEG-N1",), supersedes="TASKSET:ts2"), store)
            started, packets = start_available(state, max_concurrency=4)
            self.assertEqual([p["segment_id"] for p in packets], ["SEG-N3"])

    def test_state_rebuilds_from_event_log_and_packet_shows_task_set(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            state = central_controller.issue_task_set(state, _out(tasks=("SEG-N1",)), segment_store=store, event_log=log)
            state = central_controller.issue_task_set(
                state, _out("TASKSET:ts2", 2, ("SEG-N2",), supersedes="TASKSET:ts1"), segment_store=store, event_log=log)
            replayed = replay_segments(initial_segment_projection(), log.read_all("SEGMENT"))
            self.assertEqual(replayed["task_sets"], state["task_sets"])
            self.assertEqual(replayed["void_segments"], state["void_segments"])
            self.assertEqual(segment_control_view(replayed), segment_control_view(state))
            packet = build_brain_input_packet(state)
            validate_packet(packet)
            self.assertEqual(packet["task_set"]["task_set_id"], "TASKSET:ts2")
            self.assertEqual(packet["stale_task_ids"], ["SEG-N1"])

    def test_non_task_set_outputs_do_not_change_state(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            for code in ("NEEDS_INPUT", "NO_ACTION_REQUIRED", "BLOCKED", "UNRESOLVED"):
                new, result = central_controller.apply_control_output(state, _out(code=code), segment_store=store, event_log=log)
                self.assertEqual((new, result["status"]), (state, code))

    def test_role_interface_vocabulary_for_control(self) -> None:
        from central_role_interface import ALLOWED_RESULT_STATUS
        self.assertEqual(ALLOWED_RESULT_STATUS["ROLE:CONTROL_RESEARCH"] - {None},
                         {"TASK_SET_ISSUED", "NEEDS_INPUT", "NO_ACTION_REQUIRED", "BLOCKED", "UNRESOLVED"})


class SegmentRulingTests(_Fixture):
    def _resume(self, state, rulings, tag="resume"):
        p = _proposal(state, "RESUME", "EXECUTE", "DISPATCH", tag)
        if rulings is not None:
            p["segment_rulings"] = rulings
        return p

    def test_incomplete_or_foreign_rulings_rejected_state_unchanged(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            for rulings, code in (([], "PROPOSAL_RULINGS_INCOMPLETE"),
                                  ([{"segment_id": "SEG-X", "ruling": "ABANDON"}], "PROPOSAL_RULING_SEGMENT_NOT_PENDING")):
                with self.assertRaisesRegex(ValueError, code):
                    central_controller.commit_brain_proposal(state, self._resume(state, rulings), event_log=log, segment_store=store)
            bad = _proposal(state, "BLOCK", "BLOCK", "BLOCK", "b")
            bad["segment_rulings"] = [{"segment_id": "SEG-INGEST", "ruling": "ABANDON"}]
            with self.assertRaisesRegex(ValueError, "PROPOSAL_RULINGS_ONLY_WITH_RESUME"):
                central_controller.commit_brain_proposal(state, bad, event_log=log)

    def test_accept_completes_workflow_through_result_routing(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            new, result = central_controller.commit_brain_proposal(
                state, self._resume(state, [{"segment_id": "SEG-INGEST", "ruling": "ACCEPT"}]), event_log=log, segment_store=store)
            self.assertEqual((new["status"], new.get("terminal_state"), result["next"]), ("COMPLETED", "WORKFLOW_COMPLETE", "WORKFLOW_TERMINAL"))
            self.assertEqual(new["completed_segments"][-1]["ruling_ref"], "BRAIN_PROPOSAL:resume")
            self.assertEqual(recover_workflow(new, log)["segment_status"], "MATCH")

    def test_abandon_with_nothing_else_blocks_workflow(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            new, _ = central_controller.commit_brain_proposal(
                state, self._resume(state, [{"segment_id": "SEG-INGEST", "ruling": "ABANDON"}]), event_log=log, segment_store=store)
            self.assertEqual((new["status"], new.get("terminal_state")), ("BLOCKED", "BLOCK"))
            self.assertEqual(new["void_segments"][0]["reason_code"], "ABANDONED")
            self.assertNotIn("SEG-INGEST", [r["segment_id"] for r in build_brain_input_packet(new)["segments"]])

    def test_per_segment_rulings_mix_requeue_and_accept(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            state, store, log = self._workflow(Path(tmp))
            # 第二個 NEEDS_BRAIN segment：把 SEG-N1 直接放成 NEEDS_BRAIN 終局結果
            before = state
            state = copy.deepcopy(state)
            state["completed_segments"].append({"segment_id": "SEG-N1", "attempt_id": "ATT-N1", "result_id": "RES-N1",
                                                "skill_id": "S", "status": "UNRESOLVED", "decision_code": "NEEDS_BRAIN"})
            state["attempt_counters"]["SEG-N1"] = 1
            central_controller._log_segments(log, before, state, "SEGMENT_RESULT_ACCEPTED", "TEST:seed")
            rulings = [{"segment_id": "SEG-INGEST", "ruling": "REQUEUE"}, {"segment_id": "SEG-N1", "ruling": "ACCEPT"}]
            log_state_before = copy.deepcopy(state)
            new, result = central_controller.commit_brain_proposal(
                state, self._resume(state, rulings), event_log=log, segment_store=store)
            self.assertEqual(result["next"], "DISPATCH_READY")
            self.assertEqual([q["segment_id"] for q in new["queued_segments"]], ["SEG-INGEST"])
            self.assertEqual(new["completed_segments"][-1]["decision_code"], "WORK_COMPLETE")
            self.assertEqual(log_state_before["queued_segments"], [])


if __name__ == "__main__":
    unittest.main()
