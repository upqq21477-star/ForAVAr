#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import central_controller  # noqa: E402
import current_truth_reconciliation as ctr  # noqa: E402
import local_acceptance  # noqa: E402
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _pending_repo import pending_root  # noqa: E402
from _brain_fixture import brain_start_proposal  # noqa: E402
import minimal_closed_loop_runner as runner  # noqa: E402
from actions_execution_recovery import build as build_recovery  # noqa: E402
from command_layer import (  # noqa: E402
    build_command,
    execute_command,
    initialize_command_state,
)
from event_log import EventLog  # noqa: E402
from event_reducer import recover_workflow  # noqa: E402
from packet_layer import build_result_packet  # noqa: E402
from parallel_scheduler import accept_result, start_available, timeout_due  # noqa: E402
from system_result_adapter import adapt as adapt_system_result  # noqa: E402


class M32CloseVerticalSliceTests(unittest.TestCase):
    def make_segment(
        self,
        segment_id: str,
        *,
        max_attempts: int = 1,
        retry_on: list[str] | None = None,
        timeout_ms: int = 1000,
    ) -> dict:
        return {
            "segment_id": segment_id,
            "workflow_id": "WF-M32-CLOSE",
            "system_id": "SYSTEM-M32-CLOSE",
            "skill_id": "demo-skill",
            "skill_version": "1.0.0",
            "objective": f"完成 {segment_id}",
            "input_scope": "m32-close",
            "input_refs": ["ARTIFACT:m32-input"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": f"EXECUTION:{segment_id}",
            "context_cohort_id": "COHORT-M32-CLOSE",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {
                "max_attempts": max_attempts,
                "retry_on": retry_on or [],
            },
            "timeout_ms": timeout_ms,
        }

    def result_packet(self, task_packet: dict, decision_code: str) -> dict:
        if decision_code == "WORK_COMPLETE":
            raise ValueError("WORK_COMPLETE must use adapt_system_result() so tests exercise the canonical result boundary")
        return build_result_packet(
            task_packet,
            {
                "decision_code": decision_code,
                "output_refs": [],
                "evidence_refs": [],
                "provenance_refs": [],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 1,
                },
                "usage_observed": True,
            },
        )

    def complete_result_and_records(
        self,
        task_packet: dict,
        execution_record: dict,
    ) -> tuple[dict, list[dict], list[dict]]:
        system_result = {
            "segment_id": task_packet["segment_id"],
            "system_id": "SYSTEM-M32-CLOSE",
            "status": "WORK_COMPLETE",
            "outputs": {"result": {"status": "complete"}},
            "evidence_refs": [],
            "provenance_refs": [],
            "gaps": [],
            "unresolved": [],
            "trace": [{"step": "m32-close"}],
            "completion": {
                "segment_complete": True,
                "handoff_ready": True,
                "summary": "M32-CLOSE vertical slice complete",
            },
            "observed_usage": {
                "model_calls": 1,
                "tool_calls": 1,
                "wall_time_ms": 1,
                "usage_observed": True,
            },
        }
        result, evidence_payload, provenance_payload = adapt_system_result(
            task_packet,
            system_result,
            execution_record,
        )
        return (
            result,
            evidence_payload["records"],
            provenance_payload["records"],
        )

    def test_m32_close_vertical_slice(self) -> None:
        # 1. normal completion + CURRENT -> proposal -> command -> task -> result -> event -> terminal
        control_state = central_controller.init_state("WF-M32-CLOSE", "TASK-M32-CLOSE")
        proposal = brain_start_proposal(control_state)
        control_state = central_controller.queue_segment(
            control_state,
            self.make_segment("SEG-NORMAL"),
        )

        execution_store: dict = {}
        distillation_store: dict = {}
        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            control_state, command_result = central_controller.commit_brain_proposal(
                control_state,
                proposal,
                event_log=log,
            )
            self.assertEqual(command_result["status"], "APPLIED")

            control_state, packets = central_controller.dispatch(
                control_state,
                event_log=log,
                execution_store=execution_store,
                max_concurrency=1,
            )
            envelope = execution_store[packets[0]["execution_record_ref"]]
            result, evidence, provenance = self.complete_result_and_records(
                envelope["task_packet"],
                envelope["execution_record"],
            )
            control_state = central_controller.receive_result(
                control_state,
                result,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                segment_store={"SEG-NORMAL": self.make_segment("SEG-NORMAL")},
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(control_state["status"], "COMPLETED")

            # 4. duplicate result / late result
            control_state = central_controller.receive_result(
                control_state,
                result,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                segment_store={"SEG-NORMAL": self.make_segment("SEG-NORMAL")},
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(control_state["late_result_count"], 1)

            # 7 + 8. crash/restart + partial/truncated Event Log
            recovered = recover_workflow(
                control_state,
                log,
                candidate_command={
                    "command_id": proposal["object_id"],
                    "idempotency_key": proposal["idempotency_key"],
                },
            )
            self.assertEqual(recovered["status"], "RECOVERED")

            with log.path.open("a", encoding="utf-8") as handle:
                handle.write('{"event_type":"STATE_TRANSITION_APPLIED"')
            unknown = recover_workflow(
                control_state,
                log,
                candidate_command={
                    "command_id": "CMD:unknown-after-crash",
                    "idempotency_key": "IK:unknown-after-crash",
                },
            )
            self.assertEqual(unknown["execution_status"], "UNKNOWN")
            self.assertEqual(unknown["next_action"], "RECONCILIATION_REQUIRED")

        # 2. worker failure with scheduler retry
        segment = self.make_segment(
            "SEG-FAIL",
            max_attempts=2,
            retry_on=["FAIL"],
        )
        scheduler_state = {
            "workflow_id": "WF-M32-CLOSE",
            "status": "READY",
            "state_revision": 0,
            "queued_segments": [segment],
            "active_segments": [],
            "attempt_counters": {},
            "scheduler_max_concurrency": 1,
            "completed_segments": [],
            "retry_count": 0,
            "timeout_count": 0,
            "late_result_count": 0,
            "cancel_count": 0,
            "result_refs": [],
            "evidence_refs": [],
            "provenance_refs": [],
            "unresolved": [],
        }
        scheduler_state, packets = start_available(
            scheduler_state,
            max_concurrency=1,
            now="2026-10-05T10:00:00+00:00",
        )
        failed = self.result_packet(packets[0], "FAIL")
        scheduler_state, outcome = accept_result(
            scheduler_state,
            failed,
            segment_store={segment["segment_id"]: segment},
        )
        self.assertEqual(outcome, "RETRY_PENDING")
        self.assertEqual(scheduler_state["retry_count"], 1)

        # 3. timeout remains TIMEOUT semantics
        timeout_segment = self.make_segment(
            "SEG-TIMEOUT",
            max_attempts=1,
            retry_on=["TIMEOUT"],
            timeout_ms=1,
        )
        scheduler_state = {
            "workflow_id": "WF-M32-CLOSE",
            "status": "READY",
            "state_revision": 0,
            "queued_segments": [timeout_segment],
            "active_segments": [],
            "attempt_counters": {},
            "scheduler_max_concurrency": 1,
            "completed_segments": [],
            "retry_count": 0,
            "timeout_count": 0,
            "late_result_count": 0,
            "cancel_count": 0,
            "result_refs": [],
            "evidence_refs": [],
            "provenance_refs": [],
            "unresolved": [],
        }
        scheduler_state, _ = start_available(
            scheduler_state,
            max_concurrency=1,
            now="2026-10-05T10:00:00+00:00",
        )
        scheduler_state, timed_out = timeout_due(
            scheduler_state,
            now="2026-10-05T10:00:00.002000+00:00",
        )
        self.assertEqual(len(timed_out), 1)
        self.assertEqual(scheduler_state["completed_segments"][0]["status"], "TIMEOUT")

        # 5. stale revision is rejected before state mutation
        command_state = initialize_command_state("WF-M32-CLOSE-CMD")
        stale = build_command(command_state, "START")
        stale["expected_state_revision"] = 99
        with tempfile.TemporaryDirectory() as temp:
            updated, stale_result = execute_command(
                command_state,
                stale,
                event_log=EventLog(Path(temp) / "events.jsonl"),
            )
        self.assertEqual(stale_result["status"], "REJECTED")
        self.assertEqual(updated, command_state)

        # 6. command idempotency replay does not append a second event
        command_state = initialize_command_state("WF-M32-CLOSE-REPLAY")
        with tempfile.TemporaryDirectory() as temp:
            replay_log = EventLog(Path(temp) / "events.jsonl")
            command = build_command(
                command_state,
                "START",
                idempotency_key="IK:M32:CLOSE",
            )
            first_state, first = execute_command(
                command_state,
                command,
                event_log=replay_log,
            )
            retry = dict(command)
            retry["command_id"] = "CMD:M32:CLOSE:RETRY"
            retry["issued_at"] = "2026-10-05T10:00:01+00:00"
            second_state, second = execute_command(
                first_state,
                retry,
                event_log=replay_log,
            )
            self.assertEqual(first["status"], "APPLIED")
            self.assertEqual(second["status"], "IDEMPOTENT_REPLAY")
            self.assertEqual(first_state, second_state)
            self.assertEqual(len(replay_log.read_all("WORKFLOW")), 1)

        # 9. external runner startup failure stays diagnostic/incomplete
        recovery = build_recovery({
            "diagnostic_id": "ACTIONS_DIAGNOSTIC:999",
            "classification": "RUNNER_STARTUP_FAILURE",
        })
        self.assertEqual(recovery["decision"], "DIAGNOSE")
        self.assertFalse(recovery["retryable"])

        # 10. old runtime observation cannot replace current truth
        current = {
            "current_stage": {
                "id": "M32-CLOSE",
                "status": "IN_PROGRESS",
                "merged_commit_sha": "abc1234",
            },
            "implementation_control": {"active_work_packet": "M32-CLOSE.work.json"},
            "latest_runtime_observation": {
                "observed_at": "2026-10-05T10:00:00Z",
                "run_id": 200,
                "run_attempt": 1,
                "job_id": 300,
                "head_sha": "abc1234",
                "evidence": {
                    "step_execution_observed": True,
                    "step_count": 3,
                    "logs_available": True,
                },
            },
        }
        truth_record = {"status": "INCOMPLETE", "head_sha": "abc1234"}
        old_runtime = {
            "observed_at": "2026-10-05T09:59:00Z",
            "run": {"id": 199, "run_attempt": 1, "head_sha": "abc1234"},
            "job_id": 299,
            "classification": "RUNNER_STARTUP_FAILURE",
        }
        reconciliation = ctr.reconcile(
            current=current,
            work_packet={"work_id": "M32-CLOSE"},
            truth_record=truth_record,
            runtime_fixture=old_runtime,
        )
        self.assertEqual(reconciliation["status"], ctr.BLOCK)
        self.assertIn(
            "STALE_OR_CONFLICTING_RUNTIME_OBSERVATION",
            reconciliation["blocking_conflicts"],
        )

        # 11. command trust boundary blocks arbitrary argv and unknown action types
        with self.assertRaises(ValueError):
            runner.admit_executable_action({"argv": ["sh", "-c", "echo unsafe"]})
        with self.assertRaises(ValueError):
            runner.admit_executable_action(
                {"command_type": "RUN_SHELL", "args": {}}
            )

        # 12. acceptance/runtime boundary remains simulation-only
        with patch.object(local_acceptance, "ROOT", pending_root()):
            report = local_acceptance.simulated_report("m32-close-head", "m32-close-base")
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["mode"], "SIMULATION_ONLY")
        self.assertTrue(report["simulated"])
        self.assertEqual(
            [stage["stage_id"] for stage in report["stages"][:6]],
            [
                "M32_C01_A",
                "M32_C01_B",
                "M32_C01_C",
                "M32_C01_D",
                "M32_C01_E",
                "M32_C01_F",
            ],
        )

        self.assertEqual(
            len(report["stages"]),
            9,
        )
        self.assertEqual(report["stages"][6]["stage_id"], "M32_CLOSE_VERTICAL_SLICE")
        self.assertEqual(report["stages"][7]["stage_id"], "SIMULATION_BOUNDARY")
        self.assertEqual(report["stages"][8]["stage_id"], "RUNTIME_TRUTH_BOUNDARY")


if __name__ == "__main__":
    unittest.main(verbosity=2)
