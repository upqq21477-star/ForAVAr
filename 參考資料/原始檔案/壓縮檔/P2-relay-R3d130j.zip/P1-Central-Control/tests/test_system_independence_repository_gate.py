#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPT_DIR))

import repository_architecture_evidence
import system_independence_gate
import system_independence_repository_gate


class SystemIndependenceRepositoryGateTests(unittest.TestCase):
    def _registry(self):
        return {
            "version": "1.0",
            "systems": [
                {
                    "system_id": "A1-S01",
                    "allowed_inbound": "CENTRAL_TO_SYSTEM",
                    "allowed_outbound": "SYSTEM_TO_CENTRAL",
                    "direct_system_handoff": False,
                    "runtime_dependencies": [],
                    "state_owner": "SYSTEM_LOCAL_ONLY",
                },
                {
                    "system_id": "A1-S02",
                    "allowed_inbound": "CENTRAL_TO_SYSTEM",
                    "allowed_outbound": "SYSTEM_TO_CENTRAL",
                    "direct_system_handoff": False,
                    "runtime_dependencies": [],
                    "state_owner": "SYSTEM_LOCAL_ONLY",
                },
            ],
            "global_rules": {
                "central_state_owner": True,
                "system_to_system_handoff": False,
                "partial_handoff": False,
                "handoff_unit": "WORK_SEGMENT",
            },
        }

    def test_cross_system_import_is_violation(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "A1-S01").mkdir()
            (root / "A1-S02").mkdir()
            (root / "A1-S02/service.py").write_text("def run():\n    return 1\n", encoding="utf-8")
            (root / "A1-S01/runner.py").write_text(
                'import importlib\n\ndef main():\n    return importlib.import_module("A1_S02.service").run()\n',
                encoding="utf-8",
            )
            evidence = repository_architecture_evidence.collect(root, ["A1-S01", "A1-S02"])
            result = system_independence_repository_gate.evaluate(self._registry(), evidence)
            self.assertEqual(result["status"], "VIOLATION")
            self.assertIn("DIRECT_CROSS_SYSTEM_IMPORT", result["reason_codes"])

    def test_clean_repository_is_independent(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "A1-S01").mkdir()
            (root / "A1-S02").mkdir()
            (root / "A1-S01/runner.py").write_text("def main():\n    return 1\n", encoding="utf-8")
            (root / "A1-S02/service.py").write_text("def run():\n    return 2\n", encoding="utf-8")
            evidence = repository_architecture_evidence.collect(root, ["A1-S01", "A1-S02"])
            result = system_independence_repository_gate.evaluate(self._registry(), evidence)
            self.assertEqual(result["status"], "INDEPENDENT")

    def test_empty_system_registry_is_not_independent(self) -> None:
        registry = self._registry()
        registry["systems"] = []
        contract = system_independence_gate.evaluate(registry)
        self.assertEqual(contract["status"], "BLOCK")
        self.assertIn("SYSTEM_REGISTRY_EMPTY", " ".join(contract["errors"]))

        with tempfile.TemporaryDirectory() as tmp:
            evidence = repository_architecture_evidence.collect(Path(tmp), [])
            result = system_independence_repository_gate.evaluate(registry, evidence)
            self.assertNotEqual(result["status"], "INDEPENDENT")
            self.assertIn("REGISTRY_CONTRACT_VIOLATION", result["reason_codes"])

    def test_unresolved_boundary_is_unknown_not_pass(self) -> None:
        registry = self._registry()
        evidence = {
            "schema_version": "1.0",
            "root": "/tmp/x",
            "dependency": {"inventory": [], "edges": [], "unresolved": ["A1-S01/x.py -> .dynamic"]},
            "boundary": {
                "direct_cross_system_imports": [],
                "direct_file_writes": [],
                "foreign_current_mutations": [],
                "handoff_calls": [],
                "dynamic_boundary_unknown": [],
            },
        }
        result = system_independence_repository_gate.evaluate(registry, evidence)
        self.assertEqual(result["status"], "UNKNOWN")


if __name__ == "__main__":
    unittest.main()
