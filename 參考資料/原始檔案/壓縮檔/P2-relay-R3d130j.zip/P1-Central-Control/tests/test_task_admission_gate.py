#!/usr/bin/env python3
from __future__ import annotations

import copy
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import task_admission_gate as gate


def canonical_hash(value):
    material = copy.deepcopy(value)
    material.pop("content_hash", None)
    return "sha256:" + hashlib.sha256(
        json.dumps(material, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


class TaskAdmissionGateTests(unittest.TestCase):
    def _task_packet(self):
        task = {
            "packet_id":"pkt-1",
            "workflow_id":"WF:1",
            "segment_id":"SEG:1",
            "attempt_id":"att-1",
            "skill_id":"skill-1",
            "skill_version":"1.0.0",
            "objective":"test",
            "input_refs":["AUTHORITY:P1-CURRENT"],
            "requested_outputs":["result"],
            "constraints":["CENTRAL_ONLY"],
            "stop_condition":["done"],
            "failure_condition":["blocked"],
            "scope":{"input_scope":"test","handoff_allowed":True},
            "acceptance_ref":"CONSTRUCTION:TEST",
            "context_budget":{"target":100,"hard_ceiling":200,"estimated":80},
            "execution_record_ref":"EXECUTION:1",
            "retry_policy":{"max_attempts":1,"retry_on":[]},
            "timeout_ms":1000,
            "dependency_refs":[],
            "object_id":"TASK_PACKET:pkt-1",
            "kind":"TASK_PACKET",
            "schema_version":"1.0",
        }
        task["content_hash"] = canonical_hash(task)
        return task

    def _bundle(self, root: Path, *, bad_interface=False, out_of_scope=False):
        (root/"P1-Central-Control/progress/construction").mkdir(parents=True)
        (root/"P1-Central-Control/tasks").mkdir(parents=True)
        work = {
            "work_id":"M-TEST",
            "central_admission_ref":"ADMISSION:TEST",
            "construction_packet_ref":"P1-Central-Control/progress/construction/M-TEST.construction.json",
            "task_packet_ref":"TASK_PACKET:pkt-1",
        }
        construction = {
            "packet_id":"CONSTRUCTION:TEST",
            "status":"READY",
            "task_packet_ref":"TASK_PACKET:pkt-1",
            "write_scope":{
                "create":["P1-Central-Control/tasks/"],
                "update":[],
                "forbidden":[]
            }
        }
        task = self._task_packet()
        (root/"P1-Central-Control/progress/M-TEST.work.json").write_text(json.dumps(work),encoding="utf-8")
        (root/"P1-Central-Control/progress/construction/M-TEST.construction.json").write_text(json.dumps(construction),encoding="utf-8")
        (root/"P1-Central-Control/tasks/pkt.json").write_text(json.dumps(task),encoding="utf-8")
        (root/"P1-CURRENT.json").write_text(json.dumps({
            "implementation_control":{"active_work_packet":"P1-Central-Control/progress/M-TEST.work.json"},
            "current_stage":{"id":"M-TEST","status":"READY"}
        }),encoding="utf-8")
        request = {
            "request_id":"ADMISSION:TEST",
            "central_authority_ref":"P1-CURRENT.json",
            "active_work_packet":"P1-Central-Control/progress/M-TEST.work.json",
            "construction_packet":"P1-Central-Control/progress/construction/M-TEST.construction.json",
            "task_packet_ref":"TASK_PACKET:pkt-1",
            "task_packet_path":"P1-Central-Control/tasks/pkt.json",
            "target_type":"FUNCTION",
            "target_id":"TEST-FUNCTION",
            "interface_contract":{
                "inbound":"CENTRAL_TO_MODULE",
                "outbound":"MODULE_TO_CENTRAL",
                "system_to_system_handoff":False,
                "foreign_current_mutation":False,
                "direct_cross_system_import":False,
            },
        }
        if bad_interface:
            request["interface_contract"]["system_to_system_handoff"] = True
        if out_of_scope:
            (root/"outside.txt").write_text("x",encoding="utf-8")
        return request

    def test_valid_admission_passes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            request = self._bundle(root)
            result = gate.execute(request, root=root)
        self.assertEqual(result["status"],"PASS")
        self.assertTrue(result["admitted"])


    def test_continuation_box_is_consumed_at_admission(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            request = self._bundle(root)
            task_path = root / "P1-Central-Control/tasks/pkt.json"
            task = json.loads(task_path.read_text(encoding="utf-8"))
            task["continuation_box_ref"] = "CONTINUATION_BOX:WF:1:SEG:1:att-1"
            task["content_hash"] = canonical_hash(task)
            task_path.write_text(json.dumps(task), encoding="utf-8")

            from continuation_context_box import build
            current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
            box = build(
                current=current,
                task_packet=task,
                execution_record_ref=task["execution_record_ref"],
            )
            checkpoints = root / "P1-Central-Control/checkpoints"
            checkpoints.mkdir(parents=True)
            (checkpoints / "box.json").write_text(
                json.dumps(box),
                encoding="utf-8",
            )
            # 程式只查索引、不掃描目錄（continuation_context_box.register_checkpoint）；
            # 夾具須登記，否則 CONTINUATION_BOX_INDEX_NOT_FOUND。期望維持原樣。
            from continuation_context_box import register_checkpoint
            register_checkpoint(root, checkpoints / "box.json", box)

            result = gate.execute(request, root=root)

        self.assertEqual(result["status"], "PASS")
        self.assertEqual(
            result["continuation_box_ref"],
            "CONTINUATION_BOX:WF:1:SEG:1:att-1",
        )
        self.assertEqual(
            result["amnesia_context"]["mode"],
            "AMNESIA_RECONSTRUCTED_WITH_BOX",
        )
        self.assertEqual(result["amnesia_context"]["history_loaded"], 0)

    def test_interface_violation_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            request = self._bundle(root, bad_interface=True)
            with self.assertRaises(Exception):
                gate.validate_request(request)


    def test_system_update_without_box_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            request = self._bundle(root)
            current_path = root / "P1-CURRENT.json"
            current = json.loads(current_path.read_text(encoding="utf-8"))
            current["current_stage"]["merged_commit_sha"] = "BASE"
            current_path.write_text(json.dumps(current), encoding="utf-8")
            result = gate.execute(request, root=root, head="HEAD")

        self.assertEqual(result["status"], "BLOCK")
        self.assertIn(
            "CONTINUATION_BOX_REQUIRED_AFTER_SYSTEM_UPDATE",
            result["reason_codes"],
        )

    def test_work_ref_mismatch_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            request = self._bundle(root)
            request["request_id"] = "ADMISSION:OTHER"
            result = gate.execute(request, root=root)
        self.assertEqual(result["status"],"BLOCK")
        self.assertIn("CENTRAL_ADMISSION_REF_MISMATCH", result["reason_codes"])


if __name__ == "__main__":
    unittest.main()
