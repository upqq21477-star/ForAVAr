#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

from external_skill_adapter import invoke_skill, validate_invocation, validate_manifest  # noqa: E402
from packet_layer import content_hash  # noqa: E402


class ExternalSkillAdapterTests(unittest.TestCase):
    def make_task(self) -> dict:
        task = {
            "object_id": "TASK_PACKET:p10-001",
            "kind": "TASK_PACKET",
            "schema_version": "1.0",
            "content_hash": "",
            "packet_id": "p10-001",
            "workflow_id": "WF-P10",
            "segment_id": "SEG-P10",
            "attempt_id": "att-SEG-P10-1",
            "skill_id": "demo-skill",
            "skill_version": "1.0.0",
            "objective": "P10 adapter test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "scope": {
                "input_scope": "public",
                "handoff_allowed": True,
            },
            "acceptance_ref": "SEGMENT:SEG-P10",
            "context_budget": {
                "target": 100,
                "hard_ceiling": 200,
                "estimated": 50,
            },
            "execution_record_ref": "EXECUTION:exec-att-SEG-P10-1",
            "retry_policy": {
                "max_attempts": 1,
                "retry_on": [],
            },
            "timeout_ms": 1000,
            "dependency_refs": [],
        }
        task["content_hash"] = content_hash(task)
        return task

    def make_manifest(self) -> dict:
        return {
            "object_id": "SKILL_MANIFEST:demo-skill-1.0.0",
            "kind": "SKILL_MANIFEST",
            "schema_version": "1.0",
            "content_hash": "sha256:" + "b" * 64,
            "skill_id": "demo-skill",
            "skill_version": "1.0.0",
            "capabilities": ["CAPABILITY:CAP-SEARCH"],
            "input_scope": ["public"],
            "output_contract": {
                "result_packet_only": True,
                "requested_outputs_required": True,
            },
            "execution_policy": {
                "timeout_allowed": True,
                "evidence_required": True,
                "provenance_required": True,
            },
        }

    def make_success(self, task: dict) -> dict:
        return {
            "decision_code": "WORK_COMPLETE",
            "output_refs": ["ARTIFACT:result-001"],
            "evidence_refs": ["EVIDENCE:p10-001"],
            "provenance_refs": ["PROVENANCE:p10-001"],
            "observed_usage": {
                "model_calls": 1,
                "tool_calls": 1,
                "wall_time_ms": 10,
            },
            "usage_observed": True,
        }

    def test_manifest_and_invocation_are_strict(self):
        validate_manifest(self.make_manifest())
        validate_invocation({
            "invocation_id": "INV:p10-001",
            "skill_id": "demo-skill",
            "skill_version": "1.0.0",
            "task_packet_ref": "TASK_PACKET:p10-001",
            "execution_record_ref": "EXECUTION:exec-att-SEG-P10-1",
            "status": "DISPATCHED",
            "error_code": None,
        })

    def test_adapter_returns_canonical_result_packet(self):
        task = self.make_task()
        manifest = self.make_manifest()
        seen = {}

        def executor(packet):
            seen["task_packet_ref"] = packet["object_id"]
            return self.make_success(packet)

        result, invocation = invoke_skill(
            task,
            manifest,
            executor,
            invocation_id="INV:p10-001",
        )

        self.assertEqual(result["kind"], "RESULT_PACKET")
        self.assertEqual(result["execution_record_ref"], task["execution_record_ref"])
        self.assertEqual(invocation["status"], "RETURNED")
        self.assertEqual(seen["task_packet_ref"], task["object_id"])

    def test_scope_mismatch_is_rejected(self):
        task = self.make_task()
        task["scope"]["input_scope"] = "private"
        with self.assertRaises(ValueError):
            invoke_skill(task, self.make_manifest(), lambda _: self.make_success(task))

    def test_skill_version_mismatch_is_rejected(self):
        task = self.make_task()
        task["skill_version"] = "2.0.0"
        with self.assertRaises(ValueError):
            invoke_skill(task, self.make_manifest(), lambda _: self.make_success(task))

    def test_external_skill_cannot_return_control_state(self):
        task = self.make_task()
        manifest = self.make_manifest()

        def executor(_):
            payload = self.make_success(task)
            payload["state_after"] = {"status": "COMPLETED"}
            return payload

        with self.assertRaises(ValueError):
            invoke_skill(task, manifest, executor)

    def test_success_requires_declared_output_evidence_and_provenance(self):
        task = self.make_task()
        manifest = self.make_manifest()

        bad = self.make_success(task)
        bad["evidence_refs"] = []
        with self.assertRaises(ValueError):
            invoke_skill(task, manifest, lambda _: bad)

        bad = self.make_success(task)
        bad["provenance_refs"] = []
        with self.assertRaises(ValueError):
            invoke_skill(task, manifest, lambda _: bad)

        bad = self.make_success(task)
        bad["output_refs"] = []
        with self.assertRaises(ValueError):
            invoke_skill(task, manifest, lambda _: bad)


if __name__ == "__main__":
    unittest.main()
