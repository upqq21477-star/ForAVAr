"""S5 batch 1: temporal_order (CAP-TEMPORAL).  SIMULATED_PASS.  Pure function; interruption = rerun."""
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
import capability_run as cr  # noqa: E402
import temporal_order as to  # noqa: E402


def c(i, t, **k):
    return {"id": i, "time": t, **k}


A, B, C = "2026-01-01T00:00:00+00:00", "2026-01-02T00:00:00+00:00", "2026-01-03T00:00:00+00:00"


class Order(unittest.TestCase):
    def test_sorted_and_stable_on_ties(self):
        r = to.order([c("z", B), c("y", A), c("x", B)])
        self.assertEqual((r["status"], r["order"]), ("OK", ["y", "z", "x"]))  # z before x: input order kept

    def test_unparseable_unknown_not_guessed(self):
        r = to.order([c("a", A), c("t", "下週三"), c("n", None), {"time": A}, c("b", B)])
        self.assertEqual((r["status"], r["order"]), ("PARTIAL", ["a", "b"]))
        self.assertEqual([u["reason"] for u in r["unknown"]], ["UNPARSEABLE", "UNPARSEABLE", "NO_ID"])
        self.assertAlmostEqual(r["unknown_ratio"], 3 / 5)

    def test_naive_and_aware_not_mixed(self):
        r = to.order([c("a", A), c("n", "2026-01-01T00:00:00")])
        self.assertEqual((r["order"], r["unknown"][0]["reason"]), (["a"], "NAIVE_VS_AWARE"))
        self.assertEqual(to.order([c("p", "2026-01-02T00:00:00"), c("q", "2026-01-01T00:00:00")])["order"], ["q", "p"])
        self.assertEqual(to.order([c("n", "2026-01-01T08:00:00", tz="+08:00"), c("a", A)])["order"], ["n", "a"])  # tz given -> aware

    def test_intervals(self):
        r = to.order([c("i", {"start": B, "end": C}), c("j", {"start": A, "end": B}), c("z", {"start": A, "end": A}), c("r", {"start": C, "end": A})])
        self.assertEqual(r["order"], ["j", "i"])
        self.assertEqual({u["id"]: u["reason"] for u in r["unknown"]}, {"z": "ZERO_LENGTH_INTERVAL", "r": "INVALID_INTERVAL"})

    def test_limit_incomplete_no_truncation(self):
        r = to.order([c(str(n), A) for n in range(4)], max_items=3)
        self.assertEqual((r["status"], r["order"], r["reason"]), ("INCOMPLETE", [], "TOO_MANY"))

    def test_rerun_same_and_no_state_after_interrupt(self):
        cl = [c("b", B), c("a", A)]
        with mock.patch.object(to, "_parse", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                to.order(cl)
        self.assertEqual(to.order(cl), to.order(cl))
        self.assertEqual(to.order(cl)["order"], ["a", "b"])


class Relation(unittest.TestCase):
    def test_relations(self):
        a, b = c("a", {"start": A, "end": B}), c("b", {"start": C, "end": "2026-01-04T00:00:00+00:00"})
        self.assertEqual((to.relation(a, b), to.relation(b, a), to.disjoint(a, b)), ("before", "after", True))
        self.assertEqual((to.relation(a, c("m", {"start": B, "end": C})), to.relation(a, c("o", {"start": A, "end": C}))), ("overlaps", "overlaps"))
        self.assertFalse(to.disjoint(a, a))

    def test_unknown_cases(self):
        self.assertEqual(to.relation(c("a", A), c("n", "2026-01-01T00:00:00")), "UNKNOWN")
        self.assertEqual(to.relation(c("a", A), c("t", "soon")), "UNKNOWN")
        self.assertIsNone(to.disjoint(c("a", A), c("t", "soon")))


class Period(unittest.TestCase):
    def test_fewer_than_three_unknown(self):
        self.assertEqual(to.periodicity([c("a", A), c("b", B)])["status"], "UNKNOWN")

    def test_periodic_and_not(self):
        p = to.periodicity([c("a", A), c("b", B), c("c", C)])
        self.assertEqual((p["status"], p["period_seconds"]), ("PERIODIC", 86400.0))
        self.assertEqual(to.periodicity([c("a", A), c("b", B), c("c", "2026-02-01T00:00:00+00:00")])["status"], "NOT_PERIODIC")


class Measured(unittest.TestCase):
    def test_measured_and_mutation_caught(self):
        self.assertEqual(cr.check("CAP-TEMPORAL"), {"capability": "CAP-TEMPORAL", "ok": True, "runner_ok": True, "providers_missing": []})
        self.assertEqual(cr.check("CAP-TEMPORAL", {"temporal": lambda: True})["providers_missing"], ["temporal_order"])
        with mock.patch.object(to, "_parse", lambda cl: "UNPARSEABLE"):
            self.assertFalse(cr.check("CAP-TEMPORAL")["runner_ok"])


if __name__ == "__main__":
    unittest.main()
