
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPT_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPT_DIR))

from self_evolution_boundary_guard import canonical_sha256, evaluate_candidate
from self_evolution_trust_evidence import build_attestation, build_rollback_evidence

CONSTITUTION = {
    "constitution_id": "P1.SELF_EVOLUTION_CONSTITUTION",
    "version": "1.0",
    "invariants": [{"id": "ONE_CANONICAL_AUTHORITY", "rule": "exactly one"}],
}
VALIDATOR_REGISTRY = {
    "registry_id": "P1.SELF_EVOLUTION_VALIDATORS",
    "version": "1.0",
    "validators": {
        "VAL-A": {"trust_domain": "DOMAIN-A", "active": True, "min_epoch": 1},
        "VAL-B": {"trust_domain": "DOMAIN-B", "active": True, "min_epoch": 1},
        "VAL-C": {"trust_domain": "DOMAIN-C", "active": True, "min_epoch": 1},
    },
}
SNAPSHOT = {"snapshot": "LAST-KNOWN-GOOD"}
ROLLBACK_DIGEST = canonical_sha256(SNAPSHOT)
ROLLBACK_REGISTRY = {
    "registry_id": "P1.SELF_EVOLUTION_ROLLBACK",
    "version": "1.0",
    "snapshots": {"SNAP-1": {"snapshot_digest": ROLLBACK_DIGEST, "legal": True}},
}

def candidate():
    return {
        "candidate_id": "SAFE-001",
        "claims": {
            "superseded_control_still_active": False,
            "validator_self_certified": False,
            "hot_state_unbounded": False,
            "promotes_unknown_or_conflict": False,
        },
        "evidence": {
            "provenance_ref": "PROV:001",
            "rollback_snapshot_ref": "SNAP-1",
        },
    }

def attest(c):
    digest = canonical_sha256(c)
    constitution_digest = canonical_sha256(CONSTITUTION)
    return [
        build_attestation(
            validator_id="VAL-A", trust_domain="DOMAIN-A",
            candidate_digest=digest, constitution_digest=constitution_digest,
            decision="PASS", epoch=1, attestation_id="ATTEST-A-1",
        ),
        build_attestation(
            validator_id="VAL-B", trust_domain="DOMAIN-B",
            candidate_digest=digest, constitution_digest=constitution_digest,
            decision="PASS", epoch=1, attestation_id="ATTEST-B-1",
        ),
    ]

def rollback():
    return build_rollback_evidence(
        snapshot_id="SNAP-1",
        snapshot_digest=ROLLBACK_DIGEST,
        constitution_digest=canonical_sha256(CONSTITUTION),
        verification_epoch=1,
    )

def trusted_kwargs(c):
    return {
        "constitution": CONSTITUTION,
        "trusted_constitution_sha256": canonical_sha256(CONSTITUTION),
        "validator_evidence": attest(c),
        "validator_registry": VALIDATOR_REGISTRY,
        "trusted_validator_registry_sha256": canonical_sha256(VALIDATOR_REGISTRY),
        "rollback_evidence": rollback(),
        "rollback_registry": ROLLBACK_REGISTRY,
        "trusted_rollback_registry_sha256": canonical_sha256(ROLLBACK_REGISTRY),
        "active_canonical_authorities": ["AUTH-A"],
    }

class SelfEvolutionBoundaryGuardTests(unittest.TestCase):
    def test_safe_candidate_passes(self):
        c = candidate()
        report = evaluate_candidate(c, **trusted_kwargs(c))
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["decision"], "PROMOTE")
        self.assertEqual(report["violations"], [])

    def test_self_certifying_validator_claim_is_blocked(self):
        c = candidate()
        c["claims"]["validator_self_certified"] = True
        report = evaluate_candidate(c, **trusted_kwargs(c))
        self.assertEqual(report["status"], "BLOCK")
        self.assertIn("MUTABLE_VALIDATOR_CANNOT_SELF_CERTIFY", report["violations"])

    def test_missing_trust_anchor_fails_closed(self):
        c = candidate()
        kwargs = trusted_kwargs(c)
        kwargs["trusted_constitution_sha256"] = None
        report = evaluate_candidate(c, **kwargs)
        self.assertEqual(report["status"], "BLOCK")
        self.assertIn("TRUST_ANCHOR_UNAVAILABLE", report["violations"])

    def test_missing_validator_evidence_fails_closed(self):
        c = candidate()
        kwargs = trusted_kwargs(c)
        kwargs["validator_evidence"] = None
        report = evaluate_candidate(c, **kwargs)
        self.assertEqual(report["status"], "BLOCK")
        self.assertIn("VALIDATOR_EVIDENCE_REQUIRED", report["violations"])

    def test_registry_anchor_mismatch_fails_closed(self):
        c = candidate()
        kwargs = trusted_kwargs(c)
        kwargs["trusted_validator_registry_sha256"] = "0" * 64
        report = evaluate_candidate(c, **kwargs)
        self.assertEqual(report["status"], "BLOCK")
        self.assertIn("VALIDATOR_REGISTRY_ANCHOR_MISMATCH", report["violations"])

    def test_corrupted_rollback_evidence_fails_closed(self):
        c = candidate()
        kwargs = trusted_kwargs(c)
        kwargs["rollback_evidence"] = dict(kwargs["rollback_evidence"])
        kwargs["rollback_evidence"]["snapshot_digest"] = "0" * 64
        report = evaluate_candidate(c, **kwargs)
        self.assertEqual(report["status"], "BLOCK")
        self.assertIn("ROLLBACK_SNAPSHOT_DIGEST_MISMATCH", report["violations"])

if __name__ == "__main__":
    unittest.main()
