"""S7 batch 1: Run.close -> provenance_trace (CAP-PROVENANCE production caller).  SIMULATED_PASS (death = BaseException)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

R = Path(__file__).resolve().parents[2]
S = R / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(S))
sys.path.insert(0, str(R / "tools"))
import caller_audit as ca  # noqa: E402
import p2_run as pr  # noqa: E402

SPECS = ["provenance_trace:trace", "provenance_trace:provenance_input"]


class Died(BaseException):
    pass


class Prov(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.w = pr._toy(self.tmp / "w")

    def mk(self, journal=None):
        r = pr.Run(self.w, write_scope=["calc.py"], goal_confirmed=True, journal_path=journal)
        self.assertTrue(pr._build_mode(r))
        return r

    def fix_and_test(self, r):
        self.assertTrue(r.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"})["ok"])
        self.assertTrue(r.step("run_tests", {})["ok"])

    def close(self, r):
        return r.close(self.tmp / "log.jsonl", "c1")

    def test_chain_complete(self):
        r = self.mk()
        self.fix_and_test(r)
        res = self.close(r)
        self.assertEqual((res["provenance"], res["provenance_ok"]), ("COMPLETE", True))

    def test_out_of_band_change_is_partial_outcome_unchanged(self):
        r = self.mk()
        self.assertTrue(r.step("edit", {"path": "calc.py", "old": "a - b", "new": "a + b"})["ok"])
        (self.w / "calc.py").write_text("def add(a, b):\n    return a + b  # x\n", encoding="utf-8")
        self.assertTrue(r.step("edit", {"path": "calc.py", "old": "# x", "new": "# y"})["ok"])
        self.assertTrue(r.step("run_tests", {})["ok"])
        res = self.close(r)
        self.assertEqual((res["provenance"], res["provenance_ok"], res["outcome_class"]), ("PARTIAL", False, "PASSED"))

    def test_no_passing_tests_not_applicable(self):
        r = self.mk()
        r.step("read", {"path": "calc.py"})
        self.assertEqual(self.close(r)["provenance"], "NOT_APPLICABLE")

    def test_error_is_incomplete_death_propagates(self):
        r = self.mk()
        self.fix_and_test(r)
        with mock.patch.object(pr.ptr, "trace", side_effect=ValueError("x")):
            self.assertEqual(self.close(r)["provenance"], "INCOMPLETE")
        with mock.patch.object(pr.ptr, "trace", side_effect=Died()):
            with self.assertRaises(Died):
                self.close(r)

    def test_interrupted_then_resumed_same_result(self):
        jp = self.tmp / "j.jsonl"
        r = self.mk(jp)
        self.fix_and_test(r)
        r.release()  # death before close: journal handle gone, nothing closed
        rr = pr.Run.resume(self.w, jp, write_scope=["calc.py"], goal_confirmed=True)
        self.assertEqual(rr.status, "RESUMED")
        self.assertEqual(self.close(rr.run)["provenance"], "COMPLETE")

    def test_mutation_removing_the_calls_makes_them_dead(self):
        sc = self.tmp / "m" / "P1-Central-Control" / "scripts"
        sc.mkdir(parents=True)
        for n in ("provenance_trace.py", "graph_check.py"):
            shutil.copy(S / n, sc / n)
        src = (S / "p2_run.py").read_text(encoding="utf-8")
        (sc / "p2_run.py").write_text(src, encoding="utf-8")
        got = [x["classification"] for x in ca.audit(self.tmp / "m", SPECS)["results"]]
        self.assertEqual(got, ["PRODUCTION", "PRODUCTION"])
        (sc / "p2_run.py").write_text(src.replace("ptr.trace(", "x_(").replace("ptr.provenance_input(", "y_("), encoding="utf-8")
        got = [x["classification"] for x in ca.audit(self.tmp / "m", SPECS)["results"]]
        self.assertNotIn("PRODUCTION", got)


if __name__ == "__main__":
    unittest.main()
