from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from role_session_gate import admission  # noqa: E402


def request(
    role_id: str,
    operation: str,
    *,
    command: str,
    profile_id: str,
    mode: str,
    write_targets: list[str] | None = None,
    external_research: bool = False,
    history_loaded: int = 0,
    transient_context_loaded: bool = False,
    targeted_retrieval_only: bool = True,
    task_packet_ref: str | None = None,
    verification_target_ref: str | None = None,
    verification_target_refs: list[str] | None = None,
    acceptance_mode: str | None = None,
) -> dict:
    return {
        "request_id": f"TEST:{role_id}:{operation}",
        "role_id": role_id,
        "operation": operation,
        "activation_command": command,
        "profile_id": profile_id,
        "mode": mode,
        "task_packet_ref": task_packet_ref,
        "verification_target_ref": verification_target_ref,
        "verification_target_refs": verification_target_refs or [],
        "construction_record_ref": None,
        "acceptance_mode": acceptance_mode or "NONE",
        "requested_write_targets": write_targets or [],
        "external_research": external_research,
        "history_loaded": history_loaded,
        "transient_context_loaded": transient_context_loaded,
        "targeted_retrieval_only": targeted_retrieval_only,
    }


EXEC = dict(
    command="！施工",
    profile_id="IP:CONSTRUCTION-EXECUTOR",
    mode="CONSTRUCTION",
)
VER = dict(
    command="！驗收",
    profile_id="IP:ACCEPTANCE-VERIFIER",
    mode="ACCEPTANCE",
)


def test_executor_admits_execution():
    result = admission(request(
        "ROLE:EXECUTOR","EXECUTE_TASK",
        write_targets=["TASK_SCOPE"],
        task_packet_ref="TASK_PACKET:pkt-test",
        **EXEC,
    ))
    assert result["status"] == "PASS"


def test_executor_rejects_verification():
    result = admission(request(
        "ROLE:EXECUTOR","VERIFY_TASK",
        write_targets=[],
        task_packet_ref="TASK_PACKET:pkt-test",
        **EXEC,
    ))
    assert result["status"] == "BLOCK"
    assert "OPERATION_DENIED" in result["reason_codes"]


def test_executor_requires_amnesia():
    result = admission(request(
        "ROLE:EXECUTOR","EXECUTE_TASK",
        write_targets=["TASK_SCOPE"],
        history_loaded=1,
        task_packet_ref="TASK_PACKET:pkt-test",
        **EXEC,
    ))
    assert result["status"] == "BLOCK"
    assert "AMNESIA_HISTORY_LOADED" in result["reason_codes"]


def test_executor_cannot_research():
    result = admission(request(
        "ROLE:EXECUTOR","EXECUTE_TASK",
        write_targets=["TASK_SCOPE"],
        external_research=True,
        task_packet_ref="TASK_PACKET:pkt-test",
        **EXEC,
    ))
    assert result["status"] == "BLOCK"


def test_verifier_admits_batch_verification():
    result = admission(request(
        "ROLE:VERIFIER","VERIFY_TASK",
        write_targets=["VERIFICATION_RESULT"],
        verification_target_refs=["RESULT:32","RESULT:33","RESULT:34"],
        acceptance_mode="CONTRACT_ONLY_SIMULATION_FIRST",
        **VER,
    ))
    assert result["status"] == "PASS"


def test_verifier_requires_acceptance_mode():
    result = admission(request(
        "ROLE:VERIFIER","VERIFY_TASK",
        write_targets=["VERIFICATION_RESULT"],
        verification_target_refs=["RESULT:32"],
        **VER,
    ))
    assert result["status"] == "BLOCK"
    assert "VERIFIER_ACCEPTANCE_MODE_REQUIRED" in result["reason_codes"]


def test_verifier_rejects_execution():
    result = admission(request(
        "ROLE:VERIFIER","EXECUTE_TASK",
        write_targets=[],
        verification_target_ref="RESULT:run-1",
        acceptance_mode="SIMULATION_FIRST",
        **VER,
    ))
    assert result["status"] == "BLOCK"


def test_verifier_requires_clean_context():
    result = admission(request(
        "ROLE:VERIFIER","VERIFY_TASK",
        write_targets=["VERIFICATION_RESULT"],
        history_loaded=1,
        verification_target_ref="RESULT:run-1",
        acceptance_mode="SIMULATION_FIRST",
        **VER,
    ))
    assert result["status"] == "BLOCK"
    assert "AMNESIA_HISTORY_LOADED" in result["reason_codes"]


def test_verifier_cannot_self_repair():
    result = admission(request(
        "ROLE:VERIFIER","REPAIR_IN_SCOPE",
        write_targets=["SOURCE"],
        verification_target_ref="RESULT:run-1",
        acceptance_mode="SIMULATION_FIRST",
        **VER,
    ))
    assert result["status"] == "BLOCK"


def test_control_admits_research_and_planning():
    result = admission(request(
        "ROLE:CONTROL_RESEARCH","EXTERNAL_RESEARCH",
        command="！討論",
        profile_id="IP:CONTROL-DISCUSSION",
        mode="DISCUSSION",
        write_targets=["RESEARCH_ARTIFACTS"],
        external_research=True,
        targeted_retrieval_only=False,
    ))
    assert result["status"] == "PASS"


def test_guidance_is_same_control_role():
    result = admission(request(
        "ROLE:CONTROL_RESEARCH","ANALYZE",
        command="！指導",
        profile_id="IP:GUIDANCE-REVIEW",
        mode="GUIDANCE",
        write_targets=[],
    ))
    assert result["status"] == "PASS"


def test_control_rejects_self_verification():
    result = admission(request(
        "ROLE:CONTROL_RESEARCH","VERIFY_TASK",
        command="！討論",
        profile_id="IP:CONTROL-DISCUSSION",
        mode="DISCUSSION",
        write_targets=[],
    ))
    assert result["status"] == "BLOCK"


def test_wrong_activation_command_blocks():
    result = admission(request(
        "ROLE:EXECUTOR","EXECUTE_TASK",
        command="！討論",
        profile_id="IP:CONSTRUCTION-EXECUTOR",
        mode="CONSTRUCTION",
        write_targets=["TASK_SCOPE"],
        task_packet_ref="TASK_PACKET:pkt-test",
    ))
    assert result["status"] == "BLOCK"
    assert "ACTIVATION_COMMAND_NOT_BOUND_TO_ROLE" in result["reason_codes"]


def test_profile_mismatch_blocks():
    result = admission(request(
        "ROLE:EXECUTOR","EXECUTE_TASK",
        command="！施工",
        profile_id="IP:CONTROL-DISCUSSION",
        mode="CONSTRUCTION",
        write_targets=["TASK_SCOPE"],
        task_packet_ref="TASK_PACKET:pkt-test",
    ))
    assert result["status"] == "BLOCK"
    assert "PROFILE_NOT_BOUND_TO_ROLE" in result["reason_codes"]


def test_any_role_cannot_mutate_current():
    cases = [
        request(
            "ROLE:CONTROL_RESEARCH","MODIFY_PLAN",
            command="！討論",profile_id="IP:CONTROL-DISCUSSION",mode="DISCUSSION",
            write_targets=["P1_CURRENT"],
        ),
        request(
            "ROLE:EXECUTOR","WRITE_RESULT",
            command="！施工",profile_id="IP:CONSTRUCTION-EXECUTOR",mode="CONSTRUCTION",
            write_targets=["P1_CURRENT"],task_packet_ref="TASK_PACKET:pkt-test",
        ),
        request(
            "ROLE:VERIFIER","WRITE_VERIFICATION_RESULT",
            command="！驗收",profile_id="IP:ACCEPTANCE-VERIFIER",mode="ACCEPTANCE",
            write_targets=["P1_CURRENT"],verification_target_ref="RESULT:run-1",
            acceptance_mode="SIMULATION_FIRST",
        ),
    ]
    for result in map(admission, cases):
        assert result["status"] == "BLOCK"
        assert "WRITE_TARGET_DENIED" in result["reason_codes"]


def test_role_is_fail_closed_for_unknown_operation():
    result = admission(request(
        "ROLE:EXECUTOR","UNKNOWN_OPERATION",
        command="！施工",
        profile_id="IP:CONSTRUCTION-EXECUTOR",
        mode="CONSTRUCTION",
        write_targets=[],
        task_packet_ref="TASK_PACKET:pkt-test",
    ))
    assert result["status"] == "BLOCK"
    assert "OPERATION_NOT_ALLOWED" in result["reason_codes"]


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)
