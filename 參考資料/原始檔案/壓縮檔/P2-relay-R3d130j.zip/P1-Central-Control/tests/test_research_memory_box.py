#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
SCRIPTS=ROOT/"P1-Central-Control/scripts"
sys.path.insert(0,str(SCRIPTS))

import research_memory_box as box


def baseline():
    return {
        "risk_level":"L2",
        "baseline_revision":"rev-1",
        "source_refs":["current:1","evidence:1"],
        "goal":"test",
        "change_request":"test change",
        "facts":[
            {"claim_id":"F1","kind":"CONFIRMED","claim":"current state","source_refs":["current:fact"]},
        ],
        "constraints":[
            {"claim_id":"C1","kind":"OBSERVED","claim":"must stay model-agnostic","source_refs":["current:constraint"]},
        ],
        "capabilities":[],
        "unknowns":["unknown-a"],
        "conflicts":[],
    }


class ResearchMemoryBoxTests(unittest.TestCase):
    def test_create_is_fresh(self):
        result=box.create_box(baseline())
        self.assertEqual(result["kind"],"FRESH_DECISION_WORKSPACE")
        self.assertEqual(result["working_context"],[])
        self.assertIsNone(result["decision"])

    def test_previous_conclusion_is_rejected(self):
        value=baseline()
        value["prior_conclusions"]=["legacy conclusion"]
        with self.assertRaises(ValueError):
            box.create_box(value)

    def test_inferred_fact_is_rejected(self):
        value=baseline()
        value["facts"][0]["kind"]="INFERRED"
        with self.assertRaises(ValueError):
            box.create_box(value)

    def test_close_requires_evidence_and_alternatives(self):
        value=box.create_box(baseline())
        with self.assertRaises(ValueError):
            box.close_box(value,{"outcome":"NO_CHANGE"})

    def test_close_blocks_missing_claim_provenance(self):
        value=box.create_box(baseline())
        value["objective_baseline"]["facts"][0].pop("source_refs")
        value=box.add_external(value,{
            "evidence_id":"E1",
            "kind":"EVIDENCE",
            "source_refs":["ext:1"],
            "claim":"evidence"
        })
        value=box.add_alternative(value,{
            "option_id":"NO_CHANGE",
            "name":"No change",
            "tradeoffs":"none",
            "source_refs":["option:1"]
        })
        with self.assertRaises(ValueError):
            box.close_box(value,{
                "outcome":"NO_CHANGE",
                "evidence_refs":["ext:1"],
                "alternative_refs":["NO_CHANGE"]
            })
    def test_close_accepts_no_change(self):
        value=box.create_box(baseline())
        value=box.add_external(value,{
            "evidence_id":"E1",
            "kind":"EVIDENCE",
            "source_refs":["ext:1"],
            "claim":"existing solution is sufficient"
        })
        value=box.add_alternative(value,{
            "option_id":"NO_CHANGE",
            "name":"No change",
            "tradeoffs":"zero implementation surface",
            "source_refs":["option:no-change"]
        })
        value=box.close_box(value,{
            "outcome":"NO_CHANGE",
            "evidence_refs":["ext:1"],
            "alternative_refs":["NO_CHANGE"],
            "reason":"evidence supports no-change",
            "reversal_condition":"new evidence shows a real capability gap"
        })
        self.assertEqual(value["status"],"CLOSED")
        self.assertEqual(value["decision"]["outcome"],"NO_CHANGE")


if __name__=="__main__":
    unittest.main()
