"""S4b batch 1: stats_summary (CAP-STATISTICS).  SIMULATED_PASS.  Pure function; death/rerun = run again, same output."""
import hashlib
import json
import statistics
import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
import capability_run as cr  # noqa: E402
import stats_summary as ss  # noqa: E402

K = ("D1", "2026-W41", "VERIFIED")


def run(values, ds="D1", rng="2026-W41", trust="VERIFIED"):
    return ss.summarize(ds, values, rng, trust)


class Known(unittest.TestCase):
    def test_known_dataset(self):
        r = run([2, 4, 4, 4, 5, 5, 7, 9])
        self.assertEqual((r["status"], r["n"], r["min"], r["max"], r["mean"], r["median"]), ("OK", 8, 2, 9, 5.0, 4.5))
        self.assertAlmostEqual(r["stdev"], 2.13809, places=4)  # sample stdev, hand-checkable: sqrt(32/7)
        self.assertEqual(r["range"], "2026-W41")

    def test_n1_partial(self):
        r = run([3.5])
        self.assertEqual((r["status"], r["stdev"], r["mean"], r["reason"]), ("PARTIAL", None, 3.5, "資料不足"))

    def test_empty_insufficient_no_exception(self):
        r = run([])
        self.assertEqual((r["status"], r["n"]), ("INSUFFICIENT_DATA", 0))
        self.assertIsNone(r["mean"])

    def test_check_result_recomputes(self):
        v = [1, 2, 3, 10]
        self.assertTrue(ss.check_result(run(v), v))
        bad = dict(run(v), mean=99.0)
        self.assertFalse(ss.check_result(bad, v))


class Rejected(unittest.TestCase):
    def test_nan_bool_str_rejected_with_row(self):
        for bad, row in ((float("nan"), 2), (True, 2), ("7", 2), (float("inf"), 2)):
            r = run([1, 2, bad, 4])
            self.assertEqual((r["status"], r["bad_index"]), ("REJECTED", row), repr(bad))
            self.assertIsNone(r["mean"])

    def test_huge_int_rejected_not_raised(self):
        r = run([1, 10 ** 400])  # math.isfinite(10**400) raises OverflowError; must become REJECTED with the row
        self.assertEqual((r["status"], r["bad_index"]), ("REJECTED", 1))

    def test_missing_labels_fail_closed(self):
        self.assertEqual(run([1, 2], rng="")["status"], "REJECTED")
        self.assertEqual(run([1, 2], trust="MAYBE")["status"], "REJECTED")
        self.assertEqual(run("12")["status"], "REJECTED")


class Idempotent(unittest.TestCase):
    def test_same_input_same_hash(self):
        a, b = run([1, 2, 3]), run([1, 2, 3])
        self.assertEqual(json.dumps(a, sort_keys=True), json.dumps(b, sort_keys=True))
        self.assertEqual(a["key"], hashlib.sha256(json.dumps([[1, 2, 3], "2026-W41"]).encode()).hexdigest())
        self.assertNotEqual(a["key"], run([1, 2, 4])["key"])

    def test_interrupted_run_rerun_same(self):
        with mock.patch.object(ss.statistics, "mean", side_effect=KeyboardInterrupt):
            with self.assertRaises(KeyboardInterrupt):
                run([1, 2, 3])
        self.assertEqual(run([1, 2, 3])["status"], "OK")  # no state left behind

    def test_statistics_error_becomes_status(self):
        with mock.patch.object(ss.statistics, "stdev", side_effect=statistics.StatisticsError("x")):
            r = run([1, 2, 3])
        self.assertEqual(r["status"], "STAT_ERROR")
        self.assertIsNone(r["stdev"])  # no guessed value


class Downstream(unittest.TestCase):
    def test_unknown_when_not_usable(self):
        self.assertEqual(ss.downstream_value(run([]), "stdev"), "UNKNOWN")
        self.assertEqual(ss.downstream_value(run([3.5]), "stdev"), "UNKNOWN")
        self.assertEqual(ss.downstream_value(run([1, 3]), "mean"), 2.0)


class Measured(unittest.TestCase):
    def test_measured_and_mutations_caught(self):
        self.assertEqual(cr.check("CAP-STATISTICS"), {"capability": "CAP-STATISTICS", "ok": True, "runner_ok": True, "providers_missing": []})
        self.assertEqual(cr.check("CAP-STATISTICS", {"stats": lambda: True})["providers_missing"], ["stats_summary"])  # empty run caught
        with mock.patch.object(ss, "check_result", lambda r, v: False):
            self.assertFalse(cr.check("CAP-STATISTICS")["runner_ok"])
        with mock.patch.object(ss, "_bad_index", lambda v: None):  # reject path removed -> NaN accepted: must not pass
            try:
                caught = not cr.check("CAP-STATISTICS")["runner_ok"]
            except Exception:  # the runner blowing up is also "not passing"
                caught = True
            self.assertTrue(caught)


if __name__ == "__main__":
    unittest.main()
