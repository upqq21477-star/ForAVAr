import copy
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
import feature_lifecycle as fl  # noqa: E402


def outline():
    return [
        {"id": "N1", "parent": None, "title": "Intake", "summary": "Receive the new feature request and classify it.", "depends_on": [], "priority": 1},
        {"id": "N1.1", "parent": "N1", "title": "Parse", "summary": "Parse the request into a structured change record.", "depends_on": [], "priority": 2},
        {"id": "N1.2", "parent": "N1", "title": "Classify", "summary": "Route the change by class and authority.", "depends_on": ["N1.1"], "priority": 3},
        {"id": "N2", "parent": None, "title": "Build", "summary": "Implement the feature behind the entry point.", "depends_on": ["N1.2"], "priority": 4},
    ]


def good():
    cl = fl.new_checklist("CH-1", "demo feature")
    cl["outline"] = outline()
    return cl


class Stage1Tests(unittest.TestCase):  # SIMULATED_PASS: in-memory data only
    def test_new_checklist_starts_at_stage1_and_cannot_claim_done(self):
        cl = fl.new_checklist("CH-1", "demo")
        self.assertEqual(cl["stage"], 1)
        self.assertFalse(fl.can_claim_done(cl))
        self.assertTrue(fl.check_stage1(cl))  # empty outline is a blocker

    def test_complete_outline_passes_and_orders_leaves_by_dependency(self):
        cl = good()
        self.assertEqual(fl.check_stage1(cl), [])
        self.assertEqual(fl.todo_order(cl), ["N1.1", "N1.2", "N2"])

    def test_missing_summary_is_blocked(self):
        cl = good()
        cl["outline"][1]["summary"] = ""
        self.assertTrue(any("SUMMARY" in b for b in fl.check_stage1(cl)))

    def test_dependency_cycle_is_blocked(self):
        cl = good()
        cl["outline"][1]["depends_on"] = ["N2"]
        self.assertTrue(any("CYCLE" in b for b in fl.check_stage1(cl)))

    def test_unknown_dependency_and_parent_are_blocked(self):
        cl = good()
        cl["outline"][2]["depends_on"] = ["NOPE"]
        cl["outline"][3]["parent"] = "GHOST"
        b = fl.check_stage1(cl)
        self.assertTrue(any("UNKNOWN_DEP" in x for x in b))
        self.assertTrue(any("UNKNOWN_PARENT" in x for x in b))

    def test_priority_must_respect_dependencies(self):
        cl = good()
        cl["outline"][2]["priority"] = 1  # N1.2 before its dependency N1.1
        self.assertTrue(any("ORDER" in b for b in fl.check_stage1(cl)))

    def test_duplicate_id_and_duplicate_priority_are_blocked(self):
        cl = good()
        cl["outline"][1]["id"] = "N1"
        self.assertTrue(any("DUP_ID" in b for b in fl.check_stage1(cl)))
        cl2 = good()
        cl2["outline"][3]["priority"] = 3
        self.assertTrue(any("DUP_PRIORITY" in b for b in fl.check_stage1(cl2)))


class GateTests(unittest.TestCase):
    def test_cannot_advance_past_stage1_with_blockers(self):
        cl = fl.new_checklist("CH-2", "demo")
        with self.assertRaises(fl.LifecycleError):
            fl.advance(cl)
        self.assertEqual(cl["stage"], 1)

    def test_advance_moves_one_stage_when_exit_condition_met(self):
        cl = good()
        fl.advance(cl)
        self.assertEqual(cl["stage"], 2)

    def test_stage2_needs_entry_and_exit_code_zero_per_leaf(self):
        cl = good()
        fl.advance(cl)
        with self.assertRaises(fl.LifecycleError):
            fl.advance(cl)
        cl["runs"] = {n: {"entry": "scripts/x.py", "exit_code": 0} for n in fl.todo_order(cl)}
        cl["runs"]["N2"]["exit_code"] = 1
        with self.assertRaises(fl.LifecycleError):
            fl.advance(cl)
        cl["runs"]["N2"]["exit_code"] = 0
        fl.advance(cl)
        self.assertEqual(cl["stage"], 3)

    def test_done_only_after_real_run_evidence(self):
        cl = good()
        cl["stage"] = 4
        cl["runs"] = {n: {"entry": "x", "exit_code": 0} for n in fl.todo_order(cl)}
        cl["loop"] = {n: {"called": True, "ended": True, "retired": True, "distilled": True} for n in fl.todo_order(cl)}
        cl["final"] = {"status": "NOT_EXECUTED"}
        self.assertFalse(fl.can_claim_done(cl))
        cl["final"] = {"status": "SIMULATED_PASS"}
        self.assertFalse(fl.can_claim_done(cl))
        cl["final"] = {"status": "PROGRAM_EXECUTED_PASS"}
        self.assertTrue(fl.can_claim_done(cl))

    def test_stage3_requires_retirement_and_distillation(self):
        cl = good()
        cl["stage"] = 3
        cl["runs"] = {n: {"entry": "x", "exit_code": 0} for n in fl.todo_order(cl)}
        cl["loop"] = {n: {"called": True, "ended": True, "retired": True, "distilled": True} for n in fl.todo_order(cl)}
        bad = copy.deepcopy(cl)
        bad["loop"]["N1.2"]["retired"] = False
        with self.assertRaises(fl.LifecycleError):
            fl.advance(bad)
        fl.advance(cl)
        self.assertEqual(cl["stage"], 4)


if __name__ == "__main__":
    unittest.main()
