import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reverse_context_selection import execute


class ReverseContextSelectionTests(unittest.TestCase):
    def _base(self):
        return {
            "schema_version": "1.0",
            "request_id": "REVERSE:CTX-1",
            "status": "PASS",
            "identity": {
                "root_path": "/tmp/r",
                "root_name": "r",
                "file_count": 3,
                "source_revision": "abc"
            },
            "coverage_ledger": [],
            "inventory": [
                {"path": "app.py", "kind": "SOURCE", "language": "python", "bytes": 100, "lines": 5, "sha256": "a"*64},
                {"path": "core.py", "kind": "SOURCE", "language": "python", "bytes": 120, "lines": 6, "sha256": "b"*64},
                {"path": "unused.py", "kind": "SOURCE", "language": "python", "bytes": 80, "lines": 4, "sha256": "c"*64}
            ],
            "structure": {
                "modules": ["app.py", "core.py", "unused.py"],
                "symbols": [],
                "entrypoint_candidates": ["app.py"],
                "stub_signals": [],
                "syntax_errors": []
            },
            "dependencies": {
                "edges": [{"source": "app.py", "target": "core.py", "evidence": "import"}],
                "unresolved": []
            },
            "state_assessment": {
                "classification": "IMPLEMENTED",
                "implemented": True,
                "partial": False,
                "stub": False,
                "broken": False,
                "unknown": False,
                "next_diagnostic_point": None
            },
            "evidence": {
                "observed": [],
                "confirmed": [],
                "inferred": [],
                "unknown": ["runtime_behavior"],
                "conflict": []
            }
        }

    def test_focus_and_dependency_are_prioritized(self):
        result = execute(self._base(), focus_paths=["app.py"], max_files=2, max_bytes=250)
        paths = [x["path"] for x in result["selected_paths"]]
        self.assertIn("app.py", paths)
        self.assertIn("core.py", paths)
        self.assertIn("unused.py", result["deferred_paths"])

    def test_budget_is_bounded(self):
        result = execute(self._base(), max_files=1, max_bytes=1000)
        self.assertLessEqual(result["budget"]["selected_files"], 1)


if __name__ == "__main__":
    unittest.main()
