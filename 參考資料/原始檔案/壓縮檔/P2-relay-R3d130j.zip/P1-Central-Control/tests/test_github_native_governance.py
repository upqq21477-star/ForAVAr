import pathlib
import re
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[2]

class GitHubNativeGovernanceTests(unittest.TestCase):
    def read(self, path: str) -> str:
        return (ROOT / path).read_text(encoding="utf-8")

    def test_codeowners_has_repository_owner(self):
        content = self.read(".github/CODEOWNERS")
        self.assertIn("* @upqq21477-star", content)
        self.assertIn("/P1-Central-Control/ @upqq21477-star", content)

    def test_pull_request_template_requires_construction_state(self):
        content = self.read(".github/pull_request_template.md")
        for token in ("Construction Packet", "Work Packet", "Required State Delta", "Execution head SHA"):
            self.assertIn(token, content)

    def test_dependabot_tracks_actions(self):
        content = self.read(".github/dependabot.yml")
        self.assertIn('package-ecosystem: "github-actions"', content)
        self.assertIn('interval: "weekly"', content)

    def test_dependency_review_blocks_high(self):
        content = self.read(".github/workflows/p1-dependency-review.yml")
        self.assertIn("actions/dependency-review-action@a1d282b36b6f3519aa1f3fc636f609c47dddb294", content)
        self.assertIn("fail-on-severity: high", content)

    def test_all_external_actions_are_sha_pinned(self):
        workflow_dir = ROOT / ".github/workflows"
        action_ref = re.compile(r"uses:\s*([^\s@]+)@([^\s#]+)")
        for workflow in workflow_dir.glob("*.yml"):
            content = workflow.read_text(encoding="utf-8")
            for action, ref in action_ref.findall(content):
                if action.startswith("./"):
                    continue
                self.assertRegex(
                    ref,
                    r"^[0-9a-f]{40}$",
                    f"{workflow} uses floating action ref: {action}@{ref}",
                )

    def test_control_gate_has_concurrency(self):
        content = self.read(".github/workflows/p1-control-gate.yml")
        self.assertIn("concurrency:", content)
        self.assertIn("cancel-in-progress: true", content)

if __name__ == "__main__":
    unittest.main()
