from __future__ import annotations

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
TESTS = ROOT / "P1-Central-Control" / "tests"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(TESTS))

import central_role_interface  # noqa: E402
import construction_efficiency_review  # noqa: E402
import operational_reference_pack  # noqa: E402
import feature_batch_orchestrator  # noqa: E402
from brain_mode_controller import PLAN_GATE_KEYS, initial_control_state  # noqa: E402


def _request(operation: str, role_id: str, **kwargs) -> dict:
    request = {
        "request_id": f"TEST:{operation}:{role_id}",
        "operation": operation,
        "role_id": role_id,
    }
    request.update(kwargs)
    return request


def _prepare_root(
    root: Path,
    *,
    mode: str,
    stage_status: str = "IN_PROGRESS",
    work_status: str = "IN_PROGRESS",
    construction_status: str = "BUILDING",
    plan_approved: bool = False,
) -> tuple[Path, Path]:
    current_path = root / "P1-CURRENT.json"
    current = json.loads(current_path.read_text(encoding="utf-8"))
    current["current_stage"]["status"] = stage_status
    work_ref = current["implementation_control"]["active_work_packet"]
    construction_ref = current["implementation_control"]["active_construction_packet"]
    work_path = root / work_ref
    construction_path = root / construction_ref
    work = json.loads(work_path.read_text(encoding="utf-8"))
    construction = json.loads(construction_path.read_text(encoding="utf-8"))
    work["status"] = work_status
    construction["status"] = construction_status
    control = initial_control_state()
    control.update(
        mode=mode,
        plan_approved=plan_approved,
        plan_gates={key: True for key in PLAN_GATE_KEYS},
        plan_evidence={key: f"Reviewed current evidence for {key}." for key in PLAN_GATE_KEYS},
        last_transition=None,
    )
    work["brain_mode_control"] = control
    work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    construction_path.write_text(
        json.dumps(construction, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    current_path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return work_path, construction_path


class ConstructionProgressWatchdogTests(unittest.TestCase):
    def setUp(self):
        self._temporary = tempfile.TemporaryDirectory(prefix="p2-progress-watchdog-test-")
        self.root = Path(self._temporary.name) / "repo"
        shutil.copytree(
            ROOT,
            self.root,
            ignore=shutil.ignore_patterns("__pycache__", ".git"),
        )
        self.addCleanup(self._temporary.cleanup)

    @patch("central_role_interface.generate_construction_health_review")
    def test_repeated_no_progress_reports_trigger_review_and_pause_construction(self, review):
        _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=True,
        )
        review.return_value = {
            "status": "REVIEW_GENERATED",
            "trigger": "stalled",
            "signals": [{"code": "DOC_OR_CONTRACT_EXPANSION_CANDIDATE"}],
            "recommendations": ["Stop repeated readbacks and continue the next unblocked feature."],
        }

        first = central_role_interface.execute(
            _request("REPORT_PROGRESS", "ROLE:EXECUTOR", request_id="TEST:PROGRESS:1",
                     summary="Read same status; no implementation or evidence changed."),
            root=self.root,
        )
        second = central_role_interface.execute(
            _request("REPORT_PROGRESS", "ROLE:EXECUTOR", request_id="TEST:PROGRESS:2",
                     summary="Read same status again; no implementation or evidence changed."),
            root=self.root,
        )
        third = central_role_interface.execute(
            _request("REPORT_PROGRESS", "ROLE:EXECUTOR", request_id="TEST:PROGRESS:3",
                     summary="Repeated unchanged checkpoint; invoke recovery."),
            root=self.root,
        )
        fourth = central_role_interface.execute(
            _request("REPORT_PROGRESS", "ROLE:EXECUTOR", request_id="TEST:PROGRESS:4",
                     summary="Same unchanged checkpoint after recovery; do not repeat review."),
            root=self.root,
        )

        self.assertEqual(first["status"], "PASS")
        self.assertEqual(second["progress_classification"], "NO_PROGRESS_REPEAT")
        self.assertEqual(third["status"], "BLOCK")
        self.assertEqual(third["progress_classification"], "STALLED")
        self.assertEqual(third["reason_codes"], ["CONSTRUCTION_STALLED_NO_PROGRESS"])
        self.assertTrue(third["recovery_state_persisted"])
        self.assertIn("NEXT_UNBLOCKED_FEATURE", third["next_action"])
        self.assertEqual(fourth["status"], "BLOCK")
        self.assertEqual(fourth["reason_codes"], ["CONSTRUCTION_STALLED_ALREADY_REVIEWED"])
        self.assertFalse(fourth.get("health_review_rerun", True))
        review.assert_called_once_with(trigger="stalled", root=self.root)

        current = json.loads((self.root / "P1-CURRENT.json").read_text(encoding="utf-8"))
        work_ref = current["implementation_control"]["active_work_packet"]
        persisted = json.loads((self.root / work_ref).read_text(encoding="utf-8"))
        control = persisted["brain_mode_control"]
        self.assertEqual(control["mode"], "THINKING")
        self.assertFalse(control["plan_approved"])
        self.assertEqual(control["last_transition"]["event"], "CONSTRUCTION_STALLED")
        self.assertEqual(control["progress_guard"]["last_classification"], "STALLED")
        self.assertEqual(control["progress_guard"]["last_review_status"], "REVIEW_GENERATED")
        self.assertIn("Stop repeated readbacks", persisted["next_action"])

        manifest_ref = persisted["operational_contract"]["feature_batch_manifest_ref"]
        manifest = json.loads((self.root / manifest_ref).read_text(encoding="utf-8"))
        source_ref = next(
            reference
            for feature in manifest["features"]
            for reference in feature.get("implementation_refs", [])
            if isinstance(reference, str) and (self.root / reference).is_file()
        )
        source_path = self.root / source_ref
        original_source = source_path.read_bytes()
        try:
            source_path.write_bytes(original_source + b"\n# source changed while stalled\n")
            fifth = central_role_interface.execute(
                _request("REPORT_PROGRESS", "ROLE:EXECUTOR", request_id="TEST:PROGRESS:5",
                         summary="A source changed after the watchdog already paused construction."),
                root=self.root,
            )
        finally:
            source_path.write_bytes(original_source)

        self.assertEqual(fifth["status"], "BLOCK")
        self.assertEqual(
            fifth["reason_codes"],
            ["CONSTRUCTION_PAUSED_SOURCE_CHANGED_REVIEW_REQUIRED"],
        )
        self.assertEqual(
            fifth["next_action"],
            "REVIEW_SOURCE_CHANGE_IN_THINKING_AND_EXPLICITLY_APPROVE_CONSTRUCTION_RESUME",
        )
        persisted_after_source_change = json.loads((self.root / work_ref).read_text(encoding="utf-8"))
        self.assertEqual(
            persisted_after_source_change["next_action"],
            "REVIEW_SOURCE_CHANGE_IN_THINKING_AND_EXPLICITLY_APPROVE_CONSTRUCTION_RESUME",
        )
        self.assertEqual(
            persisted_after_source_change["handoff"]["next_step"],
            persisted_after_source_change["next_action"],
        )
        review.assert_called_once_with(trigger="stalled", root=self.root)

    def test_verifier_cannot_create_construction_progress_checkpoint(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "REPORT_PROGRESS",
                "ROLE:VERIFIER",
                summary="A verifier must not mutate construction progress.",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("ROLE_NOT_ALLOWED_FOR_PROGRESS_CHECKPOINT", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_progress_is_blocked_when_current_stage_is_closed_but_work_packet_is_stale_open(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "REPORT_PROGRESS",
                "ROLE:EXECUTOR",
                summary="Current has closed the stage although the Work Packet is stale-open.",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_control_progress_cannot_mutate_a_closed_active_work_unit(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            work_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            construction_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "REPORT_PROGRESS",
                "ROLE:CONTROL_RESEARCH",
                summary="This active work unit is already closed.",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_unresolved_executor_result_is_blocked_when_work_is_not_open(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            work_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            construction_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "SUBMIT_ROLE_RESULT",
                "ROLE:EXECUTOR",
                result_ref="TEST:RESULT:UNRESOLVED",
                result_status="INCOMPLETE",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_executor_progress_blocked_when_brain_is_paused_even_if_work_is_open(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=False,
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "REPORT_PROGRESS",
                "ROLE:EXECUTOR",
                summary="Work packet is open but Brain has paused construction.",
            ),
            root=self.root,
        )

        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("BRAIN_NOT_IN_AUTHORIZED_CONSTRUCTION_MODE", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_construction_stalled_is_not_a_caller_selectable_cognitive_event(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=True,
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:EXECUTOR",
                cognitive_event="CONSTRUCTION_STALLED",
            ),
            root=self.root,
        )

        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("COGNITIVE_EVENT_NOT_ALLOWED_FOR_ROLE", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_plan_transition_requires_plan_write_authority_not_read_only_access(self):
        _prepare_root(
            self.root,
            mode="PLAN_READY",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
        )
        with patch.object(
            central_role_interface,
            "_role_request",
            wraps=central_role_interface._role_request,
        ) as role_gate:
            result = central_role_interface.execute(
                _request(
                    "COGNITIVE_TRANSITION",
                    "ROLE:CONTROL_RESEARCH",
                    cognitive_event="PLAN_APPROVED",
                ),
                root=self.root,
            )

        self.assertEqual(result["status"], "PASS")
        kwargs = role_gate.call_args.kwargs
        self.assertEqual(kwargs["operation"], "MODIFY_PLAN")
        self.assertEqual(kwargs["requested_write_targets"], ["PLANNING_ARTIFACTS"])

    def test_only_plan_approved_rearms_watchdog_after_stall_pause(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="PLAN_READY",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
        )
        work = json.loads(work_path.read_text(encoding="utf-8"))
        fingerprint = central_role_interface._construction_progress_fingerprint(self.root, work)
        work["brain_mode_control"]["progress_guard"].update(
            last_checkpoint_fingerprint=fingerprint,
            no_progress_repeats=2,
            last_classification="STALLED",
            last_reviewed_fingerprint=fingerprint,
            last_review_status="REVIEW_GENERATED",
        )
        work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        still_paused = central_role_interface.execute(
            _request(
                "REPORT_PROGRESS",
                "ROLE:EXECUTOR",
                summary="An interim mode change must not clear the stall latch.",
            ),
            root=self.root,
        )
        self.assertEqual(still_paused["status"], "BLOCK")
        self.assertEqual(
            still_paused["reason_codes"],
            ["CONSTRUCTION_STALLED_ALREADY_REVIEWED"],
        )

        result = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="PLAN_APPROVED",
            ),
            root=self.root,
        )

        self.assertEqual(result["status"], "PASS")
        persisted = json.loads(work_path.read_text(encoding="utf-8"))
        control = persisted["brain_mode_control"]
        self.assertEqual(control["mode"], "CONSTRUCTION")
        self.assertEqual(control["progress_guard"]["last_classification"], "NOT_CHECKED")
        self.assertEqual(control["progress_guard"]["last_review_status"], "NOT_RUN")
        self.assertEqual(control["progress_guard"]["no_progress_repeats"], 0)

    def test_current_health_review_manifest_fits_bounded_source_cap(self):
        report = construction_efficiency_review._source_budget(self.root)
        request_path = (
            self.root / "P1-Central-Control/examples/operational_reference_pack.request.example.json"
        )
        request = json.loads(request_path.read_text(encoding="utf-8"))

        self.assertEqual(report["declared_source_count"], len(request["source_refs"]))
        self.assertGreater(report["declared_source_count"], 40)
        self.assertLessEqual(
            report["declared_source_count"],
            construction_efficiency_review.MAX_SOURCE_REFS,
        )
        self.assertEqual(report["missing_source_refs"], [])
        self.assertEqual(report["invalid_source_refs"], [])
        self.assertGreater(report["source_input_bytes_estimate"], 0)

    def test_explicit_final_batch_handoff_is_admitted_after_construction_closes(self):
        _prepare_root(
            self.root,
            mode="FINAL_ACCEPTANCE",
            stage_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            work_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            construction_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
        )
        request = _request(
            "SUBMIT_ROLE_RESULT",
            "ROLE:EXECUTOR",
            result_ref="TEST:FINAL_BATCH:HANDOFF",
            result_status="WORK_COMPLETE",
            final_batch_acceptance=True,
        )

        admission = central_role_interface._admit_construction_progress_request(
            request,
            self.root,
            "SUBMIT_ROLE_RESULT",
        )

        self.assertEqual(admission["status"], "PASS")
        self.assertTrue(admission["admitted"])

    def test_work_complete_result_is_blocked_when_work_is_not_open(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            work_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            construction_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "SUBMIT_ROLE_RESULT",
                "ROLE:EXECUTOR",
                result_ref="TEST:RESULT:WORK_COMPLETE_CLOSED",
                result_status="WORK_COMPLETE",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_orchestrator_owner_also_blocks_direct_mark_while_brain_is_paused(self):
        _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=False,
        )
        manifest_path = self.root / "P1-Central-Control/progress/P2-B1-B8.feature-batch.json"
        before = manifest_path.read_bytes()
        with self.assertRaisesRegex(
            feature_batch_orchestrator.BatchGateError,
            "BRAIN_NOT_IN_AUTHORIZED_CONSTRUCTION_MODE",
        ):
            feature_batch_orchestrator.mark_feature_implemented(self.root, "P2-F01")
        self.assertEqual(manifest_path.read_bytes(), before)

    def test_local_case_simulation_blocks_when_brain_is_not_in_simulation_mode(self):
        _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=False,
        )
        manifest_path = self.root / "P1-Central-Control/progress/P2-B1-B8.feature-batch.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        feature = next(item for item in manifest["features"] if item["feature_id"] == "P2-F01")
        feature["implementation_status"] = "IMPLEMENTED"
        manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        before = manifest_path.read_bytes()

        with self.assertRaisesRegex(
            feature_batch_orchestrator.BatchGateError,
            "LOCAL_CASE_BRAIN_MODE_NOT_AUTHORIZED",
        ):
            feature_batch_orchestrator.run_local_case_sim(self.root, "P2-F01")

        self.assertEqual(manifest_path.read_bytes(), before)

    def test_feature_implementation_cannot_be_marked_while_brain_is_paused(self):
        _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=False,
        )
        manifest_path = self.root / "P1-Central-Control/progress/P2-B1-B8.feature-batch.json"
        before = manifest_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "FEATURE_BATCH_CONTROL",
                "ROLE:EXECUTOR",
                batch_action="MARK_IMPLEMENTED",
                feature_id="P2-F01",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("BRAIN_NOT_IN_AUTHORIZED_CONSTRUCTION_MODE", result["reason_codes"])
        self.assertEqual(manifest_path.read_bytes(), before)

    def test_mutating_batch_action_cannot_bypass_executor_session_gate(self):
        _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            work_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            construction_status="IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
        )
        current = json.loads((self.root / "P1-CURRENT.json").read_text(encoding="utf-8"))
        manifest_path = self.root / "P1-Central-Control/progress/P2-B1-B8.feature-batch.json"
        before = manifest_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "FEATURE_BATCH_CONTROL",
                "ROLE:EXECUTOR",
                batch_action="MARK_IMPLEMENTED",
                feature_id="P2-F01",
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION", result["reason_codes"])
        self.assertEqual(manifest_path.read_bytes(), before)

    def test_verifier_result_requires_verifier_stage_admission_before_acceptance(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="THINKING",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
        )
        before = work_path.read_bytes()
        result = central_role_interface.execute(
            _request(
                "SUBMIT_ROLE_RESULT",
                "ROLE:VERIFIER",
                result_ref="TEST:VERIFICATION:UNADMITTED",
                result_status="PASS",
                work_unit_ref=None,
                acceptance_ref="P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
                head_sha="0" * 40,
            ),
            root=self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("WORK_UNIT_NOT_READY_FOR_ACCEPTANCE", result["reason_codes"])
        self.assertEqual(work_path.read_bytes(), before)

    def test_current_operational_request_validates_all_required_source_fields(self):
        request_path = (
            self.root / "P1-Central-Control/examples/operational_reference_pack.request.example.json"
        )
        schema_path = (
            self.root / "P1-Central-Control/schemas/operational_pack_request.schema.json"
        )
        request = json.loads(request_path.read_text(encoding="utf-8"))

        operational_reference_pack._validate(
            request,
            schema_path,
            "PACK_REQUEST_INVALID",
        )
        # 91 -> 88: F27 presentation_selector (script, schema, test) left source_refs when archived in R3d3
        # 88 -> 87 (R3d8): the deleted Test-Strategy and Brain-Formal docs were both retargeted to the Relay Plan,
        # which already had its own entry; the old 88 counted three entries for what is now one path
        self.assertEqual(len(request["source_refs"]), 87)
        self.assertTrue(all("required" in item for item in request["source_refs"]))
        self.assertTrue(all(item["required"] is True for item in request["source_refs"]))

    def test_operational_pack_input_budget_covers_all_declared_sources(self):
        request_path = (
            self.root / "P1-Central-Control/examples/operational_reference_pack.request.example.json"
        )
        request = json.loads(request_path.read_text(encoding="utf-8"))
        request_bytes = len(operational_reference_pack.canonical_json(request))
        current_bytes = (self.root / request["current_ref"]).stat().st_size
        blueprint_bytes = (self.root / request["blueprint_ref"]).stat().st_size
        referenced_bytes = sum(
            (self.root / item["path"]).stat().st_size
            for item in request["source_refs"]
        )
        measured_input_bytes = request_bytes + current_bytes + blueprint_bytes + referenced_bytes
        configured_budget = request["resource_budget"]["max_explicit_input_bytes"]
        retrospective_budget = construction_efficiency_review._source_budget(self.root)

        self.assertEqual(
            retrospective_budget["source_input_bytes_estimate"],
            measured_input_bytes,
        )
        self.assertGreater(len(request["source_refs"]), 40)
        self.assertGreater(measured_input_bytes, 750000)
        self.assertLessEqual(measured_input_bytes, configured_budget)
        self.assertLessEqual(
            configured_budget,
            operational_reference_pack.MAX_EXPLICIT_INPUT_BYTES,
        )

    def test_health_review_source_cap_still_blocks_unbounded_manifest(self):
        request_path = (
            self.root / "P1-Central-Control/examples/operational_reference_pack.request.example.json"
        )
        request = json.loads(request_path.read_text(encoding="utf-8"))
        request["source_refs"].extend(
            {"path": f"bounded-cap-probe/{index}.txt", "purpose": "cap test", "required": False}
            for index in range(construction_efficiency_review.MAX_SOURCE_REFS + 1 - len(request["source_refs"]))
        )
        request_path.write_text(json.dumps(request, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        with self.assertRaisesRegex(ValueError, "REVIEW_SOURCE_MANIFEST_INVALID"):
            construction_efficiency_review._source_budget(self.root)

    def test_actual_stalled_health_review_generates_report_from_current_source_manifest(self):
        import subprocess

        subprocess.run(["git", "init"], cwd=self.root, check=True, capture_output=True, text=True)
        subprocess.run(
            [
                "git", "-c", "user.name=P2 Regression", "-c",
                "user.email=p2-regression@example.invalid",
                "commit", "--allow-empty", "-m", "bounded health review baseline",
            ],
            cwd=self.root,
            check=True,
            capture_output=True,
            text=True,
        )
        report = construction_efficiency_review.generate_review(
            trigger="stalled",
            root=self.root,
        )
        request = json.loads(
            (
                self.root
                / "P1-Central-Control/examples/operational_reference_pack.request.example.json"
            ).read_text(encoding="utf-8")
        )

        self.assertEqual(report["status"], "REVIEW_GENERATED")
        self.assertEqual(
            report["source_budget_evidence"]["declared_source_count"],
            len(request["source_refs"]),
        )
        self.assertGreater(report["source_budget_evidence"]["declared_source_count"], 40)
        self.assertLessEqual(
            report["limits"]["max_declared_source_refs"],
            100,
        )
        self.assertFalse(report["limits"]["audit_history_written"])
        self.assertFalse(report["limits"]["external_model_or_metered_service_called"])

    def test_declared_output_change_changes_fingerprint_without_batch_manifest(self):
        work_path = self.root / "P1-Central-Control/progress/P2-B1-B8.work.json"
        work = json.loads(work_path.read_text(encoding="utf-8"))
        work["operational_contract"].pop("feature_batch_manifest_ref", None)
        first = central_role_interface._construction_progress_fingerprint(self.root, work)

        output_ref = next(
            output["path"]
            for output in work["outputs"]
            if isinstance(output, dict)
            and isinstance(output.get("path"), str)
            and (self.root / output["path"]).is_file()
            and output["path"] != "P1-CURRENT.json"
            and not output["path"].endswith((".work.json", ".construction.json"))
        )
        source_path = self.root / output_ref
        original = source_path.read_bytes()
        try:
            source_path.write_bytes(original + b"\n# non-batch output fingerprint marker\n")
            second = central_role_interface._construction_progress_fingerprint(self.root, work)
        finally:
            source_path.write_bytes(original)

        self.assertNotEqual(first, second)

    def test_declared_implementation_source_change_changes_progress_fingerprint(self):
        work_path = self.root / "P1-Central-Control/progress/P2-B1-B8.work.json"
        work = json.loads(work_path.read_text(encoding="utf-8"))
        first = central_role_interface._construction_progress_fingerprint(self.root, work)

        manifest_ref = work["operational_contract"]["feature_batch_manifest_ref"]
        manifest = json.loads((self.root / manifest_ref).read_text(encoding="utf-8"))
        source_ref = next(
            reference
            for feature in manifest["features"]
            for reference in feature.get("implementation_refs", [])
            if isinstance(reference, str)
            and (self.root / reference).is_file()
        )
        source_path = self.root / source_ref
        original = source_path.read_bytes()
        try:
            source_path.write_bytes(original + b"\n# progress fingerprint regression marker\n")
            second = central_role_interface._construction_progress_fingerprint(self.root, work)
        finally:
            source_path.write_bytes(original)

        self.assertNotEqual(first, second)


if __name__ == "__main__":
    unittest.main()
