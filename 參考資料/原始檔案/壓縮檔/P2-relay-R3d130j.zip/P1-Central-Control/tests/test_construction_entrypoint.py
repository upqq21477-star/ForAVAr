import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from construction_entrypoint import execute


class ConstructionEntrypointTests(unittest.TestCase):
    def _fixture(self, work: Path):
        (work / "P1-Central-Control").mkdir(parents=True)
        (work / "P1-Central-Control/capability_registry.json").write_text(
            json.dumps({
                "version": "1.0",
                "capabilities": [
                    {"capability_id": "CAP-EXISTING"}
                ]
            }),
            encoding="utf-8",
        )
        (work / "semantic.json").write_text(
            json.dumps(
                {
                    "status": "PASS",
                    "architecture_validated": True,
                    "invariants": ["target_is_bounded", "handoff_is_explicit"],
                }
            ),
            encoding="utf-8",
        )
        contract = {
            "schema_version": "1.0",
            "lifecycle_id": "CONSTRUCTION-ENTRYPOINT-TEST",
            "applies_to": "CAPABILITY",
            "stage_order": [
                "SEMANTIC_SPEC",
                "SEMANTIC_SIMULATION",
                "DISTILL",
                "DISTILLED_VALIDATION",
                "CODE_COMPILE",
                "CODE_ACCEPTANCE",
                "FINALIZE",
            ],
            "stages": [
                {
                    "stage_id": "SEMANTIC_SPEC",
                    "op": "VALIDATE_SEMANTIC_SPEC",
                    "inputs": ["semantic.json"],
                },
                {
                    "stage_id": "SEMANTIC_SIMULATION",
                    "op": "RUN_COMMAND",
                    "outputs": ["simulation.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('simulation.json').write_text('{\"status\":\"PASS\"}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "DISTILL",
                    "op": "RUN_COMMAND",
                    "inputs": ["simulation.json"],
                    "outputs": ["distilled.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('distilled.json').write_text('{\"status\":\"PASS\",\"rules\":[1]}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "DISTILLED_VALIDATION",
                    "op": "RUN_COMMAND",
                    "inputs": ["distilled.json"],
                    "outputs": ["validated.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('validated.json').write_text('{\"status\":\"PASS\"}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "CODE_COMPILE",
                    "op": "RUN_COMMAND",
                    "inputs": ["validated.json"],
                    "outputs": ["generated.py", "candidate.json"],
                    "command": [
                        sys.executable,
                        "-c",
                        "from pathlib import Path; Path('generated.py').write_text('VALUE = 42\\n', encoding='utf-8'); Path('candidate.json').write_text('{\"capability_id\":\"CAP-TEST-CONSTRUCTION\",\"class\":\"CONTROL\",\"implementation\":\"CANONICAL\",\"levels\":[0,1],\"kind\":\"CONTROL\",\"context_tier\":\"C1\",\"dependencies\":[],\"retirement_state\":\"ACTIVE\"}', encoding='utf-8')",
                    ],
                },
                {
                    "stage_id": "CODE_ACCEPTANCE",
                    "op": "RUN_COMMAND",
                    "inputs": ["generated.py"],
                    "command": [sys.executable, "-m", "py_compile", "generated.py"],
                },
                {
                    "stage_id": "FINALIZE",
                    "op": "FINALIZE",
                },
            ],
        }
        (work / "construction.json").write_text(
            json.dumps(contract, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        request = {
            "request_id": "REQ-ENTRY-001",
            "target_type": "CAPABILITY",
            "target_id": "CAP-TEST-CONSTRUCTION",
            "semantic_spec": "semantic.json",
            "lifecycle_contract": "construction.json",
            "registration": {
                "target_type": "CAPABILITY",
                "target_id": "CAP-TEST-CONSTRUCTION",
                "mode": "CREATE_NEW",
                "artifact_path": "candidate.json"
            },
        }
        (work / "request.json").write_text(
            json.dumps(request, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        return request

    def test_entrypoint_runs_full_construction(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._fixture(work)
            result = execute(request, work)
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(result["finalized"])
        self.assertEqual(result["phase"], "FINALIZE")
        self.assertEqual(result["target_type"], "CAPABILITY")
        self.assertEqual(len(result["lifecycle"]["stage_results"]), 7)
        self.assertEqual(result["registration"]["status"], "PASS")

    def test_entrypoint_rejects_target_contract_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._fixture(work)
            request["target_type"] = "SKILL"
            result = execute(request, work)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "LIFECYCLE_TARGET_TYPE_MISMATCH")
        self.assertFalse(result.get("finalized", False))

    def test_entrypoint_rejects_registration_target_mismatch(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._fixture(work)
            request["registration"]["target_id"] = "CAP-OTHER"
            result = execute(request, work)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["phase"], "REGISTRATION")
        self.assertEqual(result["reason"], "REGISTRATION_TARGET_MISMATCH")
        self.assertFalse(result.get("finalized", False))

    def test_entrypoint_rejects_missing_semantic_spec(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            request = self._fixture(work)
            request["semantic_spec"] = "missing.json"
            result = execute(request, work)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "SEMANTIC_SPEC_MISSING")


if __name__ == "__main__":
    unittest.main()
