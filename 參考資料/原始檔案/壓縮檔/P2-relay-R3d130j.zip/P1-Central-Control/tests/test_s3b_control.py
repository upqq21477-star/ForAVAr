"""S3b: verify_verdict / gap_ledger / iterate_control and their wiring (Run.close, session_driver.iterate).
SIMULATED_PASS (no real process death; death = release without close)."""
import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(ROOT / "tools"))
import caller_audit  # noqa: E402
import gap_ledger as gl  # noqa: E402
import iterate_control as ic  # noqa: E402
import p2_run  # noqa: E402
import run_journal as rj  # noqa: E402
import session_driver as sd  # noqa: E402
import verify_verdict as vv  # noqa: E402

CTOR = dict(write_scope=["calc.py"], protected=[], budget=12, goal_confirmed=True, run_id="RUN-T")
FAIL_EV = {"attempts": [{"step": "run_tests", "outcome": "failure"}], "head": "h1"}
OK_EV = {"attempts": [{"step": "run_tests", "outcome": "success", "exit_code": 0}], "head": "h2"}


class Died(BaseException):
    pass


class VerifyVerdict(unittest.TestCase):
    def test_missing_evidence_is_incomplete(self):
        for ev in (None, {}, {"attempts": []}):
            v = vv.verify("T", ev)
            self.assertEqual((v["verdict"], v["reasons"]), ("INCOMPLETE", ["EVIDENCE_MISSING"]))

    def test_same_evidence_same_verdict_and_key(self):
        a, b = vv.verify("T", FAIL_EV), vv.verify("T", json.loads(json.dumps(FAIL_EV)))
        self.assertEqual((a["verdict"], a["key"]), (b["verdict"], b["key"]))
        self.assertNotEqual(vv.verify("T", OK_EV)["key"], a["key"])

    def test_fail_names_the_failing_evidence_item(self):
        self.assertEqual(vv.verify("T", FAIL_EV)["failed"], ["attempt:0:outcome=failure"])
        bad = {"attempts": [{"outcome": "success", "exit_code": 1}], "head": "h"}  # tool exit code contradicts the outcome
        v = vv.verify("T", bad)
        self.assertEqual((v["verdict"], v["failed"]), ("FAIL", ["attempt:0:exit_code=1"]))

    def test_pass(self):
        self.assertEqual(vv.verify("T", OK_EV)["verdict"], "PASS")

    def test_verify_exception_is_incomplete_with_error_code_not_failed(self):
        v = vv.verify("T", {"attempts": [1], "head": "h"})
        self.assertEqual(v["verdict"], "INCOMPLETE")
        self.assertTrue(v["error_code"].startswith("VERIFY_ERROR"))

    def test_prior_verdict_is_reused_not_recomputed(self):
        first = vv.verify("T", FAIL_EV)
        with mock.patch.object(vv, "_decide", side_effect=AssertionError("recomputed")):
            again = vv.verify("T", FAIL_EV, prior=[first])
        self.assertEqual((again["verdict"], again["reused"]), ("FAIL", True))


class GapLedger(unittest.TestCase):
    def setUp(self):
        self.p = Path(tempfile.mkdtemp()) / "gaps.json"

    def test_same_evidence_rewritten_keeps_one_gap(self):
        ck = gl.load(self.p)
        v = vv.verify("T", FAIL_EV)
        gl.apply_verdict(ck, v, task="T")
        gl.apply_verdict(ck, v, task="T")
        self.assertEqual(len(ck["gaps"]), 1)

    def test_gap_without_evidence_ref_is_rejected(self):
        with self.assertRaises(ValueError):
            gl.make_gap("x", "FAIL", "")

    def test_priority_order_and_unknown(self):
        gaps = [gl.make_gap("a", "INCOMPLETE", "e1"), gl.make_gap("b", "???", "e2"), gl.make_gap("c", "FAIL", "e3")]
        self.assertEqual([g["priority"] for g in gl.ordered(gaps)], ["FAIL", "INCOMPLETE", "UNKNOWN"])

    def test_checkpoint_survives_reload_and_corrupt_file_is_rejected(self):
        ck = gl.load(self.p)
        gl.apply_verdict(ck, vv.verify("T", FAIL_EV), task="T")
        ck["round"] = 2
        gl.save(self.p, ck)
        self.assertEqual((gl.load(self.p)["round"], len(gl.load(self.p)["gaps"])), (2, 1))
        self.p.write_text("{not json", encoding="utf-8")
        with self.assertRaises(ValueError):
            gl.load(self.p)

    def test_pass_verdict_resolves_the_tasks_gaps(self):
        ck = gl.load(self.p)
        gl.apply_verdict(ck, vv.verify("T", FAIL_EV), task="T")
        gl.apply_verdict(ck, vv.verify("T", OK_EV), task="T")
        self.assertEqual(ck["gaps"], [])


class IterateControl(unittest.TestCase):
    def ck(self, ids=(), rnd=0, prev=()):
        return {"round": rnd, "prev_ids": list(prev),
                "gaps": [{"id": i, "priority": "FAIL", "task": "T", "desc": "", "evidence_ref": i} for i in ids]}

    def test_no_gap_is_done(self):
        self.assertEqual(ic.decide(self.ck(), 3)["decision"], "DONE")

    def test_limit_reports_unresolved(self):
        d = ic.decide(self.ck(["g1"], rnd=3), 3)
        self.assertEqual((d["decision"], d["unresolved"]), ("LIMIT", ["g1"]))

    def test_unchanged_gap_set_is_stalled(self):
        self.assertEqual(ic.decide(self.ck(["g1"], rnd=1, prev=["g1"]), 3)["decision"], "STALLED")
        self.assertEqual(ic.decide(self.ck(["g2"], rnd=1, prev=["g1"]), 3)["decision"], "CONTINUE")

    def test_finish_round_counts_and_survives_reload(self):
        p = Path(tempfile.mkdtemp()) / "g.json"
        ck = ic.finish_round(gl.load(p), prev_ids=[])
        gl.save(p, ck)
        self.assertEqual(gl.load(p)["round"], 1)  # not reset to zero after a restart


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp())
        self.wd, self.lp = p2_run._toy(self.d / "w"), self.d / "ev.jsonl"
        self.jd = self.d / "rounds"
        self.jd.mkdir()

    def iterate(self, work, **kw):
        return sd.iterate(self.wd, self.jd, self.lp, "C1", work, **{**CTOR, **kw})


class CloseWiring(Base):
    def run_with(self, outcome):
        r = p2_run.Run(self.wd, **CTOR, journal_path=self.d / "j.jsonl")
        r.attempts.append({"step": "run_tests", "outcome": outcome})
        return r

    def test_close_returns_verdict_and_writes_gap(self):
        gp = self.d / "gaps.json"
        res = self.run_with("failure").close(self.lp, "C1", gap_path=gp)
        self.assertEqual((res["verdict"], res["gaps"], res["outcome_class"]), ("FAIL", 1, "FAILED"))
        self.assertEqual(len(gl.load(gp)["gaps"]), 1)

    def test_gap_write_failure_makes_close_incomplete_and_does_not_raise(self):
        with mock.patch.object(gl, "save", side_effect=OSError("disk")):
            res = self.run_with("failure").close(self.lp, "C1", gap_path=self.d / "gaps.json")
        self.assertEqual((res["outcome_class"], res["close_error"]), ("INCOMPLETE", "GAP_WRITE_FAILED"))
        self.assertEqual(res["verdict"], "FAIL")  # the verdict is still reported; nothing is silently dropped

    def test_resume_reuses_the_journaled_verdict(self):
        jp = self.d / "j.jsonl"
        r = self.run_with("failure")
        r._jr("attempt", r.attempts[-1])
        v = vv.verify("RUN-T", {"attempts": r.attempts, "head": ""})
        r._jr("verdict", v)
        r.release()  # died after the verdict was journaled, before close
        res = p2_run.Run.resume(self.wd, jp, **CTOR)
        self.assertEqual([x["key"] for x in res.run.verdicts], [v["key"]])
        with mock.patch.object(vv, "_decide", side_effect=AssertionError("recomputed")):
            out = res.run.close(self.lp, "C1")
        self.assertEqual(out["verdict"], "FAIL")


class IterateLoop(Base):
    def test_pass_on_first_round_is_done(self):
        out = self.iterate(lambda r: r.attempts.append({"step": "run_tests", "outcome": "success", "exit_code": 0}))
        self.assertEqual((out["status"], out["round"]), ("DONE", 1))

    def test_ever_changing_failures_stop_at_the_limit(self):
        n = []

        def work(r):
            n.append(1)
            r.attempts.append({"step": "run_tests", "outcome": "failure", "n": len(n)})
        out = self.iterate(work, limit=3)
        self.assertEqual((out["status"], out["round"], len(n)), ("LIMIT", 3, 3))
        self.assertEqual(len(out["unresolved"]), 3)

    def test_identical_failures_are_stalled(self):
        out = self.iterate(lambda r: r.attempts.append({"step": "run_tests", "outcome": "failure"}), limit=5)
        self.assertEqual((out["status"], out["round"]), ("STALLED", 2))

    def test_round_that_errors_still_counts(self):
        def boom(r):
            raise RuntimeError("x")
        out = self.iterate(boom, limit=1)
        self.assertEqual(out["round"], 1)

    def test_interrupt_then_rerun_continues_same_round(self):
        seen = []

        def die(r):
            r.step("read", {"path": "calc.py"})
            raise Died()
        with self.assertRaises(Died):
            self.iterate(die)
        self.assertEqual(gl.load(self.jd / "gaps.json")["round"], 0)
        out = self.iterate(lambda r: (seen.append(len(r.trace)), r.attempts.append({"step": "run_tests", "outcome": "success"})))
        self.assertEqual((out["status"], out["round"]), ("DONE", 1))
        self.assertGreater(seen[0], 0)  # the interrupted round-1 journal was resumed, not restarted
        self.assertTrue(rj.Journal(self.jd / "round-1.jsonl").closed)

    def test_finished_loop_is_not_rerun(self):
        self.iterate(lambda r: r.attempts.append({"step": "run_tests", "outcome": "success"}))
        called = []
        out = self.iterate(lambda r: called.append(1))
        self.assertEqual((out["status"], called), ("DONE", []))


class ProductionCallers(unittest.TestCase):
    def test_new_modules_have_production_callers(self):
        specs = ["verify_verdict:verify", "gap_ledger:apply_verdict", "gap_ledger:load", "gap_ledger:save",
                 "iterate_control:decide", "iterate_control:finish_round"]
        rows = {f"{r['module']}:{r['function']}": r["classification"] for r in caller_audit.audit(ROOT, specs)["results"]}
        self.assertEqual(rows, {s: "PRODUCTION" for s in specs})


if __name__ == "__main__":
    unittest.main()
