import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))

import session_start  # noqa: E402


class SessionStartTests(unittest.TestCase):
    def test_report_has_all_sections(self):
        text = "\n".join(session_start.build_report())
        for key in ("清單驗證：", "交接檔：", "固定依賴：", "登記表：任務 DONE", "下一項：", "fixed_deps 檢查："):
            self.assertIn(key, text)

    def test_report_is_short(self):
        self.assertLess(len("\n".join(session_start.build_report()).encode("utf-8")), 2500)

    def test_precheck_line_pass_and_fail(self):
        self.assertEqual(session_start.precheck_line(lambda: (0, "[refs] HARD errors=0\nPRECHECK PASS\n")), "precheck 基線：PASS")
        line = session_start.precheck_line(lambda: (1, "[refs] HARD errors=2\n[json] HARD errors=0\n[json2] HARD errors=1\nPRECHECK FAIL\n"))
        self.assertIn("FAIL", line)
        self.assertIn("refs×2", line)
        self.assertNotIn("json×0", line)

    def test_precheck_line_nonzero_exit_without_hard_lines_still_fails(self):
        self.assertIn("FAIL", session_start.precheck_line(lambda: (2, "")))

    def test_registry_counts_match_report_line(self):
        c = session_start.registry_counts()
        self.assertLessEqual(c["done"], c["total"])
        self.assertLessEqual(c["batches_done"], c["batches_total"])
        self.assertIn(f"登記表：任務 DONE {c['done']}/{c['total']}", "\n".join(session_start.build_report()))


class HandoffCounterTests(unittest.TestCase):
    COUNTS = {"done": 11, "total": 39, "batches_done": 2, "batches_total": 8}

    def problems(self, text):
        import pack_handoff
        return pack_handoff.counter_problems({"sections": [{"blocks": [{"p": text}]}]}, self.COUNTS)

    def test_matching_counters_pass(self):
        self.assertEqual(self.problems("R4 批次 DONE（登記表 11/39、批次 2/8）"), [])

    def test_wrong_task_counter_rejected(self):
        self.assertEqual(len(self.problems("登記表 12/39、批次 2/8")), 1)

    def test_wrong_batch_counter_rejected(self):
        self.assertEqual(len(self.problems("登記表 11/39、批次 3/8")), 1)

    def test_text_without_counters_is_not_flagged(self):
        self.assertEqual(self.problems("沒有計數"), [])


if __name__ == "__main__":
    unittest.main()
