from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from acceptance_context import create_acceptance_context


def fixture_root() -> Path:
    root = Path(tempfile.mkdtemp(prefix="p1-acceptance-context-"))
    (root / "P1-Central-Control/progress/construction").mkdir(parents=True)
    (root / "P1-Central-Control/tasks").mkdir(parents=True)
    current = {
        "current_stage": {
            "id": "M32-CLOSE",
            "work_unit_id": "M32-CLOSE",
            "status": "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            "merged_commit_sha": "0a1fb571f35d33ca97decac579eb5f06f3dc918c",
        },
        "implementation_control": {
            "active_work_packet": "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json"
        },
    }
    work = {
        "work_id": "M32-CLOSE-VERTICAL-SLICE",
        "work_unit": "M32-CLOSE",
        "status": "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
        "task_packet_ref": "P1-Central-Control/tasks/M32-CLOSE.task.json",
        "construction_packet_ref": "P1-Central-Control/progress/construction/M32-CLOSE.construction.json",
    }
    task = {
        "packet_id": "pkt-M32-CLOSE",
        "object_id": "TASK_PACKET:pkt-M32-CLOSE",
    }
    construction = {"work_unit": "M32-CLOSE", "status": "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE"}
    (root / "P1-CURRENT.json").write_text(json.dumps(current), encoding="utf-8")
    (root / "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json").write_text(
        json.dumps(work), encoding="utf-8"
    )
    (root / "P1-Central-Control/tasks/M32-CLOSE.task.json").write_text(
        json.dumps(task), encoding="utf-8"
    )
    (root / "P1-Central-Control/progress/construction/M32-CLOSE.construction.json").write_text(
        json.dumps(construction), encoding="utf-8"
    )
    schema = ROOT / "P1-Central-Control/schemas/acceptance_context.schema.json"
    target_schema = root / schema.relative_to(ROOT)
    target_schema.parent.mkdir(parents=True, exist_ok=True)
    target_schema.write_text(schema.read_text(encoding="utf-8"), encoding="utf-8")
    return root


def test_create_context_updates_current_and_writes_artifact():
    root = fixture_root()
    result = create_acceptance_context(root=root)
    assert result["status"] == "CREATED"
    assert result["acceptance_ref"].endswith("M32-CLOSE.acceptance.json")
    context_path = root / result["acceptance_ref"]
    assert context_path.is_file()
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    assert current["current_stage"]["acceptance_ref"] == result["acceptance_ref"]
    assert current["current_stage"]["acceptance_mode"] == "SIMULATION_ONLY"
    context = json.loads(context_path.read_text(encoding="utf-8"))
    assert context["lifecycle_owner"] == "CENTRAL"
    assert context["authority"] == "P1-CURRENT"
    assert context["head_sha"] == "0a1fb571f35d33ca97decac579eb5f06f3dc918c"


def test_create_context_is_idempotent():
    root = fixture_root()
    first = create_acceptance_context(root=root)
    second = create_acceptance_context(root=root)
    assert second["status"] == "IDEMPOTENT_REPLAY"
    assert second["acceptance_ref"] == first["acceptance_ref"]
    assert second["context"]["content_sha256"] == first["context"]["content_sha256"]


def test_context_generation_blocks_when_work_is_open():
    root = fixture_root()
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    current["current_stage"]["status"] = "BUILDING"
    (root / "P1-CURRENT.json").write_text(json.dumps(current), encoding="utf-8")
    try:
        create_acceptance_context(root=root)
    except ValueError as exc:
        assert str(exc) == "WORK_UNIT_NOT_READY_FOR_ACCEPTANCE_CONTEXT"
    else:
        raise AssertionError("open work must not generate acceptance context")


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)
