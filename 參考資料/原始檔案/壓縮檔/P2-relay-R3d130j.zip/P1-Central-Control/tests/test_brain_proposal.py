#!/usr/bin/env python3
from __future__ import annotations

import copy
import sys
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import central_controller  # noqa: E402
from brain_proposal import (  # noqa: E402
    accept_proposal,
    materialize_command,
    validate_proposal,
    validate_proposal_against_state,
)
from event_log import EventLog  # noqa: E402


class BrainProposalTests(unittest.TestCase):
    def make_state(self) -> dict:
        return central_controller.init_state("WF-P9", "TASK-P9")

    def make_proposal(self, state: dict | None = None, **overrides) -> dict:
        state = state or self.make_state()
        proposal = {
            "object_id": "BRAIN_PROPOSAL:proposal-p9-001",
            "kind": "BRAIN_PROPOSAL",
            "schema_version": "1.0",
            "content_hash": "sha256:" + "b" * 64,
            "proposal_id": "proposal-p9-001",
            "workflow_id": state["workflow_id"],
            "aggregate_type": "WORKFLOW",
            "target_id": state["workflow_id"],
            "command_type": "START",
            "expected_state_revision": state["state_revision"],
            "idempotency_key": "proposal-p9-001:START",
            "route_mode": "DIRECT_COMMAND",
            "decision_code": "EXECUTE",
            "capability_refs": ["CAPABILITY:schema-builder"],
            "required_controls": [
                "STATE_VALIDATION",
                "IDEMPOTENCY",
                "EVENT_LOG",
            ],
            "evidence_refs": [],
            "contract_gap_refs": [],
            "semantic_explanation_ref": None,
        }
        proposal.update(overrides)
        return proposal

    def test_schema_is_strict_and_bounded(self):
        schema = __import__("json").loads(
            (SCHEMA_DIR / "brain_proposal.schema.json").read_text(
                encoding="utf-8"
            )
        )
        Draft202012Validator.check_schema(schema)
        self.assertLessEqual(
            (SCHEMA_DIR / "brain_proposal.schema.json").stat().st_size,
            8192,
        )
        with self.assertRaises(Exception):
            validate_proposal({**self.make_proposal(), "state_after": {}})

    def test_valid_proposal_is_accepted_without_state_mutation(self):
        state = self.make_state()
        proposal = self.make_proposal(state)
        before = copy.deepcopy(state)

        report = accept_proposal(state, proposal)

        self.assertEqual(report["status"], "ACCEPTED")
        self.assertEqual(state, before)
        self.assertEqual(state["status"], "READY")
        self.assertEqual(state["state_revision"], 0)

    def test_illegal_command_for_current_state_is_blocked(self):
        state = self.make_state()
        proposal = self.make_proposal(
            state,
            command_type="COMPLETE",
        )
        with self.assertRaises(ValueError):
            validate_proposal_against_state(state, proposal)

    def test_stale_revision_is_blocked(self):
        state = self.make_state()
        proposal = self.make_proposal(
            state,
            expected_state_revision=99,
        )
        with self.assertRaises(ValueError):
            validate_proposal_against_state(state, proposal)

    def test_materialized_command_is_commander_command(self):
        state = self.make_state()
        proposal = self.make_proposal(state)

        command = materialize_command(state, proposal)

        self.assertEqual(command["actor_id"], "COMMANDER")
        self.assertEqual(command["command_type"], "START")
        self.assertEqual(command["caused_by"], proposal["object_id"])
        self.assertEqual(command["target_id"], state["workflow_id"])

    def test_brain_provided_state_or_event_fields_are_not_materialized(self):
        state = self.make_state()
        proposal = self.make_proposal(
            state,
            semantic_explanation_ref="ARTIFACT:reason-001",
        )
        command = materialize_command(state, proposal)

        self.assertNotIn("state_after", command)
        self.assertNotIn("event", command)
        self.assertNotIn("status", command)

    def test_central_commit_executes_only_after_proposal_validation(self):
        state = self.make_state()
        proposal = self.make_proposal(state)

        with tempfile.TemporaryDirectory() as temp:
            state, result = central_controller.commit_brain_proposal(
                state,
                proposal,
                event_log=EventLog(Path(temp) / "events.jsonl"),
            )

        self.assertEqual(result["status"], "APPLIED")
        self.assertEqual(state["status"], "RUNNING")
        self.assertEqual(state["state_revision"], 1)
        self.assertEqual(
            result["event"]["event_type"],
            "STATE_TRANSITION_APPLIED",
        )

    def test_central_rejects_proposal_target_mismatch_before_command(self):
        state = self.make_state()
        proposal = self.make_proposal(
            state,
            target_id="WF-OTHER",
        )

        with tempfile.TemporaryDirectory() as temp:
            with self.assertRaises(ValueError):
                central_controller.commit_brain_proposal(
                    state,
                    proposal,
                    event_log=EventLog(Path(temp) / "events.jsonl"),
                )

        self.assertEqual(state["status"], "READY")
        self.assertEqual(state["state_revision"], 0)


if __name__ == "__main__":
    unittest.main()
