import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from repository_hygiene_gate import validate  # noqa: E402


class RepositoryHygieneGateTests(unittest.TestCase):
    def test_archive_versions_do_not_count_as_active(self):
        r = validate(["docs/plans/P-v1.2.md", "docs/archive/superseded/P-v1.0.md", "docs/archive/superseded/P-v1.1.md"])
        self.assertEqual(r["status"], "PASS")

    def test_multiple_active_versions_still_block(self):
        r = validate(["docs/plans/P-v1.0.md", "docs/plans/P-v1.1.md"])
        self.assertEqual(r["status"], "BLOCK")

    def test_evidence_snapshot_dir_is_exempt_from_banned_dirs(self):
        r = validate(["P1-Central-Control/evidence/r1/runs/run-001/artifacts/x.json"])
        self.assertEqual(r["status"], "PASS")

    def test_banned_dir_outside_evidence_still_blocks(self):
        r = validate(["P1-Central-Control/progress/artifacts/x.json"])
        self.assertEqual(r["status"], "BLOCK")

    def test_raw_debug_suffix_blocks_even_in_evidence(self):
        r = validate(["P1-Central-Control/evidence/r1/x.raw.json"])
        self.assertEqual(r["status"], "BLOCK")


if __name__ == "__main__":
    unittest.main()
