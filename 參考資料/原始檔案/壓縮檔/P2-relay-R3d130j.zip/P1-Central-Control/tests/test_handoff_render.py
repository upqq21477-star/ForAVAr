#!/usr/bin/env python3
"""U-9a：交接檔由資料產生；資料驗證；大小上限；repo 內現行資料可渲染。"""
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import handoff_render as hr  # noqa: E402

SAMPLE = {
    "handoff_id": "r0", "date": "2026-01-01", "store_key": "r0-TEST", "headline": "測試",
    "sections": [
        {"title": "甲", "blocks": [{"p": "段落"}, {"bullets": ["a", "b"]}]},
        {"title": "乙", "blocks": [{"table": {"header": ["x", "y"], "rows": [["1", "2"]]}}, {"code": "echo hi"}]},
    ],
}


class HandoffRenderTests(unittest.TestCase):
    def test_render_is_deterministic_and_structured(self) -> None:
        text = hr.render(SAMPLE)
        self.assertEqual(text, hr.render(json.loads(json.dumps(SAMPLE))))
        for needle in ("# r0｜P1 交接（2026-01-01）", "STORE_KEY: r0-TEST", "**一句話：測試**",
                       "## 1. 甲", "## 2. 乙", "- a", "| x | y |", "|---|---|", "```bash"):
            self.assertIn(needle, text)

    def test_invalid_data_rejected(self) -> None:
        bad_cases = [
            {**SAMPLE, "headline": ""},
            {**SAMPLE, "sections": [{"title": "空", "blocks": []}]},
            {**SAMPLE, "sections": [{"title": "x", "blocks": [{"p": "a", "code": "b"}]}]},
            {**SAMPLE, "sections": [{"title": "x", "blocks": [{"table": {"header": ["a"], "rows": [["1", "2"]]}}]}]},
            {**SAMPLE, "sections": [{"title": "x", "blocks": [{"bullets": []}]}]},
        ]
        for data in bad_cases:
            with self.assertRaises(ValueError):
                hr.render(data)

    def test_size_cap(self) -> None:
        big = {**SAMPLE, "sections": [{"title": "大", "blocks": [{"p": "字" * (hr.MAX_CHARS + 1)}]}]}
        with self.assertRaisesRegex(ValueError, "HANDOFF_TOO_LARGE"):
            hr.render(big)

    def test_repo_handoff_data_renders(self) -> None:
        data = json.loads(hr.DEFAULT_DATA.read_text(encoding="utf-8"))
        text = hr.render(data)
        self.assertIn(data["store_key"], text)
        self.assertGreaterEqual(len(data["sections"]), 8)

    def test_budget_block_is_measured_not_hand_written(self) -> None:
        data = {**SAMPLE, "sections": [{"title": "預算", "blocks": [{"budget": True}]}]}
        text = hr.render(data)
        self.assertIn("| 路徑 | 實測 B | max | target |", text)
        self.assertIn("| 全 repo |", text)
        with self.assertRaises(ValueError):
            hr.validate({**SAMPLE, "sections": [{"title": "x", "blocks": [{"budget": "123"}]}]})


if __name__ == "__main__":
    unittest.main()
