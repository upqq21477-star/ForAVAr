"""A pending-M32-CLOSE view of the repo, independent of the real Current stage.

Copies the repo once, then rebuilds M32-CLOSE's pre-close state in the copy (stage, active
packets, work/construction status, context head). Tests that assert M32 pre-close behaviour
run against this copy, so they stay valid whichever Work Unit the real Current points at.
"""
from __future__ import annotations

import atexit
import json
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
PENDING = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE"
_cache: Path | None = None


def _edit(path: Path, fn) -> None:
    data = json.loads(path.read_text(encoding="utf-8"))
    fn(data)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


M32_STAGE = {
    "id": "M32-CLOSE",
    "work_unit_id": "M32-CLOSE",
    "slice_id": "M32-CLOSE",
    "name": "Minimal Closed-Loop Runtime Vertical Slice",
    "status": PENDING,
    "implementation_step": "CLOSE_ACCEPTANCE",
    "acceptance": "ONE SIMULATION ACCEPTANCE AT M32-CLOSE WORK UNIT END",
    "acceptance_mode": "SIMULATION_ONLY",
    "acceptance_ref": "P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
    "merged_commit_sha": "006e606265026b7e5f81c5067d5901ef487d29c7",
    "validated_control_gate_run": None,
    "validated_head_sha": None,
    "regression_tests": ["P1-Central-Control/tests/test_m32_close_vertical_slice.py"],
    "latest_runtime_observation": {
        "classification": "CLOSE_ACCEPTANCE_REQUESTED",
        "program_regression_status": "INCOMPLETE",
    },
}


def _reopen_current(data: dict) -> None:
    data["current_stage"] = json.loads(json.dumps(M32_STAGE))
    # RUNTIME_TRUTH_BOUNDARY 以型別欄位（classification／program_regression_status）判斷；
    # 夾具自帶待驗收狀態的頂層觀察。期望不變。
    data["latest_runtime_observation"] = json.loads(json.dumps(M32_STAGE["latest_runtime_observation"]))
    control = data["implementation_control"]
    control["active_work_packet"] = "P1-Central-Control/progress/M32-CLOSE-VERTICAL-SLICE.work.json"
    control["active_construction_packet"] = "P1-Central-Control/progress/construction/M32-CLOSE.construction.json"


def _reopen_work(data: dict) -> None:
    data.update(status=PENDING, implementation_step="CLOSE_ACCEPTANCE")
    completion = data.get("completion")
    if isinstance(completion, dict):
        completion["verified_at"] = None
        completion.pop("acceptance_result", None)


def _reopen_construction(data: dict) -> None:
    data.update(status=PENDING, implementation_step="CLOSE_ACCEPTANCE")
    data.pop("acceptance_result", None)


def pending_root() -> Path:
    global _cache
    if _cache is None:
        tmp = Path(tempfile.mkdtemp(prefix="p1-pending-"))
        atexit.register(shutil.rmtree, tmp, ignore_errors=True)
        root = tmp / "repo"
        shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns("__pycache__", ".git"))
        _edit(root / "P1-CURRENT.json", _reopen_current)
        progress = root / "P1-Central-Control/progress"
        _edit(progress / "M32-CLOSE-VERTICAL-SLICE.work.json", _reopen_work)
        _edit(progress / "construction/M32-CLOSE.construction.json", _reopen_construction)
        # A closed repo's context was rebound to a code digest; restore what the
        # pending state would have generated (head = the stage's merged commit).
        sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
        from acceptance_context import sha256_payload

        stage = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))["current_stage"]

        def rebind(context: dict) -> None:
            context["head_sha"] = stage["merged_commit_sha"]
            context.pop("content_sha256", None)
            context["content_sha256"] = sha256_payload(context)

        _edit(root / stage["acceptance_ref"], rebind)
        _cache = root
    return _cache

