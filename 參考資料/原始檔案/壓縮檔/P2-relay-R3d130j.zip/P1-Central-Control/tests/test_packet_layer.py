#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker
from referencing import Registry, Resource

ROOT = Path(__file__).resolve().parents[2]
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
SCHEMA_DIR = ROOT / "P1-Central-Control" / "schemas"
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(TESTS_DIR))

import central_controller  # noqa: E402
from event_log import EventLog  # noqa: E402
from p7_test_records import records_for  # noqa: E402
from packet_layer import (  # noqa: E402
    build_attempt,
    build_result_packet,
    build_task_packet,
    validate_attempt,
    validate_result_packet,
    validate_task_packet,
)


class PacketLayerTests(unittest.TestCase):
    def make_segment(self, workflow_id="WF-P4", segment_id="SEG-P4-001"):
        return {
            "segment_id": segment_id,
            "workflow_id": workflow_id,
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "建立一個可驗收的 P4 packet",
            "input_scope": "runtime-test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": ["不要讀取 conversation history"],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 300000,
            "completion_contract": {
                "status": "WORK_COMPLETE",
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "ARTIFACT:execution-001",
            "context_cohort_id": "COHORT-P4",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
        }

    def schema_registry(self):
        registry = Registry()
        for name in (
            "canonical_identity.schema.json",
            "canonical_common.schema.json",
            "attempt.schema.json",
            "task_packet.schema.json",
            "result_packet.schema.json",
        ):
            schema = json.loads(
                (SCHEMA_DIR / name).read_text(encoding="utf-8")
            )
            registry = registry.with_resource(
                schema["$id"], Resource.from_contents(schema)
            )
        return registry

    def test_attempt_and_task_packet_are_real_canonical_objects(self):
        segment = self.make_segment()
        attempt = build_attempt(
            segment,
            started_at="2026-10-03T10:00:00+00:00",
        )
        task = build_task_packet(segment, attempt)

        self.assertEqual(attempt["status"], "RUNNING")
        self.assertEqual(attempt["attempt_number"], 1)
        self.assertEqual(task["attempt_id"], attempt["attempt_id"])
        self.assertEqual(task["skill_id"], "schema-builder")
        self.assertNotIn("conversation_history", task)

        validate_attempt(attempt)
        validate_task_packet(task)

    def test_task_packet_contains_all_independent_execution_context(self):
        task = build_task_packet(
            self.make_segment(),
            build_attempt(self.make_segment()),
        )
        required = {
            "workflow_id",
            "segment_id",
            "attempt_id",
            "skill_id",
            "skill_version",
            "objective",
            "input_refs",
            "requested_outputs",
            "constraints",
            "stop_condition",
            "failure_condition",
            "scope",
            "acceptance_ref",
            "context_budget",
            "execution_record_ref",
        }
        self.assertTrue(required.issubset(task))
        self.assertEqual(task["scope"]["input_scope"], "runtime-test")
        self.assertEqual(task["context_budget"]["hard_ceiling"], 2000)

    def test_result_packet_is_only_formal_skill_output(self):
        segment = self.make_segment()
        attempt = build_attempt(segment)
        task = build_task_packet(segment, attempt)

        result = build_result_packet(
            task,
            {
                "decision_code": "WORK_COMPLETE",
                "output_refs": ["ARTIFACT:result-001"],
                "evidence_refs": ["EVIDENCE:e1"],
                "provenance_refs": ["PROVENANCE:p1"],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 2,
                    "wall_time_ms": 150,
                },
            },
        )

        self.assertEqual(result["status"], "VALID")
        self.assertEqual(result["decision_code"], "WORK_COMPLETE")
        self.assertEqual(result["attempt_id"], task["attempt_id"])
        self.assertNotIn("outputs", result)
        self.assertNotIn("trace", result)
        validate_result_packet(result)

    def test_result_packet_rejects_task_attempt_mismatch(self):
        segment = self.make_segment()
        attempt = build_attempt(segment)
        task = build_task_packet(segment, attempt)

        with self.assertRaises(ValueError):
            bad_task = dict(task)
            bad_task["content_hash"] = task["content_hash"]
            bad_task["attempt_id"] = "att-other"
            build_result_packet(
                bad_task,
                {"decision_code": "WORK_COMPLETE"},
            )

    def test_decision_and_result_status_must_match(self):
        segment = self.make_segment()
        attempt = build_attempt(segment)
        task = build_task_packet(segment, attempt)

        with self.assertRaises(ValueError):
            build_result_packet(
                task,
                {
                    "status": "VALID",
                    "decision_code": "FAIL",
                },
            )

    def test_result_packet_requires_refs_not_raw_payload(self):
        segment = self.make_segment()
        attempt = build_attempt(segment)
        task = build_task_packet(segment, attempt)

        result = build_result_packet(
            task,
            {
                "decision_code": "UNRESOLVED",
                "unresolved": ["等待外部證據"],
            },
        )
        self.assertEqual(result["output_refs"], [])
        validate_result_packet(result)

    def test_schema_sizes_and_unknown_fields_remain_bounded(self):
        for filename in (
            "attempt.schema.json",
            "task_packet.schema.json",
            "result_packet.schema.json",
        ):
            schema = json.loads(
                (SCHEMA_DIR / filename).read_text(encoding="utf-8")
            )
            Draft202012Validator.check_schema(schema)
            self.assertLessEqual(
                (SCHEMA_DIR / filename).stat().st_size,
                8192,
            )

        segment = self.make_segment()
        attempt = build_attempt(segment)
        task = build_task_packet(segment, attempt)
        task["__unexpected__"] = True
        validator = Draft202012Validator(
            json.loads(
                (SCHEMA_DIR / "task_packet.schema.json").read_text(
                    encoding="utf-8"
                )
            ),
            registry=self.schema_registry(),
            format_checker=FormatChecker(),
        )
        self.assertTrue(list(validator.iter_errors(task)))

    def test_central_dispatch_now_returns_task_packet_and_tracks_attempt(self):
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-P4", "TASK-P4")
        state = central_controller.queue_segment(
            state,
            self.make_segment(),
        )

        with tempfile.TemporaryDirectory() as temp:
            state, task_packets = central_controller.dispatch(
                state,
                event_log=EventLog(Path(temp) / "events.jsonl"),
                execution_store=execution_store,
            )

        task_packet = task_packets[0]
        self.assertEqual(task_packet["kind"], "TASK_PACKET")
        self.assertEqual(task_packet["segment_id"], "SEG-P4-001")
        self.assertEqual(state["active_segments"][0]["attempt_id"], task_packet["attempt_id"])
        self.assertEqual(
            state["active_segments"][0]["task_packet_ref"],
            task_packet["object_id"],
        )

    def test_central_accepts_result_packet_only(self):
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-P4", "TASK-P4")
        state = central_controller.queue_segment(
            state,
            self.make_segment(),
        )

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, task_packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
            )
            packet = build_result_packet(
                task_packets[0],
                {
                    "decision_code": "WORK_COMPLETE",
                    "output_refs": ["ARTIFACT:result-001"],
                    "evidence_refs": ["EVIDENCE:test-001"],
                    "provenance_refs": ["PROVENANCE:test-001"],
                    "observed_usage": {
                        "model_calls": 1,
                        "tool_calls": 1,
                        "wall_time_ms": 1,
                    },
                    "usage_observed": True,
                },
            )
            envelope = execution_store[packet["execution_record_ref"]]
            evidence_records, provenance_records = records_for(
                envelope["task_packet"], packet, envelope["execution_record"]
            )
            state = central_controller.receive_result(
                state,
                packet,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                evidence_records=evidence_records,
                provenance_records=provenance_records,
            )

        self.assertEqual(state["status"], "COMPLETED")
        self.assertEqual(state["active_segments"], [])
        self.assertEqual(state["result_refs"], [packet["result_id"]])

    def test_central_rejects_legacy_system_result_shape(self):
        execution_store = {}
        distillation_store = {}
        state = central_controller.init_state("WF-P4", "TASK-P4")
        state = central_controller.queue_segment(
            state,
            self.make_segment(),
        )

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, _ = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
            )

            legacy = {
                "segment_id": "SEG-P4-001",
                "system_id": "SYSTEM-A",
                "status": "WORK_COMPLETE",
                "outputs": {"result": "raw"},
                "evidence_refs": [],
                "provenance_refs": [],
                "gaps": [],
                "unresolved": [],
                "trace": [],
                "completion": {
                    "segment_complete": True,
                    "handoff_ready": True,
                },
            }
            with self.assertRaises(ValueError):
                central_controller.receive_result(
                    state,
                    legacy,
                    event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                )


if __name__ == "__main__":
    unittest.main()
