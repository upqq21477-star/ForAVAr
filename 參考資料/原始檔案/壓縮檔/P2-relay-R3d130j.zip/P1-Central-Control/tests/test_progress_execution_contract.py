#!/usr/bin/env python3
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import progress_execution_contract as contract  # noqa: E402


class ProgressExecutionContractTests(unittest.TestCase):
    def make_packet(self, root: Path, *, reason: str = "planning_only") -> dict:
        output = root / "artifact.txt"
        output.write_text("runtime artifact\n", encoding="utf-8")
        (root / "P1-CURRENT.json").write_text(json.dumps({
            "current_stage": {
                "id": "TEST",
                "work_unit_id": "TEST",
                "validated_control_gate_run": None,
            },
            "implementation_control": {
                "active_work_packet": "work.json",
            },
        }), encoding="utf-8")
        (root / "work.json").write_text(json.dumps({
            "work_unit": "TEST",
            "status": "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
            "acceptance": {"mode": "SIMULATION_ONLY"},
            "handoff": {"gate": "WORK_UNIT_CLOSE_ACCEPTANCE_ONLY"},
        }), encoding="utf-8")
        return {
            "work_id": "TEST-CODE-FIRST",
            "phase": "TEST",
            "completion_reason": reason,
            "outputs": [{"path": "artifact.txt"}],
            "acceptance": {
                "profile": "TEST_PRINT_PASS"
            },
            "next_command": [
                "python3",
                "-m",
                "unittest",
                "-v",
                "P1-Central-Control/tests/test_progress_execution_contract.py",
            ],
            "execution_contract": {
                "version": "1.0",
                "steps": [
                    {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                    {"step_id": "ACCEPTANCE", "op": "RUN_ACCEPTANCE_COMMAND", "gate": "WORK_UNIT_CLOSE"},
                    {"step_id": "HANDOFF", "op": "EMIT_NEXT_COMMAND"},
                ],
            },
        }

    def test_contract_is_positive_operation_sequence(self) -> None:
        # acceptance 步驟必須帶 gate=WORK_UNIT_CLOSE（schema 與 test_acceptance_without_close_gate_is_blocked 一致）
        contract.validate_contract({
            "version": "1.0",
            "steps": [
                {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                {"step_id": "ACCEPTANCE", "op": "RUN_ACCEPTANCE_COMMAND", "gate": "WORK_UNIT_CLOSE"},
                {"step_id": "HANDOFF", "op": "EMIT_NEXT_COMMAND"},
            ],
        })


    def test_multiple_acceptance_steps_are_blocked(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            contract.validate_contract({
                "version": "1.0",
                "steps": [
                    {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                    {"step_id": "ACCEPTANCE_A", "op": "RUN_ACCEPTANCE_COMMAND", "gate": "WORK_UNIT_CLOSE"},
                    {"step_id": "ACCEPTANCE_B", "op": "RUN_ACCEPTANCE_COMMAND", "gate": "WORK_UNIT_CLOSE"},
                    {"step_id": "HANDOFF", "op": "EMIT_NEXT_COMMAND"},
                ],
            })
        self.assertEqual(str(ctx.exception), "WORK_UNIT_CLOSE_ONLY_ONE_ACCEPTANCE")

    def test_acceptance_must_be_last_before_handoff(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            contract.validate_contract({
                "version": "1.0",
                "steps": [
                    {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                    {"step_id": "ACCEPTANCE", "op": "RUN_ACCEPTANCE_COMMAND", "gate": "WORK_UNIT_CLOSE"},
                    {"step_id": "EXTRA", "op": "CHECK_OUTPUTS"},
                    {"step_id": "HANDOFF", "op": "EMIT_NEXT_COMMAND"},
                ],
            })
        self.assertEqual(str(ctx.exception), "ACCEPTANCE_MUST_BE_LAST_WORK_UNIT_OPERATION")

    def test_acceptance_without_close_gate_is_blocked(self) -> None:
        with self.assertRaises(Exception):
            contract.validate_contract({
                "version": "1.0",
                "steps": [
                    {"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"},
                    {"step_id": "ACCEPTANCE", "op": "RUN_ACCEPTANCE_COMMAND"},
                    {"step_id": "HANDOFF", "op": "EMIT_NEXT_COMMAND"},
                ],
            })

    def test_close_ready_guard_blocks_non_final_work_unit(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "P1-CURRENT.json").write_text(json.dumps({
                "current_stage": {"id": "TEST", "work_unit_id": "TEST"},
                "implementation_control": {"active_work_packet": "work.json"},
            }), encoding="utf-8")
            (root / "work.json").write_text(json.dumps({
                "work_unit": "TEST",
                "status": "IMPLEMENTATION_IN_PROGRESS",
                "acceptance": {"mode": "SIMULATION_ONLY"},
                "handoff": {"gate": "WORK_UNIT_CLOSE_ACCEPTANCE_ONLY"},
            }), encoding="utf-8")
            with self.assertRaises(ValueError) as ctx:
                contract.require_work_unit_close_ready(root)
        self.assertEqual(str(ctx.exception), "WORK_UNIT_NOT_READY_FOR_CLOSE_ACCEPTANCE")

    def test_close_ready_guard_blocks_already_verified_work_unit(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "P1-CURRENT.json").write_text(json.dumps({
                "current_stage": {
                    "id": "TEST",
                    "work_unit_id": "TEST",
                    "status": "VERIFIED",
                    "validated_control_gate_run": None,
                    "validated_head_sha": "fedcba7654321",
                },
                "implementation_control": {
                    "active_work_packet": "work.json",
                },
            }), encoding="utf-8")
            (root / "work.json").write_text(json.dumps({
                "work_unit": "TEST",
                "status": "VERIFIED",
                "acceptance": {"mode": "SIMULATION_ONLY"},
                "handoff": {"gate": "WORK_UNIT_CLOSE_ACCEPTANCE_ONLY"},
            }), encoding="utf-8")
            with self.assertRaises(ValueError) as ctx:
                contract.require_work_unit_close_ready(root)
        self.assertEqual(str(ctx.exception), "WORK_UNIT_ALREADY_ACCEPTED")

    def test_arbitrary_acceptance_command_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(root)
            packet["acceptance"] = {
                "command": ["python3", "-c", "open('escaped.txt', 'w').write('bad')"]
            }
            result = contract.execute(root, packet)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["step_results"][-1]["error"], "ARBITRARY_ACCEPTANCE_COMMAND_BLOCKED")
        self.assertFalse((root / "escaped.txt").exists())

    def test_c01_close_profile_covers_all_implementation_steps(self) -> None:
        simulation = contract.SIMULATION_PROFILES["M32-C01-CLOSE"]
        self.assertEqual(
            simulation["cases"],
            [
                "A_command_trust_boundary",
                "B_thin_continuation",
                "C_failure_replay",
                "D_crash_recovery",
                "E_current_truth_reconciliation",
                "F_ci_actions_security",
                "simulation_boundary_preserved",
                "runtime_truth_remains_observed_only",
            ],
        )

    def test_fixed_acceptance_profile_is_simulated(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = contract.execute(root, self.make_packet(root))
        self.assertEqual(result["status"], "PASS")
        acceptance = result["step_results"][1]["output"]
        self.assertEqual(acceptance["mode"], "SIMULATION_ONLY")
        self.assertTrue(acceptance["simulated"])
        self.assertEqual(acceptance["returncode"], 0)

    def test_simulation_is_not_selected_by_completion_reason(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            result = contract.execute(root, self.make_packet(root))
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(
            [step["status"] for step in result["step_results"]],
            ["PASS", "PASS", "PASS"],
        )
        acceptance = result["step_results"][1]["output"]
        self.assertEqual(acceptance["mode"], "SIMULATION_ONLY")

    def test_missing_next_command_is_runtime_failure(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            packet = self.make_packet(root)
            packet.pop("next_command")
            result = contract.execute(root, packet)
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["step_results"][-1]["status"], "FAIL")
        self.assertIn("next_command", result["step_results"][-1]["error"])


    # --- Output / security boundary invariants (re-covered in current form; M32 decision 2026-10-06).
    # They drive the real contract.execute() CHECK_OUTPUTS step only: no workflow carrier,
    # no legacy next_command path, no progress_gate dependency.

    @staticmethod
    def _outputs_only_packet(outputs) -> dict:
        return {
            "work_id": "TEST-OUTPUT-BOUNDARY",
            "phase": "TEST",
            "outputs": outputs,
            "execution_contract": {
                "version": "1.0",
                "steps": [{"step_id": "OUTPUTS", "op": "CHECK_OUTPUTS"}],
            },
        }

    def test_outputs_empty_is_blocked(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            result = contract.execute(Path(temp), self._outputs_only_packet([]))
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["step_results"][-1]["op"], "CHECK_OUTPUTS")
        self.assertEqual(result["step_results"][-1]["error"], "OUTPUTS_EMPTY")

    def test_unchanged_output_is_blocked_and_changed_output_passes(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            target = root / "artifact.txt"
            target.write_text("before\n", encoding="utf-8")
            before = contract.sha256_file(target)

            unchanged = contract.execute(
                root, self._outputs_only_packet([{"path": "artifact.txt", "before_sha256": before}])
            )
            self.assertEqual(unchanged["status"], "BLOCK")
            self.assertEqual(unchanged["step_results"][-1]["error"], "OUTPUT_UNCHANGED:artifact.txt")

            target.write_text("after\n", encoding="utf-8")
            changed = contract.execute(
                root, self._outputs_only_packet([{"path": "artifact.txt", "before_sha256": before}])
            )
            self.assertEqual(changed["status"], "PASS")
            measured = changed["step_results"][-1]["output"]["outputs"][0]
            self.assertEqual(measured["sha256"], contract.sha256_file(target))
            self.assertNotEqual(measured["sha256"], before)

    def test_output_path_traversal_is_blocked_without_touching_outside(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            outer = Path(temp)
            root = outer / "workspace"
            root.mkdir()
            (outer / "escaped.txt").write_text("outside\n", encoding="utf-8")
            result = contract.execute(root, self._outputs_only_packet([{"path": "../escaped.txt"}]))
            self.assertEqual(result["status"], "BLOCK")
            self.assertEqual(result["step_results"][-1]["error"], "OUTPUT_PATH_TRAVERSAL_BLOCKED")
            self.assertEqual((outer / "escaped.txt").read_text(encoding="utf-8"), "outside\n")


if __name__ == "__main__":
    unittest.main()
