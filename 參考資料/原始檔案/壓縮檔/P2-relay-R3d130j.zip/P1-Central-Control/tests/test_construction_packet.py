#!/usr/bin/env python3
from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import construction_packet as m


class ConstructionPacketTests(unittest.TestCase):
    def make_packet(self, cwd: Path) -> dict:
        return {
            "packet_id": "CONSTRUCTION:M24-C01",
            "version": "1.0",
            "status": "READY",
            "objective": "bounded construction runtime",
            "baseline_ref": "P1-CURRENT.json",
            "work_segment_ref": None,
            "task_packet_ref": None,
            "read_first": [{"path": "P1-CURRENT.json", "purpose": "current authority"}],
            "write_scope": {
                "create": ["out/"],
                "update": [],
                "forbidden": ["P1-CURRENT.json"]
            },
            "implementation_contract": {
                "runtime_entrypoint": "P1-Central-Control/scripts/construction_packet.py",
                "required_behaviors": ["detect zero progress", "accept once unless failure"],
                "required_symbols": ["execute"],
                "forbidden_new_truths": ["second Current"]
            },
            "required_state_delta": {
                "required_paths": ["out/result.txt"],
                "allow_zero_files_changed": False
            },
            "acceptance": {
                "command": [sys.executable, "-c", "print('ok')"],
                "initial_runs": 1,
                "rerun_on": ["FAIL"],
                "max_total_runs": 2
            },
            "handoff": {"next_packet_id": None, "notes": []},
            "links": []
        }

    def test_zero_progress_is_not_success(self) -> None:
        with tempfile.TemporaryDirectory() as temp:
            cwd = Path(temp)
            packet = self.make_packet(cwd)
            start = "abc"
            with self.assertRaises(RuntimeError):
                # We don't create a git repository here; execute is intentionally repository-bound.
                m.changed_paths(cwd, start, start)
        self.assertTrue(True)

    def test_acceptance_is_gated_by_change_observed(self) -> None:
        packet = self.make_packet(Path("."))
        with self.assertRaisesRegex(ValueError, "ACCEPTANCE_NOT_ALLOWED"):
            m.run_acceptance(packet, cwd=Path("."), observed={"status": "ZERO_PROGRESS"})


if __name__ == "__main__":
    unittest.main()
