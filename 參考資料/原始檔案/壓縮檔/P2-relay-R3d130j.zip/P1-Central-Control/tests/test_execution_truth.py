#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TESTS_DIR = ROOT / "P1-Central-Control" / "tests"
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))
sys.path.insert(0, str(TESTS_DIR))

import central_controller  # noqa: E402
from execution_truth import (  # noqa: E402
    bind_attempt_result,
    build_execution_record,
    cancel_execution,
    classify_late_result,
    finalize_execution,
    timeout_execution,
    validate_execution_record,
)
from event_log import EventLog  # noqa: E402
from packet_layer import build_attempt, build_result_packet, build_task_packet  # noqa: E402
from p7_test_records import records_for  # noqa: E402


class ExecutionTruthTests(unittest.TestCase):
    def make_segment(self) -> dict:
        return {
            "segment_id": "SEG-P6-001",
            "workflow_id": "WF-P6",
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "建立可驗證 Execution Truth",
            "input_scope": "p6-test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "EXECUTION:exec-att-SEG-P6-001-1",
            "context_cohort_id": "COHORT-P6",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {
                "max_attempts": 2,
                "retry_on": ["FAIL", "TIMEOUT"],
            },
            "timeout_ms": 1000,
        }

    def make_packets(self):
        segment = self.make_segment()
        attempt = build_attempt(
            segment,
            attempt_number=1,
            started_at="2026-10-03T10:00:00+00:00",
        )
        task = build_task_packet(segment, attempt)
        return segment, attempt, task

    def make_success(self, task: dict) -> dict:
        return build_result_packet(
            task,
            {
                "decision_code": "WORK_COMPLETE",
                "output_refs": ["ARTIFACT:result-001"],
                "evidence_refs": ["EVIDENCE:exec-001"],
                "provenance_refs": ["PROVENANCE:exec-001"],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 2,
                    "wall_time_ms": 25,
                },
                "usage_observed": True,
            },
        )

    def test_execution_record_binds_identity_and_input_hash(self):
        _, attempt, task = self.make_packets()
        execution = build_execution_record(
            task,
            started_at=attempt["started_at"],
        )

        self.assertEqual(execution["attempt_id"], attempt["attempt_id"])
        self.assertEqual(
            execution["execution_record_ref"],
            attempt["execution_record_ref"],
        )
        self.assertTrue(execution["input_hash"].startswith("sha256:"))
        self.assertEqual(execution["status"], "RUNNING")
        validate_execution_record(execution)

    def test_success_requires_observed_usage_evidence_provenance_and_output(self):
        _, attempt, task = self.make_packets()
        execution = build_execution_record(
            task,
            started_at=attempt["started_at"],
        )
        result = self.make_success(task)
        evidence, provenance = records_for(task, result, execution)
        finalized = finalize_execution(
            execution,
            task,
            result,
            ended_at="2026-10-03T10:00:00.025000+00:00",
            evidence_records=evidence,
            provenance_records=provenance,
        )

        self.assertEqual(finalized["status"], "SUCCEEDED")
        self.assertEqual(
            finalized["verification_result"]["status"],
            "PASSED",
        )
        self.assertTrue(finalized["output_hash"].startswith("sha256:"))
        self.assertEqual(
            finalized["observed_usage"]["wall_time_ms"],
            25,
        )

        bound = bind_attempt_result(attempt, result, finalized)
        self.assertEqual(bound["status"], "SUCCESS")
        self.assertEqual(bound["result_packet_ref"], result["object_id"])

    def test_success_without_real_observation_is_rejected(self):
        _, attempt, task = self.make_packets()
        execution = build_execution_record(
            task,
            started_at=attempt["started_at"],
        )
        result = build_result_packet(
            task,
            {
                "decision_code": "WORK_COMPLETE",
                "output_refs": ["ARTIFACT:result-001"],
                "evidence_refs": ["EVIDENCE:exec-001"],
                "provenance_refs": ["PROVENANCE:exec-001"],
                "observed_usage": {
                    "model_calls": 0,
                    "tool_calls": 0,
                    "wall_time_ms": 0,
                },
                "usage_observed": False,
            },
        )

        with self.assertRaises(ValueError):
            finalize_execution(execution, task, result)

    def test_result_from_another_execution_is_rejected(self):
        _, attempt, task = self.make_packets()
        execution = build_execution_record(task, started_at=attempt["started_at"])
        result = self.make_success(task)
        result["execution_record_ref"] = "EXECUTION:exec-other"

        with self.assertRaises(ValueError):
            finalize_execution(execution, task, result)

    def test_timeout_and_cancel_are_real_terminal_execution_states(self):
        _, attempt, task = self.make_packets()

        timeout_record = timeout_execution(
            build_execution_record(task, started_at=attempt["started_at"]),
            ended_at="2026-10-03T10:00:01+00:00",
        )
        self.assertEqual(timeout_record["status"], "TIMEOUT")
        self.assertIsNotNone(timeout_record["end_time"])

        cancel_record = cancel_execution(
            build_execution_record(task, started_at=attempt["started_at"]),
            ended_at="2026-10-03T10:00:02+00:00",
        )
        self.assertEqual(cancel_record["status"], "CANCELLED")
        self.assertIsNotNone(cancel_record["end_time"])

    def test_central_requires_external_execution_truth_for_result_acceptance(self):
        segment = self.make_segment()
        state = central_controller.init_state("WF-P6", "TASK-P6")
        state = central_controller.queue_segment(state, segment)

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            store = {}
            distillation_store = {}
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=store,
                max_concurrency=1,
            )
            result = self.make_success(packets[0])

            self.assertIn(result["execution_record_ref"], store)
            evidence, provenance = records_for(
                store[result["execution_record_ref"]]["task_packet"],
                result,
                store[result["execution_record_ref"]]["execution_record"],
            )
            state = central_controller.receive_result(
                state,
                result,
                event_log=log,
                execution_store=store,
                distillation_store=distillation_store,
                segment_store={segment["segment_id"]: segment},
                evidence_records=evidence,
                provenance_records=provenance,
            )

        envelope = store[result["execution_record_ref"]]
        self.assertEqual(
            envelope["execution_record"]["status"],
            "SUCCEEDED",
        )
        self.assertEqual(
            envelope["attempt"]["status"],
            "SUCCESS",
        )
        self.assertEqual(state["status"], "COMPLETED")

    def test_central_duplicate_result_routes_as_late_without_refinalization(self):
        segment = self.make_segment()
        state = central_controller.init_state("WF-P6", "TASK-P6")
        state = central_controller.queue_segment(state, segment)

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            execution_store = {}
            distillation_store = {}
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
                max_concurrency=1,
            )
            result = self.make_success(packets[0])
            envelope = execution_store[result["execution_record_ref"]]
            evidence, provenance = records_for(
                envelope["task_packet"], result, envelope["execution_record"]
            )

            state = central_controller.receive_result(
                state,
                result,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                segment_store={segment["segment_id"]: segment},
                evidence_records=evidence,
                provenance_records=provenance,
            )
            self.assertEqual(state["status"], "COMPLETED")
            self.assertEqual(
                execution_store[result["execution_record_ref"]]["execution_record"]["status"],
                "SUCCEEDED",
            )

            replayed_state = central_controller.receive_result(
                state,
                result,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                segment_store={segment["segment_id"]: segment},
                evidence_records=evidence,
                provenance_records=provenance,
            )

        self.assertEqual(replayed_state["status"], "COMPLETED")
        self.assertEqual(replayed_state["late_result_count"], 1)
        self.assertEqual(
            execution_store[result["execution_record_ref"]]["execution_record"]["status"],
            "SUCCEEDED",
        )

    # --- Late / duplicate result vs. Execution Truth (M32 decision 2026-10-06) ----------------
    # A closed execution is never re-finalized and a terminal workflow is never reopened, but a
    # result that arrives afterwards must still be reconciled with the recorded Execution Truth.

    def make_fail(self, task: dict) -> dict:
        return build_result_packet(
            task,
            {
                "decision_code": "FAIL",
                "output_refs": [],
                "evidence_refs": [],
                "provenance_refs": [],
                "unresolved": ["late-conflict"],
                "observed_usage": {"model_calls": 1, "tool_calls": 1, "wall_time_ms": 5},
                "usage_observed": True,
            },
        )

    def finalized_envelope(self):
        _, attempt, task = self.make_packets()
        execution = build_execution_record(task, started_at=attempt["started_at"])
        result = self.make_success(task)
        evidence, provenance = records_for(task, result, execution)
        done = finalize_execution(
            execution, task, result,
            evidence_records=evidence, provenance_records=provenance,
        )
        return task, bind_attempt_result(attempt, result, done), done, result

    def test_classify_identical_replay_is_duplicate(self):
        task, attempt, done, result = self.finalized_envelope()
        self.assertEqual(classify_late_result(done, attempt, task, result), "DUPLICATE")

    def test_classify_conflicting_result_for_closed_execution_is_rejected(self):
        task, attempt, done, _ = self.finalized_envelope()
        with self.assertRaisesRegex(ValueError, "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:DECISION_CODE"):
            classify_late_result(done, attempt, task, self.make_fail(task))

    def test_classify_result_bound_to_a_different_packet_is_rejected(self):
        task, attempt, done, result = self.finalized_envelope()
        other = dict(result)
        other["object_id"] = result["object_id"] + "-other"
        with self.assertRaisesRegex(ValueError, "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:RESULT_REF"):
            classify_late_result(done, attempt, task, other)

    def test_classify_same_ref_but_divergent_content_is_rejected(self):
        task, attempt, done, result = self.finalized_envelope()
        tampered = dict(result)
        tampered["output_refs"] = ["ARTIFACT:other"]
        with self.assertRaisesRegex(ValueError, "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH:OUTPUT_HASH"):
            classify_late_result(done, attempt, task, tampered)

    def test_classify_result_after_timeout_is_late_and_does_not_reopen(self):
        _, attempt, task = self.make_packets()
        timed_out = timeout_execution(build_execution_record(task, started_at=attempt["started_at"]))
        self.assertEqual(
            classify_late_result(timed_out, attempt, task, self.make_success(task)),
            "LATE_AFTER_NO_RESULT",
        )
        self.assertEqual(timed_out["status"], "TIMEOUT")

    def _terminal_workflow(self, temp):
        segment = self.make_segment()
        state = central_controller.init_state("WF-P6", "TASK-P6")
        state = central_controller.queue_segment(state, segment)
        log = EventLog(Path(temp) / "events.jsonl")
        execution_store, distillation_store = {}, {}
        state, packets = central_controller.dispatch(
            state, event_log=log, execution_store=execution_store, max_concurrency=1,
        )
        result = self.make_success(packets[0])
        envelope = execution_store[result["execution_record_ref"]]
        evidence, provenance = records_for(envelope["task_packet"], result, envelope["execution_record"])
        kwargs = dict(
            event_log=log, execution_store=execution_store, distillation_store=distillation_store,
            segment_store={segment["segment_id"]: segment},
        )
        state = central_controller.receive_result(
            state, result, evidence_records=evidence, provenance_records=provenance, **kwargs,
        )
        self.assertEqual(state["status"], "COMPLETED")
        return state, result, packets[0], execution_store, distillation_store, evidence, provenance, kwargs

    def test_terminal_workflow_duplicate_only_adds_late_bookkeeping(self):
        from copy import deepcopy
        with tempfile.TemporaryDirectory() as temp:
            state, result, _task, store, dstore, ev, pv, kw = self._terminal_workflow(temp)
            truth_before = deepcopy(store)
            replayed = central_controller.receive_result(
                deepcopy(state), result, evidence_records=ev, provenance_records=pv, **kw,
            )
        self.assertEqual(store, truth_before)  # Execution Truth untouched, not re-finalized
        for key in ("status", "result_refs", "completed_segments", "evidence_refs",
                    "provenance_refs", "unresolved", "active_segments", "queued_segments"):
            self.assertEqual(replayed[key], state[key], key)
        self.assertEqual(replayed["late_result_count"], state.get("late_result_count", 0) + 1)

    def test_terminal_workflow_conflicting_result_is_rejected_without_side_effects(self):
        from copy import deepcopy
        with tempfile.TemporaryDirectory() as temp:
            state, _result, task, store, dstore, ev, pv, kw = self._terminal_workflow(temp)
            conflicting = self.make_fail(task)
            state_before, truth_before, dstore_before = deepcopy(state), deepcopy(store), deepcopy(dstore)
            with self.assertRaisesRegex(ValueError, "LATE_RESULT_CONFLICTS_WITH_EXECUTION_TRUTH"):
                central_controller.receive_result(
                    deepcopy(state), conflicting, evidence_records=[], provenance_records=[], **kw,
                )
        self.assertEqual(state, state_before)
        self.assertEqual(store, truth_before)
        self.assertEqual(dstore, dstore_before)  # no distillation of a result that contradicts truth
        self.assertEqual(state.get("late_result_count", 0), state_before.get("late_result_count", 0))

    def test_central_rejects_result_without_execution_store(self):
        segment = self.make_segment()
        state = central_controller.init_state("WF-P6", "TASK-P6")
        state = central_controller.queue_segment(state, segment)

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            with self.assertRaises(ValueError):
                central_controller.dispatch(
                    state,
                    event_log=log,
                    max_concurrency=1,
                )


if __name__ == "__main__":
    unittest.main()
