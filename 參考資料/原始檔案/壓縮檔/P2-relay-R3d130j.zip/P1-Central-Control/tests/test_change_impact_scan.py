#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import tempfile
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker


ROOT = Path(__file__).resolve().parents[2]
SCHEMA_DIR = ROOT / "P1-Central-Control/schemas"
SCRIPT = ROOT / "P1-Central-Control/scripts/change_impact_scan.py"
FIXTURE_PATH = ROOT / "P1-Central-Control/fixtures/m1-change-events.json"


class ChangeImpactScanTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.registry = json.loads(
            (ROOT / "P1-Central-Control/change_impact_registry.json").read_text(encoding="utf-8")
        )
        cls.fixtures = json.loads(FIXTURE_PATH.read_text(encoding="utf-8"))

    def _run_importable(self):
        import sys

        sys.path.insert(0, str(SCRIPT.parent))
        import change_impact_scan

        return change_impact_scan

    def test_m1_schemas_are_valid_and_bounded(self) -> None:
        for filename in ("change_event.schema.json", "impact_scan.schema.json"):
            path = SCHEMA_DIR / filename
            schema = json.loads(path.read_text(encoding="utf-8"))
            Draft202012Validator.check_schema(schema)
            self.assertLessEqual(path.stat().st_size, 8192)

    def test_known_runtime_change_resolves_impact(self) -> None:
        mod = self._run_importable()
        result = mod.run(**self.fixtures["known_runtime"])
        event = result["change_event"]
        scan = result["impact_scan"]

        self.assertEqual(event["change_type"], "RUNTIME")
        self.assertEqual(scan["status"], "PASS")
        self.assertEqual(scan["decision"], "PROCEED")
        self.assertEqual(scan["unknown_paths"], [])
        self.assertIn("core-control", scan["required_regression_sets"])
        self.assertIn("e2e", scan["required_regression_sets"])
        self.assertIn("CAP-EXTRACT", scan["affected_capabilities"])

    def test_known_documentation_change_has_no_runtime_impact(self) -> None:
        mod = self._run_importable()
        result = mod.run(**self.fixtures["known_docs"])
        scan = result["impact_scan"]

        self.assertEqual(scan["status"], "PASS")
        self.assertEqual(scan["affected_capabilities"], [])
        self.assertEqual(scan["required_regression_sets"], [])

    def test_unknown_change_blocks_instead_of_guessing(self) -> None:
        mod = self._run_importable()
        result = mod.run(**self.fixtures["unknown_path"])
        scan = result["impact_scan"]

        self.assertEqual(scan["status"], "BLOCK")
        self.assertEqual(scan["decision"], "BLOCK")
        self.assertEqual(scan["unknown_paths"], ["experimental/new_runtime/unknown.py"])
        self.assertIn("IMPACT_UNRESOLVED_PATH", scan["reason_codes"])

    def test_mixed_known_and_unknown_change_still_blocks(self) -> None:
        mod = self._run_importable()
        result = mod.run(**self.fixtures["mixed_known_unknown"])
        scan = result["impact_scan"]

        self.assertEqual(scan["status"], "BLOCK")
        self.assertEqual(scan["decision"], "BLOCK")
        self.assertEqual(scan["unknown_paths"], ["experimental/new_runtime/unknown.py"])
        self.assertIn("CAP-EXTRACT", scan["affected_capabilities"])

    def test_change_ids_are_deterministic(self) -> None:
        mod = self._run_importable()
        a = mod.run(**self.fixtures["known_runtime"])
        b = mod.run(**self.fixtures["known_runtime"])
        self.assertEqual(a["change_event"]["change_id"], b["change_event"]["change_id"])
        self.assertEqual(a["impact_scan"]["scan_id"], b["impact_scan"]["scan_id"])

    def test_real_git_diff_entrypoint(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.email", "p1@test.invalid"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.name", "P1 Test"], cwd=root, check=True)

            target = root / "README.md"
            target.write_text("v1\n", encoding="utf-8")
            unicode_target = root / "A1-S01" / "執行" / "system_runner.py"
            unicode_target.parent.mkdir(parents=True)
            unicode_target.write_text("v1\n", encoding="utf-8")
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-qm", "base"], cwd=root, check=True)
            base = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=root, text=True
            ).strip()

            target.write_text("v2\n", encoding="utf-8")
            unicode_target.write_text("v2\n", encoding="utf-8")
            subprocess.run(["git", "add", "."], cwd=root, check=True)
            subprocess.run(["git", "commit", "-qm", "change"], cwd=root, check=True)
            head = subprocess.check_output(
                ["git", "rev-parse", "HEAD"], cwd=root, text=True
            ).strip()

            mod = self._run_importable()
            original_root = mod.ROOT
            original_registry = mod.REGISTRY_PATH
            original_capabilities = mod.CAPABILITY_REGISTRY_PATH
            try:
                mod.ROOT = root
                mod.REGISTRY_PATH = root / "change_impact_registry.json"
                mod.CAPABILITY_REGISTRY_PATH = root / "capability_registry.json"
                (root / "change_impact_registry.json").write_text(
                    (ROOT / "P1-Central-Control/change_impact_registry.json").read_text(encoding="utf-8"),
                    encoding="utf-8",
                )
                (root / "capability_registry.json").write_text(
                    (ROOT / "P1-Central-Control/capability_registry.json").read_text(encoding="utf-8"),
                    encoding="utf-8",
                )
                paths = mod.changed_paths_from_git(base, head)
                self.assertEqual(
                    paths,
                    ["A1-S01/執行/system_runner.py", "README.md"],
                )
            finally:
                mod.ROOT = original_root
                mod.REGISTRY_PATH = original_registry
                mod.CAPABILITY_REGISTRY_PATH = original_capabilities


if __name__ == "__main__":
    unittest.main()
