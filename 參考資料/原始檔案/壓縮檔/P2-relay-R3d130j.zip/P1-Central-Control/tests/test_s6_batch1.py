"""S6 batch 1: counterexample_log (CAP-COUNTEREXAMPLE) + hypothesis_guard (CAP-HYPOTHESIS).  SIMULATED_PASS (death = BaseException; searcher is a stub)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

R = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(R / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(R / "tools"))
import capability_run as cr  # noqa: E402
import counterexample_log as cl  # noqa: E402
import hypothesis_guard as hg  # noqa: E402

H = {"id": "H1", "scope_limit": "限 2026 資料", "alternatives": ["巧合"]}
S1, S2 = ["s1", "s2"], ["s3"]


class Died(BaseException):
    pass


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp(prefix="s6-"))
        self.addCleanup(shutil.rmtree, self.d, True)
        self.log, self.store, self.calls = self.d / "log", self.d / "store", []

    def search(self, found=()):
        def f(h, scope):
            self.calls.append(tuple(scope))
            return list(found)
        return f


class Counter(Base):
    def test_found_none_scope_and_hit_rate(self):
        a = cl.record(H, ["s2", "s1"], self.search(["s1"]), self.log)
        b = cl.record(H, S2, self.search(), self.log)
        self.assertEqual((a["status"], a["scope"], a["counterexamples"], b["status"], b["scope"]), ("FOUND", S1, ["s1"], "NONE_IN_SCOPE", S2))
        self.assertEqual(cl.hit_rate(self.log), {"total": 2, "found": 1, "rate": 0.5})

    def test_same_scope_not_repeated(self):
        x = cl.record(H, S1, self.search(), self.log)
        y = cl.record(H, ["s2", "s1"], self.search(), self.log)
        self.assertEqual((len(self.calls), x["ref"] == y["ref"]), (1, True))

    def test_death_then_resume(self):
        def die(h, s):
            raise Died()
        cl.record(H, S1, self.search(), self.log)
        with self.assertRaises(Died):
            cl.record(H, S2, die, self.log)
        cl.record(H, S1, self.search(), self.log)
        r = cl.record(H, S2, self.search(), self.log)
        self.assertEqual((self.calls, r["status"], sorted(p.suffix for p in self.log.iterdir())), ([("s1", "s2"), ("s3",)], "NONE_IN_SCOPE", [".json"] * 2))

    def test_search_unavailable_is_scope_limited(self):
        r = cl.record(H, S1, self.search(), self.log, search_available=False)
        f = cl.record(H, S2, self.search(["s3"]), self.log, search_available=False)
        self.assertEqual((r["status"], f["status"]), ("SCOPE_LIMITED", "FOUND"))

    def test_search_error_is_incomplete_never_none_in_scope(self):
        def boom(h, s):
            raise RuntimeError("down")
        a = cl.record(H, S1, boom, self.log)
        b = cl.record(H, S1, self.search(["zz"]), self.log)  # ref outside the searched scope
        self.assertEqual((a["status"], b["status"], list(self.log.glob("*.json"))), ("INCOMPLETE", "INCOMPLETE", []))

    def test_bad_input_failed_writes_nothing(self):
        for h, s in ((H, []), ("x", S1), (dict(H, id=""), S1), (H, "s1"), (H, [1])):
            self.assertEqual(cl.record(h, s, self.search(), self.log)["status"], "FAILED")
        self.assertFalse(self.log.exists())

    def test_audit_and_lookup(self):
        hs = [{"id": "H1", "level": 2}, {"id": "H2", "level": 2}, {"id": "H3", "level": 0}]
        cl.record(H, S1, self.search(), self.log)
        a = cl.audit(hs, self.log)
        self.assertEqual((a["ok"], a["missing"]), (False, ["H2"]))
        self.assertEqual((cl.lookup("H1", self.d / "none")["status"], cl.lookup("H1", self.log)["status"]), ("MISSING", "OK"))
        next(self.log.glob("*.json")).write_text("{", encoding="utf-8")
        self.assertEqual(cl.lookup("H1", self.log)["status"], "UNREADABLE")


class Hyp(Base):
    def h(self, ref=None, **kw):
        return {"id": "H1", "version": 1, "statement": "s", "scope_limit": "限", "alternatives": ["a"], "counterexample_ref": ref, "level": 2, **kw}

    def ref(self, scope=S1, found=(), hyp=H, **kw):
        return cl.record(hyp, scope, self.search(found), self.log, **kw)["ref"]

    def test_rejected_cases(self):
        r = self.ref()
        for bad in (dict(alternatives=[]), dict(statement=""), dict(version=0), dict(counterexample_ref=None), dict(counterexample_ref="deadbeef0000"), dict(id="../x")):
            self.assertEqual(hg.check(self.h(r, **bad), self.log)["status"], "REJECTED", bad)
        other = self.ref(hyp=dict(H, id="H9"))
        self.assertEqual(hg.check(self.h(other), self.log)["reason"], "COUNTEREXAMPLE_MISMATCH")

    def test_grading(self):
        g = lambda r, **kw: hg.check(self.h(r, **kw), self.log)["status"]  # noqa: E731
        self.assertEqual([g(self.ref()), g(self.ref(S2, search_available=False)), g(None, level=1), g(self.ref(["s7"], ["s7"]))],
                         ["ACCEPTABLE", "PROVISIONAL", "PROVISIONAL", "REJECTED"])
        self.assertEqual(hg.check(self.h(None), self.log, search_error=True)["status"], "PROVISIONAL")

    def test_log_unavailable_is_incomplete(self):
        r = self.ref()
        self.assertEqual(hg.check(self.h(r), self.d / "nolog")["status"], "INCOMPLETE")
        next(self.log.glob("*.json")).write_text("{", encoding="utf-8")
        self.assertEqual(hg.check(self.h(r), self.log)["status"], "INCOMPLETE")
        self.assertEqual((hg.submit(self.h(r), self.log, self.store)["status"], hg.history("H1", self.store)), ("INCOMPLETE", []))

    def test_versions_kept_and_resume_once(self):
        r = self.ref()
        hg.submit(self.h(r), self.log, self.store)
        hg.submit(self.h(r, version=2, statement="修正"), self.log, self.store)
        self.assertEqual(hg.history("H1", self.store), [(1, "ACCEPTABLE"), (2, "ACCEPTABLE")])
        with mock.patch.object(hg.counterexample_log, "resolve", side_effect=AssertionError):
            again = hg.submit(self.h(r), self.log, self.store)  # same id + version: reused, not recomputed
        self.assertEqual((again["status"], again["cached"]), ("ACCEPTABLE", True))
        self.assertEqual(hg.submit(self.h(r, statement="改"), self.log, self.store)["reason"], "VERSION_EXISTS")

    def test_death_while_saving_then_rerun(self):
        r = self.ref()
        with mock.patch.object(hg, "atomic_write", side_effect=Died):
            with self.assertRaises(Died):
                hg.submit(self.h(r), self.log, self.store)
        self.assertEqual(hg.history("H1", self.store), [])
        self.assertEqual(hg.submit(self.h(r), self.log, self.store)["status"], "ACCEPTABLE")


class Measured(unittest.TestCase):
    def test_measured_and_mutation_caught(self):
        for cap, prov, runner in (("CAP-COUNTEREXAMPLE", "counterexample_log", "counterexample"), ("CAP-HYPOTHESIS", "hypothesis_guard", "hypothesis")):
            self.assertEqual(cr.check(cap), {"capability": cap, "ok": True, "runner_ok": True, "providers_missing": []})
            self.assertEqual(cr.check(cap, {runner: lambda: True})["providers_missing"], [prov])
        for mod, name, fake in ((cl, "_check_refs", lambda refs, ids: True), (hg, "_needs_record", lambda level: False)):
            with mock.patch.object(mod, name, fake):
                try:
                    caught = not cr.check("CAP-COUNTEREXAMPLE" if mod is cl else "CAP-HYPOTHESIS")["runner_ok"]
                except Exception:
                    caught = True
            self.assertTrue(caught, name)


if __name__ == "__main__":
    unittest.main()
