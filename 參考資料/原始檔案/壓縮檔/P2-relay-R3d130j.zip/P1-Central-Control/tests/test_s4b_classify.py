"""S4b batch 2: classify_guard (CAP-CLASSIFY).  SIMULATED_PASS (death = BaseException mid-run; the model is always a stub)."""
import copy
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))
import capability_run as cr  # noqa: E402
import classify_guard as cg  # noqa: E402

TABLE = {"version": "v1", "categories": ["人物", "地點", "事件"]}
LOC = {"start": 0, "end": 3}
ITEMS = [{"item_id": f"i{n}", "text": f"t{n}"} for n in (1, 2, 3)]


def ans(cat="人物", conf=0.9, loc=LOC):
    return {"category": cat, "confidence": conf, "locator": loc}


class Died(BaseException):
    pass


class Base(unittest.TestCase):
    def setUp(self):
        self.d = Path(tempfile.mkdtemp(prefix="s4b-"))
        self.addCleanup(shutil.rmtree, self.d, True)
        self.calls = []

    def model(self, fn):
        def m(item, table, attempt):
            self.calls.append((item["item_id"], attempt))
            return fn(item, table, attempt)
        return m

    def run_(self, fn, items=ITEMS, table=TABLE, **kw):
        return cg.classify_items(items, table, self.model(fn), self.d, **kw)


class Guard(Base):
    def test_all_classified_ok_and_files_written(self):
        r = self.run_(lambda i, t, a: ans())
        self.assertEqual((r["status"], r["unclassified"], r["missing"]), ("OK", [], []))
        self.assertEqual(r["results"]["i1"]["category"], "人物")
        self.assertEqual(len(list(self.d.glob("*.json"))) >= 3, True)

    def test_not_in_table_rejected_after_two_retries(self):
        r = self.run_(lambda i, t, a: ans("怪物"), items=ITEMS[:1])
        self.assertEqual(self.calls, [("i1", 0), ("i1", 1), ("i1", 2)])
        rec = r["results"]["i1"]
        self.assertEqual((r["status"], rec["status"], rec["reason"], rec["category"]), ("PARTIAL", "UNCLASSIFIED", "NOT_IN_TABLE", None))

    def test_retry_can_recover(self):
        r = self.run_(lambda i, t, a: ans("怪物") if a == 0 else ans("地點"), items=ITEMS[:1])
        self.assertEqual((r["status"], r["results"]["i1"]["category"], len(self.calls)), ("OK", "地點", 2))

    def test_low_confidence_is_unclassified_not_forced(self):
        r = self.run_(lambda i, t, a: ans(conf=0.2), items=ITEMS[:1])
        rec = r["results"]["i1"]
        self.assertEqual((rec["status"], rec["reason"], rec["category"], len(self.calls)), ("UNCLASSIFIED", "LOW_CONFIDENCE", None, 1))

    def test_invalid_confidence_or_locator_retried_then_unclassified(self):
        for bad in (ans(conf=True), ans(conf=float("nan")), ans(conf="0.9"), ans(conf=1.5), ans(loc={}), ans(loc=None)):
            self.calls.clear()
            shutil.rmtree(self.d)
            self.d.mkdir()
            r = self.run_(lambda i, t, a, b=bad: b, items=ITEMS[:1])
            self.assertEqual((r["results"]["i1"]["reason"], len(self.calls)), ("INVALID_ANSWER", 3), repr(bad))

    def test_new_category_goes_to_proposals_only(self):
        before = copy.deepcopy(TABLE)
        r = self.run_(lambda i, t, a: {"category": None, "propose": "神獸", "confidence": 0.8, "locator": LOC}, items=ITEMS[:1])
        prop = json.loads((self.d / "_proposals.json").read_text(encoding="utf-8"))
        self.assertEqual((prop[0]["name"], prop[0]["status"]), ("神獸", "PENDING_REVIEW"))
        self.assertEqual((r["results"]["i1"]["reason"], TABLE), ("PROPOSED_NEW_CATEGORY", before))

    def test_model_mutating_table_is_refused(self):
        before = copy.deepcopy(TABLE)

        def evil(i, t, a):
            t["categories"].append("偷加")
            return ans("偷加")
        r = self.run_(evil, items=ITEMS[:1])
        self.assertEqual((r["status"], r["reason"], TABLE), ("INCOMPLETE", "TABLE_MUTATED", before))
        self.assertEqual(list(self.d.glob("*.json")), [])

    def test_bad_inputs_fail_closed_writing_nothing(self):
        for table in ({"categories": ["a"]}, {"version": "v", "categories": []}, {"version": "v", "categories": [1]}):
            self.assertEqual(self.run_(lambda i, t, a: ans(), table=table)["status"], "FAILED")
        self.assertEqual(self.run_(lambda i, t, a: ans(), items=[{"text": "x"}])["status"], "FAILED")
        self.assertEqual(list(self.d.iterdir()), [])
        self.assertEqual(self.calls, [])


class Interrupt(Base):
    def test_death_midrun_resume_skips_done(self):
        def die_on_2(i, t, a):
            if i["item_id"] == "i2":
                raise Died
            return ans()
        with self.assertRaises(Died):
            self.run_(die_on_2)
        self.calls.clear()
        r = self.run_(lambda i, t, a: ans("事件"))
        self.assertEqual([c[0] for c in self.calls], ["i2", "i3"])  # i1 kept, not redone
        self.assertEqual((r["status"], r["results"]["i1"]["category"], r["results"]["i2"]["category"]), ("OK", "人物", "事件"))

    def test_model_failure_incomplete_keeps_finished(self):
        def boom(i, t, a):
            if i["item_id"] == "i2":
                raise RuntimeError("down")
            return ans()
        r = self.run_(boom)
        self.assertEqual((r["status"], r["missing"], sorted(r["results"])), ("INCOMPLETE", ["i2", "i3"], ["i1"]))
        self.calls.clear()
        r2 = self.run_(lambda i, t, a: ans())
        self.assertEqual(([c[0] for c in self.calls], r2["status"]), (["i2", "i3"], "OK"))

    def test_table_version_change_marks_stale_and_reclassifies(self):
        self.run_(lambda i, t, a: ans())
        v2 = {"version": "v2", "categories": ["人物", "地點"]}
        stale = cg.mark_stale(self.d, "v2")
        self.assertEqual(sorted(stale), ["i1", "i2", "i3"])
        self.assertEqual(cg.mark_stale(self.d, "v2"), [])  # already marked, idempotent
        self.calls.clear()
        r = self.run_(lambda i, t, a: ans("地點"), table=v2)
        self.assertEqual((len(self.calls), r["results"]["i1"]["table_version"], r["status"]), (3, "v2", "OK"))


class Feedback(Base):
    def test_ratio_in_summary_and_f09_hint(self):
        r = self.run_(lambda i, t, a: ans(conf=0.1) if i["item_id"] != "i1" else ans())
        s = json.loads((self.d / "_summary.json").read_text(encoding="utf-8"))
        self.assertAlmostEqual(s["unclassified_ratio"], 2 / 3)
        self.assertEqual((r["f09_hint"], s["f09_hint"]), (True, True))


class Measured(unittest.TestCase):
    def test_measured_and_mutations_caught(self):
        self.assertEqual(cr.check("CAP-CLASSIFY"), {"capability": "CAP-CLASSIFY", "ok": True, "runner_ok": True, "providers_missing": []})
        self.assertEqual(cr.check("CAP-CLASSIFY", {"classify": lambda: True})["providers_missing"], ["classify_guard"])
        orig = cg._valid_answer
        cg._valid_answer = lambda a, t, th: (True, "")  # guard removed -> an out-of-table category would pass
        try:
            try:
                caught = not cr.check("CAP-CLASSIFY")["runner_ok"]
            except Exception:
                caught = True
        finally:
            cg._valid_answer = orig
        self.assertTrue(caught)


if __name__ == "__main__":
    unittest.main()
