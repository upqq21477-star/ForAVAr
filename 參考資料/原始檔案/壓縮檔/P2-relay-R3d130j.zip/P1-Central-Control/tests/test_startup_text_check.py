import json
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import startup_text_check as stc  # noqa: E402


class StartupTextTests(unittest.TestCase):
    def setUp(self):
        self.skill = stc.SKILL.read_text(encoding="utf-8")
        self.iface = stc.IFACE.read_text(encoding="utf-8")
        self.slots = json.loads(stc.SLOTS.read_text(encoding="utf-8"))

    def test_current_text_passes(self):
        self.assertEqual(stc.check(self.skill, self.iface, self.slots), [])

    def test_mutation_removing_each_required_skill_phrase_is_caught(self):
        for code, phrase in stc.SKILL_REQUIRED.items():
            self.assertIn(code, stc.check(self.skill.replace(phrase, "x"), self.iface, self.slots), code)

    def test_mutation_old_read_everything_list_is_caught(self):
        for code, phrase in stc.SKILL_FORBIDDEN.items():
            self.assertIn(code, stc.check(self.skill + "\n" + phrase, self.iface, self.slots), code)
        for code, phrase in stc.IFACE_FORBIDDEN.items():
            self.assertIn(code, stc.check(self.skill, self.iface + "\n" + phrase, self.slots), code)

    def test_mutation_interface_and_slots(self):
        for code, phrase in stc.IFACE_REQUIRED.items():
            self.assertIn(code, stc.check(self.skill, self.iface.replace(phrase, "x"), self.slots), code)
        bad = dict(self.slots); bad.pop("former_startup_list")
        self.assertIn("SLOTS_NO_FORMER_STARTUP_LIST", stc.check(self.skill, self.iface, bad))
        bad2 = json.loads(json.dumps(self.slots)); bad2["former_startup_list"]["paths"].append("nope/x.md")
        self.assertIn("SLOTS_FORMER_PATH_MISSING:nope/x.md", stc.check(self.skill, self.iface, bad2))


class WiredIntoPrecheckTests(unittest.TestCase):
    def test_startup_budget_reports_text_errors_on_a_mutated_root(self):
        import shutil
        import tempfile
        sys.path.insert(0, str(stc.ROOT / "tools"))
        import startup_budget as sb
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            for src in (stc.SKILL, stc.IFACE, stc.SLOTS):
                dst = root / src.relative_to(stc.ROOT)
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(src, dst)
            for rel in json.loads(stc.SLOTS.read_text(encoding="utf-8"))["former_startup_list"]["paths"]:
                stub = root / rel
                stub.parent.mkdir(parents=True, exist_ok=True)
                stub.touch()
            self.assertEqual(sb.text_errors(root), [])
            sk = root / stc.SKILL.relative_to(stc.ROOT)
            sk.write_text(sk.read_text(encoding="utf-8").replace("all three must hold", "x"), encoding="utf-8")
            self.assertIn("SKILL_NO_WRITE_GUARD", sb.text_errors(root))
        with tempfile.TemporaryDirectory() as td2:
            self.assertEqual(sb.text_errors(Path(td2)), [])  # isolated fixture: skipped, no false alarm


if __name__ == "__main__":
    unittest.main()
