#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from dynamic_boundary_runtime_probe import classify_observation, run_probe


class DynamicBoundaryRuntimeProbeTests(unittest.TestCase):
    def test_clean_runtime_observation_passes(self):
        self.assertEqual(
            classify_observation({
                "cross_system_imports": [],
                "cross_system_file_writes": [],
                "foreign_current_mutations": [],
                "handoff_process_targets": [],
            }),
            "PASS",
        )

    def test_incomplete_observation_never_passes(self):
        self.assertEqual(classify_observation({}), "INCOMPLETE")
        self.assertEqual(classify_observation({"cross_system_imports": []}), "INCOMPLETE")
        self.assertEqual(classify_observation({
            "cross_system_imports": [],
            "cross_system_file_writes": [],
            "foreign_current_mutations": [],
            "handoff_process_targets": None,
        }), "INCOMPLETE")

    def test_empty_system_registry_is_incomplete_not_observed(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = run_probe(Path(tmp))
        self.assertEqual(result["status"], "INCOMPLETE")
        self.assertEqual(result["evidence_class"], "NOT_OBSERVED")
        self.assertEqual(result["probes"], [])
        self.assertIn("NO_REGISTERED_SYSTEMS_OR_EXECUTION_DIRECTORIES", result["reason_codes"])

    def test_cross_system_runtime_observation_fails(self):
        self.assertEqual(
            classify_observation({
                "cross_system_imports": [{
                    "source_system": "A1-S01",
                    "target_system": "A1-S02",
                }],
                "cross_system_file_writes": [],
                "foreign_current_mutations": [],
                "handoff_process_targets": [],
            }),
            "FAIL",
        )


if __name__ == "__main__":
    unittest.main()
