from __future__ import annotations

import atexit
import json
import shutil
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import central_role_interface
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _pending_repo import pending_root


def execute(request, root=None):
    target = root or pending_root()
    if request.get("operation") == "SUBMIT_ROLE_RESULT" and request.get("role_id") == "ROLE:VERIFIER":
        current = json.loads((target / "P1-CURRENT.json").read_text(encoding="utf-8"))
        active_ref = current["implementation_control"]["active_work_packet"]
        work_path = target / active_ref
        work = json.loads(work_path.read_text(encoding="utf-8"))
        work["brain_mode_control"] = {
            "mode": "FINAL_ACCEPTANCE",
            "plan_approved": True,
            "plan_gates": {
                "objective": True,
                "scope": True,
                "change_set": True,
                "acceptance_criteria": True,
                "risk_recovery": True,
                "cost_authority": True,
                "stop_conditions": True,
            },
            "plan_evidence": {
                "objective": "Verified objective.",
                "scope": "Verified scope.",
                "change_set": "Verified change set.",
                "acceptance_criteria": "Verified acceptance criteria.",
                "risk_recovery": "Verified risks and recovery.",
                "cost_authority": "Verified cost and authority.",
                "stop_conditions": "Verified stop conditions.",
            },
            "feature_batch_complete": True,
            "simulation_batch_passed": True,
            "acceptance_policy": "FINAL_BATCH_ONLY",
            "last_transition": None,
        }
        work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return central_role_interface.execute(request, target)


def req(operation, role_id, **kwargs):
    request = {
        "request_id": f"TEST:{operation}:{role_id}",
        "operation": operation,
        "role_id": role_id,
        "activation_command": kwargs.get("activation_command"),
        "profile_id": kwargs.get("profile_id"),
        "mode": kwargs.get("mode"),
        "work_unit_ref": kwargs.get("work_unit_ref"),
        "summary": kwargs.get("summary"),
        "result_ref": kwargs.get("result_ref"),
        "result_status": kwargs.get("result_status"),
        "acceptance_ref": kwargs.get("acceptance_ref"),
        "head_sha": kwargs.get("head_sha"),
        "final_batch_acceptance": kwargs.get("final_batch_acceptance", False),
        **({"capability_id": kwargs["capability_id"]} if kwargs.get("capability_id") else {}),
    }
    for key in ("cognitive_event", "research_trigger_reasons", "research_record", "feature_batch_complete", "simulation_batch_passed", "plan_evidence"):
        if key in kwargs:
            request[key] = kwargs[key]
    return request


def test_executor_activation_is_blocked_when_work_unit_is_pending_acceptance():
    result = execute(req(
        "ROLE_ACTIVATE",
        "ROLE:EXECUTOR",
        activation_command="！施工",
    ))
    assert result["status"] == "BLOCK"
    assert "WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION" in result["reason_codes"]


def _expected_head_sha() -> str:
    """The acceptance context is the authority for the bound head; do not hard-code it."""
    context = json.loads(
        (pending_root() / "P1-Central-Control/acceptance/M32-CLOSE.acceptance.json").read_text(encoding="utf-8")
    )
    return context["head_sha"]


def test_verifier_reactivation_is_blocked_after_close():
    with patch(
        "central_role_interface.load_current",
        return_value={
            "current_stage": {
                "id": "M32-CLOSE",
                "work_unit_id": "M32-CLOSE",
                "status": "VERIFIED",
                "acceptance_ref": "P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
            },
            "implementation_control": {},
        },
    ):
        result = execute(req(
            "ROLE_ACTIVATE",
            "ROLE:VERIFIER",
            activation_command="！驗收",
        ))
    assert result["status"] == "BLOCK"
    assert "WORK_UNIT_NOT_READY_FOR_ACCEPTANCE" in result["reason_codes"]


def test_verifier_activation_is_allowed_for_m32_close():
    result = execute(req(
        "ROLE_ACTIVATE",
        "ROLE:VERIFIER",
        activation_command="！驗收",
    ))
    assert result["status"] == "PASS"
    assert result["role_id"] == "ROLE:VERIFIER"


def test_control_activation_is_allowed():
    result = execute(req(
        "ROLE_ACTIVATE",
        "ROLE:CONTROL_RESEARCH",
        activation_command="！討論",
    ))
    assert result["status"] == "PASS"
    assert result["role_id"] == "ROLE:CONTROL_RESEARCH"


def test_role_context_for_verifier_is_projection_only():
    result = execute(req(
        "GET_ROLE_CONTEXT",
        "ROLE:VERIFIER",
    ))
    assert result["status"] == "PASS"
    assert result["context_authority"] == "P1-CURRENT"
    assert "acceptance" in result
    assert "control" not in result
    assert result["acceptance"]["context"]["kind"] == "ACCEPTANCE_CONTEXT"
    assert result["acceptance"]["context"]["mode"] == "SIMULATION_ONLY"
    assert "repository_result_reentry" in result["acceptance"]["context"]["required_checks"]


def test_executor_context_is_blocked_when_construction_is_not_open():
    result = execute(req(
        "GET_ROLE_CONTEXT",
        "ROLE:EXECUTOR",
    ))
    assert result["status"] == "BLOCK"
    assert "WORK_UNIT_NOT_OPEN_FOR_CONSTRUCTION" in result["reason_codes"]


def test_progress_returns_only_to_central():
    result = execute(req(
        "REPORT_PROGRESS",
        "ROLE:EXECUTOR",
        summary="implementation progress reported",
    ), root=_construction_root())
    assert result["status"] == "PASS"
    assert result["next_action"] == "RETURN_PROGRESS_TO_CENTRAL"


def test_verifier_pass_does_not_open_next_stage():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:VERIFIER",
        result_ref="VERIFICATION:TEST",
        result_status="PASS",
        acceptance_ref="P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
        head_sha=_expected_head_sha(),
    ))
    assert result["status"] == "PASS"
    assert result["next_action"] == "CENTRAL_NEXT_STAGE_ADMISSION_PENDING"
    assert result["admission"]["status"] == "BLOCK"
    assert "ACCEPTANCE_NOT_VERIFIED" in result["admission"]["reason_codes"]


def test_next_stage_admission_is_derived_without_unlock_state():
    from central_role_interface import compute_next_stage_admission

    result = compute_next_stage_admission(
        current={
            "current_stage": {
                "status": "VERIFIED",
                "next_slice_id": "M33-CANDIDATE-EVAL",
            }
        }
    )
    assert result["status"] == "PASS"
    assert result["admitted"] is True
    assert result["next_work_unit_ref"] == "M33-CANDIDATE-EVAL"
    assert result["admission_mode"] == "DERIVED_NO_UNLOCK_STATE"


def test_verifier_failure_returns_to_control():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:VERIFIER",
        result_ref="VERIFICATION:TEST",
        result_status="FAIL",
        acceptance_ref="P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
        head_sha=_expected_head_sha(),
    ))
    assert result["status"] == "PASS"
    assert result["next_action"] == "RETURN_TO_CONTROL_RESEARCH"


def test_executor_work_complete_returns_acceptance_context_only_for_explicit_final_batch():
    root = pending_root()
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    work_path = root / current["implementation_control"]["active_work_packet"]
    work = json.loads(work_path.read_text(encoding="utf-8"))
    work["brain_mode_control"] = {
        "mode": "FINAL_ACCEPTANCE",
        "plan_approved": True,
        "plan_gates": {
            "objective": True,
            "scope": True,
            "change_set": True,
            "acceptance_criteria": True,
            "risk_recovery": True,
            "cost_authority": True,
            "stop_conditions": True,
        },
        "feature_batch_complete": True,
        "simulation_batch_passed": True,
        "integration_batch_passed": True,
        "final_batch_report_ref": "P1-Central-Control/acceptance/reports/M32-final-integration.json",
        "acceptance_policy": "FINAL_BATCH_ONLY",
        "last_transition": None,
    }
    work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:EXECUTOR",
        result_ref="RESULT:M32-CLOSE",
        result_status="WORK_COMPLETE",
        final_batch_acceptance=True,
    ), root=root)
    assert result["status"] == "PASS"
    assert result["next_action"] == "CENTRAL_ACCEPTANCE_CONTEXT_READY"
    assert result["acceptance_ref"] == "P1-Central-Control/acceptance/M32-CLOSE.acceptance.json"




def _set_cognitive_state(root, *, mode="THINKING", plan_approved=False, batch_complete=False, simulation_passed=False):
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    work_path = root / current["implementation_control"]["active_work_packet"]
    work = json.loads(work_path.read_text(encoding="utf-8"))
    work["brain_mode_control"] = {
        "mode": mode,
        "plan_approved": plan_approved,
        "plan_gates": {
            "objective": True,
            "scope": True,
            "change_set": True,
            "acceptance_criteria": True,
            "risk_recovery": True,
            "cost_authority": True,
            "stop_conditions": True,
        },
        "plan_evidence": {
            "objective": "Reviewed the stated objective.",
            "scope": "Confirmed in-scope and out-of-scope files.",
            "change_set": "Enumerated requested changes.",
            "acceptance_criteria": "Defined observable acceptance criteria.",
            "risk_recovery": "Defined risks, rollback, and recovery.",
            "cost_authority": "Confirmed permitted execution and cost limits.",
            "stop_conditions": "Defined stop conditions for blocked or unsafe states.",
        },
        "feature_batch_complete": batch_complete,
        "simulation_batch_passed": simulation_passed,
        "integration_batch_passed": False,
        "final_batch_report_ref": None,
        "acceptance_policy": "FINAL_BATCH_ONLY",
        "last_transition": None,
    }
    work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return work_path


def _construction_root():
    """Isolated copy of the real (operational) repo in authorized CONSTRUCTION mode.

    The pending-M32 view holds a legacy task-packet Work Unit: it is IMPLEMENTED (the Executor
    is blocked at entry) and fails the operational Work Unit schema, so Executor- and
    final-batch-path tests that need an open operational Work Unit run against this copy.
    """
    root = Path(tempfile.mkdtemp(prefix="p1-operational-")) / "repo"
    atexit.register(shutil.rmtree, root.parent, ignore_errors=True)
    shutil.copytree(ROOT, root, ignore=shutil.ignore_patterns("__pycache__", ".git"))
    _set_cognitive_state(root, mode="CONSTRUCTION", plan_approved=True)
    return root


def test_executor_work_complete_does_not_create_acceptance_by_default():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:EXECUTOR",
        result_ref="RESULT:M32-CLOSE",
        result_status="WORK_COMPLETE",
    ), root=_construction_root())
    # WORK_COMPLETE is a construction-step completion under acceptance_policy FINAL_BATCH_ONLY:
    # it advances the batch (LOCAL_CASE_SIMULATION_REQUIRED) and must not create an acceptance.
    # The earlier BLOCK/FINAL_BATCH_ACCEPTANCE_NOT_REQUESTED expectation described a flow in which
    # the Executor's completion went straight to the acceptance gate.
    assert result["status"] == "PASS"
    assert result["formal_acceptance_created"] is False
    assert result["next_action"] == "LOCAL_CASE_SIMULATION_REQUIRED"


def test_final_acceptance_request_blocks_until_final_batch_is_ready():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:EXECUTOR",
        result_ref="RESULT:M32-CLOSE",
        result_status="WORK_COMPLETE",
        final_batch_acceptance=True,
    ), root=_construction_root())
    assert result["status"] == "BLOCK"
    assert "FINAL_BATCH_NOT_READY" in result["reason_codes"]


def test_cognitive_transition_persists_plan_then_construction():
    root = pending_root()
    _set_cognitive_state(root)
    result = execute(req(
        "COGNITIVE_TRANSITION",
        "ROLE:CONTROL_RESEARCH",
        cognitive_event="THINKING_COMPLETE",
    ), root=root)
    assert result["status"] == "PASS"
    assert result["transition"]["mode"] == "PLAN_READY"

    result = execute(req(
        "COGNITIVE_TRANSITION",
        "ROLE:CONTROL_RESEARCH",
        cognitive_event="PLAN_APPROVED",
    ), root=root)
    assert result["status"] == "PASS"
    assert result["transition"]["mode"] == "CONSTRUCTION"
    current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
    work = json.loads((root / current["implementation_control"]["active_work_packet"]).read_text(encoding="utf-8"))
    assert work["brain_mode_control"]["mode"] == "CONSTRUCTION"
    assert work["brain_mode_control"]["plan_approved"] is True


def test_executor_cannot_approve_its_own_plan():
    root = pending_root()
    _set_cognitive_state(root, mode="PLAN_READY")
    result = execute(req(
        "COGNITIVE_TRANSITION",
        "ROLE:EXECUTOR",
        cognitive_event="PLAN_APPROVED",
    ), root=root)
    assert result["status"] == "BLOCK"
    assert "COGNITIVE_EVENT_NOT_ALLOWED_FOR_ROLE" in result["reason_codes"]


def test_final_batch_ready_requires_explicit_feature_and_simulation_flags():
    root = _construction_root()
    result = execute(req(
        "COGNITIVE_TRANSITION",
        "ROLE:CONTROL_RESEARCH",
        cognitive_event="FINAL_BATCH_READY",
        feature_batch_complete=False,
        simulation_batch_passed=True,
    ), root=root)
    assert result["status"] == "BLOCK"
    assert "FEATURE_BATCH_COMPLETION_NOT_CONFIRMED" in result["reason_codes"]


def test_verifier_result_requires_acceptance_binding():
    # Current contract: a verifier result without acceptance_ref / head_sha is blocked
    # (BLOCK result with reason codes), not signalled by an exception.
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:VERIFIER",
        result_ref="VERIFICATION:TEST",
        result_status="PASS",
    ))
    assert result["status"] == "BLOCK"
    assert result["accepted"] is False
    assert "ACCEPTANCE_CONTEXT_REF_MISMATCH" in result["reason_codes"]
    assert "admission" not in result  # nothing downstream is opened


def test_verifier_stale_head_sha_is_blocked():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:VERIFIER",
        result_ref="VERIFICATION:TEST",
        result_status="PASS",
        acceptance_ref="P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
        head_sha="stale-head-sha",
    ))
    assert result["status"] == "BLOCK"
    assert "STALE_ACCEPTANCE_HEAD_SHA" in result["reason_codes"]


def test_verifier_wrong_acceptance_context_is_blocked():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:VERIFIER",
        result_ref="VERIFICATION:TEST",
        result_status="PASS",
        acceptance_ref="P1-Central-Control/acceptance/OTHER.acceptance.json",
        head_sha=_expected_head_sha(),
    ))
    assert result["status"] == "BLOCK"
    assert "ACCEPTANCE_CONTEXT_REF_MISMATCH" in result["reason_codes"]


def test_acceptance_creation_is_not_a_role_operation():
    try:
        execute(req(
            "CREATE_ACCEPTANCE_CONTEXT",
            "ROLE:EXECUTOR",
        ))
    except Exception as exc:
        assert "is not one of" in str(exc) or "Unsupported" in str(exc)
    else:
        raise AssertionError("role interface must not expose acceptance creation")


def test_unknown_role_activation_is_blocked():
    result = execute(req(
        "ROLE_ACTIVATE",
        "ROLE:VERIFIER",
        activation_command="！施工",
    ))
    assert result["status"] == "BLOCK"
    assert "ROLE_COMMAND_MISMATCH" in result["reason_codes"]


def test_result_submission_never_targets_another_role():
    result = execute(req(
        "SUBMIT_ROLE_RESULT",
        "ROLE:VERIFIER",
        result_ref="VERIFICATION:TEST",
        result_status="PASS",
        acceptance_ref="P1-Central-Control/acceptance/M32-CLOSE.acceptance.json",
        head_sha=_expected_head_sha(),
    ))
    # Must be an accepted result (not an early BLOCK), otherwise the isolation check below is vacuous.
    assert result["status"] == "PASS"
    serialized = json.dumps(result, ensure_ascii=False)
    assert "ROLE:EXECUTOR" not in serialized
    assert "ROLE:VERIFIER" in serialized


# --- unittest discovery bridge (see _function_tests.py) ---
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _function_tests import as_unittest  # noqa: E402

load_tests = as_unittest(__name__)


def test_activation_blocks_capability_not_bound_to_role():
    """U-8 啟用層：宣告要用的 capability 必須綁在該 role（fail closed）。"""
    for role, command, cap in (
        ("ROLE:VERIFIER", "！驗收", "CAP-RETIRE"),
        ("ROLE:CONTROL_RESEARCH", "！討論", "CAP-RETIRE"),
        ("ROLE:EXECUTOR", "！施工", "CAP-VERIFY"),
    ):
        result = execute(req("ROLE_ACTIVATE", role, activation_command=command, capability_id=cap))
        assert result["status"] == "BLOCK", (role, cap)
        assert "CAPABILITY_NOT_BOUND_TO_ROLE" in result["reason_codes"]


def test_activation_passes_with_bound_capability_and_without_declaration():
    bound = execute(req("ROLE_ACTIVATE", "ROLE:VERIFIER", activation_command="！驗收", capability_id="CAP-VERIFY"))
    assert bound["status"] == "PASS"
    undeclared = execute(req("ROLE_ACTIVATE", "ROLE:VERIFIER", activation_command="！驗收"))
    assert undeclared["status"] == "PASS"
