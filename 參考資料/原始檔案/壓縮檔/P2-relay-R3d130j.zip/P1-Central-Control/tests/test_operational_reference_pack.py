#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

from operational_reference_pack import (
    PackError, build_pack, canonical_json, content_hash, verify_pack, write_pack,
    _context_character_count, MEASUREMENT_CONTRACT_VERSION, BUILDER_VERSION, sha256,
)


class OperationalReferencePackTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root / "P1-Central-Control" / "canonical").mkdir(parents=True)
        (self.root / "P1-Central-Control" / "progress" / "construction").mkdir(parents=True)
        (self.root / "P1-Central-Control" / "schemas").mkdir(parents=True)
        (self.root / "P1-Central-Control" / "examples").mkdir(parents=True)
        (self.root / "docs" / "architecture").mkdir(parents=True)
        (self.root / "docs" / "plans").mkdir(parents=True)
        self.current_ref = "P1-CURRENT.json"
        self.blueprint_ref = "docs/architecture/P2-System-Blueprint-v1.0.md"
        self.source_ref = "docs/plans/P2-Code-First-Execution-and-Distilled-Operational-Pack-v1.0.md"
        self.active_work_ref = "P1-Central-Control/progress/M-TEST.work.json"
        self.active_construction_ref = "P1-Central-Control/progress/construction/M-TEST.construction.json"
        self.construction_schema_ref = "P1-Central-Control/schemas/construction_packet.schema.json"
        self.request_ref = "P1-Central-Control/examples/operational_pack_request.fixture.json"

        self.active_work = {
            "work_unit_id": "M-TEST",
            "objective": "Build an actual bounded operational package",
            "scope": ["explicit Current projection", "selected work contract"],
            "constraints": ["No full repository scan", "No history expansion"],
            "allowed_actions": ["READ_DECLARED_INPUTS", "BUILD_PACK", "VERIFY_PACK"],
            "required_inputs": [
                self.current_ref,
                self.blueprint_ref,
                self.source_ref,
                self.active_construction_ref,
                self.construction_schema_ref,
            ],
            "steps": [
                {
                    "step_id": "S1", "action": "Validate explicit source hashes",
                    "inputs": [self.current_ref, self.blueprint_ref, self.source_ref],
                    "outputs": ["source_manifest"],
                    "failure_codes": ["PACK_REQUIRED_REF_MISSING", "PACK_SOURCE_HASH_MISMATCH"],
                    "acceptance_checks": ["Every included source has a SHA-256 hash"],
                },
                {
                    "step_id": "S2", "action": "Construct bounded task instructions",
                    "inputs": ["source_manifest", "active_work", "distilled_rules"],
                    "outputs": ["operational_reference_pack.json"],
                    "failure_codes": ["PACK_CONTEXT_BUDGET_EXCEEDED"],
                    "acceptance_checks": ["Only declared rules and selected inputs are included"],
                },
            ],
            "expected_outputs": ["Deterministic JSON Operational Pack"],
            "stop_conditions": ["Any required source is missing", "Any current fingerprint is stale"],
            "acceptance_checks": ["Same inputs produce same content hash", "A changed source blocks stale verification"],
        }
        current = {
            "schema_version": "1.0",
            "p2_target_blueprint_ref": self.blueprint_ref,
            "revision": 4,
            "state_revision": 9,
            "current_stage": {
                "id": "M-TEST", "status": "BUILDING", "work_unit_id": "M-TEST",
                "next_exact_action": "RUN_ACCEPTANCE",
                "latest_runtime_observation": {"classification": "NOT_EXECUTED", "steps_executed": False},
            },
            "implementation_control": {
                "active_work_packet": self.active_work_ref,
                "active_construction_packet": self.active_construction_ref,
                "runtime_execution_truth": {
                    "status": "INCOMPLETE",
                    "latest_observation": {
                        "observed_at": "2026-10-01T00:00:00Z",
                        "classification": "NOT_EXECUTED",
                        "head_sha": "truth-head",
                        "step_evidence": False,
                        "run_id": None,
                        "evidence": False,
                    },
                },
            },
            "latest_runtime_observation": {
                "observed_at": "2026-10-02T00:00:00Z",
                "classification": "PROGRAM_VERIFIED",
                "head_sha": "top-level-head",
                "steps_executed": True,
                "run_id": 7,
                "evidence": True,
            },
            "read_first": ["DO_NOT_READ/history-a.json", "DO_NOT_READ/history-b.json"],
        }
        work_packet = {
            "schema_version": "1.0",
            "work_id": "M-TEST",
            "work_unit": "M-TEST",
            "phase": "TEST",
            "status": "IN_PROGRESS",
            "implementation_step": "BUILD",
            "objective": "Build one test Operational Pack from the currently selected work packet.",
            "blueprint_ref": self.blueprint_ref,
            "construction_packet_ref": self.active_construction_ref,
            "inputs": [self.current_ref, self.blueprint_ref, self.source_ref],
            "outputs": [{"path": "P1-Central-Control/canonical/test-output.json"}],
            "operational_contract": self.active_work,
            "current_result": {
                "code_status": "IMPLEMENTED_UNVERIFIED",
                "python_tests": "NOT_EXECUTED",
                "formal_caller": "NOT_WIRED",
                "active_pack": "NOT_GENERATED",
                "runtime_truth": "INCOMPLETE",
                "known_execution_blocker": "Unit test fixture; no external execution.",
            },
            "acceptance": {
                "mode": "PROGRAM_EXECUTED_REQUIRED",
                "must_run": ["python3 -m unittest"],
                "required_checks": ["deterministic content hash"],
                "status_until_run": "NOT_EXECUTED",
            },
            "handoff": {"next_step": "RUN_TEST", "work_unit": "M-TEST", "gate": "PROGRAM_EXECUTED_PASS_REQUIRED"},
            "next_action": "Run unit tests before writing the canonical pack.",
        }
        construction_packet = {
            "packet_id": "CONSTRUCTION:M-TEST",
            "version": "1.0",
            "status": "BUILDING",
            "objective": "Test the Current-selected construction contract.",
            "baseline_ref": self.current_ref,
            "work_segment_ref": "M-TEST",
            "read_first": [{"path": self.current_ref, "purpose": "current authority fixture"}],
            "write_scope": {
                "create": ["P1-Central-Control/canonical/test-output.json"],
                "update": [],
                "forbidden": [self.current_ref],
            },
            "implementation_contract": {
                "runtime_entrypoint": "P1-Central-Control/scripts/operational_reference_pack.py",
                "required_behaviors": ["Build a bounded operational pack from explicit refs."],
                "required_symbols": ["build_pack", "verify_pack"],
                "forbidden_new_truths": ["Do not infer runtime PASS from a fixture test."],
            },
            "required_state_delta": {
                "required_paths": ["P1-Central-Control/scripts/operational_reference_pack.py"],
                "allow_zero_files_changed": False,
            },
            "acceptance": {
                "command": ["python3", "P1-Central-Control/tests/test_operational_reference_pack.py"],
                "initial_runs": 1,
                "rerun_on": ["FAIL"],
                "max_total_runs": 2,
            },
            "handoff": {"next_packet_id": None, "notes": ["Test fixture construction packet."]},
        }
        schema_src = Path(__file__).resolve().parents[1] / "schemas" / "construction_packet.schema.json"
        (self.root / self.construction_schema_ref).write_text(schema_src.read_text(encoding="utf-8"), encoding="utf-8")
        (self.root / self.current_ref).write_text(json.dumps(current), encoding="utf-8")
        (self.root / self.active_work_ref).write_text(json.dumps(work_packet), encoding="utf-8")
        (self.root / self.active_construction_ref).write_text(json.dumps(construction_packet), encoding="utf-8")
        (self.root / self.blueprint_ref).write_text("P2 test blueprint. Current-only; no historical context injection.\\n", encoding="utf-8")
        (self.root / self.source_ref).write_text("Source contract for the test pack.\\n", encoding="utf-8")
        self.request = {
            "schema_version": "1.0",
            "pack_id": "OPERATIONAL_PACK:TEST",
            "operation_id": "OPERATION:TEST-001",
            "current_ref": self.current_ref,
            "blueprint_ref": self.blueprint_ref,
            "active_work_ref": self.active_work_ref,
            "source_refs": [
                {"path": self.active_work_ref, "purpose": "Current-selected active work packet", "required": True},
                {"path": self.active_construction_ref, "purpose": "Current-selected construction packet", "required": True},
                {"path": self.construction_schema_ref, "purpose": "construction packet schema", "required": True},
                {"path": self.source_ref, "purpose": "work contract", "required": True},
            ],
            "distilled_rules": [
                {
                    "rule_id": "RULE-1",
                    "trigger": "A work unit starts",
                    "rule_text": "Read only Current projection and explicitly declared references; do not recursively search history.",
                    "required_inputs": [self.current_ref, self.blueprint_ref],
                    "outputs": ["Bounded task context"],
                    "constraints": ["No Current overwrite", "No history loaded"],
                    "failure_codes": ["PACK_REF_PATH_FORBIDDEN", "PACK_REQUIRED_REF_MISSING"],
                    "acceptance_checks": ["No undeclared path is read", "History loaded remains zero"],
                    "provenance_refs": [self.blueprint_ref, self.source_ref],
                    "approval": {
                        "status": "ACCEPTED",
                        "approved_by": "GOVERNANCE",
                        "rationale": "Test fixture approval for a bounded, source-backed operational rule.",
                        "approval_ref": self.blueprint_ref,
                    },
                }
            ],
            "resource_budget": {
                "max_explicit_input_bytes": 100000,
                "max_pack_bytes": 100000,
                "max_context_chars": 20000,
                "max_steps": 5,
            },
        }

    def build_pack(self, request=None):
        selected = self.request if request is None else request
        request_path = self.root / self.request_ref
        request_path.write_text(json.dumps(selected, ensure_ascii=False), encoding="utf-8")
        return build_pack(self.root, selected, request_ref=self.request_ref)


    def build_pack(self, request=None):
        selected = self.request if request is None else request
        request_path = self.root / self.request_ref
        request_path.write_text(json.dumps(selected, ensure_ascii=False), encoding="utf-8")
        return build_pack(self.root, selected, request_ref=self.request_ref)


    def test_deterministic_and_executable_content(self):
        first = self.build_pack()
        second = self.build_pack()
        self.assertEqual(first["schema_version"], "1.1")
        self.assertEqual(first["builder_version"], BUILDER_VERSION)
        self.assertEqual(BUILDER_VERSION, "1.1")
        self.assertEqual(first["content_hash"], second["content_hash"])
        self.assertEqual(first["input_fingerprint"], second["input_fingerprint"])
        self.assertEqual(len(first["active_work"]["steps"]), 2)
        self.assertEqual(first["current_projection"]["fingerprint"][:7], "sha256:")
        self.assertNotIn("read_first", json.dumps(first["current_projection"]))
        self.assertNotIn("DO_NOT_READ", json.dumps(first))
        self.assertEqual(first["resource_usage"]["step_count"], 2)
        usage = first["resource_usage"]
        self.assertEqual(usage["context_char_unit"], "UNICODE_CODE_POINTS")
        self.assertEqual(usage["measurement_contract_version"], MEASUREMENT_CONTRACT_VERSION)
        expected_input_material = {
            "request": self.request,
            "source_manifest": first["source_manifest"],
            "current_fingerprint": first["current_projection"]["fingerprint"],
            "measurement_contract_version": MEASUREMENT_CONTRACT_VERSION,
        }
        self.assertEqual(first["input_fingerprint"], sha256(canonical_json(expected_input_material)))
        self.assertIsNone(usage["model_token_count"])
        self.assertEqual(usage["model_token_count_status"], "NOT_MEASURED")
        context_material = {
            "current_projection": first["current_projection"],
            "active_work": first["active_work"],
            "distilled_rules": first["distilled_rules"],
        }
        self.assertEqual(usage["context_chars"], _context_character_count(context_material))
        unicode_material = {"text": "繁體中文🙂"}
        self.assertEqual(
            _context_character_count(unicode_material),
            len(canonical_json(unicode_material).decode("utf-8")),
        )
        self.assertGreater(
            len(canonical_json(unicode_material)),
            _context_character_count(unicode_material),
            "UTF-8 byte count must not be confused with Unicode code-point count",
        )
        self.assertEqual(first["authority"]["active_work_ref"], self.active_work_ref)
        self.assertEqual(first["active_work"], self.active_work)
        self.assertEqual(first["omitted_refs"], [])

        # Migration compatibility follows the same identity precedence as Runner/Central.
        from operational_reference_pack import _current_projection

        current_doc = json.loads((self.root / self.current_ref).read_text(encoding="utf-8"))
        current_doc["current_stage"].pop("work_unit_id", None)
        current_doc["current_stage"].pop("slice_id", None)
        self.assertEqual(_current_projection(current_doc)["work_unit_id"], "M-TEST")
        current_doc["current_stage"]["work_unit_id"] = ""
        current_doc["current_stage"]["slice_id"] = "MIGRATED-SLICE"
        self.assertEqual(_current_projection(current_doc)["work_unit_id"], "MIGRATED-SLICE")
        current_doc["current_stage"].pop("work_unit_id", None)
        self.assertEqual(_current_projection(current_doc)["work_unit_id"], "MIGRATED-SLICE")
        current_doc["current_stage"]["work_unit_id"] = "ACTIVE-WORK-UNIT"
        self.assertEqual(_current_projection(current_doc)["work_unit_id"], "ACTIVE-WORK-UNIT")

        # A malformed truthy high-priority identity must block rather than fall back.
        current_doc["current_stage"]["work_unit_id"] = ["MALFORMED"]
        with self.assertRaisesRegex(PackError, "PACK_CURRENT_INVALID"):
            _current_projection(current_doc)
        current_doc["current_stage"]["work_unit_id"] = "   "
        with self.assertRaisesRegex(PackError, "PACK_CURRENT_INVALID"):
            _current_projection(current_doc)



    def test_build_rejects_request_reference_mismatch(self):
        changed_request = json.loads(json.dumps(self.request))
        changed_request["operation_id"] = "OPERATION:DIFFERENT"
        (self.root / self.request_ref).write_text(
            json.dumps(changed_request, ensure_ascii=False), encoding="utf-8"
        )
        with self.assertRaisesRegex(PackError, "PACK_REQUEST_REF_CONTENT_MISMATCH"):
            build_pack(self.root, self.request, request_ref=self.request_ref)


    def test_request_drift_blocks_verify(self):
        pack = self.build_pack()
        changed_request = json.loads(json.dumps(self.request))
        changed_request["operation_id"] = "OPERATION:CHANGED"
        (self.root / self.request_ref).write_text(
            json.dumps(changed_request, ensure_ascii=False), encoding="utf-8"
        )
        with self.assertRaisesRegex(PackError, "PACK_STALE_REQUEST"):
            verify_pack(self.root, pack)

    def test_input_fingerprint_tampering_blocks_verify(self):
        pack = self.build_pack()
        pack["input_fingerprint"] = "sha256:" + "0" * 64
        pack["content_hash"] = content_hash(pack)
        with self.assertRaisesRegex(PackError, "PACK_INPUT_FINGERPRINT_MISMATCH"):
            verify_pack(self.root, pack)


    def test_runtime_observation_owners_are_not_flattened(self):
        pack = self.build_pack()
        runtime = pack["current_projection"]["runtime_projection"]
        self.assertEqual(runtime["truth_status"], "INCOMPLETE")
        self.assertEqual(runtime["stage_observation"]["classification"], "NOT_EXECUTED")
        self.assertEqual(runtime["current_latest_observation"]["classification"], "PROGRAM_VERIFIED")
        self.assertEqual(runtime["execution_truth_latest_observation"]["classification"], "NOT_EXECUTED")
        self.assertFalse(runtime["execution_truth_latest_observation"]["steps_executed"])

    def test_write_is_idempotent_and_verifiable(self):
        pack = self.build_pack()
        first = write_pack(self.root, "P1-Central-Control/canonical/operational_reference_pack.json", pack)
        second = write_pack(self.root, "P1-Central-Control/canonical/operational_reference_pack.json", pack)
        self.assertEqual(first["status"], "WRITTEN")
        self.assertEqual(second["status"], "UNCHANGED")
        target = self.root / first["path"]
        on_disk = json.loads(target.read_text(encoding="utf-8"))
        self.assertEqual(len(target.read_bytes()), on_disk["resource_usage"]["pack_bytes"])
        result = verify_pack(self.root, on_disk)
        self.assertEqual(result["status"], "VERIFIED")
        self.assertFalse(result["repository_scan_performed"])
        self.assertEqual(result["history_loaded"], 0)

    def test_pack_write_cannot_target_path_outside_canonical(self):
        pack = self.build_pack()
        output = self.root / "README.md"
        with self.assertRaisesRegex(PackError, "PACK_OUTPUT_PATH_FORBIDDEN"):
            write_pack(self.root, "README.md", pack)
        self.assertFalse(output.exists())

    def test_pack_write_cannot_target_unrelated_file_inside_canonical(self):
        pack = self.build_pack()
        output = self.root / "P1-Central-Control" / "canonical" / "other.json"
        with self.assertRaisesRegex(PackError, "PACK_OUTPUT_PATH_FORBIDDEN"):
            write_pack(self.root, "P1-Central-Control/canonical/other.json", pack)
        self.assertFalse(output.exists())

        # A temporary-looking name must not authorize the Builder to create
        # an unowned directory under canonical/.
        unowned_ref = (
            "P1-Central-Control/canonical/.p2-validation-not-created/"
            "operational_reference_pack.json"
        )
        with self.assertRaisesRegex(PackError, "PACK_OUTPUT_PATH_FORBIDDEN"):
            write_pack(self.root, unowned_ref, pack)
        self.assertFalse(
            (self.root / "P1-Central-Control" / "canonical" / ".p2-validation-not-created").exists()
        )

    def test_pack_write_allows_only_scoped_temporary_integration_target(self):
        pack = self.build_pack()
        output_ref = (
            "P1-Central-Control/canonical/.p2-validation-unit/"
            "operational_reference_pack.json"
        )
        # The runner-owned isolated directory must already exist before the
        # builder is invoked, just as it does under tempfile.TemporaryDirectory.
        (self.root / "P1-Central-Control" / "canonical" / ".p2-validation-unit").mkdir()
        result = write_pack(self.root, output_ref, pack)
        self.assertEqual(result["status"], "WRITTEN")
        on_disk = json.loads((self.root / output_ref).read_text(encoding="utf-8"))
        self.assertEqual(verify_pack(self.root, on_disk)["status"], "VERIFIED")

        # A symlink whose target is another allowed-looking temp directory
        # must not bypass the lexical output-path boundary.
        canonical = self.root / "P1-Central-Control" / "canonical"
        owned_target = canonical / ".p2-validation-owned"
        owned_target.mkdir()
        alias = canonical / ".p2-validation-alias"
        alias.symlink_to(owned_target, target_is_directory=True)
        alias_ref = (
            "P1-Central-Control/canonical/.p2-validation-alias/"
            "operational_reference_pack.json"
        )
        with self.assertRaisesRegex(PackError, "PACK_OUTPUT_PATH_FORBIDDEN"):
            write_pack(self.root, alias_ref, pack)
        self.assertFalse((owned_target / "operational_reference_pack.json").exists())

    def test_current_drift_blocks_verify(self):
        pack = self.build_pack()
        path = self.root / self.current_ref
        current = json.loads(path.read_text(encoding="utf-8"))
        current["state_revision"] = 10
        path.write_text(json.dumps(current), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_STALE_CURRENT"):
            verify_pack(self.root, pack)

    def test_source_drift_blocks_verify(self):
        pack = self.build_pack()
        (self.root / self.source_ref).write_text("changed source\n", encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_STALE_SOURCE"):
            verify_pack(self.root, pack)

    def test_required_source_missing_blocks(self):
        bad = json.loads(json.dumps(self.request))
        bad["source_refs"][3]["path"] = "missing/required.md"
        bad["distilled_rules"][0]["provenance_refs"] = [self.blueprint_ref, "missing/required.md"]
        with self.assertRaisesRegex(PackError, "PACK_REQUIRED_REF_MISSING"):
            self.build_pack(bad)

    def test_optional_source_missing_is_reported_and_not_used_as_provenance(self):
        request = json.loads(json.dumps(self.request))
        optional = "docs/plans/optional.md"
        request["source_refs"].append({"path": optional, "purpose": "optional context", "required": False})
        pack = self.build_pack(request)
        self.assertEqual(pack["omitted_refs"], [optional])
        self.assertTrue(any(entry["path"] == optional and entry["status"] == "OPTIONAL_MISSING" for entry in pack["source_manifest"]))

    def test_path_traversal_blocks(self):
        bad = json.loads(json.dumps(self.request))
        bad["source_refs"][3]["path"] = "../secret.json"
        bad["distilled_rules"][0]["provenance_refs"] = [self.blueprint_ref, "../secret.json"]
        with self.assertRaisesRegex(PackError, "PACK_REF_PATH_FORBIDDEN"):
            self.build_pack(bad)

    def test_request_cannot_override_the_current_selected_blueprint(self):
        bad = json.loads(json.dumps(self.request))
        other_blueprint = "docs/architecture/other-blueprint.md"
        (self.root / other_blueprint).write_text("unselected blueprint\\n", encoding="utf-8")
        bad["blueprint_ref"] = other_blueprint
        bad["source_refs"].append({
            "path": self.blueprint_ref,
            "purpose": "Current-selected P2 blueprint",
            "required": True,
        })
        with self.assertRaisesRegex(PackError, "PACK_BLUEPRINT_REF_NOT_CURRENT"):
            self.build_pack(bad)

    def test_request_cannot_select_a_work_packet_other_than_current(self):
        bad = json.loads(json.dumps(self.request))
        other_ref = "P1-Central-Control/progress/M-OTHER.work.json"
        other = json.loads((self.root / self.active_work_ref).read_text(encoding="utf-8"))
        other["work_id"] = "M-OTHER"
        other["work_unit"] = "M-OTHER"
        other["operational_contract"]["work_unit_id"] = "M-OTHER"
        (self.root / other_ref).write_text(json.dumps(other), encoding="utf-8")
        bad["active_work_ref"] = other_ref
        bad["source_refs"].append({
            "path": other_ref,
            "purpose": "deliberately mismatched work packet",
            "required": True,
        })
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_WORK_REF_NOT_CURRENT"):
            self.build_pack(bad)

    def test_active_work_blueprint_must_match_pack_authority(self):
        packet_path = self.root / self.active_work_ref
        packet = json.loads(packet_path.read_text(encoding="utf-8"))
        packet["blueprint_ref"] = "docs/architecture/other-blueprint.md"
        packet_path.write_text(json.dumps(packet), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_WORK_BLUEPRINT_MISMATCH"):
            self.build_pack()

    def test_request_cannot_override_current_active_work_pointer(self):
        bad = json.loads(json.dumps(self.request))
        bad["active_work_ref"] = self.source_ref
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_WORK_REF_NOT_CURRENT"):
            self.build_pack(bad)

    def test_active_work_construction_ref_must_match_current_pointer(self):
        work_path = self.root / self.active_work_ref
        packet = json.loads(work_path.read_text(encoding="utf-8"))
        packet["construction_packet_ref"] = "P1-Central-Control/progress/construction/OTHER.construction.json"
        work_path.write_text(json.dumps(packet), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_CONSTRUCTION_REF_MISMATCH"):
            self.build_pack()

    def test_active_work_content_tampering_blocks_verify_even_with_rehashed_pack(self):
        pack = self.build_pack()
        pack["active_work"]["objective"] = "Unapproved substituted objective"
        pack["content_hash"] = content_hash(pack)
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_WORK_CONTENT_MISMATCH"):
            verify_pack(self.root, pack)

    def test_active_work_source_drift_blocks_verify(self):
        pack = self.build_pack()
        path = self.root / self.active_work_ref
        packet = json.loads(path.read_text(encoding="utf-8"))
        packet["next_action"] = "SUBSTITUTE_ACTION"
        path.write_text(json.dumps(packet), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_STALE_SOURCE"):
            verify_pack(self.root, pack)

    def test_active_work_step_path_inputs_must_be_declared(self):
        work_path = self.root / self.active_work_ref
        packet = json.loads(work_path.read_text(encoding="utf-8"))
        packet["operational_contract"]["steps"][0]["inputs"].append(
            "docs/plans/undeclared-runtime-contract.md"
        )
        work_path.write_text(json.dumps(packet), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_REQUIRED_WORK_INPUT_NOT_DECLARED"):
            self.build_pack()

    def test_active_work_required_paths_must_be_declared(self):
        work_path = self.root / self.active_work_ref
        packet = json.loads(work_path.read_text(encoding="utf-8"))
        packet["operational_contract"]["required_inputs"].append(
            "P1-Central-Control/tests/not-declared.py"
        )
        work_path.write_text(json.dumps(packet), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_REQUIRED_WORK_INPUT_NOT_DECLARED"):
            self.build_pack()

    def test_unaccepted_rule_is_blocked(self):
        bad = json.loads(json.dumps(self.request))
        bad["distilled_rules"][0]["approval"]["status"] = "CANDIDATE"
        with self.assertRaisesRegex(PackError, "PACK_RULE_NOT_ACCEPTED"):
            self.build_pack(bad)

    def test_unknown_provenance_blocks(self):
        bad = json.loads(json.dumps(self.request))
        bad["distilled_rules"][0]["provenance_refs"] = [self.blueprint_ref, "docs/old-chat.md"]
        with self.assertRaisesRegex(PackError, "PACK_PROVENANCE_REF_NOT_DECLARED"):
            self.build_pack(bad)

    def test_resource_budget_blocks(self):
        bad = json.loads(json.dumps(self.request))
        bad["resource_budget"]["max_steps"] = 1
        with self.assertRaisesRegex(PackError, "PACK_STEP_BUDGET_EXCEEDED"):
            self.build_pack(bad)

    def test_hard_budget_limits_block_before_any_source_read(self):
        cases = [
            ("max_explicit_input_bytes", 5_000_001),
            ("max_pack_bytes", 5_000_001),
            ("max_context_chars", 100_001),
            ("max_steps", 101),
        ]
        for key, value in cases:
            with self.subTest(key=key):
                bad = json.loads(json.dumps(self.request))
                bad["resource_budget"][key] = value
                with mock.patch.object(Path, "read_bytes", side_effect=AssertionError("source read before budget gate")):
                    with self.assertRaisesRegex(PackError, "PACK_REQUEST_INVALID"):
                        self.build_pack(bad)

    def test_active_construction_packet_must_be_declared_and_required(self):
        bad = json.loads(json.dumps(self.request))
        bad["source_refs"] = [item for item in bad["source_refs"] if item["path"] != self.active_construction_ref]
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_CONSTRUCTION_REF_NOT_DECLARED_REQUIRED"):
            self.build_pack(bad)

    def test_active_construction_packet_status_must_be_active(self):
        construction_path = self.root / self.active_construction_ref
        construction = json.loads(construction_path.read_text(encoding="utf-8"))
        construction["status"] = "VERIFIED"
        construction_path.write_text(json.dumps(construction), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_CONSTRUCTION_NOT_ACTIVE"):
            self.build_pack()

    def test_active_construction_source_drift_blocks_verify(self):
        pack = self.build_pack()
        construction_path = self.root / self.active_construction_ref
        construction = json.loads(construction_path.read_text(encoding="utf-8"))
        construction["objective"] = "Drifted after pack build."
        construction_path.write_text(json.dumps(construction), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_STALE_SOURCE"):
            verify_pack(self.root, pack)

    def test_active_construction_contract_identity_fields_fail_closed(self):
        original = json.loads((self.root / self.active_construction_ref).read_text(encoding="utf-8"))
        cases = [
            ("work_segment_ref", "OTHER-WORK", "PACK_ACTIVE_CONSTRUCTION_WORK_UNIT_MISMATCH"),
            ("baseline_ref", "docs/old-blueprint.md", "PACK_ACTIVE_CONSTRUCTION_BASELINE_INVALID"),
        ]
        for field, value, error_code in cases:
            with self.subTest(field=field):
                modified = json.loads(json.dumps(original))
                modified[field] = value
                (self.root / self.active_construction_ref).write_text(json.dumps(modified), encoding="utf-8")
                with self.assertRaisesRegex(PackError, error_code):
                    self.build_pack()
        modified = json.loads(json.dumps(original))
        modified["implementation_contract"]["runtime_entrypoint"] = "P1-Central-Control/scripts/other.py"
        (self.root / self.active_construction_ref).write_text(json.dumps(modified), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_CONSTRUCTION_ENTRYPOINT_MISMATCH"):
            self.build_pack()
        (self.root / self.active_construction_ref).write_text(json.dumps(original), encoding="utf-8")

    def test_active_work_must_reference_the_current_construction_packet(self):
        work_path = self.root / self.active_work_ref
        packet = json.loads(work_path.read_text(encoding="utf-8"))
        packet["construction_packet_ref"] = "P1-Central-Control/progress/construction/OTHER.construction.json"
        work_path.write_text(json.dumps(packet), encoding="utf-8")
        with self.assertRaisesRegex(PackError, "PACK_ACTIVE_CONSTRUCTION_REF_MISMATCH"):
            self.build_pack()


    def test_pack_writer_cannot_overwrite_its_request_file(self):
        request_target = "P1-Central-Control/canonical/operational_reference_pack.json"
        (self.root / request_target).write_text(
            json.dumps(self.request, ensure_ascii=False), encoding="utf-8"
        )
        pack = build_pack(self.root, self.request, request_ref=request_target)
        with self.assertRaisesRegex(PackError, "PACK_CANNOT_OVERWRITE_SOURCE"):
            write_pack(self.root, request_target, pack)
        persisted = json.loads((self.root / request_target).read_text(encoding="utf-8"))
        self.assertEqual(persisted, self.request)


    def test_existing_output_is_not_current(self):
        pack = self.build_pack()
        with self.assertRaisesRegex(PackError, "PACK_CANNOT_OVERWRITE_CURRENT"):
            write_pack(self.root, self.current_ref, pack)

    def test_verify_rejects_forged_resource_metadata(self):
        pack = self.build_pack()
        pack["resource_usage"]["context_chars"] += 1
        pack["content_hash"] = content_hash(pack)
        with self.assertRaisesRegex(PackError, "PACK_CONTEXT_SIZE_MISMATCH"):
            verify_pack(self.root, pack)

        # The explicit unit/status metadata must fail closed if forged.
        pack = self.build_pack()
        pack["resource_usage"]["model_token_count_status"] = "ESTIMATED_FROM_CHARS"
        pack["content_hash"] = content_hash(pack)
        with self.assertRaisesRegex(PackError, "PACK_OUTPUT_INVALID"):
            verify_pack(self.root, pack)

        # The new required measurement receipt fields make the old Pack format
        # incompatible; a stale 1.0 version must not pass under the 1.1 schema.
        pack = self.build_pack()
        pack["schema_version"] = "1.0"
        pack["content_hash"] = content_hash(pack)
        with self.assertRaisesRegex(PackError, "PACK_OUTPUT_INVALID"):
            verify_pack(self.root, pack)


if __name__ == "__main__":
    unittest.main(verbosity=2)
