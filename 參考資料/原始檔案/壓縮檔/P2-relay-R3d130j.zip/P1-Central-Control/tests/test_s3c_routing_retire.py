"""S3c: CAP-INSTRUCTION-ROUTING (habit_counter + role_command_router wiring) and CAP-RETIRE failure handling.
SIMULATED_PASS (death = BaseException raised mid-run; no real process kill)."""
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import event_log as el  # noqa: E402
import lifecycle_sweep as ls  # noqa: E402
import role_command_router as router  # noqa: E402
from test_lifecycle_sweep import C, cands, make_repo  # noqa: E402

WF, CID, T = "W-S3C", "C-S3C", "2026-10-16T10:00:00+00:00"


def hc():
    import habit_counter
    return habit_counter


class Died(BaseException):
    pass


class Routing(unittest.TestCase):
    def setUp(self) -> None:
        self.tmp = Path(tempfile.mkdtemp(prefix="s3c-"))
        self.addCleanup(shutil.rmtree, self.tmp, True)
        self.log, self.state = self.tmp / "ev.log", self.tmp / "routing.json"

    def route(self, text, source="USER_DIRECT"):
        return hc().route_instruction(text, source=source, conversation_id=CID, event_log_path=self.log, workflow_id=WF,
                                      occurred_at=T, state_path=self.state)

    def route_events(self):
        if not self.log.exists():
            return []
        return [r for r in el.read_dialogue(el.EventLog(self.log).events_for("SEGMENT", WF), CID) if str(r.get("ref", "")).startswith("ROLE_ROUTE:")]

    def activations(self):
        return json.loads(self.state.read_text(encoding="utf-8"))["activations"] if self.state.exists() else {}

    def habit_state(self, *terms):
        h = hc()
        st = h.load_state(self.state)
        for term, cmd in terms:
            h.register(st, term, cmd, "USER_DIRECT")
        return st

    def test_bang_command_routes_with_event_and_activation(self) -> None:
        r = self.route("!施工")
        self.assertEqual((r["outcome"], r["role_id"]), ("ROUTED", "ROLE:EXECUTOR"))
        self.assertEqual(len(self.route_events()), 1)
        self.assertEqual(len(self.activations()), 1)

    def test_unknown_command_is_refused_and_activates_nothing(self) -> None:
        self.assertEqual(self.route("！不存在的指令")["outcome"], "REFUSED")
        self.assertEqual(self.activations(), {})
        self.assertEqual(self.route_events(), [])

    def test_llm_proposed_cannot_activate(self) -> None:
        r = self.route("！施工", source="LLM_PROPOSED")
        self.assertEqual((r["outcome"], r["reason"]), ("REFUSED", "LLM_PROPOSED_NOT_ACTIVATABLE"))
        self.assertEqual((self.activations(), self.route_events()), ({}, []))

    def test_resend_same_input_does_not_activate_twice(self) -> None:
        self.route("！施工")
        r = self.route("！施工")
        self.assertEqual(r["outcome"], "ROUTED")
        self.assertTrue(r["reused"])
        self.assertEqual((len(self.activations()), len(self.route_events())), (1, 1))

    def test_interrupt_event_without_activation_resume_only_activates(self) -> None:
        h = hc()
        with mock.patch.object(h, "save_state", side_effect=Died):
            with self.assertRaises(Died):
                self.route("！施工")
        self.assertEqual((len(self.route_events()), self.activations()), (1, {}))
        r = self.route("！施工")
        self.assertEqual(r["outcome"], "ROUTED")
        self.assertEqual((len(self.route_events()), len(self.activations())), (1, 1))  # no second event

    def test_inconsistent_activation_without_event_is_rewritten(self) -> None:
        h = hc()
        st = h.load_state(self.state)
        key = h.input_key(CID, router.normalize_command("！施工"))
        st["activations"][key] = {"role_id": "ROLE:EXECUTOR"}
        h.save_state(self.state, st)
        self.assertEqual(self.route("！施工")["outcome"], "ROUTED")
        self.assertEqual((len(self.route_events()), len(self.activations())), (1, 1))

    def test_ambiguous_text_is_unresolved_and_activates_nothing(self) -> None:
        h = hc()
        self.assertEqual(self.route("施工")["outcome"], "UNRESOLVED")  # no habit word registered
        st = self.habit_state(("施工", "！施工"), ("驗", "！驗收"))
        for _ in range(3):
            h.confirm(st, "施工", "USER_DIRECT")
            h.confirm(st, "驗", "USER_DIRECT")
        h.save_state(self.state, st)
        self.assertEqual(self.route("施工驗收")["outcome"], "UNRESOLVED")  # two eligible words: do not guess
        self.assertEqual((self.activations(), self.route_events()), ({}, []))

    def test_corrupt_state_is_unresolved_with_zero_activation(self) -> None:
        self.state.write_text("{broken", encoding="utf-8")
        self.assertEqual(self.route("！施工")["outcome"], "UNRESOLVED")
        self.assertEqual(self.route_events(), [])

    def test_habit_word_needs_three_user_confirmations(self) -> None:
        h = hc()
        st = self.habit_state(("施工", "！施工"))
        h.confirm(st, "施工", "USER_DIRECT")
        h.confirm(st, "施工", "USER_DIRECT")
        with self.assertRaises(ValueError):
            h.confirm(st, "施工", "LLM_PROPOSED")  # the model cannot add to the count
        self.assertEqual(st["habits"]["施工"]["confirmations"], 2)
        h.save_state(self.state, st)
        self.assertEqual(self.route("施工")["outcome"], "UNRESOLVED")  # only 2 confirmations
        h.confirm(st, "施工", "USER_DIRECT")
        h.save_state(self.state, st)
        r = self.route("施工")
        self.assertEqual((r["outcome"], r["role_id"]), ("ROUTED", "ROLE:EXECUTOR"))

    def test_router_wiring_calls_resolve_and_record_and_is_not_a_method_call(self) -> None:
        with mock.patch.object(router, "resolve_and_record", wraps=router.resolve_and_record) as m:
            self.route("！施工")
        self.assertEqual(m.call_count, 1)


class RetireFailureHandling(unittest.TestCase):
    def setUp(self) -> None:
        self.root = make_repo()
        self.addCleanup(shutil.rmtree, self.root, True)

    def test_protected_file_refused_and_kept(self) -> None:
        with self.assertRaisesRegex(ValueError, "PROTECTED"):
            ls.delete_batch(self.root, [ls.POLICY_PATH])
        self.assertTrue((self.root / ls.POLICY_PATH).is_file())

    def test_candidate_list_failure_deletes_nothing(self) -> None:
        before = set(cands(self.root))
        with mock.patch.object(ls, "find_candidates", side_effect=RuntimeError("scan")):
            with self.assertRaises(RuntimeError):
                ls.run_retirement(self.root)
            with self.assertRaises(RuntimeError):
                ls.delete_batch(self.root, sorted(before)[:1])
        self.assertTrue(all((self.root / p).is_file() for p in before))

    def test_interrupted_delete_then_rerun_only_deletes_the_rest(self) -> None:
        batch = ls.batches(ls.find_candidates(self.root)["candidates"], 20)[0]
        self.assertGreaterEqual(len(batch), 2)
        orig, calls = Path.unlink, []

        def dying(self_, *a, **k):
            calls.append(str(self_))
            if len(calls) == 2:
                raise Died
            return orig(self_, *a, **k)

        with mock.patch.object(Path, "unlink", dying):
            with self.assertRaises(Died):
                ls.delete_batch(self.root, batch)
        left = [p for p in batch if (self.root / p).exists()]
        self.assertTrue(0 < len(left) < len(batch))
        res = ls.run_retirement(self.root)
        self.assertEqual(res["blocked"], [])
        self.assertFalse(any(p in res["deleted"] for p in batch if p not in left))  # already-deleted file is not deleted twice
        self.assertEqual(cands(self.root), {})

    def test_single_file_delete_failure_keeps_it_and_does_not_stop_the_batch(self) -> None:
        batch = ls.batches(ls.find_candidates(self.root)["candidates"], 20)[0]
        bad = batch[-1]
        orig = Path.unlink

        def flaky(self_, *a, **k):
            if str(self_).endswith(bad):
                raise PermissionError("locked")
            return orig(self_, *a, **k)

        with mock.patch.object(Path, "unlink", flaky):
            res = ls.delete_batch(self.root, batch)
            self.assertEqual(res["failed"], [bad])
            self.assertTrue((self.root / bad).exists())
            self.assertTrue(all(not (self.root / p).exists() for p in batch if p != bad))
            run = ls.run_retirement(self.root)  # persistent failure: reported as blocked, never raises
        self.assertIn(bad, run["blocked"])
        self.assertNotIn(bad, run["deleted"])


if __name__ == "__main__":
    unittest.main()
