#!/usr/bin/env python3
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
import current_projection_sync as sync

class CurrentProjectionSyncTests(unittest.TestCase):
    def current(self):
        return {
            "implementation_control":{"active_work_packet":"P1-Central-Control/progress/M23-P11.work.json","runtime_execution_truth":{"status":"INCOMPLETE"}},
            "current_stage":{"id":"M23-P11","status":"IMPLEMENTED_UNVERIFIED"},
            "latest_runtime_observation":{"run_id":123,"run_attempt":2,"classification":"RUNNER_STARTUP_FAILURE","step_evidence":False}
        }
    def test_sync_inserts_and_inspects_projection(self):
        current = self.current()
        synced = sync.sync("# P1\n\n內容\n", current)
        self.assertEqual(sync.inspect(synced, current)["status"], "PASS")
    def test_current_execution_truth_overrides_legacy_top_level_observation(self):
        current = self.current()
        current["implementation_control"]["runtime_execution_truth"]["latest_observation"] = {
            "run_id": None,
            "run_attempt": None,
            "classification": "NOT_EXECUTED",
            "step_evidence": False,
        }
        current["latest_runtime_observation"] = {
            "run_id": 123,
            "run_attempt": 2,
            "classification": "SIMULATION_ACCEPTANCE_PASS",
            "step_evidence": False,
        }
        rendered = sync.render(current)
        self.assertIn("NOT_EXECUTED", rendered)
        self.assertNotIn("SIMULATION_ACCEPTANCE_PASS", rendered)

    def test_empty_current_observation_does_not_resurrect_legacy_history(self):
        current = self.current()
        current["implementation_control"]["runtime_execution_truth"]["latest_observation"] = {}
        current["current_stage"]["latest_runtime_observation"] = {
            "run_id": 7, "run_attempt": 1, "classification": "STALE_STAGE_PASS", "step_evidence": True
        }
        current["latest_runtime_observation"] = {
            "run_id": 6, "run_attempt": 1, "classification": "LEGACY_HISTORICAL_PASS", "step_evidence": True
        }
        rendered = sync.render(current)
        self.assertNotIn("STALE_STAGE_PASS", rendered)
        self.assertNotIn("LEGACY_HISTORICAL_PASS", rendered)
        # 渲染格式為「run X / attempt Y / <classification> / step evidence Z」，沒有 "classification" 標籤
        # （repo 根 README 內嵌的投影行同此格式）；原斷言找不存在的標籤。空 observation 的語意＝各欄皆 None。
        self.assertIn("run None / attempt None / None / step evidence None", rendered)

        # Explicit null is also a present, empty Current value—not permission to fall back.
        current["implementation_control"]["runtime_execution_truth"]["latest_observation"] = None
        rendered_null = sync.render(current)
        self.assertNotIn("STALE_STAGE_PASS", rendered_null)
        self.assertNotIn("LEGACY_HISTORICAL_PASS", rendered_null)

    def test_drift_detected(self):
        current = self.current()
        readme = sync.sync("# P1\n", current).replace("M23-P11", "M23-P10")
        self.assertEqual(sync.inspect(readme, current)["status"], "DRIFT")

    def test_diff_names_only_the_changed_field(self):
        current = self.current()
        readme = sync.sync("# P1\n", current).replace("M23-P11 / IMPLEMENTED_UNVERIFIED", "M23-P10 / IMPLEMENTED_UNVERIFIED")
        r = sync.inspect(readme, current)
        self.assertEqual(r["status"], "DRIFT")
        self.assertEqual(r["diff_fields"], ["Current Stage"])

    def test_diff_names_every_changed_field_in_order(self):
        current = self.current()
        readme = sync.sync("# P1\n", current).replace("INCOMPLETE", "COMPLETE").replace("P11.work.json", "P10.work.json")
        self.assertEqual(sync.inspect(readme, current)["diff_fields"], ["目前 Active Work", "Runtime Truth"])

    def test_missing_markers_reports_whole_block(self):
        r = sync.inspect("# P1\n", self.current())
        self.assertEqual((r["status"], r["diff_fields"]), ("DRIFT", ["CURRENT_PROJECTION_BLOCK"]))

    def test_unlabelled_extra_line_is_reported_not_silent(self):
        current = self.current()
        readme = sync.sync("# P1\n", current).replace(sync.END, "> 手寫多出的一行\n" + sync.END)
        r = sync.inspect(readme, current)
        self.assertEqual(r["status"], "DRIFT")
        self.assertEqual(r["diff_fields"], ["UNPARSED_LINES"])

    def test_pass_has_empty_diff_fields(self):
        current = self.current()
        self.assertEqual(sync.inspect(sync.sync("# P1\n", current), current)["diff_fields"], [])

    def test_write_mode_verifies_the_file_on_disk(self):
        import json, tempfile
        current = self.current()
        with tempfile.TemporaryDirectory() as d:
            cp, rp = Path(d) / "c.json", Path(d) / "README.md"
            cp.write_text(json.dumps(current), encoding="utf-8")
            rp.write_text(sync.sync("# P1\n", current).replace("INCOMPLETE", "COMPLETE"), encoding="utf-8")
            argv = sys.argv
            sys.argv = ["x", "--current", str(cp), "--readme", str(rp), "--write"]
            try:
                import contextlib, io
                with contextlib.redirect_stdout(io.StringIO()):
                    rc = sync.main()
            finally:
                sys.argv = argv
            self.assertEqual(rc, 0)
            self.assertEqual(sync.inspect(rp.read_text(encoding="utf-8"), current)["status"], "PASS")

if __name__ == "__main__":
    unittest.main()
