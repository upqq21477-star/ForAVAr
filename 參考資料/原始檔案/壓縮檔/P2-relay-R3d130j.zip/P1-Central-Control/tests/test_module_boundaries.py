#!/usr/bin/env python3
"""U-8 static boundaries: Central stays semantics-free; Capability never touches work state.

Pure import-graph checks (AST), no execution. A new violation fails; the known one is listed.
"""
from __future__ import annotations

import ast
import unittest
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
MODULES = {p.stem for p in SCRIPTS.glob("*.py")}

CENTRAL = {
    "central_controller", "command_layer", "parallel_scheduler", "event_reducer",
    "event_log", "packet_layer", "state_transition",
}
# Envelope-level collaborators Central may use (ids / status / refs only).
CENTRAL_MAY_USE = CENTRAL | {
    "brain_input", "brain_proposal", "capability_router", "execution_truth",
    "result_distillation", "state_machine_runtime_gate", "task_set",
}
# Work-state owners a Capability must never import.
WORK_STATE = CENTRAL | {"brain_input", "brain_proposal", "task_set", "execution_truth"}
CAPABILITY = {m for m in MODULES if m.startswith("capability_") and m != "capability_router"}

# Known Central leaks, tracked for removal (none now; add an entry only with a removal plan).
KNOWN_CENTRAL_LEAKS: set[tuple[str, str]] = set()


def local_imports(module: str) -> set[str]:
    tree = ast.parse((SCRIPTS / f"{module}.py").read_text(encoding="utf-8"))
    found: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found.update(a.name.split(".")[0] for a in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module and node.level == 0:
            found.add(node.module.split(".")[0])
    return found & MODULES


class ModuleBoundaryTest(unittest.TestCase):
    def test_central_imports_no_semantic_modules(self):
        bad = {
            (m, i)
            for m in CENTRAL
            for i in local_imports(m) - CENTRAL_MAY_USE
        } - KNOWN_CENTRAL_LEAKS
        self.assertEqual(bad, set())

    def test_known_leak_still_exists(self):
        # Delete the entry from KNOWN_CENTRAL_LEAKS when the leak is removed.
        for module, imported in KNOWN_CENTRAL_LEAKS:
            self.assertIn(imported, local_imports(module))

    def test_capability_never_imports_work_state(self):
        bad = {(m, i) for m in CAPABILITY for i in local_imports(m) & WORK_STATE}
        self.assertEqual(bad, set())

    def test_capability_set_is_not_empty(self):
        self.assertGreaterEqual(len(CAPABILITY), 3)


if __name__ == "__main__":
    unittest.main()
