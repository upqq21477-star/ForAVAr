from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import construction_efficiency_review as health_review
from brain_mode_controller import (
    PLAN_GATE_KEYS,
    build_construction_health_review,
    build_role_supervision_context,
    initial_control_state,
    transition_mode,
    validate_research_record,
)


def complete_gates() -> dict[str, bool]:
    return {key: True for key in PLAN_GATE_KEYS}


def valid_research_record() -> dict:
    return {
        "observations": ["The latest code path returns the wrong state."],
        "sources": ["P1-CURRENT.json", "P2-System-Blueprint-v1.0.md"],
        "hypotheses": [
            {
                "statement": "The caller skips the cognitive transition.",
                "supporting_evidence": ["No transition call appears in the current path."],
                "contradicting_evidence": ["The proposal validator is already called."],
                "discriminating_test": "Call the interface with a transition event and inspect the returned mode.",
            }
        ],
        "candidate_comparison": [
            "Add a deterministic mode controller and connect it to Central.",
            "Keep research as an optional prompt-only convention.",
        ],
        "selected_solution": "Use a bounded deterministic controller behind the existing Central interface.",
        "stop_condition": "Stop research when one contract-valid path and the required negative cases are covered.",
    }


class BrainModeControllerTests(unittest.TestCase):
    def test_task_starts_in_thinking(self):
        control = initial_control_state()
        self.assertEqual(control["mode"], "THINKING")
        self.assertFalse(control["plan_approved"])
        self.assertEqual(control["acceptance_policy"], "FINAL_BATCH_ONLY")

        restarted = transition_mode(
            current_mode="FINAL_ACCEPTANCE",
            event="TASK_STARTED",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(restarted["mode"], "THINKING")
        self.assertFalse(restarted["plan_approved"])
        self.assertFalse(restarted["feature_batch_complete"])
        self.assertFalse(restarted["simulation_batch_passed"])
        self.assertFalse(restarted["integration_batch_passed"])
        self.assertEqual(restarted["missing_plan_gates"], list(PLAN_GATE_KEYS))
        review_samples = [
            {"sha": "a" * 40, "date": "2026-10-08", "subject": "Implement bounded core",
             "files": [{"path": "P1-Central-Control/scripts/core.py", "additions": 100, "deletions": 10}]},
            {"sha": "b" * 40, "date": "2026-10-09", "subject": "Fix regression in core",
             "files": [{"path": "P1-Central-Control/scripts/core.py", "additions": 20, "deletions": 8}]},
            {"sha": "c" * 40, "date": "2026-10-10", "subject": "Fix core edge case",
             "files": [{"path": "P1-Central-Control/scripts/core.py", "additions": 6, "deletions": 2}]},
        ]
        review = build_construction_health_review(
            trigger="slowdown", samples=review_samples,
            construction_units=100, maintenance_units=25, resource_unit="tokens",
        )
        self.assertEqual(review["classification"], "REVIEW_RECOMMENDED")
        self.assertIn("REPEATED_FILE_TOUCHES", [x["code"] for x in review["signals"]])
        self.assertIn("MULTIPLE_CORRECTIVE_COMMITS", [x["code"] for x in review["signals"]])
        self.assertEqual(review["maintenance_resource_budget"]["status"], "OVER_BUDGET")
        self.assertEqual(review["maintenance_resource_budget"]["ratio"], 0.25)
        self.assertIn("MAINTENANCE_RESOURCE_BUDGET_EXCEEDED", [x["code"] for x in review["signals"]])
        unmeasured = build_construction_health_review(trigger="user_requested", samples=review_samples)
        self.assertEqual(unmeasured["maintenance_resource_budget"]["status"], "UNMEASURED")
        self.assertEqual(unmeasured["model_reasoning_quality"], "NOT_DIRECTLY_OBSERVABLE_FROM_GIT_METADATA")
        self.assertFalse(unmeasured["retention"]["full_diff_loaded"])
        self.assertFalse(unmeasured["retention"]["persistent_review_history_written"])

        # Exercise the exact 20% boundary and reject non-comparable telemetry.
        at_limit = build_construction_health_review(
            trigger="user_requested", samples=review_samples,
            construction_units=100, maintenance_units=20, resource_unit="tokens",
        )
        self.assertEqual(at_limit["maintenance_resource_budget"]["status"], "WITHIN_BUDGET")
        self.assertEqual(at_limit["maintenance_resource_budget"]["ratio"], 0.2)
        invalid_usage_cases = (
            {"construction_units": 0, "maintenance_units": 1, "resource_unit": "tokens"},
            {"construction_units": 100, "maintenance_units": 21, "resource_unit": ""},
            {"construction_units": float("nan"), "maintenance_units": 1, "resource_unit": "tokens"},
            {"construction_units": 100, "maintenance_units": -1, "resource_unit": "tokens"},
        )
        for usage_case in invalid_usage_cases:
            with self.subTest(usage_case=usage_case):
                invalid = build_construction_health_review(
                    trigger="user_requested", samples=review_samples, **usage_case,
                )
                self.assertEqual(
                    invalid["maintenance_resource_budget"]["status"],
                    "INVALID_OR_INCOMPLETE_TELEMETRY",
                )
                self.assertIsNone(invalid["maintenance_resource_budget"]["ratio"])

        # Source-byte budget pressure is separate from measured maintenance usage.
        near_source_budget = build_construction_health_review(
            trigger="slowdown", samples=review_samples,
            source_input_bytes=85, source_input_budget_bytes=100,
        )
        self.assertEqual(near_source_budget["source_input_budget"]["status"], "NEAR_BUDGET")
        self.assertIn("SOURCE_INPUT_BUDGET_PRESSURE", [x["code"] for x in near_source_budget["signals"]])
        over_source_budget = build_construction_health_review(
            trigger="slowdown", samples=review_samples,
            source_input_bytes=101, source_input_budget_bytes=100,
        )
        self.assertEqual(over_source_budget["source_input_budget"]["status"], "OVER_BUDGET")

        # Invalid triggers and unbounded input windows fail closed.
        with self.assertRaisesRegex(ValueError, "REVIEW_TRIGGER_REQUIRED"):
            build_construction_health_review(trigger="routine", samples=review_samples)
        with self.assertRaisesRegex(ValueError, "REVIEW_COMMIT_WINDOW_INVALID"):
            build_construction_health_review(trigger="user_requested", samples=review_samples + [review_samples[0]])
        too_many_files = dict(review_samples[0])
        too_many_files["files"] = [
            {"path": f"src/module_{index}.py", "additions": 1, "deletions": 0}
            for index in range(21)
        ]
        with self.assertRaisesRegex(ValueError, "REVIEW_FILE_WINDOW_INVALID"):
            build_construction_health_review(trigger="user_requested", samples=[too_many_files])

        # Mock git output to verify the CLI consumes no more than 20 numstat rows.
        class FakeStdout:
            def __init__(self, total_rows):
                self.total_rows = total_rows
                self.rows_read = 0
                self.closed = False

            def __iter__(self):
                return self

            def __next__(self):
                if self.rows_read >= self.total_rows:
                    raise StopIteration
                self.rows_read += 1
                return f"1\t0\tfile_{self.rows_read}.py\n"

            def close(self):
                self.closed = True

        class FakeProcess:
            def __init__(self, raise_on_terminate=False):
                self.stdout = FakeStdout(21)
                self.stderr = None
                self.terminated = False
                self.raise_on_terminate = raise_on_terminate

            def terminate(self):
                if self.raise_on_terminate:
                    raise ProcessLookupError()
                self.terminated = True

            def wait(self, timeout=None):
                return 0

            def kill(self):
                self.terminated = True

        fake_process = FakeProcess()
        with patch.object(health_review.subprocess, "Popen", return_value=fake_process):
            file_rows, truncated = health_review._numstat(Path("."), "a" * 40)
        self.assertEqual(len(file_rows), 20)
        self.assertEqual(fake_process.stdout.rows_read, 20)
        self.assertTrue(fake_process.stdout.closed)
        self.assertTrue(fake_process.terminated)
        self.assertTrue(truncated)

        # The child may exit naturally between reading the capped row and terminate().
        race_process = FakeProcess(raise_on_terminate=True)
        with patch.object(health_review.subprocess, "Popen", return_value=race_process):
            race_rows, race_truncated = health_review._numstat(Path("."), "b" * 40)
        self.assertEqual(len(race_rows), 20)
        self.assertEqual(race_process.stdout.rows_read, 20)
        self.assertTrue(race_process.stdout.closed)
        self.assertTrue(race_truncated)

        # Exercise the manifest reader with a minimal temporary repository.
        with tempfile.TemporaryDirectory() as temp_dir:
            root = Path(temp_dir)
            (root / "P1-Central-Control" / "examples").mkdir(parents=True)
            (root / "src.py").write_text("print('ok')\n", encoding="utf-8")
            (root / "blueprint.md").write_text("# bp\n", encoding="utf-8")
            current_doc = {"implementation_control": {"active_work_packet": "work.json"}}
            (root / "P1-CURRENT.json").write_text(
                json.dumps(current_doc), encoding="utf-8",
            )
            request_path = root / "P1-Central-Control" / "examples" / "operational_reference_pack.request.example.json"
            request_doc = {
                "current_ref": "P1-CURRENT.json",
                "active_work_ref": "work.json",
                # _source_budget 現要求 blueprint_ref（construction_efficiency_review.py）；夾具補上，期望不變。
                "blueprint_ref": "blueprint.md",
                "source_refs": [{"path": "src.py"}],
                "resource_budget": {"max_explicit_input_bytes": 1000},
            }
            request_path.write_text(json.dumps(request_doc), encoding="utf-8")
            evidence = health_review._source_budget(root)
            self.assertEqual(evidence["declared_source_count"], 1)
            self.assertEqual(evidence["existing_source_count"], 1)
            self.assertEqual(evidence["missing_source_refs"], [])
            self.assertEqual(evidence["invalid_source_refs"], [])

            request_doc["resource_budget"] = []
            request_path.write_text(json.dumps(request_doc), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "REVIEW_INPUT_BUDGET_INVALID"):
                health_review._source_budget(root)

            request_doc["resource_budget"] = {"max_explicit_input_bytes": 1000}
            request_doc["source_refs"] = [{"path": "."}]
            request_path.write_text(json.dumps(request_doc), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "REVIEW_SOURCE_REF_INVALID"):
                health_review._source_budget(root)

            request_doc["source_refs"] = [{"path": "../outside.py"}]
            request_path.write_text(json.dumps(request_doc), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "REVIEW_PATH_FORBIDDEN"):
                health_review._source_budget(root)

            (root / "source-directory").mkdir()
            request_doc["source_refs"] = [
                {"path": "missing-source.py"},
                {"path": "source-directory"},
            ]
            request_path.write_text(json.dumps(request_doc), encoding="utf-8")
            directory_evidence = health_review._source_budget(root)
            self.assertEqual(directory_evidence["existing_source_count"], 0)
            self.assertEqual(directory_evidence["missing_source_refs"], ["missing-source.py"])
            self.assertEqual(directory_evidence["invalid_source_refs"], ["source-directory"])

            # End-to-end report assembly must retain source diagnostics in the
            # final limits object; do not overwrite them after computing the counts.
            (root / ".git").touch()
            samples = [
                {"sha": "a" * 40, "date": "2026-10-10", "subject": "Initial sample", "files": []},
                {"sha": "b" * 40, "date": "2026-10-11", "subject": "Follow-up sample", "files": []},
            ]
            with patch.object(health_review, "_commits", return_value=samples), patch.object(
                health_review, "_numstat", return_value=([], False)
            ):
                report = health_review.generate_review(trigger="user_requested", root=root)
            self.assertEqual(report["status"], "BLOCKED")
            self.assertEqual(report["limits"]["missing_source_ref_count"], 1)
            self.assertEqual(report["limits"]["invalid_source_ref_count"], 1)

    def test_thinking_skips_heavy_research_for_known_simple_task(self):
        result = transition_mode(
            current_mode="THINKING",
            event="THINKING_COMPLETE",
            plan_gates=complete_gates(),
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["mode"], "PLAN_READY")
        self.assertFalse(result["research_recommended"])

        # An out-of-mode completion event must not force PLAN_READY or RESEARCH.
        for invalid_source_mode in ("RESEARCH", "PLAN_READY", "CONSTRUCTION"):
            with self.subTest(source_mode=invalid_source_mode):
                blocked = transition_mode(
                    current_mode=invalid_source_mode,
                    event="THINKING_COMPLETE",
                    plan_gates=complete_gates(),
                    research_trigger_reasons=["ROOT_CAUSE_UNKNOWN"],
                    plan_approved=invalid_source_mode == "CONSTRUCTION",
                )
                self.assertEqual(blocked["status"], "BLOCK")
                self.assertEqual(blocked["reason_code"], "THINKING_MODE_REQUIRED")
                self.assertEqual(blocked["mode"], "THINKING")
                self.assertTrue(blocked["construction_paused"])

    def test_unknown_root_cause_triggers_research(self):
        result = transition_mode(
            current_mode="THINKING",
            event="THINKING_COMPLETE",
            plan_gates=complete_gates(),
            research_trigger_reasons=["ROOT_CAUSE_UNKNOWN"],
        )
        self.assertEqual(result["mode"], "RESEARCH")
        self.assertEqual(result["reason_code"], "RESEARCH_TRIGGERED")

    def test_unexpected_output_pauses_construction_and_returns_to_thinking(self):
        result = transition_mode(
            current_mode="CONSTRUCTION",
            event="UNEXPECTED_OUTPUT",
            plan_gates=complete_gates(),
            plan_approved=True,
        )
        self.assertEqual(result["mode"], "THINKING")
        self.assertTrue(result["construction_paused"])
        self.assertTrue(result["research_recommended"])
        self.assertFalse(result["plan_approved"])

    def test_incomplete_plan_gate_blocks_plan_ready(self):
        gates = complete_gates()
        gates["cost_authority"] = False
        result = transition_mode(
            current_mode="THINKING",
            event="THINKING_COMPLETE",
            plan_gates=gates,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["mode"], "THINKING")
        # 原期望 ["cost_authority"] 是舊行為：阻擋後回到 THINKING 時，程式 fail-closed 重置全部 plan gate
        # （brain_mode_controller.transition_mode 的 effective_plan_gates；同檔 TASK_STARTED 與
        # 行 478 的暫停案例皆已斷言全部 7 項缺）。此處保留 BLOCK／THINKING，並確認缺口含 cost_authority。
        self.assertEqual(result["missing_plan_gates"], list(PLAN_GATE_KEYS))
        self.assertIn("cost_authority", result["missing_plan_gates"])

    def test_plan_approval_requires_plan_ready_and_complete_gates(self):
        result = transition_mode(
            current_mode="THINKING",
            event="PLAN_APPROVED",
            plan_gates=complete_gates(),
            plan_approved=True,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason_code"], "PLAN_READY_STATE_REQUIRED")

        result = transition_mode(
            current_mode="PLAN_READY",
            event="PLAN_APPROVED",
            plan_gates=complete_gates(),
            plan_approved=True,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["mode"], "CONSTRUCTION")
        self.assertTrue(result["plan_approved"])

    def test_research_requires_bounded_hypotheses_and_counterevidence(self):
        valid, issues = validate_research_record(valid_research_record())
        self.assertTrue(valid, issues)

        invalid_record = valid_research_record()
        invalid_record["hypotheses"] = invalid_record["hypotheses"] * 4
        valid, issues = validate_research_record(invalid_record)
        self.assertFalse(valid)
        self.assertIn("RESEARCH_HYPOTHESIS_BUDGET_INVALID", issues)

        missing_sources = valid_research_record()
        missing_sources["sources"] = []
        valid, issues = validate_research_record(missing_sources)
        self.assertFalse(valid)
        self.assertIn("RESEARCH_SOURCE_BUDGET_INVALID", issues)

        empty_support = valid_research_record()
        empty_support["hypotheses"][0]["supporting_evidence"] = []
        valid, issues = validate_research_record(empty_support)
        self.assertFalse(valid)
        self.assertIn("RESEARCH_SUPPORTING_EVIDENCE_INVALID:0", issues)

        empty_counterevidence = valid_research_record()
        empty_counterevidence["hypotheses"][0]["contradicting_evidence"] = []
        valid, issues = validate_research_record(empty_counterevidence)
        self.assertFalse(valid)
        self.assertIn("RESEARCH_CONTRADICTING_EVIDENCE_INVALID:0", issues)

        oversized_statement = valid_research_record()
        oversized_statement["hypotheses"][0]["statement"] = "x" * 1001
        valid, issues = validate_research_record(oversized_statement)
        self.assertFalse(valid)
        self.assertIn("RESEARCH_HYPOTHESIS_STATEMENT_TOO_LONG:0", issues)

        oversized_discriminating_test = valid_research_record()
        oversized_discriminating_test["hypotheses"][0]["discriminating_test"] = "x" * 1001
        valid, issues = validate_research_record(oversized_discriminating_test)
        self.assertFalse(valid)
        self.assertIn("RESEARCH_DISCRIMINATING_TEST_TOO_LONG:0", issues)

    def test_research_completion_requires_a_complete_record(self):
        result = transition_mode(
            current_mode="RESEARCH",
            event="RESEARCH_COMPLETE",
            plan_gates=complete_gates(),
            research_record={"observations": ["observed"]},
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["mode"], "THINKING")
        self.assertEqual(result["reason_code"], "RESEARCH_RECORD_INCOMPLETE")

        missing_sources = valid_research_record()
        missing_sources["sources"] = []
        empty_counterevidence = valid_research_record()
        empty_counterevidence["hypotheses"][0]["contradicting_evidence"] = []
        oversized_test = valid_research_record()
        oversized_test["hypotheses"][0]["discriminating_test"] = "x" * 1001
        for invalid_record in (missing_sources, empty_counterevidence, oversized_test):
            with self.subTest(invalid_record=invalid_record):
                blocked = transition_mode(
                    current_mode="RESEARCH",
                    event="RESEARCH_COMPLETE",
                    plan_gates=complete_gates(),
                    research_record=invalid_record,
                )
                self.assertEqual(blocked["status"], "BLOCK")
                self.assertEqual(blocked["mode"], "THINKING")
                self.assertEqual(blocked["reason_code"], "RESEARCH_RECORD_INCOMPLETE")
                self.assertTrue(blocked["construction_paused"])

        # A valid-looking record must not bypass the explicit RESEARCH state.
        for invalid_source_mode in ("THINKING", "PLAN_READY", "CONSTRUCTION"):
            with self.subTest(source_mode=invalid_source_mode):
                bypass_attempt = transition_mode(
                    current_mode=invalid_source_mode,
                    event="RESEARCH_COMPLETE",
                    plan_gates=complete_gates(),
                    plan_approved=invalid_source_mode == "CONSTRUCTION",
                    research_record=valid_research_record(),
                )
                self.assertEqual(bypass_attempt["status"], "BLOCK")
                self.assertEqual(bypass_attempt["reason_code"], "RESEARCH_MODE_REQUIRED")
                self.assertEqual(bypass_attempt["mode"], "THINKING")
                self.assertTrue(bypass_attempt["construction_paused"])

        valid_completion = transition_mode(
            current_mode="RESEARCH",
            event="RESEARCH_COMPLETE",
            plan_gates=complete_gates(),
            research_record=valid_research_record(),
        )
        self.assertEqual(valid_completion["status"], "PASS")
        self.assertEqual(valid_completion["mode"], "PLAN_READY")
        self.assertEqual(valid_completion["reason_code"], "RESEARCH_COMPLETE_PLAN_READY")

    def test_construction_step_completion_enters_simulation(self):
        result = transition_mode(
            current_mode="CONSTRUCTION",
            event="CONSTRUCTION_STEP_COMPLETE",
            plan_gates=complete_gates(),
            plan_approved=True,
        )
        self.assertEqual(result["mode"], "SIMULATION")
        self.assertEqual(result["reason_code"], "LOCAL_SIMULATION_REQUIRED")

        blocked = transition_mode(
            current_mode="CONSTRUCTION",
            event="CONSTRUCTION_STEP_COMPLETE",
            plan_gates=complete_gates(),
            plan_approved=False,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertEqual(blocked["reason_code"], "CONSTRUCTION_NOT_AUTHORIZED")
        self.assertEqual(blocked["mode"], "THINKING")
        self.assertFalse(blocked["plan_approved"])
        self.assertFalse(blocked["feature_batch_complete"])
        self.assertFalse(blocked["simulation_batch_passed"])
        self.assertFalse(blocked["integration_batch_passed"])

    def test_simulation_pass_returns_to_thinking_before_next_construction(self):
        result = transition_mode(
            current_mode="SIMULATION",
            event="SIMULATION_PASSED",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=False,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["reason_code"], "STEP_SIMULATION_PASSED_RETURN_TO_THINKING")
        self.assertEqual(result["mode"], "THINKING")
        self.assertTrue(result["construction_paused"])
        self.assertFalse(result["plan_approved"])
        self.assertEqual(len(result["missing_plan_gates"]), 7)
        self.assertEqual(result["acceptance_policy"], "FINAL_BATCH_ONLY")
        self.assertFalse(result["feature_batch_complete"])
        self.assertFalse(result["simulation_batch_passed"])
        self.assertFalse(result["integration_batch_passed"])

        # A later construction slice must not resume directly from SIMULATION.
        for invalid_source_mode in ("THINKING", "CONSTRUCTION"):
            with self.subTest(source_mode=invalid_source_mode):
                blocked = transition_mode(
                    current_mode=invalid_source_mode,
                    event="SIMULATION_PASSED",
                    plan_gates=complete_gates(),
                    plan_approved=True,
                )
                self.assertEqual(blocked["status"], "BLOCK")
                self.assertEqual(blocked["reason_code"], "SIMULATION_MODE_REQUIRED")
                self.assertEqual(blocked["mode"], "THINKING")
                self.assertTrue(blocked["construction_paused"])

        incomplete_gates = complete_gates()
        incomplete_gates["cost_authority"] = False
        for case_name, plan_approved, gates in (
            ("approval_missing", False, complete_gates()),
            ("gate_missing", True, incomplete_gates),
        ):
            with self.subTest(case=case_name):
                blocked = transition_mode(
                    current_mode="SIMULATION",
                    event="SIMULATION_PASSED",
                    plan_gates=gates,
                    plan_approved=plan_approved,
                )
                self.assertEqual(blocked["status"], "BLOCK")
                self.assertEqual(blocked["reason_code"], "SIMULATION_PLAN_NOT_AUTHORIZED")
                self.assertEqual(blocked["mode"], "THINKING")
                self.assertTrue(blocked["construction_paused"])

    def test_simulation_failure_returns_to_thinking_and_recommends_research(self):
        result = transition_mode(
            current_mode="SIMULATION",
            event="SIMULATION_FAILED",
            plan_gates=complete_gates(),
            plan_approved=True,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["reason_code"], "SIMULATION_FAILED_RETURN_TO_THINKING")
        self.assertEqual(result["mode"], "THINKING")
        self.assertTrue(result["construction_paused"])
        self.assertTrue(result["research_recommended"])
        self.assertFalse(result["plan_approved"])

        for invalid_source_mode in ("THINKING", "CONSTRUCTION", "FINAL_ACCEPTANCE"):
            with self.subTest(source_mode=invalid_source_mode):
                blocked = transition_mode(
                    current_mode=invalid_source_mode,
                    event="SIMULATION_FAILED",
                    plan_gates=complete_gates(),
                    plan_approved=invalid_source_mode == "CONSTRUCTION",
                    feature_batch_complete=invalid_source_mode == "FINAL_ACCEPTANCE",
                    simulation_batch_passed=invalid_source_mode == "FINAL_ACCEPTANCE",
                    integration_batch_passed=invalid_source_mode == "FINAL_ACCEPTANCE",
                )
                self.assertEqual(blocked["status"], "BLOCK")
                self.assertEqual(blocked["reason_code"], "SIMULATION_MODE_REQUIRED")
                self.assertEqual(blocked["mode"], "THINKING")
                self.assertTrue(blocked["construction_paused"])

    def test_final_batch_requires_both_completion_and_simulation_evidence(self):
        blocked = transition_mode(
            current_mode="CONSTRUCTION",
            event="FINAL_BATCH_READY",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=False,
        )
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertEqual(blocked["reason_code"], "FINAL_BATCH_INTEGRATION_EVIDENCE_MISSING")
        self.assertEqual(blocked["mode"], "THINKING")
        self.assertFalse(blocked["feature_batch_complete"])
        self.assertFalse(blocked["simulation_batch_passed"])
        self.assertFalse(blocked["integration_batch_passed"])

        invalid_source = transition_mode(
            current_mode="FINAL_ACCEPTANCE",
            event="FINAL_BATCH_READY",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(invalid_source["status"], "BLOCK")
        self.assertEqual(invalid_source["reason_code"], "FINAL_BATCH_SOURCE_MODE_INVALID")
        self.assertEqual(invalid_source["mode"], "THINKING")
        self.assertFalse(invalid_source["plan_approved"])
        self.assertFalse(invalid_source["feature_batch_complete"])
        self.assertFalse(invalid_source["simulation_batch_passed"])
        self.assertFalse(invalid_source["integration_batch_passed"])

        unapproved_plan = transition_mode(
            current_mode="CONSTRUCTION",
            event="FINAL_BATCH_READY",
            plan_gates=complete_gates(),
            plan_approved=False,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(unapproved_plan["status"], "BLOCK")
        self.assertEqual(unapproved_plan["reason_code"], "FINAL_BATCH_PLAN_NOT_APPROVED")
        self.assertEqual(unapproved_plan["mode"], "THINKING")
        self.assertTrue(unapproved_plan["construction_paused"])

        incomplete_gates = complete_gates()
        incomplete_gates["stop_conditions"] = False
        missing_plan_gate = transition_mode(
            current_mode="CONSTRUCTION",
            event="FINAL_BATCH_READY",
            plan_gates=incomplete_gates,
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(missing_plan_gate["status"], "BLOCK")
        self.assertEqual(missing_plan_gate["reason_code"], "PLAN_GATE_INCOMPLETE")
        self.assertEqual(missing_plan_gate["mode"], "THINKING")
        self.assertTrue(missing_plan_gate["construction_paused"])

        accepted = transition_mode(
            current_mode="CONSTRUCTION",
            event="FINAL_BATCH_READY",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(accepted["status"], "PASS")
        self.assertEqual(accepted["reason_code"], "FINAL_BATCH_READY_FOR_INDEPENDENT_ACCEPTANCE")
        self.assertEqual(accepted["mode"], "FINAL_ACCEPTANCE")

    def test_final_acceptance_failure_returns_to_thinking(self):
        premature = transition_mode(
            current_mode="CONSTRUCTION",
            event="FINAL_ACCEPTANCE_FAILED",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(premature["status"], "BLOCK")
        self.assertEqual(premature["reason_code"], "FINAL_ACCEPTANCE_EVIDENCE_GATE_REQUIRED")
        self.assertEqual(premature["mode"], "CONSTRUCTION")
        self.assertTrue(premature["construction_paused"])

        result = transition_mode(
            current_mode="FINAL_ACCEPTANCE",
            event="FINAL_ACCEPTANCE_FAILED",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["reason_code"], "FINAL_ACCEPTANCE_FAILED_RETURN_TO_THINKING")
        self.assertEqual(result["mode"], "THINKING")
        self.assertTrue(result["construction_paused"])
        self.assertTrue(result["research_recommended"])

    def test_final_acceptance_pass_closes(self):
        result = transition_mode(
            current_mode="FINAL_ACCEPTANCE",
            event="FINAL_ACCEPTANCE_PASSED",
            plan_gates=complete_gates(),
            plan_approved=True,
            feature_batch_complete=True,
            simulation_batch_passed=True,
            integration_batch_passed=True,
        )
        self.assertEqual(result["mode"], "CLOSE")

    def test_supervision_context_never_claims_runtime_evidence(self):
        control = initial_control_state()
        control.update(
            mode="CONSTRUCTION",
            plan_approved=True,
            plan_gates=complete_gates(),
        )
        # A forged legacy boolean map must not bypass the missing evidence record.
        context = build_role_supervision_context(
            current={"current_stage": {"id": "P2-B2.2"}},
            work_packet={"brain_mode_control": control},
            role_id="ROLE:EXECUTOR",
        )
        self.assertEqual(context["current_mode"], "CONSTRUCTION")
        self.assertFalse(context["construction_allowed"])
        self.assertEqual(context["missing_plan_gates"], list(PLAN_GATE_KEYS))
        self.assertEqual(context["required_next_step"], "PAUSE_CONSTRUCTION_AND_REPLAN")
        self.assertTrue(all(value == "" for value in context["plan_evidence"].values()))
        self.assertEqual(context["acceptance_policy"]["formal_acceptance"], "FINAL_BATCH_ONLY")
        self.assertEqual(context["runtime_evidence"], "NOT_PROVIDED_BY_MODE_CONTROLLER")


if __name__ == "__main__":
    unittest.main()
