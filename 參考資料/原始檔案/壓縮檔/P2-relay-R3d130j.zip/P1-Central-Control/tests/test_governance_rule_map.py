"""治理規則對照表（R3h）：每條規則的強制證據逐項核對，缺口不得被藏起來。

可直接執行：python3 P1-Central-Control/tests/test_governance_rule_map.py
"""
import copy
import hashlib
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MAP = ROOT / "P1-Central-Control/policy/governance_rule_map.v1.0.json"
STATUS = {"ENFORCED", "PARTIAL", "POLICY_ONLY", "NOT_IMPLEMENTED"}


def check(m: dict, root: Path = ROOT) -> list[str]:
    errs, seen = [], set()
    arch = root / m["source"]["archived_full_text"]
    if not arch.exists() or hashlib.sha256(arch.read_bytes()).hexdigest() != m["source"]["sha256"]:
        errs.append("SOURCE_ARCHIVE_MISSING_OR_ALTERED")
    for r in m["rules"]:
        i = r["id"]
        if i in seen:
            errs.append(f"{i}:DUPLICATE_ID")
        seen.add(i)
        if r["status"] not in STATUS:
            errs.append(f"{i}:BAD_STATUS")
        has_refs = bool(r["refs"])
        if r["status"] in ("ENFORCED", "PARTIAL") and not has_refs:
            errs.append(f"{i}:NO_REFS")
        if r["status"] in ("POLICY_ONLY", "NOT_IMPLEMENTED") and has_refs:
            errs.append(f"{i}:REFS_ON_UNENFORCED")
        if r["status"] in ("PARTIAL", "NOT_IMPLEMENTED") and not r.get("gap"):
            errs.append(f"{i}:GAP_REQUIRED")
        for ref in r["refs"]:
            p = root / ref["path"]
            if not p.exists():
                errs.append(f"{i}:REF_FILE_MISSING:{ref['path']}")
            elif ref["term"].lower() not in p.read_text(encoding="utf-8").lower():
                errs.append(f"{i}:REF_TERM_NOT_FOUND:{ref['path']}:{ref['term']}")
    return errs


class GovernanceRuleMapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.m = json.loads(MAP.read_text(encoding="utf-8"))

    def test_map_checks_out(self):
        self.assertEqual(check(self.m), [])

    def test_every_section_has_rules(self):
        for sec in "1234":
            self.assertGreaterEqual(sum(r["section"] == sec for r in self.m["rules"]), 9)

    def test_gaps_are_declared_not_hidden(self):
        ni = [r for r in self.m["rules"] if r["status"] == "NOT_IMPLEMENTED"]
        self.assertTrue(ni and all(r["gap"] for r in ni))

    def test_bad_term_is_caught(self):
        bad = copy.deepcopy(self.m)
        next(r for r in bad["rules"] if r["refs"])["refs"][0]["term"] = "ZZZ_NO_SUCH_TERM_ZZZ"
        self.assertTrue(any("REF_TERM_NOT_FOUND" in e for e in check(bad)))

    def test_unenforced_rule_cannot_claim_refs(self):
        bad = copy.deepcopy(self.m)
        r = next(r for r in bad["rules"] if r["status"] == "POLICY_ONLY")
        r["refs"] = [{"path": "tools/precheck.py", "term": "hygiene"}]
        self.assertTrue(any("REFS_ON_UNENFORCED" in e for e in check(bad)))

    def test_partial_without_gap_is_caught(self):
        bad = copy.deepcopy(self.m)
        r = next(r for r in bad["rules"] if r["status"] == "PARTIAL")
        r.pop("gap")
        self.assertTrue(any("GAP_REQUIRED" in e for e in check(bad)))

    def test_altered_archive_is_caught(self):
        bad = copy.deepcopy(self.m)
        bad["source"]["sha256"] = "0" * 64
        self.assertIn("SOURCE_ARCHIVE_MISSING_OR_ALTERED", check(bad))


if __name__ == "__main__":
    unittest.main()
