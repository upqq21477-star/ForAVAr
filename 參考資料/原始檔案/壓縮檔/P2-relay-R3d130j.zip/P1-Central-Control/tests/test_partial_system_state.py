import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from partial_system_state import execute


class PartialSystemStateTests(unittest.TestCase):
    def _base(self):
        return {
            "schema_version": "1.0",
            "request_id": "REVERSE:TEST-P1",
            "status": "PASS",
            "identity": {
                "root_path": "/tmp/example",
                "root_name": "example",
                "file_count": 2,
                "source_revision": None
            },
            "coverage_ledger": [],
            "inventory": [
                {"path": "app.py", "kind": "SOURCE", "language": "python", "bytes": 10, "lines": 1, "sha256": "a"*64}
            ],
            "structure": {
                "modules": ["app.py"],
                "symbols": [{"path": "app.py", "kind": "FUNCTION", "name": "main"}],
                "entrypoint_candidates": ["app.py"],
                "stub_signals": [],
                "syntax_errors": []
            },
            "dependencies": {
                "edges": [],
                "unresolved": []
            },
            "state_assessment": {
                "classification": "IMPLEMENTED",
                "implemented": True,
                "partial": False,
                "stub": False,
                "broken": False,
                "unknown": False,
                "next_diagnostic_point": None
            },
            "evidence": {
                "observed": ["inventory.files=1"],
                "confirmed": ["root_path_exists"],
                "inferred": ["entrypoint_candidate:app.py"],
                "unknown": ["runtime_behavior"],
                "conflict": []
            }
        }

    def test_expected_missing_is_missing_not_unknown(self):
        result = execute(self._base(), expected_paths=["app.py", "controller.py"])
        self.assertEqual(result["classification"], "MISSING")
        self.assertEqual(result["missing"], ["controller.py"])
        self.assertTrue(any("missing_paths_are_missing" in x for x in result["evidence"]["unknown"]))

    def test_unresolved_dependency_is_partial(self):
        base = self._base()
        base["dependencies"]["unresolved"] = ["app.py -> package.missing"]
        result = execute(base)
        self.assertEqual(result["classification"], "PARTIAL")
        self.assertIn("app.py -> package.missing", result["dependencies"]["unresolved"])


if __name__ == "__main__":
    unittest.main()
