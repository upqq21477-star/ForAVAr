import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import brief_use as bu  # noqa: E402
import event_log as el  # noqa: E402


class BriefUseTests(unittest.TestCase):
    def test_simulation_all_pass(self):
        res = bu.simulate()
        self.assertGreaterEqual(len(res), 10)
        self.assertEqual([n for n, ok, _ in res if not ok], [])

    def test_event_builder_rejects_wrong_type_and_missing_fields(self):
        kw = dict(workflow_id="w", revision=1, brief_session_id="b", occurred_at="2026-10-14T00:00:00Z")
        with self.assertRaises(ValueError):
            el.make_brief_use_event(event_type="SEGMENT_STARTED", **kw)
        with self.assertRaises(ValueError):
            el.make_brief_use_event(event_type="BRIEF_SLOTS_CITED", **kw)
        with self.assertRaises(ValueError):
            el.make_brief_use_event(event_type="INFORMATION_GAP_PROPOSED", **kw)

    def test_new_types_registered(self):
        self.assertIn("BRIEF_SLOTS_CITED", el.SEGMENT_EVENT_TYPES)
        self.assertIn("INFORMATION_GAP_PROPOSED", el.SEGMENT_EVENT_TYPES)

    def test_slot_id_deterministic(self):
        self.assertEqual(bu.slot_id_for("a/b.py::foo_bar"), "S_GAP_FOO_BAR")


if __name__ == "__main__":
    unittest.main()
