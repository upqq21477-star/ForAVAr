import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import p2_run  # noqa: E402
import path_distill as pd  # noqa: E402


class PathGateParity(unittest.TestCase):
    def test_fp_path_gate_matches_run_path(self):
        with tempfile.TemporaryDirectory() as td:
            run = p2_run.Run(td, write_scope=[])
            for rel in ["/etc/x.py", "../o.py", "a/../b.py", "", None, 5, "x.exe", "calc.py", "sub/n.md"]:
                try:
                    run._path(rel)
                    want = None
                except p2_run.GateReject as g:
                    want = g.code
                self.assertEqual(pd.fp_path_gate({"path": rel}, "read", td, p2_run.SUFFIXES), want, rel)

    def test_wrong_arg_shape_misses(self):
        self.assertIsNone(pd.fp_path_gate({"path": "/etc/x.py", "bogus": 1}, "read", "/tmp", p2_run.SUFFIXES))
        self.assertIsNone(pd.fp_path_gate({"path": "/etc/x.py"}, "search", "/tmp", p2_run.SUFFIXES))

    def test_tool_gate_codes(self):
        self.assertEqual(pd.fp_tool_gate("rm", 5), "TOOL_UNKNOWN")
        self.assertEqual(pd.fp_tool_gate("read", 0), "BUDGET_EXHAUSTED")
        self.assertIsNone(pd.fp_tool_gate("read", 1))

    def test_test_outcome(self):
        a = []
        self.assertEqual(pd.fp_test_outcome(a, 0, "r"), "success")
        self.assertEqual(pd.fp_test_outcome(a, 1, "r"), "failure")
        self.assertEqual([x["t"] for x in a], [0, 1])


class Toggle(unittest.TestCase):
    def test_use_fast_off_never_hits_and_on_hits_same_code(self):
        pd.HITS.clear()
        with tempfile.TemporaryDirectory() as td:
            off = p2_run.Run(td, write_scope=[], use_fast=False).step("read", {"path": "../x.py"})
            self.assertEqual(off["code"], "PATH_ESCAPE")
            self.assertEqual(pd.HITS, {})
            on = p2_run.Run(td, write_scope=[], use_fast=True).step("read", {"path": "../x.py"})
            self.assertEqual(on["code"], "PATH_ESCAPE")
            self.assertEqual(pd.HITS, {"FP1": 1})

    def test_edit_in_thinking_mode_keeps_original_precedence(self):
        with tempfile.TemporaryDirectory() as td:
            r = p2_run.Run(td, write_scope=[], use_fast=True)
            self.assertEqual(r.step("edit", {"path": "/etc/x.py", "old": "a", "new": "b"})["code"], "NOT_AUTHORIZED_TO_BUILD")


class Classify(unittest.TestCase):
    def _t(self, tool, digest="d"):
        return {"seq": 1, "tool": tool, "verdict": "ALLOW", "code": "OK", "args_digest": digest, "mode": "CONSTRUCTION"}

    def test_stable_mechanical_edit_semantic_unstable_semantic(self):
        runs = [[self._t("run_tests"), self._t("edit"), self._t("read", "d%d" % k)] for k in range(3)]
        c = pd.classify(runs)
        self.assertEqual([x["class"] for x in c], ["mechanical", "semantic", "mechanical"])
        runs[2][0]["code"] = "X"
        self.assertEqual(pd.classify(runs)[0]["class"], "semantic")


class ReplayAndThreshold(unittest.TestCase):
    def test_replay_equivalent_then_mutation_detected(self):
        sem, fast = pd.capture(False), pd.capture(True)
        self.assertEqual(sem["hits"], {})
        self.assertEqual(pd.compare(sem["rec"], fast["rec"])["equivalence_rate"], 1.0)
        orig = pd.fp_test_outcome

        def bad(attempts, exit_code, run_id):
            attempts.append({"step": "run_tests", "outcome": "success", "head_sha": run_id, "t": len(attempts)})
            return "success"
        pd.fp_test_outcome = bad
        try:
            mut = pd.capture(True)
        finally:
            pd.fp_test_outcome = orig
        self.assertLess(pd.compare(sem["rec"], mut["rec"])["equivalence_rate"], 1.0)

    def test_threshold_tamper_blocks_measure(self):
        with tempfile.TemporaryDirectory() as td:
            ev = Path(td)
            pd.write_threshold(ev)
            (ev / "threshold.json").write_text('{"min_ratio": 0.0}\n', encoding="utf-8")
            with self.assertRaises(SystemExit):
                pd.measure(ev)
            with self.assertRaises(SystemExit):
                pd.measure(Path(td) / "none")


if __name__ == "__main__":
    unittest.main()
