#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))

import regression_selection as selection  # noqa: E402
from packet_layer import content_hash  # noqa: E402


class RegressionSelectionTests(unittest.TestCase):
    def routing_report(self, status="INSUFFICIENT_DATA"):
        return {
            "object_id":"ROUTING_REEVALUATION:M3-TEST",
            "kind":"ROUTING_REEVALUATION",
            "schema_version":"1.0",
            "content_hash":"sha256:" + "0"*64,
            "routing_reevaluation_id":"M3-TEST",
            "source_reevaluation_id":"M2-TEST",
            "source_reevaluation_status":status,
            "routes":[{
                "capability_id":"CAP-EXTRACT",
                "evaluation_ref":"NATIVE_REPLACEMENT_EVAL:EVAL-1",
                "evaluation_status":"PASS",
                "evaluation_state":"FINALIZED",
                "route_mode":"MODEL_ONLY",
                "decision_code":"CANDIDATE_READY",
                "capability_refs":["CAP-EXTRACT"],
                "required_controls":[],
                "evidence_refs":[],
                "contract_gap_refs":[]
            }],
            "pending":[{
                "capability_id":"CAP-CLASSIFY",
                "reason_code":"M2_PENDING"
            }] if status=="INSUFFICIENT_DATA" else [],
            "status":status
        }

    def valid_routing(self, status="INSUFFICIENT_DATA"):
        report=self.routing_report(status)
        report["content_hash"]=selection.routing_reevaluation.content_hash(report)
        return report

    def impact(self, sets=None):
        return {
            "scan_id":"IMPACT:M4-TEST",
            "change_id":"CHANGE:M4-TEST",
            "status":"PASS",
            "decision":"PROCEED",
            "unknown_paths":[],
            "affected_capabilities":["CAP-EXTRACT","CAP-CLASSIFY"],
            "required_regression_sets":sets or ["routing","e2e"],
            "path_results":[{
                "path":"P1-Central-Control/scripts/routing_reevaluation.py",
                "matched_rule_ids":["CONTROL_SCRIPTS"],
                "change_type":"RUNTIME",
                "known":True
            }],
            "rule_registry":"M1_IMPACT_MAP_V1",
            "reason_codes":["IMPACT_RESOLVED"]
        }

    def registry(self):
        return selection.load_set_registry(ROOT / "P1-Central-Control/regression_selection_registry.json")

    def test_pass_candidate_selects_required_sets(self):
        report=selection.select(self.valid_routing("PASS"),self.impact(),registry=self.registry(),selection_id="M4-001")
        self.assertEqual(report["status"],"PASS")
        self.assertEqual(report["selected_regression_sets"],["e2e","routing"])
        self.assertEqual(report["selections"][0]["regression_sets"],["e2e","routing"])
        selection.validate_report(report)

    def test_partial_routing_is_deferred(self):
        report=selection.select(self.valid_routing(),self.impact(),registry=self.registry(),selection_id="M4-002")
        self.assertEqual(report["status"],"INSUFFICIENT_DATA")
        self.assertEqual(report["selected_regression_sets"],["e2e","routing"])
        self.assertEqual(report["pending"][0]["capability_id"],"CAP-CLASSIFY")
        self.assertEqual(report["pending"][0]["reason_code"],"ROUTE_DEFERRED")

    def test_empty_required_regression_sets_never_pass(self):
        impact = self.impact()
        impact["required_regression_sets"] = []
        report = selection.select(self.valid_routing("PASS"), impact, registry=self.registry(), selection_id="M4-EMPTY")
        self.assertEqual(report["status"], "INSUFFICIENT_DATA")
        self.assertIn("NO_REQUIRED_REGRESSION_SETS", report["reason_codes"])
        self.assertEqual(report["selected_regression_sets"], [])

    def test_no_ready_routes_never_pass_empty_selection(self):
        routing = self.valid_routing("PASS")
        routing["routes"] = []
        routing["pending"] = []
        routing["content_hash"] = selection.routing_reevaluation.content_hash(routing)
        report = selection.select(routing, self.impact(), registry=self.registry(), selection_id="M4-NO-ROUTES")
        self.assertEqual(report["status"], "INSUFFICIENT_DATA")
        self.assertIn("NO_REGRESSION_SETS_SELECTED", report["reason_codes"])

    def test_unknown_regression_set_blocks(self):
        with self.assertRaises(ValueError):
            selection.select(self.valid_routing("PASS"),self.impact(["unknown"]),registry=self.registry())

    def test_blocked_routing_is_rejected(self):
        report=self.valid_routing("PASS")
        report["routes"][0]["decision_code"]="BLOCK"
        report["routes"][0]["route_mode"]=None
        report["status"]="BLOCK"
        report["source_routing_status"]="BLOCK"
        report["content_hash"]=selection.routing_reevaluation.content_hash(report)
        with self.assertRaises(ValueError):
            selection.select(report,self.impact(),registry=self.registry())

    def test_old_or_raw_input_is_not_accepted(self):
        report=self.valid_routing("PASS")
        report["raw_measurement"]={"sample_size":100}
        report["content_hash"]=selection.routing_reevaluation.content_hash(report)
        with self.assertRaises(ValueError):
            selection.select(report,self.impact(),registry=self.registry())


if __name__=="__main__":
    unittest.main()
