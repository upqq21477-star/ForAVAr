#!/usr/bin/env python3
from __future__ import annotations
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))
import actions_execution_truth_adapter as adapter

HEAD = "a" * 40

def diagnostic():
    return {
        "diagnostic_id": "ACTIONS_DIAGNOSTIC:37180388978",
        "run_status": "completed",
        "run_conclusion": "failure",
        "head_sha": HEAD,
        "classification": "RUNNER_STARTUP_FAILURE",
        "job_count": 1,
        "jobs": [{
            "job_id": 111371604817,
            "name": "control-gate",
            "status": "completed",
            "conclusion": "failure",
            "runner_id": None,
            "runner_name": "",
            "runner_group_id": None,
            "steps_evidence": "NULL",
            "step_count": 0,
            "classification": "RUNNER_STARTUP_FAILURE",
            "labels": ["ubuntu-latest"],
            "started_at": None,
            "completed_at": None,
            "elapsed_seconds": None,
        }],
        "evidence": {
            "runner_assigned": False,
            "step_execution_observed": False,
            "logs_available": False,
        },
    }

def closure(program_truth="PROGRAM_VERIFIED", head_sha=HEAD):
    return {
        "closure_id": "ACTIONS_CLOSURE:37180388978",
        "external_classification": "RUNNER_STARTUP_FAILURE",
        "local_acceptance_status": "PASS" if program_truth == "PROGRAM_VERIFIED" else "INCOMPLETE",
        "closure_status": "VERIFIED" if program_truth == "PROGRAM_VERIFIED" else "INCOMPLETE",
        "program_truth": program_truth,
        "head_sha": head_sha,
        "evidence_refs": ["ACTIONS_DIAGNOSTIC:37180388978", "LOCAL_ACCEPTANCE:37180388978"],
        "reason_code": "LOCAL_CONFIRMS_RUNNER_FAILURE_ONLY",
    }

class ActionsExecutionTruthAdapterTests(unittest.TestCase):
    def test_runner_failure_plus_local_pass_becomes_pass_truth(self):
        result = adapter.build(diagnostic(), closure(), head_sha=HEAD, observed_at="2026-10-04T00:00:00Z")
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["program_truth"], "PROGRAM_VERIFIED")
        self.assertEqual(result["runtime_run_id"], 37180388978)
        self.assertFalse(result["step_execution_observed"])

    def test_regression_truth_maps_to_fail(self):
        item = closure("PROGRAM_REGRESSION")
        item["closure_status"] = "PROGRAM_REGRESSION_FAIL"
        item["reason_code"] = "LOCAL_ACCEPTANCE_FAILED"
        result = adapter.build(diagnostic(), item, head_sha=HEAD)
        self.assertEqual(result["status"], "FAIL")

    def test_unresolved_truth_does_not_become_fail(self):
        item = closure("PROGRAM_UNRESOLVED")
        result = adapter.build(diagnostic(), item, head_sha=HEAD)
        self.assertEqual(result["status"], "INCOMPLETE")

    def test_mismatched_closure_head_is_rejected(self):
        item = closure(head_sha="b" * 40)
        with self.assertRaisesRegex(ValueError, "CLOSURE_HEAD_SHA_MISMATCH"):
            adapter.build(diagnostic(), item, head_sha=HEAD)

if __name__ == "__main__":
    unittest.main(verbosity=2)
