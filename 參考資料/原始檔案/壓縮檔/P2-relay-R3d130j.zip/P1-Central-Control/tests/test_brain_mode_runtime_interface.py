from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import central_role_interface  # noqa: E402
import run_p2_validation_cycle  # noqa: E402
from brain_mode_controller import PLAN_GATE_KEYS, initial_control_state  # noqa: E402
from _pending_repo import pending_root  # noqa: E402


def _request(operation: str, role_id: str, **kwargs) -> dict:
    request = {
        "request_id": f"TEST:{operation}:{role_id}",
        "operation": operation,
        "role_id": role_id,
    }
    request.update(kwargs)
    return request


def _prepare_root(
    root: Path,
    *,
    mode: str,
    stage_status: str = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
    work_status: str = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
    construction_status: str = "IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE",
    plan_approved: bool = False,
    feature_batch_complete: bool = False,
    simulation_batch_passed: bool = False,
) -> tuple[Path, Path]:
    current_path = root / "P1-CURRENT.json"
    current = json.loads(current_path.read_text(encoding="utf-8"))
    current["current_stage"]["status"] = stage_status
    work_ref = current["implementation_control"]["active_work_packet"]
    construction_ref = current["implementation_control"]["active_construction_packet"]
    work_path = root / work_ref
    construction_path = root / construction_ref
    work = json.loads(work_path.read_text(encoding="utf-8"))
    construction = json.loads(construction_path.read_text(encoding="utf-8"))
    work["status"] = work_status
    construction["status"] = construction_status
    control = initial_control_state()
    control.update(
        mode=mode,
        plan_approved=plan_approved,
        plan_gates={key: True for key in PLAN_GATE_KEYS},
        plan_evidence={key: f"Reviewed current evidence for {key}." for key in PLAN_GATE_KEYS},
        feature_batch_complete=feature_batch_complete,
        simulation_batch_passed=simulation_batch_passed,
        last_transition=None,
    )
    work["brain_mode_control"] = control
    work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    construction_path.write_text(
        json.dumps(construction, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    current_path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return work_path, construction_path


class BrainModeRuntimeInterfaceTests(unittest.TestCase):
    def setUp(self):
        if self._testMethodName == "test_final_batch_ready_requires_explicit_completion_and_simulation":
            self._root_temporary = tempfile.TemporaryDirectory(prefix="p2-operational-acceptance-test-")
            self.root = Path(self._root_temporary.name) / "repo"
            shutil.copytree(
                pending_root(),
                self.root,
                ignore=shutil.ignore_patterns("__pycache__", ".git"),
            )
            self.addCleanup(self._root_temporary.cleanup)
        else:
            self.root = pending_root()

    def test_central_interface_persists_thinking_plan_and_construction_modes(self):
        work_path, _ = _prepare_root(self.root, mode="THINKING")
        work = json.loads(work_path.read_text(encoding="utf-8"))
        control = work["brain_mode_control"]
        control["plan_evidence"] = {key: "" for key in PLAN_GATE_KEYS}
        control["plan_gates"] = {key: False for key in PLAN_GATE_KEYS}
        control["plan_approved"] = False
        work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        blocked = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="THINKING_COMPLETE",
            ),
            self.root,
        )
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertEqual(blocked["transition"]["reason_code"], "PLAN_GATE_INCOMPLETE")

        plan_evidence = {
            "objective": "Goal and expected outcome are explicit.",
            "scope": "Exact files and boundaries are identified.",
            "change_set": "Required source and schema changes are enumerated.",
            "acceptance_criteria": "Observable final checks are specified.",
            "risk_recovery": "Failure handling and recovery are defined.",
            "cost_authority": "Execution authority and cost boundaries are confirmed.",
            "stop_conditions": "Stop conditions are explicit.",
        }
        first = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="THINKING_COMPLETE",
                plan_evidence=plan_evidence,
            ),
            self.root,
        )
        self.assertEqual(first["status"], "PASS")
        self.assertEqual(first["transition"]["mode"], "PLAN_READY")

        second = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="PLAN_APPROVED",
            ),
            self.root,
        )
        self.assertEqual(second["status"], "PASS")
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertEqual(saved["mode"], "CONSTRUCTION")
        self.assertTrue(saved["plan_approved"])
        self.assertEqual(saved["last_transition"]["role_id"], "ROLE:CONTROL_RESEARCH")

        failure = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="HYPOTHESIS_FAILED",
            ),
            self.root,
        )
        self.assertEqual(failure["status"], "PASS")
        self.assertEqual(failure["transition"]["mode"], "THINKING")
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertFalse(saved["plan_approved"])
        self.assertTrue(all(value is False for value in saved["plan_gates"].values()))
        self.assertTrue(all(value == "" for value in saved["plan_evidence"].values()))

    def test_executor_cannot_approve_plan(self):
        _prepare_root(self.root, mode="PLAN_READY")
        result = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:EXECUTOR",
                cognitive_event="PLAN_APPROVED",
            ),
            self.root,
        )
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("COGNITIVE_EVENT_NOT_ALLOWED_FOR_ROLE", result["reason_codes"])

        # The legacy M32 Task Packet must never enter the new Operational
        # Work Unit final-batch acceptance bridge.
        with patch("central_role_interface._validate_final_batch_report") as report_validator:
            legacy_final = central_role_interface.execute(
                _request(
                    "COGNITIVE_TRANSITION",
                    "ROLE:CONTROL_RESEARCH",
                    cognitive_event="FINAL_BATCH_READY",
                    feature_batch_complete=True,
                    simulation_report_ref="P1-Central-Control/acceptance/reports/P2-B2.2-final-integration.json",
                ),
                self.root,
            )
        self.assertEqual(legacy_final["status"], "BLOCK")
        self.assertIn(
            "OPERATIONAL_WORK_UNIT_REQUIRED_FOR_FINAL_BATCH",
            legacy_final["reason_codes"],
        )
        report_validator.assert_not_called()

    def test_work_complete_enters_local_simulation_without_formal_acceptance(self):
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=True,
        )
        # A stale CONSTRUCTION label without plan evidence is not authority.
        work = json.loads(work_path.read_text(encoding="utf-8"))
        control = work["brain_mode_control"]
        control["plan_evidence"] = {key: "" for key in PLAN_GATE_KEYS}
        control["plan_gates"] = {key: False for key in PLAN_GATE_KEYS}
        control["plan_approved"] = False
        work_path.write_text(json.dumps(work, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        denied = central_role_interface.execute(
            _request(
                "SUBMIT_ROLE_RESULT",
                "ROLE:EXECUTOR",
                result_ref="RESULT:UNAUTHORIZED-COMPLETE",
                result_status="WORK_COMPLETE",
                final_batch_acceptance=False,
            ),
            self.root,
        )
        self.assertEqual(denied["status"], "BLOCK")
        self.assertTrue(denied["recovery_state_persisted"])
        self.assertEqual(denied["cognitive_transition"]["mode"], "THINKING")
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertEqual(saved["mode"], "THINKING")
        self.assertTrue(all(value is False for value in saved["plan_gates"].values()))
        self.assertTrue(all(value == "" for value in saved["plan_evidence"].values()))

        # An admitted construction slice completes into local simulation, never formal acceptance.
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=True,
        )
        result = central_role_interface.execute(
            _request(
                "SUBMIT_ROLE_RESULT",
                "ROLE:EXECUTOR",
                result_ref="RESULT:FEATURE-SLICE-1",
                result_status="WORK_COMPLETE",
                final_batch_acceptance=False,
            ),
            self.root,
        )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["next_action"], "LOCAL_CASE_SIMULATION_REQUIRED")
        self.assertFalse(result["formal_acceptance_created"])
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertEqual(saved["mode"], "SIMULATION")

        # A passing slice simulation returns to THINKING and withdraws the prior approval.
        passed = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:EXECUTOR",
                cognitive_event="SIMULATION_PASSED",
            ),
            self.root,
        )
        self.assertEqual(passed["status"], "PASS")
        self.assertEqual(passed["transition"]["reason_code"], "STEP_SIMULATION_PASSED_RETURN_TO_THINKING")
        self.assertEqual(passed["transition"]["mode"], "THINKING")
        self.assertTrue(passed["transition"]["construction_paused"])
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertEqual(saved["mode"], "THINKING")
        self.assertFalse(saved["plan_approved"])
        self.assertTrue(all(value is False for value in saved["plan_gates"].values()))
        self.assertTrue(all(value == "" for value in saved["plan_evidence"].values()))

        # Every new construction slice requires fresh evidence-bearing thought.
        plan_evidence = {
            "objective": "Goal and expected outcome remain explicit.",
            "scope": "Exact files and allowed change boundary are rechecked.",
            "change_set": "The next change set is reviewed before implementation.",
            "acceptance_criteria": "Observable acceptance conditions are restated.",
            "risk_recovery": "Failure recovery and rollback constraints are reviewed.",
            "cost_authority": "Execution authority and cost limits are reconfirmed.",
            "stop_conditions": "The conditions that stop work are restated.",
        }
        thought = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="THINKING_COMPLETE",
                plan_evidence=plan_evidence,
            ),
            self.root,
        )
        self.assertEqual(thought["status"], "PASS")
        self.assertEqual(thought["transition"]["mode"], "PLAN_READY")
        approval = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="PLAN_APPROVED",
            ),
            self.root,
        )
        self.assertEqual(approval["status"], "PASS")
        self.assertEqual(approval["transition"]["mode"], "CONSTRUCTION")
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertTrue(saved["plan_approved"])

        # The next construction slice still follows the same local simulation route.
        result_again = central_role_interface.execute(
            _request(
                "SUBMIT_ROLE_RESULT",
                "ROLE:EXECUTOR",
                result_ref="RESULT:FEATURE-SLICE-2",
                result_status="WORK_COMPLETE",
                final_batch_acceptance=False,
            ),
            self.root,
        )
        self.assertEqual(result_again["status"], "PASS")
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertEqual(saved["mode"], "SIMULATION")

        failed = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:EXECUTOR",
                cognitive_event="SIMULATION_FAILED",
            ),
            self.root,
        )
        self.assertEqual(failed["status"], "PASS")
        self.assertEqual(failed["transition"]["mode"], "THINKING")
        self.assertTrue(failed["transition"]["research_recommended"])
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertEqual(saved["mode"], "THINKING")
        self.assertFalse(saved["plan_approved"])
        self.assertTrue(all(value is False for value in saved["plan_gates"].values()))
        self.assertTrue(all(value == "" for value in saved["plan_evidence"].values()))

    def test_final_batch_ready_requires_explicit_completion_and_simulation(self):
        # This path must exercise B2.2's Operational Work Unit, not the legacy
        # M32 Task Packet reused by the other role-interface compatibility cases.
        current_path = self.root / "P1-CURRENT.json"
        current_path.write_bytes((ROOT / "P1-CURRENT.json").read_bytes())
        work_path, _ = _prepare_root(
            self.root,
            mode="CONSTRUCTION",
            stage_status="IN_PROGRESS",
            work_status="IN_PROGRESS",
            construction_status="BUILDING",
            plan_approved=True,
        )
        current = json.loads(current_path.read_text(encoding="utf-8"))
        work_doc = json.loads(work_path.read_text(encoding="utf-8"))
        construction_path = self.root / current["implementation_control"]["active_construction_packet"]
        construction_doc = json.loads(construction_path.read_text(encoding="utf-8"))

        # Model an Operational Work Unit before its first formal close attempt.
        current["current_stage"].pop("acceptance_ref", None)
        current["current_stage"].pop("acceptance_mode", None)
        current_path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        blocked = central_role_interface.execute(
            _request(
                "COGNITIVE_TRANSITION",
                "ROLE:CONTROL_RESEARCH",
                cognitive_event="FINAL_BATCH_READY",
                feature_batch_complete=False,
            ),
            self.root,
        )
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertIn("FEATURE_BATCH_COMPLETION_NOT_CONFIRMED", blocked["reason_codes"])

        # Unsafe Work Unit IDs cannot be used to construct acceptance-context paths.
        original_unit = current["current_stage"].get("work_unit_id") or current["current_stage"]["id"]
        current["current_stage"]["work_unit_id"] = "../outside"
        work_doc["work_unit"] = "../outside"
        # Keep the contract consistent with work_unit so the feature-batch ID check passes
        # and the acceptance-context path check is the one under test.
        work_doc["operational_contract"]["work_unit_id"] = "../outside"
        construction_doc["work_segment_ref"] = "../outside"
        work_path.write_text(json.dumps(work_doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        construction_path.write_text(json.dumps(construction_doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        current_path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        report_evidence = {
            "status": "PASS",
            "report_ref": "P1-Central-Control/acceptance/reports/P2-B2.2-final-integration.json",
            "repository_commit": "a" * 40,
            "report_sha256": "sha256:" + "b" * 64,
            "expected_test_method_count": 102,
            "actual_test_method_count": 102,
            "canonical_pack_write_outcome": "WRITTEN",
        }
        with (
            patch("central_role_interface._role_request", return_value={"status": "PASS"}),
            patch("central_role_interface.validate_final_test_gate", return_value={"required": False}),
            patch("central_role_interface._validate_final_batch_report", return_value=report_evidence),
            patch("central_role_interface._missing_batch_outputs", return_value=[]),
        ):
            unsafe = central_role_interface.execute(
                _request(
                    "COGNITIVE_TRANSITION",
                    "ROLE:CONTROL_RESEARCH",
                    cognitive_event="FINAL_BATCH_READY",
                    feature_batch_complete=True,
                    simulation_report_ref="P1-Central-Control/acceptance/reports/P2-B2.2-final-integration.json",
                ),
                self.root,
            )
        self.assertEqual(unsafe["status"], "BLOCK")
        self.assertIn("ACCEPTANCE_WORK_UNIT_ID_UNSAFE", unsafe.get("detail", ""))
        self.assertFalse((self.root / "outside.operational-acceptance.json").exists())

        current["current_stage"]["work_unit_id"] = original_unit
        work_doc["work_unit"] = original_unit
        work_doc["operational_contract"]["work_unit_id"] = original_unit
        construction_doc["work_segment_ref"] = original_unit
        work_path.write_text(json.dumps(work_doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        construction_path.write_text(json.dumps(construction_doc, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        current_path.write_text(json.dumps(current, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        with (
            patch("central_role_interface.validate_final_test_gate", return_value={"required": False}),
            patch("central_role_interface._validate_final_batch_report", return_value=report_evidence),
            patch("central_role_interface._missing_batch_outputs", return_value=[]),
        ):
            ready = central_role_interface.execute(
                _request(
                    "COGNITIVE_TRANSITION",
                    "ROLE:CONTROL_RESEARCH",
                    cognitive_event="FINAL_BATCH_READY",
                    feature_batch_complete=True,
                    simulation_report_ref="P1-Central-Control/acceptance/reports/P2-B2.2-final-integration.json",
                ),
                self.root,
            )
        self.assertEqual(ready["status"], "PASS")
        self.assertEqual(ready["transition"]["mode"], "FINAL_ACCEPTANCE")
        self.assertEqual(
            ready["acceptance_ref"],
            f"P1-Central-Control/acceptance/{original_unit}.operational-acceptance.json",
        )
        current_after = json.loads(current_path.read_text(encoding="utf-8"))
        self.assertEqual(current_after["current_stage"]["status"], "READY_FOR_CLOSE_ACCEPTANCE")
        self.assertEqual(current_after["current_stage"]["acceptance_ref"], ready["acceptance_ref"])
        self.assertTrue((self.root / ready["acceptance_ref"]).is_file())

        with patch("central_role_interface._validate_final_batch_report", return_value=report_evidence):
            verifier_context = central_role_interface.execute(
                _request("GET_ROLE_CONTEXT", "ROLE:VERIFIER"),
                self.root,
            )
        self.assertEqual(verifier_context["status"], "PASS")
        self.assertEqual(
            verifier_context["acceptance"]["context"]["kind"],
            "OPERATIONAL_ACCEPTANCE_CONTEXT",
        )
        saved = json.loads(work_path.read_text(encoding="utf-8"))["brain_mode_control"]
        self.assertTrue(saved["feature_batch_complete"])
        self.assertTrue(saved["simulation_batch_passed"])

        with (
            patch("central_role_interface._role_request", return_value={"status": "PASS"}),
            patch("central_role_interface._validate_final_batch_report", return_value=report_evidence),
        ):
            verdict = central_role_interface.execute(
                _request(
                    "SUBMIT_ROLE_RESULT",
                    "ROLE:VERIFIER",
                    result_ref="RESULT:FINAL-BATCH-VERIFIER",
                    result_status="PASS",
                    acceptance_ref=ready["acceptance_ref"],
                    head_sha=report_evidence["repository_commit"],
                ),
                self.root,
            )
        self.assertEqual(verdict["status"], "PASS")
        persisted_work = json.loads(work_path.read_text(encoding="utf-8"))
        persisted_construction = json.loads(construction_path.read_text(encoding="utf-8"))
        persisted_current = json.loads(current_path.read_text(encoding="utf-8"))
        self.assertEqual(persisted_work["status"], "VERIFIED")
        self.assertEqual(persisted_work["current_result"]["code_status"], "VERIFIED")
        self.assertEqual(persisted_work["current_result"]["python_tests"], "PASS_102_OF_102")
        # B2.2 only proves its declared batch and Pack layer; do not upgrade B1→B7.
        self.assertEqual(persisted_work["current_result"]["runtime_truth"], "INCOMPLETE")
        self.assertEqual(persisted_construction["status"], "VERIFIED")
        self.assertNotIn("implementation_step", persisted_construction)
        self.assertNotIn("next_action", persisted_construction)
        self.assertTrue(
            any(
                note.startswith("B2.2 lifecycle:")
                and "global Runtime remains INCOMPLETE" in note
                for note in persisted_construction["handoff"]["notes"]
            )
        )
        self.assertEqual(persisted_current["current_stage"]["status"], "VERIFIED")
        self.assertIn("full B1→B7", persisted_current["current_stage"]["operational_result"])
        accepted_context = json.loads((self.root / ready["acceptance_ref"]).read_text(encoding="utf-8"))
        self.assertEqual(accepted_context["status"], "ACCEPTED")


    def test_final_batch_report_binds_real_git_head_and_exact_suite_evidence(self):
        # Runner, Pack Builder and Central must resolve migrated Work Unit identity identically.
        self.assertEqual(central_role_interface._stage_work_unit_id({"id": "STAGE-ID"}), "STAGE-ID")
        self.assertEqual(
            central_role_interface._stage_work_unit_id({"id": "STAGE-ID", "slice_id": "SLICE-ID"}),
            "SLICE-ID",
        )
        self.assertEqual(
            central_role_interface._stage_work_unit_id(
                {"id": "STAGE-ID", "slice_id": "SLICE-ID", "work_unit_id": ""}
            ),
            "SLICE-ID",
        )
        self.assertIsNone(
            central_role_interface._stage_work_unit_id(
                {"id": "STAGE-ID", "slice_id": "SLICE-ID", "work_unit_id": "   "}
            )
        )
        self.assertEqual(
            central_role_interface._stage_work_unit_id(
                {"id": "STAGE-ID", "slice_id": "SLICE-ID", "work_unit_id": "WORK-UNIT"}
            ),
            "WORK-UNIT",
        )
        self.assertIsNone(central_role_interface._stage_work_unit_id({}))
        self.assertIsNone(
            central_role_interface._stage_work_unit_id(
                {"work_unit_id": ["MALFORMED"], "slice_id": "SLICE-ID", "id": "STAGE-ID"}
            )
        )
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            subprocess.run(["git", "init", "-q"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.name", "P2 Test"], cwd=root, check=True)
            subprocess.run(["git", "config", "user.email", "p2-test@example.invalid"], cwd=root, check=True)
            (root / "anchor.txt").write_text("committed source\n", encoding="utf-8")
            current_fixture = {
                "current_stage": {"id": "P2-B2.2", "work_unit_id": "P2-B2.2"},
                "implementation_control": {
                    "active_work_packet": "P1-Central-Control/progress/P2-B2.2.work.json",
                    "active_construction_packet": "P1-Central-Control/progress/construction/P2-B2.2.construction.json",
                },
            }
            (root / "P1-CURRENT.json").write_text(
                json.dumps(current_fixture) + "\n", encoding="utf-8"
            )
            work_ref = Path("P1-Central-Control/progress/P2-B2.2.work.json")
            construction_ref = Path("P1-Central-Control/progress/construction/P2-B2.2.construction.json")
            (root / work_ref).parent.mkdir(parents=True, exist_ok=True)
            (root / construction_ref).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / work_ref, root / work_ref)
            shutil.copyfile(ROOT / construction_ref, root / construction_ref)
            # The final-test gate validates the active work packet against this schema.
            schema_ref = Path("P1-Central-Control/schemas/operational_work_unit.schema.json")
            (root / schema_ref).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(ROOT / schema_ref, root / schema_ref)
            (root / ".gitignore").write_text(
                "P1-Central-Control/acceptance/reports/*.json\n"
                "P1-Central-Control/canonical/operational_reference_pack.json\n",
                encoding="utf-8",
            )
            subprocess.run(
                ["git", "add", "anchor.txt", "P1-CURRENT.json", ".gitignore", str(work_ref), str(construction_ref), str(schema_ref)],
                cwd=root,
                check=True,
            )
            subprocess.run(["git", "commit", "-qm", "fixture"], cwd=root, check=True)
            head = subprocess.run(
                ["git", "rev-parse", "HEAD"], cwd=root, text=True,
                capture_output=True, check=True,
            ).stdout.strip()

            report_ref = "P1-Central-Control/acceptance/reports/final-integration.json"
            report_path = root / report_ref
            report_path.parent.mkdir(parents=True)
            canonical = root / "P1-Central-Control/canonical/operational_reference_pack.json"
            canonical.parent.mkdir(parents=True)
            canonical.write_text("{}\n", encoding="utf-8")
            canonical_hash = "sha256:" + hashlib.sha256(canonical.read_bytes()).hexdigest()
            counts = {
                "P1-Central-Control/tests/test_continuation_context_box.py": 11,
                "P1-Central-Control/tests/test_knowledge_retrieval.py": 18,
                "P1-Central-Control/tests/test_operational_reference_pack.py": 35,
                "P1-Central-Control/tests/test_current_projection_sync.py": 3,
                "P1-Central-Control/tests/test_run_p2_validation.py": 15,
                "P1-Central-Control/tests/test_brain_mode_controller.py": 15,
                "P1-Central-Control/tests/test_brain_mode_runtime_interface.py": 5,
            }
            report = {
                "report_schema_version": "2.1",
                "mode": "integration",
                "status": "PACK_INTEGRATION_PASS",
                "repository_commit": head,
                "repository_worktree_clean_at_start": True,
                "preflight": {
                    "status": "PREFLIGHT_PASS",
                    "current_stage_id": "P2-B2.2",
                    "current_stage_acceptance": None,
                    "current_stage_regression_tests": None,
                    "current_blueprint_ref": None,
                    "active_work_ref": "P1-Central-Control/progress/P2-B2.2.work.json",
                    "active_work_unit": "P2-B2.2",
                    "active_construction_ref": "P1-Central-Control/progress/construction/P2-B2.2.construction.json",
                    "active_construction_packet_id": "CONSTRUCTION:P2-B2.2",
                    "active_work_contract_sha256": central_role_interface._active_work_contract_sha256(
                        json.loads((root / work_ref).read_text(encoding="utf-8"))
                    ),
                    "active_construction_contract_sha256": central_role_interface._active_construction_contract_sha256(
                        json.loads((root / construction_ref).read_text(encoding="utf-8"))
                    ),
                },
                "expected_test_method_count": 102,
                "actual_test_method_count": 102,
                "pinned_dependencies": {"status": "MATCH"},
                "steps": [
                    {
                        "name": name,
                        "status": "PASS",
                        "expected_test_count": count,
                        "actual_test_count": count,
                    }
                    for name, count in counts.items()
                ],
                "check_only_result": {"status": "READY", "write_performed": False},
                "canonical_pack_write_outcome": "WRITTEN",
                "canonical_pack_write_occurred": True,
                "canonical_pack_sha256": canonical_hash,
                "canonical_verify_result": {"status": "VERIFIED"},
                "canonical_idempotency_result": {"status": "UNCHANGED"},
            }
            report_path.write_text(json.dumps(report), encoding="utf-8")
            simulation = {
                "status": "SIMULATION_PASS",
                "repository_commit": head,
                "expected_test_method_count": 102,
                "actual_test_method_count": 102,
            }
            with (
                patch.object(run_p2_validation_cycle, "ROOT", root),
                patch.object(run_p2_validation_cycle, "FINAL_INTEGRATION_REPORT", report_ref),
            ):
                rejected, reject_reason = run_p2_validation_cycle.seal_cycle_gate_evidence(
                    simulation,
                    report,
                    simulation_exit_code=2,
                    integration_exit_code=0,
                )
                self.assertFalse(rejected)
                self.assertEqual(reject_reason, "FINAL_CYCLE_EXIT_CODE_NOT_ZERO")
                sealed, seal_reason = run_p2_validation_cycle.seal_cycle_gate_evidence(
                    simulation,
                    report,
                    simulation_exit_code=0,
                    integration_exit_code=0,
                )
            self.assertTrue(sealed, seal_reason)
            report = json.loads(report_path.read_text(encoding="utf-8"))
            self.assertEqual(report["cycle_gate_evidence"]["status"], "P2_PACK_CYCLE_PASS")
            verified = central_role_interface._validate_final_batch_report(root, report_ref)
            self.assertEqual(verified["status"], "PASS")
            self.assertEqual(verified["repository_commit"], head)
            self.assertEqual(verified["actual_test_method_count"], 102)

            # A report cannot be reused after Current changes its acceptance contract.
            current_after_valid = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
            current_after_valid["current_stage"]["acceptance"] = "changed after Integration"
            (root / "P1-CURRENT.json").write_text(
                json.dumps(current_after_valid) + "\n", encoding="utf-8"
            )
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_CURRENT_AUTHORITY_DRIFT"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            current_after_valid["current_stage"].pop("acceptance")
            (root / "P1-CURRENT.json").write_text(
                json.dumps(current_after_valid) + "\n", encoding="utf-8"
            )

            # A report cannot be reused after Current changes the selected Work Unit.
            current_after_valid = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
            # The drift case needs a *valid* but different active packet; a missing file is
            # rejected earlier by the feature-batch gate (BATCH_FILE_MISSING), never reaching the drift check.
            shutil.copyfile(root / work_ref, root / "P1-Central-Control/progress/other.work.json")
            current_after_valid["implementation_control"]["active_work_packet"] = (
                "P1-Central-Control/progress/other.work.json"
            )
            (root / "P1-CURRENT.json").write_text(
                json.dumps(current_after_valid) + "\n", encoding="utf-8"
            )
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_CURRENT_AUTHORITY_DRIFT"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            (root / "P1-Central-Control/progress/other.work.json").unlink()
            current_after_valid["implementation_control"]["active_work_packet"] = (
                "P1-Central-Control/progress/P2-B2.2.work.json"
            )
            (root / "P1-CURRENT.json").write_text(
                json.dumps(current_after_valid) + "\n", encoding="utf-8"
            )

            # JSON booleans compare equal to integers in Python; exit-code gates
            # must require actual integer zero, not JSON false.
            valid_report = json.loads(json.dumps(report))
            valid_report["cycle_gate_evidence"]["simulation_exit_code"] = False
            report_path.write_text(json.dumps(valid_report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_CYCLE_GATE_EVIDENCE_INVALID"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            report_path.write_text(json.dumps(report), encoding="utf-8")

            # Current and the report-bound acceptance context may legitimately
            # change after final integration as the independent-verifier lifecycle runs.
            context_ref = "P1-Central-Control/acceptance/M32-CLOSE.operational-acceptance.json"
            (root / "P1-Central-Control/acceptance").mkdir(parents=True, exist_ok=True)
            (root / context_ref).write_text("{}\n", encoding="utf-8")
            updated_current = json.loads((root / "P1-CURRENT.json").read_text(encoding="utf-8"))
            updated_current["current_stage"]["acceptance_ref"] = context_ref
            (root / "P1-CURRENT.json").write_text(
                json.dumps(updated_current) + "\n",
                encoding="utf-8",
            )
            self.assertEqual(
                central_role_interface._validate_final_batch_report(root, report_ref)["status"],
                "PASS",
            )

            # Lifecycle-only state changes and Central-owned notes are allowed;
            # the stable plan/scope/acceptance contract must remain identical.
            baseline_work_document = json.loads((root / work_ref).read_text(encoding="utf-8"))
            baseline_construction_document = json.loads((root / construction_ref).read_text(encoding="utf-8"))
            lifecycle_work = json.loads(json.dumps(baseline_work_document))
            lifecycle_work.update(
                status="READY_FOR_CLOSE_ACCEPTANCE",
                implementation_step="READY_FOR_CLOSE_ACCEPTANCE",
                next_action="Await independent Verifier.",
                current_result={
                    "code_status": "PROGRAM_EXECUTED_PASS",
                    "python_tests": "PASS_102_OF_102",
                    "formal_caller": "WIRED",
                    "active_pack": "CANONICAL_PACK_VERIFIED_IDEMPOTENT",
                    "runtime_truth": "INCOMPLETE",
                    "known_execution_blocker": "Verifier pending.",
                },
                brain_mode_control={**initial_control_state(), "mode": "FINAL_ACCEPTANCE", "final_batch_report_ref": report_ref},
            )
            lifecycle_work["handoff"]["next_step"] = "Await independent Verifier."
            (root / work_ref).write_text(json.dumps(lifecycle_work) + "\n", encoding="utf-8")
            lifecycle_construction = json.loads(json.dumps(baseline_construction_document))
            lifecycle_construction["status"] = "READY_FOR_CLOSE_ACCEPTANCE"
            lifecycle_construction["handoff"]["notes"].append(
                "B2.2 lifecycle: Await independent Verifier."
            )
            (root / construction_ref).write_text(json.dumps(lifecycle_construction) + "\n", encoding="utf-8")
            self.assertEqual(
                central_role_interface._validate_final_batch_report(root, report_ref)["status"],
                "PASS",
            )
            (root / work_ref).write_text(json.dumps(baseline_work_document) + "\n", encoding="utf-8")
            (root / construction_ref).write_text(json.dumps(baseline_construction_document) + "\n", encoding="utf-8")

            # Edits to Work scope or Construction contract must invalidate a report.
            work_document = json.loads((root / work_ref).read_text(encoding="utf-8"))
            work_document["objective"] = "tampered after Integration"
            (root / work_ref).write_text(json.dumps(work_document) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_ACTIVE_WORK_CONTRACT_DRIFT"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            work_document["objective"] = json.loads((ROOT / work_ref).read_text(encoding="utf-8"))["objective"]
            (root / work_ref).write_text(json.dumps(work_document) + "\n", encoding="utf-8")

            construction_document = json.loads((root / construction_ref).read_text(encoding="utf-8"))
            construction_document["objective"] = "tampered after Integration"
            (root / construction_ref).write_text(json.dumps(construction_document) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_ACTIVE_CONSTRUCTION_CONTRACT_DRIFT"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            construction_document["objective"] = json.loads(
                (ROOT / construction_ref).read_text(encoding="utf-8")
            )["objective"]
            (root / construction_ref).write_text(json.dumps(construction_document) + "\n", encoding="utf-8")

            # The Pack is ignored by Git, so its bytes need their own report binding.
            canonical.write_text('{"changed":true}\n', encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_CANONICAL_PACK_HASH_MISMATCH"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            canonical.write_text("{}\n", encoding="utf-8")

            # A report bound to the right HEAD is still rejected if source changes.
            (root / "anchor.txt").write_text("uncommitted source\n", encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_SOURCE_TREE_CHANGED"):
                central_role_interface._validate_final_batch_report(root, report_ref)
            (root / "anchor.txt").write_text("committed source\n", encoding="utf-8")

            report["repository_commit"] = "0" * 40
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_REPORT_HEAD_MISMATCH"):
                central_role_interface._validate_final_batch_report(root, report_ref)

            report["repository_commit"] = head
            report.pop("cycle_gate_evidence")
            report_path.write_text(json.dumps(report), encoding="utf-8")
            with self.assertRaisesRegex(ValueError, "FINAL_BATCH_CYCLE_GATE_EVIDENCE_MISSING"):
                central_role_interface._validate_final_batch_report(root, report_ref)




if __name__ == "__main__":
    unittest.main()
