from __future__ import annotations
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"P1-Central-Control/scripts"))
import central_role_interface as central

class CentralFeatureDecisionRouteTests(unittest.TestCase):
    def test_presentation_decision_is_refused_after_f27_archive(self):
        result=central.execute({
            "request_id":"F27-CENTRAL-NORMAL",
            "operation":"PRESENTATION_DECISION",
            "role_id":"ROLE:EXECUTOR",
            "presentation_request":{
                "decision_id":"F27-CENTRAL-NORMAL",
                "task":"Explain workflow state transitions",
                "task_kind":"process",
                "source_refs":["docs/architecture/P2-System-Blueprint-v1.0.md"],
                "facts":[{"status":"CONFIRMED","statement":"Local simulation follows construction."}]
            }
        },ROOT)
        # Original expectation (PASS + flowchart) required presentation_selector.
        # F27 was archived in R3d3, so routing can no longer succeed; the
        # contract is now an explicit, stable refusal instead of an import error.
        self.assertEqual(result["status"],"BLOCK")
        self.assertFalse(result["accepted"])
        self.assertEqual(result["reason_codes"],["PRESENTATION_ARCHIVED"])

    def test_change_classification_requires_brain_control_authority(self):
        result=central.execute({
            "request_id":"F28-CENTRAL-NEGATIVE",
            "operation":"CHANGE_CLASSIFICATION",
            "role_id":"ROLE:EXECUTOR",
            "change_request":{
                "change_id":"F28-CENTRAL-NEGATIVE",
                "statement":"This change appears systemic.",
                "affected_scope":"MULTI_DOMAIN",
                "confirmed_reusable_mechanism":True,
                "evidence_refs":["evidence/root-cause.json"],
                "evidence":[{"kind":"CONFIRMED","statement":"Confirmed across domains."}],
                "target_kinds":["contract"],
                "authoritative_targets":[],
                "candidate_derived_views":[]
            }
        },ROOT)
        self.assertEqual(result["status"],"BLOCK")
        self.assertIn("CHANGE_CLASSIFICATION_ROLE_FORBIDDEN",result["reason_codes"])

    def test_authorized_change_classification_returns_evidence_bound_route(self):
        result=central.execute({
            "request_id":"F28-CENTRAL-BOUNDARY",
            "operation":"CHANGE_CLASSIFICATION",
            "role_id":"ROLE:CONTROL_RESEARCH",
            "change_request":{
                "change_id":"F28-CENTRAL-BOUNDARY",
                "statement":"A confirmed reusable mechanism affects multiple P2 domains.",
                "affected_scope":"MULTI_DOMAIN",
                "confirmed_reusable_mechanism":True,
                "evidence_refs":["evidence/root-cause.json"],
                "evidence":[{"kind":"CONFIRMED","statement":"Same mechanism reproduced across domains."}],
                "target_kinds":["contract"],
                "authoritative_targets":["docs/architecture/P2-System-Blueprint-v1.0.md"],
                "candidate_derived_views":["docs/plans/P2-Relay-Update-Plan.md"]
            }
        },ROOT)
        self.assertEqual(result["status"],"PASS")
        self.assertEqual(result["classification_record"]["classification"],"SYSTEMIC_CAPABILITY")
        self.assertFalse(result["state_written"])



    def test_blueprint_update_assessment_is_brain_only_read_only_and_ranked(self):
        payload = {
            "request_id": "F28-BLUEPRINT-ROUTE",
            "impact_matrix": [
                {
                    "path": path, "disposition": "NO_REWORK_REQUIRED",
                    "owner": "ROLE:CONTROL_RESEARCH",
                    "current_evidence": "Current source path has been read from the active repository branch.",
                    "reason": "This read-only ranking request does not propose a change to this path.",
                    "required_action": "No rework in this assessment; revisit if a ranked requirement affects this path.",
                    "evidence_invalidation": [],
                    "unlock_condition": "Source remains unchanged and the disposition is confirmed."
                }
                for path in (
                    "P1-CURRENT.json",
                    "docs/architecture/P2-System-Blueprint-v1.0.md",
                    "docs/plans/P2-Relay-Update-Plan.md",
                    "P1-Central-Control/progress/P2-B1-B8.work.json",
                    "P1-Central-Control/progress/construction/P2-B1-B8.construction.json",
                    "P1-Central-Control/progress/P2-B1-B8.feature-batch.json",
                    "P1-Central-Control/policy/user_redline_policy.v1.0.json",
                    "P1-Central-Control/schemas/user_redline_policy.schema.json",
                    "docs/plans/P2-Feature-Triage.md",
                    # R3d8: the former Test-Strategy entry is now the same file as the roadmap entry above
                )
            ],
            "candidate_requirements": [
                {"requirement_id": "BASE", "title": "Resolve source authority", "redline_status": "CLEAR", "classification_complete": True, "protected_categories": [], "requested_operations": ["read_current_and_canonical_sources"], "impact_score": 4, "urgency_score": 4, "dependency_foundation": True},
                {"requirement_id": "TRANSACTION", "title": "Apply guarded blueprint transaction", "redline_status": "CLEAR", "classification_complete": True, "protected_categories": [], "requested_operations": ["read_current_and_canonical_sources"], "depends_on": ["BASE"], "impact_score": 5, "urgency_score": 5, "rework_risk_score": 5, "authority_conflict": True},
            ],
        }
        blocked = central.execute({
            "request_id": "F28-BLUEPRINT-ROLE", "operation": "BLUEPRINT_UPDATE_ASSESSMENT",
            "role_id": "ROLE:EXECUTOR", "blueprint_update_request": payload,
        }, ROOT)
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertIn("BLUEPRINT_UPDATE_ROLE_FORBIDDEN", blocked["reason_codes"])
        result = central.execute({
            "request_id": "F28-BLUEPRINT-ROUTE", "operation": "BLUEPRINT_UPDATE_ASSESSMENT",
            "role_id": "ROLE:CONTROL_RESEARCH", "blueprint_update_request": payload,
        }, ROOT)
        self.assertEqual(result["status"], "PASS", result)
        self.assertFalse(result["state_written"])
        self.assertEqual(result["blueprint_update_assessment"]["status"], "ASSESSMENT_READY")
        self.assertEqual([x["requirement_id"] for x in result["blueprint_update_assessment"]["priority_order"]], ["BASE", "TRANSACTION"])
    def test_intent_resolution_returns_bounded_clarification_and_enforces_brain_role(self):
        blocked = central.execute({
            "request_id": "F24-CENTRAL-ROLE",
            "operation": "INTENT_RESOLUTION",
            "role_id": "ROLE:EXECUTOR",
            "intent_request": {"request_id": "F24-CENTRAL-ROLE", "user_text": "Help me optimize this"},
        }, ROOT)
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertIn("INTENT_RESOLUTION_ROLE_FORBIDDEN", blocked["reason_codes"])
        routed = central.execute({
            "request_id": "F24-CENTRAL-AMBIGUOUS",
            "operation": "INTENT_RESOLUTION",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "intent_request": {
                "request_id": "F24-CENTRAL-AMBIGUOUS",
                "user_text": "Help me optimize this",
                "context_facts": [{"status": "CONFLICT", "statement": "Two sources disagree about the target.", "source_ref": None}],
            },
        }, ROOT)
        self.assertEqual(routed["status"], "PASS")
        self.assertFalse(routed["state_written"])
        self.assertEqual(routed["domain_decision_status"], "CONFLICT_REQUIRES_CLARIFICATION")
        self.assertEqual(len(routed["intent_resolution"]["clarification_options"]), 3)



    def test_factory_strategy_routes_repair_without_authorizing_execution(self):
        payload = {
            "request_id": "F20-CENTRAL-NORMAL",
            "system_id": "SYS-EXAMPLE",
            "request_kind": "FIX_FAILURE",
            "system_status": "PRESENT",
            "inventory_status": "COMPLETE",
            "root_cause_status": "CONFIRMED",
            "repair_scope_bounded": True,
            "architecture_status": "COMPATIBLE",
            "compatibility_status": "COMPATIBLE",
            "rebuild_evidence_status": "NONE",
            "explicit_rebuild_authorization": False,
            "governance_approval": False,
            "rollback_ready": True,
            "scope_ref": "P1-Central-Control/scripts/construction_factory.py",
            "evidence_refs": ["evidence/failure-reproduction.json"],
            "root_cause_refs": ["evidence/root-cause-confirmed.json"],
            "rebuild_evidence_refs": [],
        }
        result = central.execute({
            "request_id": "F20-CENTRAL-NORMAL",
            "operation": "SYSTEM_FACTORY_STRATEGY",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "factory_strategy_request": payload,
        }, ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["factory_strategy"]["chosen_strategy"], "REPAIR")
        self.assertFalse(result["state_written"])
        self.assertFalse(result["execution_authorized"])

    def test_factory_strategy_is_brain_only_and_partial_inventory_stays_unresolved(self):
        payload = {
            "request_id": "F20-CENTRAL-NEGATIVE",
            "system_id": "SYS-EXAMPLE",
            "request_kind": "FIX_FAILURE",
            "system_status": "PRESENT",
            "inventory_status": "PARTIAL",
            "root_cause_status": "CONFIRMED",
            "repair_scope_bounded": True,
            "architecture_status": "COMPATIBLE",
            "compatibility_status": "COMPATIBLE",
            "rebuild_evidence_status": "NONE",
            "explicit_rebuild_authorization": False,
            "governance_approval": False,
            "rollback_ready": True,
            "scope_ref": "P1-Central-Control/scripts/construction_factory.py",
            "evidence_refs": ["evidence/failure-reproduction.json"],
            "root_cause_refs": ["evidence/root-cause-confirmed.json"],
            "rebuild_evidence_refs": [],
        }
        blocked = central.execute({
            "request_id": "F20-CENTRAL-ROLE",
            "operation": "SYSTEM_FACTORY_STRATEGY",
            "role_id": "ROLE:EXECUTOR",
            "factory_strategy_request": payload,
        }, ROOT)
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertIn("FACTORY_STRATEGY_ROLE_FORBIDDEN", blocked["reason_codes"])
        routed = central.execute({
            "request_id": "F20-CENTRAL-NEGATIVE",
            "operation": "SYSTEM_FACTORY_STRATEGY",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "factory_strategy_request": payload,
        }, ROOT)
        self.assertEqual(routed["factory_strategy"]["status"], "NEEDS_EVIDENCE")
        self.assertIsNone(routed["factory_strategy"]["chosen_strategy"])


    def test_capability_lifecycle_review_is_brain_only_and_non_mutating(self):
        payload = {
            "request_id": "F18-CENTRAL-SELECT",
            "action": "SELECT_FOR_NEED",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "problem_class": "VALIDATION_FAILURE",
            "required_capability_ids": ["CAP-INGEST"],
            "optional_capability_ids": ["CAP-COUNTEREXAMPLE"],
            "context_budget": "C1",
            "include_optional": True,
            "scope_ref": "P1-Central-Control/policy/planner_library.v1.0.json",
        }
        blocked = central.execute({
            "request_id": "F18-CENTRAL-ROLE",
            "operation": "CAPABILITY_LIFECYCLE_REVIEW",
            "role_id": "ROLE:EXECUTOR",
            "capability_lifecycle_request": payload,
        }, ROOT)
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertIn("CAPABILITY_LIFECYCLE_ROLE_FORBIDDEN", blocked["reason_codes"])
        result = central.execute({
            "request_id": "F18-CENTRAL-SELECT",
            "operation": "CAPABILITY_LIFECYCLE_REVIEW",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "capability_lifecycle_request": payload,
        }, ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertFalse(result["registry_written"])
        self.assertFalse(result["execution_authorized"])
        self.assertEqual(result["domain_decision_status"], "SELECTED")


    def test_root_cause_distillation_is_brain_only_and_never_writes_state(self):
        payload = {
            "request_id": "F22-CENTRAL",
            "failure_id": "FAILURE-CENTRAL-22",
            "failure_statement": "A confirmed capability binding defect breaks the planner handoff across callers.",
            "target_scope_ref": "P1-Central-Control/scripts/planner_library.py",
            "affected_scope": "MULTI_DOMAIN",
            "target_paths": ["P1-Central-Control/scripts/planner_library.py", "P1-Central-Control/scripts/central_role_interface.py"],
            "source_revision": "0123456789abcdef0123456789abcdef01234567",
            "recurrence_count": 2,
            "explicit_one_off": False,
            "evidence": [
                {"evidence_id": "SUPPORT", "kind": "OBSERVED", "statement": "The failure reproduces when the required binding is missing.", "source_ref": "evidence/failure.json"},
                {"evidence_id": "CONTRADICT", "kind": "CONFIRMED", "statement": "A second independent failure with the binding present challenges a binding-only explanation.", "source_ref": "evidence/counterexample.json"},
            ],
            "hypotheses": [{
                "hypothesis_id": "H-BINDING",
                "statement": "The missing required role-capability binding is the common mechanism.",
                "supporting_evidence_ids": ["SUPPORT"],
                "contradicting_evidence_ids": ["CONTRADICT"],
                "discriminating_test_ref": "tests/test_binding_gate.py::test_missing_binding_blocks",
                "test_result": "CONFIRMS",
                "test_output_ref": "evidence/discriminating-test.json",
            }],
            "prior_scope_fingerprint": None,
            "prior_downstream_evidence_refs": [],
            "repair_outcome": "NOT_RUN",
            "governance_approval": False,
        }
        blocked = central.execute({
            "request_id": "F22-CENTRAL-ROLE",
            "operation": "ROOT_CAUSE_DISTILLATION",
            "role_id": "ROLE:EXECUTOR",
            "root_cause_request": payload,
        }, ROOT)
        self.assertEqual(blocked["status"], "BLOCK")
        self.assertIn("ROOT_CAUSE_DISTILLATION_ROLE_FORBIDDEN", blocked["reason_codes"])
        result = central.execute({
            "request_id": "F22-CENTRAL",
            "operation": "ROOT_CAUSE_DISTILLATION",
            "role_id": "ROLE:CONTROL_RESEARCH",
            "root_cause_request": payload,
        }, ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["domain_decision_status"], "CONFIRMED")
        self.assertFalse(result["state_written"])
        self.assertFalse(result["registry_written"])
        self.assertFalse(result["execution_authorized"])

if __name__=="__main__": unittest.main()
