"""S6 batch 3: provenance_trace (CAP-PROVENANCE) + evidence_outer (G-EV1~3).  SIMULATED_PASS (death = BaseException; guard calls are stubs)."""
import shutil
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

R = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(R / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(R / "tools"))
import capability_run as cr  # noqa: E402
import evidence_outer as eo  # noqa: E402
import provenance_trace as pt  # noqa: E402
import synthesis_guard as sg  # noqa: E402


class Died(BaseException):
    pass


def rec(i, ins, outs, act=None, s=1, e=2):
    return {"id": i, "activity": act or "a" + i, "input_refs": ins, "output_refs": outs, "started": s, "ended": e}


CHAIN = [rec("r1", ["raw"], ["e1"], s=1, e=2), rec("r2", ["e1"], ["e2"], s=3, e=4)]


class Trace(unittest.TestCase):
    def test_complete_chain(self):
        r = pt.trace(CHAIN, "e2", originals={"raw"})
        self.assertEqual((r["ok"], r["status"], r["roots"], r["breaks"], set(r["chain"])), (True, "COMPLETE", ["raw"], [], {"r1", "r2"}))

    def test_break_located(self):
        r = pt.trace(CHAIN, "e2", originals=set())
        self.assertEqual((r["ok"], r["status"], r["breaks"]), (False, "PARTIAL", [{"at": "raw", "reason": "UNDECLARED_ROOT"}]))

    def test_cycle_failed_with_witness(self):
        r = pt.trace([rec("r1", ["e2"], ["e1"]), rec("r2", ["e1"], ["e2"])], "e2")
        self.assertEqual((r["ok"], r["status"]), (False, "FAILED"))
        self.assertEqual(r["cycle"][0], r["cycle"][-1])

    def test_bad_record_is_break_not_exception(self):
        r = pt.trace([dict(CHAIN[0]), {"id": "r2", "output_refs": ["e2"]}], "e2", originals={"raw"})
        self.assertEqual((r["ok"], r["breaks"]), (False, [{"at": "r2", "reason": "BAD_RECORD"}]))

    def test_duplicate_generation_rejected(self):
        r = pt.trace(CHAIN + [rec("r3", ["raw"], ["e1"], act="ar1")], "e2", originals={"raw"})
        self.assertFalse(r["ok"])
        self.assertIn("DUP_GENERATION", [v["reason"] for v in r["violations"]])

    def test_use_before_generation_flagged(self):
        r = pt.trace([rec("r1", ["raw"], ["e1"], s=1, e=9), rec("r2", ["e1"], ["e2"], s=3, e=4)], "e2", originals={"raw"})
        self.assertEqual((r["ok"], [v["reason"] for v in r["violations"]]), (False, ["USE_BEFORE_GENERATION"]))

    def test_depth_limit_is_incomplete_never_truncated(self):
        long_ = [rec(f"r{i}", [f"e{i-1}" if i else "raw"], [f"e{i}"], s=2 * i, e=2 * i + 1) for i in range(6)]
        self.assertEqual(pt.trace(long_, "e5", originals={"raw"}, max_depth=2)["status"], "INCOMPLETE")
        self.assertEqual(pt.trace(long_, "e5", originals={"raw"})["status"], "COMPLETE")

    def test_unreadable_and_error_are_incomplete(self):
        class Boom(list):
            def __iter__(self):
                raise RuntimeError("x")
        self.assertEqual((pt.trace("x", "e")["status"], pt.trace("x", "e")["reason"]), ("INCOMPLETE", "INPUT_UNREADABLE"))
        self.assertEqual(pt.trace(Boom([1]), "e")["reason"], "GUARD_ERROR")

    def test_death_propagates_and_rerun_is_identical(self):
        with mock.patch.object(pt.graph_check, "check", side_effect=Died):
            with self.assertRaises(Died):
                pt.trace(CHAIN, "e2", originals={"raw"})
        self.assertEqual(pt.trace(CHAIN, "e2", originals={"raw"}), pt.trace(CHAIN, "e2", originals={"raw"}))

    def test_feeds_synthesis_guard(self):
        ok, bad = pt.trace(CHAIN, "e2", originals={"raw"}), pt.trace(CHAIN, "e2")
        self.assertEqual(pt.provenance_input(ok), {"ok": True, "breaks": []})
        self.assertFalse(pt.provenance_input(bad)["ok"])
        self.assertIsNone(pt.provenance_input(pt.trace("x", "e")))
        v = {"verdict": "PASS"}
        i = {"claims": [{"id": "c", "verdict": v}], "hypotheses": [], "gaps": [], "provenance": pt.provenance_input(ok)}
        d = {"text": "t", "claim_refs": ["c"], "hypothesis_main": [], "hypothesis_pending": [], "status": "COMPLETE", "gaps": []}
        self.assertEqual(sg.check(i, d)["status"], "COMPLETE")
        self.assertEqual(sg.check(dict(i, provenance=pt.provenance_input(bad)), d)["reason"], "PROVENANCE_BREAK")
        self.assertEqual(sg.check(dict(i, provenance=pt.provenance_input(pt.trace("x", "e"))), d)["status"], "INCOMPLETE")


class Outer(unittest.TestCase):
    def call(self, msg):
        def f():
            raise ValueError(msg)
        return eo.classify(f)

    def test_g_ev1_mapping(self):
        self.assertEqual(eo.classify(lambda: {"result": "PASS"})["status"], "PASS")
        for m in ("缺少 EvidenceRecord: e1", "缺少 ProvenanceRecord: p1", "Provenance 缺少 TaskPacket input_refs", "ExecutionRecord 尚未達 SUCCEEDED，禁止驗收成功結果"):
            self.assertEqual(self.call(m)["status"], "INCOMPLETE", m)
        for m in ("成功結果的 Evidence 必須為 SUPPORTS", "Evidence captured_at 晚於 ExecutionRecord end_time", "evidence.schema.json 驗證失敗: 缺少 EvidenceRecord"):
            r = self.call(m)
            self.assertEqual((r["status"], r["verdict"]), ("FAILED", "FAIL"), m)

    def test_g_ev1_guard_error_and_death(self):
        def boom():
            raise RuntimeError("no jsonschema")
        self.assertEqual(eo.classify(boom), {"status": "INCOMPLETE", "verdict": "INCOMPLETE", "reason": "GUARD_ERROR"})

        def die():
            raise Died
        with self.assertRaises(Died):
            eo.classify(die)

    def test_mapping_markers_exist_in_real_guard(self):
        src = (R / "P1-Central-Control" / "scripts" / "evidence_provenance_guard.py").read_text(encoding="utf-8")
        for m in eo.MARKERS:
            self.assertIn(m, src)

    def test_g_ev2_research_claims(self):
        ev = [{"object_id": "e1", "claim_ref": "h1", "relation": "SUPPORTS", "source_ref": "s"}]
        ok = {"id": "h1", "kind": "HYPOTHESIS", "evidence_refs": ["e1"]}
        self.assertEqual(eo.check_research_claims([ok], ev)["status"], "PASS")
        for bad, why in ((dict(ok, evidence_refs=[]), "NO_EVIDENCE_REF"), (dict(ok, evidence_refs=["zz"]), "UNRESOLVED_REF"),
                         (dict(ok, id="h2"), "NOT_BOUND")):
            r = eo.check_research_claims([bad], ev)
            self.assertEqual((r["status"], r["bad"][0]["reason"]), ("REJECTED", why))
        r = eo.check_research_claims([ok], [dict(ev[0], relation="REFUTES")])
        self.assertEqual(r["bad"][0]["reason"], "NOT_SUPPORTING")
        self.assertEqual(eo.check_research_claims("x", ev)["status"], "INCOMPLETE")
        self.assertEqual(eo.check_research_claims([ok], ev + ev)["status"], "INCOMPLETE")

    def test_g_ev3_locator_warnings_do_not_change_verdict(self):
        d = Path(tempfile.mkdtemp(prefix="s6b3-"))
        self.addCleanup(shutil.rmtree, d, True)
        (d / "a.txt").write_text("x")
        ev = [{"object_id": f"e{i}", "locator": l} for i, l in enumerate(["a.txt#L1", "gone.txt", "https://x.org/p"])] + [{"object_id": "e9"}]
        w = eo.locator_warnings(ev, d)
        self.assertEqual([(x["ref"], x["kind"]) for x in w], [("e1", "LOCATOR_UNRESOLVED"), ("e2", "LOCATOR_UNVERIFIABLE")])

        def bad(_l):
            raise OSError
        self.assertEqual([x["kind"] for x in eo.locator_warnings(ev[:1], d, resolver=bad)], ["RESOLVER_ERROR"])


class Wiring(unittest.TestCase):
    def test_measured_and_mutation_caught(self):
        for c in ("CAP-PROVENANCE", "CAP-EVIDENCE"):
            self.assertTrue(cr.check(c)["ok"], c)
        for name, c in (("provenance", "CAP-PROVENANCE"),):
            try:
                ok = cr.check(c, {**cr.RUNNERS, name: lambda: False})["ok"]
            except Exception:
                ok = False
            self.assertFalse(ok)
        with mock.patch.object(pt, "trace", side_effect=RuntimeError):
            try:
                ok = cr.check("CAP-PROVENANCE")["ok"]
            except Exception:
                ok = False
        self.assertFalse(ok)
        with mock.patch.object(eo, "classify", side_effect=RuntimeError):
            try:
                ok = cr.check("CAP-PROVENANCE")["ok"]
            except Exception:
                ok = False
        self.assertFalse(ok)
        self.assertEqual(cr.check("CAP-PROVENANCE", {**cr.RUNNERS, "provenance": lambda: True})["providers_missing"], ["provenance_trace", "evidence_outer"])


if __name__ == "__main__":
    unittest.main()
