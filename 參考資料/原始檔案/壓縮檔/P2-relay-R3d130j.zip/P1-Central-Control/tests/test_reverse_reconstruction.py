import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reverse_reconstruction import execute


class ReverseReconstructionTests(unittest.TestCase):
    def _request(self, root: Path):
        return {
            "schema_version": "1.0",
            "request_id": "REVERSE:TEST-001",
            "root_path": str(root),
            "focus_paths": ["app.py", "missing.py"],
            "max_inventory_files": 100,
            "max_focus_files": 10
        }

    def test_reconstructs_structure_dependency_and_coverage(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "pkg").mkdir()
            (root / "pkg" / "__init__.py").write_text("", encoding="utf-8")
            (root / "pkg" / "core.py").write_text(
                "def work():\n    return 1\n", encoding="utf-8"
            )
            (root / "app.py").write_text(
                "from pkg.core import work\n\ndef main():\n    return work()\n",
                encoding="utf-8",
            )
            (root / "README.md").write_text("# demo\n", encoding="utf-8")
            result = execute(self._request(root))
        self.assertEqual(result["status"], "PASS")
        self.assertGreaterEqual(result["identity"]["file_count"], 4)
        self.assertIn("app.py", result["structure"]["entrypoint_candidates"])
        self.assertTrue(any(edge["source"] == "app.py" and edge["target"] == "pkg/core.py"
                            for edge in result["dependencies"]["edges"]))
        self.assertTrue(any(row["scope"] == "RUNTIME" and row["status"] == "UNKNOWN"
                            for row in result["coverage_ledger"]))

    def test_reverse_entrypoint_uses_progressive_chain(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "app.py").write_text(
                "def main():\n    return 7\n",
                encoding="utf-8",
            )
            result = execute(self._request(root))
        self.assertEqual(result["status"], "PASS")
        self.assertTrue(any(row["scope"] == "DEEP_READ" for row in result["coverage_ledger"]))
        self.assertTrue(any(row["scope"] == "RUNTIME" and row["status"] == "UNKNOWN"
                            for row in result["coverage_ledger"]))
        self.assertGreaterEqual(result["identity"]["file_count"], 1)

    def test_broken_and_stub_state_is_not_reported_as_complete(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            (root / "broken.py").write_text("def broken(:\n", encoding="utf-8")
            (root / "stub.py").write_text("# TODO\ndef todo():\n    pass\n", encoding="utf-8")
            result = execute(self._request(root))
        self.assertEqual(result["status"], "PASS")
        self.assertIn(result["state_assessment"]["classification"], {"BROKEN", "STUB"})
        self.assertTrue(result["state_assessment"]["partial"] or result["state_assessment"]["broken"])

    def test_missing_root_is_blocked(self):
        result = execute({
            "schema_version": "1.0",
            "request_id": "REVERSE:TEST-002",
            "root_path": "/definitely/missing/repository"
        })
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "ROOT_PATH_UNAVAILABLE")


if __name__ == "__main__":
    unittest.main()
