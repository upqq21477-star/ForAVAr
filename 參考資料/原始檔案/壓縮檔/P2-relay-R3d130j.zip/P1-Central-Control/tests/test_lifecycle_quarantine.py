#!/usr/bin/env python3
"""R4R-S2（FR-03／FR-04）：data_classes 分類、QUARANTINED 分段退場、還原位元組相同、重查、EPHEMERAL 清理、預算建議。"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import tempfile
import unittest
from datetime import datetime, timedelta, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))

import lifecycle_sweep as ls  # noqa: E402

C = "P1-Central-Control/"
GRP = [C + "scripts/dead.py", C + "scripts/dead_dep.py"]


class Base(unittest.TestCase):
    def setUp(self) -> None:
        self.root = ls.sim_repo(Path(tempfile.mkdtemp(prefix="p1-q-")))
        self.addCleanup(shutil.rmtree, self.root, True)

    def run_dir(self, run_id: str) -> Path:
        return ls._qroot(self.root) / run_id


class Classify(unittest.TestCase):
    def setUp(self) -> None:
        self.pol = ls.load_policy(ROOT)

    def test_seven_classes_with_valid_dispositions(self) -> None:
        classes = {k: v for k, v in self.pol["data_classes"].items() if not k.startswith("_")}
        self.assertEqual(len(classes), 7)
        for name, spec in classes.items():
            self.assertIn(spec["disposition"], ("RETAIN", "REVIEW", "ARCHIVE", "EPHEMERAL"), name)
            self.assertTrue(spec["paths"], name)

    def test_longest_prefix_wins_and_unknown_is_reported(self) -> None:
        pol = {"data_classes": {"A": {"paths": ["x/"], "disposition": "RETAIN"}, "B": {"paths": ["x/y/"], "disposition": "EPHEMERAL"}}}
        self.assertEqual(ls.classify_path("x/y/f.json", pol)["class"], "B")
        self.assertEqual(ls.classify_path("x/f.json", pol)["class"], "A")
        self.assertEqual(ls.classify_path("z/f", pol), {"path": "z/f", "class": "UNCLASSIFIED", "disposition": None})

    def test_real_paths_classify(self) -> None:
        self.assertEqual(ls.classify_path("docs/handoffs/HANDOFF.md", self.pol)["disposition"], "RETAIN")
        self.assertEqual(ls.classify_path(C + "progress/a.json", self.pol)["class"], "PROGRESS")
        self.assertEqual(ls.classify_path(C + "briefs/s1.json", self.pol)["disposition"], "EPHEMERAL")
        self.assertEqual(ls.classify_path(C + "scripts/x.py", self.pol)["class"], "UNCLASSIFIED")


class Quarantine(Base):
    def test_quarantine_moves_files_and_writes_manifest(self) -> None:
        m = ls.quarantine_batch(self.root, GRP, batches_done=3)
        self.assertFalse(any((self.root / p).exists() for p in GRP))
        self.assertEqual(m["state"], "QUARANTINED")
        self.assertEqual(m["batches_done_at"], 3)
        self.assertTrue(all(len(f["sha256"]) == 64 and f["size"] > 0 for f in m["files"]))
        self.assertIn("--restore " + m["run_id"], m["restore"])
        self.assertTrue((self.run_dir(m["run_id"]) / "files" / GRP[0]).is_file())

    def test_refuses_non_candidate_and_protected(self) -> None:
        with self.assertRaisesRegex(ValueError, "NOT_A_CANDIDATE"):
            ls.quarantine_batch(self.root, [C + "scripts/live.py"])
        with self.assertRaisesRegex(ValueError, "PROTECTED|NOT_A_CANDIDATE"):
            ls.quarantine_batch(self.root, [C + "policy/repo_budget.json"])

    def test_registry_reference_blocks_quarantine_and_moves_nothing(self) -> None:
        ref = self.root / C / "registry" / "ref.json"  # outside the entry roots: unreachable, but still a registry reference
        ref.parent.mkdir(parents=True)
        ref.write_text(json.dumps({"x": GRP[0]}), encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "EVIDENCE_INCOMPLETE.*REGISTRY"):
            ls.quarantine_batch(self.root, GRP)
        self.assertTrue(all((self.root / p).exists() for p in GRP))

    def test_workflow_reference_is_evidence_and_also_makes_it_reachable(self) -> None:
        wf = self.root / ".github/workflows/ci.yml"
        wf.write_text(wf.read_text(encoding="utf-8") + "\nrun: python " + GRP[1] + "\n", encoding="utf-8")
        self.assertTrue(any(x.startswith("WORKFLOW:") for x in ls.removal_evidence(self.root, [GRP[1]])))
        with self.assertRaisesRegex(ValueError, "NOT_A_CANDIDATE"):
            ls.quarantine_batch(self.root, GRP)
        self.assertTrue(all((self.root / p).exists() for p in GRP))

    def test_regression_test_reference_is_evidence(self) -> None:
        t = self.root / C / "tests" / "test_other.py"
        t.write_text("import dead_dep\n", encoding="utf-8")
        self.assertTrue(any(x.startswith("REGRESSION:") for x in ls.removal_evidence(self.root, [GRP[1]])))

    def test_batch_size_limit(self) -> None:
        with self.assertRaisesRegex(ValueError, "BATCH_TOO_LARGE"):
            ls.quarantine_batch(self.root, [f"p{i}" for i in range(ls.load_policy(self.root)["batch_max_files"] + 1)])

    def test_sweep_ignores_quarantine_dir(self) -> None:
        ls.quarantine_batch(self.root, GRP)
        self.assertFalse(any(c["path"].startswith(ls.QUARANTINE_REL) for c in ls.find_candidates(self.root)["candidates"]))
        self.assertFalse(any(f.startswith(ls.QUARANTINE_REL) for f in ls._files(self.root)))


class Restore(Base):
    def test_restore_is_byte_identical(self) -> None:
        before = {p: (self.root / p).read_bytes() for p in GRP}
        m = ls.quarantine_batch(self.root, GRP)
        self.assertEqual(ls.restore_batch(self.root, m["run_id"])["restored"], 2)
        self.assertEqual({p: (self.root / p).read_bytes() for p in GRP}, before)
        self.assertFalse(self.run_dir(m["run_id"]).exists())

    def test_restore_refuses_overwrite_and_moves_nothing(self) -> None:
        m = ls.quarantine_batch(self.root, GRP)
        (self.root / GRP[1]).write_text("new content\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "RESTORE_CONFLICT"):
            ls.restore_batch(self.root, m["run_id"])
        self.assertFalse((self.root / GRP[0]).exists())
        self.assertEqual((self.root / GRP[1]).read_text(encoding="utf-8"), "new content\n")

    def test_restore_detects_tampered_file(self) -> None:
        m = ls.quarantine_batch(self.root, GRP)
        (self.run_dir(m["run_id"]) / "files" / GRP[0]).write_text("tampered\n", encoding="utf-8")
        with self.assertRaisesRegex(ValueError, "HASH_MISMATCH"):
            ls.restore_batch(self.root, m["run_id"])
        self.assertFalse((self.root / GRP[0]).exists())

    def test_unknown_run(self) -> None:
        with self.assertRaisesRegex(ValueError, "UNKNOWN_RUN"):
            ls.restore_batch(self.root, "Q9999")


class Advance(Base):
    def test_observation_counts_batches_not_calendar(self) -> None:
        m = ls.quarantine_batch(self.root, GRP, batches_done=5)
        a = ls.advance_quarantine(self.root, batches_done=5)[0]
        self.assertEqual((a["action"], a["remaining_batches"]), ("OBSERVING", 2))
        self.assertEqual(ls.advance_quarantine(self.root, batches_done=6)[0]["remaining_batches"], 1)
        self.assertEqual(ls._load(self.run_dir(m["run_id"]) / "manifest.json")["state"], "QUARANTINED")

    def test_full_sequence_to_removed(self) -> None:
        m = ls.quarantine_batch(self.root, GRP, batches_done=0)
        self.assertEqual(ls.advance_quarantine(self.root, batches_done=2)[0]["state"], "VERIFIED_UNUSED")
        self.assertEqual(ls.advance_quarantine(self.root, batches_done=2)[0]["state"], "REMOVED")
        rd = self.run_dir(m["run_id"])
        self.assertFalse((rd / "files").exists())
        self.assertEqual(ls._load(rd / "manifest.json")["state"], "REMOVED")
        self.assertEqual(ls.advance_quarantine(self.root, batches_done=9), [])

    def test_recheck_blocks_purge_when_referenced_again(self) -> None:
        m = ls.quarantine_batch(self.root, GRP, batches_done=0)
        ls.advance_quarantine(self.root, batches_done=2)
        (self.root / C / "canonical" / "late.json").write_text(json.dumps({"use": GRP[0]}), encoding="utf-8")
        a = ls.advance_quarantine(self.root, batches_done=2)[0]
        self.assertEqual((a["action"], a["state"]), ("BLOCKED", "REFERENCED_AGAIN"))
        self.assertTrue((self.run_dir(m["run_id"]) / "files" / GRP[0]).is_file())

    def test_removed_run_cannot_be_restored(self) -> None:
        m = ls.quarantine_batch(self.root, GRP, batches_done=0)
        ls.advance_quarantine(self.root, batches_done=2)
        ls.advance_quarantine(self.root, batches_done=2)
        with self.assertRaisesRegex(ValueError, "ALREADY_REMOVED"):
            ls.restore_batch(self.root, m["run_id"])


class Ephemeral(Base):
    def _brief(self, name: str, **kw: object) -> Path:
        p = self.root / C / "briefs" / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(kw), encoding="utf-8")
        return p

    def test_expired_removed_active_and_unexpiring_kept(self) -> None:
        now = datetime(2026, 10, 15, tzinfo=timezone.utc)
        old = (now - timedelta(days=1)).isoformat()
        gone = self._brief("old.json", expires_at=old)
        live = self._brief("live.json", expires_at=old, active=True)
        none = self._brief("none.json", note="no expiry")
        fresh = self._brief("fresh.json", expires_at=(now + timedelta(days=1)).isoformat())
        res = ls.sweep_ephemeral(self.root, now)
        self.assertEqual(res["removed"], [C + "briefs/old.json"])
        self.assertFalse(gone.exists())
        self.assertTrue(live.exists() and none.exists() and fresh.exists())
        self.assertEqual(res["kept_active"], [C + "briefs/live.json"])
        self.assertEqual(res["no_expiry"], [C + "briefs/none.json"])

    def test_missing_directory_is_a_noop(self) -> None:
        self.assertEqual(ls.sweep_ephemeral(self.root), {"removed": [], "kept_active": [], "no_expiry": [], "unreadable": []})

    def test_unreadable_file_is_kept_and_reported(self) -> None:
        p = self.root / C / "briefs" / "bad.json"
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text("{not json", encoding="utf-8")
        self.assertEqual(ls.sweep_ephemeral(self.root)["unreadable"], [C + "briefs/bad.json"])
        self.assertTrue(p.exists())


class Budget(Base):
    def test_over_budget_lists_largest_with_advice_and_under_budget_is_silent(self) -> None:
        pdir = self.root / C / "progress"
        pdir.mkdir(parents=True)
        (pdir / "big.json").write_text("x" * 20000, encoding="utf-8")
        (pdir / "small.json").write_text("y" * 100, encoding="utf-8")
        s = ls.suggest_budget(self.root)
        self.assertEqual(len(s), 1)
        self.assertEqual(s[0]["largest"][0]["path"], C + "progress/big.json")
        self.assertGreater(s[0]["over_by"], 0)
        self.assertIn("archive_governance", s[0]["advice"])
        (pdir / "big.json").write_text("x" * 100, encoding="utf-8")
        self.assertEqual(ls.suggest_budget(self.root), [])


class Entry(unittest.TestCase):
    def test_simulate_quarantine_entry_exits_zero_with_simulated_pass(self) -> None:
        r = subprocess.run([sys.executable, str(ROOT / C / "scripts/lifecycle_sweep.py"), "--simulate-quarantine"], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("SIMULATED_PASS", r.stdout)
        self.assertNotIn("FAIL", r.stdout)


if __name__ == "__main__":
    unittest.main()
