#!/usr/bin/env python3
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import actions_execution_local_fallback as fallback


class ActionsExecutionLocalFallbackTests(unittest.TestCase):
    def diagnostic(self, classification):
        return {
            "diagnostic_id": "ACTIONS_DIAGNOSTIC:123",
            "classification": classification,
        }

    def test_runner_failure_is_planned_without_execution(self):
        with patch.object(fallback.subprocess, "run") as run:
            result = fallback.execute(
                self.diagnostic("RUNNER_STARTUP_FAILURE"),
                head_sha="abc1234567890",
                output=Path("/tmp/report.json"),
                acceptance_output=Path("/tmp/acceptance.json"),
                attempt_index=0,
                max_external_retries=2,
            )
        run.assert_not_called()
        self.assertEqual(result["decision"], "REPLAY_LOCAL")
        self.assertEqual(result["status"], "PLANNED")
        self.assertIsNone(result["return_code"])

    def test_runner_failure_after_retry_budget_is_still_planned(self):
        with patch.object(fallback.subprocess, "run") as run:
            result = fallback.execute(
                self.diagnostic("RUNNER_STARTUP_FAILURE"),
                head_sha="abc1234567890",
                output=Path("/tmp/report.json"),
                acceptance_output=Path("/tmp/acceptance.json"),
                attempt_index=2,
                max_external_retries=2,
            )
        run.assert_not_called()
        self.assertEqual(result["decision"], "REPLAY_LOCAL")
        self.assertEqual(result["status"], "PLANNED")
        self.assertIsNone(result["return_code"])

    def test_workflow_execution_failure_is_planned_without_execution(self):
        with patch.object(fallback.subprocess, "run") as run:
            result = fallback.execute(
                self.diagnostic("WORKFLOW_EXECUTION_FAILURE"),
                head_sha="abc1234567890",
                output=Path("/tmp/report.json"),
                acceptance_output=Path("/tmp/acceptance.json"),
                attempt_index=0,
            )
        run.assert_not_called()
        self.assertEqual(result["decision"], "REPLAY_LOCAL")
        self.assertEqual(result["status"], "PLANNED")
        self.assertIsNone(result["return_code"])

    def test_pass_is_noop(self):
        with patch.object(fallback.subprocess, "run") as run:
            result = fallback.execute(
                self.diagnostic("PASS"),
                head_sha="abc1234567890",
                output=Path("/tmp/report.json"),
                acceptance_output=Path("/tmp/acceptance.json"),
                attempt_index=0,
            )
        run.assert_not_called()
        self.assertEqual(result["decision"], "NOOP")
        self.assertEqual(result["status"], "SKIPPED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
