import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from scenario_oracle import execute


class ScenarioOracleTests(unittest.TestCase):
    def test_positive_negative_recovery_classes(self):
        with tempfile.TemporaryDirectory() as tmp:
            req = {
                "schema_version": "1.0",
                "oracle_id": "ORACLE:001",
                "root_path": tmp,
                "minimum_classes": ["POSITIVE", "NEGATIVE", "RECOVERY"],
                "scenarios": [
                    {"scenario_id": "positive", "class": "POSITIVE", "command": [sys.executable, "-c", "raise SystemExit(0)"], "expected_exit_code": 0},
                    {"scenario_id": "negative", "class": "NEGATIVE", "command": [sys.executable, "-c", "raise SystemExit(3)"], "expected_exit_code": 3},
                    {"scenario_id": "recovery", "class": "RECOVERY", "command": [sys.executable, "-c", "raise SystemExit(0)"], "expected_exit_code": 0}
                ]
            }
            result = execute(req)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(len(result["results"]), 3)

    def test_missing_scenario_class_blocks(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = execute({
                "schema_version": "1.0",
                "oracle_id": "ORACLE:002",
                "root_path": tmp,
                "minimum_classes": ["POSITIVE", "NEGATIVE", "RECOVERY"],
                "scenarios": [
                    {"scenario_id": "positive", "class": "POSITIVE", "command": [sys.executable, "-c", "pass"], "expected_exit_code": 0}
                ]
            })
        self.assertEqual(result["status"], "BLOCK")
        self.assertIn("NEGATIVE", result["missing_classes"])


if __name__ == "__main__":
    unittest.main()
