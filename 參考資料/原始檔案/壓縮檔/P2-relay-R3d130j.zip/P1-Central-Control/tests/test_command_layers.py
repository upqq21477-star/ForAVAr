from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import librarian  # noqa: E402


class CommandLayerTests(unittest.TestCase):
    def test_real_files_are_consistent(self):
        self.assertEqual(librarian.check_command_lists(**librarian.command_inputs()), [])

    def test_every_negative_case_is_detected(self):
        inp = librarian.command_inputs()
        cases = librarian.command_negative_cases(inp)
        self.assertGreaterEqual(len(cases), 7)
        for name, mut, want in cases:
            got = librarian.check_command_lists(**mut)
            self.assertTrue(any(e.startswith(want) for e in got), (name, got))

    def test_skill_keeps_no_second_table_copy(self):
        skill = (ROOT / librarian.CMD_FILES["skill"]).read_text(encoding="utf-8")
        self.assertIn(librarian.IFACE_REL, skill)
        self.assertNotIn("| **\uff01", skill)

    def test_always_pass_checker_turns_contract_check_failed(self):
        real = librarian.check_command_lists
        librarian.check_command_lists = lambda *a, **k: []
        try:
            failed = [n for n, ok, _ in librarian.check_contracts() if not ok]
        finally:
            librarian.check_command_lists = real
        self.assertTrue(any(n.startswith("negative: commands:") for n in failed), failed)


if __name__ == "__main__":
    unittest.main()
