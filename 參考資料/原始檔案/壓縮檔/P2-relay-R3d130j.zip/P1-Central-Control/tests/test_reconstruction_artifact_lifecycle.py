import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))

from reconstruction_artifact_lifecycle import execute


class ReconstructionArtifactLifecycleTests(unittest.TestCase):
    def test_create_use_verify_promote(self):
        created = execute(
            "RECONART:001", "ARCHITECTURE_MAP", "REVERSE:001", "ABSENT", "CREATE"
        )
        used = execute(
            "RECONART:001", "ARCHITECTURE_MAP", "REVERSE:001", created["status"], "USE"
        )
        verified = execute(
            "RECONART:001",
            "ARCHITECTURE_MAP",
            "REVERSE:001",
            used["status"],
            "VERIFY",
            ["dependency-map", "structure-map"]
        )
        promoted = execute(
            "RECONART:001",
            "ARCHITECTURE_MAP",
            "REVERSE:001",
            verified["status"],
            "PROMOTE",
            ["verified-architecture"]
        )
        self.assertEqual(promoted["status"], "PROMOTED")

    def test_verify_requires_evidence(self):
        with self.assertRaisesRegex(ValueError, "EVIDENCE_REQUIRED"):
            execute("RECONART:002", "GAP_REGISTER", "REVERSE:002", "USED", "VERIFY")

    def test_illegal_promotion_blocks(self):
        with self.assertRaisesRegex(ValueError, "ILLEGAL_ARTIFACT_TRANSITION"):
            execute("RECONART:003", "FUNCTION_MAP", "REVERSE:003", "CREATED", "PROMOTE")


if __name__ == "__main__":
    unittest.main()
