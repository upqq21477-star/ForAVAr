#!/usr/bin/env python3
"""DEFECT-006：Control Gate 缺 truth_record／fixture_ref 須回 INCOMPLETE，不得裸 KeyError 或誤判 PASS。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

import control_gate_runtime as gate  # noqa: E402

CURRENT = {"implementation_control": {"current_truth_reconciliation": {"script": "x.py"}, "active_work_packet": "w.json"}}


class ControlGateMissingRefsTests(unittest.TestCase):
    def _run(self, current):
        captured = {}

        def fake_report(output, base, head, status, stages):
            captured["status"], captured["stages"] = status, stages
            return 2

        with mock.patch.object(gate, "load_json", side_effect=[{}, current]), \
             mock.patch.object(gate, "run_research_memory_box_close_gate", return_value=("B", "D")), \
             mock.patch.object(gate, "write_report", side_effect=fake_report):
            gate.execute(base_sha="a", head_sha="b", output="out.json", skip_unit_tests=True)
        return captured

    def test_missing_both_refs_is_incomplete_not_keyerror(self):
        got = self._run(dict(CURRENT))
        self.assertEqual(got["status"], "INCOMPLETE")
        last = got["stages"][-1]
        self.assertEqual((last["stage_id"], last["status"]), ("CURRENT_TRUTH_RECONCILIATION", "INCOMPLETE"))
        self.assertEqual(last["reason_code"], "CURRENT_TRUTH_INPUT_REFERENCES_MISSING")

    def test_missing_only_fixture_ref_is_incomplete(self):
        cur = dict(CURRENT, latest_runtime_observation={"truth_record": "t.json"})
        got = self._run(cur)
        self.assertEqual(got["status"], "INCOMPLETE")
        self.assertEqual(got["stages"][-1]["reason_code"], "CURRENT_TRUTH_INPUT_REFERENCES_MISSING")


if __name__ == "__main__":
    unittest.main()
