#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS_DIR = ROOT / "P1-Central-Control" / "scripts"
sys.path.insert(0, str(SCRIPTS_DIR))

import central_controller  # noqa: E402
from event_log import EventLog  # noqa: E402
from packet_layer import build_attempt, build_result_packet, build_task_packet  # noqa: E402
from result_distillation import (
    distill_result,
    validate_distillation_input,
    validate_distillation_record,
)


class ResultDistillationTests(unittest.TestCase):
    def make_segment(self) -> dict:
        return {
            "segment_id": "SEG-P8-001",
            "workflow_id": "WF-P8",
            "system_id": "SYSTEM-A",
            "skill_id": "schema-builder",
            "skill_version": "1.0.0",
            "objective": "測試 Result Distillation",
            "input_scope": "p8-test",
            "input_refs": ["ARTIFACT:input-001"],
            "requested_outputs": ["result"],
            "constraints": [],
            "stop_condition": ["result_ready"],
            "failure_condition": ["invalid_input"],
            "dependency_refs": [],
            "completion_contract": {
                "required_outputs": ["result"],
                "handoff_allowed": True,
            },
            "execution_record_ref": "EXECUTION:exec-att-SEG-P8-001-1",
            "context_cohort_id": "COHORT-P8",
            "context_budget": {
                "estimated_total_context": 100,
                "target_context_budget": 1000,
                "hard_context_ceiling": 2000,
                "risk": "LOW",
            },
            "retry_policy": {"max_attempts": 1, "retry_on": []},
            "timeout_ms": 1000,
        }

    def make_packet(self, decision_code: str) -> dict:
        segment = self.make_segment()
        attempt = build_attempt(
            segment,
            attempt_number=1,
            started_at="2026-10-03T10:00:00+00:00",
        )
        task = build_task_packet(segment, attempt)
        return build_result_packet(
            task,
            {
                "decision_code": decision_code,
                "output_refs": ["ARTIFACT:result-001"]
                if decision_code == "WORK_COMPLETE"
                else [],
                "unresolved": ["需要補充資料"]
                if decision_code == "UNRESOLVED"
                else [],
                "evidence_refs": ["EVIDENCE:p8-001"],
                "provenance_refs": ["PROVENANCE:p8-001"],
                "observed_usage": {
                    "model_calls": 1,
                    "tool_calls": 1,
                    "wall_time_ms": 1,
                },
                "usage_observed": True,
            },
        )

    def test_valid_work_complete_distills_output_to_confirmed(self):
        result = self.make_packet("WORK_COMPLETE")
        record = distill_result(result)
        self.assertEqual(record["result_status"], "VALID")
        self.assertEqual(record["confirmed_refs"], ["ARTIFACT:result-001"])
        self.assertEqual(record["unknown"], [])
        self.assertEqual(record["evidence_refs"], ["EVIDENCE:p8-001"])
        validate_distillation_record(record)

    def test_unresolved_result_becomes_unknown_without_inventing_confirmation(self):
        result = self.make_packet("UNRESOLVED")
        record = distill_result(result)
        self.assertEqual(record["confirmed_refs"], [])
        self.assertEqual(record["unknown"], ["需要補充資料"])

    def test_invalid_result_never_becomes_confirmed(self):
        result = self.make_packet("FAIL")
        record = distill_result(result)
        self.assertEqual(record["confirmed_refs"], [])
        self.assertEqual(record["unknown"], [])

    def test_semantic_refs_are_preserved_as_candidates_not_executed(self):
        result = self.make_packet("WORK_COMPLETE")
        semantic = {
            "confirmed_refs": ["ARTIFACT:semantic-confirmed"],
            "inference_refs": ["ARTIFACT:inference-001"],
            "conflict_refs": ["ARTIFACT:conflict-001"],
            "state_change_candidate_refs": ["STATE_CHANGE:candidate-001"],
            "next_action_candidate_refs": ["ACTION:candidate-001"],
        }
        validate_distillation_input(semantic)
        record = distill_result(result, semantic_input=semantic)
        self.assertEqual(
            record["confirmed_refs"],
            ["ARTIFACT:result-001", "ARTIFACT:semantic-confirmed"],
        )
        self.assertEqual(record["inference_refs"], ["ARTIFACT:inference-001"])
        self.assertEqual(record["conflict_refs"], ["ARTIFACT:conflict-001"])
        self.assertEqual(
            record["state_change_candidate_refs"],
            ["STATE_CHANGE:candidate-001"],
        )
        self.assertEqual(
            record["next_action_candidate_refs"],
            ["ACTION:candidate-001"],
        )

    def test_central_requires_external_distillation_store(self):
        state = central_controller.init_state("WF-P8", "TASK-P8")
        state = central_controller.queue_segment(state, self.make_segment())
        execution_store = {}

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
            )
            result = self.make_packet("UNRESOLVED")
            result["execution_record_ref"] = packets[0]["execution_record_ref"]
            with self.assertRaises(ValueError):
                central_controller.receive_result(
                    state,
                    result,
                    event_log=log,
                    execution_store=execution_store,
                    evidence_records=[],
                    provenance_records=[],
                )

    def test_central_writes_distillation_and_bounded_recent_ref(self):
        state = central_controller.init_state("WF-P8", "TASK-P8")
        state = central_controller.queue_segment(state, self.make_segment())
        execution_store = {}
        distillation_store = {}

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
            )
            result = self.make_packet("UNRESOLVED")
            result["execution_record_ref"] = packets[0]["execution_record_ref"]
            state = central_controller.receive_result(
                state,
                result,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                evidence_records=[],
                provenance_records=[],
            )

        ref = "DISTILLATION:dist-" + result["result_id"]
        self.assertIn(ref, distillation_store)
        self.assertEqual(state["recent_distillation_refs"], [ref])

    def test_central_distills_success_after_execution_and_guard(self):
        state = central_controller.init_state("WF-P8", "TASK-P8")
        state = central_controller.queue_segment(state, self.make_segment())
        execution_store = {}
        distillation_store = {}

        with tempfile.TemporaryDirectory() as temp:
            log = EventLog(Path(temp) / "events.jsonl")
            state, packets = central_controller.dispatch(
                state,
                event_log=log,
                execution_store=execution_store,
            )
            envelope = execution_store[packets[0]["execution_record_ref"]]
            task = envelope["task_packet"]
            result = build_result_packet(
                task,
                {
                    "decision_code": "WORK_COMPLETE",
                    "output_refs": ["ARTIFACT:result-001"],
                    "evidence_refs": ["EVIDENCE:p8-success"],
                    "provenance_refs": ["PROVENANCE:p8-success"],
                    "observed_usage": {
                        "model_calls": 1,
                        "tool_calls": 1,
                        "wall_time_ms": 1,
                    },
                    "usage_observed": True,
                },
            )
            evidence = [{
                "object_id": "EVIDENCE:p8-success",
                "kind": "EVIDENCE",
                "schema_version": "1.0",
                "content_hash": "sha256:" + "0" * 64,
                "source_ref": "ARTIFACT:input-001",
                "claim_ref": result["object_id"],
                "relation": "SUPPORTS",
                "captured_at": envelope["execution_record"]["start_time"],
            }]
            provenance = [{
                "object_id": "PROVENANCE:p8-success",
                "kind": "PROVENANCE",
                "schema_version": "1.0",
                "content_hash": "sha256:" + "0" * 64,
                "subject_ref": result["object_id"],
                "activity_ref": envelope["execution_record"]["execution_record_ref"],
                "agent_ref": "SKILL:schema-builder-1.0.0",
                "input_refs": ["ARTIFACT:input-001"],
                "output_refs": ["ARTIFACT:result-001"],
                "relation": "WAS_GENERATED_BY",
            }]
            state = central_controller.receive_result(
                state,
                result,
                event_log=log,
                execution_store=execution_store,
                distillation_store=distillation_store,
                evidence_records=evidence,
                provenance_records=provenance,
            )

        record = distillation_store[result["object_id"].replace("RESULT_PACKET:", "DISTILLATION:dist-")]
        self.assertEqual(record["confirmed_refs"], ["ARTIFACT:result-001"])
        self.assertEqual(state["status"], "COMPLETED")


if __name__ == "__main__":
    unittest.main()
