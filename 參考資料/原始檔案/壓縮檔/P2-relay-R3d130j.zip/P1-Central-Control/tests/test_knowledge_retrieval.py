#!/usr/bin/env python3
"""CS-1 B7：Retrieval（Exact／Structural）、快照恢復、Working Context、Amnesia（P16）、Full Reconstruction（P20）。SIMULATION_ONLY。"""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import knowledge_context as kc  # noqa: E402
import knowledge_intake as ki  # noqa: E402
import knowledge_retrieval as kr  # noqa: E402
from _knowledge_fixture import J, KB, POISON, T1, T2, T3, TS, raw  # noqa: E402

COLD = ("ACTIVE", "WARM", "COLD")
CT = {"stage": "B7"}
TASK = {"task_id": "T-1", "goal": "回答 A 系統現況"}


class Base(unittest.TestCase):
    def setUp(self) -> None:
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        self.kb = KB(Path(tmp.name))
        self.s, self.r = self.kb.store, kr.Retriever(self.kb.store)

    def refs(self, res):
        return [x["claim_ref"] for x in res["results"]]


class RetrievalTests(Base):
    def test_exact_keys(self) -> None:
        kb = self.kb
        self.assertEqual(self.refs(self.r.exact(claim_ref=kb.c2)), [kb.c2])
        self.assertEqual(self.refs(self.r.exact(source_ref="SOURCE:d")), sorted([kb.c2, kb.c3, kb.c4, kb.cp]))
        self.assertEqual(self.refs(self.r.exact(segment_ref=kb.segs[2])), [kb.c2])
        self.assertEqual(self.refs(self.r.exact(source_ref="SOURCE:d", revision=2)), [kb.c2])
        for bad, code in (({}, "EXACT_KEY_REQUIRED"), ({"entity_id": "x"}, "EXACT_KEY_UNKNOWN"), ({"claim_ref": ""}, "EXACT_KEY_EMPTY")):
            with self.assertRaisesRegex(ValueError, code):
                self.r.exact(**bad)

    def test_scope_cold_needs_reason_and_superseded_hidden_by_default(self) -> None:
        self.assertEqual(self.refs(self.r.exact(claim_ref=self.kb.c1)), [])
        with self.assertRaisesRegex(ValueError, "COLD_REASON_REQUIRED"):
            self.r.exact(claim_ref=self.kb.c1, scope=COLD)
        got = self.r.exact(claim_ref=self.kb.c1, scope=COLD, reason="追溯舊版")
        self.assertEqual(got["results"][0]["state"]["lifecycle"], "SUPERSEDED")
        for sc, code in (("ARCHIVE", "ARCHIVE_VIA_PROTOCOL_ONLY"), ("ALL", "SCOPE_ALL_FORBIDDEN"), ("EXTERNAL", "EXTERNAL_NOT_SERVED")):
            with self.assertRaisesRegex(ValueError, code):
                self.r.text("系統", scope=sc)

    def test_temporal_default_is_valid_at_not_latest_mention(self) -> None:
        self.assertEqual(self.refs(self.r.text("SQLite", scope=COLD, reason="歷史", at="2026-03-01T00:00:00Z")), [self.kb.c1])
        self.assertEqual(self.refs(self.r.text("SQLite", scope=COLD, reason="歷史", at=T3)), [])
        self.assertEqual(self.refs(self.r.text("JSON", at=T3)), [self.kb.c2])
        self.assertEqual(self.refs(self.r.text("JSON", at=T1)), [])

    def test_conflict_not_flattened(self) -> None:
        res = self.r.text("網路")
        self.assertEqual(self.refs(res), sorted([self.kb.c3, self.kb.c4]))
        for x in res["results"]:
            self.assertEqual((x["state"]["adjudication"], x["state"]["epistemic"]), ("DISPUTED", "CONFLICTED"))
        self.assertEqual(self.r.trace(self.kb.c3)["conflicts"][0]["status"], "UNRESOLVED")

    def test_non_canonical_is_untrusted_candidate_and_off_by_default(self) -> None:
        o = self.s.add_observation("INFERENCE", "推測", self.kb.segs[0], producer="R1", captured_at=TS, basis_refs=[self.s.claims[self.kb.c1]["observation_refs"][0]])["object_id"]
        ref = self.s.propose_claim("p1", "FACT", "推測：A 使用 SQLite", [o], [])["object_id"]
        self.assertEqual(self.refs(self.r.text("推測")), [])
        got = self.r.text("推測", promotion=("PROPOSED",))["results"][0]
        self.assertEqual((got["claim_ref"], got["truth_status"], got["instruction_content"]), (ref, "UNTRUSTED_CANDIDATE", False))
        self.assertTrue(all(x["truth_status"] == "CANONICAL_CLAIM" and x["instruction_content"] is False for x in self.r.text("系統")["results"]))

    def test_too_broad_and_short(self) -> None:
        with mock.patch.object(kr, "HARD_CAP", 1), self.assertRaisesRegex(ValueError, "TARGET_TOO_BROAD"):
            self.r.text("系統")
        with self.assertRaisesRegex(ValueError, "TEXT_TOO_SHORT"):
            self.r.text("A")

    def test_structural_trace_chain(self) -> None:
        t = self.r.trace(self.kb.c2)
        self.assertEqual([v["claim"] for v in t["versions"]], [self.kb.c1, self.kb.c2])
        self.assertEqual(t["sources"], ["SOURCE:d"])
        self.assertEqual({e["fragment"] for e in t["evidence"]}, {"SQLite", "JSON"})
        for e in t["evidence"]:
            self.assertIn(e["fragment"], self.s.segment_text(e["segment_ref"]))
            self.assertEqual(e["segment_read_state"], "PROCESSED")
        kinds = {k for _, k, _ in t["edges"]}
        self.assertTrue({"VERSION_OF", "SUPPORTED_BY", "DERIVED_FROM", "QUOTED_IN", "PART_OF"} <= kinds)
        with self.assertRaisesRegex(ValueError, "CLAIM_UNKNOWN"):
            self.r.trace("CLAIM:nope")

    def test_store_type_enforced(self) -> None:
        with self.assertRaisesRegex(ValueError, "STORE_TYPE_INVALID"):
            kr.Retriever(object())


class SnapshotTests(Base):
    def _forge(self, snap, mutate):
        snap = json.loads(json.dumps(snap))
        mutate(snap)
        snap.pop("snapshot_hash")
        from event_log import content_hash
        snap["snapshot_hash"] = content_hash(snap)
        return snap

    def test_roundtrip_equal(self) -> None:
        snap, fresh = self.kb.reload()
        st = kr.restore(snap, fresh.ledger, fresh.texts)
        self.assertEqual(st.claims, self.s.claims)
        self.assertEqual(kr.snapshot(st), snap)
        self.assertEqual(kr.Retriever(st).text("JSON", at=T3), self.r.text("JSON", at=T3))

    def test_tamper_blocked(self) -> None:
        snap, fresh = self.kb.reload()

        def content(s): s["claims"][0]["content"] = "被竄改"

        def promote(s):
            c = next(x for x in s["claims"] if x["object_id"] == self.kb.c2)
            c["promotion"] = "CANONICAL"
            c.pop("adjudication", None)

        def quote(s): s["observations"][0]["quote"] = "不存在的引文"

        for fn in (content, promote, quote):
            with self.assertRaisesRegex(ValueError, "RESTORE_BLOCKED:INTEGRITY"):
                kr.restore(self._forge(snap, fn), fresh.ledger, fresh.texts)
        bad = dict(snap, claims=[])
        with self.assertRaisesRegex(ValueError, "SNAPSHOT_HASH"):
            kr.restore(bad, fresh.ledger, fresh.texts)

    def test_source_and_ledger_must_match(self) -> None:
        snap, fresh = self.kb.reload()
        with self.assertRaisesRegex(ValueError, "SOURCE_TEXT_MISMATCH"):
            kr.restore(snap, fresh.ledger, {"SOURCE:d": fresh.texts["SOURCE:d"] + "x"})
        with self.assertRaisesRegex(ValueError, "SOURCE_TEXT_MISMATCH"):
            kr.restore(snap, fresh.ledger, {})
        empty = ki.ReadingLedger(self.kb.tmp / "other.jsonl", list(fresh.ledger.segments.values()))
        with self.assertRaisesRegex(ValueError, "LEDGER_HEAD_MISMATCH"):
            kr.restore(snap, empty, fresh.texts)


class ContextTests(Base):
    def ctx(self, **kw):
        return kc.assemble_context(self.s, current_truth=CT, active_task=TASK, at=T3, **kw)

    def test_channels_and_scope(self) -> None:
        c = self.ctx()
        self.assertEqual(kc.instruction_channel(c), {"current_truth": CT, "active_task": TASK})
        got = {x["claim_ref"] for x in c["data"]["claims"]}
        self.assertEqual(got, {self.kb.c2, self.kb.c3, self.kb.c4, self.kb.cp})
        self.assertNotIn(self.kb.c1, got)  # SUPERSEDED（COLD）不自動進 Context
        self.assertEqual(c["scopes_included"], ["ACTIVE", "WARM"])
        self.assertEqual(c["trust"], {"instructions": "AUTHORITATIVE", "data": "DATA"})
        self.assertNotIn(POISON, json.dumps(c["instructions"], ensure_ascii=False))
        self.assertIn(POISON, json.dumps(c["data"], ensure_ascii=False))
        self.assertEqual(self.ctx()["context_hash"], c["context_hash"])

    def test_budget_reports_omissions(self) -> None:
        c = self.ctx(budget_chars=40)
        shown = {x["claim_ref"] for x in c["data"]["claims"]}
        self.assertTrue(c["omitted_refs"])
        self.assertEqual(shown | set(c["omitted_refs"]), {self.kb.c2, self.kb.c3, self.kb.c4, self.kb.cp})
        self.assertFalse(shown & set(c["omitted_refs"]))

    def test_authority_and_checkpoint_required(self) -> None:
        for kw in ({"current_truth": {}}, {"active_task": {}}):
            with self.assertRaisesRegex(ValueError, "CONTEXT_AUTHORITY_REQUIRED"):
                kc.assemble_context(self.s, **{"current_truth": CT, "active_task": TASK, "at": T3, **kw})
        cp = {"knowledge_snapshot_hash": kr.snapshot(self.s)["snapshot_hash"], "resume_cursor": "s3"}
        self.assertEqual(self.ctx(checkpoint=cp)["data"]["checkpoint"], cp)
        self.s.add_observation("UNKNOWN", "新缺口", self.kb.segs[0], producer="R1", captured_at=TS)
        with self.assertRaisesRegex(ValueError, "CHECKPOINT_STALE"):
            self.ctx(checkpoint=cp)


class AmnesiaAndReconstructionTests(Base):
    def test_p16_amnesia_resume_same_context(self) -> None:
        cp = {"knowledge_snapshot_hash": kr.snapshot(self.s)["snapshot_hash"], "resume_cursor": "s3"}
        before = kc.assemble_context(self.s, current_truth=CT, active_task=TASK, at=T3, checkpoint=cp)
        status_before = kc.status_report(self.s, self.kb.contract, T3)
        snap, fresh = self.kb.reload()
        del self.s, self.r, self.kb.store  # Working Context 清除：只留 snapshot／ledger 檔／原文／checkpoint
        st = kr.restore(snap, fresh.ledger, fresh.texts)
        after = kc.assemble_context(st, current_truth=CT, active_task=TASK, at=T3, checkpoint=cp)
        self.assertEqual(after["context_hash"], before["context_hash"])
        self.assertEqual(kc.status_report(st, fresh.contract, T3), status_before)

    def test_p20_full_reconstruction_answer(self) -> None:
        # Raw → Manifest → Segment → Reading → Coverage → Canonical（fixture 已走完）→ Reset → Resume → Retrieval → Answer
        cov = ki.coverage(self.kb.ledger, self.kb.contract)
        self.assertTrue(ki.full_read_claim_holds(cov, self.kb.ledger, self.kb.contract))
        snap, fresh = self.kb.reload()
        _, again = ki.build_source("d", raw(), location="mem://d", version="v1", max_chars=20)
        self.assertEqual([s["object_id"] for s in again], self.kb.segs)  # 同 Raw 重建出同 Segment
        st = kr.restore(snap, fresh.ledger, fresh.texts)
        self.assertEqual(self.refs(kr.Retriever(st).exact(segment_ref=self.kb.segs[2])), [self.kb.c2])
        a = kc.status_report(st, fresh.contract, T3)
        self.assertEqual((a["coverage"], a["unread"]), ("COMPLETE", []))
        self.assertEqual(a["read"], self.kb.segs)
        self.assertIn(self.kb.c2, a["currently_valid"])
        self.assertNotIn(self.kb.c1, a["currently_valid"] + a["disputed"])
        self.assertEqual(sorted(a["disputed"]), sorted([self.kb.c3, self.kb.c4]))
        self.assertEqual(a["conflicts"][0]["status"], "UNRESOLVED")
        self.assertEqual(len(a["unknown_observations"]), 1)
        adopted = {x["claim"]: x for x in a["adopted"]}
        self.assertEqual(adopted[self.kb.c2]["supersedes"], [self.kb.c1])
        self.assertEqual(adopted[self.kb.c2]["adjudication"]["by"], J[0])
        self.assertTrue(a["traceable"])

    def test_status_report_does_not_load_full_version_history(self) -> None:
        # Default status is a current-state projection, not an implicit history query.
        with mock.patch.object(self.s, "history", side_effect=AssertionError("history must be opt-in")):
            report = kc.status_report(self.s, self.kb.contract, T3)
        self.assertTrue(report["traceable"])
        self.assertTrue(report["adopted"])
        self.assertTrue(all("versions" not in item for item in report["adopted"]))

    def test_missing_segment_is_incomplete_not_done(self) -> None:
        import knowledge_versioning as kv
        from _knowledge_fixture import KBEmpty
        with tempfile.TemporaryDirectory() as t:
            e = KBEmpty(Path(t), raw())
            a = kc.status_report(kv.TemporalKnowledgeStore(e.ledger, e.texts), e.contract, T3)
            self.assertEqual((a["coverage"], a["read"], a["unread"]), ("INCOMPLETE", [], e.segs))
            self.assertEqual((a["confirmed"], a["currently_valid"]), ([], []))


if __name__ == "__main__":
    unittest.main()
