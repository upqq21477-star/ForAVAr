from __future__ import annotations
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"P1-Central-Control/scripts"))
from change_classification_router import ChangeClassificationError,classify_and_route,validate_record

class ChangeClassificationRouterTests(unittest.TestCase):
    def test_confirmed_cross_domain_mechanism_routes_as_systemic_capability(self):
        record=classify_and_route({
            "change_id":"F28-NORMAL","statement":"A shared failure mechanism affects planning, construction, and acceptance.",
            "affected_scope":"MULTI_DOMAIN","confirmed_reusable_mechanism":True,
            "evidence_refs":["P1-Central-Control/acceptance/reports/root-cause.json"],
            "evidence":[{"kind":"CONFIRMED","statement":"Same failure mechanism reproduced across domains."}],
            "target_kinds":["contract"],"authoritative_targets":["docs/architecture/P2-System-Blueprint-v1.0.md"],
            "candidate_derived_views":["docs/plans/P2-Relay-Update-Plan.md"]})
        self.assertEqual(record["status"],"ROUTED"); self.assertEqual(record["classification"],"SYSTEMIC_CAPABILITY")
        self.assertTrue(record["eligible_for_blueprint_update"]); self.assertIn("Evolution",record["route"])
        self.assertIn("docs/architecture/P2-System-Blueprint-v1.0.md",record["derived_views_to_sync"])
        validate_record(record,ROOT)

    def test_one_off_is_not_promoted_and_scope_conflict_blocks(self):
        one_off=classify_and_route({
            "change_id":"F28-NEGATIVE-ONE-OFF","statement":"Change this single response only.",
            "affected_scope":"SINGLE_OUTPUT","explicit_one_off":True,"evidence_refs":[],"evidence":[],
            "target_kinds":["content"],"authoritative_targets":[],"candidate_derived_views":[]})
        self.assertEqual(one_off["classification"],"ONE_OFF"); self.assertFalse(one_off["eligible_for_blueprint_update"])
        conflict=classify_and_route({
            "change_id":"F28-NEGATIVE-CONFLICT","statement":"One-off intent conflicts with all-domain impact.",
            "affected_scope":"MULTI_DOMAIN","explicit_one_off":True,"evidence_refs":[],"evidence":[],
            "target_kinds":["global_policy"],"authoritative_targets":[],"candidate_derived_views":[]})
        self.assertEqual(conflict["status"],"BLOCKED_CONFLICT"); self.assertIsNone(conflict["classification"])
        with self.assertRaisesRegex(ChangeClassificationError,"CHANGE_SCOPE_INVALID"):
            classify_and_route({"change_id":"bad","statement":"bad","affected_scope":"EVERYWHERE"})

    def test_recurrence_without_confirmed_evidence_does_not_create_rule(self):
        record=classify_and_route({
            "change_id":"F28-BOUNDARY","statement":"Similar issue appeared twice but the root cause remains uncertain.",
            "affected_scope":"SUBSYSTEM","recurrence_count":2,"confirmed_reusable_mechanism":False,
            "evidence_refs":["notes/repeated-observation.txt"],
            "evidence":[{"kind":"INFERRED","statement":"The causes may be related."}],
            "target_kinds":["contract"],"authoritative_targets":["P1-Central-Control/scripts/central_role_interface.py"],
            "candidate_derived_views":["README.md"]})
        self.assertEqual(record["status"],"NEEDS_EVIDENCE"); self.assertIsNone(record["classification"])
        self.assertFalse(record["eligible_for_blueprint_update"]); self.assertEqual(record["derived_views_to_sync"],[])

if __name__=="__main__": unittest.main()
