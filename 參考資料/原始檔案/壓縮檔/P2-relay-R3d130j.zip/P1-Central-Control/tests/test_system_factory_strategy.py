from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control/scripts"))

from system_factory_strategy import decide_strategy


def _repair_request(**overrides):
    request = {
        "request_id": "F20-TEST",
        "system_id": "SYS-EXAMPLE",
        "request_kind": "FIX_FAILURE",
        "system_status": "PRESENT",
        "inventory_status": "COMPLETE",
        "root_cause_status": "CONFIRMED",
        "repair_scope_bounded": True,
        "architecture_status": "COMPATIBLE",
        "compatibility_status": "COMPATIBLE",
        "rebuild_evidence_status": "NONE",
        "explicit_rebuild_authorization": False,
        "governance_approval": False,
        "rollback_ready": True,
        "scope_ref": "P1-Central-Control/scripts/construction_factory.py",
        "evidence_refs": ["evidence/failure-reproduction.json"],
        "root_cause_refs": ["evidence/root-cause-confirmed.json"],
        "rebuild_evidence_refs": [],
    }
    request.update(overrides)
    return request


class SystemFactoryStrategyTests(unittest.TestCase):
    def test_confirmed_bounded_failure_selects_repair_without_execution_authority(self):
        decision = decide_strategy(_repair_request())
        self.assertEqual(decision["status"], "STRATEGY_SELECTED")
        self.assertEqual(decision["chosen_strategy"], "REPAIR")
        self.assertFalse(decision["execution_authorized"])
        self.assertEqual(decision["scope_ref"], "P1-Central-Control/scripts/construction_factory.py")
        self.assertTrue(any(check["check_id"] == "ROOT_CAUSE" and check["status"] == "PASS" for check in decision["checks"]))

    def test_partial_inventory_blocks_strategy_and_does_not_infer_missing(self):
        decision = decide_strategy(_repair_request(inventory_status="PARTIAL"))
        self.assertEqual(decision["status"], "NEEDS_EVIDENCE")
        self.assertIsNone(decision["chosen_strategy"])
        self.assertFalse(decision["execution_authorized"])
        self.assertTrue(any("unscanned" in warning.lower() for warning in decision["warnings"]))

    def test_rebuild_requires_confirmation_governance_and_rollback(self):
        rebuild = _repair_request(
            request_id="F20-REBUILD",
            request_kind="REPLACE_ARCHITECTURE",
            architecture_status="CONFLICT",
            compatibility_status="INCOMPATIBLE",
            rebuild_evidence_status="CONFIRMED",
            rebuild_evidence_refs=["evidence/architecture-conflict-confirmed.json"],
            root_cause_status="UNKNOWN",
            root_cause_refs=[],
            explicit_rebuild_authorization=False,
            governance_approval=False,
            rollback_ready=False,
        )
        confirmation = decide_strategy(rebuild)
        self.assertEqual(confirmation["status"], "NEEDS_CONFIRMATION")
        self.assertIsNone(confirmation["chosen_strategy"])
        rebuild["explicit_rebuild_authorization"] = True
        governance = decide_strategy(rebuild)
        self.assertEqual(governance["status"], "NEEDS_GOVERNANCE")
        self.assertTrue(governance["governance_approval_required"])
        rebuild["governance_approval"] = True
        rollback = decide_strategy(rebuild)
        self.assertEqual(rollback["status"], "BLOCKED_SCOPE")
        rebuild["rollback_ready"] = True
        approved = decide_strategy(rebuild)
        self.assertEqual(approved["status"], "STRATEGY_SELECTED")
        self.assertEqual(approved["chosen_strategy"], "REBUILD")
        self.assertFalse(approved["execution_authorized"])


if __name__ == "__main__":
    unittest.main()
