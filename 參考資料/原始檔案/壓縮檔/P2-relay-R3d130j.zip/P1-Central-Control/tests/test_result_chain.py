"""020c result chains: measured links, plus mutations that must flip a scenario (R3d12w)."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

SCRIPTS = Path(__file__).resolve().parents[1] / "scripts"
sys.path.insert(0, str(SCRIPTS))
import current_truth_reconciliation  # noqa: E402
import evidence_provenance_guard  # noqa: E402
import result_chain  # noqa: E402


def _by(rows):
    return {r["scenario"]: r["ok"] for r in rows}


class ResultChainTests(unittest.TestCase):
    def test_all_scenarios_pass_and_links_are_measured(self):
        chains, rows = result_chain.scenarios()
        self.assertTrue(all(r["ok"] for r in rows), rows)
        for cid in (result_chain.CHAIN_PACKET, result_chain.CHAIN_RECEIPT):
            self.assertEqual(chains[cid]["exit_code"], 0)
            for link in ("central_controller", "execution_truth", "evidence_provenance_guard", "current_truth_reconciliation"):
                self.assertIn(link, chains[cid]["links_exercised"])
        self.assertIn("runtime_evidence_probe", chains[result_chain.CHAIN_RECEIPT]["links_exercised"])
        self.assertNotIn("runtime_evidence_probe", chains[result_chain.CHAIN_PACKET]["links_exercised"])

    def test_mutation_classifier_never_ingested_fails_chain(self):
        with mock.patch.object(current_truth_reconciliation, "classify_repository_result",
                               return_value=("PERSISTED_PENDING_CENTRAL", {"status": "INCOMPLETE"})):
            chains, rows = result_chain.scenarios()
        self.assertFalse(_by(rows)["CH-PACKET-INGEST-ACCEPT:positive"])
        self.assertEqual(chains[result_chain.CHAIN_PACKET]["exit_code"], 1)

    def test_mutation_noop_evidence_validation_is_caught(self):
        with mock.patch.object(evidence_provenance_guard, "validate_evidence", lambda r: None):
            _, rows = result_chain.scenarios()
        self.assertFalse(_by(rows)["evidence:tampered_record_refused"])

    def test_mutation_failed_probe_not_stopped_is_caught(self):
        real = result_chain.runtime_evidence_probe.execute

        def lie(req):
            out = dict(real(req))
            out["return_code"] = out["expected_exit_code"]  # a failed receipt rewritten as success
            return out

        with mock.patch.object(result_chain.runtime_evidence_probe, "execute", lie):
            _, rows = result_chain.scenarios()
        self.assertFalse(_by(rows)["receipt:failed_probe_stops_before_ingest"])


if __name__ == "__main__":
    unittest.main()
