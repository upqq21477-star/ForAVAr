#!/usr/bin/env python3
"""D11 驗收：Segment 狀態進 Event Log＋Reducer；刪除 Execution Store 後僅憑 Log 重建相符。"""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "tests"))

import central_controller  # noqa: E402
from event_log import EventLog  # noqa: E402
from event_reducer import (  # noqa: E402
    initial_segment_projection,
    log_segment_change,
    recover_workflow,
    replay_segments,
    segment_control_view,
)
from p7_test_records import records_for  # noqa: E402
import test_parallel_scheduler as _psm  # noqa: E402  (模組引用，避免重複收集其測試類)

WF = "WF-P5"


class SegmentEventReplayTests(unittest.TestCase):
    def setUp(self) -> None:
        self.fx = _psm.ParallelSchedulerTests()
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "events.jsonl"
        self.log = EventLog(self.path)
        self.execution_store: dict = {}
        self.distillation_store: dict = {}

    def receive(self, state, packet, decision, store):
        kwargs = {}
        if decision == "WORK_COMPLETE":
            ev, pv = records_for(packet, self.fx.make_result(packet, decision))
            kwargs = {"evidence_records": ev, "provenance_records": pv}
        return central_controller.receive_result(
            state, self.fx.make_result(packet, decision),
            event_log=self.log, execution_store=self.execution_store,
            distillation_store=self.distillation_store, segment_store=store, **kwargs)

    def rebuilt(self) -> dict:
        """只讀檔案；不碰 execution_store／live state。"""
        events = EventLog(self.path).read_all("SEGMENT")
        return replay_segments(initial_segment_projection(), events, workflow_id=WF)

    def test_dependency_block_rebuilds_blocked_segments_from_log_only(self) -> None:
        a, c = self.fx.make_segment("A"), self.fx.make_segment("C", dependencies=["A"])
        store = {"A": a, "C": c}
        state = central_controller.init_state(WF, "TASK")
        state = central_controller.queue_segment(state, a, event_log=self.log)
        state = central_controller.queue_segment(state, c, event_log=self.log)
        state, packets = central_controller.dispatch(
            state, event_log=self.log, execution_store=self.execution_store, max_concurrency=2)
        state = self.receive(state, packets[0], "FAIL", store)

        self.assertTrue(state.get("blocked_segments"))
        self.execution_store.clear()  # 模擬 Execution Store 遺失
        self.assertEqual(self.rebuilt(), segment_control_view(state))
        self.assertEqual(self.rebuilt()["blocked_segments"][0]["segment_id"], "C")

    def test_recover_workflow_reports_segment_match_and_mismatch(self) -> None:
        a = self.fx.make_segment("A")
        state = central_controller.init_state(WF, "TASK")
        state = central_controller.queue_segment(state, a, event_log=self.log)
        state, packets = central_controller.dispatch(
            state, event_log=self.log, execution_store=self.execution_store)
        ok = recover_workflow(state, EventLog(self.path))
        self.assertEqual(ok["segment_status"], "MATCH")
        self.assertEqual(ok["status"], "RECOVERED")

        broken = {**state, "active_segments": []}  # crash 後 Current 落後／被改壞
        bad = recover_workflow(broken, EventLog(self.path))
        self.assertEqual(bad["segment_status"], "MISMATCH")
        self.assertEqual(bad["status"], "RECONCILIATION_REQUIRED")
        self.assertEqual(bad["segment_projection"]["active_segments"], state["active_segments"])

    def test_current_nonempty_segments_without_segment_events_requires_reconciliation(self) -> None:
        a = self.fx.make_segment("A")
        state = central_controller.init_state(WF, "TASK")
        state = central_controller.queue_segment(state, a)  # 故意不寫 Segment Event
        result = recover_workflow(state, EventLog(self.path))
        self.assertEqual(result["status"], "RECONCILIATION_REQUIRED")
        self.assertEqual(result["segment_status"], "NOT_LOGGED_CURRENT_NONEMPTY")
        self.assertEqual(result["next_action"], "RECONCILIATION_REQUIRED")

    def test_retry_timeout_cancel_and_late_result_are_replayable(self) -> None:
        r = self.fx.make_segment("R", max_attempts=2, retry_on=["FAIL"])
        t = self.fx.make_segment("T", max_attempts=2, retry_on=["TIMEOUT"], timeout_ms=1)
        x = self.fx.make_segment("X")
        store = {"R": r, "T": t, "X": x}
        state = central_controller.init_state(WF, "TASK")
        for seg in (r, t, x):
            state = central_controller.queue_segment(state, seg, event_log=self.log)
        state, packets = central_controller.dispatch(
            state, event_log=self.log, execution_store=self.execution_store, max_concurrency=3)
        by_seg = {p["segment_id"]: p for p in packets}
        state = self.receive(state, by_seg["R"], "FAIL", store)           # retry
        state, outcome = central_controller.cancel(
            state, "X", execution_store=self.execution_store, event_log=self.log)
        self.assertEqual(outcome, "CANCELLED")
        state, timed = central_controller.check_timeouts(
            state, now="2099-01-01T00:00:00+00:00", segment_store=store,
            execution_store=self.execution_store, event_log=self.log)      # timeout retry
        self.assertTrue(timed)
        self.assertEqual(self.rebuilt(), segment_control_view(state))
        kinds = {e["event_type"] for e in EventLog(self.path).read_all("SEGMENT")}
        self.assertTrue({"SEGMENT_QUEUED", "SEGMENT_STARTED", "SEGMENT_RESULT_ACCEPTED",
                         "SEGMENT_TIMED_OUT", "SEGMENT_CANCELLED"} <= kinds)

    def test_unlogged_queue_is_caught_up_visibly_but_other_divergence_fails_closed(self) -> None:
        a = self.fx.make_segment("A")
        state = central_controller.init_state(WF, "TASK")
        state = central_controller.queue_segment(state, a)  # 呼叫端忘了傳 event_log
        state, _ = central_controller.dispatch(
            state, event_log=self.log, execution_store=self.execution_store)
        events = EventLog(self.path).read_all("SEGMENT")
        self.assertEqual(events[0]["causation_id"], "CATCHUP:UNLOGGED_QUEUE")
        self.assertEqual(self.rebuilt(), segment_control_view(state))

        diverged = {**state, "completed_segments": [{"segment_id": "Z", "decision_code": "FAIL"}]}
        after = {**diverged, "retry_count": 9}
        with self.assertRaises(ValueError):
            log_segment_change(self.log, diverged, after, event_type="SEGMENT_RESULT_ACCEPTED",
                               causation_id="TEST", occurred_at="2026-10-07T00:00:00+00:00")

    def test_segment_event_revision_gap_is_rejected_on_replay(self) -> None:
        a = self.fx.make_segment("A")
        state = central_controller.init_state(WF, "TASK")
        state = central_controller.queue_segment(state, a, event_log=self.log)
        state, _ = central_controller.dispatch(
            state, event_log=self.log, execution_store=self.execution_store)
        events = EventLog(self.path).read_all("SEGMENT")
        with self.assertRaises(ValueError):
            replay_segments(initial_segment_projection(), events[1:], workflow_id=WF)


if __name__ == "__main__":
    unittest.main()
