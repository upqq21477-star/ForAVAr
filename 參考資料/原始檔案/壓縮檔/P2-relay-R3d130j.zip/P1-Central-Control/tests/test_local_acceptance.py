#!/usr/bin/env python3
from __future__ import annotations

import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import local_acceptance as acceptance  # noqa: E402
sys.path.insert(0, str(Path(__file__).resolve().parent))
from _pending_repo import pending_root  # noqa: E402


class LocalAcceptanceEntrypointTests(unittest.TestCase):
    def test_entrypoint_file_exists(self):
        self.assertTrue(
            (ROOT / "P1-Central-Control/scripts/local_acceptance.py").is_file()
        )

    def test_fail_gate_is_capturable_when_report_exists(self):
        with tempfile.TemporaryDirectory() as temp:
            report = Path(temp) / "control-gate-report.json"
            report.write_text("{}", encoding="utf-8")
            self.assertTrue(acceptance.gate_result_is_capturable(1, report))

    def test_unexpected_gate_code_is_not_capturable(self):
        with tempfile.TemporaryDirectory() as temp:
            report = Path(temp) / "control-gate-report.json"
            report.write_text("{}", encoding="utf-8")
            self.assertFalse(acceptance.gate_result_is_capturable(9, report))

    def test_simulation_report_is_single_c01_close_acceptance(self):
        with patch.object(acceptance, "ROOT", pending_root()):
            report = acceptance.simulated_report(
                "head-sha",
                "base-sha",
            )
        stage_ids = [stage["stage_id"] for stage in report["stages"]]
        self.assertEqual(
            stage_ids,
            [
                "M32_C01_A",
                "M32_C01_B",
                "M32_C01_C",
                "M32_C01_D",
                "M32_C01_E",
                "M32_C01_F",
                "M32_CLOSE_VERTICAL_SLICE",
                "SIMULATION_BOUNDARY",
                "RUNTIME_TRUTH_BOUNDARY",
            ],
        )
        self.assertEqual(report["status"], "PASS")
        self.assertEqual(report["work_unit"], "M32-CLOSE")

    def test_requires_central_acceptance_context(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "P1-CURRENT.json").write_text(
                '{"current_stage":{"id":"M32-CLOSE","status":"IMPLEMENTED_PENDING_CLOSE_ACCEPTANCE"}}',
                encoding="utf-8",
            )
            with self.assertRaisesRegex(
                ValueError,
                "CENTRAL_ACCEPTANCE_CONTEXT_REQUIRED",
            ):
                acceptance.require_central_acceptance_context(root)

    def test_external_result_option_is_declared(self):
        source = (
            ROOT / "P1-Central-Control/scripts/local_acceptance.py"
        ).read_text(encoding="utf-8")
        self.assertIn('--external-result', source)


class RuntimeTruthBoundaryTests(unittest.TestCase):
    """RUNTIME_TRUTH_BOUNDARY 以型別欄位判斷：模擬或未過的觀察不得當真實證據。"""

    check = staticmethod(acceptance.observation_is_not_real_evidence)

    def test_simulation_classification_holds(self):
        self.assertTrue(self.check({"classification": "SIMULATION_FAIL", "program_regression_status": "PASS"}))

    def test_incomplete_regression_holds(self):
        self.assertTrue(self.check({"classification": "CLOSE_ACCEPTANCE_REQUESTED", "program_regression_status": "INCOMPLETE"}))

    def test_real_pass_must_fail(self):
        # 負例：真實通過（非 SIMULATION_*、回歸 PASS）時，邊界檢查必須為 False。
        self.assertFalse(self.check({"classification": "REAL_RUNTIME_PASS", "program_regression_status": "PASS"}))

    def test_missing_or_malformed_fails_closed(self):
        for bad in (None, {}, [], "SIMULATION_ONLY", {"classification": "SIMULATION_FAIL"}, {"classification": 1, "program_regression_status": "PASS"}):
            self.assertFalse(self.check(bad), bad)


if __name__ == "__main__":
    unittest.main()
