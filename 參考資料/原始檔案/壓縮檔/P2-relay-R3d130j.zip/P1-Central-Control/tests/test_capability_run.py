#!/usr/bin/env python3
"""R3d12y：tools/capability_run.py 實跑四項能力；含 3 突變（空跑、清掃失敗、對話失敗）須被抓到。SIMULATION_ONLY。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))

import capability_run as cr  # noqa: E402


class CapabilityRunTests(unittest.TestCase):
    def test_real_run_all_capabilities_pass_with_measured_providers(self) -> None:
        for cap in cr.CAPS:
            with self.subTest(cap):
                self.assertEqual(cr.check(cap), {"capability": cap, "ok": True, "runner_ok": True, "providers_missing": []})

    def test_mutation_runner_that_runs_nothing_is_caught(self) -> None:
        r = cr.check("CAP-EVIDENCE", {"chain": lambda: True})
        self.assertFalse(r["ok"])
        self.assertEqual(r["providers_missing"], ["evidence_provenance_guard"])

    def test_mutation_sweep_failure_is_caught(self) -> None:
        with mock.patch.object(cr.lifecycle_sweep, "simulate_quarantine", lambda: {"status": "FAIL", "steps": []}):
            self.assertFalse(cr.check("CAP-RETIRE")["ok"])

    def test_mutation_dialogue_failure_is_caught(self) -> None:
        with mock.patch.object(cr.dialogue_loop, "simulate", lambda: [("x", False, "mut")]):
            r = cr.check("CAP-CONVERSATION-RECORD")
        self.assertFalse(r["ok"])
        self.assertFalse(r["runner_ok"])


class S3bCapabilityRunTests(unittest.TestCase):
    """R3d12zr S3b②: CAP-VERIFY / CAP-GAP / CAP-ITERATE run and measured by capability_run (SIMULATED_PASS)."""

    NEW = {"CAP-VERIFY": "verify_verdict", "CAP-GAP": "gap_ledger", "CAP-ITERATE": "iterate_control"}

    def test_new_caps_are_in_the_measured_list_and_pass(self) -> None:
        for cap, stem in self.NEW.items():
            with self.subTest(cap):
                self.assertIn(cap, cr.CAPS)
                self.assertEqual(cr.CAPS[cap][0], (stem,))
                self.assertEqual(cr.check(cap), {"capability": cap, "ok": True, "runner_ok": True, "providers_missing": []})

    def test_mutation_verify_always_pass_is_caught(self) -> None:
        with mock.patch.object(cr.verify_verdict, "_decide", lambda ev: ("PASS", [], [])):
            self.assertFalse(cr.check("CAP-VERIFY")["runner_ok"])

    def test_mutation_gap_apply_noop_is_caught(self) -> None:
        with mock.patch.object(cr.gap_ledger, "apply_verdict", lambda ck, v, task: ck):
            self.assertFalse(cr.check("CAP-GAP")["runner_ok"])

    def test_mutation_iterate_always_done_is_caught(self) -> None:
        with mock.patch.object(cr.iterate_control, "decide", lambda ck, limit=3: {"decision": "DONE", "round": 0, "unresolved": []}):
            self.assertFalse(cr.check("CAP-ITERATE")["runner_ok"])

    def test_mutation_runner_that_runs_nothing_is_caught(self) -> None:
        for cap, stem in self.NEW.items():
            with self.subTest(cap):
                r = cr.check(cap, {"verify": lambda: True, "gap": lambda: True, "iterate": lambda: True})
                self.assertFalse(r["ok"])
                self.assertEqual(r["providers_missing"], [stem])

    def test_wiring_audit_reports_the_three_as_wired(self) -> None:
        import subprocess
        root = Path(__file__).resolve().parents[2]
        out = subprocess.run([sys.executable, "-B", str(root / "tools" / "wiring_audit.py")], cwd=root, capture_output=True,
                             text=True, encoding="utf-8").stdout
        for cap in self.NEW:
            with self.subTest(cap):
                line = next(x for x in out.splitlines() if x.startswith(cap + " "))
                self.assertIn("maturity=WIRED", line)


class S3cCapabilityRunTests(unittest.TestCase):
    def test_instruction_routing_is_measured_and_wired(self) -> None:
        self.assertEqual(cr.check("CAP-INSTRUCTION-ROUTING"), {"capability": "CAP-INSTRUCTION-ROUTING", "ok": True, "runner_ok": True, "providers_missing": []})
        with mock.patch.object(cr.habit_counter, "route_instruction", lambda *a, **k: {"outcome": "ROUTED"}):
            self.assertFalse(cr.check("CAP-INSTRUCTION-ROUTING")["runner_ok"])


class S4aCapabilityRunTests(unittest.TestCase):
    def test_ingest_and_extract_are_measured_and_mutations_are_caught(self) -> None:
        for cap, stem in (("CAP-INGEST", "segment_ingest"), ("CAP-EXTRACT", "extract_guard")):
            self.assertEqual(cr.check(cap), {"capability": cap, "ok": True, "runner_ok": True, "providers_missing": []})
            self.assertEqual(cr.check(cap, {"ingest": lambda: True, "extract": lambda: True})["providers_missing"], [stem])
        with mock.patch.object(cr.segment_ingest, "check_coverage", lambda t, s: ["X"]):
            self.assertFalse(cr.check("CAP-INGEST")["runner_ok"])
        with mock.patch.object(cr.extract_guard, "check_fields", lambda sc, r, sg: {k: "OK" for k in sc["fields"]}):
            self.assertFalse(cr.check("CAP-EXTRACT")["runner_ok"])


if __name__ == "__main__":
    unittest.main()
