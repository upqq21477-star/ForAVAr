import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))
sys.path.insert(0, str(ROOT / "P1-Central-Control" / "scripts"))
import feature_lifecycle as fl  # noqa: E402
import librarian as lib  # noqa: E402
import p2_run  # noqa: E402
import pack_handoff as ph  # noqa: E402


def run_with(route):
    t = Path(tempfile.mkdtemp())
    return p2_run.Run(t, write_scope=["."], brief=lib.sample_brief(route, "B"), goal_confirmed=True)


class WiringTests(unittest.TestCase):  # SIMULATED_PASS: temp workdirs only
    def test_build_brief_opens_stage1_checklist_automatically(self):
        r = run_with("BUILD")
        self.assertEqual(r.lifecycle["stage"], 1)

    def test_non_build_brief_opens_nothing(self):
        self.assertIsNone(run_with("STARTUP").lifecycle)

    def test_close_cannot_report_passed_while_lifecycle_open(self):
        r = run_with("BUILD")
        r.attempts.append({"outcome": "success"})
        res = r.close(Path(tempfile.mkdtemp()) / "log.jsonl", "c1")
        self.assertNotEqual(res["outcome_class"], "PASSED")
        self.assertEqual(res["lifecycle_stage"], 1)
        self.assertTrue(res["lifecycle_blockers"])

    def test_relay_rules_carry_the_four_stages_every_session(self):
        text = " ".join(str(b) for b in ph.RULES_BLOCKS)
        for key in ("藍圖", "能運行", "退場", "實際運行"):
            self.assertIn(key, text)


if __name__ == "__main__":
    unittest.main()
