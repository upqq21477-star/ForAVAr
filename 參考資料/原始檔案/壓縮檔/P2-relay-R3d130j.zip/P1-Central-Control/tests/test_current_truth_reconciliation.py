#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
import unittest
from pathlib import Path

from jsonschema import Draft202012Validator, FormatChecker

ROOT = Path(__file__).resolve().parents[2]
SCRIPTS = ROOT / "P1-Central-Control/scripts"
sys.path.insert(0, str(SCRIPTS))

import current_truth_reconciliation as ctr


def base_inputs():
    current = {
        "current_stage": {"id": "WORK-1", "status": "IN_PROGRESS", "merged_commit_sha": "abc1234"},
        "implementation_control": {"active_work_packet": "work.json"},
        "latest_runtime_observation": {"run_id": 10},
    }
    work = {"work_id": "WORK-1"}
    truth_record = {"status": "INCOMPLETE", "head_sha": "abc1234"}
    runtime = {
        "classification": "RUNNER_STARTUP_FAILURE",
        "run": {"id": 10, "head_sha": "abc1234"},
    }
    return current, work, truth_record, runtime


class CurrentTruthReconciliationTests(unittest.TestCase):
    def test_reconcile_output_matches_declared_schema(self):
        current, work, truth_record, runtime = base_inputs()
        result = ctr.reconcile(
            current=current,
            work_packet=work,
            truth_record=truth_record,
            runtime_fixture=runtime,
        )
        schema_path = ROOT / "P1-Central-Control/schemas/current_truth_reconciliation.schema.json"
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        errors = sorted(Draft202012Validator(schema, format_checker=FormatChecker()).iter_errors(result), key=lambda e: list(e.path))
        self.assertEqual([e.message for e in errors], [])

    def test_older_runtime_observation_cannot_replace_current(self):
        current, work, truth_record, runtime = base_inputs()
        current["latest_runtime_observation"] = {
            "observed_at": "2026-10-05T10:00:00Z",
            "run_id": 200,
            "run_attempt": 1,
            "job_id": 300,
            "head_sha": "abc1234",
            "evidence": False,
        }
        runtime["observed_at"] = "2026-10-05T09:59:00Z"
        runtime["run"] = {
            "id": 199,
            "run_attempt": 1,
            "head_sha": "abc1234",
        }
        runtime["job_id"] = 299
        result = ctr.reconcile(
            current=current,
            work_packet=work,
            truth_record=truth_record,
            runtime_fixture=runtime,
        )
        self.assertEqual(result["status"], ctr.BLOCK)
        self.assertIn("STALE_OR_CONFLICTING_RUNTIME_OBSERVATION", result["blocking_conflicts"])

    def test_cross_workflow_observation_is_conflict(self):
        current, _, _, _ = base_inputs()
        current["latest_runtime_observation"] = {
            "observed_at": "2026-10-05T10:00:00Z",
            "workflow": "P1 Control Gate",
            "run_id": 200,
            "run_attempt": 1,
            "job_id": 300,
            "head_sha": "abc1234",
            "evidence": {
                "step_execution_observed": True,
                "step_count": 3,
                "logs_available": True,
            },
        }
        candidate = {
            "observed_at": "2026-10-05T10:00:00Z",
            "workflow": "Other Workflow",
            "run": {
                "id": 201,
                "run_attempt": 1,
                "name": "Other Workflow",
                "head_sha": "abc1234",
            },
            "job_id": 301,
            "classification": "WORKFLOW_EXECUTION_SUCCESS",
        }
        self.assertEqual(
            ctr.compare_observations(
                current["latest_runtime_observation"],
                candidate,
            ),
            "CONFLICT",
        )

    def test_same_runtime_identity_with_more_evidence_is_newer(self):
        current, work, truth_record, runtime = base_inputs()
        current["latest_runtime_observation"] = {
            "observed_at": "2026-10-05T10:00:00Z",
            "run_id": 200,
            "run_attempt": 1,
            "job_id": 300,
            "head_sha": "abc1234",
            "evidence": {
                "step_execution_observed": False,
                "step_count": 0,
                "logs_available": False,
            },
        }
        runtime["observed_at"] = "2026-10-05T10:00:00Z"
        runtime["run"] = {
            "id": 200,
            "run_attempt": 1,
            "head_sha": "abc1234",
        }
        runtime["job_id"] = 300
        runtime["evidence"] = {
            "step_execution_observed": True,
            "step_count": 3,
            "logs_available": True,
        }
        result = ctr.reconcile(
            current=current,
            work_packet=work,
            truth_record=truth_record,
            runtime_fixture=runtime,
        )
        self.assertEqual(result["status"], ctr.INCOMPLETE)
        self.assertNotIn("STALE_OR_CONFLICTING_RUNTIME_OBSERVATION", result["blocking_conflicts"])

    def test_truth_record_fixture_conflict_blocks(self):
        current, work, truth_record, runtime = base_inputs()
        truth_record["head_sha"] = "different"
        result = ctr.reconcile(current=current, work_packet=work, truth_record=truth_record, runtime_fixture=runtime)
        self.assertEqual(result["status"], ctr.BLOCK)
        self.assertIn("TRUTH_RECORD_RUNTIME_HEAD_MISMATCH", result["blocking_conflicts"])

    def test_persisted_repository_result_is_pending_until_central_ingestion(self):
        current, work, truth_record, runtime = base_inputs()
        current["result_refs"] = []
        repository_result = {
            "result_id": "res-1",
            "workflow_id": "WF-1",
            "segment_id": "SEG-1",
            "attempt_id": "ATT-1",
            "skill_id": "skill",
            "skill_version": "1.0",
            "status": "UNRESOLVED",
            "decision_code": "UNRESOLVED",
            "output_refs": [],
            "unresolved": ["external-runtime"],
            "evidence_refs": [],
            "provenance_refs": [],
            "observed_usage": {"model_calls": 0, "tool_calls": 0, "wall_time_ms": 0},
            "usage_observed": False,
            "execution_record_ref": "EXECUTION:ATT-1",
            "object_id": "RESULT_PACKET:res-1",
            "kind": "RESULT_PACKET",
            "schema_version": "1.0",
            "content_hash": "",
        }
        from packet_layer import content_hash
        repository_result["content_hash"] = content_hash(repository_result)
        result = ctr.reconcile(
            current=current,
            work_packet=work,
            truth_record=truth_record,
            runtime_fixture=runtime,
            repository_result=repository_result,
        )
        self.assertEqual(result["repository_result_status"], "PERSISTED_PENDING_CENTRAL")
        self.assertEqual(result["status"], ctr.INCOMPLETE)
        self.assertIn("REPOSITORY_RESULT_PENDING_CENTRAL_INGESTION", result["incomplete_reasons"])

    def test_ingested_repository_result_is_reflected_by_current(self):
        current, work, truth_record, runtime = base_inputs()
        current["result_refs"] = ["res-1"]
        repository_result = {
            "result_id": "res-1",
            "workflow_id": "WF-1",
            "segment_id": "SEG-1",
            "attempt_id": "ATT-1",
            "skill_id": "skill",
            "skill_version": "1.0",
            "status": "UNRESOLVED",
            "decision_code": "UNRESOLVED",
            "output_refs": [],
            "unresolved": ["external-runtime"],
            "evidence_refs": [],
            "provenance_refs": [],
            "observed_usage": {"model_calls": 0, "tool_calls": 0, "wall_time_ms": 0},
            "usage_observed": False,
            "execution_record_ref": "EXECUTION:ATT-1",
            "object_id": "RESULT_PACKET:res-1",
            "kind": "RESULT_PACKET",
            "schema_version": "1.0",
            "content_hash": "",
        }
        from packet_layer import content_hash
        repository_result["content_hash"] = content_hash(repository_result)
        result = ctr.reconcile(
            current=current,
            work_packet=work,
            truth_record=truth_record,
            runtime_fixture=runtime,
            repository_result=repository_result,
        )
        self.assertEqual(result["repository_result_status"], "INGESTED")
        self.assertNotIn("REPOSITORY_RESULT_PENDING_CENTRAL_INGESTION", result["incomplete_reasons"])

    def test_consistent_unverified_state_is_incomplete(self):
        current, work, truth_record, runtime = base_inputs()
        result = ctr.reconcile(current=current, work_packet=work, truth_record=truth_record, runtime_fixture=runtime)
        self.assertEqual(result["status"], ctr.INCOMPLETE)
        self.assertNotIn("TRUTH_RECORD_HEAD_NOT_CURRENT_STAGE_HEAD", result["incomplete_reasons"])

    def test_verified_state_without_pass_evidence_blocks(self):
        current, work, truth_record, runtime = base_inputs()
        current["current_stage"]["status"] = "VERIFIED"
        result = ctr.reconcile(current=current, work_packet=work, truth_record=truth_record, runtime_fixture=runtime)
        self.assertEqual(result["status"], ctr.BLOCK)
        self.assertIn("VERIFIED_WITHOUT_PASS_EVIDENCE", result["blocking_conflicts"])

    def test_closure_verified_pass_with_runner_failure_can_pass(self):
        current, work, truth_record, runtime = base_inputs()
        current["current_stage"]["status"] = "VERIFIED"
        truth_record["status"] = "PASS"
        truth_record["program_truth"] = "PROGRAM_VERIFIED"
        truth_record["closure_status"] = "VERIFIED"
        runtime["classification"] = "RUNNER_STARTUP_FAILURE"
        result = ctr.reconcile(current=current, work_packet=work, truth_record=truth_record, runtime_fixture=runtime)
        self.assertEqual(result["status"], ctr.PASS)

    def test_closure_program_truth_status_mismatch_blocks(self):
        current, work, truth_record, runtime = base_inputs()
        truth_record["status"] = "FAIL"
        truth_record["program_truth"] = "PROGRAM_VERIFIED"
        result = ctr.reconcile(current=current, work_packet=work, truth_record=truth_record, runtime_fixture=runtime)
        self.assertEqual(result["status"], ctr.BLOCK)
        self.assertIn("CLOSURE_PROGRAM_TRUTH_STATUS_MISMATCH", result["blocking_conflicts"])

    def test_verified_pass_with_current_runtime_can_pass(self):
        current, work, truth_record, runtime = base_inputs()
        current["current_stage"]["status"] = "VERIFIED"
        truth_record["status"] = "PASS"
        runtime["classification"] = "WORKFLOW_EXECUTION_SUCCESS"
        runtime["run"]["head_sha"] = "abc1234"
        result = ctr.reconcile(current=current, work_packet=work, truth_record=truth_record, runtime_fixture=runtime)
        self.assertEqual(result["status"], ctr.PASS)


if __name__ == "__main__":
    unittest.main()
