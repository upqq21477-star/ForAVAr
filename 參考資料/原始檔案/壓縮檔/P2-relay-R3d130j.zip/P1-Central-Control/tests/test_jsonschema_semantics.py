"""composed unevaluatedProperties／$ref 的規格語意核對（R3d11d）。

驗證器無關：本檔在 repo 內後備驗證器與真 jsonschema 4.26 下都必須全過。
後備下通過、真依賴下失敗＝後備與真實語意分歧，要修後備（或對應 schema）。
"""
import unittest

from jsonschema import Draft202012Validator as V

U = {"unevaluatedProperties": False}
D = {"$defs": {"d": {"properties": {"a": {}}}}}


def ok(schema, inst):
    return not list(V(schema).iter_errors(inst))


class ComposedUnevaluatedTests(unittest.TestCase):
    def test_allof_properties_count_as_evaluated(self):
        s = {"allOf": [{"properties": {"a": {}}}], **U}
        self.assertTrue(ok(s, {"a": 1}))
        self.assertFalse(ok(s, {"a": 1, "b": 2}))

    def test_ref_properties_count_as_evaluated(self):
        s = {**D, "$ref": "#/$defs/d", **U}
        self.assertTrue(ok(s, {"a": 1}))
        self.assertFalse(ok(s, {"a": 1, "c": 2}))

    def test_allof_with_nested_ref(self):
        self.assertTrue(ok({**D, "allOf": [{"$ref": "#/$defs/d"}], **U}, {"a": 1}))

    def test_anyof_all_matching_branches_evaluate(self):
        s = {"anyOf": [{"properties": {"a": {}}}, {"properties": {"b": {}}}], **U}
        self.assertTrue(ok(s, {"a": 1, "b": 1}))
        self.assertFalse(ok(s, {"c": 1}))

    def test_failed_branch_gives_no_annotation(self):
        s = {"anyOf": [{"properties": {"a": {"type": "string"}}, "required": ["a"]}, {"properties": {"b": {}}}], **U}
        self.assertFalse(ok(s, {"a": 1, "b": 1}))

    def test_if_then_properties(self):
        s = {"if": {"properties": {"k": {"const": 1}}, "required": ["k"]}, "then": {"properties": {"x": {}}}, **U}
        self.assertTrue(ok(s, {"k": 1, "x": 2}))
        self.assertFalse(ok(s, {"k": 2}))

    def test_oneof_matching_branch_evaluates(self):
        s = {"oneOf": [{"properties": {"a": {}}, "required": ["a"]}, {"properties": {"b": {}}, "required": ["b"]}], **U}
        self.assertTrue(ok(s, {"a": 1}))

    def test_not_does_not_evaluate(self):
        self.assertFalse(ok({"not": {"properties": {"a": {"type": "string"}}}, **U}, {"a": 1}))

    def test_schema_valued_unevaluated(self):
        s = {"properties": {"a": {}}, "unevaluatedProperties": {"type": "integer"}}
        self.assertTrue(ok(s, {"a": "s", "b": 1}))
        self.assertFalse(ok(s, {"b": "x"}))

    def test_nested_object_has_own_scope(self):
        self.assertFalse(ok({"properties": {"o": {"properties": {"p": {}}, **U}}}, {"o": {"p": 1, "q": 1}}))

    def test_additional_properties_false(self):
        self.assertFalse(ok({"properties": {"a": {}}, "additionalProperties": False}, {"a": 1, "z": 1}))


if __name__ == "__main__":
    unittest.main()
