from __future__ import annotations
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"P1-Central-Control/scripts"))
from intent_resolution import IntentResolutionError,resolve_intent,validate_result
import central_controller

class IntentResolutionTests(unittest.TestCase):
 def test_clear_intent_resolves_without_redundant_clarification(self):
  result=resolve_intent({"request_id":"F24-NORMAL","user_text":"Summarize the current P2 roadmap","context_facts":[{"status":"CONFIRMED","statement":"The roadmap is the active planning view.","source_ref":"docs/plans/P2-Relay-Update-Plan.md"}]})
  self.assertEqual(result["status"],"RESOLVED")
  self.assertEqual(result["intent_category"],"SUMMARIZE")
  self.assertFalse(result["needs_clarification"])
  validate_result(result,ROOT)
  state=central_controller.init_state("WF-F24-NORMAL","TASK-F24-NORMAL")
  handoff=central_controller.prepare_brain_intent_handoff(state,result)
  self.assertEqual(handoff["status"],"READY_FOR_BRAIN_PROPOSAL")
  self.assertTrue(handoff["candidate_commands"])
  self.assertFalse(handoff["state_written"])
  self.assertEqual(handoff["state_revision"],state["state_revision"])

 def test_ambiguous_and_conflicting_context_returns_bounded_options(self):
  result=resolve_intent({"request_id":"F24-NEGATIVE","user_text":"Help me optimize this","context_facts":[{"status":"CONFLICT","statement":"Two sources disagree about the target.","source_ref":None},{"status":"UNKNOWN","statement":"The target subsystem is not identified.","source_ref":None}]})
  self.assertEqual(result["status"],"CONFLICT_REQUIRES_CLARIFICATION")
  self.assertEqual(len(result["clarification_options"]),3)
  self.assertTrue(result["needs_clarification"])
  self.assertTrue(any("UNKNOWN/CONFLICT" in x for x in result["warnings"]))
  state=central_controller.init_state("WF-F24-NEGATIVE","TASK-F24-NEGATIVE")
  handoff=central_controller.prepare_brain_intent_handoff(state,result)
  self.assertEqual(handoff["status"],"NEEDS_CLARIFICATION")
  self.assertEqual(handoff["candidate_commands"],[])

 def test_correction_slash_hint_and_high_impact_authorization_boundary(self):
  corrected=resolve_intent({"request_id":"F24-BOUNDARY","user_text":"Maybe /xray the system","user_correction":"Explain the /diagram capability without changing files","context_facts":[{"status":"INFERRED","statement":"The user may want code changes.","source_ref":None}]})
  self.assertTrue(corrected["correction_overrides_prior_inference"])
  self.assertEqual(corrected["intent_category"],"EXPLAIN")
  self.assertEqual(corrected["slash_labels_as_capability_hints"][0]["method_hint"],"DIAGRAM_AS_CODE")
  risky=resolve_intent({"request_id":"F24-RISK","user_text":"Delete the old archive"})
  self.assertTrue(risky["confirmation_required"])
  self.assertEqual(risky["authorization_status"],"CONFIRMATION_REQUIRED")
  self.assertEqual(risky["status"],"RESOLVED")
  state=central_controller.init_state("WF-F24-BOUNDARY","TASK-F24-BOUNDARY")
  safe_handoff=central_controller.prepare_brain_intent_handoff(state,corrected)
  self.assertEqual(safe_handoff["status"],"READY_FOR_BRAIN_PROPOSAL")
  risky_handoff=central_controller.prepare_brain_intent_handoff(state,risky)
  self.assertEqual(risky_handoff["status"],"NEEDS_CONFIRMATION")
  self.assertEqual(risky_handoff["candidate_commands"],[])

if __name__=="__main__": unittest.main()
