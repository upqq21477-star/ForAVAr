import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = ROOT / "scripts"
sys.path.insert(0, str(SCRIPTS))

from construction_registration import validate


class ConstructionRegistrationTests(unittest.TestCase):
    def _capability(self, work: Path, capability_id: str = "CAP-NEW"):
        registry = {
            "version": "1.0",
            "capabilities": [{"capability_id": "CAP-OLD"}],
        }
        (work / "P1-Central-Control").mkdir(parents=True)
        (work / "P1-Central-Control/capability_registry.json").write_text(
            json.dumps(registry), encoding="utf-8"
        )
        (work / "candidate.json").write_text(
            json.dumps({
                "capability_id": capability_id,
                "class": "CONTROL",
                "implementation": "CANONICAL",
                "levels": [0, 1],
                "kind": "CONTROL",
                "context_tier": "C1",
                "dependencies": [],
                "retirement_state": "ACTIVE",
            }),
            encoding="utf-8",
        )

    def test_new_capability_is_ready(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            self._capability(work)
            result = validate(
                {
                    "target_type": "CAPABILITY",
                    "target_id": "CAP-NEW",
                    "mode": "CREATE_NEW",
                    "artifact_path": "candidate.json",
                },
                base_dir=work,
            )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["registration"], "READY")

    def test_existing_capability_cannot_be_created_again(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            self._capability(work, "CAP-OLD")
            result = validate(
                {
                    "target_type": "CAPABILITY",
                    "target_id": "CAP-OLD",
                    "mode": "CREATE_NEW",
                    "artifact_path": "candidate.json",
                },
                base_dir=work,
            )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "TARGET_ALREADY_EXISTS")

    def test_update_existing_requires_existing_target(self):
        with tempfile.TemporaryDirectory() as tmp:
            work = Path(tmp)
            self._capability(work, "CAP-MISSING")
            result = validate(
                {
                    "target_type": "CAPABILITY",
                    "target_id": "CAP-MISSING",
                    "mode": "UPDATE_EXISTING",
                    "artifact_path": "candidate.json",
                },
                base_dir=work,
            )
        self.assertEqual(result["status"], "BLOCK")
        self.assertEqual(result["reason"], "TARGET_NOT_FOUND")

    def test_architecture_change_uses_decision_ref(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = validate(
                {
                    "target_type": "ARCHITECTURE_CHANGE",
                    "target_id": "ADR-M20-P9",
                    "mode": "UPDATE_EXISTING",
                    "artifact_path": "not-used.json",
                    "decision_ref": "DECISION:M20-P9",
                },
                base_dir=tmp,
            )
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["registration"], "DECISION_REF_READY")


if __name__ == "__main__":
    unittest.main()
