#!/usr/bin/env python3
"""R3d12y：tools/track_a_dryrun.py（SC-07）；含 3 突變（讀回恆通過、S6 缺漏、程序文字混入 Python 步驟）須被抓到。SIMULATION_ONLY。"""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest import mock

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "tools"))

import track_a_dryrun as ta  # noqa: E402


def _failed(rows: list[tuple[str, bool, str]]) -> list[str]:
    return [n for n, ok, _ in rows if not ok]


class TrackADryRunTests(unittest.TestCase):
    def test_all_checks_pass_on_the_real_repo(self) -> None:
        self.assertEqual(_failed(ta.checks()), [])

    def test_mutation_readback_always_pass_is_caught(self) -> None:
        with mock.patch.object(ta.librarian, "readback", lambda *_a, **_k: {"result": "PASS", "sampled": [], "mismatch": []}):
            self.assertIn("negative: tampered excerpt caught by readback", _failed(ta.checks()))

    def test_mutation_s6_scenario_missing_is_caught(self) -> None:
        with mock.patch.object(ta, "p2_run_s6", lambda: ["S03"]):
            self.assertIn("p2_run --simulate S01-S06 pass", _failed(ta.checks()))

    def test_mutation_procedure_with_python_step_is_caught(self) -> None:
        real = ta.track_a_procedure()
        with mock.patch.object(ta, "track_a_procedure", lambda *_a, **_k: real + ["4. run python3 scripts/librarian.py"]):
            self.assertIn("no Track A step requires Python", _failed(ta.checks()))


if __name__ == "__main__":
    unittest.main()
