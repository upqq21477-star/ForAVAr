# P1｜Central Control Layer

## 定位

P1 Central Control 是所有獨立 System 的唯一協調中心。

它負責：
- 接受任務。
- 保存跨 System 狀態。
- 決定下一個工作段落。
- 建立 Work Segment。
- 將完整工作段落分派給單一 System。
- 接收 System 完整回報。
- 保存 Result / Evidence / Provenance / Trace。
- 決定下一段工作或結束。
- 執行 System 間交接。

中央控制層不取代 System 的專業工作。

## 嚴格拓撲

Central Controller
├─ System A
├─ System B
└─ System C

System A 不能把資料直接交給 System B。
System B 不能取得 System A 的內部狀態。
所有狀態、交接、下一任務與跨 System context 都由 Central Control 持有。

## 工作段落

中央控制器每次只分派一個完整 Work Segment。

Central → 建立 Segment → Dispatch → System 完整執行 → System 回報完整 Result → Central 接收 → 更新中央狀態 → 決定下一 Segment

不得：
System → 做一步 → 回報 → Central → 再做一步 → 回報

除非這一步本身就是一個獨立、可交付的 Work Segment。

## 狀態位置

### Central State
- 整體 Task。
- Segment queue。
- 已完成 System 工作。
- 系統回報。
- handoff history。
- unresolved / gaps。
- global evidence / provenance refs。
- next segment。
- workflow terminal state。

### System Local State
只允許保存本次 Segment 的暫存計算與本 System 內部完成工作所需的 runtime state。

System Local State 不得成為其他 System 的直接輸入來源、全域 workflow state、長期跨工作記憶、Central queue 或其他 System 的 handoff state。

## System 邊界
每個 System 必須有 Input Contract、Output Contract、Boundary、Stop Condition、Failure Condition、Segment Completion Condition。

每次被呼叫都必須是完整工作。

## 唯一交接方向
有效：Central → System、System → Central。
無效：System A → System B、System B → System C。

## 核心原則
System 是 worker。
Central 是 coordinator / router / state owner / handoff manager。
Skill 是 Central Control 的操作規範，不把所有 System 的內部責任混進中央。

## 建設入口

所有新建或重大改造的 System / Function / Skill / Capability / Architecture Change，統一由：

`P1-Central-Control/scripts/construction_entrypoint.py`

接收 Construction Request。

入口會固定執行：

SEMANTIC_SPEC
→ SEMANTIC_SIMULATION
→ DISTILL
→ DISTILLED_VALIDATION
→ CODE_COMPILE
→ CODE_ACCEPTANCE
→ FINALIZE

Construction Request：
`P1-Central-Control/schemas/construction_request.schema.json`

Construction Result：
`P1-Central-Control/schemas/construction_result.schema.json`

Construction Lifecycle：
`P1-Central-Control/schemas/construction_lifecycle_contract.schema.json`

未完成七階段不得回傳 finalized=true。


## 逆向重建入口

Legacy / 半成品 / 文件與程式不一致的系統，先經：

`P1-Central-Control/scripts/reverse_reconstruction.py`

固定順序：

IDENTITY
→ SOURCE_INVENTORY
→ STRUCTURE
→ DEPENDENCY
→ DEEP_READ（延後）
→ RUNTIME（UNKNOWN，除非另有執行證據）

輸出：

- Coverage Ledger
- Structure Map
- Local Dependency Map
- State Assessment
- OBSERVED / CONFIRMED / INFERRED / UNKNOWN / CONFLICT

逆向引擎預設不執行被分析 Repository，避免把未驗證的 runtime 行為當成事實。
