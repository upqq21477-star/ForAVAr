#!/usr/bin/env python3
"""Deterministic adaptive presentation selection. Views never replace source truth."""
from __future__ import annotations
import argparse, json
from pathlib import Path
from typing import Any

ROOT=Path(__file__).resolve().parents[2]
SCHEMA_REF="P1-Central-Control/schemas/presentation_decision.schema.json"
GOALS={"decision","understanding","implementation","audit"}
VIEWS={"auto","prose","table","architecture","flowchart","state_machine","sequence_diagram","interactive","timeline"}
DETAIL={"summary","standard","deep"}
FACT_STATUS={"OBSERVED","CONFIRMED","INFERRED","UNKNOWN","CONFLICT"}

class PresentationDecisionError(ValueError): pass

def _text(value: Any, code: str, limit: int=2000) -> str:
    if not isinstance(value,str) or not value.strip() or len(value)>limit:
        raise PresentationDecisionError(f"PRESENTATION_{code}_INVALID")
    return value.strip()

def _refs(value: Any) -> list[str]:
    if not isinstance(value,list) or len(value)>40:
        raise PresentationDecisionError("PRESENTATION_SOURCE_REFS_INVALID")
    result=[]
    for ref in value:
        if not isinstance(ref,str) or not ref.strip() or len(ref)>500 or ref.strip().startswith(("/","\\")) or ".." in Path(ref.strip()).parts:
            raise PresentationDecisionError("PRESENTATION_SOURCE_REF_INVALID")
        if ref.strip() not in result: result.append(ref.strip())
    return result

def select_presentation(request: dict[str,Any]) -> dict[str,Any]:
    if not isinstance(request,dict): raise PresentationDecisionError("PRESENTATION_REQUEST_OBJECT_REQUIRED")
    decision_id=_text(request.get("decision_id","PRESENTATION:UNSPECIFIED"),"DECISION_ID",120)
    task=_text(request.get("task"),"TASK",4000)
    goal=request.get("presentation_goal","understanding")
    preferred=request.get("preferred_view","auto")
    detail=request.get("detail_level","standard")
    renderer=request.get("renderer_available",False)
    if goal not in GOALS: raise PresentationDecisionError("PRESENTATION_GOAL_INVALID")
    if preferred not in VIEWS: raise PresentationDecisionError("PRESENTATION_PREFERRED_VIEW_INVALID")
    if detail not in DETAIL: raise PresentationDecisionError("PRESENTATION_DETAIL_LEVEL_INVALID")
    if not isinstance(renderer,bool): raise PresentationDecisionError("PRESENTATION_RENDERER_FLAG_INVALID")
    refs=_refs(request.get("source_refs",[]))
    facts=request.get("facts",[])
    if not isinstance(facts,list) or len(facts)>100: raise PresentationDecisionError("PRESENTATION_FACTS_INVALID")
    preserve=["Derived views are never an authority source.","Keep unknown, inferred, conflicting, and not-executed states distinct."]
    warnings=[]
    unknown=False
    for fact in facts:
        if not isinstance(fact,dict) or fact.get("status") not in FACT_STATUS:
            raise PresentationDecisionError("PRESENTATION_FACT_STATUS_INVALID")
        statement=_text(fact.get("statement"),"FACT_STATEMENT")
        status=fact["status"]
        if status in {"UNKNOWN","CONFLICT"}:
            unknown=True; preserve.append(f"{status}: {statement}")
        elif status=="INFERRED": preserve.append(f"INFERRED (not confirmed): {statement}")
    if unknown: warnings.append("UNKNOWN/CONFLICT facts must not be rendered as confirmed relationships.")
    state=request.get("execution_state")
    if state in {"PLANNED","UNKNOWN","NOT_WIRED","NOT_EXECUTED"}:
        preserve.append(f"Execution state remains {state}; do not display as completed.")
    elif state is not None and not isinstance(state,str):
        raise PresentationDecisionError("PRESENTATION_EXECUTION_STATE_INVALID")
    kind=request.get("task_kind","auto")
    if kind not in {"auto","direct","architecture","process","contract","comparison","temporal"}:
        raise PresentationDecisionError("PRESENTATION_TASK_KIND_INVALID")
    folded=task.casefold()
    if kind=="auto":
        if any(x in folded for x in ("架構","責任邊界","依賴關係","architecture","system boundary")): kind="architecture"
        elif any(x in folded for x in ("流程","步驟","狀態轉移","workflow","state machine","sequence")): kind="process"
        elif any(x in folded for x in ("欄位","schema","契約","判定規則","規則表","contract")): kind="contract"
        elif any(x in folded for x in ("比較","篩選","多維","compare","explore")): kind="comparison"
        elif any(x in folded for x in ("時間變化","時間線","timeline")): kind="temporal"
        elif goal=="decision" or len(task)<=160: kind="direct"
        else: kind="contract"
    mapping={"direct":"prose","architecture":"architecture","process":"flowchart","contract":"table","comparison":"interactive","temporal":"timeline"}
    chosen=mapping[kind]
    reason={"direct":"Direct request: concise text is the default.","architecture":"Responsibilities, boundaries, and dependencies suit a layered architecture view.","process":"Sequence, branches, and state transitions suit a flow diagram.","contract":"Fields and rules suit a contract or decision table.","comparison":"Multi-dimensional exploration may benefit from an interactive view.","temporal":"Time-dependent change suits a bounded timeline."}[kind]
    if preferred!="auto": chosen=preferred; reason=f"Caller explicitly preferred {preferred}; evidence and authority restrictions still apply."
    status="DECIDED"
    if chosen in {"interactive","timeline"} and not renderer:
        chosen="prose_and_table"; status="FALLBACK"
        warnings.append("Renderer unavailable; returned an accessible text/table fallback.")
    if chosen=="interactive": preserve.append("Interaction filters the view only; it does not change source state or permissions.")
    if chosen in {"architecture","flowchart","state_machine","sequence_diagram"}:
        preserve.append("Distinguish confirmed edges from planned/unknown edges; include failure and recovery paths where relevant.")
    return {
        "decision_id":decision_id,"status":status,
        "request_kind":{"direct":"DIRECT_ANSWER","architecture":"ARCHITECTURE","process":"PROCESS_OR_STATE","contract":"CONTRACT_OR_RULES","comparison":"COMPARISON_OR_EXPLORATION","temporal":"TEMPORAL_CHANGE"}[kind],
        "selected_view":chosen,"detail_level":detail,"rationale":reason,"source_refs":refs,
        "must_preserve":list(dict.fromkeys(preserve)),"fallback_view":"prose_and_table",
        "warnings":warnings,"renderer_required":chosen in {"interactive","timeline"}
    }

def validate_decision(decision:dict[str,Any],root:Path=ROOT)->None:
    path=root/SCHEMA_REF
    if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve()):
        raise PresentationDecisionError("PRESENTATION_SCHEMA_PATH_INVALID")
    try:
        from jsonschema import Draft202012Validator
        schema=json.loads(path.read_text(encoding="utf-8"))
        Draft202012Validator.check_schema(schema); Draft202012Validator(schema).validate(decision)
    except PresentationDecisionError: raise
    except Exception as exc: raise PresentationDecisionError(f"PRESENTATION_DECISION_SCHEMA_INVALID:{type(exc).__name__}") from exc

def main()->int:
    parser=argparse.ArgumentParser(description="Select an accessible presentation view")
    parser.add_argument("--request",required=True); parser.add_argument("--output")
    args=parser.parse_args()
    try:
        request=json.loads(Path(args.request).read_text(encoding="utf-8"))
        decision=select_presentation(request); validate_decision(decision)
        rendered=json.dumps(decision,ensure_ascii=False,indent=2)+"\n"
        if args.output: Path(args.output).write_text(rendered,encoding="utf-8")
        print(rendered,end=""); return 0
    except (OSError,json.JSONDecodeError,PresentationDecisionError) as exc:
        print(json.dumps({"status":"BLOCKED","reason_code":str(exc).split(":",1)[0],"detail":str(exc)},ensure_ascii=False,indent=2)); return 2

if __name__=="__main__": raise SystemExit(main())
