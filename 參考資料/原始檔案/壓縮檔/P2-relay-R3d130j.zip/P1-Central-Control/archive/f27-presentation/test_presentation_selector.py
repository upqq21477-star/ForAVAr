from __future__ import annotations
import sys
import unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/"P1-Central-Control/scripts"))
from presentation_selector import PresentationDecisionError,select_presentation,validate_decision

class PresentationSelectorTests(unittest.TestCase):
    def test_simple_and_structured_requests_select_semantic_views(self):
        simple=select_presentation({"decision_id":"F27-NORMAL-SIMPLE","task":"Explain this setting","task_kind":"direct"})
        structured=select_presentation({"decision_id":"F27-NORMAL-STRUCTURED","task":"Explain workflow state transitions","task_kind":"process","source_refs":["docs/architecture/P2-System-Blueprint-v1.0.md"],"facts":[{"status":"CONFIRMED","statement":"Construction precedes local simulation."}]})
        self.assertEqual(simple["selected_view"],"prose")
        self.assertEqual(structured["selected_view"],"flowchart")
        self.assertEqual(structured["source_refs"],["docs/architecture/P2-System-Blueprint-v1.0.md"])

    def test_unknown_and_conflicting_facts_are_never_promoted(self):
        decision=select_presentation({"decision_id":"F27-NEGATIVE","task":"Map dependencies","task_kind":"architecture","facts":[{"status":"UNKNOWN","statement":"Caller X may be connected."},{"status":"CONFLICT","statement":"Two sources disagree about owner Y."},{"status":"INFERRED","statement":"Possible dependency Z."}]})
        preserved=" ".join(decision["must_preserve"])
        self.assertIn("UNKNOWN:",preserved); self.assertIn("CONFLICT:",preserved); self.assertIn("INFERRED (not confirmed):",preserved)
        self.assertTrue(decision["warnings"])
        with self.assertRaisesRegex(PresentationDecisionError,"PRESENTATION_FACT_STATUS_INVALID"):
            select_presentation({"decision_id":"bad","task":"Map dependencies","facts":[{"status":"PASS","statement":"Unsupported."}]})

    def test_unavailable_renderer_falls_back_to_text_and_table(self):
        decision=select_presentation({"decision_id":"F27-BOUNDARY","task":"Compare options interactively","task_kind":"comparison","renderer_available":False,"detail_level":"deep"})
        self.assertEqual(decision["status"],"FALLBACK"); self.assertEqual(decision["selected_view"],"prose_and_table")
        self.assertEqual(decision["fallback_view"],"prose_and_table"); self.assertFalse(decision["renderer_required"])
        validate_decision(decision,ROOT)

if __name__=="__main__": unittest.main()
