"""R8: conflict / stale evidence gate through the vertical slice (error_exits row 9)."""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

from foravar_vertical_slice import run_vertical_slice  # noqa: E402
from error_exits import ERROR_EXITS  # noqa: E402
import evidence_gate  # noqa: E402
from loop_fixtures import HIGH, LOW, OBS, OBS2, OBS3, TID, Fake, passing, task  # noqa: E402

ACTION = "RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE"
CONFLICT_RECORDS = [OBS, OBS2]


def ev(records=None, conflicts=None, status="CONFLICT"):
    d = {"task_id": TID, "status": status, "records": list(records or CONFLICT_RECORDS), "critical_unknowns": []}
    if conflicts is not None:
        d["conflicts"] = conflicts
    return d


def conflict(resolution=None):
    c = {"conflict_id": "K1", "evidence_ids": ["E1", "E2"]}
    if resolution is not None:
        c["resolution"] = resolution
    return c


def run(profile, evidence, evaluate=None, **task_kw):
    fake = Fake(evaluate_script=[evaluate or passing()], evidence=evidence)
    return run_vertical_slice(task(profile, **task_kw), fake.adapters(**({"clock": lambda: "2026-10-24T00:00:00Z"}))), fake


class ConflictTests(unittest.TestCase):
    def test_unresolved_conflict_low_risk_cannot_pass(self):
        r, fake = run(LOW, ev())
        self.assertEqual(r["status"], "PARTIAL")
        self.assertEqual(r["feedback"]["action"], ACTION)
        self.assertEqual(r["acceptance"]["failure_class"], "SOURCE_OR_EVIDENCE_ERROR")
        self.assertEqual(fake.calls["execute"], 1)
        self.assertTrue(r["evidence_gate"]["blocks_pass"])

    def test_unresolved_conflict_high_risk_blocked_before_execute(self):
        r, fake = run(HIGH, ev())
        self.assertEqual((r["status"], r["feedback"]["action"], r["failure_class"]), ("BLOCKED", ACTION, "SOURCE_OR_EVIDENCE_ERROR"))
        self.assertEqual(fake.calls["execute"], 0)

    def test_side_effect_task_blocked_before_execute(self):
        r, fake = run({**LOW, "side_effects": True}, ev())
        self.assertEqual(r["status"], "BLOCKED")
        self.assertEqual(fake.calls["execute"], 0)

    def test_unknown_side_effect_metadata_counts_as_side_effecting(self):
        prof = {k: v for k, v in LOW.items() if k != "side_effects"}
        r, fake = run(prof, ev())
        self.assertEqual((r["status"], fake.calls["execute"]), ("BLOCKED", 0))

    def test_resolution_citing_observed_outside_evidence_allows_pass(self):
        res = {"resolved_by": ["E3"], "summary": "primary source confirms E1"}
        r, _ = run(HIGH, ev([OBS, OBS2, OBS3], [conflict(res)]), passing(("E1", "E3")))
        self.assertEqual(r["status"], "PASS")
        self.assertEqual(r["evidence_gate"]["conflicts"], [])

    def test_claiming_resolved_without_evidence_does_not_count(self):
        for res in ({"summary": "resolved"}, {"resolved_by": []}, {"resolved_by": ["E9"]}, {"resolved_by": ["E1"]}):
            with self.subTest(res=res):
                r, fake = run(HIGH, ev([OBS, OBS2], [conflict(res)]))
                self.assertEqual((r["status"], fake.calls["execute"]), ("BLOCKED", 0))

    def test_resolution_citing_unobserved_record_does_not_count(self):
        declared = {**OBS3, "status": "DECLARED"}
        r, _ = run(LOW, ev([OBS, OBS2, declared], [conflict({"resolved_by": ["E3"]})]))
        self.assertEqual(r["status"], "PARTIAL")

    def test_profile_flag_without_conflict_list_is_unresolved(self):
        r, _ = run({**LOW, "has_source_conflict": True}, ev(status="READY"))
        self.assertEqual(r["status"], "PARTIAL")
        self.assertEqual(r["evidence_gate"]["conflicts"][0]["conflict_id"], "UNIDENTIFIED")

    def test_evaluation_claim_needs_resolution_evidence_id(self):
        base = ev([OBS, OBS2, OBS3], [conflict()])
        ok, _ = run(LOW, base, passing(("E1", "E3"), conflict_resolutions=[{"conflict_id": "K1", "resolved_by": ["E3"]}]))
        self.assertEqual(ok["status"], "PASS")
        bad, _ = run(LOW, base, passing(conflict_resolutions=[{"conflict_id": "K1", "resolved_by": []}]))
        self.assertEqual(bad["status"], "PARTIAL")

    def test_non_pass_outcomes_keep_their_status(self):
        failing = {"task_id": TID, "criteria_results": [{"criterion_id": "C1", "status": "FAIL", "evidence_ids": ["E1"]}], "failure_branch": "LOCAL_FAILURE"}
        r, _ = run(LOW, ev(), failing)
        self.assertEqual((r["status"], r["feedback"]["action"]), ("FAILED", "REPAIR_LOCAL_NODE_AND_REGRESS"))

    def test_no_conflict_passes_and_fast_path_untouched(self):
        r, _ = run(LOW, ev(status="READY"))
        self.assertEqual(r["status"], "PASS")
        self.assertEqual(r["evidence_gate"], {"conflicts": [], "stale": [], "blocks_pass": False, "reasons": []})
        fast = {"risk_level": "LOW", "requires_external_evidence": False, "requires_diagnostic": False, "has_source_conflict": False,
                "has_critical_unknowns": False, "side_effects": False}
        r2 = run_vertical_slice(task(fast), Fake(evaluate_script=[passing(("E1",))]).adapters())
        self.assertIn("EVIDENCE_SHORT_CIRCUIT", r2["trace"])


class StaleTests(unittest.TestCase):
    def test_target_revision_mismatch_is_stale_low_risk_partial(self):
        r, _ = run(LOW, ev(status="READY", records=[OBS]), target_revision="r2")
        self.assertEqual((r["status"], r["feedback"]["action"]), ("PARTIAL", ACTION))
        self.assertEqual(r["evidence_gate"]["stale"][0]["evidence_id"], "E1")

    def test_target_revision_mismatch_high_risk_blocked_before_execute(self):
        r, fake = run(HIGH, ev(status="READY", records=[OBS]), target_revision="r2")
        self.assertEqual((r["status"], fake.calls["execute"]), ("BLOCKED", 0))

    def test_matching_revision_passes(self):
        r, _ = run(HIGH, ev(status="READY", records=[OBS]), target_revision="r1")
        self.assertEqual(r["status"], "PASS")

    def test_expiry_uses_clock_and_fails_closed(self):
        expired = {**OBS, "valid_until": "2026-10-01"}
        r, _ = run(LOW, ev(status="READY", records=[expired]))
        self.assertEqual(r["status"], "PARTIAL")
        fresh = {**OBS, "valid_until": "2026-12-01T00:00:00Z"}
        self.assertEqual(run(LOW, ev(status="READY", records=[fresh]))[0]["status"], "PASS")
        garbage = {**OBS, "valid_until": "next tuesday"}
        r3, _ = run(LOW, ev(status="READY", records=[garbage]))
        self.assertEqual(r3["status"], "PARTIAL")
        self.assertIn("unparseable", r3["evidence_gate"]["stale"][0]["reason"])

    def test_stale_execution_evidence_blocks_pass_at_acceptance(self):
        stale_exec = {**OBS3, "target_revision": "r0"}
        fake = Fake(evaluate_script=[passing()], execute_script=[{**__import__("loop_fixtures").good_exec(), "evidence_records": [stale_exec]}])
        r = run_vertical_slice(task(LOW, target_revision="r1"), fake.adapters())
        self.assertEqual((r["status"], r["feedback"]["action"]), ("PARTIAL", ACTION))

    def test_only_observed_records_can_be_stale(self):
        out = evidence_gate.stale_records([{**OBS, "status": "DECLARED", "target_revision": "zz"}], target_revision="r1",
                                          now=__import__("datetime").datetime.now(__import__("datetime").timezone.utc))
        self.assertEqual(out, [])


class TableTests(unittest.TestCase):
    def test_row9_matches_blueprint(self):
        with open(os.path.join(os.path.dirname(__file__), "..", "docs", "blueprint.json"), encoding="utf-8") as fh:
            bp = json.load(fh)
        row = [r for r in bp["architecture"]["closed_loop"]["error_exits"]["map"] if "STALE" in r["event"]][0]
        status, action, cls = ERROR_EXITS["EVIDENCE_CONFLICT_OR_STALE"]
        self.assertEqual((action, cls), (row["action"], row["class"]))
        self.assertTrue(row["status"].startswith(status))
        self.assertIn("BLOCKED", row["status"])


if __name__ == "__main__":
    unittest.main()
