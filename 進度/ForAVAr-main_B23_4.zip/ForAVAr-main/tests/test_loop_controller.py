"""R7: closed-loop controller consumes feedback.action per blueprint closed_loop.reentry (contract level, fake adapters)."""
import json
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

import foravar_vertical_slice as slice_mod  # noqa: E402
from foravar_vertical_slice import FAILURE_BRANCHES, FAILURE_CLASSES  # noqa: E402
from error_exits import ERROR_EXITS  # noqa: E402
import loop_controller as lc  # noqa: E402
from loop_controller import FAILURE_CLASS_SOURCES, REENTRY, attribute, load_loop_state, run_closed_loop  # noqa: E402
from loop_fixtures import HIGH, LOW, OBS, OBS2, OBS3, TID, Fake, failing, good_exec, passing, task, unknown  # noqa: E402

B = {"max_attempts": 4}
GRAPH = {"a": [], "b": ["a"]}


def correction(root="METHOD_OR_ROUTING_ERROR", cause=("E1",), changed=("a",)):
    return {"symptom": "s", "root_cause": root, "cause_evidence_ids": list(cause), "evidence": [OBS], "graph": GRAPH,
            "changed": list(changed), "tests_by_item": {"a": ["t_a"], "b": ["t_b"]}}


def go(fake, handlers=None, budget=B, profile=LOW, persist=None, adapters=None, tsk=None, **kw):
    return run_closed_loop(tsk or task(profile), adapters or fake.adapters(), budget=budget, handlers=handlers or {}, persist=persist, **kw)


def boom(ctx):
    raise AssertionError("handler must not be called")


class Dirs:
    def __enter__(self):
        self.a, self.b = tempfile.TemporaryDirectory(), tempfile.TemporaryDirectory()
        return {"root": self.a.name, "snap_dir": self.b.name}

    def __exit__(self, *exc):
        self.a.cleanup()
        self.b.cleanup()


class BranchReentryTests(unittest.TestCase):
    def test_pass_first_attempt(self):
        r = go(Fake())
        self.assertEqual((r["final_status"], r["attempts"], r["stop"]["condition"]), ("PASS", 1, "ACCEPTED_BY_SLICE"))

    def test_local_failure_repair_within_plan_then_regression_gate(self):
        for done, expect in ((["t_a", "t_b"], "PASS"), (["t_a"], "PARTIAL")):
            with self.subTest(done=done):
                fake = Fake([failing("LOCAL_FAILURE"), passing()])
                h = {"REPAIR_LOCAL_NODE_AND_REGRESS": lambda ctx: {"correction": correction(), "apply": lambda plan, d=done: {"actually_changed": ["a"], "regression_run": d}}}
                r = go(fake, h)
                self.assertEqual((r["final_status"], r["attempts"]), (expect, 2))
                self.assertEqual(r["regression"]["required"], ["t_a", "t_b"])
                if expect == "PARTIAL":
                    self.assertEqual(r["stop"]["condition"], "REGRESSION_INCOMPLETE")
                    self.assertEqual(r["open_items"], ["t_b"])

    def test_local_repair_outside_plan_is_change_set_mismatch(self):
        fake = Fake([failing("LOCAL_FAILURE"), passing()])
        h = {"REPAIR_LOCAL_NODE_AND_REGRESS": lambda ctx: {"correction": correction(), "apply": lambda plan: {"actually_changed": ["a", "zzz"]}}}
        r = go(fake, h)
        self.assertEqual((r["final_status"], r["stop"]["condition"], r["stop"]["failure_class"]), ("BLOCKED", "CHANGE_SET_MISMATCH", "INTEGRATION_OR_DEPENDENCY_UPDATE_ERROR"))
        self.assertEqual(r["stop"]["action"], "RESTORE_AND_REPLAN")
        self.assertEqual((r["unexpected"], r["attempts"]), (["zzz"], 1))

    def test_local_repair_without_plan_or_new_info_stops(self):
        r = go(Fake([failing("LOCAL_FAILURE"), passing()]), {"REPAIR_LOCAL_NODE_AND_REGRESS": lambda ctx: {}})
        self.assertEqual(r["stop"]["condition"], "NO_NEW_INFORMATION")

    def test_method_failure_reroute_needs_a_different_method(self):
        ok = go(Fake([failing("METHOD_FAILURE"), passing()]), {"REROUTE_METHOD": lambda ctx: {"method": "m2"}})
        self.assertEqual((ok["final_status"], ok["history"][0]["failure_class"]), ("PASS", "METHOD_OR_ROUTING_ERROR"))
        same = go(Fake([failing("METHOD_FAILURE"), passing()]), {"REROUTE_METHOD": lambda ctx: {}})
        self.assertEqual((same["final_status"], same["stop"]["condition"], same["stop"]["failure_class"]), ("PARTIAL", "NO_NEW_INFORMATION", "COST_OR_STOP_ERROR"))

    def test_model_failure_revises_model(self):
        fake = Fake([failing("MODEL_FAILURE"), passing()])
        seen = {}
        h = {"REVISE_PROBLEM_MODEL": lambda ctx: seen.update(node=ctx["node"]) or {"adapters": {"frame": fake.adapters()["frame"]}}}
        r = go(fake, h)
        self.assertEqual((r["final_status"], seen["node"], r["history"][0]["failure_class"]), ("PASS", "N07-N09", "INFERENCE_OR_MODEL_ERROR"))

    def test_frame_failure_reframes_with_new_task(self):
        fake = Fake([failing("FRAME_FAILURE"), passing()])
        r = go(fake, {"REFRAME_PROBLEM": lambda ctx: {"task": task(LOW, goal="reframed goal")}})
        self.assertEqual((r["final_status"], r["history"][0]["failure_class"]), ("PASS", "GOAL_OR_SEMANTIC_ERROR"))

    def test_evidence_gap_gathers_new_evidence(self):
        fake = Fake([failing("EVIDENCE_GAP"), passing()])
        r = go(fake, {"GATHER_DISCRIMINATING_EVIDENCE": lambda ctx: {"new_evidence_ids": ["E5"]}})
        self.assertEqual((r["final_status"], r["history"][0]["failure_class"], r["history"][1]["new_evidence_ids"]), ("PASS", "SOURCE_OR_EVIDENCE_ERROR", ["E5"]))

    def test_authorization_failure_waits_for_authority(self):
        r = go(Fake([failing("AUTHORIZATION_FAILURE")]), {"STOP_AND_REQUEST_AUTHORIZATION": boom})
        self.assertEqual((r["final_status"], r["stop"]["failure_class"], r["attempts"]), ("BLOCKED", "AUTHORIZATION_OR_POLICY_BLOCK", 1))

    def test_no_feasible_solution_rejects(self):
        r = go(Fake([failing("NO_FEASIBLE_SOLUTION")]), {"REJECT_WITH_REASON": boom})
        self.assertEqual((r["final_status"], r["stop"]["reenter"], r["stop"]["failure_class"]), ("REJECTED", "F7", "GOAL_OR_SEMANTIC_ERROR"))


class ClassifyTests(unittest.TestCase):
    def classify(self, spec, extra=None):
        h = {"CLASSIFY_FAILURE_BEFORE_RETRY": lambda ctx: spec, "REROUTE_METHOD": lambda ctx: {"method": "m2"}, **(extra or {})}
        return go(Fake([failing("NONE"), passing()]), h)

    def test_evidence_supported_root_cause_then_branch_reentry(self):
        r = self.classify({"branch": "METHOD_FAILURE", "correction": correction()})
        self.assertEqual((r["final_status"], r["history"][0]["failure_class"], r["history"][0]["attribution"]), ("PASS", "METHOD_OR_ROUTING_ERROR", "classified:evidence"))

    def test_root_cause_without_evidence_is_unknown(self):
        r = self.classify({"branch": "METHOD_FAILURE", "correction": correction(cause=())})
        self.assertEqual((r["final_status"], r["history"][0]["failure_class"]), ("PASS", "UNKNOWN"))

    def test_no_branch_stays_unattributed(self):
        r = self.classify({"branch": "NONE"})
        self.assertEqual((r["final_status"], r["stop"]["condition"], r["stop"]["failure_class"], r["attempts"]), ("FAILED", "UNATTRIBUTED", "UNKNOWN", 1))

    def test_no_classifier_means_no_blind_retry(self):
        fake = Fake([failing("NONE"), passing()])
        r = go(fake)
        self.assertEqual((r["stop"]["condition"], r["stop"]["failure_class"], fake.calls["execute"]), ("NO_HANDLER", "UNKNOWN", 1))

    def test_classified_terminal_branch_stops(self):
        r = self.classify({"branch": "NO_FEASIBLE_SOLUTION", "reason": "hard constraint"})
        self.assertEqual(r["final_status"], "REJECTED")


class InconclusiveTests(unittest.TestCase):
    def fake(self, exec_script=None):
        return Fake([passing()], execute_script=exec_script or [TimeoutError("slow"), good_exec()])

    def test_inspect_not_applied_with_new_observation_then_execute_retry(self):
        fake = self.fake()
        r = go(fake, {"INSPECT_ACTUAL_STATE_BEFORE_RETRY": lambda ctx: {"outcome": "NOT_APPLIED", "new_evidence_ids": ["INS-1"]}}, profile=HIGH)
        self.assertEqual((r["final_status"], fake.calls["execute"], r["history"][0]["status"]), ("PASS", 2, "INCONCLUSIVE"))
        self.assertTrue(r["history"][0]["unknown_side_effect"])

    def test_inspection_without_new_information_stops_blocked(self):
        fake = self.fake()
        r = go(fake, {"INSPECT_ACTUAL_STATE_BEFORE_RETRY": lambda ctx: {"outcome": "NOT_APPLIED"}}, profile=HIGH)
        self.assertEqual((r["final_status"], r["stop"]["condition"], fake.calls["execute"]), ("BLOCKED", "NO_NEW_INFORMATION", 1))

    def test_effect_already_applied_evaluates_without_rerunning_execute(self):
        fake = self.fake([TimeoutError("slow")])
        r = go(fake, {"INSPECT_ACTUAL_STATE_BEFORE_RETRY": lambda ctx: {"outcome": "APPLIED", "execution": good_exec()}}, profile=HIGH)
        self.assertEqual((r["final_status"], fake.calls["execute"], fake.calls["evaluate"], fake.calls["frame"]), ("PASS", 1, 1, 1))

    def test_applied_without_observed_execution_is_incomplete(self):
        r = go(self.fake(), {"INSPECT_ACTUAL_STATE_BEFORE_RETRY": lambda ctx: {"outcome": "APPLIED"}}, profile=HIGH)
        self.assertEqual((r["final_status"], r["stop"]["condition"]), ("INCONCLUSIVE", "INSPECTION_INCOMPLETE"))

    def test_handler_must_report_outcome(self):
        r = go(self.fake(), {"INSPECT_ACTUAL_STATE_BEFORE_RETRY": lambda ctx: {"new_evidence_ids": ["X"]}}, profile=HIGH)
        self.assertEqual(r["stop"]["condition"], "INSPECTION_INCOMPLETE")

    def test_no_inspector_means_no_auto_rerun(self):
        fake = self.fake()
        r = go(fake, profile=HIGH)
        self.assertEqual((r["final_status"], r["stop"]["condition"], fake.calls["execute"]), ("INCONCLUSIVE", "NO_HANDLER", 1))


class NotProvenTests(unittest.TestCase):
    def test_evaluator_fault_reruns_evaluation_only(self):
        fake = Fake([RuntimeError("boom"), passing()])
        r = go(fake)
        self.assertEqual((r["final_status"], fake.calls["execute"], fake.calls["evaluate"], fake.calls["route"]), ("PASS", 1, 2, 1))
        self.assertEqual(r["history"][0]["failure_class"], "ACCEPTANCE_OR_MEASUREMENT_ERROR")

    def test_permanently_broken_evaluator_is_bounded(self):
        fake = Fake([RuntimeError("boom")])
        r = go(fake, budget={"max_attempts": 3})
        self.assertEqual((r["final_status"], r["stop"]["condition"], r["stop"]["failure_class"], fake.calls["execute"]), ("PARTIAL", "BUDGET_EXHAUSTED", "COST_OR_STOP_ERROR", 1))

    def test_unknown_is_preserved_without_gatherer(self):
        r = go(Fake([unknown()]))
        self.assertEqual((r["final_status"], r["stop"]["condition"], r["open_items"]), ("NOT_PROVEN", "UNKNOWN_PRESERVED", ["C1"]))

    def test_unknown_resolved_when_gatherer_adds_evidence(self):
        r = go(Fake([unknown(), passing()]), {"PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE": lambda ctx: {"new_evidence_ids": ["E8"]}})
        self.assertEqual((r["final_status"], r["attempts"]), ("PASS", 2))


class ErrorExitReentryTests(unittest.TestCase):
    def test_conflict_refresh_reentry(self):
        conflicted = {"task_id": TID, "status": "CONFLICT", "records": [OBS, OBS2], "critical_unknowns": [], "conflicts": [{"conflict_id": "K1", "evidence_ids": ["E1", "E2"]}]}
        resolved = {**conflicted, "records": [OBS, OBS2, OBS3], "conflicts": [{**conflicted["conflicts"][0], "resolution": {"resolved_by": ["E3"]}}]}
        fake = Fake([passing(("E1",)), passing(("E1", "E3"))], evidence=conflicted)
        h = {"RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE": lambda ctx: {"new_evidence_ids": ["E3"], "adapters": {"evidence": lambda t, f: dict(resolved)}}}
        r = go(fake, h)
        self.assertEqual((r["final_status"], r["history"][0]["status"], r["history"][0]["failure_class"]), ("PASS", "PARTIAL", "SOURCE_OR_EVIDENCE_ERROR"))

    def test_task_input_fix(self):
        bad = {**task(LOW), "goal": ""}
        r = go(Fake(), {"FIX_TASK_INPUT": lambda ctx: {"task": task(LOW)}}, tsk=bad)
        self.assertEqual((r["final_status"], r["history"][0]["failure_class"]), ("PASS", "GOAL_OR_SEMANTIC_ERROR"))

    def test_adapter_replacement_required(self):
        fake = Fake()
        broken = fake.adapters(frame=lambda t: (_ for _ in ()).throw(RuntimeError("frame down")))
        r = go(fake, {"FIX_OR_REPLACE_ADAPTER": lambda ctx: {"adapters": {"frame": fake.adapters()["frame"]}}}, adapters=broken)
        self.assertEqual((r["final_status"], r["history"][0]["failure_class"]), ("PASS", "TOOL_OR_ADAPTER_ERROR"))
        r2 = go(fake, {"FIX_OR_REPLACE_ADAPTER": lambda ctx: {}}, adapters=broken)
        self.assertEqual(r2["stop"]["condition"], "NO_NEW_INFORMATION")

    def test_authorization_denied_waits(self):
        deny = Fake().adapters(authorize=lambda t, r: {"task_id": TID, "status": "DENIED", "reason": "no"})
        r = go(Fake(), {"STOP_AND_REQUEST_AUTHORIZATION": boom}, profile=HIGH, adapters=deny)
        self.assertEqual((r["final_status"], r["stop"]["failure_class"]), ("BLOCKED", "AUTHORIZATION_OR_POLICY_BLOCK"))

    def test_handler_faults_are_named_stops(self):
        def raiser(ctx):
            raise RuntimeError("nope")
        r = go(Fake([failing("METHOD_FAILURE")]), {"REROUTE_METHOD": raiser})
        self.assertEqual((r["final_status"], r["stop"]["condition"], r["stop"]["failure_class"]), ("FAILED", "HANDLER_FAULT", "TOOL_OR_ADAPTER_ERROR"))
        r2 = go(Fake([failing("METHOD_FAILURE")]), {"REROUTE_METHOD": lambda ctx: {"bogus": 1}})
        self.assertEqual(r2["stop"]["condition"], "HANDLER_FAULT")

    def test_public_entry_never_raises(self):
        r = go(Fake(), budget={})
        self.assertEqual((r["final_status"], r["stop"]["condition"]), ("BLOCKED", "BUDGET_INVALID"))
        r2 = run_closed_loop("not a task", {}, budget=B)
        self.assertIn(r2["final_status"], {"BLOCKED", "FAILED"})
        r3 = run_closed_loop(task(LOW), Fake().adapters(), budget=B, runner=lambda t, a: 1 / 0)
        self.assertEqual(r3["stop"]["condition"], "CONTROLLER_FAULT")


class BudgetAndCheckpointTests(unittest.TestCase):
    def always_new_method(self):
        return {"REROUTE_METHOD": lambda ctx: {"method": f"m{ctx['attempt'] + 1}"}}

    def test_budget_exhaustion_saves_state_and_closes_partial_or_blocked(self):
        for profile, expect in ((LOW, "PARTIAL"), (HIGH, "BLOCKED")):
            with self.subTest(profile=profile["risk_level"]), Dirs() as p:
                r = go(Fake([failing("METHOD_FAILURE")]), self.always_new_method(), budget={"max_attempts": 2}, profile=profile, persist=p)
                self.assertEqual((r["final_status"], r["stop"]["condition"], r["stop"]["failure_class"], r["attempts"]), (expect, "BUDGET_EXHAUSTED", "COST_OR_STOP_ERROR", 2))
                with open(os.path.join(p["root"], "state", f"{TID}.bundle.json"), encoding="utf-8") as fh:
                    bundle = json.load(fh)
                self.assertEqual((bundle["level"], bundle["TASK_EXECUTION_STATE"]["status"], bundle["TASK_EXECUTION_STATE"]["next_action"]), ("P2", expect, "STOP_PARTIAL_STATE_SAVED"))

    def test_cost_budget_counts_handler_cost(self):
        h = {"REROUTE_METHOD": lambda ctx: {"method": f"m{ctx['attempt'] + 1}", "cost": 5}}
        r = go(Fake([failing("METHOD_FAILURE")]), h, budget={"max_attempts": 9, "max_cost": 5})
        self.assertEqual((r["stop"]["condition"], r["attempts"]), ("BUDGET_EXHAUSTED", 1))

    def test_every_attempt_writes_p2_checkpoint_and_handoff(self):
        with Dirs() as p:
            go(Fake([failing("METHOD_FAILURE"), passing()]), {"REROUTE_METHOD": lambda ctx: {"method": "m2"}}, persist=p)
            for suffix in ("bundle.json", "handoff.md", "loop.json"):
                self.assertTrue(os.path.exists(os.path.join(p["root"], "state", f"{TID}.{suffix}")), suffix)
            loop = load_loop_state(p["root"], TID)
            self.assertEqual((len(loop["history"]), loop["last_result"]["status"], loop["pending_action"]), (2, "PASS", "CLOSE"))

    def test_resume_continues_from_pending_action(self):
        with Dirs() as p:
            first = go(Fake([failing("METHOD_FAILURE"), passing()]), {}, persist=p)
            self.assertEqual((first["final_status"], first["stop"]["condition"]), ("FAILED", "NO_HANDLER"))
            state = load_loop_state(p["root"], TID)
            self.assertEqual(state["pending_action"], "REROUTE_METHOD")
            fake2 = Fake([passing()])
            r = go(fake2, {"REROUTE_METHOD": lambda ctx: {"method": "m2"}}, persist=p, resume=state)
            self.assertEqual((r["final_status"], r["attempts"], fake2.calls["execute"]), ("PASS", 2, 1))

    def test_checkpoint_write_failure_stops_with_persistence_fault(self):
        with tempfile.NamedTemporaryFile() as bad, tempfile.TemporaryDirectory() as snap:
            fake = Fake([failing("METHOD_FAILURE"), passing()])
            r = go(fake, {"REROUTE_METHOD": lambda ctx: {"method": "m2"}}, persist={"root": bad.name, "snap_dir": snap})
            self.assertEqual((r["final_status"], r["stop"]["condition"], r["stop"]["failure_class"], fake.calls["execute"]),
                             ("BLOCKED", "PERSISTENCE_FAULT", "PERSISTENCE_OR_STATE_ERROR", 1))


class TableTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        with open(os.path.join(os.path.dirname(__file__), "..", "docs", "blueprint.json"), encoding="utf-8") as fh:
            cls.bp = json.load(fh)

    def test_every_emitted_action_has_one_reentry_row(self):
        actions = {a for _s, a, _c in ERROR_EXITS.values()}
        for status in ("PASS", "PARTIAL", "BLOCKED", "NOT_PROVEN"):
            actions.add(slice_mod._feedback(status, "NONE")["action"])
        for branch in FAILURE_BRANCHES:
            actions.add(slice_mod._feedback("FAILED", branch)["action"])
        for status in ("BLOCKED", "NOT_PROVEN", "FAILED", "REJECTED", "CANCELLED", "INCONCLUSIVE", "PARTIAL"):
            actions.add(slice_mod._early(status, "t", [], "r")["feedback"]["action"])
        actions.add("RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE")
        self.assertEqual(sorted(a for a in actions if a not in REENTRY), [])

    def test_reentry_matches_blueprint_map(self):
        node_text = lambda n: n.replace("-", "–").replace(">", "→").replace("|", " 或 ")
        for row in self.bp["architecture"]["closed_loop"]["reentry"]["map"]:
            action = row["action"]
            self.assertIn(action, REENTRY, row)
            mode, node, cls = REENTRY[action]
            if node:
                self.assertIn(node_text(node), row["reenter"], row)
            else:
                self.assertEqual(mode, "STOP", row)
            if cls:
                self.assertIn(cls, row["default_class"], row)

    def test_branch_actions_match_slice(self):
        for branch, action in lc.BRANCH_ACTION.items():
            self.assertEqual(slice_mod._feedback("FAILED", branch)["action"], action)
        self.assertEqual(set(lc.BRANCH_ACTION), FAILURE_BRANCHES - {"NONE"})

    def test_all_ten_failure_classes_have_sources(self):
        self.assertEqual(set(FAILURE_CLASS_SOURCES), set(self.bp["runtime_contract"]["failure_classes"]))
        self.assertEqual(set(FAILURE_CLASS_SOURCES), FAILURE_CLASSES)
        self.assertEqual([c for c, s in FAILURE_CLASS_SOURCES.items() if not s], [])

    def test_all_ten_failure_classes_are_produced_by_real_runs(self):
        seen = set()

        def note(r):
            seen.update(h["failure_class"] for h in r["history"] if h["failure_class"])
            if r["stop"].get("failure_class"):
                seen.add(r["stop"]["failure_class"])
        note(go(Fake(), tsk={**task(LOW), "goal": ""}))                                              # GOAL_OR_SEMANTIC
        note(go(Fake([failing("EVIDENCE_GAP")])))                                                    # SOURCE_OR_EVIDENCE
        note(go(Fake([failing("MODEL_FAILURE")])))                                                   # INFERENCE_OR_MODEL
        note(go(Fake([failing("METHOD_FAILURE")])))                                                  # METHOD_OR_ROUTING
        note(go(Fake(), adapters=Fake().adapters(frame=lambda t: 1 / 0)))                           # TOOL_OR_ADAPTER
        note(go(Fake(), profile=HIGH, adapters=Fake().adapters(authorize=lambda t, r: {"task_id": TID, "status": "DENIED"})))  # AUTHORIZATION
        with tempfile.NamedTemporaryFile() as bad, tempfile.TemporaryDirectory() as snap:           # PERSISTENCE_OR_STATE
            note(go(Fake(), persist={"root": bad.name, "snap_dir": snap}))
        note(go(Fake([failing("LOCAL_FAILURE")]), {"REPAIR_LOCAL_NODE_AND_REGRESS": lambda c: {"correction": correction(), "apply": lambda p: {"actually_changed": ["q"]}}}))  # INTEGRATION
        note(go(Fake([RuntimeError("x")]), budget={"max_attempts": 2}))                              # ACCEPTANCE + COST_OR_STOP
        self.assertEqual(seen & FAILURE_CLASSES, FAILURE_CLASSES, sorted(FAILURE_CLASSES - seen))

    def test_attribute_priority_and_unknown(self):
        self.assertEqual(attribute({"status": "FAILED", "failure_class": "TOOL_OR_ADAPTER_ERROR", "feedback": {"action": "REROUTE_METHOD"}})[0], "TOOL_OR_ADAPTER_ERROR")
        self.assertEqual(attribute({"status": "FAILED", "feedback": {"action": "CLASSIFY_FAILURE_BEFORE_RETRY"}}), ("UNKNOWN", "unattributed"))
        self.assertEqual(attribute({"status": "PASS", "feedback": {"action": "CLOSE"}})[0], "")


if __name__ == "__main__":
    unittest.main()
