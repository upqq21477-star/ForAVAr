"""R4: frame completeness gate (N02 boundary/dependency, N03 competing frames), standalone and through the slice."""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

from foravar_vertical_slice import run_vertical_slice  # noqa: E402
from frame_gate import assess_frame, competing_required, g_level  # noqa: E402
from loop_fixtures import HIGH, LOW, TID, Fake, task  # noqa: E402

SAFE = {**LOW, "frame_gate": True}
DEP = {"id": "D1", "direction": "UPSTREAM", "status": "KNOWN", "impact": "LOW"}


def frame(**kw):
    f = {"task_id": TID, "status": "READY", "frame_id": "F", "problem_statement": "p", "in_scope": ["a"],
         "out_of_scope": [{"item": "b", "reason": "not requested"}], "unknowns": [], "dependencies": [DEP]}
    f.update(kw)
    return f


def rules(profile, f):
    return {v["rule"] for v in assess_frame(profile, f)["violations"]}


def run(profile, f):
    fake = Fake()
    return run_vertical_slice(task(profile), fake.adapters(frame=lambda t: f)), fake


class BoundaryDependencyTests(unittest.TestCase):
    def test_complete_frame_is_ok(self):
        out = assess_frame(SAFE, frame())
        self.assertEqual((out["ok"], out["status"], out["violations"]), (True, "OK", []))

    def test_empty_or_malformed_scope(self):
        self.assertIn("BOUNDARY_IN_SCOPE", rules(SAFE, frame(in_scope=[])))
        self.assertIn("BOUNDARY_IN_SCOPE", rules(SAFE, frame(in_scope=[" "])))

    def test_exclusion_needs_reason(self):
        self.assertIn("EXCLUSION_REASON", rules(SAFE, frame(out_of_scope=["bare string"])))
        self.assertIn("EXCLUSION_REASON", rules(SAFE, frame(out_of_scope=[{"item": "x", "reason": ""}])))

    def test_dependencies_must_be_declared_and_well_formed(self):
        f = frame()
        del f["dependencies"]
        self.assertIn("DEPENDENCIES_UNDECLARED", rules(SAFE, f))
        self.assertIn("DEPENDENCIES_UNDECLARED", rules(SAFE, frame(dependencies=[])))
        self.assertEqual(rules(SAFE, frame(dependencies=[], no_dependencies_basis="standalone script, no callers")), set())
        self.assertIn("DEPENDENCY_MALFORMED", rules(SAFE, frame(dependencies=[{**DEP, "impact": "HUGE"}])))
        self.assertIn("DEPENDENCY_MALFORMED", rules(SAFE, frame(dependencies=[DEP, DEP])))

    def test_high_impact_unknown_dependency_cannot_be_assumed_absent(self):
        dep = {**DEP, "status": "UNKNOWN", "impact": "HIGH"}
        self.assertIn("HIGH_IMPACT_UNKNOWN_DEPENDENCY_NOT_CARRIED", rules(SAFE, frame(dependencies=[dep])))
        for carried in (["D1"], [{"id": "D1"}], [{"dependency_id": "D1"}]):
            self.assertEqual(rules(SAFE, frame(dependencies=[dep], unknowns=carried)), set())

    def test_carried_high_unknown_dependency_blocks_even_low_risk(self):
        dep = {**DEP, "status": "UNKNOWN", "impact": "HIGH"}
        self.assertEqual(assess_frame(SAFE, frame(dependencies=[dep], unknowns=["D1"]))["high_impact_unknown_dependencies"], ["D1"])


class CompetingFrameTests(unittest.TestCase):
    ALT = {"frame_id": "F2", "summary": "other cut", "rejected_reason": "misses upstream"}

    def test_trigger_conditions(self):
        self.assertFalse(competing_required(LOW))
        self.assertTrue(competing_required(HIGH))
        self.assertTrue(competing_required({**LOW, "risk_level": "CRITICAL"}))
        for g, want in (("G0", False), ("G1", False), ("G2", True), ("G3", True), (2, True), (1, False), ("bad", True), (True, True), (9, True)):
            self.assertEqual(competing_required({**LOW, "governance": g}), want, g)
        self.assertEqual(g_level({}), 0)

    def test_required_case_needs_alternative_and_reason(self):
        p = {**SAFE, "governance": "G2"}
        self.assertEqual(rules(p, frame()), {"COMPETING_FRAMES_MISSING", "ADOPTION_REASON_MISSING"})
        self.assertEqual(rules(p, frame(alternatives=[self.ALT])), {"ADOPTION_REASON_MISSING"})
        out = assess_frame(p, frame(alternatives=[self.ALT], adopted_reason="covers upstream"))
        self.assertTrue(out["ok"])
        self.assertEqual(out["frames_counted"], 2)

    def test_alternative_must_be_distinct_and_justified(self):
        p = {**SAFE, "governance": "G3"}
        for bad in ({**self.ALT, "frame_id": "F"}, {**self.ALT, "rejected_reason": ""}, {**self.ALT, "summary": ""}, "text"):
            r = rules(p, frame(alternatives=[bad], adopted_reason="r"))
            self.assertTrue({"ALTERNATIVE_MALFORMED", "COMPETING_FRAMES_MISSING"} <= r, bad)
        dup = rules(p, frame(alternatives=[self.ALT, self.ALT], adopted_reason="r"))
        self.assertEqual(dup, {"ALTERNATIVE_MALFORMED"})

    def test_optional_alternatives_still_validated_when_present(self):
        self.assertIn("ALTERNATIVE_MALFORMED", rules(SAFE, frame(alternatives="x")))
        self.assertIn("ALTERNATIVE_MALFORMED", rules(SAFE, frame(alternatives=[{"frame_id": "F2"}])))


class StatusAndSliceTests(unittest.TestCase):
    def test_low_stakes_incomplete_is_not_proven_high_stakes_blocked(self):
        f = frame(in_scope=[])
        self.assertEqual(assess_frame(SAFE, f)["status"], "NOT_PROVEN")
        self.assertEqual(assess_frame({**SAFE, "side_effects": True}, f)["status"], "BLOCKED")
        undeclared = {k: v for k, v in SAFE.items() if k != "side_effects"}
        self.assertEqual(assess_frame(undeclared, f)["status"], "BLOCKED")
        self.assertEqual(assess_frame({**SAFE, "risk_level": "HIGH"}, f)["status"], "BLOCKED")

    def test_slice_stops_before_evidence_on_incomplete_frame(self):
        r, fake = run(SAFE, frame(in_scope=[]))
        self.assertEqual((r["status"], r["failure_class"]), ("NOT_PROVEN", "GOAL_OR_SEMANTIC_ERROR"))
        self.assertIn("BOUNDARY_IN_SCOPE", r["feedback"]["reason"])
        self.assertEqual(r["feedback"]["action"], "PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE")
        self.assertEqual((fake.calls["evidence"], fake.calls["execute"]), (0, 0))
        self.assertIn("FRAME_GATE", r["trace"])

    def test_slice_blocks_high_risk_without_competing_frames(self):
        r, fake = run({**HIGH, "frame_gate": True}, frame())
        self.assertEqual((r["status"], r["feedback"]["action"]), ("BLOCKED", "STOP_BLOCKED"))
        self.assertIn("COMPETING_FRAMES_MISSING", r["frame_gate"]["violations"][0]["rule"])
        self.assertEqual(fake.calls["execute"], 0)

    def test_slice_proceeds_and_reports_gate_when_complete(self):
        r, fake = run(SAFE, frame())
        self.assertEqual(r["status"], "PASS")
        self.assertTrue(r["frame_gate"]["ok"])
        self.assertEqual(fake.calls["execute"], 1)

    def test_gate_is_opt_in_and_existing_behaviour_unchanged(self):
        r, _ = run(LOW, {k: v for k, v in frame().items() if k != "dependencies"})
        self.assertEqual(r["status"], "PASS")
        self.assertIsNone(r["frame_gate"])

    def test_frame_gate_flag_must_be_boolean(self):
        r, _ = run({**LOW, "frame_gate": "yes"}, frame())
        self.assertEqual(r["status"], "BLOCKED")
        self.assertEqual(r["event"], "TASK_INVALID")

    def test_malformed_input_never_raises(self):
        for f in ({}, {"in_scope": 5, "dependencies": "x", "alternatives": 3, "out_of_scope": 1, "unknowns": 2}):
            assess_frame({**SAFE, "governance": "G3"}, f)


if __name__ == "__main__":
    unittest.main()
