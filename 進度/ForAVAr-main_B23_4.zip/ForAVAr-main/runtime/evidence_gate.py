"""Conflict / stale evidence gate (R8; blueprint closed_loop.error_exits row 9).

Pure assessment, no I/O. Rules:
  1. A conflict is UNRESOLVED unless it carries a resolution citing >=1 OBSERVED evidence id that exists
     and is not one of the conflicting records (claiming "resolved" without evidence does not count).
  2. A task flagged ``has_source_conflict`` or evidence status CONFLICT with no conflict list is an
     unresolved conflict of unknown identity.
  3. An OBSERVED record is STALE if the task pins ``target_revision`` and the record's differs, or its
     ``valid_until`` is past ``now`` / unparseable (fail closed).
The slice uses the result: before execution a high-risk or side-effecting task is BLOCKED; at
acceptance an unresolved conflict or stale cited evidence blocks PASS (-> PARTIAL).
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from datetime import datetime, timezone
from typing import Any

ACTION = "RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE"


def _parse(ts: str) -> datetime | None:
    try:
        dt = datetime.fromisoformat(ts.strip().replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def stale_records(records: Iterable[Mapping[str, Any]], *, target_revision: str | None, now: datetime) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for r in records:
        if r.get("status") != "OBSERVED":
            continue
        eid = str(r.get("evidence_id"))
        if target_revision and r.get("target_revision") != target_revision:
            out.append({"evidence_id": eid, "reason": f"target_revision {r.get('target_revision')!r} != {target_revision!r}"})
            continue
        if "valid_until" in r:
            until = _parse(r["valid_until"]) if isinstance(r["valid_until"], str) else None
            if until is None:
                out.append({"evidence_id": eid, "reason": "valid_until unparseable (fail closed)"})
            elif until < now:
                out.append({"evidence_id": eid, "reason": f"expired at {r['valid_until']}"})
    return out


def unresolved_conflicts(conflicts: Sequence[Mapping[str, Any]], index: Mapping[str, Mapping[str, Any]]) -> list[dict[str, Any]]:
    """Conflicts lacking a resolution that cites existing OBSERVED evidence outside the conflict itself."""
    out: list[dict[str, Any]] = []
    for c in conflicts:
        cid = str(c.get("conflict_id", "UNNAMED"))
        resolution = c.get("resolution")
        cited = list(resolution.get("resolved_by", [])) if isinstance(resolution, Mapping) else []
        sides = set(c.get("evidence_ids", []))
        ok = bool(cited) and all(
            isinstance(i, str) and i not in sides and index.get(i, {}).get("status") == "OBSERVED" for i in cited)
        if ok:
            continue
        reason = "no resolution" if not resolution else "resolution does not cite existing observed evidence outside the conflict"
        out.append({"conflict_id": cid, "reason": reason})
    return out


def assess(*, profile: Mapping[str, Any], evidence: Mapping[str, Any], records: Sequence[Mapping[str, Any]],
           index: Mapping[str, Mapping[str, Any]], target_revision: str | None, now: datetime,
           extra_resolutions: Sequence[Mapping[str, Any]] = ()) -> dict[str, Any]:
    """Return {'conflicts': [...unresolved], 'stale': [...], 'blocks_pass': bool, 'reasons': [...]}.

    extra_resolutions: later claims (e.g. from evaluation) shaped {conflict_id, resolved_by:[ids]}; they obey rule 1.
    """
    declared = [dict(c) for c in evidence.get("conflicts", []) if isinstance(c, Mapping)]
    claims = {str(x.get("conflict_id")): x for x in extra_resolutions if isinstance(x, Mapping)}
    for c in declared:
        claim = claims.get(str(c.get("conflict_id")))
        if claim and not c.get("resolution"):
            c["resolution"] = {"resolved_by": claim.get("resolved_by", [])}
    flagged = evidence.get("status") == "CONFLICT" or profile.get("has_source_conflict") is True
    if flagged and not declared:
        declared = [{"conflict_id": "UNIDENTIFIED", "evidence_ids": [], "resolution": claims.get("UNIDENTIFIED")}]
    conflicts = unresolved_conflicts(declared, index)
    stale = stale_records(records, target_revision=target_revision, now=now)
    reasons = [f"conflict {c['conflict_id']}: {c['reason']}" for c in conflicts] + \
              [f"stale {s['evidence_id']}: {s['reason']}" for s in stale]
    return {"conflicts": conflicts, "stale": stale, "blocks_pass": bool(conflicts or stale), "reasons": reasons}
