"""Minimal forAVAr thinking-loop integration seam.

This module orchestrates caller-supplied cognitive/tool adapters. It does not
implement a language model, permissions engine, task registry, persistence layer,
retry loop, or GitHub operations. An optional cancel_requested adapter can stop a task
before execution (status CANCELLED). It builds an in-memory RunRecord receipt
(run_record.py) but never persists it; retry decisions live in retry_policy.py and
are made by the caller, not by this module. Authorization remains an explicit adapter gate.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from typing import Any

try:
    from .policy_gate import evaluate_authorization
    from .run_record import build_run_record, run_record_required
    from .content_guard import quarantine_if_injected
    from .error_exits import STAGE_EVENT, envelope, error_receipt, evidence_envelope
    from .evidence_gate import ACTION as EVIDENCE_ACTION, assess as assess_evidence
    from .frame_gate import assess_frame
    from .model_gate import assess_model
except ImportError:  # supports direct imports when runtime/ is on sys.path
    from policy_gate import evaluate_authorization
    from run_record import build_run_record, run_record_required
    from content_guard import quarantine_if_injected
    from error_exits import STAGE_EVENT, envelope, error_receipt, evidence_envelope
    from evidence_gate import ACTION as EVIDENCE_ACTION, assess as assess_evidence
    from frame_gate import assess_frame
    from model_gate import assess_model

IMPLEMENTATION_VERSION = "0.8.0"
IMPLEMENTATION_STATUS = "EVIDENCE_GATE_INTEGRATED_RUNTIME_NOT_VALIDATED"

EVIDENCE_KINDS = {
    "SOURCE_OBSERVATION",
    "STATIC_CHECK",
    "RETROSPECTIVE_REPLAY",
    "PROGRAM_TEST",
    "RUNTIME_OBSERVATION",
    "EXECUTION_OBSERVATION",
}
CRITERION_STATES = {"PASS", "FAIL", "UNKNOWN", "NOT_RUN"}
EXECUTION_STATES = {"EXECUTED", "PARTIAL", "BLOCKED", "FAILED", "NOT_RUN", "TIMEOUT_UNKNOWN_SIDE_EFFECT"}
RISK_LEVELS = {"LOW", "MEDIUM", "HIGH", "CRITICAL"}
# F5 repair branches (how far back to go). Orthogonal to FAILURE_CLASSES below.
FAILURE_BRANCHES = {
    "NONE",
    "LOCAL_FAILURE",
    "METHOD_FAILURE",
    "MODEL_FAILURE",
    "FRAME_FAILURE",
    "AUTHORIZATION_FAILURE",
    "EVIDENCE_GAP",
    "NO_FEASIBLE_SOLUTION",
}
# Blueprint runtime_contract.failure_classes: root-cause categories (optional field).
FAILURE_CLASSES = {
    "GOAL_OR_SEMANTIC_ERROR",
    "SOURCE_OR_EVIDENCE_ERROR",
    "INFERENCE_OR_MODEL_ERROR",
    "METHOD_OR_ROUTING_ERROR",
    "TOOL_OR_ADAPTER_ERROR",
    "AUTHORIZATION_OR_POLICY_BLOCK",
    "PERSISTENCE_OR_STATE_ERROR",
    "INTEGRATION_OR_DEPENDENCY_UPDATE_ERROR",
    "ACCEPTANCE_OR_MEASUREMENT_ERROR",
    "COST_OR_STOP_ERROR",
}


class ContractError(ValueError):
    """Raised when an adapter violates the vertical-slice contract."""


def _text(value: Any, field: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ContractError(f"{field} must be a non-empty string")
    return value.strip()


def _record(value: Any, field: str) -> dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ContractError(f"{field} must be an object")
    return dict(value)


def _validate_task(task: Mapping[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    _text(task.get("task_id"), "task.task_id")
    _text(task.get("goal"), "task.goal")
    raw_criteria = task.get("acceptance_criteria")
    if not isinstance(raw_criteria, list) or not raw_criteria:
        raise ContractError("task.acceptance_criteria must be a non-empty list")
    criteria: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_criteria):
        item = _record(raw, f"task.acceptance_criteria[{index}]")
        criterion_id = _text(item.get("id"), f"acceptance_criteria[{index}].id")
        _text(item.get("description"), f"acceptance_criteria[{index}].description")
        if criterion_id in seen:
            raise ContractError(f"duplicate acceptance criterion: {criterion_id}")
        seen.add(criterion_id)
        required_kinds = item.get("required_evidence_kinds", [])
        if not isinstance(required_kinds, list) or any(kind not in EVIDENCE_KINDS for kind in required_kinds):
            raise ContractError(f"invalid evidence kind requirement for {criterion_id}")
        criteria.append({**item, "id": criterion_id, "required_evidence_kinds": required_kinds})

    profile = task.get("profile", {})
    if not isinstance(profile, Mapping):
        raise ContractError("task.profile must be an object")
    profile = dict(profile)
    risk = profile.get("risk_level")
    if risk is not None and risk not in RISK_LEVELS:
        raise ContractError(f"invalid task.profile.risk_level: {risk}")
    for key in ("requires_external_evidence", "requires_diagnostic", "has_source_conflict", "has_critical_unknowns", "side_effects", "frame_gate"):
        if key in profile and not isinstance(profile[key], bool):
            raise ContractError(f"task.profile.{key} must be boolean")
    return criteria, profile


def _simple_fast_path(profile: Mapping[str, Any]) -> bool:
    """Short-circuit only when every condition is explicit and low-risk."""
    return (
        profile.get("risk_level") == "LOW"
        and profile.get("requires_external_evidence") is False
        and profile.get("requires_diagnostic") is False
        and profile.get("has_source_conflict") is False
        and profile.get("has_critical_unknowns") is False
        and profile.get("side_effects") is False
    )


def _call(adapters: Mapping[str, Callable[..., Any]], name: str, *args: Any) -> dict[str, Any]:
    fn = adapters.get(name)
    if not callable(fn):
        raise ContractError(f"missing callable adapter: {name}")
    return _record(fn(*args), f"adapter.{name} result")


def _now(adapters: Mapping[str, Callable[..., Any]]) -> datetime:
    """Optional ``clock`` adapter returns an ISO timestamp (deterministic tests); default is real UTC time."""
    clock = adapters.get("clock")
    if callable(clock):
        dt = datetime.fromisoformat(str(clock()).replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    return datetime.now(timezone.utc)


def _bind_task(value: Mapping[str, Any], task_id: str, field: str) -> None:
    if value.get("task_id") != task_id:
        raise ContractError(f"{field}.task_id does not match the active task")


def _early(status: str, task_id: str, trace: list[str], reason: str, action: str | None = None, **extra: Any) -> dict[str, Any]:
    action = action or {
        "BLOCKED": "STOP_BLOCKED",
        "NOT_PROVEN": "PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE",
        "FAILED": "CLASSIFY_FAILURE_BEFORE_RETRY",
        "REJECTED": "REJECT_WITH_REASON",  # F5: no feasible solution within hard constraints
        "CANCELLED": "STOP_AND_REPORT_STATE_NO_EXECUTION",  # F5: stopped on request before execution
        "INCONCLUSIVE": "INSPECT_ACTUAL_STATE_BEFORE_RETRY",
    }.get(status, "STOP_AND_PRESERVE_STATE")
    return {
        "task_id": task_id,
        "implementation_version": IMPLEMENTATION_VERSION,
        "implementation_status": IMPLEMENTATION_STATUS,
        "status": status,
        "trace": list(trace),
        "feedback": {"action": action, "reason": reason},
        **extra,
    }


def _validate_evidence(records: Any, field: str) -> dict[str, dict[str, Any]]:
    if not isinstance(records, list):
        raise ContractError(f"{field} must be a list")
    index: dict[str, dict[str, Any]] = {}
    for n, raw in enumerate(records):
        record = _record(raw, f"{field}[{n}]")
        evidence_id = _text(record.get("evidence_id"), f"{field}[{n}].evidence_id")
        if evidence_id in index:
            raise ContractError(f"duplicate evidence_id: {evidence_id}")
        kind = record.get("kind")
        if kind not in EVIDENCE_KINDS:
            raise ContractError(f"invalid evidence kind for {evidence_id}: {kind}")
        # Declared or linked material is not evidence unless an observation is recorded.
        required = ("target_revision", "observed_at", "summary")
        if record.get("status") == "OBSERVED" and all(isinstance(record.get(k), str) and record[k].strip() for k in required):
            if kind in {"PROGRAM_TEST", "RUNTIME_OBSERVATION"}:
                if not isinstance(record.get("run_id"), str) or not record["run_id"].strip():
                    raise ContractError(f"{kind} evidence {evidence_id} requires run_id")
                if not isinstance(record.get("command"), str) or not record["command"].strip():
                    raise ContractError(f"{kind} evidence {evidence_id} requires command")
                if not isinstance(record.get("exit_code"), int):
                    raise ContractError(f"{kind} evidence {evidence_id} requires integer exit_code")
            if kind == "RUNTIME_OBSERVATION":
                for key in ("environment", "output_digest"):
                    if not isinstance(record.get(key), str) or not record[key].strip():
                        raise ContractError(f"RUNTIME_OBSERVATION evidence {evidence_id} requires {key}")
        index[evidence_id] = quarantine_if_injected(record)
    return index


def _feedback(status: str, failure_branch: str, reason: str = "") -> dict[str, str]:
    actions = {
        "PASS": "CLOSE",
        "PARTIAL": "PARTIAL_CLOSEOUT_WITH_OPEN_ITEMS",
        "BLOCKED": "STOP_BLOCKED",
        "NOT_PROVEN": "PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE",
        "FAILED": {
            "LOCAL_FAILURE": "REPAIR_LOCAL_NODE_AND_REGRESS",
            "METHOD_FAILURE": "REROUTE_METHOD",
            "MODEL_FAILURE": "REVISE_PROBLEM_MODEL",
            "FRAME_FAILURE": "REFRAME_PROBLEM",
            "AUTHORIZATION_FAILURE": "STOP_AND_REQUEST_AUTHORIZATION",
            "EVIDENCE_GAP": "GATHER_DISCRIMINATING_EVIDENCE",
            "NO_FEASIBLE_SOLUTION": "REJECT_WITH_REASON",
            "NONE": "CLASSIFY_FAILURE_BEFORE_RETRY",
        }[failure_branch],
    }
    action = actions[status]
    return {"action": action, "reason": reason or failure_branch}


def _run_core(task: Mapping[str, Any], adapters: Mapping[str, Callable[..., Any]], ctx: dict[str, Any]) -> dict[str, Any]:
    """Run one conditional thinking loop; return a traceable, non-persistent receipt.

    Required adapters: frame(task), evidence(task, frame), route(task, frame, evidence),
    execute(task, frame, evidence, route), evaluate(task, execution, evidence).
    A low-risk direct task may bypass evidence gathering only when all short-circuit
    profile fields are explicitly false/LOW. A selected route never grants permission.
    """
    ctx["stage"] = "task"
    task_obj = _record(task, "task")
    criteria, profile = _validate_task(task_obj)
    task_id = task_obj["task_id"]
    ctx.update(task_id=task_id, profile=profile)
    trace: list[str] = ctx["trace"]

    ctx["stage"] = "frame"
    frame = _call(adapters, "frame", task_obj)
    trace.append("FRAME")
    ctx["frame"] = frame
    _bind_task(frame, task_id, "frame")
    frame_status = frame.get("status")
    if frame_status != "READY":
        status = "BLOCKED" if frame_status == "BLOCKED" else "NOT_PROVEN"
        return _early(status, task_id, trace, str(frame.get("reason", "problem framing is incomplete")), frame=frame)
    _text(frame.get("frame_id"), "frame.frame_id")
    _text(frame.get("problem_statement"), "frame.problem_statement")
    for key in ("in_scope", "out_of_scope", "unknowns"):
        if not isinstance(frame.get(key), list):
            raise ContractError(f"frame.{key} must be a list")
    frame_gate: dict[str, Any] | None = None
    if profile.get("frame_gate") is True:  # R4 (opt-in): boundary/dependency/competing-frame completeness
        frame_gate = assess_frame(profile, frame)
        ctx["frame_gate"] = frame_gate
        trace.append("FRAME_GATE")
        if not frame_gate["ok"]:
            reason = "frame incomplete: " + "; ".join(x["rule"] for x in frame_gate["violations"])
            return _early(frame_gate["status"], task_id, trace, reason, frame=frame, frame_gate=frame_gate,
                          failure_class="GOAL_OR_SEMANTIC_ERROR")

    pre_gate: dict[str, Any] = {"conflicts": [], "stale": [], "blocks_pass": False, "reasons": []}
    if _simple_fast_path(profile):
        evidence = {"task_id": task_id, "status": "NOT_REQUIRED", "records": [], "critical_unknowns": [], "reason": "explicit low-risk short path"}
        trace.append("EVIDENCE_SHORT_CIRCUIT")
    else:
        ctx["stage"] = "evidence"
        evidence = _call(adapters, "evidence", task_obj, frame)
        trace.append("EVIDENCE")
        ctx["evidence"] = evidence
        _bind_task(evidence, task_id, "evidence")
        if evidence.get("status") not in {"READY", "PARTIAL", "CONFLICT", "BLOCKED"}:
            raise ContractError("adapter.evidence status must be READY, PARTIAL, CONFLICT, or BLOCKED")
        evidence_index_pre = _validate_evidence(evidence.get("records", []), "evidence.records")
        if evidence.get("status") == "BLOCKED":
            return _early("BLOCKED", task_id, trace, str(evidence.get("reason", "evidence collection is blocked")), frame=frame, evidence=evidence)
        critical_unknowns = evidence.get("critical_unknowns", [])
        if not isinstance(critical_unknowns, list):
            raise ContractError("evidence.critical_unknowns must be a list")
        if critical_unknowns and (profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is True):
            return _early("BLOCKED", task_id, trace, "critical unknown affects a high-risk or side-effecting task", frame=frame, evidence=evidence)
        # R8: conflict / stale gate before execution. High-risk or side-effecting work is BLOCKED here;
        # lower-risk work proceeds but cannot PASS (checked again at acceptance).
        hard = profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is not False
        pre_gate = assess_evidence(profile=profile, evidence=evidence, records=evidence.get("records", []),
                                   index=evidence_index_pre, target_revision=task_obj.get("target_revision"), now=_now(adapters))
        ctx["evidence_gate"] = pre_gate
        trace.append("EVIDENCE_GATE")
        if pre_gate["blocks_pass"] and hard:
            out = evidence_envelope(task_id, "; ".join(pre_gate["reasons"]), hard_block=True)
            return _early("BLOCKED", task_id, trace, out["feedback"]["reason"], EVIDENCE_ACTION, frame=frame, evidence=evidence,
                          failure_class="SOURCE_OR_EVIDENCE_ERROR", evidence_gate=pre_gate, event="EVIDENCE_CONFLICT_OR_STALE")

    model: dict[str, Any] | None = None
    model_gate: dict[str, Any] | None = None
    if "model" in adapters:  # R3-model (optional stage, N07-N09): validated before routing
        ctx["stage"] = "model"
        model = _call(adapters, "model", task_obj, frame, evidence)
        trace.append("MODEL")
        ctx["model"] = model
        _bind_task(model, task_id, "model")
        if model.get("status") != "READY":
            status = "BLOCKED" if model.get("status") == "BLOCKED" else "NOT_PROVEN"
            return _early(status, task_id, trace, str(model.get("reason", "problem model is incomplete")), frame=frame, evidence=evidence, model=model)
        observed = {r["evidence_id"] for r in evidence.get("records", []) if isinstance(r, Mapping) and r.get("status") == "OBSERVED"
                    and isinstance(r.get("evidence_id"), str)}
        model_gate = assess_model(profile, model, observed)
        ctx["model_gate"] = model_gate
        trace.append("MODEL_GATE")
        if not model_gate["ok"]:
            reason = "model incomplete: " + "; ".join(x["rule"] for x in model_gate["violations"])
            return _early(model_gate["status"], task_id, trace, reason, frame=frame, evidence=evidence, model=model,
                          model_gate=model_gate, failure_class="INFERENCE_OR_MODEL_ERROR")

    ctx["stage"] = "route"
    route = _call(adapters, "route", task_obj, frame, evidence)
    trace.append("ROUTE")
    ctx["route"] = route
    _bind_task(route, task_id, "route")
    if route.get("status") in {"BLOCKED", "NOT_PROVEN", "REJECTED", "CANCELLED"}:
        return _early(route["status"], task_id, trace, str(route.get("reason", "route did not authorize execution")), frame=frame, evidence=evidence, route=route)
    if route.get("status") != "ROUTED":
        raise ContractError("adapter.route status must be ROUTED or a supported terminal status")
    candidates = route.get("candidate_methods")
    if not isinstance(candidates, list) or not candidates or any(not isinstance(x, str) or not x.strip() for x in candidates):
        raise ContractError("route.candidate_methods must be a non-empty list of method IDs")
    if len(set(candidates)) != len(candidates):
        raise ContractError("route.candidate_methods must not contain duplicates")
    selected = _text(route.get("selected_method"), "route.selected_method")
    if selected not in candidates:
        raise ContractError("route.selected_method must be one of candidate_methods")
    _text(route.get("reason"), "route.reason")
    _text(route.get("stop_rule"), "route.stop_rule")
    if not isinstance(route.get("requires_authorization"), bool):
        raise ContractError("route.requires_authorization must be boolean")
    required_scope = route.get("required_scope", [])
    if not isinstance(required_scope, list) or any(
        not isinstance(scope, str) or not scope.strip() for scope in required_scope
    ):
        raise ContractError("route.required_scope must be a list of non-empty scope strings")
    route["required_scope"] = required_scope

    authorization = evaluate_authorization(task_obj, profile, route, adapters)
    trace.append("POLICY_GATE")
    if authorization.get("required"):
        trace.append("AUTHORIZATION")
        if authorization.get("status") != "AUTHORIZED":
            return _early(
                "BLOCKED",
                task_id,
                trace,
                str(authorization.get("reason", "authorization was not granted")),
                frame=frame,
                evidence=evidence,
                route=route,
                authorization=authorization,
                failure_class="AUTHORIZATION_OR_POLICY_BLOCK",
            )
    else:
        trace.append("AUTHORIZATION_NOT_REQUIRED")

    # Optional cancel hook (F5 CANCELLED): checked once, after the policy gate and before execution.
    # Nothing has executed yet, so no receipt exists. Cancelling mid-execution is out of scope.
    cancel_check = adapters.get("cancel_requested")
    if callable(cancel_check):
        trace.append("CANCEL_CHECK")
        try:
            cancelled = cancel_check(task_obj)
        except Exception as exc:  # fail closed: do not execute if cancellation state is unknown
            return _early("BLOCKED", task_id, trace, f"cancel check failed ({type(exc).__name__}); execution not started", frame=frame, evidence=evidence, route=route, authorization=authorization)
        if cancelled is True:
            return _early("CANCELLED", task_id, trace, "cancellation requested before execution", frame=frame, evidence=evidence, route=route, authorization=authorization)

    rr_required = run_record_required(profile, criteria)
    ctx["stage"] = "execute"
    try:
        execution = _call(adapters, "execute", task_obj, frame, evidence, route)
    except TimeoutError as exc:
        trace.append("EXECUTION")
        receipt = build_run_record(task_id, None, result_status="TIMEOUT_UNKNOWN_SIDE_EFFECT", required=rr_required)
        if profile.get("side_effects") is False:
            return _early("FAILED", task_id, trace, f"execution timed out ({exc}); no side effects declared", frame=frame, evidence=evidence, route=route, failure_class="TOOL_OR_ADAPTER_ERROR", run_record=receipt)
        return _early("INCONCLUSIVE", task_id, trace, f"execution timed out ({exc}); external side effects unknown", frame=frame, evidence=evidence, route=route, failure_class="TOOL_OR_ADAPTER_ERROR", unknown_side_effect=True, run_record=receipt)
    trace.append("EXECUTION")
    ctx["execution"] = execution
    _bind_task(execution, task_id, "execution")
    execution_status = execution.get("status")
    if execution_status not in EXECUTION_STATES:
        raise ContractError(f"invalid execution.status: {execution_status}")
    if execution_status == "TIMEOUT_UNKNOWN_SIDE_EFFECT":
        receipt = build_run_record(task_id, execution, result_status=execution_status, required=rr_required)
        return _early("INCONCLUSIVE", task_id, trace, str(execution.get("reason", "execution timed out; external side effects unknown")), frame=frame, evidence=evidence, route=route, execution=execution, failure_class="TOOL_OR_ADAPTER_ERROR", unknown_side_effect=True, run_record=receipt)
    if execution_status in {"BLOCKED", "FAILED", "NOT_RUN"}:
        status = "BLOCKED" if execution_status == "BLOCKED" else ("FAILED" if execution_status == "FAILED" else "NOT_EXECUTED")
        extra = {}
        if execution_status == "FAILED":  # something actually ran: keep its receipt
            extra["run_record"] = build_run_record(task_id, execution, result_status=execution_status, required=rr_required)
        return _early(status, task_id, trace, str(execution.get("reason", f"execution status: {execution_status}")), frame=frame, evidence=evidence, route=route, execution=execution, **extra)
    _text(execution.get("execution_id"), "execution.execution_id")
    _text(execution.get("result_summary"), "execution.result_summary")
    run_record = build_run_record(task_id, execution, result_status=execution_status, required=rr_required)
    ctx["run_record"] = run_record
    ctx["stage"] = "evaluate"

    evaluation = _call(adapters, "evaluate", task_obj, execution, evidence)
    trace.append("EVALUATION")
    _bind_task(evaluation, task_id, "evaluation")
    raw_results = evaluation.get("criteria_results")
    if not isinstance(raw_results, list):
        raise ContractError("evaluation.criteria_results must be a list")
    results: dict[str, dict[str, Any]] = {}
    required_ids = {c["id"] for c in criteria}
    for i, raw in enumerate(raw_results):
        result = _record(raw, f"evaluation.criteria_results[{i}]")
        criterion_id = _text(result.get("criterion_id"), f"criteria_results[{i}].criterion_id")
        if criterion_id not in required_ids:
            raise ContractError(f"evaluation returned unknown criterion: {criterion_id}")
        if criterion_id in results:
            raise ContractError(f"duplicate evaluation result for criterion: {criterion_id}")
        if result.get("status") not in CRITERION_STATES:
            raise ContractError(f"invalid status for criterion {criterion_id}")
        results[criterion_id] = result

    all_records = list(evidence.get("records", [])) + list(execution.get("evidence_records", []))
    evidence_index = _validate_evidence(all_records, "evidence_records")
    normalized: list[dict[str, Any]] = []
    for criterion in criteria:
        criterion_id = criterion["id"]
        result = dict(results.get(criterion_id, {"criterion_id": criterion_id, "status": "NOT_RUN", "evidence_ids": []}))
        evidence_ids = result.get("evidence_ids", [])
        if not isinstance(evidence_ids, list) or any(not isinstance(x, str) for x in evidence_ids):
            raise ContractError(f"evidence_ids must be a list of strings for {criterion_id}")
        cited = [evidence_index.get(x) for x in evidence_ids]
        traceable = bool(cited) and all(item is not None and item.get("status") == "OBSERVED" for item in cited)
        required_kinds = set(criterion["required_evidence_kinds"])
        available_kinds = {item.get("kind") for item in cited if item is not None and item.get("status") == "OBSERVED"}
        if result["status"] in {"PASS", "FAIL"} and (not traceable or not required_kinds.issubset(available_kinds)):
            result["status"] = "UNKNOWN"
            result["reason"] = "evaluation claim lacks linked observed evidence of the required kind"
        result["evidence_ids"] = evidence_ids
        normalized.append(result)

    if any(r["status"] == "FAIL" for r in normalized):
        status = "FAILED"
    elif any(r["status"] in {"UNKNOWN", "NOT_RUN"} for r in normalized):
        status = "NOT_PROVEN"
    elif execution_status == "PARTIAL":
        status = "PARTIAL"
    else:
        status = "PASS"
    rr_note = ""
    if status == "PASS" and run_record["required"] and not run_record["complete"]:
        # A receipt is not acceptance, but a required receipt must not be silently missing.
        status = "PARTIAL"
        rr_note = "required run_record incomplete: " + ", ".join(run_record["missing"])
    claims = evaluation.get("conflict_resolutions", [])
    if not isinstance(claims, list):
        raise ContractError("evaluation.conflict_resolutions must be a list")
    gate = assess_evidence(profile=profile, evidence=evidence, records=all_records, index=evidence_index,
                           target_revision=task_obj.get("target_revision"), now=_now(adapters), extra_resolutions=claims)
    if "EVIDENCE_GATE" not in trace:
        trace.append("EVIDENCE_GATE")
    gate_note = ""
    if status == "PASS" and gate["blocks_pass"]:
        status = "PARTIAL"
        gate_note = "evidence gate: " + "; ".join(gate["reasons"])
    failure_branch = evaluation.get("failure_branch")
    failure_class = evaluation.get("failure_class")
    if failure_branch is None and failure_class in FAILURE_BRANCHES:  # legacy key: failure_class held the repair branch
        failure_branch, failure_class = failure_class, None
    failure_branch = "NONE" if failure_branch is None else failure_branch
    if failure_branch not in FAILURE_BRANCHES:
        raise ContractError(f"invalid evaluation.failure_branch: {failure_branch}")
    if failure_class is not None and failure_class not in FAILURE_CLASSES:
        raise ContractError(f"invalid evaluation.failure_class: {failure_class}")
    reason = str(evaluation.get("reason", ""))
    for note in (rr_note, gate_note):
        if note:
            reason = f"{reason}; {note}" if reason else note
    feedback = _feedback(status, failure_branch, reason)
    if gate_note:  # R8: the gate, not the receipt, is why this PASS was withheld -> refresh/resolve, not generic closeout
        feedback = {"action": EVIDENCE_ACTION, "reason": reason}
        failure_class = failure_class or "SOURCE_OR_EVIDENCE_ERROR"
    trace.append("FEEDBACK")
    return {
        "task_id": task_id,
        "implementation_version": IMPLEMENTATION_VERSION,
        "implementation_status": IMPLEMENTATION_STATUS,
        "status": status,
        "trace": trace,
        "frame": frame,
        "evidence": evidence,
        "route": route,
        "authorization": authorization,
        "execution": execution,
        "run_record": run_record,
        "acceptance": {"criteria_results": normalized, "failure_branch": failure_branch, "failure_class": failure_class, "reason": reason},
        "feedback": feedback,
        "evidence_gate": gate,
        "frame_gate": frame_gate,
        "model": model,
        "model_gate": model_gate,
        "runtime_observation_present": any(
            item.get("kind") == "RUNTIME_OBSERVATION" and item.get("status") == "OBSERVED"
            and all(isinstance(item.get(k), str) and item[k].strip() for k in ("run_id", "command", "target_revision", "observed_at", "environment", "output_digest"))
            and isinstance(item.get("exit_code"), int)
            for item in evidence_index.values()
        ),
    }


def run_vertical_slice(task: Mapping[str, Any], adapters: Mapping[str, Callable[..., Any]]) -> dict[str, Any]:
    """Public entry (R6): never lets an adapter exception or ContractError escape.

    Faults map to blueprint closed_loop.error_exits via ``error_exits.envelope``: a named terminal status,
    feedback action, failure_class and an ``error`` receipt. Execute-stage faults are treated as
    possible side effects (INCONCLUSIVE) unless the profile explicitly declares side_effects=False.
    """
    ctx: dict[str, Any] = {"trace": [], "stage": "task"}
    try:
        return _run_core(task, adapters, ctx)
    except Exception as exc:  # noqa: BLE001 - R6: every fault must surface as a named exit
        return _fault_exit(task, ctx, exc)


def _fault_exit(task: Any, ctx: dict[str, Any], exc: Exception) -> dict[str, Any]:
    stage = ctx.get("stage", "task")
    raw_id = task.get("task_id") if isinstance(task, Mapping) else None
    task_id = ctx.get("task_id") or (raw_id if isinstance(raw_id, str) and raw_id.strip() else "UNKNOWN")
    trace = list(ctx["trace"])
    parts = {k: ctx[k] for k in ("frame", "evidence", "model", "route", "execution", "run_record") if k in ctx}
    receipt = error_receipt(stage, exc)
    if stage == "execute":
        profile = ctx.get("profile", {})
        no_effect = profile.get("side_effects") is False
        event = "EXECUTE_FAULT_NO_EFFECT" if no_effect else "EXECUTE_FAULT_UNKNOWN_EFFECT"
        trace.append("EXECUTION")
        parts["run_record"] = build_run_record(
            task_id, None, result_status="TIMEOUT_UNKNOWN_SIDE_EFFECT" if not no_effect else "FAILED", required=True)
        out = envelope(task_id, event, f"execute stage fault ({type(exc).__name__}): {receipt['message']}", stage=stage, receipt=receipt)
        if not no_effect:
            out["unknown_side_effect"] = True
    else:
        event = STAGE_EVENT[stage]
        out = envelope(task_id, event, f"{stage} stage fault ({type(exc).__name__}): {receipt['message']}", stage=stage, receipt=receipt)
    out.update(implementation_version=IMPLEMENTATION_VERSION, implementation_status=IMPLEMENTATION_STATUS, trace=trace, **parts)
    return out
