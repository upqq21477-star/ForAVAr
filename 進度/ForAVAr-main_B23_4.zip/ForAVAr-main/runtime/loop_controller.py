"""Closed-loop controller (R7; blueprint architecture.closed_loop.reentry).

Consumes ``feedback.action`` from ``run_vertical_slice`` and re-enters upstream per the reentry table.
Rules enforced here:
  * every re-entry passes ``decide_retry`` first (no new information / budget exhausted -> STOP, state saved);
  * FAILED without attribution is classified first (classify handler + ``plan_correction``); an unsupported
    root cause is recorded as UNKNOWN, never invented;
  * INCONCLUSIVE: inspect the actual state first; execute is never re-run blindly. If the inspection shows the
    effect was applied/partial, only evaluation re-runs (cached execution, execute adapter not called);
  * RERUN_EVALUATION_ONLY replays cached frame/evidence/route/execution and calls only ``evaluate``;
  * LOCAL repair: plan_correction before mutation, ``change_set_guard`` after, regression checks tracked and
    a later PASS is withheld (PARTIAL) while required regressions are not reported run;
  * with ``persist`` set, a P2 checkpoint (bundle + handoff + loop state) is written after every attempt and
    ``resume`` continues from it; a write failure stops the loop with PERSISTENCE_FAULT.
Handlers are caller-supplied: ``handlers[action](ctx) -> dict`` with optional keys ``task``, ``adapters``,
``method``, ``target``, ``new_evidence_ids``, ``discriminating_change``, ``actual_state_read``, ``cost`` (see
HANDLER_RESULT_KEYS). Returning a replacement task/adapters counts as a discriminating change; returning
nothing new makes decide_retry STOP. Stdlib only; never raises from the public entry.
"""
from __future__ import annotations

import json
import os
from collections.abc import Callable, Mapping
from typing import Any

try:
    from .foravar_vertical_slice import FAILURE_CLASSES, FAILURE_BRANCHES, run_vertical_slice
    from .retry_policy import RetryPolicyError, decide_retry
    from .correction_propagation import PropagationError, plan_correction
    from .error_exits import ERROR_EXITS, change_set_guard, envelope, error_receipt, persistence_guard
    from .state_bundle import build_bundle, export_handoff, persist_checkpoint
except ImportError:  # direct imports with runtime/ on sys.path
    from foravar_vertical_slice import FAILURE_CLASSES, FAILURE_BRANCHES, run_vertical_slice
    from retry_policy import RetryPolicyError, decide_retry
    from correction_propagation import PropagationError, plan_correction
    from error_exits import ERROR_EXITS, change_set_guard, envelope, error_receipt, persistence_guard
    from state_bundle import build_bundle, export_handoff, persist_checkpoint

CONTROLLER_VERSION = "0.1.0"
HANDLER_RESULT_KEYS = {"task", "adapters", "method", "target", "new_evidence_ids", "discriminating_change",
                       "actual_state_read", "cost", "execution", "outcome", "correction", "apply", "branch",
                       "state_report", "regression_run"}

CLOSE, STOP, REENTER = "CLOSE", "STOP", "REENTER"
# action -> (mode, re-entry node, default failure_class). One row, one return point per action (blueprint reentry map
# plus the error-exit and closeout actions the slice can emit).
REENTRY: dict[str, tuple[str, str | None, str | None]] = {
    "CLOSE": (CLOSE, None, None),
    "PARTIAL_CLOSEOUT_WITH_OPEN_ITEMS": (STOP, None, None),
    "STOP_BLOCKED": (STOP, None, None),
    "STOP_AND_PRESERVE_STATE": (STOP, None, None),
    "STOP_AND_REPORT_STATE_NO_EXECUTION": (STOP, None, None),
    "STOP_AND_REQUEST_AUTHORIZATION": (STOP, None, "AUTHORIZATION_OR_POLICY_BLOCK"),
    "REJECT_WITH_REASON": (STOP, "F7", "GOAL_OR_SEMANTIC_ERROR"),
    "ROLLBACK_AND_REPORT": (STOP, None, "PERSISTENCE_OR_STATE_ERROR"),
    "REPAIR_LOCAL_NODE_AND_REGRESS": (REENTER, "N13", None),
    "REROUTE_METHOD": (REENTER, "N11", "METHOD_OR_ROUTING_ERROR"),
    "REVISE_PROBLEM_MODEL": (REENTER, "N07-N09", "INFERENCE_OR_MODEL_ERROR"),
    "REFRAME_PROBLEM": (REENTER, "N17>N01-N03", "GOAL_OR_SEMANTIC_ERROR"),
    "GATHER_DISCRIMINATING_EVIDENCE": (REENTER, "N04-N06", "SOURCE_OR_EVIDENCE_ERROR"),
    "RESOLVE_CONFLICT_OR_REFRESH_EVIDENCE": (REENTER, "N04-N06", "SOURCE_OR_EVIDENCE_ERROR"),
    "CLASSIFY_FAILURE_BEFORE_RETRY": (REENTER, "N17", None),
    "INSPECT_ACTUAL_STATE_BEFORE_RETRY": (REENTER, "N12", "TOOL_OR_ADAPTER_ERROR"),
    "RERUN_EVALUATION_ONLY": (REENTER, "N10", "ACCEPTANCE_OR_MEASUREMENT_ERROR"),
    "PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE": (REENTER, "N04-N06|F7", "ACCEPTANCE_OR_MEASUREMENT_ERROR"),
    "FIX_TASK_INPUT": (REENTER, "N01", "GOAL_OR_SEMANTIC_ERROR"),
    "FIX_OR_REPLACE_ADAPTER": (REENTER, "N12", "TOOL_OR_ADAPTER_ERROR"),
    "RESTORE_AND_REPLAN": (REENTER, "N13", "INTEGRATION_OR_DEPENDENCY_UPDATE_ERROR"),
}
OPTIONAL_HANDLER = {"PRESERVE_UNKNOWN_AND_IDENTIFY_MISSING_EVIDENCE"}  # no handler = F7: keep the unknown, stop
DEFAULT_NOOP = {"RERUN_EVALUATION_ONLY"}  # no handler needed: only the evaluator reruns (execute is never touched)
# F5 failure_branch -> action (mirror of the slice's FAILED table); used after classification.
BRANCH_ACTION = {
    "LOCAL_FAILURE": "REPAIR_LOCAL_NODE_AND_REGRESS", "METHOD_FAILURE": "REROUTE_METHOD",
    "MODEL_FAILURE": "REVISE_PROBLEM_MODEL", "FRAME_FAILURE": "REFRAME_PROBLEM",
    "AUTHORIZATION_FAILURE": "STOP_AND_REQUEST_AUTHORIZATION", "EVIDENCE_GAP": "GATHER_DISCRIMINATING_EVIDENCE",
    "NO_FEASIBLE_SOLUTION": "REJECT_WITH_REASON",
}
BRANCH_CLASS = {"LOCAL_FAILURE": None, "METHOD_FAILURE": "METHOD_OR_ROUTING_ERROR", "MODEL_FAILURE": "INFERENCE_OR_MODEL_ERROR",
                "FRAME_FAILURE": "GOAL_OR_SEMANTIC_ERROR", "AUTHORIZATION_FAILURE": "AUTHORIZATION_OR_POLICY_BLOCK",
                "EVIDENCE_GAP": "SOURCE_OR_EVIDENCE_ERROR", "NO_FEASIBLE_SOLUTION": "GOAL_OR_SEMANTIC_ERROR"}
STOP_STATUS = {"REJECT_WITH_REASON": "REJECTED", "STOP_AND_REQUEST_AUTHORIZATION": "BLOCKED"}  # waiting on authority = BLOCKED
BUDGET_STOP_CLASS = "COST_OR_STOP_ERROR"
UNKNOWN_CLASS = "UNKNOWN"
# Where each of the 10 failure classes can come from (tested against the blueprint list and by real runs).
FAILURE_CLASS_SOURCES: dict[str, list[str]] = {c: [] for c in sorted(FAILURE_CLASSES)}
for _ev, (_s, _a, _c) in ERROR_EXITS.items():
    FAILURE_CLASS_SOURCES[_c].append(f"error_exit:{_ev}")
for _b, _c in BRANCH_CLASS.items():
    if _c:
        FAILURE_CLASS_SOURCES[_c].append(f"branch:{_b}")
FAILURE_CLASS_SOURCES[BUDGET_STOP_CLASS].append("retry_policy:budget_stop")


def attribute(result: Mapping[str, Any]) -> tuple[str, str]:
    """(failure_class or UNKNOWN, source). Explicit class from the slice/adapter wins; then branch; then action default."""
    if result.get("status") == "PASS":
        return "", "none"
    explicit = result.get("failure_class") or (result.get("acceptance") or {}).get("failure_class")
    if explicit in FAILURE_CLASSES:
        return explicit, "explicit"
    branch = (result.get("acceptance") or {}).get("failure_branch")
    if BRANCH_CLASS.get(branch):
        return BRANCH_CLASS[branch], f"branch:{branch}"
    default = REENTRY.get(result.get("feedback", {}).get("action", ""), (None, None, None))[2]
    return (default, "action_default") if default else (UNKNOWN_CLASS, "unattributed")


def _blocked_or_partial(last: Mapping[str, Any], profile: Mapping[str, Any]) -> str:
    """Budget stop closes as BLOCKED when state may be unsafe/unknown or the task is high-risk, else PARTIAL."""
    risky = profile.get("risk_level") in {"HIGH", "CRITICAL"} or profile.get("side_effects") is not False
    return "BLOCKED" if (last.get("status") in {"INCONCLUSIVE", "BLOCKED"} or last.get("unknown_side_effect") or risky) else "PARTIAL"


def _method(result: Mapping[str, Any]) -> Any:
    return (result.get("route") or {}).get("selected_method")


def _target(task: Mapping[str, Any], result: Mapping[str, Any]) -> Any:
    return task.get("target_revision") or (result.get("execution") or {}).get("target_version")


def _jsonable(value: Any) -> Any:
    return json.loads(json.dumps(value, default=str, ensure_ascii=False))


def _replay_adapters(prev: Mapping[str, Any], current: Mapping[str, Callable[..., Any]],
                     execution: Mapping[str, Any] | None) -> dict[str, Callable[..., Any]] | None:
    """Adapters for an evaluation-only pass: cached upstream results, no real execute, no cancel hook."""
    execution = execution or prev.get("execution")
    if not (prev.get("frame") and prev.get("route") and execution):
        return None
    ad = {k: v for k, v in current.items() if k != "cancel_requested"}
    frame, route, evidence = prev["frame"], prev["route"], prev.get("evidence")
    ad["frame"] = lambda t: dict(frame)
    ad["route"] = lambda t, f, e: dict(route)
    ad["execute"] = lambda t, f, e, r: dict(execution)
    if evidence is not None:
        ad["evidence"] = lambda t, f: dict(evidence)
    return ad


def _checkpoint(persist: Mapping[str, Any] | None, task_id: str, task: Mapping[str, Any], state: dict[str, Any],
                result: Mapping[str, Any], next_action: str, decisions: list[str]) -> dict[str, Any] | None:
    """P2 checkpoint after an attempt. Returns None on success/no-persist, or a PERSISTENCE_FAULT envelope."""
    if not persist:
        return None
    receipts = [h["run_record"] for h in state["history"] if h.get("run_record")][-5:]
    bundle = build_bundle(task_id, "P2", task_state={
        "status": result.get("status"), "key_decisions": decisions[-10:], "blockers": [result.get("feedback", {}).get("reason", "")]
        if result.get("status") not in {"PASS"} else [], "run_records": receipts, "next_action": next_action,
        "recovery": "resume_closed_loop(root, task_id, ...) re-enters at the pending feedback action"},
        evidence_state={"verified_results": [f"attempt {len(state['history'])}: {result.get('status')}"]})
    handoff = export_handoff({"task_id": task_id, "goal": task.get("goal", "NOT_PROVIDED"), "current_status": result.get("status"),
                              "next_action": next_action, "key decisions": decisions[-10:]})
    loop = {"schema": "foravar.loop_state/1", "task": _jsonable(task), "history": _jsonable(state["history"]),
            "spent_cost": state["spent_cost"], "regression_required": sorted(state["regression_required"]),
            "regression_done": sorted(state["regression_done"]), "decisions": decisions[-50:],
            "last_result": _jsonable(result), "pending_action": next_action}
    tid = "".join(c if c.isalnum() or c in "-_" else "_" for c in task_id)
    rel = persist.get("rel_dir", "state")
    n = 1  # release_txn needs a fresh snapshot dir per transaction: one subdir per checkpoint, never reused (also across resumes)
    while os.path.exists(os.path.join(persist["snap_dir"], f"ckpt-{n:04d}")):
        n += 1
    snap = os.path.join(persist["snap_dir"], f"ckpt-{n:04d}")
    out = persistence_guard(task_id, persist_checkpoint, persist["root"], snap, bundle, handoff, rel_dir=rel,
                            extra_files={f"{rel}/{tid}.loop.json": json.dumps(loop, ensure_ascii=False, sort_keys=True, indent=1)})
    return out if out.get("status") != "PERSISTED" else None


def _final(task_id: str, status: str, stop: dict[str, Any], state: dict[str, Any], result: Mapping[str, Any] | None, **extra: Any) -> dict[str, Any]:
    return {"task_id": task_id, "controller_version": CONTROLLER_VERSION, "final_status": status, "stop": stop,
            "attempts": len(state["history"]), "history": [{k: v for k, v in h.items() if k != "run_record"} for h in state["history"]],
            "result": result, "regression": {"required": sorted(state["regression_required"]), "done": sorted(state["regression_done"])},
            **extra}


def run_closed_loop(task: Mapping[str, Any], adapters: Mapping[str, Callable[..., Any]], *, budget: Mapping[str, Any],
                    handlers: Mapping[str, Callable[[dict[str, Any]], Mapping[str, Any] | None]] | None = None,
                    persist: Mapping[str, Any] | None = None, resume: Mapping[str, Any] | None = None,
                    runner: Callable[..., dict[str, Any]] | None = None) -> dict[str, Any]:
    """Drive the slice until PASS or a justified stop. Never raises.

    budget  : decide_retry budget (max_attempts required); ``spent_cost`` is accumulated from handler ``cost``.
    persist : {'root','snap_dir','rel_dir'?}; omitted = P0 (no checkpoint).
    resume  : loop state dict from ``load_loop_state`` to continue a stopped run (re-supply adapters/handlers).
    """
    task_id = task.get("task_id") if isinstance(task, Mapping) and isinstance(task.get("task_id"), str) and task["task_id"].strip() else "UNKNOWN"
    state: dict[str, Any] = {"history": [], "spent_cost": 0, "regression_required": set(), "regression_done": set()}
    try:
        return _loop(task, adapters, budget, handlers or {}, persist, resume, runner or run_vertical_slice, state)
    except Exception as exc:  # noqa: BLE001 - controller faults must be named exits too
        out = envelope(task_id, "ADAPTER_FAULT", f"controller fault ({type(exc).__name__}): {str(exc)[:200]}", stage="controller",
                       receipt=error_receipt("controller", exc))
        return _final(task_id, out["status"], {"condition": "CONTROLLER_FAULT", "reason": out["feedback"]["reason"],
                                               "failure_class": out["failure_class"]}, state, None, error=out["error"])


def _loop(task, adapters, budget, handlers, persist, resume, runner, state) -> dict[str, Any]:
    task_id = task.get("task_id", "UNKNOWN") if isinstance(task, Mapping) else "UNKNOWN"
    cur_task, cur_ad = dict(task), dict(adapters)
    decisions: list[str] = []
    result: dict[str, Any] | None = None
    mode_next = "FULL"                    # FULL | EVAL_ONLY
    exec_override: Mapping[str, Any] | None = None
    proposed: dict[str, Any] = {"method": None, "target": cur_task.get("target_revision")}
    step = "RUN"
    if resume:
        state["history"] = list(resume.get("history", []))
        state["spent_cost"] = resume.get("spent_cost", 0)
        state["regression_required"] = set(resume.get("regression_required", []))
        state["regression_done"] = set(resume.get("regression_done", []))
        decisions = list(resume.get("decisions", []))
        result = dict(resume["last_result"])
        cur_task = dict(resume.get("task") or cur_task)
        step = "DISPATCH"
    guard = int(budget.get("max_attempts", 1)) * 3 + 6 if isinstance(budget.get("max_attempts"), int) else 6

    while guard > 0:
        guard -= 1
        if step == "RUN":
            b = {**budget, "spent_cost": state["spent_cost"]}
            try:
                d = decide_retry(state["history"], proposed, b)
            except RetryPolicyError as exc:
                out = envelope(task_id, "TASK_INVALID", f"invalid retry budget: {exc}", stage="budget")
                return _final(task_id, out["status"], {"condition": "BUDGET_INVALID", "reason": out["feedback"]["reason"],
                                                       "failure_class": out["failure_class"], "action": out["feedback"]["action"]}, state, result)
            if d["decision"] == "STOP":
                return _stop_on_budget(task_id, d, cur_task, state, result, persist, decisions)
            if mode_next == "EVAL_ONLY":
                replay = _replay_adapters(result or {}, cur_ad, exec_override)
                if replay is None:
                    return _final(task_id, result["status"], {"condition": "REPLAY_UNAVAILABLE", "reason": "no cached frame/route/execution for evaluation-only rerun",
                                                              "failure_class": UNKNOWN_CLASS}, state, result)
                new = runner(cur_task, replay)
            else:
                new = runner(cur_task, cur_ad)
            mode_next, exec_override = "FULL", None
            cls, src = attribute(new)
            entry = {"attempt": len(state["history"]) + 1, "method": _method(new) or proposed.get("method"), "target": _target(cur_task, new) or proposed.get("target"),
                     "status": new.get("status"), "action": new.get("feedback", {}).get("action"), "failure_class": cls, "attribution": src,
                     "unknown_side_effect": bool(new.get("unknown_side_effect")), "new_evidence_ids": list(proposed.get("new_evidence_ids", [])),
                     "run_record": new.get("run_record")}
            state["history"].append(entry)
            result = new
            decisions.append(f"attempt {entry['attempt']}: {entry['status']} -> {entry['action']}")
            step = "DISPATCH"
            fault = _checkpoint(persist, task_id, cur_task, state, result, entry["action"] or "", decisions)
            if fault:
                return _final(task_id, fault["status"], {"condition": "PERSISTENCE_FAULT", "reason": fault["feedback"]["reason"],
                                                         "failure_class": fault["failure_class"], "action": fault["feedback"]["action"]}, state, result, error=fault["error"])
            continue

        # ---- DISPATCH: consume feedback.action of `result` ----
        action = result.get("feedback", {}).get("action", "")
        if action not in REENTRY:
            return _final(task_id, result["status"], {"condition": "UNKNOWN_ACTION", "reason": f"no re-entry row for action {action!r}",
                                                      "failure_class": UNKNOWN_CLASS}, state, result)
        mode, node, _ = REENTRY[action]
        cls, _src = attribute(result)
        if mode == CLOSE:
            missing = sorted(state["regression_required"] - state["regression_done"])
            if missing:
                return _final(task_id, "PARTIAL", {"condition": "REGRESSION_INCOMPLETE", "action": "RUN_REGRESSION", "failure_class": None,
                                                   "reason": f"required regression checks not reported run: {missing}"}, state, result, open_items=missing)
            return _final(task_id, "PASS", {"condition": "ACCEPTED_BY_SLICE", "action": "CLOSE", "failure_class": None, "reason": "all criteria passed with linked evidence"}, state, result)
        if mode == STOP:
            return _final(task_id, STOP_STATUS.get(action, result["status"]), {"condition": "TERMINAL_ACTION", "action": action, "reenter": node,
                                                                              "failure_class": cls or None, "reason": result.get("feedback", {}).get("reason", "")}, state, result)

        ctx = {"task": cur_task, "last_result": result, "history": state["history"], "attempt": len(state["history"]),
               "failure_class": cls, "action": action, "node": node, "evidence_gate": result.get("evidence_gate")}
        if action == "CLASSIFY_FAILURE_BEFORE_RETRY":
            h = handlers.get(action)
            if not callable(h):
                return _final(task_id, result["status"], {"condition": "NO_HANDLER", "action": action, "reenter": node, "failure_class": UNKNOWN_CLASS,
                                                          "reason": "FAILED without attribution and no classify handler; classify before retry"}, state, result)
            try:
                c = dict(h(ctx) or {})
            except Exception as exc:  # noqa: BLE001
                return _handler_fault(task_id, action, exc, state, result)
            branch = c.get("branch")
            root = UNKNOWN_CLASS
            if isinstance(c.get("correction"), Mapping):
                try:
                    root = plan_correction(**c["correction"])["root_cause"]
                except (PropagationError, TypeError) as exc:
                    return _handler_fault(task_id, action, exc, state, result)
            if branch not in BRANCH_ACTION:
                return _final(task_id, result["status"], {"condition": "UNATTRIBUTED", "action": action, "reenter": node, "failure_class": root,
                                                          "reason": "classification produced no repair branch; unknown stays unknown"}, state, result)
            # no evidence-supported root cause stays UNKNOWN; the branch only decides how far back to go
            state["history"][-1]["failure_class"] = root
            state["history"][-1]["attribution"] = "classified:" + ("evidence" if root != UNKNOWN_CLASS else "unsupported_root_cause")
            decisions.append(f"classified {branch}, root_cause={root}")
            action = BRANCH_ACTION[branch]
            mode, node, _ = REENTRY[action]
            if mode == STOP:
                return _final(task_id, STOP_STATUS.get(action, result["status"]), {"condition": "TERMINAL_ACTION", "action": action, "reenter": node,
                                                                                  "failure_class": state["history"][-1]["failure_class"] or None, "reason": c.get("reason", branch)}, state, result)
            ctx.update(action=action, node=node, failure_class=state["history"][-1]["failure_class"])

        h = handlers.get(action)
        if not callable(h) and action in DEFAULT_NOOP:
            h = lambda _ctx: {}  # noqa: E731
        if not callable(h):
            if action in OPTIONAL_HANDLER:
                missing = [r["criterion_id"] for r in (result.get("acceptance") or {}).get("criteria_results", []) if r.get("status") in {"UNKNOWN", "NOT_RUN"}]
                return _final(task_id, result["status"], {"condition": "UNKNOWN_PRESERVED", "action": action, "reenter": node, "failure_class": cls or None,
                                                          "reason": "unknown preserved; missing discriminating evidence for: " + (", ".join(missing) or "unspecified")}, state, result, open_items=missing)
            return _final(task_id, result["status"], {"condition": "NO_HANDLER", "action": action, "reenter": node, "failure_class": cls or None,
                                                      "reason": f"no handler for re-entry action {action}; stopping with state preserved"}, state, result)
        try:
            out = dict(h(ctx) or {})
        except Exception as exc:  # noqa: BLE001
            return _handler_fault(task_id, action, exc, state, result)
        unknown_keys = sorted(set(out) - HANDLER_RESULT_KEYS)
        if unknown_keys:
            return _handler_fault(task_id, action, ValueError(f"unknown handler result keys: {unknown_keys}"), state, result)

        proposed = {"method": out.get("method", _method(result)), "target": out.get("target", _target(cur_task, result)),
                    "new_evidence_ids": list(out.get("new_evidence_ids", [])),
                    "discriminating_change": bool(out.get("discriminating_change")) or bool(out.get("task")) or bool(out.get("adapters")),
                    "actual_state_read": bool(out.get("actual_state_read"))}
        state["spent_cost"] += out["cost"] if isinstance(out.get("cost"), (int, float)) and out["cost"] > 0 else 0
        if out.get("task"):
            cur_task = {**out["task"]}
        if out.get("adapters"):
            cur_ad.update(out["adapters"])

        if action == "REPAIR_LOCAL_NODE_AND_REGRESS" and isinstance(out.get("correction"), Mapping) and callable(out.get("apply")):
            try:
                plan = plan_correction(**out["correction"])
                applied = dict(out["apply"](plan) or {})
            except Exception as exc:  # noqa: BLE001
                return _handler_fault(task_id, action, exc, state, result)
            guard_out = change_set_guard(task_id, plan, applied.get("actually_changed", []))
            if guard_out.get("status") != "WITHIN_PLAN":
                return _final(task_id, guard_out["status"], {"condition": "CHANGE_SET_MISMATCH", "action": guard_out["feedback"]["action"],
                                                             "failure_class": guard_out["failure_class"], "reason": guard_out["feedback"]["reason"]}, state, result, unexpected=guard_out["unexpected"])
            state["regression_required"] |= set(plan["regression_checks"])
            state["regression_done"] |= set(applied.get("regression_run", []))
            proposed["discriminating_change"] = True
            decisions.append(f"local repair within plan {plan['allowed_to_change']}; regressions required {plan['regression_checks']}")
        elif action == "REPAIR_LOCAL_NODE_AND_REGRESS":
            proposed["discriminating_change"] = proposed["discriminating_change"] and bool(out.get("correction"))

        if action == "RERUN_EVALUATION_ONLY":
            mode_next = "EVAL_ONLY"
            # an evaluation that raised never produced a verdict, so its rerun is not a repetition
            proposed["discriminating_change"] = True
        if action == "INSPECT_ACTUAL_STATE_BEFORE_RETRY":
            proposed["actual_state_read"] = True
            oc = out.get("outcome")
            if oc in {"APPLIED", "PARTIAL"}:
                if not isinstance(out.get("execution"), Mapping):
                    return _final(task_id, "INCONCLUSIVE", {"condition": "INSPECTION_INCOMPLETE", "action": action, "failure_class": "TOOL_OR_ADAPTER_ERROR",
                                                            "reason": f"inspection reports {oc} but supplied no observed execution record; execute is not re-run"}, state, result)
                mode_next, exec_override = "EVAL_ONLY", dict(out["execution"])
                proposed["discriminating_change"] = True  # the inspection itself is the new information
                decisions.append(f"actual state {oc}; evaluating observed state, execute not re-run")
            elif oc != "NOT_APPLIED":
                return _final(task_id, "INCONCLUSIVE", {"condition": "INSPECTION_INCOMPLETE", "action": action, "failure_class": "TOOL_OR_ADAPTER_ERROR",
                                                        "reason": "inspection handler must report outcome NOT_APPLIED, APPLIED or PARTIAL"}, state, result)
        step = "RUN"
    return _final(task_id, result["status"] if result else "BLOCKED", {"condition": "LOOP_GUARD", "failure_class": BUDGET_STOP_CLASS,
                                                                      "reason": "iteration guard reached; stopping with state preserved"}, state, result)


def _handler_fault(task_id, action, exc, state, result):
    return _final(task_id, result["status"] if result else "BLOCKED", {"condition": "HANDLER_FAULT", "action": action, "failure_class": "TOOL_OR_ADAPTER_ERROR",
                                                                      "reason": f"handler for {action} failed ({type(exc).__name__}): {str(exc)[:200]}"},
                  state, result, error=error_receipt("handler", exc))


def _stop_on_budget(task_id, d, task, state, result, persist, decisions):
    """decide_retry said STOP: save partial state, close as PARTIAL/BLOCKED (never silently continue)."""
    last = result or {}
    if d.get("required_action") == "INSPECT_ACTUAL_STATE_BEFORE_RETRY":
        status, cond, cls = "INCONCLUSIVE", "INSPECTION_REQUIRED", "TOOL_OR_ADAPTER_ERROR"
    else:
        cond = d.get("stop_condition") or "STOP"
        cls = d.get("failure_class") or BUDGET_STOP_CLASS
        status = "BLOCKED" if cond == "AUTHORITY_UNAVAILABLE" else _blocked_or_partial(last, task.get("profile", {}))
    stop = {"condition": cond, "failure_class": cls, "reason": d.get("reason", ""), "action": "STOP_PARTIAL_STATE_SAVED"}
    if result is not None:
        decisions.append(f"retry refused: {cond}")
        fault = _checkpoint(persist, task_id, task, state, {**result, "status": status}, "STOP_PARTIAL_STATE_SAVED", decisions)
        if fault:
            stop.update(condition="PERSISTENCE_FAULT", failure_class=fault["failure_class"], reason=fault["feedback"]["reason"])
            status = "BLOCKED"
    return _final(task_id, status, stop, state, result, last_status=last.get("status"))


def load_loop_state(root: str, task_id: str, rel_dir: str = "state") -> dict[str, Any]:
    """Read the loop state written by the P2 checkpoint (for ``resume=``)."""
    tid = "".join(c if c.isalnum() or c in "-_" else "_" for c in task_id)
    with open(os.path.join(root, rel_dir, f"{tid}.loop.json"), encoding="utf-8") as fh:
        return json.load(fh)
