"""Coverage view (R2/R5): problems, functions and flows -> how the system handles each.

Single source of level and status = docs/progress_ledger.json (PR-034). This file keeps only MECH
(mechanism name -> source symbol + test file) and PROCESS_FLOWS (task-flow / build-stage rows that have no
ledger entry). Levels: CODE enforced by runtime code AND a named test; SLOT stage/adapter contract exists, effect
NOT_VERIFIED until FINAL_TEST; PROCESS handled by an operating procedure; DECISION owner item. GAP never allowed.
check() proves a mechanism exists and is tested, not that it is sufficient.
Usage: python tools/coverage.py [repo_root] [--md out.md]
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter
from typing import Any

S, G, R, RT, SB, PL, CO, CK, BH = (
    "runtime/foravar_vertical_slice.py", "runtime/policy_gate.py", "runtime/run_record.py", "runtime/retry_policy.py",
    "runtime/state_bundle.py", "runtime/adapter_contract.py", "runtime/correction_propagation.py",
    "tools/check_consistency.py", "tools/final_test_harness.py")
T_RC, T_CTL, T_SB, T_AD, T_CP, T_CC, T_FH = (
    "tests/test_runtime_contract.py", "tests/test_run_control.py", "tests/test_state_bundle.py",
    "tests/test_adapter_contract.py", "tests/test_correction_propagation.py", "tests/test_check_consistency.py",
    "tests/test_final_test_harness.py")

MECH: dict[str, tuple[str, str, str]] = {  # name -> (source file, symbol, test file)
    "TASK": (S, "_validate_task", T_RC), "FRAME": (S, "frame_status", T_RC), "EVID": (S, "_validate_evidence", T_RC),
    "UNK": (S, "NOT_PROVEN", T_RC), "CONFLICT": ("runtime/evidence_gate.py", "def unresolved_conflicts", "tests/test_evidence_gate.py"), "CRIT_UNK": (S, "critical_unknowns", T_RC),
    "ROUTE": (S, "candidate_methods", T_RC), "FAST": (S, "_simple_fast_path", T_RC),
    "EXEC": (S, "TIMEOUT_UNKNOWN_SIDE_EFFECT", T_RC), "CANCEL": (S, "cancel_requested", T_RC),
    "FEEDBACK": (S, "_feedback", T_RC), "BRANCH": (S, "FAILURE_BRANCHES", T_RC),
    "POL": (G, "evaluate_authorization", T_RC), "RUNREC": (R, "build_run_record", T_CTL),
    "RETRY": (RT, "decide_retry", T_CTL), "BUNDLE": (SB, "build_bundle", T_SB), "HANDOFF": (SB, "export_handoff", T_SB),
    "PLUGIN": (PL, "validate_plugin_declaration", T_AD), "CORR": (CO, "plan_correction", T_CP),
    "CHG": (CO, "check_change_set", T_CP), "CONSIST": (CK, "def check", T_CC), "BASE": (BH, "def decide", T_FH),
    "TXN": ("runtime/release_txn.py", "apply_transaction", "tests/test_release_txn.py"),
    "GUARD": ("runtime/content_guard.py", "scan_untrusted", "tests/test_content_guard.py"),
    "ADAPT": ("adapters/model_adapter.py", "make_adapter", "tests/test_model_adapter.py"),
    "COVER": ("tools/coverage.py", "def check", "tests/test_coverage.py"),
    "ERREXIT": ("runtime/error_exits.py", "def envelope", "tests/test_error_exits.py"),
    "GATE": ("tools/stage_gate.py", "def record_gate", "tests/test_stage_gate.py"),
    "LOOP": ("runtime/loop_controller.py", "def run_closed_loop", "tests/test_loop_controller.py"),
    "EGATE": ("runtime/evidence_gate.py", "def assess", "tests/test_evidence_gate.py"),
    "MGATE": ("runtime/model_gate.py", "def assess_model", "tests/test_model_gate.py"),
    "FGATE": ("runtime/frame_gate.py", "def assess_frame", "tests/test_frame_gate.py"),
}
LEVELS = ("CODE", "SLOT", "PROCESS", "DECISION", "GAP")
NO_MECH_STATUS = ("MERGED", "DEFERRED")  # not realised here; no mechanism required
NOT_COUNTED = ("MERGED", "DEFERRED", "PLANNED")  # excluded from the CODE mechanism-backed count

PROCESS_FLOWS: dict[str, tuple[str, list[str], str]] = {
    'TASKFLOW:INTAKE': ('CODE', ['TASK'], ''),
    'TASKFLOW:AUTHORIZE': ('CODE', ['POL'], ''),
    'TASKFLOW:SELECT_SOP': ('SLOT', ['ROUTE', 'ADAPT'], ''),
    'TASKFLOW:PLAN': ('SLOT', ['ROUTE', 'ADAPT'], ''),
    'TASKFLOW:EXECUTE': ('CODE', ['EXEC', 'RUNREC'], ''),
    'TASKFLOW:VERIFY': ('CODE', ['UNK', 'EVID'], ''),
    'TASKFLOW:PERSIST': ('CODE', ['BUNDLE', 'TXN'], 'persist_checkpoint: bundle+handoff written as one transaction'),
    'TASKFLOW:REVIEW': ('PROCESS', ['BASE'], 'independent review is manual'),
    'STAGE:PLANNING': ('PROCESS', ['CORR'], 'impact planning automated; plan authoring manual'),
    'STAGE:REALIZATION': ('CODE', ['CONSIST'], ''),
    'STAGE:CLOSURE': ('CODE', ['CONSIST'], ''),
    'STAGE:FINAL_TEST': ('CODE', ['BASE'], 'harness only; real run is batch 4 (FINAL_TEST), NOT_EXECUTED'),
}
KINDS = ("problems", "functions", "architecture")


def _read(root: str, rel: str) -> str:
    try:
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def _json(root: str, rel: str) -> dict[str, Any]:
    try:
        return json.loads(_read(root, rel) or "{}")
    except ValueError:
        return {}


def expected_ids(root: str) -> dict[str, set[str]]:
    reg, prob = _json(root, "docs/capability_registry.json"), _json(root, "docs/problem_register.json")
    arch = _json(root, "docs/blueprint.json").get("architecture", {})
    oc = _json(root, "docs/operating_contract.json")
    arch_ids = {x["id"] for k in ("axes", "skeleton_nodes", "conditional_framework") for x in arch.get(k, [])}
    flows = set(arch_ids) | {f"TASKFLOW:{s}" for s in oc.get("task_flow", [])}
    flows |= {f"STAGE:{s['stage']}" for s in oc.get("build_stage_flow", [])}
    prob_ids = {i["id"] for i in prob.get("items", [])}
    cap = {i["id"] for i in reg.get("items", [])}
    return {"problems": prob_ids, "functions": cap - prob_ids, "architecture": arch_ids, "flows": flows}


def _row(kind: str, r: dict[str, Any]) -> tuple[str, list[str], str, str]:
    """(level, mechanisms, note, status) of a ledger row."""
    lvl = r.get("control_level" if kind == "problems" else "target_level", "")
    note = r.get("residual" if kind == "problems" else "note", "")
    return lvl, list(r.get("mechanisms") or []), note, r.get("status", "")


def _mech_ok(root: str, mechs: list[str]) -> bool:
    for m in mechs:
        if m not in MECH:
            return False
        src, sym, test = MECH[m]
        if sym.removeprefix("def ") not in _read(root, src) or not _read(root, test):
            return False
    return True


def _scan(root: str, errors: list[str]) -> tuple[dict[str, Counter], dict[str, Any]]:
    led = _json(root, "docs/progress_ledger.json")
    if not led:
        errors.append("progress_ledger.json missing or unreadable")
        return {}, {}
    exp = expected_ids(root)
    levels: dict[str, Counter] = {}
    views: dict[str, Any] = {}
    for kind in KINDS:
        rows = led.get(kind, [])
        have = [r.get("id") for r in rows]
        if set(have) != exp[kind] or len(have) != len(set(have)):
            errors.append(f"{kind}: ledger id set differs from authority (missing={sorted(exp[kind] - set(have))[:5]} "
                          f"extra={sorted(set(have) - exp[kind])[:5]})")
        by_level: Counter = Counter()
        by_status: Counter = Counter()
        backed = total = 0
        for r in rows:
            lvl, mechs, note, status = _row(kind, r)
            by_level[lvl] += 1
            by_status[status] += 1
            if lvl not in LEVELS or lvl == "GAP":
                errors.append(f"{r.get('id')}: level {lvl}")
            for m in mechs:
                if m not in MECH:
                    errors.append(f"{r.get('id')}: unknown mechanism {m}")
            if status in NO_MECH_STATUS:
                continue
            if lvl in ("CODE", "SLOT") and not mechs:
                errors.append(f"{r.get('id')}: {lvl} needs a mechanism")
            if lvl == "PROCESS" and not note:
                errors.append(f"{r.get('id')}: PROCESS needs a note on the procedure")
            if lvl == "CODE" and status not in NOT_COUNTED:
                total += 1
                if mechs and _mech_ok(root, mechs):
                    backed += 1
                else:
                    errors.append(f"{r.get('id')}: CODE item without existing mechanism symbol/test")
            if status == "ACCEPTED" and not r.get("evidence"):
                errors.append(f"{r.get('id')}: ACCEPTED without evidence")
        levels[kind] = by_level
        views[kind] = {"total": len(rows), "level": dict(by_level), "status": dict(by_status),
                       "code_mechanism_backed": f"{backed}/{total}"}
    pf_have = set(PROCESS_FLOWS)
    pf_want = exp["flows"] - exp["architecture"]
    if pf_have != pf_want:
        errors.append(f"flows: process-flow table differs from operating_contract (missing={sorted(pf_want - pf_have)} extra={sorted(pf_have - pf_want)})")
    for id_, (lvl, mechs, note) in PROCESS_FLOWS.items():
        if lvl not in LEVELS or lvl == "GAP":
            errors.append(f"{id_}: level {lvl}")
        if lvl in ("CODE", "SLOT") and not mechs:
            errors.append(f"{id_}: {lvl} needs a mechanism")
        if lvl == "PROCESS" and not note:
            errors.append(f"{id_}: PROCESS needs a note on the procedure")
        if mechs and not _mech_ok(root, mechs):
            errors.append(f"{id_}: mechanism missing symbol/test")
    views["_led"] = led
    return levels, views


def ledger_report(root: str) -> dict[str, Any]:
    """Progress view from the ledger. ACCEPTED is listed separately and never inferred from tests."""
    errors: list[str] = []
    _, views = _scan(root, errors)
    led = views.pop("_led", {})
    gates = [(g.get("stage"), g.get("batch"), g.get("status")) for g in led.get("stage_gates", [])]
    accepted = sum(1 for k in KINDS for r in led.get(k, []) if r.get("status") == "ACCEPTED")
    return {"errors": errors, "views": views, "gates": gates, "accepted": accepted}


def check(root: str) -> dict[str, Any]:
    errors: list[str] = []
    for name, (src, sym, test) in MECH.items():
        if sym.removeprefix("def ") not in _read(root, src):
            errors.append(f"mechanism {name}: symbol '{sym}' not found in {src}")
        if not _read(root, test):
            errors.append(f"mechanism {name}: test file {test} missing")
    levels, views = _scan(root, errors)
    led = views.pop("_led", {})
    exp = expected_ids(root)
    fl = Counter(PROCESS_FLOWS[k][0] for k in PROCESS_FLOWS) + levels.get("architecture", Counter())
    out_levels = {"problems": dict(levels.get("problems", {})), "functions": dict(levels.get("functions", {})), "flows": dict(fl)}
    totals = {"problems": len(exp["problems"]), "functions": len(exp["functions"]), "flows": len(exp["flows"])}
    accepted = sum(1 for k in KINDS for r in led.get(k, []) if r.get("status") == "ACCEPTED")
    gates = [(g.get("stage"), g.get("batch"), g.get("status")) for g in led.get("stage_gates", [])]
    return {"errors": errors, "levels": out_levels, "totals": totals,
            "ledger": {"views": views, "gates": gates, "accepted": accepted}}


def hud_markdown(root: str) -> str:
    rep = ledger_report(root)
    out = ["# forAVAr HUD（ledger 驅動）", ""]
    out.append("放行：" + " → ".join(f"{s}({b}):{st}" for s, b, st in rep["gates"]))
    out.append(f"ACCEPTED：{rep['accepted']}（未達 SYSTEM_DONE 不得宣稱完成）")
    out += ["", "| 類別 | 總數 | 層級 | 狀態 | CODE 機制備齊 |", "|---|---|---|---|---|"]
    for kind, v in rep["views"].items():
        out.append(f"| {kind} | {v['total']} | {v['level']} | {v['status']} | {v['code_mechanism_backed']} |")
    out.append("")
    out += [f"ERROR: {e}" for e in rep["errors"]] or ["ledger 與權威 ID 集合一致"]
    return "\n".join(out) + "\n\n"


def to_markdown(root: str) -> str:
    out = [hud_markdown(root) + "# forAVAr 覆蓋清冊（問題／功能／流程）", "",
           "CODE＝程式強制且有測試；SLOT＝契約入口、內容由 adapter 提供（未驗證）；PROCESS＝靠流程手動處理。層級與狀態來源＝ledger。", ""]
    titles: dict[str, str] = {}
    for i in _json(root, "docs/problem_register.json").get("items", []):
        titles[i["id"]] = i.get("title", "")
    for i in _json(root, "docs/capability_registry.json").get("items", []):
        titles.setdefault(i["id"], i.get("name", ""))
    led = _json(root, "docs/progress_ledger.json")
    for a in led.get("architecture", []):
        titles.setdefault(a["id"], a.get("name", ""))
    tables = {"問題清單": [(r["id"],) + _row("problems", r)[:3] for r in led.get("problems", [])],
              "功能清單": [(r["id"],) + _row("functions", r)[:3] for r in led.get("functions", [])],
              "流程清單": [(r["id"],) + _row("architecture", r)[:3] for r in led.get("architecture", [])]
              + [(k, *v) for k, v in PROCESS_FLOWS.items()]}
    for kind, rows in tables.items():
        out += [f"## {kind}（{len(rows)}）", "", "| ID | 名稱 | 層級 | 處理機制 | 限制／說明 |", "|---|---|---|---|---|"]
        for id_, lvl, mechs, note in rows:
            out.append(f"| {id_} | {titles.get(id_, '')[:28]} | {lvl} | {' '.join(mechs)} | {note} |")
        out.append("")
    return "\n".join(out)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    repo = args[0] if args and not args[0].endswith(".md") else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    if "--md" in sys.argv:
        dest = sys.argv[sys.argv.index("--md") + 1]
        with open(dest, "w", encoding="utf-8") as fh:
            fh.write(to_markdown(repo))
    rep = check(repo)
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    sys.exit(1 if rep["errors"] else 0)
