# foravab B23.4 — 外部資料包（主 repo 之外）
對應主 repo：ForAVAr-main_B23_4.zip。檔名隨更新批號變動。規則：只放「下一次更新會用到」的資料；用過、用不到的移除並在下表留一行；要用再回找。

## 在包內（下次更新用）
| 檔案 | sha256 前16 | 內容 | 下次用途 |
|---|---|---|---|
| data/closure_resolved.json | bb8f0c3bd5f9b36b | 閉環情境已解／OK 列（24 列：B22 17＋B23 段2 FIXED 7） | B24 CLOSURE 回歸時的情境目錄；R4 frame／R3 model 已新增 slice 階段（皆選用），B24 確認未回退；R3-synthesis 完成後再確認一次 |

## 已移除（只留紀錄；回找路徑見各列）
| 資料 | sha256 前16 | 用過於 | 為何移除 |
|---|---|---|---|
| tools/final_test_runs/B18_outputs.json（5497B） | fe489b0f71858881 | B18 C0/C1/C2 同模型錄製輸出；SIMULATION_ONLY | 下次更新不用；B25 以真實運行重產；回找＝ForAVAr-main_B22.zip |
| tools/final_test_runs/B18_result.json（2056B） | b3ff90e9bf758b60 | B18 重播結果；SIMULATION_ONLY | 同上 |
| tools/final_test_runs/B19_outputs.json（17609B） | 4376a6e8919f8d19 | B19 v2 錄製輸出；SIMULATION_ONLY | 同上 |
| tools/final_test_runs/B19_result.json（4447B） | 50c53b48e4ae10b5 | B19 重播結果；SIMULATION_ONLY | 同上 |
| tools/final_test_run.py＋tests/test_final_test_run.py | — | 重播上述資料的執行器 | 只服務已移除資料；B25 另寫真實運行腳本 |
| tools/coverage.py 舊手寫層級表（PROBLEMS／FUNCTIONS／FLOWS） | — | B23 段3（R5） | 內容已全數搬入 ledger（mechanisms／note），不再使用；回找路徑＝ForAVAr-main_B23_2.zip |

備註：rubric 指紋 ece6a3b7ce587fb8／5eed467fa27fda63 記在 blueprint maturity 與 handoff，B25 沿用。
