import json
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
from check_consistency import check  # noqa: E402


class ConsistencyTests(unittest.TestCase):
    def copy_repo(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for sub in ("docs", "runtime", "tests"):
            shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copy(os.path.join(ROOT, "README.md"), d)
        return d

    def test_real_repo_has_no_errors(self):
        r = check(ROOT)
        self.assertEqual(r["errors"], 0, r["findings"])
        self.assertGreater(r["ids_checked"]["capability"], 0)

    def test_detects_duplicate_id_and_count_mismatch(self):
        d = self.copy_repo()
        p = os.path.join(d, "docs", "capability_registry.json")
        data = json.load(open(p, encoding="utf-8"))
        data["items"].append(dict(data["items"][0]))
        json.dump(data, open(p, "w", encoding="utf-8"))
        checks = {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}
        self.assertTrue({"id_unique", "index_counts"} <= checks)

    def test_detects_broken_json_missing_file_and_unlisted_module(self):
        d = self.copy_repo()
        open(os.path.join(d, "docs", "problem_register.json"), "w").write("{bad")
        os.remove(os.path.join(d, "runtime", "run_record.py"))
        open(os.path.join(d, "runtime", "extra.py"), "w").write("")
        checks = {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}
        self.assertTrue({"json_parse", "local_ref", "readme_listing"} <= checks)

    def test_rejected_is_info_not_error(self):
        r = check(ROOT)
        self.assertTrue(any(x["level"] == "INFO" and "REJECTED" in x["detail"] for x in r["findings"]), r["findings"])


if __name__ == "__main__":
    unittest.main()
