"""State bundle P0/P1/P2 and handoff export (blueprint runtime_contract.state_bundle).

Three state classes are kept in separate sections and never merged:
TASK_EXECUTION_STATE, CLAIM_EVIDENCE_STATE, LONG_TERM_RULE_MEMORY.
A bundle is a portable *derived view*: it never replaces authoritative files or
execution receipts (it only references them). No GitHub operations; stdlib json only.

Levels: P0 = no persisted state (nothing is written); P1 = minimal status, key decisions,
blockers, verified results, evidence links; P2 = task-bound checkpoint (adds run_records,
next_action, recovery).
Read-only: LONG_TERM_RULE_MEMORY (P1/P2 authority files) is never written by this module;
``write_bundle`` refuses to touch it and ``read_bundle`` returns an immutable view.
SOP-HANDOFF-001 stays PROVISIONAL_CURRENT_MANUAL -- export is a helper, not automation.
"""
from __future__ import annotations

import json
import os
import tempfile
from collections.abc import Mapping
from types import MappingProxyType
from typing import Any

LEVELS = ("P0", "P1", "P2")
STATE_CLASSES = ("TASK_EXECUTION_STATE", "CLAIM_EVIDENCE_STATE", "LONG_TERM_RULE_MEMORY")
HANDOFF_FIELDS = (
    "task_id", "goal", "acceptance", "scope_and_permissions", "source_commit",
    "current_status", "completed_with_evidence", "open_or_blocked_items",
    "key decisions", "modified_paths", "tests actually run/results", "next_action",
    "recovery/rollback if applicable",
)
P1_TASK_KEYS = ("status", "key_decisions", "blockers")
P2_TASK_EXTRA = ("run_records", "next_action", "recovery")
SCHEMA = "foravar.state_bundle/1"


class StateBundleError(ValueError):
    """Raised for malformed bundles or forbidden writes."""


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({k: _freeze(v) for k, v in value.items()})
    if isinstance(value, list):
        return tuple(_freeze(v) for v in value)
    return value


def build_bundle(task_id: str, level: str, *, task_state: Mapping[str, Any] | None = None,
                 evidence_state: Mapping[str, Any] | None = None,
                 rule_memory_refs: list[str] | None = None) -> dict[str, Any] | None:
    """Build a bundle. P0 returns None (no extra persisted state)."""
    if level not in LEVELS:
        raise StateBundleError(f"level must be one of {LEVELS}")
    if not isinstance(task_id, str) or not task_id.strip():
        raise StateBundleError("task_id is required")
    if level == "P0":
        return None
    ts = dict(task_state or {})
    allowed = set(P1_TASK_KEYS) | (set(P2_TASK_EXTRA) if level == "P2" else set())
    extra = sorted(set(ts) - allowed)
    if extra:
        raise StateBundleError(f"task_state keys not allowed at {level}: {extra}")
    ev = dict(evidence_state or {})
    bad = sorted(set(ev) - {"verified_results", "evidence_links", "claims"})
    if bad:
        raise StateBundleError(f"evidence_state keys not allowed: {bad}")
    return {
        "schema": SCHEMA,
        "task_id": task_id,
        "level": level,
        "TASK_EXECUTION_STATE": ts,
        "CLAIM_EVIDENCE_STATE": ev,
        # references only; the rule memory itself is read-only and lives in the repo
        "LONG_TERM_RULE_MEMORY": {"refs": list(rule_memory_refs or []), "access": "READ_ONLY"},
        "authority_note": "derived view; does not replace authoritative files or execution receipts",
    }


def validate_bundle(bundle: Mapping[str, Any]) -> list[str]:
    errors: list[str] = []
    if bundle.get("schema") != SCHEMA:
        errors.append("schema mismatch")
    if bundle.get("level") not in ("P1", "P2"):
        errors.append("level must be P1 or P2 in a persisted bundle")
    for cls in STATE_CLASSES:
        if not isinstance(bundle.get(cls), Mapping):
            errors.append(f"missing state class {cls}")
    if bundle.get("LONG_TERM_RULE_MEMORY", {}).get("access") != "READ_ONLY":
        errors.append("LONG_TERM_RULE_MEMORY must be READ_ONLY")
    return errors


def write_bundle(bundle: Mapping[str, Any] | None, path: str) -> str | None:
    """Atomically write a P1/P2 bundle as JSON. P0 (None) writes nothing."""
    if bundle is None:
        return None
    errors = validate_bundle(bundle)
    if errors:
        raise StateBundleError("; ".join(errors))
    norm = os.path.normpath(path).replace("\\", "/")
    parts = norm.split("/")
    if "docs" in parts or parts[-1] in {"blueprint.json", "operating_contract.json",
                                          "capability_registry.json", "problem_register.json", "index.json"}:
        raise StateBundleError("refusing to write into authority files/docs (read-only memory)")
    directory = os.path.dirname(os.path.abspath(path))
    os.makedirs(directory, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=directory, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(bundle, fh, ensure_ascii=False, sort_keys=True, indent=2)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return path


def read_bundle(path: str) -> Mapping[str, Any]:
    """Read a bundle as an immutable view (cannot be mutated and re-saved by accident)."""
    with open(path, encoding="utf-8") as fh:
        data = json.load(fh)
    errors = validate_bundle(data)
    if errors:
        raise StateBundleError("; ".join(errors))
    return _freeze(data)


def export_handoff(fields: Mapping[str, Any]) -> dict[str, Any]:
    """Return a handoff dict with exactly operating_contract.handoff_fields.

    Missing fields become 'NOT_PROVIDED' (never invented); unknown keys are rejected.
    """
    unknown = sorted(set(fields) - set(HANDOFF_FIELDS))
    if unknown:
        raise StateBundleError(f"unknown handoff fields: {unknown}")
    out = {f: fields.get(f, "NOT_PROVIDED") for f in HANDOFF_FIELDS}
    out["handoff_status"] = "SOP-HANDOFF-001=PROVISIONAL_CURRENT_MANUAL"
    return out


def handoff_to_markdown(handoff: Mapping[str, Any]) -> str:
    lines = [f"# HANDOFF {handoff.get('task_id', '')}", ""]
    for f in HANDOFF_FIELDS[1:]:
        v = handoff.get(f, "NOT_PROVIDED")
        if isinstance(v, (list, tuple)):
            v = "\n".join(f"- {x}" for x in v) or "NOT_PROVIDED"
        lines += [f"## {f}", str(v), ""]
    lines.append(f"_{handoff.get('handoff_status', '')}_")
    return "\n".join(lines)
