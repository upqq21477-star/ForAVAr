"""Static consistency check (SOP-CAND-008). Read-only; stdlib only; not part of Runtime.

Placement note: this is a repo-maintenance tool, not Runtime/source. It is kept under
tools/ (not runtime/) so the runtime boundary stays clean; move to forAVArb if the owner
prefers. Checks: JSON parses; capability/problem IDs unique and match index counts; local
path references exist; runtime/tests files are listed in README; code status literals vs
blueprint runtime_contract.statuses. Findings: ERROR (breaks consistency) or INFO (known,
documented deviation). Usage: python tools/check_consistency.py [repo_root]
"""
from __future__ import annotations

import json
import os
import re
import sys
from typing import Any

DOCS = ("blueprint.json", "operating_contract.json", "capability_registry.json", "problem_register.json", "index.json")
# F5 vocabulary kept by design (see handoff): not in terminal_states but intentionally used.
KNOWN_EXTRA_STATUSES = {"REJECTED"}
PATH_RE = re.compile(r"(?:runtime|tests|tools|docs)/[\w./-]+\.(?:py|json|md)")


def _load(root: str, name: str, findings: list[dict[str, str]]) -> Any:
    try:
        with open(os.path.join(root, "docs", name), encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError) as exc:
        findings.append({"level": "ERROR", "check": "json_parse", "detail": f"docs/{name}: {exc}"})
        return None


def _dups(ids: list[str]) -> list[str]:
    seen: set[str] = set()
    return sorted({i for i in ids if i in seen or seen.add(i)})  # type: ignore[func-returns-value]


def check(root: str) -> dict[str, Any]:
    f: list[dict[str, str]] = []
    err = lambda c, d: f.append({"level": "ERROR", "check": c, "detail": d})  # noqa: E731
    info = lambda c, d: f.append({"level": "INFO", "check": c, "detail": d})  # noqa: E731
    docs = {n: _load(root, n, f) for n in DOCS}

    cap, prob, idx, bp = (docs[n] for n in ("capability_registry.json", "problem_register.json", "index.json", "blueprint.json"))
    cap_ids = [i.get("id") for i in (cap or {}).get("items", [])]
    prob_ids = [i.get("id") for i in (prob or {}).get("items", [])]
    for label, ids in (("capability", cap_ids), ("problem", prob_ids)):
        if _dups(ids):
            err("id_unique", f"duplicate {label} ids: {_dups(ids)}")
    snap = (idx or {}).get("integrity_snapshot", {})
    for label, ids, key in (("capability", cap_ids, "capability_items"), ("problem", prob_ids, "problem_items")):
        if idx and snap.get(key) != len(ids):
            err("index_counts", f"index {key}={snap.get(key)} but registry has {len(ids)} {label} items")

    readme_path = os.path.join(root, "README.md")
    readme = open(readme_path, encoding="utf-8").read() if os.path.exists(readme_path) else ""
    if not readme:
        err("readme", "README.md missing or empty")
    refs = set(PATH_RE.findall(readme)) | set(PATH_RE.findall(json.dumps(idx or {}, ensure_ascii=False)))
    for ref in sorted(refs):
        if not os.path.exists(os.path.join(root, ref)):
            err("local_ref", f"referenced path does not exist: {ref}")
    for folder in ("runtime", "tests"):
        d = os.path.join(root, folder)
        for name in sorted(os.listdir(d)) if os.path.isdir(d) else []:
            if name.endswith(".py") and not name.startswith("__") and f"{folder}/{name}" not in readme:
                err("readme_listing", f"{folder}/{name} not listed in README")

    statuses = set((bp or {}).get("runtime_contract", {}).get("statuses", []))
    code_path = os.path.join(root, "runtime", "foravar_vertical_slice.py")
    if statuses and os.path.exists(code_path):
        src = open(code_path, encoding="utf-8").read()
        used = set(re.findall(r'_early\(\s*"([A-Z_]+)"', src)) | set(re.findall(r'status = "([A-Z_]+)"', src))
        used |= {s for s in KNOWN_EXTRA_STATUSES if f'"{s}"' in src}
        for s in sorted(used - statuses):
            (info if s in KNOWN_EXTRA_STATUSES else err)("status_vocab", f"code status '{s}' not in blueprint runtime_contract.statuses" + (" (known F5 deviation)" if s in KNOWN_EXTRA_STATUSES else ""))
    return {"errors": sum(x["level"] == "ERROR" for x in f), "info": sum(x["level"] == "INFO" for x in f),
            "findings": f, "ids_checked": {"capability": len(cap_ids), "problem": len(prob_ids)}}


if __name__ == "__main__":
    report = check(sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), ".."))
    print(json.dumps(report, ensure_ascii=False, indent=2))
    sys.exit(1 if report["errors"] else 0)
