# forAVAr

```json
{
  "INDEX": "docs/index.json",
  "BLUEPRINT": "docs/blueprint.json",
  "OPERATING_CONTRACT": "docs/operating_contract.json",
  "CAPABILITY_REGISTRY": "docs/capability_registry.json",
  "PROBLEM_REGISTER": "docs/problem_register.json",
  "RUNTIME": ["runtime/foravar_vertical_slice.py", "runtime/policy_gate.py", "runtime/run_record.py", "runtime/retry_policy.py", "runtime/state_bundle.py", "runtime/adapter_contract.py"],
  "TESTS": ["tests/test_runtime_contract.py", "tests/test_run_control.py", "tests/test_state_bundle.py", "tests/test_adapter_contract.py", "tests/test_check_consistency.py", "tests/test_final_test_harness.py"],
  "TOOLS": ["tools/check_consistency.py", "tools/final_test_harness.py"],
  "ARCHIVE_REPO": "upqq21477-star/forAVArb",
  "P1": "READ_ONLY",
  "P2": "READ_ONLY"
}
```

Start at `docs/index.json` for navigation by architecture layer, A/N/F IDs, M/G/P/T, capability IDs, PR IDs and archived source paths.

Current authority: `docs/blueprint.json`, `docs/operating_contract.json`, `docs/capability_registry.json`, `docs/problem_register.json`.

Research/history/candidate/validation source files are archived in `forAVArb`; find exact source paths via the [archive manifest](https://github.com/upqq21477-star/forAVArb/blob/main/歸檔/forAVAr_main_退場歸檔_2026-10-24/manifest.json).

Runtime status: `POLICY_GATE_INTEGRATED_RUNTIME_NOT_VALIDATED`. Contract tests: `python -m unittest discover -s tests`; recorded results and maturity are in `docs/blueprint.json` under `maturity`.
