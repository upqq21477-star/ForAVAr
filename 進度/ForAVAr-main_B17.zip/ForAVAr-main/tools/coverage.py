"""Coverage ledger: every problem, function and flow item -> how the system handles it.

This is the executable form of VIEW-006 (P1/P2 function -> four layers) and VIEW-008
(problem -> control point -> regression). Levels (honest, not promotional):
  CODE     enforced by runtime code AND covered by a named test (see MECH; limits in note)
  SLOT     runtime defines the stage/adapter contract; the reasoning content is supplied by an
           adapter -- the entry point exists, effectiveness is NOT_VERIFIED until FINAL_TEST
  PROCESS  handled by an operating procedure/SOP; no automation (manual by design)
  DECISION owner decision item, not a function
  GAP      not handled (must stay empty; check() reports any)
check() verifies completeness against the registries, and that each mechanism's file, symbol
and test exist. It cannot prove a mechanism is *sufficient* -- only that it exists and is tested.
Usage: python tools/coverage.py [repo_root] [--md out.md]
"""
from __future__ import annotations

import json
import os
import sys
from collections import Counter
from typing import Any

S, G, R, RR_, RT, SB, PL, CO, CK, BH = (
    "runtime/foravar_vertical_slice.py", "runtime/policy_gate.py", "runtime/run_record.py", "runtime/run_record.py",
    "runtime/retry_policy.py", "runtime/state_bundle.py", "runtime/adapter_contract.py",
    "runtime/correction_propagation.py", "tools/check_consistency.py", "tools/final_test_harness.py")
T_RC, T_CTL, T_SB, T_AD, T_CP, T_CC, T_FH = (
    "tests/test_runtime_contract.py", "tests/test_run_control.py", "tests/test_state_bundle.py",
    "tests/test_adapter_contract.py", "tests/test_correction_propagation.py", "tests/test_check_consistency.py",
    "tests/test_final_test_harness.py")

MECH: dict[str, tuple[str, str, str]] = {  # name -> (source file, symbol, test file)
    "TASK": (S, "_validate_task", T_RC), "FRAME": (S, "frame_status", T_RC), "EVID": (S, "_validate_evidence", T_RC),
    "UNK": (S, "NOT_PROVEN", T_RC), "CONFLICT": (S, "CONFLICT", T_RC), "CRIT_UNK": (S, "critical_unknowns", T_RC),
    "ROUTE": (S, "candidate_methods", T_RC), "FAST": (S, "_simple_fast_path", T_RC),
    "EXEC": (S, "TIMEOUT_UNKNOWN_SIDE_EFFECT", T_RC), "CANCEL": (S, "cancel_requested", T_RC),
    "FEEDBACK": (S, "_feedback", T_RC), "BRANCH": (S, "FAILURE_BRANCHES", T_RC),
    "POL": (G, "evaluate_authorization", T_RC), "RUNREC": (R, "build_run_record", T_CTL),
    "RETRY": (RT, "decide_retry", T_CTL), "BUNDLE": (SB, "build_bundle", T_SB), "HANDOFF": (SB, "export_handoff", T_SB),
    "PLUGIN": (PL, "validate_plugin_declaration", T_AD), "CORR": (CO, "plan_correction", T_CP),
    "CHG": (CO, "check_change_set", T_CP), "CONSIST": (CK, "def check", T_CC), "BASE": (BH, "def decide", T_FH),
    "TXN": ("runtime/release_txn.py", "apply_transaction", "tests/test_release_txn.py"),
    "GUARD": ("runtime/content_guard.py", "scan_untrusted", "tests/test_content_guard.py"),
    "ADAPT": ("adapters/model_adapter.py", "make_adapter", "tests/test_model_adapter.py"),
    "COVER": ("tools/coverage.py", "def check", "tests/test_coverage.py"),
}
LEVELS = ("CODE", "SLOT", "PROCESS", "DECISION", "GAP")
Item = tuple[str, list[str], str]


def _i(level: str, mechs: str = "", note: str = "") -> Item:
    return level, [m for m in mechs.split() if m], note


PROBLEMS: dict[str, Item] = {
    "PR-001": _i("CODE", "TASK EVID", "criteria are mandatory; result judged against them"),
    "PR-002": _i("CODE", "EVID UNK", "claims without linked OBSERVED evidence downgrade to UNKNOWN"),
    "PR-003": _i("CODE", "EVID", "revision/date required; staleness judgement itself is adapter-supplied"),
    "PR-004": _i("CODE", "BUNDLE HANDOFF"),
    "PR-005": _i("CODE", "BUNDLE", "checkpoint + deterministic compaction (compact_bundle); no semantic summarisation"),
    "PR-006": _i("CODE", "CORR", "root cause UNKNOWN unless OBSERVED evidence supports it"),
    "PR-007": _i("CODE", "UNK CONFLICT"),
    "PR-008": _i("CODE", "RETRY EVID", "same input+method is not independent verification"),
    "PR-009": _i("CODE", "POL GUARD", "authorization fail-closed + heuristic content scan quarantines instruction-like evidence; paraphrased/encoded injection not detected"),
    "PR-010": _i("CODE", "BASE RUNREC", "regression comparator + target_version/fingerprint; real drift detection needs FINAL_TEST"),
    "PR-011": _i("CODE", "CORR", "no rule from unsupported cause; promotion decision itself is manual"),
    "PR-012": _i("CODE", "ROUTE RETRY"),
    "PR-013": _i("CODE", "FRAME BRANCH", "unready frame stops; FRAME_FAILURE routes to reframe"),
    "PR-014": _i("CODE", "CORR"),
    "PR-015": _i("CODE", "PLUGIN CONSIST"),
    "PR-016": _i("CODE", "PLUGIN EVID", "declared capability is not evidence"),
    "PR-017": _i("CODE", "TXN", "verify-fail or crash -> full rollback from snapshot; applying is automated, choosing the change is not"),
    "PR-018": _i("CODE", "POL PLUGIN", "declared side effects are not a security boundary"),
    "PR-019": _i("CODE", "CONSIST"),
    "PR-020": _i("CODE", "CHG"),
    "PR-021": _i("PROCESS", "HANDOFF", "handoff export exists; cannot force a new session to load rules"),
    "PR-022": _i("PROCESS", "", "logical roles do not prove independence (blueprint); independent review is manual"),
    "PR-023": _i("CODE", "BASE", "rubric fixed + fingerprinted before runs; required sample kinds"),
    "PR-024": _i("CODE", "RETRY"),
    "PR-025": _i("CODE", "UNK CORR", "unknown is never treated as compatible; impact set is bounded"),
    "PR-026": _i("CODE", "TXN BUNDLE", "restore_drill re-hashes snapshot; retained zips remain the off-repo backup"),
    "PR-027": _i("CODE", "BASE"),
    "PR-028": _i("CODE", "CORR CHG TXN", "all-or-nothing change set via release_txn; lock file serialises writers"),
    "PR-029": _i("CODE", "EVID", "revision/date recorded; refresh trigger is manual"),
    "PR-030": _i("CODE", "POL"),
    "PR-031": _i("CODE", "FAST"),
    "PR-032": _i("PROCESS", "PLUGIN", "map to existing capability IDs first (plugin_contract replacement rule)"),
    "PR-033": _i("PROCESS", "CONSIST", "single authority order; checker catches listing drift only"),
    "PR-034": _i("PROCESS", "CONSIST"),
    "PR-035": _i("PROCESS", "CONSIST"),
    "PR-036": _i("CODE", "CORR"),
    "PR-037": _i("PROCESS", "BASE", "adoption requires baseline comparison"),
    "PR-038": _i("PROCESS", "", "retirement governance is a procedure (VIEW-011)"),
    "PR-039": _i("CODE", "BASE"),
    "PR-040": _i("CODE", "CONSIST", "IDs unique and severity-independent"),
    "PR-041": _i("PROCESS", "", "terminology disambiguation is editorial"),
    "PR-042": _i("CODE", "EVID", "PROGRAM_TEST/RUNTIME_OBSERVATION need run_id/command; maturity labels separate research from execution"),
    "PR-043": _i("CODE", "CONSIST"),
    "PR-044": _i("CODE", "CONSIST", "status vocabulary checked against blueprint"),
    "PR-045": _i("PROCESS", "", "behavioral; minimal clarification is not machine-checkable"),
    "PR-046": _i("PROCESS", "", "presentation choice (VIEW-010)"),
    "PR-047": _i("PROCESS", ""),
    "PR-048": _i("PROCESS", "BASE", "introduce only after baseline comparison"),
    "PR-049": _i("SLOT", "ROUTE PLUGIN", "domain adapters plug in via route + plugin_contract"),
    "PR-050": _i("CODE", "BUNDLE POL", "state writer refuses docs/ authority files; protected actions need authorization"),
    "PR-051": _i("PROCESS", "", "do not pre-build abstractions; enforced by review"),
    "PR-052": _i("CODE", "BUNDLE HANDOFF", "context bundle exists; no GitHub operations by design"),
    "PR-053": _i("CODE", "TASK POL", "task validated and gate runs before execution"),
    "PR-054": _i("PROCESS", "HANDOFF", "placement/writeback loop is procedural"),
}

FUNCTIONS: dict[str, Item] = {}
_slot_ev = "ROUTE"  # analysis capabilities enter through adapter stages
for n in range(1, 49):
    FUNCTIONS[f"P1-F{n:02d}"] = _i("SLOT", "EVID", "analysis content supplied by evidence/frame/evaluate adapters")
FUNCTIONS.update({
    "P1-F06": _i("CODE", "EVID", "claim vs evidence separated by kind/status"),
    "P1-F10": _i("CODE", "CRIT_UNK", "critical unknowns block high-risk tasks"),
    "P1-F15": _i("CODE", "CONFLICT"),
    "P1-F32": _i("CODE", "EVID"), "P1-F38": _i("CODE", "EVID", "criteria results must cite linked OBSERVED evidence"),
    "P1-F40": _i("CODE", "UNK"), "P1-F43": _i("CODE", "RETRY"), "P1-F46": _i("CODE", "UNK", "unknowns preserved"),
    "P1-F48": _i("CODE", "RUNREC BUNDLE", "trace + receipts + checkpoint"),
})
_p2 = {
    1: ("CODE", "TASK"), 2: ("CODE", "ROUTE", "route contract validated before execution"), 3: ("CODE", "PLUGIN"),
    4: ("SLOT", "ROUTE"), 5: ("CODE", "ROUTE FEEDBACK"), 6: ("PROCESS", "", "roles are logical only"),
    7: ("CODE", "RUNREC"), 8: ("SLOT", "EVID"), 9: ("CODE", "BUNDLE"), 10: ("PROCESS", "", "rebuild is manual"),
    11: ("PROCESS", "", "lifecycle/archive procedure"), 12: ("SLOT", "PLUGIN"), 13: ("CODE", "CORR"),
    14: ("CODE", "CONSIST HANDOFF"), 15: ("CODE", "BRANCH", "failure_branch + failure_class"),
    16: ("PROCESS", "", "chat+GitHub minimal mode is operational"), 17: ("CODE", "BUNDLE"),
    18: ("PROCESS", "PLUGIN", "intake/retire is procedural"), 19: ("CODE", "UNK FEEDBACK"),
    20: ("PROCESS", "", "BUILD/REPAIR/EXTEND selection by owner/agent"), 21: ("SLOT", "ROUTE"), 22: ("CODE", "CORR"),
    23: ("PROCESS", "", "think/build isolation is operational"), 24: ("SLOT", "FRAME"),
    25: ("PROCESS", "", "distillation pack is manual"), 26: ("PROCESS", "CONSIST"), 27: ("PROCESS", ""),
    28: ("PROCESS", "CORR", "classification manual; impact set automated"), 29: ("CODE", "RETRY", "budget only"),
    30: ("PROCESS", "BASE", "four-stage governance is the operating flow; FINAL_TEST harness exists"),
}
for n, v in _p2.items():
    FUNCTIONS[f"P2-F{n:02d}"] = _i(*v)
FUNCTIONS.update({
    "CF-001": _i("CODE", "ROUTE"), "CF-002": _i("SLOT", "EVID"), "CF-003": _i("SLOT", "EVID"),
    "CF-004": _i("PROCESS", "HANDOFF"), "CF-005": _i("CODE", "CORR", "problem ID reuse"),
    "CF-006": _i("PROCESS"), "CF-007": _i("PROCESS"), "CF-008": _i("CODE", "CONSIST"), "CF-009": _i("PROCESS"),
    "CF-010": _i("PROCESS"),
    "SOP-CAND-005": _i("PROCESS", "POL CONSIST"), "SOP-CAND-006": _i("CODE", "CORR"), "SOP-CAND-007": _i("CODE", "CORR"),
    "SOP-CAND-008": _i("CODE", "CONSIST"), "SOP-CAND-009": _i("CODE", "BASE"), "SOP-CAND-010": _i("CODE", "HANDOFF"),
    "SOP-CAND-011": _i("SLOT", "FRAME"), "SOP-CAND-012": _i("CODE", "BUNDLE BASE"),
    "SOP-META-001": _i("PROCESS"), "SOP-DOC-001": _i("PROCESS"),
    "VIEW-001": _i("CODE", "CONSIST"), "VIEW-002": _i("PROCESS"), "VIEW-003": _i("CODE", "CONSIST"),
    "VIEW-004": _i("PROCESS"), "VIEW-005": _i("PROCESS", "", "maturity layers live in blueprint.maturity"),
    "VIEW-006": _i("CODE", "COVER"), "VIEW-007": _i("PROCESS"), "VIEW-008": _i("CODE", "COVER"),
    "VIEW-009": _i("CODE", "POL"), "VIEW-010": _i("PROCESS"), "VIEW-011": _i("PROCESS"),
    "VIEW-012": _i("CODE", "BUNDLE CONSIST"),
    "CORE-001": _i("CODE", "ROUTE FEEDBACK"), "RENDER-001": _i("CODE", "FRAME EVID"),
    "SKELETON-001": _i("CODE", "ROUTE EXEC"), "FRAMEWORK-001": _i("CODE", "FEEDBACK"),
})
_DISC = {
    "DISC-SOP-001": "ruled: shared preflight segment, no standalone SOP", "DISC-SOP-002": "ruled: ADR only for architecture/governance/vocabulary/authority",
    "DISC-SOP-003": "ruled: stdlib scripts primary, manual checklist secondary", "DISC-SOP-005": "ruled: L3 needs user approval + logical review",
    "DISC-SOP-006": "ruled: FAST default; full scan only L3/authority/protected/critical UNKNOWN",
    "DISC-SOP-007": "ruled: propose+sandbox-test automatic; authority writes need user approval",
}
for k, v in _DISC.items():
    FUNCTIONS[k] = _i("PROCESS", "POL" if k == "DISC-SOP-007" else "", v + " (B13, by delegation)")
FUNCTIONS["DISC-SOP-004"] = _i("CODE", "BASE", "ruled: harness rubric + sample kinds formally adopted (B13)")

FLOWS: dict[str, Item] = {
    "F0": _i("CODE", "TASK POL"), "F1": _i("CODE", "FRAME"), "F2": _i("CODE", "EVID CRIT_UNK"),
    "F3": _i("CODE", "ROUTE RETRY"), "F4": _i("CODE", "POL CANCEL EXEC RUNREC"), "F5": _i("CODE", "UNK BRANCH FEEDBACK"),
    "F6": _i("CODE", "BUNDLE HANDOFF", "GitHub writeback is manual"),
    "F7": _i("CODE", "FEEDBACK BASE", "real C0/C1/C2 evaluation NOT_EXECUTED"),
    "N01": _i("CODE", "TASK"), "N02": _i("SLOT", "FRAME"), "N03": _i("SLOT", "FRAME"), "N04": _i("SLOT", "EVID"),
    "N05": _i("CODE", "EVID"), "N06": _i("CODE", "CRIT_UNK CONFLICT"), "N07": _i("SLOT", "EVID"), "N08": _i("SLOT", "EVID"),
    "N09": _i("CODE", "RETRY", "discriminating_change recognised as retry justification"), "N10": _i("CODE", "TASK FAST"),
    "N11": _i("CODE", "ROUTE"), "N12": _i("CODE", "RETRY"), "N13": _i("CODE", "EXEC"), "N14": _i("CODE", "BUNDLE"),
    "N15": _i("SLOT", "FEEDBACK"), "N16": _i("CODE", "UNK EVID"), "N17": _i("CODE", "CORR BRANCH"),
    "N18": _i("CODE", "FEEDBACK BUNDLE HANDOFF"),
    "A1": _i("CODE", "FRAME TASK"), "A2": _i("CODE", "EVID"), "A3": _i("SLOT", "EVID"), "A4": _i("CODE", "ROUTE RETRY"),
    "A5": _i("CODE", "EXEC RUNREC"), "A6": _i("CODE", "UNK BRANCH CORR FEEDBACK"),
    "TASKFLOW:INTAKE": _i("CODE", "TASK"), "TASKFLOW:AUTHORIZE": _i("CODE", "POL"),
    "TASKFLOW:SELECT_SOP": _i("SLOT", "ROUTE"), "TASKFLOW:PLAN": _i("SLOT", "ROUTE"),
    "TASKFLOW:EXECUTE": _i("CODE", "EXEC RUNREC"), "TASKFLOW:VERIFY": _i("CODE", "UNK EVID"),
    "TASKFLOW:PERSIST": _i("CODE", "BUNDLE TXN", "persist_checkpoint: bundle+handoff written as one transaction"), "TASKFLOW:REVIEW": _i("PROCESS", "BASE", "independent review is manual"),
    "STAGE:PLANNING": _i("PROCESS", "CORR", "impact planning automated; plan authoring manual"),
    "STAGE:REALIZATION": _i("CODE", "CONSIST"), "STAGE:CLOSURE": _i("CODE", "CONSIST"),
    "STAGE:FINAL_TEST": _i("CODE", "BASE", "harness only; real run is batch 4 (FINAL_TEST), NOT_EXECUTED"),
}

_NOTES = {
    "PR-034": "single authority order in operating_contract; checker catches listing drift only",
    "PR-035": "topic routing by index.json id_lookup; manual placement",
    "PR-047": "format/readability is editorial review",
    "P2-F26": "batch update + one manual integration acceptance (build_stage_flow)",
    "P2-F27": "presentation chosen per reader/purpose (VIEW-010)",
    "CF-004": "dialog -> traceable doc via handoff template; manual",
    "CF-006": "version governance & backup rotation: SOP in archive (registry source_status); manual, zip chain as backup",
    "CF-007": "axis consolidation and length split: editorial SOP",
    "CF-009": "SOP fixed-flow evolution: SOP-META-001 procedure",
    "CF-010": "SOP creation/dialog distillation: SOP-DOC-001 procedure",
    "SOP-CAND-005": "pre-scan of intent/duties/conflicts: preflight checklist; gate+consistency checker partly automate",
    "SOP-META-001": "SOP lifecycle procedure; owner-governed",
    "SOP-DOC-001": "SOP document standard fields; template-driven",
    "VIEW-002": "human HUD/panel in markdown: generated on demand by tools/coverage.py --md",
    "VIEW-004": "tree/relationship diagrams drawn on request from index.json",
    "VIEW-007": "SOP/problem-fix/new-feature routing tags: applied by reviewer",
    "VIEW-010": "adaptive presentation: reviewer/agent judgement",
    "VIEW-011": "capability adopt/merge/replace/retire decision procedure; owner-governed",
}
for _k, _n in _NOTES.items():
    for _t in (PROBLEMS, FUNCTIONS, FLOWS):
        if _k in _t:
            _t[_k] = (_t[_k][0], _t[_k][1], _n)


def _read(root: str, rel: str) -> str:
    try:
        with open(os.path.join(root, rel), encoding="utf-8") as fh:
            return fh.read()
    except OSError:
        return ""


def expected_ids(root: str) -> dict[str, set[str]]:
    reg = json.loads(_read(root, "docs/capability_registry.json") or "{}")
    prob = json.loads(_read(root, "docs/problem_register.json") or "{}")
    bp = json.loads(_read(root, "docs/blueprint.json") or "{}")
    oc = json.loads(_read(root, "docs/operating_contract.json") or "{}")
    arch = bp.get("architecture", {})
    flows = {x["id"] for k in ("axes", "skeleton_nodes", "conditional_framework") for x in arch.get(k, [])}
    flows |= {f"TASKFLOW:{s}" for s in oc.get("task_flow", [])}
    flows |= {f"STAGE:{s['stage']}" for s in oc.get("build_stage_flow", [])}
    cap = {i["id"] for i in reg.get("items", [])}
    return {"problems": {i["id"] for i in prob.get("items", [])}, "functions": cap - {i["id"] for i in prob.get("items", [])},
            "flows": flows}


def check(root: str) -> dict[str, Any]:
    exp = expected_ids(root)
    maps = {"problems": PROBLEMS, "functions": FUNCTIONS, "flows": FLOWS}
    errors: list[str] = []
    levels: dict[str, Counter] = {}
    for kind, table in maps.items():
        missing = sorted(exp[kind] - set(table))
        extra = sorted(set(table) - exp[kind])
        if missing:
            errors.append(f"{kind}: unhandled/unmapped ids {missing}")
        if extra:
            errors.append(f"{kind}: map has ids not in source {extra}")
        levels[kind] = Counter(v[0] for v in table.values())
        for id_, (lvl, mechs, note) in table.items():
            if lvl not in LEVELS or lvl == "GAP":
                errors.append(f"{id_}: level {lvl}")
            if lvl in ("CODE", "SLOT") and not mechs:
                errors.append(f"{id_}: {lvl} needs a mechanism")
            if lvl == "PROCESS" and not note:
                errors.append(f"{id_}: PROCESS needs a note on the procedure")
            for m in mechs:
                if m not in MECH:
                    errors.append(f"{id_}: unknown mechanism {m}")
    for name, (src, sym, test) in MECH.items():
        if sym.removeprefix("def ") not in _read(root, src):
            errors.append(f"mechanism {name}: symbol '{sym}' not found in {src}")
        if not _read(root, test):
            errors.append(f"mechanism {name}: test file {test} missing")
    return {"errors": errors, "levels": {k: dict(v) for k, v in levels.items()},
            "totals": {k: len(v) for k, v in maps.items()}}


def to_markdown(root: str) -> str:
    out = ["# forAVAr 覆蓋清冊（問題／功能／流程）", "",
           "CODE＝程式強制且有測試；SLOT＝執行階段有契約入口、內容由 adapter 提供（未驗證）；PROCESS＝靠流程手動處理；DECISION＝待決策。", ""]
    titles = {}
    try:
        for i in json.loads(_read(root, "docs/problem_register.json"))["items"]:
            titles[i["id"]] = i["title"]
        for i in json.loads(_read(root, "docs/capability_registry.json"))["items"]:
            titles.setdefault(i["id"], i["name"])
    except (ValueError, KeyError):
        pass
    for kind, table in (("問題清單", PROBLEMS), ("功能清單", FUNCTIONS), ("流程清單", FLOWS)):
        out += [f"## {kind}（{len(table)}）", "", "| ID | 名稱 | 層級 | 處理機制 | 限制／說明 |", "|---|---|---|---|---|"]
        for id_, (lvl, mechs, note) in table.items():
            out.append(f"| {id_} | {titles.get(id_, '')[:28]} | {lvl} | {' '.join(mechs)} | {note} |")
        out.append("")
    return "\n".join(out)


# B16/B17: SLOT items whose stage now has a model-adapter template pack get the ADAPT mechanism (level stays SLOT).
for _t in (FUNCTIONS, FLOWS, PROBLEMS):
    for _k, (_lvl, _m, _n) in list(_t.items()):
        if _lvl == "SLOT" and set(_m) & {"FRAME", "EVID", "ROUTE", "FEEDBACK", "PLUGIN"} and "ADAPT" not in _m:
            _t[_k] = (_lvl, _m + ["ADAPT"], _n)


if __name__ == "__main__":
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    repo = args[0] if args and not args[0].endswith(".md") else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    if "--md" in sys.argv:
        dest = sys.argv[sys.argv.index("--md") + 1]
        with open(dest, "w", encoding="utf-8") as fh:
            fh.write(to_markdown(repo))
    rep = check(repo)
    print(json.dumps(rep, ensure_ascii=False, indent=2))
    sys.exit(1 if rep["errors"] else 0)
