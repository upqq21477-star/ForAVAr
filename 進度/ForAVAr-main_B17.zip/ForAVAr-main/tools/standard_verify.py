"""Standard verify callback for release_txn.apply_transaction (one end-of-batch gate).

``verify(root)`` runs the unit tests and the two checkers; returns a list of problems
(empty = compatible). Commands are injectable so the callback itself is testable.
Usage: python tools/standard_verify.py [repo_root]
"""
from __future__ import annotations

import os
import subprocess
import sys

DEFAULT_CMDS = (
    [sys.executable, "-m", "unittest", "discover", "-s", "tests"],
    [sys.executable, "tools/check_consistency.py"],
    [sys.executable, "tools/coverage.py"],
)


def verify(root: str, cmds=DEFAULT_CMDS) -> list[str]:
    problems: list[str] = []
    for cmd in cmds:
        r = subprocess.run(list(cmd), cwd=root, capture_output=True, text=True)
        if r.returncode:
            problems.append(f"{' '.join(cmd[1:])}: {(r.stdout + r.stderr)[-500:]}")
    return problems


if __name__ == "__main__":
    repo = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
    out = verify(repo)
    print("\n".join(out) or "OK")
    sys.exit(1 if out else 0)
