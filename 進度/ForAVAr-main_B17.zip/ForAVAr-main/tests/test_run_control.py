"""Tests for runtime/run_record.py, runtime/retry_policy.py and their slice integration."""
from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
sys.path.insert(0, os.path.dirname(__file__))

from run_record import RUN_RECORD_FIELDS, build_run_record, fingerprint, run_record_required  # noqa: E402
from retry_policy import RetryPolicyError, decide_retry  # noqa: E402
from test_runtime_contract import HIGH, LOW, TID, full_exec, obs, run, task  # noqa: E402

CLOCK = lambda: "2026-10-24T00:00:00+00:00"  # noqa: E731


class RunRecordTests(unittest.TestCase):
    def test_fingerprint_is_canonical(self):
        self.assertEqual(fingerprint({"a": 1, "b": [2]}), fingerprint({"b": [2], "a": 1}))
        self.assertNotEqual(fingerprint({"a": 1}), fingerprint({"a": 2}))

    def test_complete_record_has_all_blueprint_fields(self):
        rec = build_run_record(TID, {**full_exec(0, 0, 0, 0), "evidence_records": [obs("E9")]},
                               result_status="EXECUTED", required=True, clock=CLOCK)
        for f in RUN_RECORD_FIELDS:
            self.assertIn(f, rec)
        self.assertTrue(rec["complete"])
        self.assertEqual(rec["missing"], [])
        self.assertEqual((rec["run_id"], rec["evidence_ids"]), ("X1", ["E9"]))
        self.assertEqual((rec["timestamp"], rec["timestamp_source"]), (CLOCK(), "RUNTIME_CLOCK"))

    def test_fingerprint_depends_on_result_and_evidence_not_on_order(self):
        a = build_run_record(TID, {**full_exec(0, 0, 0, 0), "evidence_records": [obs("E1"), obs("E2")]},
                             result_status="EXECUTED", required=False, clock=CLOCK)
        b = build_run_record(TID, {**full_exec(0, 0, 0, 0), "evidence_records": [obs("E2"), obs("E1")]},
                             result_status="EXECUTED", required=False, clock=CLOCK)
        c = build_run_record(TID, {**full_exec(0, 0, 0, 0), "result_summary": "different"},
                             result_status="EXECUTED", required=False, clock=CLOCK)
        self.assertEqual(a["output_fingerprint"], b["output_fingerprint"])
        self.assertNotEqual(a["output_fingerprint"], c["output_fingerprint"])

    def test_missing_fields_are_none_and_listed_never_fabricated(self):
        rec = build_run_record(TID, {"execution_id": "X1", "result_summary": "ok"},
                               result_status="EXECUTED", required=True, clock=CLOCK)
        self.assertFalse(rec["complete"])
        self.assertEqual(sorted(rec["missing"]), ["environment", "exit_status", "target_version", "tool_or_command"])
        self.assertIsNone(rec["exit_status"])

    def test_adapter_timestamp_wins_and_bool_exit_status_rejected(self):
        rec = build_run_record(TID, {**full_exec(0, 0, 0, 0), "timestamp": "T0", "exit_status": True},
                               result_status="EXECUTED", required=False, clock=CLOCK)
        self.assertEqual((rec["timestamp"], rec["timestamp_source"]), ("T0", "ADAPTER"))
        self.assertIsNone(rec["exit_status"])

    def test_no_execution_means_no_fingerprint(self):
        rec = build_run_record(TID, None, result_status="TIMEOUT_UNKNOWN_SIDE_EFFECT", required=True, clock=CLOCK)
        self.assertIsNone(rec["output_fingerprint"])
        self.assertFalse(rec["complete"])

    def test_required_rule(self):
        crit_plain = [{"id": "C1", "required_evidence_kinds": ["SOURCE_OBSERVATION"]}]
        crit_exec = [{"id": "C1", "required_evidence_kinds": ["PROGRAM_TEST"]}]
        self.assertFalse(run_record_required(LOW, crit_plain))
        self.assertTrue(run_record_required(LOW, crit_exec))
        self.assertTrue(run_record_required(HIGH, crit_plain))
        self.assertTrue(run_record_required({"risk_level": "LOW"}, crit_plain))  # side effects unknown


class SliceIntegrationTests(unittest.TestCase):
    def _high(self, execute):
        r = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                             "selected_method": "m", "reason": "r", "stop_rule": "s",
                             "requires_authorization": True, "required_scope": ["w"]}
        g = lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A",  # noqa: E731
                          "authorized_scope": ["w"]}
        ev = lambda t, f: {"task_id": TID, "status": "READY", "records": [obs()], "critical_unknowns": []}  # noqa: E731
        return run(task({**HIGH}), route=r, authorize=g, evidence=ev, execute=execute)

    def test_required_but_incomplete_receipt_downgrades_pass_to_partial(self):
        out, _ = self._high(lambda t, f, e, r: {"task_id": TID, "status": "EXECUTED",
                                                 "execution_id": "X", "result_summary": "ok"})
        self.assertEqual(out["status"], "PARTIAL")
        self.assertIn("run_record incomplete", out["feedback"]["reason"])
        self.assertFalse(out["run_record"]["complete"])

    def test_complete_receipt_keeps_pass(self):
        out, _ = self._high(full_exec)
        self.assertEqual(out["status"], "PASS")

    def test_not_required_incomplete_receipt_does_not_downgrade(self):
        out, _ = run()  # LOW profile, plain criteria
        self.assertFalse(out["run_record"]["required"])

    def test_failed_and_timeout_keep_receipt(self):
        out, _ = run(execute=lambda t, f, e, r: {"task_id": TID, "status": "FAILED", "execution_id": "X"})
        self.assertEqual(out["run_record"]["result_status"], "FAILED")

        def boom(t, f, e, r):
            raise TimeoutError("slow")
        out, _ = run(execute=boom)
        self.assertEqual(out["run_record"]["result_status"], "TIMEOUT_UNKNOWN_SIDE_EFFECT")

    def test_not_run_has_no_receipt(self):
        out, _ = run(execute=lambda t, f, e, r: {"task_id": TID, "status": "NOT_RUN"})
        self.assertNotIn("run_record", out)


def attempt(**kw):
    return {"method": "m1", "target": "t1", "input_fingerprint": "f1", "new_evidence_ids": [], **kw}


class RetryPolicyTests(unittest.TestCase):
    B = {"max_attempts": 3}

    def test_requires_explicit_bound(self):
        for bad in ({}, {"max_attempts": 0}, {"max_attempts": True}, {"max_attempts": "3"},
                    {"max_attempts": 2, "max_cost": -1}):
            with self.assertRaises(RetryPolicyError):
                decide_retry([], {}, bad)

    def test_first_attempt_allowed(self):
        self.assertEqual(decide_retry([], attempt(), self.B)["decision"], "RETRY")

    def test_same_input_and_method_stops(self):
        out = decide_retry([attempt()], attempt(), self.B)
        self.assertEqual((out["decision"], out["stop_condition"]), ("STOP", "NO_NEW_INFORMATION"))
        self.assertEqual(out["failure_class"], "COST_OR_STOP_ERROR")

    def test_each_justification_allows_retry(self):
        h = [attempt(new_evidence_ids=["E1"])]
        cases = {
            "NEW_EVIDENCE": attempt(new_evidence_ids=["E2"]),
            "DISCRIMINATING_CHANGE": attempt(discriminating_change=True),
            "DIFFERENT_METHOD": attempt(method="m2"),
            "CHANGED_TARGET": attempt(target="t2"),
        }
        for want, prop in cases.items():
            out = decide_retry(h, prop, self.B)
            self.assertEqual(out["decision"], "RETRY", want)
            self.assertIn(want, out["justification"])

    def test_already_seen_evidence_is_not_new(self):
        out = decide_retry([attempt(new_evidence_ids=["E1"])], attempt(new_evidence_ids=["E1"]), self.B)
        self.assertEqual(out["stop_condition"], "NO_NEW_INFORMATION")

    def test_attempt_and_cost_budget(self):
        h = [attempt(), attempt(method="m2"), attempt(method="m3")]
        out = decide_retry(h, attempt(method="m4"), self.B)
        self.assertEqual((out["stop_condition"], out["failure_class"]), ("BUDGET_EXHAUSTED", "COST_OR_STOP_ERROR"))
        out = decide_retry([attempt()], attempt(method="m2"), {"max_attempts": 5, "max_cost": 10, "spent_cost": 10})
        self.assertEqual(out["stop_condition"], "BUDGET_EXHAUSTED")

    def test_flags_stop_before_budget_checks(self):
        h = [attempt()]
        p = attempt(method="m2")
        self.assertEqual(decide_retry(h, p, {**self.B, "acceptance_satisfied": True})["stop_condition"], "ACCEPTANCE_SATISFIED")
        out = decide_retry(h, p, {**self.B, "authority_available": False})
        self.assertEqual((out["stop_condition"], out["failure_class"]), ("AUTHORITY_UNAVAILABLE", "AUTHORIZATION_OR_POLICY_BLOCK"))
        self.assertEqual(decide_retry(h, p, {**self.B, "decision_relevant": False})["stop_condition"], "NOT_DECISION_RELEVANT")

    def test_unknown_side_effect_needs_state_inspection_first(self):
        h = [attempt(unknown_side_effect=True)]
        out = decide_retry(h, attempt(method="m2"), self.B)
        self.assertEqual((out["decision"], out["required_action"]), ("STOP", "INSPECT_ACTUAL_STATE_BEFORE_RETRY"))
        out = decide_retry(h, attempt(method="m2", actual_state_read=True), self.B)
        self.assertEqual(out["decision"], "RETRY")
        out = decide_retry([attempt(status="INCONCLUSIVE")], attempt(method="m2"), self.B)
        self.assertEqual(out["decision"], "STOP")
        # inspecting state alone does not justify repeating the identical attempt
        out = decide_retry(h, attempt(actual_state_read=True), self.B)
        self.assertEqual(out["stop_condition"], "NO_NEW_INFORMATION")


if __name__ == "__main__":
    unittest.main()
