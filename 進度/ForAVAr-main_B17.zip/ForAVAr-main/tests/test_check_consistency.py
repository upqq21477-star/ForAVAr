import json
import os
import shutil
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
from check_consistency import check  # noqa: E402


class ConsistencyTests(unittest.TestCase):
    def copy_repo(self):
        d = tempfile.mkdtemp()
        self.addCleanup(shutil.rmtree, d)
        for sub in ("docs", "runtime", "tests"):
            shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub), ignore=shutil.ignore_patterns("__pycache__"))
        shutil.copy(os.path.join(ROOT, "README.md"), d)
        return d

    def test_real_repo_has_no_errors(self):
        r = check(ROOT)
        self.assertEqual(r["errors"], 0, r["findings"])
        self.assertGreater(r["ids_checked"]["capability"], 0)

    def test_detects_duplicate_id_and_count_mismatch(self):
        d = self.copy_repo()
        p = os.path.join(d, "docs", "capability_registry.json")
        with open(p, encoding="utf-8") as fh:
            data = json.load(fh)
        data["items"].append(dict(data["items"][0]))
        with open(p, "w", encoding="utf-8") as fh:
            json.dump(data, fh)
        checks = {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}
        self.assertTrue({"id_unique", "index_counts"} <= checks)

    def test_detects_broken_json_missing_file_and_unlisted_module(self):
        d = self.copy_repo()
        with open(os.path.join(d, "docs", "problem_register.json"), "w") as fh:
            fh.write("{bad")
        os.remove(os.path.join(d, "runtime", "run_record.py"))
        with open(os.path.join(d, "runtime", "extra.py"), "w") as fh:
            fh.write("")
        checks = {x["check"] for x in check(d)["findings"] if x["level"] == "ERROR"}
        self.assertTrue({"json_parse", "local_ref", "readme_listing"} <= checks)

    def test_vocabulary_is_aligned_no_known_deviation(self):
        r = check(ROOT)
        self.assertEqual(r["info"], 0, r["findings"])


if __name__ == "__main__":
    unittest.main()
