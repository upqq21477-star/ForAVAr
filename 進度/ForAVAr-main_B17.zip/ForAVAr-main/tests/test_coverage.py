import os
import sys
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "tools"))
import coverage  # noqa: E402


class CoverageTests(unittest.TestCase):
    def test_every_problem_function_and_flow_is_handled_and_mechanisms_exist(self):
        rep = coverage.check(ROOT)
        self.assertEqual(rep["errors"], [])
        self.assertEqual(rep["totals"], {"problems": 54, "functions": 121, "flows": 44})

    def test_no_gap_level_and_pending_decisions_are_explicit(self):
        for table in (coverage.PROBLEMS, coverage.FUNCTIONS, coverage.FLOWS):
            self.assertNotIn("GAP", {v[0] for v in table.values()})
        decisions = {k for k, v in coverage.FUNCTIONS.items() if v[0] == "DECISION"}
        self.assertEqual(len(decisions), 0)

    def test_missing_id_is_detected(self):
        saved = coverage.PROBLEMS.pop("PR-001")
        try:
            self.assertTrue(any("PR-001" in e for e in coverage.check(ROOT)["errors"]))
        finally:
            coverage.PROBLEMS["PR-001"] = saved

    def test_process_without_note_and_code_without_mechanism_rejected(self):
        saved = coverage.PROBLEMS["PR-017"]
        coverage.PROBLEMS["PR-017"] = ("PROCESS", [], "")
        coverage.PROBLEMS["PR-001"], keep = ("CODE", [], ""), coverage.PROBLEMS["PR-001"]
        try:
            errs = coverage.check(ROOT)["errors"]
            self.assertTrue(any("PR-017" in e for e in errs) and any("PR-001" in e for e in errs))
        finally:
            coverage.PROBLEMS["PR-017"], coverage.PROBLEMS["PR-001"] = saved, keep

    def test_markdown_lists_all_three_inventories(self):
        md = coverage.to_markdown(ROOT)
        for h in ("問題清單（54）", "功能清單（121）", "流程清單（44）"):
            self.assertIn(h, md)


if __name__ == "__main__":
    unittest.main()
