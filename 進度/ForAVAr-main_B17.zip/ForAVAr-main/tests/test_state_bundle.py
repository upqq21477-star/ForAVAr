import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

from state_bundle import (HANDOFF_FIELDS, STATE_CLASSES, StateBundleError, build_bundle,  # noqa: E402
                          export_handoff, handoff_to_markdown, read_bundle, validate_bundle, write_bundle)


class StateBundleTests(unittest.TestCase):
    def test_p0_writes_nothing(self):
        self.assertIsNone(build_bundle("T1", "P0"))
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "x.json")
            self.assertIsNone(write_bundle(None, p))
            self.assertFalse(os.path.exists(p))

    def test_bad_level_and_task_id(self):
        with self.assertRaises(StateBundleError):
            build_bundle("T1", "P9")
        with self.assertRaises(StateBundleError):
            build_bundle(" ", "P1")

    def test_three_classes_separated(self):
        b = build_bundle("T1", "P1", task_state={"status": "PARTIAL"}, evidence_state={"evidence_links": ["e1"]})
        for c in STATE_CLASSES:
            self.assertIn(c, b)
        self.assertEqual(b["LONG_TERM_RULE_MEMORY"]["access"], "READ_ONLY")
        self.assertNotIn("evidence_links", b["TASK_EXECUTION_STATE"])

    def test_p1_rejects_p2_only_keys_p2_accepts(self):
        with self.assertRaises(StateBundleError):
            build_bundle("T1", "P1", task_state={"next_action": "x"})
        b = build_bundle("T1", "P2", task_state={"next_action": "x", "run_records": []})
        self.assertEqual(b["level"], "P2")

    def test_roundtrip_identical(self):
        b = build_bundle("T1", "P2", task_state={"status": "PASS", "key_decisions": ["d1"], "next_action": "n"},
                         evidence_state={"verified_results": ["39/39"]}, rule_memory_refs=["docs/blueprint.json"])
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "sub", "b.json")
            write_bundle(b, p)
            back = read_bundle(p)
            self.assertEqual(back["task_id"], "T1")
            self.assertEqual(back["TASK_EXECUTION_STATE"]["key_decisions"], ("d1",))
            self.assertEqual(back["CLAIM_EVIDENCE_STATE"]["verified_results"], ("39/39",))

    def test_read_view_is_immutable(self):
        b = build_bundle("T1", "P1", task_state={"status": "PASS"})
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "b.json")
            write_bundle(b, p)
            back = read_bundle(p)
            with self.assertRaises(TypeError):
                back["LONG_TERM_RULE_MEMORY"]["refs"] = []
            with self.assertRaises(TypeError):
                back["TASK_EXECUTION_STATE"]["status"] = "X"

    def test_write_refuses_authority_paths(self):
        b = build_bundle("T1", "P1")
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(StateBundleError):
                write_bundle(b, os.path.join(d, "docs", "b.json"))
            with self.assertRaises(StateBundleError):
                write_bundle(b, os.path.join(d, "blueprint.json"))

    def test_validate_catches_tampered_memory_access(self):
        b = build_bundle("T1", "P1")
        b["LONG_TERM_RULE_MEMORY"]["access"] = "READ_WRITE"
        self.assertTrue(validate_bundle(b))
        with tempfile.TemporaryDirectory() as d:
            with self.assertRaises(StateBundleError):
                write_bundle(b, os.path.join(d, "b.json"))

    def test_handoff_export_fields_exact_and_not_invented(self):
        h = export_handoff({"task_id": "T1", "goal": "g"})
        for f in HANDOFF_FIELDS:
            self.assertIn(f, h)
        self.assertEqual(h["acceptance"], "NOT_PROVIDED")
        self.assertIn("PROVISIONAL", h["handoff_status"])
        with self.assertRaises(StateBundleError):
            export_handoff({"bogus": 1})
        self.assertIn("## goal", handoff_to_markdown(h))


if __name__ == "__main__":
    unittest.main()
