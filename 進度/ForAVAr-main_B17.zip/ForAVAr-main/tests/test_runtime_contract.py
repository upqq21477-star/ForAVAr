"""Contract tests for runtime/policy_gate.py and runtime/foravar_vertical_slice.py.

Run from repo root:  python -m unittest discover -s tests -v
Stdlib only. Adapters are in-memory fakes; no network, no filesystem writes.
"""
from __future__ import annotations

import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

from policy_gate import authorization_required, evaluate_authorization  # noqa: E402
from foravar_vertical_slice import ContractError, run_vertical_slice  # noqa: E402

TID = "T-1"
LOW = {
    "risk_level": "LOW",
    "requires_external_evidence": False,
    "requires_diagnostic": False,
    "has_source_conflict": False,
    "has_critical_unknowns": False,
    "side_effects": False,
}
HIGH = {**LOW, "risk_level": "HIGH", "side_effects": True}


def obs(eid="E1", kind="SOURCE_OBSERVATION", **kw):
    base = {"evidence_id": eid, "kind": kind, "status": "OBSERVED",
            "target_revision": "r1", "observed_at": "2026-10-24", "summary": "s"}
    base.update(kw)
    return base


def task(profile=None, criteria=None):
    return {
        "task_id": TID, "goal": "g", "profile": dict(profile or LOW),
        "acceptance_criteria": criteria if criteria is not None else [
            {"id": "C1", "description": "d", "required_evidence_kinds": ["SOURCE_OBSERVATION"]}],
    }


def make_adapters(**over):
    calls = []

    def frame(t):
        calls.append("frame")
        return {"task_id": TID, "status": "READY", "frame_id": "F1", "problem_statement": "p",
                "in_scope": [], "out_of_scope": [], "unknowns": []}

    def evidence(t, f):
        calls.append("evidence")
        return {"task_id": TID, "status": "READY", "records": [obs()], "critical_unknowns": []}

    def route(t, f, e):
        calls.append("route")
        return {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m1"],
                "selected_method": "m1", "reason": "r", "stop_rule": "s",
                "requires_authorization": False, "required_scope": []}

    def execute(t, f, e, r):
        calls.append("execute")
        return {"task_id": TID, "status": "EXECUTED", "execution_id": "X1", "result_summary": "ok"}

    def evaluate(t, x, e):
        calls.append("evaluate")
        return {"task_id": TID, "criteria_results": [
            {"criterion_id": "C1", "status": "PASS", "evidence_ids": ["E1"]}]}

    ad = {"frame": frame, "evidence": evidence, "route": route, "execute": execute, "evaluate": evaluate}
    ad.update(over)
    ad["_calls"] = calls
    return ad


def full_exec(t, f, e, r):
    """Execution result carrying every RunRecord field the adapter must supply."""
    return {"task_id": TID, "status": "EXECUTED", "execution_id": "X1", "result_summary": "ok",
            "target_version": "r1", "tool_or_command": "cmd", "exit_status": 0, "environment": "env"}


def run(t=None, **over):
    ad = make_adapters(**over)
    calls = ad.pop("_calls")
    return run_vertical_slice(t or task(), ad), calls


class PolicyGateTests(unittest.TestCase):
    def ev(self, profile, route, adapters=None):
        return evaluate_authorization({"task_id": TID}, profile, route, adapters or {})

    def test_required_matrix(self):
        self.assertFalse(authorization_required(LOW, {}))
        self.assertTrue(authorization_required(HIGH, {}))
        self.assertTrue(authorization_required({"risk_level": "LOW"}, {}))  # side_effects unknown
        self.assertTrue(authorization_required({"side_effects": False}, {}))  # risk unknown
        self.assertTrue(authorization_required(LOW, {"requires_authorization": True}))

    def test_not_required(self):
        self.assertEqual(self.ev(LOW, {})["status"], "NOT_REQUIRED")

    def test_bad_scope_type_blocks(self):
        self.assertEqual(self.ev(LOW, {"required_scope": "x"})["status"], "BLOCKED")
        self.assertEqual(self.ev(LOW, {"required_scope": [" "]})["status"], "BLOCKED")

    def test_empty_scope_blocks_when_required(self):
        self.assertEqual(self.ev(HIGH, {"required_scope": []})["status"], "BLOCKED")

    def test_missing_adapter_blocks(self):
        self.assertEqual(self.ev(HIGH, {"required_scope": ["w"]})["status"], "BLOCKED")

    def test_adapter_exception_blocks(self):
        def boom(t, r):
            raise RuntimeError("x")
        self.assertEqual(self.ev(HIGH, {"required_scope": ["w"]}, {"authorize": boom})["status"], "BLOCKED")

    def test_non_mapping_blocks(self):
        self.assertEqual(self.ev(HIGH, {"required_scope": ["w"]}, {"authorize": lambda t, r: "yes"})["status"], "BLOCKED")

    def test_task_mismatch_blocks(self):
        g = {"task_id": "OTHER", "status": "AUTHORIZED", "authorization_id": "A", "authorized_scope": ["w"]}
        self.assertEqual(self.ev(HIGH, {"required_scope": ["w"]}, {"authorize": lambda t, r: g})["status"], "BLOCKED")

    def test_denied_status_blocks(self):
        g = {"task_id": TID, "status": "DENIED", "reason": "no"}
        out = self.ev(HIGH, {"required_scope": ["w"]}, {"authorize": lambda t, r: g})
        self.assertEqual((out["status"], out["reason"]), ("BLOCKED", "no"))

    def test_missing_authorization_id_blocks(self):
        g = {"task_id": TID, "status": "AUTHORIZED", "authorized_scope": ["w"]}
        self.assertEqual(self.ev(HIGH, {"required_scope": ["w"]}, {"authorize": lambda t, r: g})["status"], "BLOCKED")

    def test_bad_granted_scope_blocks(self):
        g = {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A", "authorized_scope": "w"}
        self.assertEqual(self.ev(HIGH, {"required_scope": ["w"]}, {"authorize": lambda t, r: g})["status"], "BLOCKED")

    def test_partial_scope_blocks(self):
        g = {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A", "authorized_scope": ["r"]}
        out = self.ev(HIGH, {"required_scope": ["r", "w"]}, {"authorize": lambda t, r: g})
        self.assertEqual((out["status"], out["missing_scope"]), ("BLOCKED", ["w"]))

    def test_full_scope_authorizes(self):
        g = {"task_id": TID, "status": "AUTHORIZED", "authorization_id": " A ", "authorized_scope": ["w", "r", "x"]}
        out = self.ev(HIGH, {"required_scope": ["r", "w"]}, {"authorize": lambda t, r: g})
        self.assertEqual((out["status"], out["authorization_id"]), ("AUTHORIZED", "A"))


class VerticalSliceTests(unittest.TestCase):
    def test_fast_path_accepted_when_execution_supplies_evidence(self):
        out, calls = run(execute=lambda t, f, e, r: {
            "task_id": TID, "status": "EXECUTED", "execution_id": "X1", "result_summary": "ok",
            "evidence_records": [obs()]})
        self.assertEqual(out["status"], "PASS")
        self.assertNotIn("evidence", calls)  # short circuit
        self.assertIn("EVIDENCE_SHORT_CIRCUIT", out["trace"])
        self.assertIn("AUTHORIZATION_NOT_REQUIRED", out["trace"])

    def test_fast_path_pass_without_any_evidence_is_not_proven(self):
        out, _ = run()  # short-circuit yields no records; PASS cannot be linked
        self.assertEqual(out["status"], "NOT_PROVEN")
        self.assertEqual(out["acceptance"]["criteria_results"][0]["status"], "UNKNOWN")

    def test_full_path_accepted_with_evidence(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, calls = run(t)
        self.assertEqual(out["status"], "PASS")
        self.assertIn("evidence", calls)
        self.assertEqual(out["feedback"]["action"], "CLOSE")

    def test_frame_blocked_and_not_ready(self):
        out, calls = run(frame=lambda t: {"task_id": TID, "status": "BLOCKED", "reason": "x"})
        self.assertEqual(out["status"], "BLOCKED")
        self.assertNotIn("execute", calls)
        out, _ = run(frame=lambda t: {"task_id": TID, "status": "AMBIGUOUS"})
        self.assertEqual(out["status"], "NOT_PROVEN")

    def test_evidence_blocked(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, calls = run(t, evidence=lambda t, f: {"task_id": TID, "status": "BLOCKED", "records": []})
        self.assertEqual(out["status"], "BLOCKED")
        self.assertNotIn("execute", calls)

    def test_critical_unknown_blocks_high_risk(self):
        t = task({**HIGH})
        out, calls = run(t, evidence=lambda t, f: {"task_id": TID, "status": "PARTIAL", "records": [], "critical_unknowns": ["u"]})
        self.assertEqual(out["status"], "BLOCKED")
        self.assertNotIn("execute", calls)

    def test_route_terminal_status(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, calls = run(t, route=lambda t, f, e: {"task_id": TID, "status": "REJECTED", "reason": "nope"})
        self.assertEqual(out["status"], "REJECTED")  # F5 branch: no feasible solution
        self.assertEqual(out["feedback"]["action"], "REJECT_WITH_REASON")
        self.assertNotIn("execute", calls)

    def test_high_risk_without_authorize_adapter_never_executes(self):
        r = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                             "selected_method": "m", "reason": "r", "stop_rule": "s",
                             "requires_authorization": True, "required_scope": ["write"]}
        out, calls = run(task({**HIGH}), route=r,
                         evidence=lambda t, f: {"task_id": TID, "status": "READY", "records": [], "critical_unknowns": []})
        self.assertEqual(out["status"], "BLOCKED")
        self.assertNotIn("execute", calls)
        self.assertIn("AUTHORIZATION", out["trace"])

    def test_high_risk_with_grant_executes(self):
        r = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                             "selected_method": "m", "reason": "r", "stop_rule": "s",
                             "requires_authorization": True, "required_scope": ["write"]}
        grant = lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A1",  # noqa: E731
                              "authorized_scope": ["write"]}
        out, calls = run(task({**HIGH}), route=r, authorize=grant, execute=full_exec,
                         evidence=lambda t, f: {"task_id": TID, "status": "READY", "records": [obs()], "critical_unknowns": []})
        self.assertEqual(out["status"], "PASS")
        self.assertTrue(out["run_record"]["complete"])

    def test_route_contract_errors(self):
        t = task({**LOW, "requires_external_evidence": True})
        bad = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["a"],  # noqa: E731
                               "selected_method": "b", "reason": "r", "stop_rule": "s",
                               "requires_authorization": False}
        with self.assertRaises(ContractError):
            run(t, route=bad)

    def test_execution_failures(self):
        for st, want in (("FAILED", "FAILED"), ("BLOCKED", "BLOCKED"), ("NOT_RUN", "NOT_EXECUTED")):
            out, _ = run(execute=lambda t, f, e, r, st=st: {"task_id": TID, "status": st})
            self.assertEqual(out["status"], want)

    def test_evaluate_fail_and_failure_class_feedback(self):
        ev = lambda t, x, e: {"task_id": TID, "failure_class": "METHOD_FAILURE", "reason": "m",  # noqa: E731
                              "criteria_results": [{"criterion_id": "C1", "status": "FAIL", "evidence_ids": ["E1"]}]}
        t = task({**LOW, "requires_external_evidence": True})
        out, _ = run(t, evaluate=ev)
        self.assertEqual(out["status"], "FAILED")
        self.assertEqual(out["feedback"]["action"], "REROUTE_METHOD")
        # legacy key: failure_class carried the repair branch
        self.assertEqual((out["acceptance"]["failure_branch"], out["acceptance"]["failure_class"]), ("METHOD_FAILURE", None))

    def test_missing_criterion_result_is_not_run(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, _ = run(t, evaluate=lambda t, x, e: {"task_id": TID, "criteria_results": []})
        self.assertEqual(out["status"], "NOT_PROVEN")
        self.assertEqual(out["acceptance"]["criteria_results"][0]["status"], "NOT_RUN")

    def test_pass_without_required_kind_downgraded(self):
        t = task({**LOW, "requires_external_evidence": True},
                 [{"id": "C1", "description": "d", "required_evidence_kinds": ["PROGRAM_TEST"]}])
        out, _ = run(t)  # only SOURCE_OBSERVATION evidence available
        self.assertEqual(out["status"], "NOT_PROVEN")

    def test_unobserved_evidence_does_not_count(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, _ = run(t, evidence=lambda t, f: {"task_id": TID, "status": "READY",
                                               "records": [obs(status="DECLARED")], "critical_unknowns": []})
        self.assertEqual(out["status"], "NOT_PROVEN")

    def test_partial_execution_gives_partial(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, _ = run(t, execute=lambda t, f, e, r: {"task_id": TID, "status": "PARTIAL",
                                                    "execution_id": "X", "result_summary": "half"})
        self.assertEqual(out["status"], "PARTIAL")

    def test_task_id_mismatch_raises(self):
        with self.assertRaises(ContractError):
            run(frame=lambda t: {"task_id": "OTHER", "status": "READY"})

    def test_task_validation_errors(self):
        dup = task(criteria=[{"id": "C1", "description": "d"}, {"id": "C1", "description": "d"}])
        for bad in (dup, task(criteria=[]), {**task(), "goal": ""},
                    task(profile={**LOW, "risk_level": "EXTREME"}),
                    task(criteria=[{"id": "C1", "description": "d", "required_evidence_kinds": ["VIBES"]}]),
                    task(profile={**LOW, "side_effects": "no"})):
            with self.assertRaises(ContractError):
                run_vertical_slice(bad, make_adapters())

    def test_runtime_evidence_requires_run_fields(self):
        t = task({**LOW, "requires_external_evidence": True})
        bad = obs("E1", "RUNTIME_OBSERVATION")  # no run_id/command/exit_code
        with self.assertRaises(ContractError):
            run(t, evidence=lambda t, f: {"task_id": TID, "status": "READY", "records": [bad], "critical_unknowns": []})

    def test_runtime_observation_flag(self):
        t = task({**LOW, "requires_external_evidence": True},
                 [{"id": "C1", "description": "d", "required_evidence_kinds": ["RUNTIME_OBSERVATION"]}])
        rec = obs("E1", "RUNTIME_OBSERVATION", run_id="r", command="c", exit_code=0,
                  environment="env", output_digest="d")
        out, _ = run(t, execute=full_exec,
                     evidence=lambda t, f: {"task_id": TID, "status": "READY", "records": [rec], "critical_unknowns": []})
        self.assertEqual(out["status"], "PASS")
        self.assertTrue(out["runtime_observation_present"])

    def test_duplicate_evidence_id_raises(self):
        t = task({**LOW, "requires_external_evidence": True})
        with self.assertRaises(ContractError):
            run(t, evidence=lambda t, f: {"task_id": TID, "status": "READY",
                                          "records": [obs(), obs()], "critical_unknowns": []})

    def _fail_eval(self, **extra):
        return lambda t, x, e: {"task_id": TID, "reason": "m", **extra,
                                "criteria_results": [{"criterion_id": "C1", "status": "FAIL", "evidence_ids": ["E1"]}]}

    def test_branch_and_class_are_independent(self):
        t = task({**LOW, "requires_external_evidence": True})
        out, _ = run(t, evaluate=self._fail_eval(failure_branch="FRAME_FAILURE", failure_class="GOAL_OR_SEMANTIC_ERROR"))
        self.assertEqual(out["feedback"]["action"], "REFRAME_PROBLEM")
        self.assertEqual(out["acceptance"]["failure_class"], "GOAL_OR_SEMANTIC_ERROR")

    def test_invalid_failure_class_or_branch_raises(self):
        t = task({**LOW, "requires_external_evidence": True})
        with self.assertRaises(ContractError):
            run(t, evaluate=self._fail_eval(failure_class="VIBES"))
        with self.assertRaises(ContractError):
            run(t, evaluate=self._fail_eval(failure_branch="VIBES"))

    def test_timeout_status_with_side_effects_is_inconclusive_and_not_retried(self):
        t = task({**HIGH})
        r = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                             "selected_method": "m", "reason": "r", "stop_rule": "s",
                             "requires_authorization": True, "required_scope": ["write"]}
        grant = lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A1",  # noqa: E731
                              "authorized_scope": ["write"]}
        ev = lambda t, f: {"task_id": TID, "status": "READY", "records": [], "critical_unknowns": []}  # noqa: E731
        n = []
        def ex(t, f, e, r):
            n.append(1)
            return {"task_id": TID, "status": "TIMEOUT_UNKNOWN_SIDE_EFFECT"}
        out, calls = run(t, route=r, authorize=grant, evidence=ev, execute=ex)
        self.assertEqual(out["status"], "INCONCLUSIVE")
        self.assertEqual(out["feedback"]["action"], "INSPECT_ACTUAL_STATE_BEFORE_RETRY")
        self.assertTrue(out["unknown_side_effect"])
        self.assertEqual(len(n), 1)  # executed once, never auto-retried
        self.assertNotIn("evaluate", calls)

    def test_timeout_exception_by_side_effect_declaration(self):
        def boom(t, f, e, r):
            raise TimeoutError("slow")
        out, _ = run(execute=boom)  # LOW profile, side_effects False
        self.assertEqual((out["status"], out["failure_class"]), ("FAILED", "TOOL_OR_ADAPTER_ERROR"))
        self.assertNotIn("unknown_side_effect", out)
        t = task({**LOW, "side_effects": True})
        r = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                             "selected_method": "m", "reason": "r", "stop_rule": "s",
                             "requires_authorization": False, "required_scope": ["w"]}
        grant = lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A",  # noqa: E731
                              "authorized_scope": ["w"]}
        ev = lambda t, f: {"task_id": TID, "status": "READY", "records": [], "critical_unknowns": []}  # noqa: E731
        out, _ = run(t, route=r, authorize=grant, evidence=ev, execute=boom)
        self.assertEqual(out["status"], "INCONCLUSIVE")
        self.assertTrue(out["unknown_side_effect"])

    def test_authorization_block_carries_failure_class(self):
        r = lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"],  # noqa: E731
                             "selected_method": "m", "reason": "r", "stop_rule": "s",
                             "requires_authorization": True, "required_scope": ["write"]}
        ev = lambda t, f: {"task_id": TID, "status": "READY", "records": [], "critical_unknowns": []}  # noqa: E731
        out, _ = run(task({**HIGH}), route=r, evidence=ev)
        self.assertEqual(out["failure_class"], "AUTHORIZATION_OR_POLICY_BLOCK")

EV = task({**LOW, "requires_external_evidence": True})


class CancelledTests(unittest.TestCase):
    def test_cancel_before_execution_skips_execute_and_has_no_receipt(self):
        out, calls = run(cancel_requested=lambda t: True)
        self.assertEqual(out["status"], "CANCELLED")
        self.assertNotIn("execute", calls)
        self.assertIn("CANCEL_CHECK", out["trace"])
        self.assertNotIn("run_record", out)

    def test_not_cancelled_runs_normally_and_hook_is_optional(self):
        out, calls = run(EV, cancel_requested=lambda t: False)
        self.assertEqual(out["status"], "PASS")
        self.assertIn("execute", calls)
        out2, _ = run(EV)
        self.assertNotIn("CANCEL_CHECK", out2["trace"])

    def test_non_true_values_do_not_cancel_and_errors_fail_closed(self):
        out, _ = run(EV, cancel_requested=lambda t: "yes")
        self.assertEqual(out["status"], "PASS")

        def boom(t):
            raise RuntimeError("x")
        out, calls = run(cancel_requested=boom)
        self.assertEqual(out["status"], "BLOCKED")
        self.assertNotIn("execute", calls)

    def test_route_can_return_cancelled(self):
        out, calls = run(route=lambda t, f, e: {"task_id": TID, "status": "CANCELLED", "reason": "owner stopped"})
        self.assertEqual(out["status"], "CANCELLED")
        self.assertNotIn("execute", calls)

if __name__ == "__main__":
    unittest.main()
