import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

from adapter_contract import (PLUGIN_FIELDS, REFERENCE_PLUGIN, AdapterContractError,  # noqa: E402
                              declared_side_effects, reference_adapters, validate_plugin_declaration, wrap_plugin)
from foravar_vertical_slice import run_vertical_slice  # noqa: E402

LOW = {"risk_level": "LOW", "requires_external_evidence": True, "requires_diagnostic": False,
       "has_source_conflict": False, "has_critical_unknowns": False, "side_effects": False}


def task():
    return {"task_id": "REF-T", "goal": "count", "profile": dict(LOW), "acceptance_criteria": [
        {"id": "C1", "description": "count correct", "required_evidence_kinds": ["SOURCE_OBSERVATION"]}]}


class PluginDeclarationTests(unittest.TestCase):
    def test_reference_declaration_is_valid_and_has_11_fields(self):
        self.assertEqual(len(PLUGIN_FIELDS), 11)
        self.assertEqual(validate_plugin_declaration(REFERENCE_PLUGIN), [])

    def test_each_missing_field_is_reported(self):
        for f in PLUGIN_FIELDS:
            d = {k: v for k, v in REFERENCE_PLUGIN.items() if k != f}
            self.assertIn(f"missing field: {f}", validate_plugin_declaration(d))

    def test_bad_values(self):
        for k, v in [("timeout", 0), ("timeout", True), ("idempotency", "MAYBE"), ("side_effect_level", "READ_ONLY"),
                     ("tests", []), ("error_types", ["", "x"]), ("input_schema", {"a": "weird"})]:
            self.assertTrue(validate_plugin_declaration({**REFERENCE_PLUGIN, "__": 0, k: v}), (k, v))

    def test_unknown_field_rejected_and_non_mapping(self):
        self.assertIn("unknown field: extra", validate_plugin_declaration({**REFERENCE_PLUGIN, "extra": 1}))
        self.assertTrue(validate_plugin_declaration([]))

    def test_side_effect_declaration_is_not_a_boundary(self):
        self.assertFalse(declared_side_effects(REFERENCE_PLUGIN))
        self.assertTrue(declared_side_effects({**REFERENCE_PLUGIN, "side_effect_level": "UNKNOWN"}))
        self.assertTrue(declared_side_effects({}))  # absent => treated as possible side effects

    def test_side_effecting_without_permission_flagged(self):
        d = {**REFERENCE_PLUGIN, "side_effect_level": "EXTERNAL_WRITE", "permission_requirement": []}
        self.assertTrue(validate_plugin_declaration(d))


class WrapPluginTests(unittest.TestCase):
    def test_schema_enforced_both_ways(self):
        ok = wrap_plugin(REFERENCE_PLUGIN, lambda p: {"words": 2})
        self.assertEqual(ok({"text": "a b"}), {"words": 2})
        with self.assertRaises(AdapterContractError):
            ok({"text": 5})
        with self.assertRaises(AdapterContractError):
            wrap_plugin(REFERENCE_PLUGIN, lambda p: {"words": "2"})({"text": "a"})
        with self.assertRaises(AdapterContractError):
            wrap_plugin(REFERENCE_PLUGIN, lambda p: {"words": True})({"text": "a"})

    def test_declared_error_becomes_failed_undeclared_propagates_timeout_reraised(self):
        def boom(p): raise ValueError("bad")
        self.assertEqual(wrap_plugin(REFERENCE_PLUGIN, boom)({"text": "a"})["status"], "FAILED")
        def other(p): raise KeyError("k")
        with self.assertRaises(KeyError):
            wrap_plugin(REFERENCE_PLUGIN, other)({"text": "a"})
        def slow(p): raise TimeoutError("t")
        with self.assertRaises(TimeoutError):
            wrap_plugin(REFERENCE_PLUGIN, slow)({"text": "a"})

    def test_invalid_declaration_refused_at_wrap_time(self):
        with self.assertRaises(AdapterContractError):
            wrap_plugin({"version": "1"}, lambda p: {})


class EndToEndReferenceTests(unittest.TestCase):
    def test_reference_adapters_reach_pass_with_complete_receipt(self):
        r = run_vertical_slice(task(), reference_adapters("REF-T", "one two three"))
        self.assertEqual(r["status"], "PASS")
        self.assertTrue(r["run_record"]["complete"])
        self.assertEqual(r["execution"]["result_summary"], "words=3")

    def test_deterministic_same_input_same_fingerprint(self):
        a = run_vertical_slice(task(), reference_adapters("REF-T", "x y"))
        b = run_vertical_slice(task(), reference_adapters("REF-T", "x y"))
        self.assertEqual(a["run_record"]["output_fingerprint"], b["run_record"]["output_fingerprint"])
        c = run_vertical_slice(task(), reference_adapters("REF-T", "x y z"))
        self.assertNotEqual(a["run_record"]["output_fingerprint"], c["run_record"]["output_fingerprint"])


if __name__ == "__main__":
    unittest.main()
