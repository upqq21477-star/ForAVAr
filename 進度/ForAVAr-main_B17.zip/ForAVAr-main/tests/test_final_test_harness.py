import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "tools"))
from final_test_harness import RUBRIC, SAMPLES, decide, evaluate, rubric_fingerprint, score, synthetic_conditions  # noqa: E402


def S(kind, exp):
    return {"id": kind, "kind": kind, "text": "t", "expected_status": exp}


class HarnessTests(unittest.TestCase):
    def test_score_counts_false_pass_and_safety_and_keeps_failures(self):
        samples = [S("normal", "PASS"), S("unauthorized_side_effect", "BLOCKED")]
        out = [{"status": "PASS", "cost": 1}, {"status": "PASS", "cost": 3, "side_effect_executed": True}]
        r = score(out, samples)
        self.assertEqual((r["quality"], r["false_pass"], r["safety_violations"], r["cost"]), (0.5, 1, 1, 2.0))
        self.assertEqual(r["failures_kept"], ["unauthorized_side_effect"])

    def test_rubric_fingerprint_detects_change(self):
        self.assertEqual(rubric_fingerprint(), rubric_fingerprint(dict(RUBRIC)))
        self.assertNotEqual(rubric_fingerprint(), rubric_fingerprint({**RUBRIC, "max_cost_ratio_c2_over_c1": 9}))

    def test_decide_paths(self):
        good = {"quality": 1.0, "false_pass": 0, "safety_violations": 0, "cost": 2.0}
        c1 = {"quality": 0.5, "false_pass": 0, "safety_violations": 0, "cost": 1.0}
        self.assertEqual(decide({"C1": c1, "C2": good}, SAMPLES)["decision"], "ADOPT")
        self.assertEqual(decide({"C1": c1, "C2": {**good, "safety_violations": 1}}, SAMPLES)["decision"], "REJECT")
        self.assertEqual(decide({"C1": c1, "C2": {**good, "cost": 9.0}}, SAMPLES)["decision"], "INCONCLUSIVE")
        self.assertEqual(decide({"C1": c1}, SAMPLES)["decision"], "INCONCLUSIVE")
        self.assertEqual(decide({"C1": c1, "C2": good}, SAMPLES[:2])["decision"], "INCONCLUSIVE")

    def test_synthetic_self_test_orders_conditions_and_labels_evidence(self):
        res = evaluate(synthetic_conditions())
        rep = res["report"]
        self.assertEqual(rep["C2"]["quality"], 1.0)
        self.assertEqual(rep["C2"]["safety_violations"], 0)
        self.assertGreater(rep["C0"]["false_pass"], rep["C2"]["false_pass"])
        self.assertGreater(rep["C1"]["safety_violations"], 0)
        self.assertIn("SELF_TEST", res["evidence_class"])
        self.assertNotEqual(res["decision"]["decision"], "REJECT")


if __name__ == "__main__":
    unittest.main()
