"""Integration: vertical slice -> run_record -> retry_policy -> state_bundle -> handoff.

The caller owns the retry loop (the slice never retries); this test is that caller.
All adapters are in-memory fakes: contract-level evidence only.
"""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))

from foravar_vertical_slice import run_vertical_slice  # noqa: E402
from retry_policy import decide_retry  # noqa: E402
from state_bundle import build_bundle, export_handoff, read_bundle, write_bundle  # noqa: E402

TID = "INT-1"
HIGH = {"risk_level": "HIGH", "requires_external_evidence": True, "requires_diagnostic": False,
        "has_source_conflict": False, "has_critical_unknowns": False, "side_effects": True}
OBS = {"evidence_id": "E1", "kind": "SOURCE_OBSERVATION", "status": "OBSERVED",
       "target_revision": "r1", "observed_at": "2026-10-24", "summary": "s"}


def task():
    return {"task_id": TID, "goal": "g", "profile": dict(HIGH), "acceptance_criteria": [
        {"id": "C1", "description": "d", "required_evidence_kinds": ["SOURCE_OBSERVATION"]}]}


def adapters(execute):
    return {
        "frame": lambda t: {"task_id": TID, "status": "READY", "frame_id": "F", "problem_statement": "p",
                            "in_scope": [], "out_of_scope": [], "unknowns": []},
        "evidence": lambda t, f: {"task_id": TID, "status": "READY", "records": [OBS], "critical_unknowns": []},
        "route": lambda t, f, e: {"task_id": TID, "status": "ROUTED", "candidate_methods": ["m"], "selected_method": "m",
                                  "reason": "r", "stop_rule": "s", "requires_authorization": True, "required_scope": ["w"]},
        "authorize": lambda t, r: {"task_id": TID, "status": "AUTHORIZED", "authorization_id": "A", "authorized_scope": ["w"]},
        "execute": execute,
        "evaluate": lambda t, x, e: {"task_id": TID, "criteria_results": [
            {"criterion_id": "C1", "status": "PASS", "evidence_ids": ["E1"]}]},
    }


def good_exec(t, f, e, r):
    return {"task_id": TID, "status": "EXECUTED", "execution_id": "X2", "result_summary": "ok",
            "target_version": "r1", "tool_or_command": "cmd", "exit_status": 0, "environment": "env"}


def timeout_exec(t, f, e, r):
    raise TimeoutError("slow")


class ChainTests(unittest.TestCase):
    def test_timeout_then_inspect_then_retry_then_pass_then_handoff(self):
        budget = {"max_attempts": 3}
        history, receipts = [], []

        # attempt 1: times out -> INCONCLUSIVE with unknown side effect
        r1 = run_vertical_slice(task(), adapters(timeout_exec))
        self.assertEqual(r1["status"], "INCONCLUSIVE")
        self.assertTrue(r1["unknown_side_effect"])
        receipts.append(r1["run_record"])
        history.append({"method": "m", "target": "r1", "status": r1["status"], "unknown_side_effect": True})
        self.assertEqual(decide_retry([], {"method": "m", "target": "r1"}, budget)["decision"], "RETRY")

        # blind retry is refused until the actual state is inspected
        blind = decide_retry(history, {"method": "m2", "target": "r1"}, budget)
        self.assertEqual(blind["decision"], "STOP")
        self.assertEqual(blind["required_action"], "INSPECT_ACTUAL_STATE_BEFORE_RETRY")

        # after inspection with a changed method, a retry is allowed
        ok = decide_retry(history, {"method": "m2", "target": "r1", "actual_state_read": True}, budget)
        self.assertEqual(ok["decision"], "RETRY")
        self.assertIn("DIFFERENT_METHOD", ok["justification"])

        # attempt 2 succeeds
        r2 = run_vertical_slice(task(), adapters(good_exec))
        self.assertEqual(r2["status"], "PASS")
        self.assertTrue(r2["run_record"]["complete"])
        receipts.append(r2["run_record"])

        # P2 checkpoint round trip carries both receipts; PASS in a receipt is not acceptance
        bundle = build_bundle(TID, "P2", task_state={
            "status": r2["status"], "key_decisions": ["retry only after state inspection"],
            "run_records": receipts, "next_action": "none"},
            evidence_state={"verified_results": ["attempt 2 PASS (fake adapters)"]})
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "ckpt.json")
            write_bundle(bundle, path)
            back = read_bundle(path)
            self.assertEqual(len(back["TASK_EXECUTION_STATE"]["run_records"]), 2)
            self.assertEqual(back["TASK_EXECUTION_STATE"]["run_records"][0]["result_status"], "TIMEOUT_UNKNOWN_SIDE_EFFECT")

        h = export_handoff({"task_id": TID, "current_status": r2["status"], "next_action": "none"})
        self.assertEqual(h["current_status"], "PASS")
        self.assertEqual(h["goal"], "NOT_PROVIDED")

    def test_same_input_and_method_after_inspection_still_stops(self):
        hist = [{"method": "m", "target": "r1", "status": "INCONCLUSIVE", "unknown_side_effect": True}]
        r = decide_retry(hist, {"method": "m", "target": "r1", "actual_state_read": True}, {"max_attempts": 3})
        self.assertEqual(r["stop_condition"], "NO_NEW_INFORMATION")


if __name__ == "__main__":
    unittest.main()
