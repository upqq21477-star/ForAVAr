import os
import sys
import tempfile
import unittest

ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(ROOT, "runtime"))
import release_txn as T  # noqa: E402


def _w(root, rel, text):
    p = os.path.join(root, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


def _r(root, rel):
    p = os.path.join(root, rel)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8", newline="") as fh:
        return fh.read()


class ReleaseTxnTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.root = os.path.join(self._t.name, "repo")
        self.snap = os.path.join(self._t.name, "snap")
        _w(self.root, "a.txt", "A1")
        _w(self.root, "sub/b.txt", "B1")

    def tearDown(self):
        self._t.cleanup()

    def test_multi_file_commit_applies_all_including_create_and_delete(self):
        rep = T.apply_transaction(self.root, {"a.txt": "A2", "new/c.txt": "C1", "sub/b.txt": None}, self.snap)
        self.assertEqual(rep["status"], "COMMITTED")
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "new/c.txt"), _r(self.root, "sub/b.txt")), ("A2", "C1", None))
        self.assertEqual(T.classify(self.root, self.snap), "AFTER")

    def test_failed_verify_rolls_back_every_file(self):
        rep = T.apply_transaction(self.root, {"a.txt": "A2", "new/c.txt": "C1"}, self.snap,
                                  verify=lambda r: ["incompatible"])
        self.assertEqual(rep["status"], "ROLLED_BACK")
        self.assertTrue(rep["rollback_verified"])
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "new/c.txt")), ("A1", None))
        self.assertEqual(T.classify(self.root, self.snap), "BEFORE")

    def test_exception_midway_rolls_back_no_partial_state(self):
        def boom(_root):
            raise RuntimeError("verify crashed")
        rep = T.apply_transaction(self.root, {"a.txt": "A2", "sub/b.txt": "B2"}, self.snap, verify=boom)
        self.assertEqual(rep["status"], "ROLLED_BACK")
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "sub/b.txt")), ("A1", "B1"))

    def test_recover_rolls_back_crashed_prepared_release(self):
        T.apply_transaction(self.root, {"a.txt": "A2", "sub/b.txt": "B2"}, self.snap)
        m = T._load(self.snap)
        m["state"] = "PREPARED"  # simulate crash before COMMITTED + one file reverted by hand
        T._write_json(os.path.join(self.snap, "manifest.json"), m)
        _w(self.root, "sub/b.txt", "B1")
        self.assertEqual(T.classify(self.root, self.snap), "PARTIAL")
        self.assertEqual(T.recover(self.root, self.snap), "ROLLED_BACK")
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "sub/b.txt")), ("A1", "B1"))

    def test_explicit_rollback_after_commit_restores_previous_version(self):
        T.apply_transaction(self.root, {"a.txt": "A2", "new/c.txt": "C1"}, self.snap)
        rep = T.rollback(self.root, self.snap)
        self.assertTrue(rep["rollback_verified"])
        self.assertEqual((_r(self.root, "a.txt"), _r(self.root, "new/c.txt")), ("A1", None))

    def test_restore_drill_passes_then_detects_corrupted_snapshot(self):
        T.apply_transaction(self.root, {"a.txt": "A2"}, self.snap)
        self.assertEqual(T.restore_drill(self.snap), [])
        _w(self.snap, "files/a.txt", "tampered")
        self.assertTrue(any("mismatch" in p for p in T.restore_drill(self.snap)))

    def test_path_escape_authority_and_reuse_rejected(self):
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"../x.txt": "x"}, self.snap)
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap)
        rep = T.apply_transaction(self.root, {"docs/blueprint.json": "{}"}, self.snap, authorized=True)
        self.assertEqual(rep["status"], "COMMITTED")
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {"a.txt": "A9"}, self.snap)
        with self.assertRaises(T.TxnError):
            T.apply_transaction(self.root, {}, os.path.join(self._t.name, "s2"))


class PersistCheckpointTests(unittest.TestCase):
    def setUp(self):
        self._t = tempfile.TemporaryDirectory()
        self.root = os.path.join(self._t.name, "repo")
        os.makedirs(self.root)
        self.snap = os.path.join(self._t.name, "snap")
        sys.path.insert(0, os.path.join(ROOT, "tools"))

    def tearDown(self):
        self._t.cleanup()

    def _bundle(self):
        import state_bundle as sb
        b = sb.build_bundle("T/1", "P2", task_state={"status": "DONE", "next_action": "n", "recovery": "r", "run_records": []})
        h = sb.export_handoff({"task_id": "T/1", "goal": "g"})
        return sb, b, h

    def test_persist_writes_bundle_and_handoff_together_and_reads_back(self):
        sb, b, h = self._bundle()
        rep = sb.persist_checkpoint(self.root, self.snap, b, h)
        self.assertEqual(rep["status"], "COMMITTED")
        self.assertEqual(sb.read_bundle(os.path.join(self.root, "state", "T_1.bundle.json"))["task_id"], "T/1")
        self.assertIn("# HANDOFF", _r(self.root, "state/T_1.handoff.md"))

    def test_failed_verify_leaves_no_files_and_p0_writes_nothing(self):
        sb, b, h = self._bundle()
        rep = sb.persist_checkpoint(self.root, self.snap, b, h, verify=lambda r: ["bad"])
        self.assertEqual(rep["status"], "ROLLED_BACK")
        self.assertIsNone(_r(self.root, "state/T_1.bundle.json"))
        self.assertEqual(sb.persist_checkpoint(self.root, os.path.join(self._t.name, "s2"), None)["status"], "SKIPPED_P0")

    def test_authority_path_in_extra_files_refused_before_any_write(self):
        sb, b, h = self._bundle()
        with self.assertRaises(sb.StateBundleError):
            sb.persist_checkpoint(self.root, self.snap, b, h, extra_files={"docs/blueprint.json": "{}"})
        self.assertIsNone(_r(self.root, "state/T_1.bundle.json"))

    def test_standard_verify_reports_failing_command_only(self):
        import standard_verify as sv
        ok = [sys.executable, "-c", "pass"]
        bad = [sys.executable, "-c", "import sys; print('boom'); sys.exit(3)"]
        self.assertEqual(sv.verify(self.root, (ok,)), [])
        out = sv.verify(self.root, (ok, bad))
        self.assertEqual(len(out), 1)
        self.assertIn("boom", out[0])


if __name__ == "__main__":
    unittest.main()
