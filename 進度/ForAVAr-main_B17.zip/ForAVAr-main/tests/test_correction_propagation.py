import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "runtime"))
from correction_propagation import (PropagationError, check_change_set, downstream,  # noqa: E402
                                    fingerprint_plan, plan_correction, symptom_key)

GRAPH = {"spec": [], "code": ["spec"], "test": ["code"], "doc": ["spec"], "other": []}
EV = [{"evidence_id": "E1", "status": "OBSERVED", "bound_to": ["code"]},
      {"evidence_id": "E2", "status": "OBSERVED", "bound_to": ["other"]},
      {"evidence_id": "E3", "status": "DECLARED", "bound_to": ["code"]}]


def plan(**kw):
    base = dict(symptom="x fails", root_cause="TOOL_OR_ADAPTER_ERROR", cause_evidence_ids=["E1"], evidence=EV,
                graph=GRAPH, changed=["code"], tests_by_item={"test": ["tests/test_a.py"], "code": ["tests/test_b.py"]})
    base.update(kw)
    return plan_correction(**base)


class PropagationTests(unittest.TestCase):
    def test_downstream_is_transitive_and_excludes_unrelated(self):
        self.assertEqual(downstream(GRAPH, ["spec"]), {"code", "test", "doc"})
        self.assertEqual(downstream(GRAPH, ["code"]), {"test"})
        with self.assertRaises(PropagationError):
            downstream(GRAPH, ["nope"])

    def test_cycle_terminates(self):
        self.assertEqual(downstream({"a": ["b"], "b": ["a"], "c": ["b"]}, ["a"]), {"b", "c"})

    def test_root_cause_needs_observed_evidence_else_unknown(self):
        self.assertEqual(plan()["root_cause"], "TOOL_OR_ADAPTER_ERROR")
        self.assertEqual(plan(cause_evidence_ids=["E3"])["root_cause"], "UNKNOWN")  # declared, not observed
        self.assertEqual(plan(cause_evidence_ids=[])["root_cause"], "UNKNOWN")
        self.assertEqual(plan(cause_evidence_ids=["missing"])["root_cause"], "UNKNOWN")
        self.assertEqual(plan(root_cause=None)["root_cause"], "UNKNOWN")
        with self.assertRaises(PropagationError):
            plan(root_cause="MADE_UP")

    def test_plan_sets_and_invalidation_and_regression(self):
        p = plan()
        self.assertEqual(p["impact_set"], ["test"])
        self.assertEqual(p["allowed_to_change"], ["code", "test"])
        self.assertEqual(p["invalidate_evidence"], ["E1", "E3"])  # bound to changed code; E2 untouched
        self.assertEqual(p["regression_checks"], ["tests/test_a.py", "tests/test_b.py"])

    def test_change_outside_plan_is_flagged(self):
        p = plan()
        self.assertEqual(check_change_set(p, ["code", "test"]), [])
        self.assertEqual(check_change_set(p, ["code", "doc"]), ["doc"])

    def test_repeated_symptom_reuses_problem_id(self):
        key = symptom_key("X  FAILS")
        self.assertEqual(key, symptom_key("x fails"))
        p = plan(known_problems={key: "PR-7"})
        self.assertEqual((p["problem_id"], p["mint_new_problem_id"]), ("PR-7", False))
        q = plan(symptom="different")
        self.assertTrue(q["mint_new_problem_id"])

    def test_empty_change_rejected_and_plan_is_deterministic(self):
        with self.assertRaises(PropagationError):
            plan(changed=[])
        self.assertEqual(fingerprint_plan(plan()), fingerprint_plan(plan()))


if __name__ == "__main__":
    unittest.main()
