"""Correction propagation planner (blueprint runtime_contract.correction_propagation).

Pure planning/checking functions; they never mutate files. Five rules:
1 root cause must be evidence-supported, otherwise UNKNOWN;
2 impact/dependency set and exact change set are fixed BEFORE mutation;
3 only affected items may change (check_change_set flags anything outside the plan);
4 evidence bound to changed items is invalidated (listed, not deleted);
5 relevant regression checks are named; a repeated symptom reuses the existing problem ID.
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Iterable, Mapping, Sequence
from typing import Any

try:
    from .foravar_vertical_slice import FAILURE_CLASSES
except ImportError:  # direct import with runtime/ on sys.path
    from foravar_vertical_slice import FAILURE_CLASSES


class PropagationError(ValueError):
    """Raised for malformed inputs or a change set that exceeds the planned impact."""


def downstream(graph: Mapping[str, Sequence[str]], changed: Iterable[str]) -> set[str]:
    """Items that transitively depend on any changed item. graph = {item: [items it depends on]}."""
    changed = set(changed)
    unknown = sorted(c for c in changed if c not in graph and not any(c in d for d in graph.values()))
    if unknown:
        raise PropagationError(f"changed items not in dependency graph: {unknown}")
    affected: set[str] = set()
    frontier = set(changed)
    while frontier:
        nxt = {n for n, deps in graph.items() if n not in affected and n not in changed and frontier & set(deps)}
        affected |= nxt
        frontier = nxt
    return affected


def symptom_key(symptom: str) -> str:
    """Stable key so a repeated symptom maps to the same problem ID."""
    return hashlib.sha256(" ".join(symptom.lower().split()).encode("utf-8")).hexdigest()[:16]


def plan_correction(
    *,
    symptom: str,
    root_cause: str | None,
    cause_evidence_ids: Sequence[str],
    evidence: Sequence[Mapping[str, Any]],
    graph: Mapping[str, Sequence[str]],
    changed: Sequence[str],
    tests_by_item: Mapping[str, Sequence[str]] | None = None,
    known_problems: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    """Build the plan that must exist before any mutation.

    evidence: records with evidence_id, status and optional bound_to (items they depend on).
    known_problems: {symptom_key: problem_id}; a match reuses the ID (never mint a duplicate).
    """
    if not changed:
        raise PropagationError("changed must name at least one item")
    by_id = {e.get("evidence_id"): e for e in evidence}
    supported = bool(cause_evidence_ids) and all(
        by_id.get(i, {}).get("status") == "OBSERVED" for i in cause_evidence_ids)
    if root_cause is not None and root_cause not in FAILURE_CLASSES:
        raise PropagationError(f"root_cause must be one of FAILURE_CLASSES or None: {root_cause}")
    effective_cause = root_cause if (root_cause and supported) else "UNKNOWN"

    affected = downstream(graph, changed)
    touched = set(changed) | affected
    invalidated = sorted(e["evidence_id"] for e in evidence
                         if e.get("evidence_id") and touched & set(e.get("bound_to", [])))
    tests = tests_by_item or {}
    regression = sorted({t for item in touched for t in tests.get(item, [])})
    key = symptom_key(symptom)
    existing = (known_problems or {}).get(key)
    return {
        "root_cause": effective_cause,
        "root_cause_supported": effective_cause != "UNKNOWN",
        "change_set": sorted(set(changed)),
        "impact_set": sorted(affected),
        "allowed_to_change": sorted(touched),
        "invalidate_evidence": invalidated,
        "regression_checks": regression,
        "symptom_key": key,
        "problem_id": existing,
        "mint_new_problem_id": existing is None,
    }


def check_change_set(plan: Mapping[str, Any], actually_changed: Iterable[str]) -> list[str]:
    """Return items changed outside the plan (empty = within plan). Rule 3: only affected items change."""
    allowed = set(plan["allowed_to_change"])
    return sorted(set(actually_changed) - allowed)


def fingerprint_plan(plan: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(plan, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
