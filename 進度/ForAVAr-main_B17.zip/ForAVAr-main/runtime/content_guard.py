"""Content-level scan of untrusted text (PR-009). Heuristic, fail-closed, stdlib only.

Authorization stays fail-closed in policy_gate regardless of content; this adds a second,
content-level layer: evidence whose summary looks like an embedded instruction is
QUARANTINED (status != OBSERVED), so the slice can no longer cite it as proof -> UNKNOWN.
Limits (honest): regex heuristics, EN + Traditional Chinese only; paraphrased or encoded
injection is NOT detected; quoting an attack in a security document will false-positive
(that is the safe direction). It never executes or follows anything it scans.
"""
from __future__ import annotations

import re
from collections.abc import Mapping
from typing import Any

_P = {
    "OVERRIDE_EN": r"\b(ignore|disregard|forget|override)\b[^.\n]{0,30}\b(instructions?|rules?|prompts?|polic(?:y|ies)|guidelines?)\b",
    "ROLE_EN": r"\byou are now\b|\bact as (?:a |an )?(?:system|admin|root|developer)\b|\bnew instructions?\s*:",
    "EXFIL_EN": r"\b(reveal|print|send|leak)\b[^.\n]{0,30}\b(system prompt|api[ _-]?key|secret|password|token)s?\b",
    "EXEC_EN": r"\b(run|execute)\b[^.\n]{0,20}\b(the following|this)\b[^.\n]{0,20}\b(command|script|code)\b|\b(curl|wget)\b[^\n]{0,80}\|\s*(sh|bash)\b",
    "AUTH_CLAIM_EN": r"\b(authorization|permission)\s+(is\s+)?granted\b|\buser (has )?(approved|authorized)\b|\bdo not tell the user\b",
    "OVERRIDE_ZH": r"(忽略|無視|忘記|覆寫)[^。\n]{0,12}(指令|規則|提示|政策|限制)",
    "ROLE_ZH": r"你現在是|新的指示\s*[:：]|系統提示",
    "EXFIL_ZH": r"(洩漏|輸出|傳送|告訴我)[^。\n]{0,12}(系統提示|金鑰|密碼|憑證|token)",
    "EXEC_ZH": r"執行(以下|下列|這個)[^。\n]{0,6}(指令|命令|腳本|程式)",
    "AUTH_CLAIM_ZH": r"(已獲授權|已經授權|使用者已(核准|同意|授權)|不要告訴使用者)",
}
_RX = {k: re.compile(v, re.IGNORECASE) for k, v in _P.items()}
QUARANTINED = "QUARANTINED"


def scan_untrusted(text: Any) -> list[dict[str, str]]:
    """Return findings [{pattern_id, excerpt}] for instruction-like content in ``text``."""
    if not isinstance(text, str):
        return []
    out = []
    for pid, rx in _RX.items():
        m = rx.search(text)
        if m:
            out.append({"pattern_id": pid, "excerpt": m.group(0)[:40]})
    return out


def quarantine_if_injected(record: Mapping[str, Any]) -> dict[str, Any]:
    """Copy of an evidence record; OBSERVED + instruction-like text -> status QUARANTINED.

    Scans every string field. Findings are attached as ``injection_findings`` (never executed).
    """
    rec = dict(record)
    findings = [f for v in rec.values() for f in scan_untrusted(v)]
    if findings:
        rec["injection_findings"] = findings
        if rec.get("status") == "OBSERVED":
            rec["status"] = QUARANTINED
    return rec
