"""Plugin/adapter contract validator and a deterministic reference adapter set
(blueprint roles_and_plugins.plugin_contract, 11 fields).

EXAMPLE ONLY. The reference adapters are pure functions over in-memory input; they prove
the contract is wireable end to end, NOT that any real adapter works
(real_adapter_wiring stays NOT_VERIFIED). A plugin-declared side_effect_level is a
declaration, not an execution security boundary: ``declared_side_effects`` only decides
what to put in the task profile, and the policy gate still treats anything other than an
explicit NONE as possible side effects.
"""
from __future__ import annotations

from collections.abc import Callable, Mapping
from typing import Any

PLUGIN_FIELDS = (
    "input_schema", "output_schema", "error_types", "timeout", "idempotency",
    "side_effect_level", "permission_requirement", "evidence_fields", "version",
    "fallback_or_replacement", "tests",
)
SIDE_EFFECT_LEVELS = {"NONE", "LOCAL_WRITE", "EXTERNAL_WRITE", "UNKNOWN"}
IDEMPOTENCY = {"IDEMPOTENT", "NON_IDEMPOTENT", "UNKNOWN"}
_TYPES = {"str": str, "int": int, "float": (int, float), "bool": bool, "list": list, "dict": dict}


class AdapterContractError(ValueError):
    """Raised when a plugin output violates its declared output_schema."""


def _nonempty_str_list(v: Any) -> bool:
    return isinstance(v, list) and bool(v) and all(isinstance(x, str) and x.strip() for x in v)


def validate_plugin_declaration(decl: Mapping[str, Any]) -> list[str]:
    """Return a list of problems (empty = declaration is well formed). Never raises."""
    if not isinstance(decl, Mapping):
        return ["declaration must be an object"]
    errors = [f"missing field: {f}" for f in PLUGIN_FIELDS if f not in decl]
    unknown = sorted(set(decl) - set(PLUGIN_FIELDS) - {"id", "name"})
    errors += [f"unknown field: {k}" for k in unknown]
    for f in ("input_schema", "output_schema"):
        s = decl.get(f)
        if f in decl and not (isinstance(s, Mapping) and s and all(t in _TYPES for t in s.values())):
            errors.append(f"{f} must be a non-empty {{field: type}} map, types in {sorted(_TYPES)}")
    if "error_types" in decl and not _nonempty_str_list(decl["error_types"]):
        errors.append("error_types must be a non-empty list of names")
    t = decl.get("timeout")
    if "timeout" in decl and (isinstance(t, bool) or not isinstance(t, (int, float)) or t <= 0):
        errors.append("timeout must be a positive number (seconds)")
    if "idempotency" in decl and decl["idempotency"] not in IDEMPOTENCY:
        errors.append(f"idempotency must be one of {sorted(IDEMPOTENCY)}")
    if "side_effect_level" in decl and decl["side_effect_level"] not in SIDE_EFFECT_LEVELS:
        errors.append(f"side_effect_level must be one of {sorted(SIDE_EFFECT_LEVELS)}")
    if "permission_requirement" in decl and not isinstance(decl["permission_requirement"], list):
        errors.append("permission_requirement must be a list of scopes ([] = none)")
    if "evidence_fields" in decl and not _nonempty_str_list(decl["evidence_fields"]):
        errors.append("evidence_fields must be a non-empty list")
    if "version" in decl and not (isinstance(decl["version"], str) and decl["version"].strip()):
        errors.append("version must be a non-empty string")
    fb = decl.get("fallback_or_replacement")
    if "fallback_or_replacement" in decl and not (isinstance(fb, str) and fb.strip()):
        errors.append("fallback_or_replacement must be a capability ID or 'NONE'")
    if "tests" in decl and not _nonempty_str_list(decl["tests"]):
        errors.append("tests must be a non-empty list of test references")
    if decl.get("side_effect_level") in {"LOCAL_WRITE", "EXTERNAL_WRITE", "UNKNOWN"} and \
            decl.get("idempotency") == "IDEMPOTENT" and not decl.get("permission_requirement"):
        errors.append("side-effecting plugin declares no permission_requirement")
    return errors


def declared_side_effects(decl: Mapping[str, Any]) -> bool:
    """Profile value for side_effects: False only for an explicit NONE (declaration, not a boundary)."""
    return decl.get("side_effect_level") != "NONE"


def check_schema(payload: Mapping[str, Any], schema: Mapping[str, str], what: str) -> None:
    for key, tname in schema.items():
        if key not in payload:
            raise AdapterContractError(f"{what}: missing '{key}'")
        v = payload[key]
        if (tname != "bool" and isinstance(v, bool)) or not isinstance(v, _TYPES[tname]):
            raise AdapterContractError(f"{what}: '{key}' must be {tname}")


def wrap_plugin(decl: Mapping[str, Any], fn: Callable[[Mapping[str, Any]], Mapping[str, Any]]) -> Callable[[Mapping[str, Any]], dict[str, Any]]:
    """Wrap a plugin callable: validate input/output against the declared schemas.

    Declared error types become status=FAILED results; TimeoutError is re-raised so the
    runtime's unknown-side-effect handling applies. Undeclared exceptions propagate.
    """
    problems = validate_plugin_declaration(decl)
    if problems:
        raise AdapterContractError("; ".join(problems))
    declared = set(decl["error_types"])

    def call(payload: Mapping[str, Any]) -> dict[str, Any]:
        check_schema(payload, decl["input_schema"], "input")
        try:
            out = dict(fn(payload))
        except TimeoutError:
            raise
        except Exception as exc:  # noqa: BLE001
            if type(exc).__name__ in declared:
                return {"status": "FAILED", "error_type": type(exc).__name__, "reason": str(exc)}
            raise
        check_schema(out, decl["output_schema"], "output")
        return out

    return call


# ---- deterministic reference example -------------------------------------------------

REFERENCE_PLUGIN = {
    "id": "reference.word_count", "name": "deterministic word counter (example)",
    "input_schema": {"text": "str"}, "output_schema": {"words": "int"},
    "error_types": ["ValueError"], "timeout": 1, "idempotency": "IDEMPOTENT",
    "side_effect_level": "NONE", "permission_requirement": [],
    "evidence_fields": ["evidence_id", "kind", "status", "target_revision", "observed_at", "summary"],
    "version": "0.1.0", "fallback_or_replacement": "NONE",
    "tests": ["tests/test_adapter_contract.py"],
}


def reference_adapters(task_id: str, text: str) -> dict[str, Callable[..., Any]]:
    """Five-adapter set for run_vertical_slice: count words in ``text``. Fully deterministic."""
    counter = wrap_plugin(REFERENCE_PLUGIN, lambda p: {"words": len(p["text"].split())})

    def frame(t):
        return {"task_id": task_id, "status": "READY", "frame_id": "REF-F1",
                "problem_statement": "count words", "in_scope": ["text"], "out_of_scope": [], "unknowns": []}

    def evidence(t, f):
        return {"task_id": task_id, "status": "READY", "critical_unknowns": [], "records": [
            {"evidence_id": "REF-E1", "kind": "SOURCE_OBSERVATION", "status": "OBSERVED",
             "target_revision": "ref-1", "observed_at": "2026-01-01", "summary": "input text"}]}

    def route(t, f, e):
        return {"task_id": task_id, "status": "ROUTED", "candidate_methods": ["reference.word_count"],
                "selected_method": "reference.word_count", "reason": "only method", "stop_rule": "one pass",
                "requires_authorization": False, "required_scope": []}

    def execute(t, f, e, r):
        out = counter({"text": text})
        return {"task_id": task_id, "status": "EXECUTED", "execution_id": "REF-X1",
                "result_summary": f"words={out['words']}", "target_version": "ref-1",
                "tool_or_command": "reference.word_count", "exit_status": 0, "environment": "stdlib-python",
                "timestamp": "2026-01-01T00:00:00+00:00"}

    def evaluate(t, x, e):
        ok = x["result_summary"] == f"words={len(text.split())}"
        return {"task_id": task_id, "criteria_results": [
            {"criterion_id": "C1", "status": "PASS" if ok else "FAIL", "evidence_ids": ["REF-E1"]}]}

    return {"frame": frame, "evidence": evidence, "route": route, "execute": execute, "evaluate": evaluate}
