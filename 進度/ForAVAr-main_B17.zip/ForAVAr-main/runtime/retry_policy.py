"""Bounded retry decision (blueprint runtime_contract.retry_policy).

Pure decision function: it never loops, executes or sleeps. The caller keeps the
attempt history and acts on the decision. Rule: retries are bounded, and a retry is
allowed only with new evidence, a discriminating change, a different method, or a
changed target. Repeating the same input and method is not independent verification.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import Any

STOP_CONDITIONS = (
    "ACCEPTANCE_SATISFIED",
    "AUTHORITY_UNAVAILABLE",
    "NOT_DECISION_RELEVANT",
    "BUDGET_EXHAUSTED",
    "NO_NEW_INFORMATION",
)


class RetryPolicyError(ValueError):
    """Raised when the retry inputs are malformed (e.g. no explicit bound)."""


def _stop(condition: str, reason: str, failure_class: str | None = None, **extra: Any) -> dict[str, Any]:
    return {"decision": "STOP", "stop_condition": condition, "reason": reason, "failure_class": failure_class, **extra}


def decide_retry(
    history: Sequence[Mapping[str, Any]],
    proposed: Mapping[str, Any],
    budget: Mapping[str, Any],
) -> dict[str, Any]:
    """Decide RETRY or STOP for one proposed attempt.

    history  : prior attempts; each may carry method, target, input_fingerprint,
               new_evidence_ids (list[str]), status, unknown_side_effect (bool).
    proposed : method, target, input_fingerprint, new_evidence_ids, discriminating_change (bool),
               actual_state_read (bool, True once the real state was inspected).
    budget   : max_attempts (required int >= 1); optional max_cost/spent_cost; flags
               acceptance_satisfied, authority_available (default True),
               decision_relevant (default True).
    """
    max_attempts = budget.get("max_attempts")
    if isinstance(max_attempts, bool) or not isinstance(max_attempts, int) or max_attempts < 1:
        raise RetryPolicyError("budget.max_attempts must be an explicit integer >= 1 (retries must be bounded)")
    for key in ("max_cost", "spent_cost"):
        if key in budget and (isinstance(budget[key], bool) or not isinstance(budget[key], (int, float)) or budget[key] < 0):
            raise RetryPolicyError(f"budget.{key} must be a non-negative number")

    if budget.get("acceptance_satisfied") is True:
        return _stop("ACCEPTANCE_SATISFIED", "acceptance conditions are already satisfied")
    if budget.get("authority_available", True) is not True:
        return _stop("AUTHORITY_UNAVAILABLE", "required authority, permission or source is unavailable",
                     "AUTHORIZATION_OR_POLICY_BLOCK")
    if budget.get("decision_relevant", True) is not True:
        return _stop("NOT_DECISION_RELEVANT", "remaining information would not change the decision")

    attempts = len(history)
    if attempts >= max_attempts:
        return _stop("BUDGET_EXHAUSTED", f"attempt limit reached ({attempts}/{max_attempts})", "COST_OR_STOP_ERROR")
    if "max_cost" in budget and budget.get("spent_cost", 0) >= budget["max_cost"]:
        return _stop("BUDGET_EXHAUSTED", "cost budget exhausted", "COST_OR_STOP_ERROR")

    last = dict(history[-1]) if history else {}
    if last and (last.get("unknown_side_effect") is True or last.get("status") == "INCONCLUSIVE") \
            and proposed.get("actual_state_read") is not True:
        # Partial failure / unknown side effect: read the real state first, never blind-retry.
        return {"decision": "STOP", "stop_condition": None, "failure_class": None,
                "reason": "previous attempt left unknown side effects; inspect the actual state before any retry",
                "required_action": "INSPECT_ACTUAL_STATE_BEFORE_RETRY"}

    if not history:
        return {"decision": "RETRY", "reason": "first attempt", "justification": ["FIRST_ATTEMPT"], "attempts_used": 0}

    seen_evidence = {e for h in history for e in h.get("new_evidence_ids", [])}
    new_evidence = [e for e in proposed.get("new_evidence_ids", []) if e not in seen_evidence]
    justification: list[str] = []
    if new_evidence:
        justification.append("NEW_EVIDENCE")
    if proposed.get("discriminating_change") is True:
        justification.append("DISCRIMINATING_CHANGE")
    if proposed.get("method") != last.get("method"):
        justification.append("DIFFERENT_METHOD")
    if proposed.get("target") != last.get("target"):
        justification.append("CHANGED_TARGET")
    if not justification:
        return _stop("NO_NEW_INFORMATION", "same input and method with no new evidence, change or target",
                     "COST_OR_STOP_ERROR")
    return {"decision": "RETRY", "reason": "retry is justified", "justification": justification,
            "attempts_used": attempts}
