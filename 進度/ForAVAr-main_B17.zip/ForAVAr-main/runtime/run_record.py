"""RunRecord builder (blueprint runtime_contract.run_record).

A RunRecord is an *execution receipt*: what was run, where, with what outcome. It is
never acceptance of the deliverable (INV-08). Fields the adapter did not supply are
recorded as None and listed in ``missing`` -- they are never fabricated. The only
runtime-supplied fields are the timestamp (from an injectable clock) and the
output fingerprint (computed from the execution result).

This module does not persist anything; persistence belongs to the state bundle.
"""
from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Mapping
from datetime import datetime, timezone
from typing import Any

RUN_RECORD_FIELDS = (
    "task_id",
    "run_id",
    "target_version",
    "timestamp",
    "tool_or_command",
    "exit_status",
    "environment",
    "output_fingerprint",
    "evidence_ids",
    "result_status",
)
EXECUTION_EVIDENCE_KINDS = {"PROGRAM_TEST", "RUNTIME_OBSERVATION", "EXECUTION_OBSERVATION"}


def fingerprint(payload: Any) -> str:
    """sha256 over canonical JSON (sorted keys, no whitespace, UTF-8)."""
    canonical = json.dumps(payload, sort_keys=True, ensure_ascii=False, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def run_record_required(profile: Mapping[str, Any], criteria: list[Mapping[str, Any]]) -> bool:
    """Required when actual execution/side-effect evidence is required.

    Unknown side-effect metadata counts as possible side effects, matching the policy gate.
    """
    if profile.get("side_effects") is not False:
        return True
    return any(EXECUTION_EVIDENCE_KINDS & set(c.get("required_evidence_kinds", [])) for c in criteria)


def _clean(value: Any) -> Any:
    return value.strip() if isinstance(value, str) and value.strip() else (None if isinstance(value, str) else value)


def build_run_record(
    task_id: str,
    execution: Mapping[str, Any] | None,
    *,
    result_status: str,
    required: bool,
    clock: Callable[[], str] | None = None,
) -> dict[str, Any]:
    """Build a receipt from an execution result (or None when the adapter raised/timed out)."""
    ex = dict(execution or {})
    records = [r for r in ex.get("evidence_records", []) if isinstance(r, Mapping)]
    evidence_ids = [r["evidence_id"] for r in records if isinstance(r.get("evidence_id"), str)]
    exit_status = ex.get("exit_status")
    record: dict[str, Any] = {
        "task_id": task_id,
        "run_id": _clean(ex.get("run_id") or ex.get("execution_id")),
        "target_version": _clean(ex.get("target_version")),
        "timestamp": _clean(ex.get("timestamp")),
        "tool_or_command": _clean(ex.get("tool_or_command")),
        "exit_status": exit_status if isinstance(exit_status, int) and not isinstance(exit_status, bool) else None,
        "environment": _clean(ex.get("environment")),
        "output_fingerprint": None,
        "evidence_ids": evidence_ids,
        "result_status": result_status,
    }
    timestamp_source = "ADAPTER"
    if record["timestamp"] is None:
        record["timestamp"] = (clock or (lambda: datetime.now(timezone.utc).isoformat()))()
        timestamp_source = "RUNTIME_CLOCK"
    if execution is not None:
        record["output_fingerprint"] = fingerprint(
            {"result_summary": ex.get("result_summary"), "evidence_ids": sorted(evidence_ids)}
        )
    missing = [f for f in RUN_RECORD_FIELDS if f != "evidence_ids" and record[f] is None]
    record["required"] = required
    record["complete"] = not missing
    record["missing"] = missing
    record["timestamp_source"] = timestamp_source
    return record
