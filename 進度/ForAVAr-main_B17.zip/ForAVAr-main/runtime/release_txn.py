"""Multi-file release transaction with snapshot, rollback and restore drill.

Closes the A-severity gaps PR-017 (incompatible/partial release, failed rollback),
PR-026 (versioned but not truly recoverable) and PR-028 (multi-file partial success).
Stdlib only; no GitHub operations; never decides *what* to change, only applies it safely.

Flow: validate paths -> snapshot originals (sha256) -> journal PREPARED -> stage new content
-> replace files -> optional verify callback -> journal COMMITTED. Any failure (or a failed
verify) restores every file from the snapshot and journals ROLLED_BACK. A crash between
PREPARED and COMMITTED is detected by ``recover`` and rolled back.
Authority files (docs/*.json) need ``authorized=True`` (PR-050); the caller owns authorization.
Concurrency: an exclusive lock file (O_EXCL, stale after LOCK_TTL_SECONDS) serialises transactions
on one repo root across processes. Atomicity is per file via os.replace plus snapshot rollback
for the set (not an OS-level transaction); network filesystems without O_EXCL are unsupported.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import tempfile
import time
from collections.abc import Callable, Mapping
from contextlib import contextmanager
from typing import Any

SCHEMA = "foravar.release_txn/1"
AUTHORITY = {"blueprint.json", "operating_contract.json", "capability_registry.json",
             "problem_register.json", "index.json"}
STATES = ("PREPARED", "COMMITTED", "ROLLED_BACK")
LOCK_NAME = ".foravar_txn.lock"
LOCK_TTL_SECONDS = 600  # a lock older than this is treated as stale (crashed holder)


class TxnError(ValueError):
    """Raised for invalid change sets or unusable snapshots."""


def _sha(path: str) -> str | None:
    if not os.path.isfile(path):
        return None
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        h.update(fh.read())
    return h.hexdigest()


def _sha_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _safe_rel(root: str, rel: str) -> str:
    norm = os.path.normpath(rel).replace("\\", "/")
    if os.path.isabs(rel) or norm.startswith("..") or norm in (".", ""):
        raise TxnError(f"path escapes repo root: {rel}")
    full = os.path.abspath(os.path.join(root, norm))
    if not full.startswith(os.path.abspath(root) + os.sep):
        raise TxnError(f"path escapes repo root: {rel}")
    return norm


@contextmanager
def _lock(root: str):
    path = os.path.join(root, LOCK_NAME)
    os.makedirs(root, exist_ok=True)
    for attempt in (0, 1):
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            break
        except FileExistsError:
            try:
                stale = time.time() - os.path.getmtime(path) > LOCK_TTL_SECONDS
            except OSError:
                stale = True
            if attempt == 0 and stale:
                try:
                    os.unlink(path)
                except OSError:
                    pass
                continue
            raise TxnError("repo is locked by another transaction") from None
    try:
        os.write(fd, str(os.getpid()).encode())
        os.close(fd)
        yield
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass


def _write_json(path: str, data: Mapping[str, Any]) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=os.path.dirname(path), suffix=".tmp")
    with os.fdopen(fd, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, sort_keys=True, indent=2)
    os.replace(tmp, path)


def _load(snap_dir: str) -> dict[str, Any]:
    try:
        with open(os.path.join(snap_dir, "manifest.json"), encoding="utf-8") as fh:
            m = json.load(fh)
    except (OSError, ValueError) as exc:
        raise TxnError(f"manifest unreadable: {exc}") from exc
    if m.get("schema") != SCHEMA or m.get("state") not in STATES:
        raise TxnError("manifest schema/state invalid")
    return m


def _restore(root: str, snap_dir: str, manifest: Mapping[str, Any]) -> None:
    for rel, info in manifest["files"].items():
        dest = os.path.join(root, rel)
        if info["before"] is None:
            if os.path.exists(dest):
                os.unlink(dest)
            continue
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        shutil.copyfile(os.path.join(snap_dir, "files", rel), dest)


def _apply_transaction(root: str, changes: Mapping[str, str | None], snap_dir: str, *,
                      authorized: bool = False,
                      verify: Callable[[str], list[str]] | None = None) -> dict[str, Any]:
    """Apply ``{relative_path: new_text | None(delete)}`` as one unit.

    ``verify(root)`` returns a list of problems; non-empty means incompatible -> full rollback.
    Returns a report with status COMMITTED or ROLLED_BACK (never a partial state).
    """
    if not changes:
        raise TxnError("empty change set")
    rels = {_safe_rel(root, r): v for r, v in changes.items()}
    if not authorized and any(os.path.basename(r) in AUTHORITY and "docs" in r.split("/") for r in rels):
        raise TxnError("authority files require authorized=True")
    if os.path.exists(os.path.join(snap_dir, "manifest.json")):
        raise TxnError("snapshot dir already used; use a fresh directory")
    files: dict[str, Any] = {}
    for rel, new in rels.items():
        src = os.path.join(root, rel)
        before = _sha(src)
        if before is not None:
            os.makedirs(os.path.dirname(os.path.join(snap_dir, "files", rel)), exist_ok=True)
            shutil.copyfile(src, os.path.join(snap_dir, "files", rel))
        after = None if new is None else _sha_bytes(new.encode("utf-8"))
        files[rel] = {"before": before, "after": after}
    manifest = {"schema": SCHEMA, "state": "PREPARED", "files": files}
    _write_json(os.path.join(snap_dir, "manifest.json"), manifest)
    problems: list[str] = []
    staged: dict[str, str] = {}
    try:
        for rel, new in rels.items():  # stage everything first; nothing live is touched yet
            if new is None:
                continue
            dest = os.path.join(root, rel)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            fd, tmp = tempfile.mkstemp(dir=os.path.dirname(dest), suffix=".stage")
            with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
                fh.write(new)
            staged[rel] = tmp
        for rel, new in rels.items():
            dest = os.path.join(root, rel)
            if new is None:
                if os.path.exists(dest):
                    os.unlink(dest)
            else:
                os.replace(staged.pop(rel), dest)
        if verify is not None:
            problems = list(verify(root))
        else:
            problems = [f"hash mismatch: {r}" for r, i in files.items() if _sha(os.path.join(root, r)) != i["after"]]
    except BaseException as exc:  # noqa: BLE001 - always roll back, then report
        problems = [f"apply failed: {type(exc).__name__}: {exc}"]
    finally:
        for tmp in staged.values():
            if os.path.exists(tmp):
                os.unlink(tmp)
    if problems:
        _restore(root, snap_dir, manifest)
        restored_ok = all(_sha(os.path.join(root, r)) == i["before"] for r, i in files.items())
        manifest["state"] = "ROLLED_BACK"
        _write_json(os.path.join(snap_dir, "manifest.json"), manifest)
        return {"status": "ROLLED_BACK", "problems": problems, "rollback_verified": restored_ok,
                "files": sorted(files)}
    manifest["state"] = "COMMITTED"
    _write_json(os.path.join(snap_dir, "manifest.json"), manifest)
    return {"status": "COMMITTED", "problems": [], "rollback_verified": None, "files": sorted(files)}


def apply_transaction(root: str, changes: Mapping[str, str | None], snap_dir: str, *,
                      authorized: bool = False,
                      verify: Callable[[str], list[str]] | None = None) -> dict[str, Any]:
    """Locked wrapper: see ``_apply_transaction``. Raises TxnError if another transaction holds the lock."""
    with _lock(root):
        return _apply_transaction(root, changes, snap_dir, authorized=authorized, verify=verify)


def classify(root: str, snap_dir: str) -> str:
    """BEFORE / AFTER / PARTIAL: where the live files stand relative to the snapshot manifest."""
    m = _load(snap_dir)
    cur = {r: _sha(os.path.join(root, r)) for r in m["files"]}
    if all(cur[r] == i["before"] for r, i in m["files"].items()):
        return "BEFORE"
    if all(cur[r] == i["after"] for r, i in m["files"].items()):
        return "AFTER"
    return "PARTIAL"


def _recover(root: str, snap_dir: str) -> str:
    """Crash recovery: a PREPARED (never committed) or PARTIAL release is rolled back."""
    m = _load(snap_dir)
    state = classify(root, snap_dir)
    if m["state"] == "PREPARED" or state == "PARTIAL":
        _restore(root, snap_dir, m)
        m["state"] = "ROLLED_BACK"
        _write_json(os.path.join(snap_dir, "manifest.json"), m)
        return "ROLLED_BACK"
    return m["state"]


def _rollback(root: str, snap_dir: str) -> dict[str, Any]:
    """Explicit post-commit rollback to the snapshot (previous version); result is verified."""
    m = _load(snap_dir)
    _restore(root, snap_dir, m)
    ok = all(_sha(os.path.join(root, r)) == i["before"] for r, i in m["files"].items())
    m["state"] = "ROLLED_BACK"
    _write_json(os.path.join(snap_dir, "manifest.json"), m)
    return {"status": "ROLLED_BACK", "rollback_verified": ok}


def recover(root: str, snap_dir: str) -> str:
    with _lock(root):
        return _recover(root, snap_dir)


def rollback(root: str, snap_dir: str) -> dict[str, Any]:
    with _lock(root):
        return _rollback(root, snap_dir)


def restore_drill(snap_dir: str) -> list[str]:
    """PR-026: prove the snapshot can really restore. Copies it to a scratch dir and re-hashes.

    Returns problems (empty = every pre-change file is present and matches its recorded hash).
    """
    m = _load(snap_dir)
    problems: list[str] = []
    with tempfile.TemporaryDirectory() as scratch:
        for rel, info in m["files"].items():
            if info["before"] is None:
                continue
            src = os.path.join(snap_dir, "files", rel)
            if not os.path.isfile(src):
                problems.append(f"snapshot file missing: {rel}")
                continue
            dst = os.path.join(scratch, rel)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copyfile(src, dst)
            if _sha(dst) != info["before"]:
                problems.append(f"snapshot hash mismatch: {rel}")
    return problems
